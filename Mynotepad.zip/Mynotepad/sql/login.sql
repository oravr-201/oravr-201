set sqlprompt "_user'@'_connect_identifier> "
set linesize 190
set pages 1000
set long 32000
col name for a60
col OWNER for a25
col OBJECT_NAME for a40
col SPID for a10
col PROGRAM for a40
col TRACEID for a25
col TRACEFILE for a65
col inst_name for a20
col host_name for a30
col member for a70
col file_name for a70
col OS_USERNAME for a20
col username for a20
col userhost for a20
col TERMINAL for a15
col TIMESTAMP for a30
col ACTION_NAME for a10
col ACCOUNT_STATUS for a16
col tablespace_name for a40
-- Used by Trusted Oracle
COLUMN ROWLABEL FORMAT A15
-- Used for the SHOW ERRORS command
COLUMN LINE/COL FORMAT A8
COLUMN ERROR    FORMAT A65  WORD_WRAPPED
-- Used for the SHOW SGA command
COLUMN name_col_plus_show_sga FORMAT a24
-- Defaults for SHOW PARAMETERS
COLUMN name_col_plus_show_param FORMAT a36 HEADING NAME
COLUMN value_col_plus_show_param FORMAT a30 HEADING VALUE
-- Defaults for SET AUTOTRACE EXPLAIN report
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
alter session set nls_date_format = 'DD-Mon-YYYY HH24:MI:SS';
col BLOCKED for a7
col STARTUP_TIME for a19
select instance_name INS_NAME,STATUS,DATABASE_STATUS DB_STATUS,LOGINS,BLOCKED,to_char(STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from v$instance;
