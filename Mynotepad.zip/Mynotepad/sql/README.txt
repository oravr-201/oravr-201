Command-line DBA Scripts for Oracle, mostly aimed at troubleshooting performance 

Author: Luca.Canali@cern.ch
Current version: June 2015
Description of the scripts at: http://externaltable.blogspot.com/2012/09/on-command-line-dba.html
