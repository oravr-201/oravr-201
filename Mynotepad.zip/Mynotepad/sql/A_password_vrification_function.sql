 CREATE OR REPLACE NONEDITIONABLE FUNCTION "SYS"."AORMAN12_VERIFY_FUNCTION"

(username varchar2,
  password varchar2,
  old_password varchar2)
  RETURN boolean IS
   n boolean;
   m integer;
   differ integer;
   isdigit boolean;
   ischar  boolean;
   ispunct boolean;
   digitarray varchar2(20);
   punctarray varchar2(25);
   chararray varchar2(52);

BEGIN
   digitarray:= '0123456789';
   chararray:= 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
   punctarray:='(!"#$%&()``*+,-/:;<=>?_)';

  -- 1. Check if password is same as or similar to username
   IF NLS_LOWER(password) = NLS_LOWER(username) THEN
     raise_application_error(-20001, 'Password same as o
r similar to user');
   END IF;

   -- Check if Minimum password length  is 8 characters :
   IF length(password) < 8 THEN
      raise_application_error(-20002, 'Password length less
than 8');
   END IF;

   -- Check if the password is too simple :
   IF NLS_LOWER(password) IN ('welcome', 'database', 'account',
'user', 'password', 'oracle', 'computer', 'abcd', 'A
ORMAN12','bank','xyz','janurary','febuary','march','
april','may','june','july','august','september','oct
ober','november','December','atos') THEN
      raise_application_error(-20002, 'Password Is too simple')
;
   END IF;

   -- 2. Check if the password contains at least one letter, one
 digit and one punctuation mark.

    -- 1. Check for the digit
   isdigit:=FALSE;
   m := length(password);
   FOR i IN 1..10 LOOP
      FOR j IN 1..m LOOP
         IF substr(password,j,1) = substr(digitarray,i,1) THEN
            isdigit:=TRUE;
             GOTO findchar;
         END IF;
      END LOOP;
   END LOOP;
   IF isdigit = FALSE THEN
      raise_application_error(-20003, 'Password should contain at le
ast one digit, one character and one punctuation');
   END IF;

   -- 2. Check for the character
   <<findchar>>
   ischar:=FALSE;
   FOR i IN 1..length(chararray) LOOP
      FOR j IN 1..m LOOP
         IF substr(password,j,1) = substr(chararray,i,1) THEN
            ischar:=TRUE;
             GOTO findpunct;
         END IF;
      END LOOP;
   END LOOP;
   IF ischar = FALSE THEN
      raise_application_error(-20003, 'Password should cont
ain at least one \ digit, one character and one punc
tuation');
   END IF;

      -- 3. Check for the punctuation
   <<findpunct>>
   ispunct:=FALSE;
   FOR i IN 1..length(punctarray) LOOP
      FOR j IN 1..m LOOP
         IF substr(password,j,1) = substr(punctarray,i,1) THEN
            ispunct:=TRUE;
             GOTO endsearch;
         END IF;
      END LOOP;
   END LOOP;
   IF ispunct = FALSE THEN
      raise_application_error(-20003, 'Password should contain
at least one \ digit, one character and one punctuat
ion');
   END IF;

   <<endsearch>>

   -- 3. Check if the password differs from the previous password b
y at least 3 letters

   IF old_password IS NOT NULL THEN
     differ := length(old_password) - length(password);

     IF abs(differ) < 3 THEN
       IF length(password) < length(old_password) THEN
         m := length(password);
       ELSE
         m := length(old_password);
       END IF;

       differ := abs(differ);
       FOR i IN 1..m LOOP
         IF substr(password,i,1) != substr(old_password,i,1) THEN

           differ := differ + 1;
         END IF;
       END LOOP;

       IF differ < 3 THEN
         raise_application_error(-20004, 'Password should dif
fer by at \
         least 3 characters');
       END IF;
     END IF;
   END IF;
   -- Everything is fine; return TRUE ;
   RETURN(TRUE);
END;
