SELECT * FROM ( select S.INST_ID,
   substr(s.username,1,18) username,
   substr(s.program,1,15) program,
   decode(s.command,
     0,'No Command',
     1,'Create Table',
     2,'Insert',
     3,'Select',
     6,'Update',
     7,'Delete',
     9,'Create Index',
     15,'Alter Table',
     21,'Create View',
     23,'Validate Index',
     35,'Alter Database',
     39,'Create Tablespace',
     41,'Drop Tablespace',
     40,'Alter Tablespace',
     53,'Drop User',
     62,'Analyze Table',
     63,'Analyze Index',
     s.command||': Other') command
from
   gv$session     s,
   gv$process     p,
   gv$transaction t,
   gv$rollstat    r,
   v$rollname    n
where s.paddr = p.addr
and s.taddr = t.addr (+)
and t.xidusn = r.usn (+)
and r.usn = n.usn (+)
order by 1)
WHERE USERNAME NOT IN ('DBSNMP','GGATE','SYS')
AND COMMAND <>'No Command';




















-----------------


  SELECT *
    FROM DBA_HIST_ACTIVE_SESS_HISTORY
   WHERE     session_type != 'BACKGROUND'
         AND sample_time BETWEEN TO_DATE ('7/10/2020 05:45:00',
                                          'mm/dd/yyyy hh24:mi:ss')
                             AND TO_DATE ('7/10/2020 06:45:00',
                                          'mm/dd/yyyy hh24:mi:ss')
         AND instance_number = '1'
ORDER BY sample_time DESC