-- define verialbes 
-- def SQLPATH='/home/oracle/sql' 
----def SQLPATH='/home/oracle/sql' 
----@&SQLPATH/init.sql
alias init=@&SQLPATH/init.sql
-- column
col db_name new_value db_name

--set 
set echo off 
SET SQLFORMAT ansiconsole


select name db_name from v$database;
set sqlprompt "@|blue _USER|@@@|green &db_name|@@|red >|@ "


alias w=select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from gv$instance I,gv$database D ;
alias w1=SELECT to_char(SYSDATE,'dd-mm-yyyy hh24:mi:ss') "DATE",SYS_CONTEXT('USERENV','SERVER_HOST') AS DB_HOSTNAME ,SYS_CONTEXT('USERENV','DB_NAME') AS INSTANCE,SYS_CONTEXT('USERENV','HOST') AS CLIENTHOST FROM DUAL;
alias ps =SELECT SID, SERIAL#    FROM GV$SESSION    WHERE AUDSID = Sys_Context('USERENV', 'SESSIONID')      AND INST_ID = USERENV('Instance'); 
alias redo=SELECT     a.group#   , a.member   , sum(b.bytes/1024/1024 ) "size_mb"   , null   , TO_NUMBER(null)   , TO_NUMBER(null) FROM     v$logfile a   , v$log b WHERE     a.group# = b.group# group by a.group#,member order by 1;
alias resource=SELECT    TO_NUMBER(a.value) max_sess_allowed  , TO_NUMBER(count(*)) num_sessions  , LPAD(ROUND((count(*)/a.value)*100,0) || '%', 19)  pct_utl FROM  v$session    b, v$parameter  a WHERE    a.name = 'sessions' GROUP BY     a.value;
alias scountuser=SELECT     lpad(nvl(sess.username, '[B.G. Process]'), 15) username   , count(*) num_user_sess   , nvl(act.count, 0)   count_a   , nvl(inact.count, 0) count_i FROM     v$session sess   , (SELECT    count(*) count, nvl(username, '[B.G. Process]') username      FROM      v$session      WHERE     status = 'ACTIVE'      GROUP BY  username)   act   , (SELECT    count(*) count, nvl(username, '[B.G. Process]') username      FROM      v$session      WHERE     status = 'INACTIVE'      GROUP BY  username) inact WHERE          nvl(sess.username, '[B.G. Process]') = act.username (+)      and nvl(sess.username, '[B.G. Process]') = inact.username (+) GROUP BY     sess.username   , act.count   , inact.count ;



-- files 
alias role=@&SQLPATH/role.sql ;
alias redohistory=@$SQLPATH/redohistory.sql;




----load data 

w
w1
ps


cle scr 

