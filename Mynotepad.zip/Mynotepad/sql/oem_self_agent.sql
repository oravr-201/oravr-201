https://docs.oracle.com/en/enterprise-manager/cloud-control/enterprise-manager-cloud-control/13.4/embsc/installing-oracle-management-agents.html#GUID-1B824483-9C55-47D9-9450-3929E5BA47F7


--Auto logout 

$emctl set property -name oracle.sysman.eml.maxInactiveTime -value -1 -sysman_pwd mptykow2020 
 
 Restart the OMS 