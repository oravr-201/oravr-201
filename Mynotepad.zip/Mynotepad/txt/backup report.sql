NAMBAckup	:					NAMBAckup report :NBU Admin <NBU_Admin@atos.net> -- FGA ,BRS,DRG


Philips		: 					TSM Events Report Level 1 on AOEDI for ALLEVENTS on 2017-01-30 09:04:01 (c=6,f=0,m=0,p=0,s=0,severed=0,r=0,u=0,i=0,unknown=0,rerun=0)
								TSM Events Report Level 1 on AOEDI for ALLEVENTS on 2017-02-10 09:04:00 (c=6,f=0,m=0,p=0,s=0,severed=0,r=0,u=0,i=0,unknown=0,rerun=0)


Stanley		:					Stanley WMS RMAN backup report as of 013017 202:02. 20:02

	
								TSM Events Report Level 1 on TSM3 for SWK on 2017-01-30 12:00:01 (c=12,f=0,m=1,p=0,s=0,severed=0,r=0,u=0,i=0,unknown=0,rerun=0) 23:30					



UNIFY report 					http://admingate.saacon.net/LandingPages/admingate.saacon.net.aspx
								use Old link 
								SACCON  ID/PAsswd
								Entry Point NA-USA
								- Managed AdminGAte
								
								AdminGate Unify - SEN_US
								 Entry point Germany
								-- Connectivity Tools 
								- remote desktop connection
								
								
stand by backup report :		STANDBY BACKUP REPORT FOR DRAEGER
								
								
Atos	usaodba1	aorman11	TSM backup report for aorman11	Rman Hot backup to Disk	Everyday at 10.30pm
Atos	usaodba1	aorman11	Rman hot backup to Tape	Everyday at 1pm
Atos	usaodba1	AORMAN12	Netbackup report	Rman hot	Everyday at 2pm

Atos_aorman_backup 

Database Backup for aorman11

DRG Oracle Backup Report
======================================================================================

Monsanto - Daily Backup report
Automated_Oracle_Alert@stpmls01.monsanto.com



Monsanto Backup Server	stlumaindbprd02
 
5029538
BACKUP Report
stlumaindbprd02
infradbp
/home/oracle/BackupReport
 
server and backup location of monsanto 

SELECT pr.username "O/S Id",
       ss.username "Oracle User Id",
       ss.status "status",
       ss.sid "Session Id",
       ss.serial# "Serial No",
       lpad(pr.spid,7) "Process Id",
       substr(sqa.sql_text,1,540) "Sql Text"
  FROM v$process pr, v$session ss, v$sqlarea sqa
 WHERE pr.addr=ss.paddr
   AND ss.username is not null
   AND ss.sql_address=sqa.address(+)
   AND ss.sql_hash_value=sqa.hash_value(+)
   AND ss.status='ACTIVE'
ORDER BY 1,2,7


set lines 300 pages 300 
col TIME_TAKEN_DISPLAY for a10
col start_time for a20
col status for a20
col input_type for a20
select SESSION_KEY, INPUT_TYPE, STATUS,
to_char(START_TIME,'dd-mm-yyyy:hh24:mi:ss') start_time,
to_char(END_TIME,'dd-mm-yyyy:hh24:mi:ss') end_time,
time_taken_display,OUTPUT_BYTES/1024/1024 "size in MB",
OUTPUT_DEVICE_TYPE
from V$RMAN_BACKUP_JOB_DETAILS
order by session_key;
								
						
				p2 		
			5011588 
			5011587 
			5011586 
								
								
								no
NYBC\spatil	Dhoom17$$

DX Database Backups Report 
RMANDB1 ORACLE EXPIRE DATE
DAILY OUP WINDOWS DB Backup
SEI BK-0kn01-OP17
PTP29 ORACLE EXPIRE DATE
Oracle INDUSTRY Database Backups Report 
PTD,STS Database Backups Report 
DAILY OP50 LINUX DB Backup
DAILY OP55 LINUX DB Backup
DAILY OP56 LINUX DB Backup

								
			

huntsman report 

[oracle@usarav102 Monthly_Report]$ pwd
/home/oracle/scripts/rman/logs/Monthly_Report

00 00 06 * * /home/oracle/scripts/rman/rman_report.sh

			
						




Location: /Upgrade_Backup/fullbkp_5Aug17_DR

RUN
{
ALLOCATE CHANNEL c1 DEVICE TYPE disk;
ALLOCATE CHANNEL c2 DEVICE TYPE disk;
ALLOCATE CHANNEL c3 DEVICE TYPE disk;
ALLOCATE CHANNEL c4 DEVICE TYPE disk;
sql 'ALTER SYSTEM ARCHIVE LOG CURRENT';
sql 'ALTER SYSTEM SWITCH LOGFILE';
sql 'ALTER SYSTEM SWITCH LOGFILE';
sql 'ALTER SYSTEM SWITCH LOGFILE';
CROSSCHECK ARCHIVELOG ALL;
backup AS COMPRESSED BACKUPSET full database tag STBY_FULL format '/Upgrade_Backup/fullbkp_5Aug17_DR/%d_%T_%s_%p_FULL';
backup as compressed backupset archivelog all format '/Upgrade_Backup/fullbkp_5Aug17_DR/%d_%s_%p_%c_%t.arc.rman';
backup current controlfile format '/Upgrade_Backup/fullbkp_5Aug17_DR/%d_%T_%s_%p_CONTROL';
release channel c1;
release channel c2;
release channel c3;
release channel c4;
}



						