set long 1000000
select dbms_metadata.get_granted_ddl('SYSTEM_GRANT','ORDDATA') from dual;

select dbms_metadata.get_granted_ddl('ROLE_GRANT','ORDDATA') from dual;


# crsctl start resource -all 
# /etc/init.d/ohasd start
















Bzapb4881j@Sushal


Hi,

I have an IT Professional with 4+ years of experience in Database System administration on Unix and Windows. 
Sound knowledge and Strong hands-on experience in Database system Administration  Oracle on heterogeneous 
like Unix – Linux , Solaris IBM AIX, and windows  also Strong hands-on experience oracle Goldengate and RAC.

Full Name                : VISHAL VILAS BHANDWALKAR
Contact No               : 9960902688
E-Mail id                : vishalvilas.b@gmail.com
Primary Skill            : ORACLE DBA 9i to 12c (RAC AND GOLDENGATE )
Certification            : OCP 11G ,ORACLE RAC CERTIFIED 11g
Overall Exp              : 4 years
Relevant Exp             : 4 years (ORACLE DBA )
Current Location         : PUNE
Preferred Location       : PUNE
Current Company          : ATOS (permanat)
Permanent / Contract     : PERMANENT
Notice Period            : 60 days
Highest Qualification (regular only): BCS ( computer science )
passport  				 : Z3744690



Hi,

I have an IT Professional with 4+ years of experience in Database System administration on Unix and Windows. 
Sound knowledge and Strong hands-on experience in Database system Administration  Oracle on heterogeneous 
like Unix – Linux , Solaris IBM AIX, and windows  also Strong hands-on experience oracle Goldengate and RAC.

Full Name                : VISHAL B
Contact No               : 9762158929
E-Mail id                : dba.wish@rediffmail.com
Primary Skill            : ORACLE DBA 9i to 12c (RAC AND GOLDENGATE )
Certification            : OCP 11G ,ORACLE RAC CERTIFIED 11g
Overall Exp              : 4 years
Relevant Exp             : 4 years (ORACLE DBA )
Current Location         : PUNE
Preferred Location       : PUNE
Current Company          : ATOS (permanat)
Permanent / Contract     : PERMANENT
Notice Period            : 60 days
Highest Qualification (regular only): BCS ( computer science )
passport  				 : Z3744690



Tejas Lone---->IT Recruiter
tejas@thinkpeople.in
Contact No: 9773801544 /022 - 41130433


DR00327328@techmahindra.com





























