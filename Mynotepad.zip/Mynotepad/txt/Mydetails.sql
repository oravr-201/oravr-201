AWS Account details :
Id 		: vishalvilas
Account no 	: 321036802274
password 	: Vishal0117@ 

VMware account 	:
Id 		: vishalvilas
pass		: Vishal 

oracle account 	:
Id 		: vishal.vastu@gmail.com	
Pass		: Vishal

fujitsu		:
id 
pass 		:Vishal$0117$0117@