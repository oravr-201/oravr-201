find . -type f -name "*.aud" -mtime +30 -print -exec rm {} \;
find . -type f -name "*.trc" -mtime +30 -print -exec rm {} \;
find . -type f -name "*.trm" -mtime +30 -print -exec rm {} \;

find . -type f -name "*.sh*"  -print -exec ls -altr {} \;


find . -type f -name "*alertCSMPRD.log"
find . -type f -mtime +3 -exec rm {} \

-- remove the files up till date like Mar 12 

ls -ltr | grep "Mar 12" | awk '{print $9}'  | xargs rm -f 

tail -100f file 	
grep -A4 'word' file 

AIX:
grep -n 'ORA-27063' alert_ecfp1.log | cut -d':' -f1 |  xargs  -n1 -I % awk 'NR<=%+4 && NR>=%-4' alert_ecfp1.log 

--large files :
 du -sh * | sort -hr | head -n10

ps -ef | grep -i pmon | tee post_output_pmon.txt
--check error :

	cat `lsnrctl stat LISTENER|grep Log|awk '{print $4}'`|grep "TNS-"
	cat `lsnrctl stat LISTENER|grep Log|awk '{print $4}'`|grep "TNS-"

kill sessions :
ps -ewf |grep rman|awk '{print $2}' | xargs kill -9  

database process :
ps -ewf |grep "LOCAL=NO"|awk '{print $2}' | xargs kill -9


CPU:

lscpu
prtconf
lparstat -i | grep -i online
telnet :
telnet database.example.com 1522
mails :

mail -s "test backup " -a /home/oracle/backup.xls -a /home/oracle/backup1.xls  vishal-vilas.bandwalkar@atos.net
mailx -s "test backup "   vishal-vilas.bandwalkar@atos.net
==================================================================================================










--Sar report :

https://www.linuxnix.com/linux-sar-command-report-historical-data-part-3/


















[root@stocell1 ~] vi partitions.sh

#!/bin/bash
for i in {1..20}
do
cat <<EOF | fdisk /dev/sdb
n
p
{$i}

+500M
w
EOF
done




stty columns 160






/*
set timeout 60
spawn ssh username@machine1.domain.com
spawn scp -p a519185@161.134.221.105:/oracle/admin/home/BackupReport/Backup_Final_18Apr2017.log /home/oracle/BackupReport/vb.log
expect "Password: "
send "Password\r"
send "\r" # This is successful. I am able to login successfully to the first machine
set timeout 60
spawn ssh username@machine2.domain.com  #This fails


  --- scp command help 
expect -c " 
# exp_internal 1 # uncomment for debugging 
spawn  scp -q qcp_xtns.dmp oracle@logarchive.ifxlv.com:/archive/bkups/dumps/transmoneris 
expect { 
                "*password:*" { send oracle@7534\r\n; interact } 
                eof { exit } 
        } 
exit 
" 
+919833431490

for i in serverhostname ;
	do
		ssh $i "command1;command2"; 
	done
	
	
for i in serverhostname1 serverhostname2;
	do 
		scp -p $i file1 file2 root@server2:/destination;
	done
	
for i in serverhostname1 serverhostname2; 
	do 
		scp -p $i file1 file2 root@server2:/destination;
	done
 
for i in `cat serverlist.txt`; 
	 do 
		scp -p $i file1 file2 root@server2:/destination ; 
	done
 
for i in serverhostname1 serverhostname2; do scp -p $i file1 file2 root@server2:/destination;done
 
for i in `cat serverlist.txt`;  do scp -p $i file1 file2 root@server2:/destination ; done
 
echo "linuxpassword" | passwd --stdin linuxuser
 

 
set timeout 60
spawn ssh username@machine1.domain.com
spawn scp -p a519185@161.134.221.105:/oracle/admin/home/BackupReport/Backup_Final_18Apr2017.log /home/oracle/BackupReport/vb.log
expect "Password: "
send "Password\r"
send "\r" # This is successful. I am able to login successfully to the first machine
set timeout 60
spawn ssh username@machine2.domain.com  #This fails

 
sshpass -p your_password scp oracle@west


for i in `cat serverlist.txt`; 
	 do 
		#scp -p $i file1 file2 root@server2:/destination ; 
		sshpass -p your_password scp oracle@$i:/destination
	done

varun.jain203@gmail.com

============================================================================================================================================

cat listener.log >> liwtener.log.14sep
cat /dev/null > listener.log
echo. > listener.log	---windows 

ps aux | sort +5 -6 -n -r | head -5
/sbin/fuser /u01/app/oracle/product/11.2.0/db_1/lib/libclntsh.so.11.1
http://oracletechdba.blogspot.in/2014/07/opatch-error-with-ibclntshso111.html


cat /dev/null > D:\app\oracle\diag\tnslsnr\bmnj62-t-oradb2\listener\trace\listener.log
*/