mkdir -p /u01/app/oracle/acfsmounts/data_acfsvol3
# chown oracle:oinstall /u01/app/oracle/acfsmounts/data_acfsvol3
As the "oracle" user, switch to the ASM environment on node 1 of the RAC, then connect to the ASM instance using SQL*Plus.

[oracle@rac1 ~]$ . oraenv
ORACLE_SID = [RAC1] ? +ASM1
The Oracle base for ORACLE_HOME=/u01/app/11.2.0/grid is /u01/app/oracle
[oracle@rac1 ~]$ dbhome
/u01/app/11.2.0/grid
[oracle@rac1 ~]$ sqlplus / as sysasm
Issue to the following command to create a new volume.

SQL> ALTER DISKGROUP DATA ADD VOLUME ACFSVOL3 SIZE 10G;

Diskgroup altered.

SQL>
Exit the SQL*Plus session, then create a file system on the volume.

[oracle@rac1 ~]$ /sbin/mkfs -t acfs -b 4k /dev/asm/acfsvol3-301 -n "ASMVOL3"
mkfs.acfs: version                   = 11.2.0.1.0.0
mkfs.acfs: on-disk version           = 39.0
mkfs.acfs: volume                    = /dev/asm/acfsvol3-301
mkfs.acfs: volume size               = 10737418240
mkfs.acfs: Format complete.
[oracle@rac1 ~]$ /sbin/acfsutil registry -f -a /dev/asm/acfsvol3-301 /u01/app/oracle/acfsmounts/data_acfsvol3
/bin/mount -t acfs /dev/asm/acfsvol3-301 /u01/app/oracle/acfsmounts/data_acfsvol3


You can unmount and mount all the ACFS locations using the following commands from the "root" user on each RAC node.

# /bin/umount -t acfs -a
# /sbin/mount.acfs -o all