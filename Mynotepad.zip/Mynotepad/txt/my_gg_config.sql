EAST 	:			EE 			EEW									
WEST 	:			PW			PEW			REW
SOUTH 	:			PS			PES			RES
NORTH	:			PN			PEN			REN

EAST 	:			PA 			PWE			RWE						
WEST 	:			EW			EWE			
SOUTH 	:			PB			PWS			RWS
NORTH	:			PC			PWN			RWN

info extract EEW,showch
info EEW,showch

stats RWE table UNI.TEST_C
ADD EXTRACT EWE, TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /u01/app/Goldengate/dirdat/EW , EXTRACT EWE, MEGABYTES 100

-- Pump Process for replicating data in DCE reporting database
ADD EXTRACT PWE, EXTTRAILSOURCE /u01/app/Goldengate/dirdat/EW
ADD RMTTRAIL /u01/app/Goldengate/dirdat/PA, EXTRACT PWE, MEGABYTES 100


ADD EXTRACT PWS, EXTTRAILSOURCE /u01/app/Goldengate/dirdat/EW
ADD RMTTRAIL /u01/app/Goldengate/dirdat/PB, EXTRACT PWS, MEGABYTES 100

ADD EXTRACT PWN, EXTTRAILSOURCE /u01/app/Goldengate/dirdat/EW
ADD RMTTRAIL /u01/app/Goldengate/dirdat/PC, EXTRACT PWN, MEGABYTES 100


-- create the process on different server where you want to replicate data
-- Replicat Process
ADD REPLICAT RWE, EXTTRAIL /u01/app/Goldengate/dirdat/PA
ADD REPLICAT RWS, EXTTRAIL /u01/app/Goldengate/dirdat/PB
ADD REPLICAT RWN, EXTTRAIL /u01/app/Goldengate/dirdat/PC


1. parameters 
2. lag ...











east : p
west : s
