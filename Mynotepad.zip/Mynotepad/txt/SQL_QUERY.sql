=======================================================================================================================================		
													SQL_ID			
=======================================================================================================================================		

SELECT P.SPID,S.USERNAME,S.PROGRAM,S.SID,S.SQL_ID FROM V$SESSION S,V$PROCESS P WHERE P.ADDR=S.PADDR AND S.SID=&38;

SELECT USERNAME,MACHINE,LOGON_TIME,SQL_ID FROM V$SESSION WHERE SID=&38;

SELECT USERNAME,MACHINE,LOGON_TIME,SQL_ID FROM V$SESSION WHERE SQL_ID='&AN75VV6C4KQMQ';

SELECT SID,SERIAL., A.SQL_ID, A.SQL_TEXT, S.USERNAME,I.HOST_NAME, MACHINE, S.EVENT, S.SECONDS_IN_WAIT SEC_WAIT,TO_CHAR(LOGON_TIME,'DD-MON-RR HH24:MI') LOGIN
FROM GV$SESSION S, GV$SQLAREA A,GV$INSTANCE I WHERE S.USERNAME IS NOT NULL AND S.SQL_ADDRESS=A.ADDRESS
AND S.INST_ID=A.INST_ID AND I.INST_ID = A.INST_ID AND SQL_TEXT NOT LIKE 'SELECT S.USERNAME,S.SECONDS_IN_WAIT%' AND A.SQL_ID='3VZK188FR0NY6'; 
  
SELECT S.SNAP_ID,H.STARTUP_TIME,PLAN_HASH_VALUE,EXECUTIONS_TOTAL,EXECUTIONS_DELTA,CPU_TIME_TOTAL*POWER(10,-6) "CPU_TIME_TOTAL"
FROM  DBA_HIST_SQLSTAT S,  DBA_HIST_SNAPSHOT H WHERE S.SNAP_ID IN (431, 432, 433) AND SQL_ID='GQ3V91DGCP8BC'AND S.SNAP_ID=H.SNAP_ID;


 SELECT SQL.SQL_TEXT SQL_TEXT, T.USED_UREC RECORDS, T.USED_UBLK BLOCKS,(T.USED_UBLK*8192/1024) KBYTES FROM V$TRANSACTION T, V$SESSION S,
 V$SQL SQL WHERE T.ADDR = S.TADDR AND S.SQL_ID = SQL.SQL_ID AND S.SID=334;



=======================================================================================================================================		
											RESTORE PROCESS % 
=======================================================================================================================================		

	SET ECHO ON TIMING ON
	SET LINES 32000
	COL USERNAME        FORMAT A10
	COL OPNAME          FORMAT A35
	COL SOFAR           FORMAT 999,999,999,999,999,999
	COL TOTALWORK       FORMAT 999,999,999,999
	COL 'WORK DONE %'   FORMAT 999.99
	COL START_TIME      FORMAT A20
	COL 'END_AT'		FORMAT A20
	SELECT SID,USERNAME,OPNAME,SOFAR,TOTALWORK,SOFAR/TOTALWORK*100 "WORK DONE %", TO_CHAR(START_TIME,'DD-MON-YY HH24:MI:SS') "START_TIME",
	TO_CHAR(SYSDATE + TIME_REMAINING/3600/24,'DD-MON-YY HH24:MI:SS') "END_AT" FROM  V$SESSION_LONGOPS WHERE SOFAR!=TOTALWORK 
	AND TOTALWORK!=0 AND OPNAME LIKE 'RMAN%'; 

=======================================================================================================================================		
											RMAN BACKUP JOB DETAILS  % 
=======================================================================================================================================		

set lines 200 pages 200	 	 	
col STATUS format a9	 	 	
col hrs format 999.99	 	 	
col start_time for a30	 	 	
col end_time for a30	 	 	
select	 	 	 	 	
SESSION_KEY,SESSION_RECID,SESSION_STAMP ,INPUT_TYPE, STATUS,	
to_char(START_TIME,'mm/dd/yy hh24:mi') start_time,	
to_char(END_TIME,'mm/dd/yy hh24:mi')   end_time,	
elapsed_seconds/3600                   hrs	
from V$RMAN_BACKUP_JOB_DETAILS	 	
order by 1;
 
 
DELETE  ARCHIVELOG ALL BACKED UP 1 TIMES TO DEVICE TYPE 'SBT_TAPE';


HTTP://WWW.CODECRETE.NET/UNWRAPIT/ 

--FIND ERRORS IN BACKUP USING ID AND STAMP 

SET LINES 200                                                                                                                     
SET PAGES 1000   
SELECT OUTPUT   
FROM GV$RMAN_OUTPUT  
WHERE SESSION_RECID =&3957                                                                            
AND SESSION_STAMP =&922493495
ORDER BY RECID;	


UNALISE
SET LINES 300 PAGES 300
COL TIME_TAKEN_DISPLAY FOR A10
COL START_TIME FOR A20
COL STATUS FOR A20
COL INPUT_TYPE FOR A20
COL INSTANCE_NAME FOR A5
COL HOST_NAME FOR A20
COL INPUT_TYPE FOR A10
SELECT I.INSTANCE_NAME,I.HOST_NAME,R.INPUT_TYPE,
TO_CHAR(R.START_TIME,'DD-MM-YYYY:HH24:MI:SS') START_TIME,
R.STATUS
FROM V\$INSTANCE I ,V\$RMAN_BACKUP_JOB_DETAILS R WHERE REGEXP_LIKE(INPUT_TYPE,'INCR|FULL','I') AND START_TIME > SYSDATE-1 ORDER BY START_TIME;


NOHUP $ORACLE_HOME/BIN/RMAN CMDFILE=/ORACLE/RDCPRDUS/DATA1/BACKUP_27_FEB_2018_FULL/FULL_BACKUP.RMAN LOG=/ORACLE/RDCPRDUS/DATA1/BACKUP_27_FEB_2018_FULL/FULL.LOG &


=======================================================================================================================================		
											CHECK SCHEMASIZE   % 
=======================================================================================================================================		

SET LINESIZE 150
SET PAGESIZE 5000
COL OWNER FOR A15
COL SEGMENT_NAME FOR A30
COL SEGMENT_TYPE FOR A20
COL TABLESPACE_NAME FOR A30
CLEAR BREAKS
CLEAR COMPUTES
COMPUTE SUM OF SIZE_IN_GB ON REPORT
BREAK ON REPORT
SELECT OWNER,SUM(BYTES)/1024/1024/1000 "SIZE_IN_GB" FROM DBA_SEGMENTS GROUP BY OWNER ORDER BY OWNER;

=======================================================================================================================================		
											DATABASE DETAILS   % 
=======================================================================================================================================		

SET LINES 123
COL NAME FOR A8
COL DB_UNIQUE_NAME FOR A20
COL CONTROLFILE_TYPE FOR A20
SELECT NAME,DB_UNIQUE_NAME,OPEN_MODE,CONTROLFILE_TYPE,DATABASE_ROLE FROM V$DATABASE;

SELECT * FROM SYSFILES;
=======================================================================================================================================		
											IMPORT  DETAILS   % 
=======================================================================================================================================		
SET PAGES 200 LINES 200
COL USERNAME FORMAT A10
COL OPNAME FORMAT A30
COL SOFAR FORMAT 9999999999
COL 'WORK DONE %' FORMAT 999.99
COL START_TIME FORMAT A20
SELECT SID,USERNAME,OPNAME,SOFAR,TOTALWORK,SOFAR/TOTALWORK*100 "WORK DONE %",TO_CHAR(START_TIME,'DD-MON-YY HH24:MI:SS') "START_TIME",
TO_CHAR(SYSDATE + TIME_REMAINING/3600/24,'DD-MON-YY HH24:MI:SS') "END_AT" FROM V$SESSION_LONGOPS WHERE SOFAR!=TOTALWORK AND TOTALWORK!=0;


SET ECHO ON TIMING ON
SET LINES 32000
COL USERNAME        FORMAT A10
COL OPNAME          FORMAT A35
COL SOFAR           FORMAT 999,999,999,999,999,999
COL TOTALWORK       FORMAT 999,999,999,999
COL 'WORK DONE %'   FORMAT 999.99
COL START_TIME      FORMAT A20
COL 'END_AT'		FORMAT A20
SELECT SID,USERNAME,OPNAME,SOFAR,TOTALWORK,SOFAR/TOTALWORK*100 "WORK DONE %", TO_CHAR(START_TIME,'DD-MON-YY HH24:MI:SS') "START_TIME",
TO_CHAR(SYSDATE + TIME_REMAINING/3600/24,'DD-MON-YY HH24:MI:SS') "END_AT" FROM  V$SESSION_LONGOPS WHERE SOFAR!=TOTALWORK 
AND TOTALWORK!=0 AND OPNAME LIKE 'SYS_EXPORT%'
=======================================================================================================================================		
											CHECK TABLES INDEX   % 
=======================================================================================================================================		

COL OWNER FOR A10
COL TABLE_OWNER FOR A10
COL INDEX_TYPE FOR A10
SELECT OWNER,INDEX_NAME,INDEX_TYPE,TABLE_OWNER,TABLE_NAME,TABLESPACE_NAME,LAST_ANALYZED
FROM DBA_INDEXES WHERE TABLE_NAME='SAP_SCHEDULE_LINE_HIST';


SELECT OWNER,TABLE_NAME,LAST_ANALYZED, GLOBAL_STATS FROM DBA_TABLES 
WHERE TABLE_NAME='SAP_SCHEDULE_LINE_HIST';

EXECUTE DBMS_STATS.GATHER_TABLE_STATS ('DWHIST', 'SAP_SCHEDULE_LINE_HIST');


--WHO LOCKS WHOMS (MASTER) 
SELECT ORACLE_USERNAME USERNAME, OWNER OBJECT_OWNER, OBJECT_NAME, OBJECT_TYPE, S.OSUSER, S.SID SID,
S.SERIAL. SERIAL,DECODE(L.BLOCK, 0, 'NOT BLOCKING', 1, 'BLOCKING', 2, 'GLOBAL') STATUS,
DECODE(V.LOCKED_MODE, 0, 'NONE', 1, 'NULL', 2, 'ROW-S (SS)', 3, 'ROW-X (SX)', 4, 'SHARE', 5, 'S/ROW-X (SSX)', 6, 'EXCLUSIVE', TO_CHAR(LMODE) ) MODE_HELD
FROM GV$LOCKED_OBJECT V, DBA_OBJECTS D, GV$LOCK L, GV$SESSION S
WHERE V.OBJECT_ID = D.OBJECT_ID
  AND (V.OBJECT_ID = L.ID1)
  AND V.SESSION_ID = S.SID
ORDER BY ORACLE_USERNAME, SESSION_ID;
 
--WHO LOCKS WHOMS (CHILD ) 		 
SELECT 
  ORACLE_USERNAME, OS_USER_NAME, LOCKED_MODE,
  OBJECT_NAME,OBJECT_TYPE
FROM V$LOCKED_OBJECT A,DBA_OBJECTS B
WHERE A.OBJECT_ID = B.OBJECT_ID 


----FAILED JOBS

SELECT JOB, WHAT FROM DBA_JOBS WHERE BROKEN = 'Y' OR FAILURES > 0;
SELECT LOG_DATE,STATUS,JOB_NAME FROM DBA_SCHEDULER_JOB_RUN_DETAILS WHERE STATUS='FAILED'
SELECT LOG_DATE,STATUS FROM DBA_SCHEDULER_JOB_RUN_DETAILS WHERE JOB_NAME=’BSLN_MAINTAIN_STATS_JOB’;


		 
============================================================================================
FIND DUPLICATE INDEX COLUMN AND REBUIELD 
============================================================================================


SELECT 'ALTER INDEX '||OWNER||'.'||INDEX_NAME||' REBUILD TABLESPACE '||TABLESPACE_NAME ||';'SQL_TO_REBUILD_INDEX FROM   DBA_INDEXES WHERE  STATUS = 'UNUSABLE';

SELECT 'ALTER INDEX '||INDEX_OWNER||'.'||INDEX_NAME ||' REBUILD PARTITION '||PARTITION_NAME||' TABLESPACE '||TABLESPACE_NAME ||';' SQL_TO_REBUILD_INDEX
FROM   DBA_IND_PARTITIONS WHERE  STATUS = 'UNUSABLE';



SELECT OWNER, INDEX_NAME, TABLESPACE_NAME FROM   DBA_INDEXES WHERE  STATUS = 'UNUSABLE';
SELECT INDEX_OWNER, INDEX_NAME, PARTITION_NAME, TABLESPACE_NAME FROM   DBA_IND_PARTITIONS WHERE  STATUS = 'UNUSABLE';

-----FIND DUPLICATE COLUMN(FULL)
CREATE TABLE PGDATA_PX.PX_TMP_SNL_PPU_WU_OPR_DUP AS 

SELECT * 
FROM PGDATA_PX.PX_TMP_SNL_PPU_WU_OPR OTER
WHERE EXISTS (SELECT 1 
	           FROM PGDATA_PX.PX_TMP_SNL_PPU_WU_OPR INER 
               WHERE UNIT_KEY = OTER.UNIT_KEY 
			     AND INER.MONTH_PERIOD = OTER.MONTH_PERIOD
				 AND INER.ROWID > OTER.ROWID);

-----FIND DUPLICATE COLUMN
SELECT MONTH_PERIOD, UNIT_KEY, COUNT(*)
FROM PGDATA_PX.PX_TMP_SNL_PPU_WU_OPR 
GROUP BY MONTH_PERIOD, UNIT_KEY
HAVING COUNT(*) > 1; 	
====================================================================================================================
								SESSION 
====================================================================================================================
								


SET FEEDBACK OFF LINESIZE 190 PAGES 1000
COL INST FOR 99
COL MODULE FOR A27
COL EVENT FOR A28
COL MACHINE FOR A27
COL "STATUS|WAIT_STATE|TIME_WAITED" FOR A30
COL "USERNAME | SID,SERIAL." FOR A35
SELECT S.INST_ID INST,S.USERNAME||' | '||S.SID||','||S.SERIAL. "USERNAME | SID,SERIAL.",
SUBSTR(S.MODULE,1,27)"MODULE",
SUBSTR(S.MACHINE,1,27)"MACHINE",
SUBSTR(S.STATUS||'|'||W.STATE||'|'||W.SECONDS_IN_WAIT||'SEC',1,30) "STATUS|WAIT_STATE|TIME_WAITED",
SUBSTR(W.EVENT,1,28)"EVENT",S.PREV_SQL_ID,S.SQL_ID CURR_SQL_ID
FROM GV$SESSION S, GV$SESSION_WAIT W
WHERE S.USERNAME IS NOT NULL
AND S.SID=W.SID
ORDER BY INST,USERNAME,MODULE;
SELECT COUNT(*) "COUNT ALL" FROM GV$SESSION WHERE USERNAME IS NOT NULL;
SELECT COUNT(*) "COUNT INACTIVE"FROM GV$SESSION WHERE USERNAME IS NOT NULL AND STATUS='INACTIVE';
SELECT COUNT(*) "COUNT ACTIVE"FROM GV$SESSION WHERE USERNAME IS NOT NULL AND STATUS='ACTIVE';

====================================================================================================================
								ARCHIVE LOG
====================================================================================================================

SELECT TO_DATE(FIRST_TIME) DAY,
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'00',1,0)),'99') "00",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'01',1,0)),'99') "01",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'02',1,0)),'99') "02",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'03',1,0)),'99') "03",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'04',1,0)),'99') "04",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'05',1,0)),'99') "05",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'06',1,0)),'99') "06",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'07',1,0)),'99') "07",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'08',1,0)),'99') "08",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'09',1,0)),'99') "09",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'10',1,0)),'99') "10",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'11',1,0)),'99') "11",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'12',1,0)),'99') "12",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'13',1,0)),'99') "13",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'14',1,0)),'99') "14",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'15',1,0)),'99') "15",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'16',1,0)),'99') "16",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'17',1,0)),'99') "17",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'18',1,0)),'99') "18",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'19',1,0)),'99') "19",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'20',1,0)),'99') "20",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'21',1,0)),'99') "21",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'22',1,0)),'99') "22",
TO_CHAR(SUM(DECODE(TO_CHAR(FIRST_TIME,'HH24'),'23',1,0)),'99') "23"
FROM
V$LOG_HISTORY
WHERE TO_DATE(FIRST_TIME) > SYSDATE -8
GROUP BY
TO_CHAR(FIRST_TIME,'YYYY-MON-DD'), TO_DATE(FIRST_TIME)
ORDER BY TO_DATE(FIRST_TIME)
/

---



SET PAGES 1000
SELECT TRUNC(COMPLETION_TIME,'DD') DAY, THREAD., ROUND(SUM(BLOCKS*BLOCK_SIZE)/1048576) MB,COUNT(*) ARCHIVES_GENERATED FROM V$ARCHIVED_LOG
GROUP BY TRUNC(COMPLETION_TIME,'DD'),THREAD. ORDER BY 1;





SET PAGES 1000
SELECT TRUNC(COMPLETION_TIME,'HH') HOUR,THREAD. , ROUND(SUM(BLOCKS*BLOCK_SIZE)/1048576) MB,COUNT(*) ARCHIVES FROM V$ARCHIVED_LOG
GROUP BY TRUNC(COMPLETION_TIME,'HH'),THREAD.  ORDER BY 1 ;



===============================================================================================
				 % MONITOR THE UGA, PGA AND CURSOR USAGE PER SESSION % 
===============================================================================================

SET PAGES500 LINES110 TRIMS ON
CLEAR COL
COL NAME FORMAT A30 
COL USERNAME FORMAT A20
BREAK ON USERNAME NODUP SKIP 1

SELECT VSES.USERNAME||':'||VSST.SID||','||VSES.SERIAL. USERNAME, VSTT.NAME, MAX(VSST.VALUE) VALUE 
FROM V$SESSTAT VSST, V$STATNAME VSTT, V$SESSION VSES
WHERE VSTT.STATISTIC. = VSST.STATISTIC. AND VSST.SID = VSES.SID AND VSTT.NAME IN 
('SESSION PGA MEMORY','SESSION PGA MEMORY MAX','SESSION UGA MEMORY','SESSION UGA MEMORY MAX', 
'SESSION CURSOR CACHE COUNT','SESSION CURSOR CACHE HITS','SESSION STORED PROCEDURE SPACE',
'OPENED CURSORS CURRENT','OPENED CURSORS CUMULATIVE') AND VSES.USERNAME IS NOT NULL
GROUP BY VSES.USERNAME, VSST.SID, VSES.SERIAL., VSTT.NAME ORDER BY VSES.USERNAME, VSST.SID, VSES.SERIAL., VSTT.NAME; 



---CURRENT  PROCESS AND SESSION (COUNT)
SELECT RESOURCE_NAME, CURRENT_UTILIZATION, MAX_UTILIZATION FROM V$RESOURCE_LIMIT WHERE RESOURCE_NAME IN ('PROCESSES','SESSIONS');








===============================================================================================
						ASM DISK
===============================================================================================


SET LINES 140 PAGES 1000

COL NAME FORMAT A20

COL PATH FORMAT A25

SELECT GROUP_NUMBER,DISK_NUMBER,NAME,MOUNT_STATUS,HEADER_STATUS,MODE_STATUS,STATE,TOTAL_MB,FREE_MB,PATH FROM V$ASM_DISK

ORDER BY GROUP_NUMBER,PATH ;

COL PATH FOR A40
SET LINES 150
SET PAGES 100
COL NAME FOR A20
COL ASM_GROUP FOR A10
SELECT ADG.NAME ASM_GROUP, AD.DISK_NUMBER, AD.NAME,AD.HEADER_STATUS, AD.MODE_STATUS,AD.REDUNDANCY, AD.PATH, AD.VOTING_FILE
FROM V$ASM_DISKGROUP ADG, V$ASM_DISK AD WHERE   ADG.GROUP_NUMBER = AD.GROUP_NUMBER ORDER BY AD.PATH; 

SELECT OPERATION, STATE,POWER, ACTUAL, SOFAR, EST_WORK, EST_MINUTES FROM V$ASM_OPERATION WHERE GROUP_NUMBER=1;

ALTER DISKGROUP AUDDATA DROP  DISK '<DISK_NAME>' ;

SELECT DISK_NUMBER, HEADER_STATUS, MODE_STATUS, PATH, VOTING_FILE 
FROM V$ASM_DISK  WHERE HEADER_STATUS ='FORMER' ORDER BY DISK_NUMBER;

ALTER DISKGROUP AUDARCH REBALANCE POWER 8;

=================================================================================================================================
									DATAPUMP
===================================================================================================================================

--FIND DATAPUMP JOBS :
SET LINES 150
COL OWNER_NAME FORMAT A10
COL JOB_NAME FORMAT A20
COL OPERATION FORMAT A10

SELECT OWNER_NAME, JOB_NAME, OPERATION
FROM DBA_DATAPUMP_JOBS WHERE STATE='NOT RUNNING' AND ATTACHED_SESSIONS=0;


--KILL DATAPUMP JOBS  BY SQL
SET HEAD OFF
SELECT 'DROP TABLE ' || OWNER_NAME || '.' || JOB_NAME || ';'
FROM DBA_DATAPUMP_JOBS WHERE STATE='NOT RUNNING' AND ATTACHED_SESSIONS=0;

---DIRECTORY 
SET LINESIZE    180
SET PAGESIZE    50000
COLUMN OWNER            FORMAT A10   HEADING 'OWNER'
COLUMN DIRECTORY_NAME   FORMAT A30   HEADING 'DIRECTORY NAME'
COLUMN DIRECTORY_PATH   FORMAT A85   HEADING 'DIRECTORY PATH'
SELECT OWNER,DIRECTORY_NAME,DIRECTORY_PATH FROM DBA_DIRECTORIES ORDER BY OWNER,DIRECTORY_NAME;									

---DBA SHEDULER JOB
SELECT OWNER, JOB_NAME FROM DBA_SCHEDULER_JOBS;
SELECT OWNER, PROGRAM_NAME, ENABLED FROM DBA_SCHEDULER_PROGRAMS;


==================================================================================================================
									HIGH MEMORY QUERY
===================================================================================================================

SELECT SPID,ADDR FROM V$PROCESS WHERE SPID IN ()
SELECT USERNAME,STATUS,SQL_ID,STATUS,SQL_ID FROM V$SESSION WHERE PADDR IN ()


================================================================================================================
								OBJECT DETAILS ;
================================================================================================================
SELECT SEGMENT_NAME,SEGMENT_TYPE,BYTES/1024/1024 MB FROM DBA_SEGMENTS WHERE SEGMENT_TYPE='TABLE' AND SEGMENT_NAME='&AR_SUMMARY';
SELECT OWNER,OBJECT_NAME,SUBOBJECT_NAME,OBJECT_ID,OBJECT_TYPE,CREATED,LAST_DDL_TIME,STATUS FROM DBA_OBJECTS WHERE OBJECT_NAME='AR_SUMMARY';

SELECT TABLESPACE_NAME, OWNER, SEGMENT_TYPE "OBJECT TYPE",
       COUNT(OWNER) "NUMBER OF OBJECTS",
       ROUND(SUM(BYTES) / 1024 / 1024, 2) "TOTAL SIZE IN MB"
FROM   SYS.DBA_SEGMENTS
WHERE  TABLESPACE_NAME IN ('MPIS')
GROUP BY TABLESPACE_NAME, OWNER, SEGMENT_TYPE
ORDER BY TABLESPACE_NAME, OWNER, SEGMENT_TYPE;

================================================================================================================
								TABLESPACE USES TIME ;
================================================================================================================

SELECT BEGIN_INTERVAL_TIME,END_INTERVAL_TIME,B.NAME, 
    ROUND((TABLESPACE_SIZE*8*1024)/1024/1024,2) SIZE_MB, 
    ROUND((TABLESPACE_MAXSIZE*8*1024)/1024/1024,2) MAXSIZE_MB, 
    ROUND((TABLESPACE_USEDSIZE*8*1024)/1024/1024,2) USEDSIZE_MB, 
    ROUND(((TABLESPACE_USEDSIZE*8*1024)/1024/1024)/((TABLESPACE_MAXSIZE*8*1024)/1024/1024)*100,2) "USED_PERCENTAGE" 
FROM DBA_HIST_TBSPC_SPACE_USAGE A 
    JOIN V$TABLESPACE B ON (A.TABLESPACE_ID = B.TS.) 
    JOIN DBA_HIST_SNAPSHOT C ON (A.SNAP_ID = C.SNAP_ID) 
WHERE NAME = 'USER_TEMP' -- TABLESPACENAME TO CHECK THE GRADUAL GROWTH OF PARTICULAR TABLESPACE 
    AND BEGIN_INTERVAL_TIME BETWEEN TO_DATE('09/19/2017 22:30:00','MM/DD/YYYY HH24:MI:SS') 
                                AND TO_DATE ('09/20/2017 03:00:00','MM/DD/YYYY HH24:MI:SS') 
ORDER BY 1 DESC; 

================================================================================================================
								FAILED JOB DETAILS ;
================================================================================================================

SELECT OWNER,JOB_NAME,STATUS,ERROR.,ACTUAL_START_DATE,RUN_DURATION,INSTANCE_ID FROM DBA_SCHEDULER_JOB_RUN_DETAILSDBA_SCHEDULER_JOB_RUN_DETAILS 
WHERE JOB_NAME LIKE 'CR_REPORTING_JOB' AND ACTUAL_START_DATE > ADD_MONTHS (SYSDATE,-1);

================================================================================================================
								RMAN ;
================================================================================================================
RUN
{
CONFIGURE CONTROLFILE AUTOBACKUP ON;
ALLOCATE CHANNEL C1 DEVICE TYPE DISK;
ALLOCATE CHANNEL C2 DEVICE TYPE DISK;
ALLOCATE CHANNEL C3 DEVICE TYPE DISK;
ALLOCATE CHANNEL C4 DEVICE TYPE DISK;
BACKUP AS COMPRESSED BACKUPSET FULL DATABASE TAG ORCL_FULL FORMAT '/ORACLE/PD3/BACKUP/BKP_NOV_14_2017/%D_%T_%S_%P_FULL' ;
SQL 'ALTER SYSTEM ARCHIVE LOG CURRENT';
BACKUP TAG ORCL_ARCHIVE FORMAT '/ORACLE/PD3/BACKUP/BKP_NOV_14_2017/%D_%T_%S_%P_ARCHIVE' ARCHIVELOG ALL;
BACKUP TAG ORCL_CONTROL CURRENT CONTROLFILE FORMAT '/ORACLE/PD3/BACKUP/BKP_NOV_14_2017/%D_%T_%S_%P_CONTROL';
RELEASE CHANNEL C1;
RELEASE CHANNEL C2;
RELEASE CHANNEL C3;
RELEASE CHANNEL C4;
}
NOHUP RMAN CHECKSYNTAX CMDFILE=/BACKUP/ORABACK/RESTOR/RMANRUNIISP_CDC.RCV MSGLOG /BACKUP/ORABACK/RESTOR/RMAN_RESTORE_IISP_CDC_CHECK.LOG &
NOHUP RMAN TARGET / CMDFILE=/BACKUP/ORABACK/RESTOR/RMANRUNIISP_CDC.RCV MSGLOG /BACKUP/ORABACK/RESTOR/RMAN_RESTORE_IISP_CDC.LOG &


================================================================================================================
DATABASE SIZE :
================================================================================================================
SELECT
"RESERVED_SPACE(MB)", "RESERVED_SPACE(MB)" - "FREE_SPACE(MB)" "USED_SPACE(MB)","FREE_SPACE(MB)","DATABASE SIZE(GB)"
FROM(
SELECT 
(SELECT SUM(BYTES/(1014*1024*1024)) FROM DBA_DATA_FILES) "RESERVED_SPACE(MB)",
(SELECT SUM(BYTES/(1024*1024*1024)) FROM DBA_FREE_SPACE) "FREE_SPACE(MB)",
(SELECT SUM(BYTES/(1024*1024*1024)) FROM DBA_SEGMENTS) "DATABASE SIZE(GB)"
FROM DUAL
);


SELECT TO_CHAR(CREATION_TIME, 'RRRR MONTH') "MONTH", 
ROUND(SUM(BYTES)/1024/1024/1024) "GROWTH IN GBYTES" 
FROM SYS.V_$DATAFILE 
WHERE CREATION_TIME < SYSDATE-8 
GROUP BY TO_CHAR(CREATION_TIME, 'RRRR MONTH');





---object details 


set heading on pages 1000
set lines 32000
col USERNAME for a25
col PASSWORD for a25
col account_status for a23
col PROFILE for a15
col DEFAULT_TABLESPACE for a20
col TEMPORARY_TABLESPACE for a20
PROMPT
SELECT A.USERNAME,B.PASSWORD,A.ACCOUNT_STATUS,A.PROFILE,A.DEFAULT_TABLESPACE,A.TEMPORARY_TABLESPACE FROM DBA_USERS A, USER$ B WHERE A.USER_ID=B.USER. AND USERNAME=UPPER('&&username');
PROMPT
PROMPT USER's OBJECT COUNT':
PROMPT --------------------

select  USERNAME,
        count(decode(o.TYPE., 2,o.OBJ.,'')) Tables,
        count(decode(o.TYPE., 1,o.OBJ.,'')) Indexes,
        count(decode(o.TYPE., 5,o.OBJ.,'')) Syns,
        count(decode(o.TYPE., 4,o.OBJ.,'')) Views,
        count(decode(o.TYPE., 6,o.OBJ.,'')) Seqs,
        count(decode(o.TYPE., 7,o.OBJ.,'')) Procs,
        count(decode(o.TYPE., 8,o.OBJ.,'')) Funcs,
        count(decode(o.TYPE., 9,o.OBJ.,'')) Pkgs,
        count(decode(o.TYPE.,12,o.OBJ.,'')) Trigs,
        count(decode(o.TYPE.,10,o.OBJ.,'')) Deps
from    obj$ o,
        dba_users u
where   u.USER_ID = o.OWNER. (+) and u.USERNAME in ('ACADMIN','ACSELECT','ASSETCENTER','CRONDBA','H68327','HAS0','INFA','INFA_AM9','UCMDB_AGENT')
group   by USERNAME
order   by USERNAME;


--Tsys user_audit
col username format a30
col PROFILE format a18
col ACCOUNT_STATUS format a23
col GRANTED_ROLE format a18
col CLIENTHOST for a40
col INSTANCE for a20
col DB_HOSTNAME for a40
set lines 400
set pages 400
select USERNAME,ACCOUNT_STATUS, PROFILE, DrP.GRANTED_ROLE,DRP.ADMIN_OPTION, AUTHENTICATION_TYPE, CREATED, EXPIRY_DATE, LOCK_DATE from dba_users du, DBA_ROLE_PRIVS drp
where DU.USERNAME=DrP.GRANTEE
and DRP.GRANTED_ROLE in ('DB_RELEASE_GROUP','OPERATOR','DBA','ORDADMIN','VIEWER','WKUSER','MGMT_USER','OWB_USER','OEM_MONITOR','RESOURCE')
order by 1 ;


--index rebuiled :


select a.*, round(index_leaf_estimate_if_rebuilt/current_leaf_blocks*100) percent, case when index_leaf_estimate_if_rebuilt/current_leaf_blocks < 0.5 then 'candidate for rebuild' end status
from
(
select table_name, index_name, current_leaf_blocks, round (100 / 90 * (ind_num_rows * (rowid_length + uniq_ind + 4) + sum((avg_col_len) * (tab_num_rows) ) ) / (8192 - 192) ) as index_leaf_estimate_if_rebuilt
from (
select tab.table_name, tab.num_rows tab_num_rows , decode(tab.partitioned,'YES',10,6) rowid_length , ind.index_name, ind.index_type, ind.num_rows ind_num_rows, ind.leaf_blocks as current_leaf_blocks,
decode(uniqueness,'UNIQUE',0,1) uniq_ind,ic.column_name as ind_column_name, tc.column_name , tc.avg_col_len
from dba_tables tab
join dba_indexes ind on ind.owner=tab.owner and ind.table_name=tab.table_name
join dba_ind_columns ic on ic.table_owner=tab.owner and ic.table_name=tab.table_name and ic.index_owner=tab.owner and ic.index_name=ind.index_name
join dba_tab_columns tc on tc.owner=tab.owner and tc.table_name=tab.table_name and tc.column_name=ic.column_name
where tab.owner='&OWNER' and ind.leaf_blocks is not null and ind.leaf_blocks > 1000
) group by table_name, index_name, current_leaf_blocks, ind_num_rows, uniq_ind, rowid_length
) a where index_leaf_estimate_if_rebuilt/current_leaf_blocks < 0.5
order by index_leaf_estimate_if_rebuilt/current_leaf_blocks;




HTTP://ORACLETECHDBA.BLOGSPOT.IN/2014/07/OPATCH-ERROR-WITH-IBCLNTSHSO111.HTML