DECLARE

            V_SCHEMA VARCHAR2(50):='%EMPINFO%';

            V_PASS VARCHAR2(50);

            V_PROFILE VARCHAR2(30);

            V_OLD_EXP_DT DATE;

            V_NEW_EXP_DT DATE;

            V_CNT NUMBER;

            V_GLOBAL_NAME VARCHAR2(30);

            BEGIN

            SELECT COUNT(*) INTO V_CNT FROM DBA_USERS WHERE USERNAME=UPPER(V_SCHEMA);

            SELECT GLOBAL_NAME INTO V_GLOBAL_NAME FROM GLOBAL_NAME; 

            IF V_CNT = 0 THEN

            DBMS_OUTPUT.PUT_LINE('THE USER '||V_SCHEMA||' DOES NOT EXIST IN DB,PLEASE TRY AGAIN ');

            ELSE

            SELECT EXPIRY_DATE INTO V_OLD_EXP_DT FROM DBA_USERS WHERE USERNAME=UPPER(V_SCHEMA);

            SELECT PASSWORD INTO V_PASS FROM SYS.USER$ WHERE NAME=V_SCHEMA;

            SELECT PROFILE INTO V_PROFILE FROM DBA_USERS WHERE USERNAME=V_SCHEMA;

            EXECUTE IMMEDIATE('alter user '||V_SCHEMA||' account unlock');

            EXECUTE IMMEDIATE('alter user '||V_SCHEMA||' profile default');

            EXECUTE IMMEDIATE('alter user '||V_SCHEMA||' identified by values '||''''||V_PASS||''''||'');

            EXECUTE IMMEDIATE('alter user '||V_SCHEMA||' profile '||V_PROFILE);

            SELECT EXPIRY_DATE INTO V_NEW_EXP_DT FROM DBA_USERS WHERE USERNAME=UPPER(V_SCHEMA);

            DBMS_OUTPUT.PUT_LINE(' USER NAME :'||V_SCHEMA);

            DBMS_OUTPUT.PUT_LINE(' OLD EXPIRY DATE : '||V_OLD_EXP_DT);

            DBMS_OUTPUT.PUT_LINE(' NEW EXPIRY DATE : '||V_NEW_EXP_DT);

            DBMS_OUTPUT.PUT_LINE('DB NAME : '||SUBSTR(V_GLOBAL_NAME,1,INSTR(V_GLOBAL_NAME,'.',1,1)-1));

            END IF;

            END;

            / 

