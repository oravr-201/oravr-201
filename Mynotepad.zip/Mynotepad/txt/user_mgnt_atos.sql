---------------------------------------------------------
check roles tables 
----------------------------------------------------------
select * from dba_role_privs where grantee = 'SCHEMA_NAME';
-------------------------------------------------------
Details of user :
--------------------------------------------------------

select username, account_status, default_tablespace,temporary_tablespace, profile from dba_users where username ='&GJAIN';

select * from dba_sys_privs where grantee ='&EFIGUERO';

select * from dba_sys_privs where grantee ='&rolename';

select grantee, owner, table_name, grantor, privilege from dba_tab_privs ‎where grantee ='&username';

select grantee, owner, table_name, grantor, privilege from dba_tab_privs where grantee ='&rolename';

select * from dba_roles where role ='&rolename';

select * from dba_role_privs where grantee ='&rolename';

select * from role_sys_privs where role ='&rolename';

select * from dba_profiles where profile ='&profile';

-------------------------------------------------------
user Quota :
-------------------------------------------------------

select * from dba_ts_quotas where username ='&username';

alter user shaan quota 40m on RTBS;‎

GRANTING AND REVOKING PRIVILEGES:

GRANT create table to SHAAN;‎
GRANT create session to SHAAN;
GRANT create any table, create tablespace to SHAAN;

REVOKE create any table from SHAAN;
REVOKE create tablespace from SHAAN;
GRANT select, insert, update, delete on HRSM.PAY_PAYMENT_MASTER to HRMS;

REVOKE update,delete on HRMS.PAY_PAYMENT_MASTER from HRMS;

-------------------------------------------------------
ROLE :
-------------------------------------------------------
create role MY_ROLE;

GRANT create any table, alter any table, drop any table, select any table, update any table, delete any table to MY_ROLE;

GRANT create any index, alter any index, drop any index to MY_ROLE
GRANT alter session, restricted session to MY_ROLE;

GRANT create tablespace, alter tablespace, drop tablespace, unlimited tablespace to MY_ROLE;
GRANT select, insert, update, delete on HRMS.PAY_PAYMENT_MASTER to MY_ROLE;

GRANT MY_ROLE to '&username';

-------------------------------------------------------

set long 1000 
select dbms_metadata.get_ddl('USER','EFIGUERO') from dual; 

set heading off;
set echo off;
Set pages 999;
set lines 32000;
set long 9999999;

spool ddl_list.sql
select dbms_metadata.get_ddl('TABLE','J_2IEXTRCT','SAPSR3') from dual; 
select dbms_metadata.get_ddl('INDEX','J_2IEXTRCT~0','SAPSR3') from dual;
select dbms_metadata.get_ddl('INDEX','WDY_UI_PROPERTY~0','SAPSR3') from dual;
spool off;



select 'grant ' || privilege || ' to ' || grantee ||'; ' from dba_sys_privs where grantee='EFIGUERO' order by grantee; 
select 'grant ' || granted_role || ' to ' || grantee ||'; ' from dba_role_privs where grantee='EFIGUERO' order by grantee; 
select 'Grant ' || PRIVILEGE || ' on ' || GRANTOR || '.' || TABLE_NAME || ' to ' || grantee || ';' from dba_TAB_PRIVS where GRANTEE in ('EFIGUERO'); 

select ROLE from dba_roles where role like '%tool%';

select username,account_status,profile,expiry_date from dba_users where username like '%FHOWARD%'; 

SELECT name,ctime,ptime FROM sys.user$ WHERE  name = 'MPL_USER';


===================================================================================================================
								USER MIRROR 
===================================================================================================================
select 'grant '||PRIVILEGE||' ON '||OWNER||'.'||TABLE_NAME||' to GJAIN;' FROM DBA_TAB_PRIVS WHERE GRANTEE='EFIGUERO';
select 'grant '||PRIVILEGE||' to GJAIN;' from dba_sys_privs where GRANTEE='EFIGUERO';
select 'grant '||GRANTED_ROLE||' TO GJAIN;' from dba_role_privs where grantee='EFIGUERO';






set pagesize 500
set linesize 200
set trimspool on
column "EXPIRE DATE" format a15
select username as "USER NAME", expiry_date as "EXPIRE DATE", account_status from dba_users where expiry_date < sysdate+120
and account_status IN ( 'OPEN', 'EXPIRED(GRACE)' ) order by account_status, expiry_date, username;






--user mirror 
set sqlprompt "_date':'_user'@'_connect_identifier> "
ACCEPT username   char  PROMPT 'Enter username  for the :'
set pages 0
set echo off heading off feedback off
SELECT 'CREATE USER ' || u.username ||' IDENTIFIED ' ||' BY VALUES ''' || c.password || ''' DEFAULT TABLESPACE ' || u.default_tablespace ||' TEMPORARY TABLESPACE ' || u.temporary_tablespace ||' PROFILE ' || u.profile || case when account_status= 'OPEN' then ';' else ' Account LOCK;' end "--Creation Statement"
FROM dba_users u,user$ c where u.username=c.name and u.username=upper('&&username')
UNION
select 'GRANT '||GRANTED_ROLE||' TO '||GRANTEE|| case when ADMIN_OPTION='YES' then ' WITH ADMIN OPTION;' else ';' end "Granted Roles"
from dba_role_privs where grantee= upper('&&username')
UNION
select 'GRANT '||PRIVILEGE||' TO '||GRANTEE|| case when ADMIN_OPTION='YES' then ' WITH ADMIN OPTION;' else ';' end "Granted System Privileges"
from dba_sys_privs where grantee= upper('&&username')
UNION
select 'GRANT '||PRIVILEGE||' ON '||OWNER||'.'||TABLE_NAME||' TO '||GRANTEE||case when GRANTABLE='YES' then ' WITH GRANT OPTION;' else ';' end "Granted Object Privileges"
from DBA_TAB_PRIVS where GRANTEE=upper('&&username');

set heading on pages 1000
set lines 32000
col USERNAME for a25
col PASSWORD for a25
col account_status for a23
col PROFILE for a15
col DEFAULT_TABLESPACE for a20
col TEMPORARY_TABLESPACE for a20
PROMPT
SELECT A.USERNAME,B.PASSWORD,A.ACCOUNT_STATUS,A.PROFILE,A.DEFAULT_TABLESPACE,A.TEMPORARY_TABLESPACE FROM DBA_USERS A, USER$ B WHERE A.USER_ID=B.USER# AND USERNAME=UPPER('&&username');
PROMPT
PROMPT USER's OBJECT COUNT:
PROMPT --------------------

select  USERNAME,
        count(decode(o.TYPE#, 2,o.OBJ#,'')) Tables,
        count(decode(o.TYPE#, 1,o.OBJ#,'')) Indexes,
        count(decode(o.TYPE#, 5,o.OBJ#,'')) Syns,
        count(decode(o.TYPE#, 4,o.OBJ#,'')) Views,
        count(decode(o.TYPE#, 6,o.OBJ#,'')) Seqs,
        count(decode(o.TYPE#, 7,o.OBJ#,'')) Procs,
        count(decode(o.TYPE#, 8,o.OBJ#,'')) Funcs,
        count(decode(o.TYPE#, 9,o.OBJ#,'')) Pkgs,
        count(decode(o.TYPE#,12,o.OBJ#,'')) Trigs,
        count(decode(o.TYPE#,10,o.OBJ#,'')) Deps
from    obj$ o,
        dba_users u
where   u.USER_ID = o.OWNER# (+) and u.USERNAME=upper('&&username')
group   by USERNAME
order   by USERNAME;
set heading off
PROMPT
select 'SCHEMA SIZE: '||ceil(sum(bytes)/1024/1024)||' MB' from dba_segments where owner=UPPER('&&username') group by owner;
PROMPT ------------

PROMPT
select     'Number of Invalid Objects: '||count(*) from dba_objects where STATUS = 'INVALID' and owner=upper('&&username');
PROMPT   --------------------------

PROMPT
select 'Number of Connected Sessions: ' || count(*) from gv$session where username=upper('&&username');
PROMPT  -----------------------------




============================================================================================================

set long 60000000
set pagesize 100000
SELECT dbms_metadata.get_ddl ('TABLE','V_VWORKFLOW','VENDAVO') from dual; 


impdp /as sysdba directory tables=VENDAVO.V_VWORKFLOW sqlfile=V_VWORKFLOW.sql

select distinct tablespace_name,owner from dba_segments where owner='CIP_STAGE' 

'''

=================================
List of users Roles :
=================================
col username  format a15
col "default ts"   format a15
col "temporary ts" format a15
col roles format a25
col profile format a10

break on username on created on "default TS" on "Temporary TS" on profile

select username,created,
       default_tablespace "Default TS",
       temporary_tablespace "Temporary TS",
       profile,
       Granted_role "roles"
from sys.dba_users,sys.dba_role_privs
where username = grantee(+)
order by username;



--RESET PASSWORD :

col USERNAME for a10 
col ACCOUNT_STATUS for a8
col PROFILE for a20
set lines 3200 pages 2000
SELECT username, account_status, lock_date, expiry_date, su.PASSWORD, PROFILE,
  ' ALTER USER '||USERNAME|| ' PROFILE DEFAULT; '||CHR(10)||CHR(10)||
  ' ALTER USER '||USERNAME|| ' IDENTIFIED BY VALUES '''||SU.PASSWORD||''';' ||CHR(10)||CHR(10)||
  ' ALTER USER '||USERNAME|| ' PROFILE '||PROFILE||'; '|| CHR(10)||CHR(10)||
  ' ALTER USER '||USERNAME|| ' ACCOUNT UNLOCK;' RESET_CMD
FROM dba_users du, sys.user$ su
WHERE du.username = su.NAME
  AND du.username = 'VISHALBH'
ORDER BY username ASC;





----OLD PASSWORD TO NEWPASSWORD 
SELECT NAME, PASSWORD,
CASE 
   WHEN name='TRANSIT_SMSNOX_SNOX_3124' THEN 'ALTER USER TRANSIT_SMSNOX_SNOX_3125 IDENTIFIED BY VALUES '''||password||''';'
   WHEN name='TRANSIT_SMSNOX_TNOX_3124' THEN 'ALTER USER TRANSIT_SMSNOX_TNOX_3125 IDENTIFIED BY VALUES '''||password||''';'
   WHEN name='TRANSIT_FE_SNOX_3124' THEN 'ALTER USER TRANSIT_FE_SNOX_3125 IDENTIFIED BY VALUES '''||password||''';'
   WHEN name='TRANSIT_FE_TNOX_3124' THEN 'ALTER USER TRANSIT_FE_TNOX_3125 IDENTIFIED BY VALUES '''||password||''';'
   WHEN name='TRANSIT_GATEWAY_SNOX_3124' THEN 'ALTER USER TRANSIT_GATEWAY_SNOX_3125 IDENTIFIED BY VALUES '''||password||''';'
   WHEN name='TRANSIT_GATEWAY_TNOX_3124' THEN 'ALTER USER TRANSIT_GATEWAY_TNOX_3125 IDENTIFIED BY VALUES '''||password||''';'
END A
  FROM sys.user$
 WHERE name IN ('TRANSIT_SMSNOX_SNOX_3124',
                'TRANSIT_SMSNOX_TNOX_3124',
                'TRANSIT_FE_SNOX_3124',
                'TRANSIT_FE_TNOX_3124',
                'TRANSIT_GATEWAY_SNOX_3124',
                'TRANSIT_GATEWAY_TNOX_3124'); 
				
				
				



 select owner,object_type,count(1) from dba_objects where owner='VENDAVO' group by owner,object_type;

 
 
 
 --grants scripts 
 
 
 
 spool grant_all.sql
set pages 0
set lines 32000
set echo off heading off feedback off

select 'grant ' || privilege || ' to ' || grantee ||'; ' from dba_sys_privs where GRANTEE in ()
union 
select 'grant ' || granted_role || ' to ' || grantee ||'; ' from dba_role_privs where GRANTEE in ()
union
select 'Grant ' || PRIVILEGE || ' on ' || GRANTOR || '.' || TABLE_NAME || ' to ' || grantee || ';' from dba_TAB_PRIVS where GRANTEE in ();


spool off
