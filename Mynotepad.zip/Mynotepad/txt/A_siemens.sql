passage.cna.com 
snow   		----> https://atosglobal.service-now.com/				 ATOSA652766						dec$Action20180117
Nam JH 		----> 161.89.145.220									 a652766							Welcome#2018
Nam JH 		----> 161.89.145.212									 a652766							Welcome1234%
NYBV 		----> 155.45.72.115/116									 NYBC\vbhandwa						apr$Action2018
HUNTSMAN 	----> 10.200.85.43										 SPECIALTIES\h127379				May$2018
VANATOR 	----> 10.199.52.11 										 DOM01\h127379						march$Action2018
saacon 		----> http://admingate.saacon.net 						 saacon\A652766						may$Action20180117
Ww900 		----> https://emea-de-082.asn.saacon.net  				 ww900\w9a97sr0						may$Action20180117
AD001		----> https://emea-de-033.asn.saacon.net/vpn/index.html	 ad001\w99atng0						may$Action20180117
AD005		---->													 ad005\w99atnf0						P9FuKsZZWKynyX1
AD009		---->													 ad009\w99atne0						r37C8FYVTK9SggF
Ashland		---->													 CORPASH\c805654					Welcome123			
Valvoline	---->													 CORPVAL\c805654					Welcome123
zerox 		---->													 q5PV67WG							apr$Action2018
zerox 		---->													 C5074809							f60u6qKXZ0
Monsanto	----> https://mondesk.monsanto.com/						 vvbhan								Mon$1234
DIAG 		----> 													 DIAG-LOCAL\A591590					Qhdv-1234567890
GUI Siemens ----> 129.73.128.195									 --USE ww900			
UNIFY       ---->														 a_alad								Dragon11$  
Finolex		----> 10.87.192.7										 finolexind\alad					Matunga123$
MOS 		----> Huntsman,venator,nybc,siemens 					 hemant.pethe@atos.net				Lara$123
MOS			----> Huntsman,venator,nybc,siemens						 amey.lad@atos.net					Zapak123$	
MOS			----> NAM												 DFW-Midrange-DBA@atosorigin.com 	Qazws@123
MOS 		----> monsnato
CSM 		----> 10.200.225.62										CORP\ext_BolisetV					May@2018

username: Philips_DCO 
Password = Philip$DC012
https://access.redhat.com/downloads/ 
STORMENT, LARRY D
==================================================================================================================
										( Links )
==================================================================================================================
SDM 	   ----->  https://sdm.atos-services.net/CAisd/pdmweb3.exe
siemens old----->  https://emea-de-082.asn.saacon.net/vpn/index.html
mondesk    ----->  https://mondesk.monsanto.com/vpn/index-mondesk.html
unify 	   ----->  https://admingate-emea.saacon.net/Citrix/XenApp/site/default.aspx
ash		   ----->  https://na-tx.asn.saacon.net
P saacon   ----->  https://emea-de.asn.saacon.net
policy 	   ----->  https://portal.myvantageconnect.co.in/#/Home			====> ATOS24497/oct$Action2018
snow	   ----->  https://atosglobal.service-now.com/sp/?id=sso&portal-id=service_now
sharepoint ----->  https://sp2013.myatos.net/ms/NAM/ds/_layouts/15/viewlsts.aspx?BaseType=0
cmdb	   ----->  http://155.45.60.170/DDMRemediateCDP/InfoExQuery.aspx
ser request----->  http://servicerequest.it-solutions.myatos.net/RequestCenter/myservices/myservice.do?resetBN=true&tabId=5257
pf 		   ----->  https://unifiedportal-mem.epfindia.gov.in/memberinterface/
pf2        ----->  http://www.epfindia.gov.in/site_en/For_Employees.php?id=sm2_index
N cerner   ----->  https://admingate-emea.saacon.net/Citrix/XenApp/site/default.aspx   ====> http://10.80.94.135/Siemens/Citrix/auth/silentDetection.aspx
ad001      ----->  https://emea-de-033.asn.saacon.net/Citrix/SiemensAD001V3/site/default.aspx
										 
==================================================================================================================
										( siemens )
==================================================================================================================

UNIX 	-->   INGOUnixTeamSorensen.it-solutions@atos.net,IN_AHS_UNIX-L3.it-solutions@atos.net
				--surendranath.darla@atos.net,varjang.zala@atos.net,
WINTEL 	-->	  IT-Solutions US GO Wintel Team Cremin
				--Devadiga, Jayaprakash; Thorat, Kiran							
Backup	-->   ron.forrester@atos.net,richard_green@atos.net				
Dyamon	-->	  michael.simmons@atos.net,don.peters@atos.net			
\\155.45.163.189\dsl_emea$	--------for software 	
\\155.45.163.189\ts_emea$ 	--------for copy		
Oracle/Sie18_orac18e_db18	

USLZUA200J7SRV     			161.218.81.11 			a652766			Zapak123$
USLZUA200JWSRV     			161.218.81.31			a652766         june$Action2017		--
USLZUA200KMSRV     			161.134.187.40			a652766         Zapak123$			--
USLZUA4003QSRV     			161.218.81.188			a652766         may$Action2018		
USLZUA4002USRV     			137.223.149.140			a652766         Zapak123$			--
USDFSTPTP2/USIRVA30023SRV	10.80.94.67       	 	a652766         may$Action2018
USDXSLDPLMDB1				10.80.96.39        		a652766         may$Action2018
USDXSLPPLMDB1				165.226.210.49      	a652766         Atos@123			--ip
USDXSLPRMAN1				172.17.156.55       	a652766         ljkjjkji$&ju(9		--ip
USDXSLPRMAN2				10.80.97.80         	a652766         may$Action2018
USMLVA30020SRV				10.80.96.111        	a652766         Sie6_orac6e_db6
USMLVA3003QSRV				10.80.96.18         	a652766         may$Action2018
USMLVA3004MSRV				10.80.100.58        	a652766         may$Action2018
USMLVA4A09SRV				136.157.166.26      	a652766         Zapak123$			--
USLZUA4A0KN01				161.134.154.199     	a652766         june$Action2017		--
USLZUA4A0KN02				161.134.154.201     	a652766         ljkjjkji$&ju(9		--
USLZUA4A0KSRV (OP17)		161.218.81.228	      	a652766         may$Action2018 		
USLZUA4A0MSRV				161.134.154.196     	a652766         ljkjjkji$&ju(9		--ip
USMLVA0001USRV				161.134.221.105     	a652766         june$Action2017		--ip
USMLVA0001YSRV				161.134.221.103     	a652766         june$Action2017		--ip
USLZUA4009BSRV (OT17)		137.223.149.235     	a652766         may$Action2018
USMLVA3003TSRV				161.134.222.209     	a652766         ljkjjkji$&ju(9		--ip
USMLVA3003USRV				161.134.222.210     	a652766         ljkjjkji$&ju(9		--ip
USIRV99003VSRV				10.80.100.104       	a652766         ljkjjkji$&ju(9		--ip
USLZUC40010SRV				136.157.188.109     	a652766         may$Action2018
USLZUA000MXSRV				155.45.145.131      	a652766         ljkjjkji$&ju(9		--ip
USMLVA3006JSRV				10.80.100.59        	a652766         may$Action2018
USIRVA30020SRV				136.157.166.6       	a652766         Qwerty@XYZ@$$2016
USIRVA30021SRV				136.157.166.8       	a652766         may$Action2018
usmlvv1psf645				10.80.104.6         	a652766         ljkjjkji$&ju(9		--ip
moe1a6						10.74.75.61         	a652766         Zapak123$ 			a548609/Qwerty@XYZ@$$2016
MOE1A5						10.74.75.60         	a652766         sep$Action2018 Zapak123$			a548609/Qwerty@XYZ@$$2016	
oradev02 -	        	    10.80.100.56		 	a652766			dec$Action2018
MLVVUL3U - 					10.80.100.103		 	a652766			may$Action2018					
MLVVUL5U        			10.80.100.102  							Atos123@20!6Atos   	a519185/Zapak1234$    
usdxslporcdb1 				165.226.210.213					 		sdksjcvnl$$11567KLDKD
usdxslprman1  				172.17.192.19		 	a435715			m{K)70C3w]Yy$qa
usdxslprman2  				165.226.210.43		 	a435715			abcd1234
sn1D3704.dc.siemens.net		sn1D3704.dc.siemens.net	a652766			june$Action2018
sn1d3704.dc.siemens.net 	136.157.216.125			a652766			june$Action2018
sn1d9001.dc.siemens.net     136.157.216.131			a652766			june$Action2018
usrch00001fsrv				161.134.200.77 			a652766			june$Action2018
USIRVA300BKSRV/USDXSLPRMAN1 136.157.216.100 		a652766			aug$Action2018
USIRVA300BMSRV/USDXSLPRMAN2 136.157.216.101			a652766			aug$Action2018
USMLVA30042SRV.corp-am.corp.dom						a_lathiyan		July@2018
ustxca3002vsrv.dc.siemens.net	10.80.98.14			a652766			abcd1234
sn1d3305.dc.siemens.net			136.157.216.62		a652766			aug$Action2018

==================================================================================================================
										( FGA )
==================================================================================================================
GEMS 		-->		DLT04437@atos.net						
Backup		-->		gmin-india-backupsupport@atos.net							
FGA Linux	-->		IN_AHS_UNIX-L3.it-solutions@atos.net							
UNIX		-->		IN_ICS_UNIX_NA_Support.it-solutions@atos.net							
WINTEL		-->		INAHSWintelNONGAINL2support.it-solutions@atos.net,INICSWintelNONGAINL3support.it-solutions@atos.net						
BACKUP 		-->		gmin-india-backupsupport_nongain-backup@atos.net							

fgsdcdcacdb01				10.158.17.105		a652766			Atos@123	 	
fgpdcpcacdb01				10.200.57.105		a652766			Atos@123		
fgpdcdjskap44				10.200.57.95		a652766			Atos@123																										
fgpdcpjskap44				10.200.57.90		a652766			Atos@123		
fgpdcpjskap46				10.200.57.93															
fgpdcpfocdb01				10.200.44.38		a652766			Atos@123		
fgsdcqfocdb01				10.200.48.29		a652766			Atos@123	
fgsdcrfocdb01				10.200.48.28		a652766			Atos@123		
fgpdcpkrodb01				10.200.56.125 		a652766			Atos@123		
fgabumpx					10.200.44.208		a652766			Atos@123		
pil01db3					10.200.56.177		a652766			Atos@123		
lescxa07					10.200.56.167		a652766			Atos@123																											
lescxa0b					10.200.56.169		a652766			Atos@123																								
lescxa0c					10.200.56.168		a652766			Atos@123		
NTDEV050					10.200.56.107		FGA\oracledba	F!rstA0r
OPWORAIMG02A				10.200.56.109		FGA\oracledba	F!rstA0r!giN


==================================================================================================================
										( STENLEY )
==================================================================================================================
GEMS 		-->		DLT04437@atos.net						
Backup		-->		gmin-india-backupsupport@atos.net							
FGA Linux	-->		IN_AHS_UNIX-L3.it-solutions@atos.net							
UNIX		-->		IN_ICS_UNIX_NA_Support.it-solutions@atos.net							
WINTEL		-->		INAHSWintelNONGAINL2support.it-solutions@atos.net,INICSWintelNONGAINL3support.it-solutions@atos.net						
BACKUP 		-->		gmin-india-backupsupport_nongain-backup@atos.net							

arlhp01						10.200.66.20/10.130.129.20					a569880				Atos@1234
arlhp01						10.200.66.20/10.130.129.20          		a569880				Atos@1234
arlhp02						10.200.66.22/10.130.129.22         			a569880				Atos@1234
arlhp04						10.200.66.26/10.130.129.26          		a569880				Atos@1234
arlhp05						10.200.66.28/10.130.129.28          		a569880				Atos@1234
arlhp07						10.200.66.43/10.130.129.43         			a569880				Atos@1234
arlhp07						10.200.66.43/10.130.129.43          		a569880				Atos@1234
arlhp08						10.200.66.41/10.130.129.41          		a569880				Atos@1234
ddchp01						10.200.72.11/10.130.193.11          		a569880				Atos@1234
ddchp01						10.200.72.11/10.130.193.11          		a569880				Atos@1234
ddchp02						10.200.72.9	/10.130.193.8           		a569880				Atos@1234
ddchp03						10.200.72.7	/10.130.193.6           		a569880				Atos@1234
ddchp03						10.200.72.7	/10.130.193.6           		a569880				Atos@1234
sappd01						10.200.64.253	                    		a569880				Atos@1234
sapqd01						10.200.65.200	                    		a569880				Atos@1234
stlctlm01					10.200.67.108	                    		a569880				Atos@1234
stlctlmd01					10.200.68.58                       			a569880				Atos@1234


==================================================================================================================
										( philips )
==================================================================================================================
GEMS 		-->		DLT04437@atos.net						
Backup		-->		gmin-india-backupsupport@atos.net							
FGA Linux	-->		IN_AHS_UNIX-L3.it-solutions@atos.net							
UNIX		-->		IN_ICS_UNIX_NA_Support.it-solutions@atos.net							
WINTEL		-->		INAHSWintelNONGAINL2support.it-solutions@atos.net,INICSWintelNONGAINL3support.it-solutions@atos.net						
BACKUP 		-->		gmin-india-backupsupport_nongain-backup@atos.net
					--carlos.lunasepulveda@atos.net

US1EDIP3					10.200.101.163						a435715				March$2018		
US1EDIP4					10.200.101.164						a435715				March$2018

==================================================================================================================
										( HUNTSMAN )
==================================================================================================================
Help Desk	 --> 	helpdesk.belgium.hun@atosorigin-services.com													
Monitoring 	 -->	marek.kolosowski@atos.net								
Windows		 --> 	CS-IN-NAMNS.OSSupport@atos.net								
UNIX		 -->    in_ahs_unix-l3.it-solutions@atos.net,CS-IN-NAMNS.OSSupport@atos.net
					--Ganga mishra,ravindra javeda,pritesh kamble
SAP			 -->	dlsapbasisadmin.ca.it-solutions@atos.net								
Backup 		 -->	gmin-cloudops-compute@atos.net								
Alpha Cloude --> 	inunixsupport2@atos.net								

OEM			-->	https://10.201.64.26:7802/em/  			sysman/Summer2014      huntsmandba/cr3tic1l       		
oracle : n3wr3xd0g 
dbsnmp : newipo23  


bebma625 														h127379				aug$Action2017		 
bebma490            											h127379				bebma490$Action2018       
BEBMA397            											h127379				aug$Action2017       
bebma891            											h127379				aug$Action2017       
BEBMA626            											h127379				aug$Action2017       
BEBEA124            											h127379				aug$Action2017       
BEBMA892            											h127379				Welcome@2018       
Beevsdwq            											h127379				aug$Action2017       
usarav185           											h127379				aug$Action2017       
uscaav550           											h127379				aug$Action2017       
uscaav549           											h127379				aug$Action2017       
Beevsdwp            											h127379				aug$Action2017       
uscavdsab1          											h127379				aug$Action2017       
usarav102           											h127379				aug$Action2017       
usarav103           											h127379				aug$Action2017       
USARAV237           											h127379				aug$Action2017    --   
USCRLVDTOY          											h127379				USCRLVDTOY$Action2018
usarvpsab1          											h127379				March$Action2018
usarav199           											h127379				March$Action2018	
usarav198           											h127379				March$Action2018
usarav197           											h127379				March$Action2018
ussea433            											h127379				aug$Action2017       
ussea313            											h127379				ussea313$Action2018
ussea312            											h127379				aug$Action2017       
ussea340            											h127379				aug$Action2017       
ussea432            											h127379				March$Action2018
ussef336            											h127379				March$Action2018
W3lcome#2018
==================================================================================================================
										( venator )
==================================================================================================================
Help Desk	 --> 	sd-venator@atos-services.net												
Monitoring 	 -->	marek.kolosowski@atos.net								
Windows		 --> 	CS-IN-NAMNS.OSSupport@atos.net								
UNIX		 -->    in_ahs_unix-l3.it-solutions@atos.net,CS-IN-NAMNS.OSSupport@atos.net
					--Ganga mishra,ravindra javeda,pritesh kamble
SAP		 -->	dlsapbasisadmin.ca.it-solutions@atos.net								
Backup 		 -->	gmin-cloudops-compute@atos.net								
Alpha Cloude 	 --> 	inunixsupport2@atos.net								

Qwerty#12345678

EMEAA501														h127379				W3lcome#2018
EMEAAV102                                                       h127379				june$Action2018
EMEAAV257                                                       h127379				june$Action2018
EMEAAV258                                                       h127379				june$Action2018
emeaav336                                                       h127379				june$Action2018
EMEASV123                                                       h127379				june$Action2018
EMEASV124                                                       h127379				sep$Action2018
EMEASV125                                                       h127379				h127379
EMEASV164                                                       h127379				june$Action2018
EMEASV463                                                       h127379				june$Action2018
EMEASV464                                                       h127379				june$Action2018
EMEASV465                                                       h127379				june$Action2018
EMEASV466                                                       h127379				june$Action2018
EMEASV459                                                       h127379				june$Action2018
EMEAAV112                                                       h127379				june$Action2018

welcome123

==================================================================================================================
										( nybc )
==================================================================================================================

monitoring 		--> david.jasper@atos.net				US.Tools.ATMToolBox							
Backup 			-->	kenneth.newbern@atos.net ,Sagar Shinde											
UNIX			--> IN_ICS_UNIX_NA_Support.it-solutions@atos.net,jitendra.2.kumar@atos.net											
OEM 			--> https://edoem.nybc.org:7799/em	sysman/sysadm1n	 : shankar/oct2015	
wintel 			--> IT-Solutions IN ICS Wintel NON GAIN L2 support . <INAHSWintelNONGAINL2support.it-solutions@atos.net (file://inahswintelnongainl2support.it-solutions@atos.net/)>; IT-Solutions IN ICS Wintel NON GAIN L3 support  


pctepdb01						172.28.2.171						oracle				deploy4snow
pctepdb02						172.28.2.172                    	oracle				deploy4snow
pctepmdb01						172.28.2.153                    	oracle				deploy4snow
pcvepdb01						172.28.2.231                    	oracle				deploy4snow
pcvepdb02						172.28.2.232                    	oracle				deploy4snow
pcpepdb01						172.28.2.201                    	oracle				deploy4snow
pcpepdb02						172.28.2.202                    	oracle				deploy4snow
pcnepdb01						172.28.2.190                    	oracle				deploy4snow
sfvepdb01						172.29.2.231                    	oracle				deploy4snow
sfvepdb02						172.29.2.232                    	oracle				deploy4snow
sfpepdb01						172.29.2.201                    	oracle				deploy4snow
sfpepdb02						172.29.2.202                    	oracle				deploy4snow
ceaix01																oracle				ora11gcle
ceaix02																oracle				ora11gcle
vega																oracle				At0sDBA
VPVISORA01															vbhandwa			apr$Action2017		Terum0bct
VTVISORA01															vbhandwa			apr$Action2017		Terum0bct

==================================================================================================================
										( CSM)
==================================================================================================================

USTXSS264						10.150.0.174					oracle				gold$1234
CSMS00052						10.150.0.220                    oracle				gold$1234
CSMS00065						10.150.0.229                    oracle				gold$1234

==================================================================================================================
										( Atos internal )
==================================================================================================================


masd003x						155.45.63.77					a511411 			Atos@123
MASD007X						155.45.63.114					a511411 			Atos@123
MASD021X						155.45.63.163					a511411 			Atos@123
MASD057X						155.45.63.190					a511411 			Atos@123
MZSD023X						155.45.63.151					a511411 			Atos@123
MASD020X						155.45.63.153					a511411 			Atos@123
OHCLRP03						155.45.63.83					a511411 			Atos@123
OHCLRP06						155.45.63.109							
OHERSP01						155.45.63.30					a511411 			Atos@123
MASD058X						155.45.65.88					a511411 			Atos@123
USLZUA0001UDAT					155.45.121.160							
USLZUA0006USRV					155.45.145.44 							
USLZUC1P703DAT					155.45.119.139					a511411 			Atos@123
USLZUILX001DAT					155.45.120.235							
USMASA00017DAT					155.45.61.231					a511411 			Atos@123
USMASA0003ZSRV					155.45.61.39					a511411 			Atos@123
USMASOHX001DAT					155.45.59.69					a511411 			Atos@123 
USLZUA000E6SRV					10.85.153.163				 
MASD077X						155.45.63.1	 			

==================================================================================================================
										( unify)
==================================================================================================================
	
LZUC064A														a_alad				Dragon11$
LZUC065A                                                        a_alad				Dragon11$
USIRVC0003KSRV                                                  a_alad				Dragon11$
USIRVC0004ASRV                                                  a_alad				Dragon11$
USIRVC00045SRV                                                  a_alad				Dragon11$


==================================================================================================================
										( finolex)
==================================================================================================================
AIX team 	----> Savla, Dipen dipen.savla@atos.net	;tripti.kumari@atos.net;GMIN-MO-UNIX-AIX gmin-mo-unix-aix@atos.net													
Storage team----> Feroskhan, Abdul <abdul.feroskhan@atos.net>; GMIN-Storage-Mumbai <gmin-storage-mumbai@atos.net>								




FEPDEV					192.9.201.56							oradev				finolex1234
FEPQAS					192.9.201.57							oraqas				finolex1234
FBIWDEV					192.9.201.51							orafbd				finolex1234
FBIWQAS					192.9.201.52							orafbq				finolex1234
FEPPRD					192.9.201.58							orafep				finolex1234
eccprddb				192.9.201.14 /11						oraprd				basis123
eccprdci				192.9.201.15/12						oraprd				basis123
devsrv					192.9.201.20							oradev				basis123
qassrv					192.9.201.30							oraqas				basis123
solman					192.9.201.21							oraslp				finolex1234
eppsrv					192.9.201.29							oraepp				finolex1234
epdsrv					192.9.202.17							oraepp				finolex1234
FBIWPRD					192.9.201.53							orafbp				finolex1234
filclust1				192.9.208.6						 	oraprd				basis123

==================================================================================================================
										( ASHlAND / valvoline )
==================================================================================================================


ORAEMT1.ASCO.ASHLAND.COM 					c805654			apr$Action2018										
TESTCTLM.ASCO.ASHLAND.COM                   c805654			apr$Action2018	
CTMPRDB8.ASCO.ASHLAND.COM                   c805654			apr$Action2018	
ORADVDB2.ASCO.ASHLAND.COM                   c805654			apr$Action2018	
ORAQADB1.ASCO.ASHLAND.COM                   c805654			apr$Action2018	
ORAPRDB1.ASCO.ASHLAND.COM                   c805654			apr$Action2018	
NAOHDUBDVX503.ashland.ad.ai                 c805654			apr$Action2018	
NAKYLEXDVX104.ashland.ad.ai                 c805654			apr$Action2018	
NATXIRRMAN201.CORP.ASHLAND.COM				oracle			RMAN_A5H1AN0

ORAVEMT1.CORP.VALVOLINE.COM					c805654			aug$Action2018
CTMVTST1.CORP.VALVOLINE.COM                 c805654         aug$Action2018
CTMVPRD1.CORP.VALVOLINE.COM                 c805654         aug$Action2018
ORAVDDB1.CORP.VALVOLINE.COM                 c805654         aug$Action2018
ORAVQDB1.CORP.VALVOLINE.COM                 c805654         aug$Action2018
ORAVPDB1.CORP.VALVOLINE.COM                 c805654         aug$Action2018
ORAVDV1.CORP.VALVOLINE.COM                  c805654         aug$Action2018
ORAVQA1.CORP.VALVOLINE.COM                  c805654         ORAPRDB3.CORP.VALVOLINE.COM                 c805654         aug$Action2018
ORAVTR1.CORP.VALVOLINE.COM                  c805654         aug$Action2018
NATXIRRMAN101.CORP.VALVOLINE.COM 			oracle			RMAN_VALVOLIN3

CORP.ASHLAND.COM	         				Admingate (MGMT)			
NATXIRVJH101                 				10.202.173.51				corpash/c805654			Nov@2018!123456
NATXIRVJH102                 				10.202.173.52				corpash/c805654         Welcome1234
NATXIRVJH103                 				10.202.173.53				corpash/c805654         Welcome1234
NATXIRVJH104                 				10.202.173.54 				corpash/c805654         Welcome1234
CORP.VALVOLINE.COM	         				Admingate (MGMT)	                                
NATXIRVJH201                 				10.202.176.221				corpval/c805654         Welcome123456
NATXIRVJH202                 				10.202.176.222	            corpval/c805654         Welcome123456
NATXIRVJH203                 				10.202.176.223	            corpval/c805654         Welcome123456
NATXIRVJH204                 				10.202.176.224  	        corpval/c805654         Welcome123456




==================================================================================================================
										( monsanto )
==================================================================================================================
OEM ----> https://oemprd.monsanto.com/em	sysman				tfr1s1ng	

Metalink oracle SR login 
username : karthikeyan.1.b@monsanto.com (file://karthikeyan.1.b@monsanto.com/) 
pwd : Sbi_262692 
S is alone caps 


Cna2018$

VB2018vb$

VB0820vb

aug$Act2018

Virtual Machine Host Name

VW7MSPATSP1142

CID: CAE0735

Employee Id:  238908

Dummy SSN: 777-02-4175