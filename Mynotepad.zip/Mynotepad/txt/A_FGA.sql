161.89.145.218

NAM Inventory:		"D:\DBA\Atos\Inventory"
password :			 CEsduflp!


a186526
Jackman@00
=================================================================================================
													  FGA
==================================================== Atos@123 ====================================


fgsdcdcacdb01			not connect 		10.158.17.105			a652766			Atos@123	 	ORADEV01
																									CADEV
																									BAGSDEV

fgpdcpcacdb01				connect			10.200.57.105			a652766			Atos@123		BAGSPRD:/oracle/product/9.2.0:N
																									CAPRD:/oracle/product/9.2.0:N
																									HEATPRD:/oracle/product/9.2.0:N

fgpdcdjskap44				connect			10.200.57.95			a652766			Atos@123		NJUSTST:/oracle/product/9.2:Y
																									NJUSDEV:/oracle/product/9.2:Y
																									NJCADEV:/oracle/product/9.2:Y
																									NJCATST:/oracle/product/9.2:Y

fgpdcpjskap44				connect			10.200.57.90			a652766			Atos@123		NJPRD:/oracle/product/9.2.0:Y

fgpdcpjskap46																						NJPRD:/oracle/product/9.2.0:Y
							connect									a652766			Atos@123		NJCAPRD:/oracle/product/9.2.0:Y

fgpdcpfocdb01				connect			10.200.44.38			a652766			Atos@123		FOCUSPRD:/appl/oracle/product/v102:Y

fgsdcqfocdb01			not	connect			10.200.48.29			a652766			Atos@123	

	
fgsdcrfocdb01				connect			10.200.48.28			a652766			Atos@123		FOCUSPRF:/appl/oracle/product/v102:Y
																									FOCUSPRD:/appl/oracle/product/v102:Y

fgpdcpkrodb01				connect			10.200.56.125 			a652766			Atos@123		FOCUSPRF:/appl/oracle/product/v102:Y
																									FOCUSPRD:/appl/oracle/product/v102:Y

fgabumpx					connect			10.200.44.208			a652766			Atos@123		HRUSADEV:/DEV/oracle/products/9.2.0:Y
																									HRCANDEV:/DEV/oracle/products/9.2.0:Y
																									HRUSATST:/QA/oracle/products/9.2.0:Y
																									HRCANTST:/QA/oracle/products/9.2.0:Y
																									ADPIDEV:/DEV/oracle/products/10.2.0:Y
																									HRDMO:/DEV/oracle/products/9.2.0:N
pil01db3					connect			10.200.56.177			a652766			Atos@123		HRUSAPRD:/PRO/oracle/products/9.2.0:Y
																									HRCANPRD:/PRO/oracle/products/9.2.0:Y
																									
lescxa07					connect			10.200.56.167			a652766			Atos@123		DWDEV:/DEV/oracle/product/10.2.0:Y
																									RMANDEV:/DEV/oracle/product/10.2.0:Y
																									DWRPTDEV:/DEV/oracle/product/10.2.0:Y
																									XETLDEV:/DEV/oracle/product/10.2.0:Y
																									GENDB:/DEV/oracle/product/10.2.0:Y
																									
lescxa0b					connect			10.200.56.169			a652766			Atos@123		DWPRD:/PRO/oracle/product/10.2.0:Y
																									DWRPTPRD:/PRO/oracle/product/10.2.0:Y
																									XETLPRD:/PRO/oracle/product/10.2.0:Y
																									RMANPRD:/PRO/oracle/product/10.2.0:Y
																									ADPIPRD:/PRO/oracle/product/10.2.0:Y
																									
lescxa0c					connect			10.200.56.168			a652766			Atos@123		XETLSYS:/QA/oracle/product/10.2.0:Y
																									DWSYS:/QA/oracle/product/10.2.0:Y
																									GENDBSYS:/QA/oracle/product/10.2.0:Y
																									ADPITST:/QA/oracle/product/10.2.0:Y

																									
NTDEV050	10.200.56.107	FGA\oracledba	F!rstA0r!giN

OPWORAIMG02A 10.158.10.109	FGA\adm-pshah	January@2017
 

																									
																							



---------------------------------------------------------------------------------------------------
