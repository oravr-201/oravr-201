
FOR ussea313 :

OCW	: 26609929
ACFS	: 22502505
DB PSU	: 26609445	
ojvm	: /rmana/PATCH_TWE_OCT17/26550684/26027154

1)DB Environment:	
srvctl stop home -o /u01/app/oracle/product/11.2.0.4 -s /u01/Patches/HomeStatus.log	
	
2)Root user:	
/u01/app/grid/product/11.2.0/crs/install/roothas.pl -unlock	
	
3)Apply OCW ==>ACFS==> DB PSU patch on grid home .	
As GI home owner:--oracle	-----grid home :/u01/app/grid/product/11.2.0
Cd /u07/PATCH/23274134	
opatch napply -oh /u01/app/grid/product/11.2.0 -local /rmana/PATCH_TWE_OCT17/26550684/26610246/26609929			-------OCW
opatch napply -oh /u01/app/grid/product/11.2.0 -local /rmana/PATCH_TWE_OCT17/26550684/26610246/22502505			-------ACFS
opatch napply -oh /u01/app/grid/product/11.2.0 -local /rmana/PATCH_TWE_OCT17/26550684/26610246/26609445			-------DBPSU	
	
	
	
4)Prepatch---Oracle user	
/rmana/PATCH_TWE_OCT17/26550684/26610246/26609929/custom/server/26609929/custom/scripts/prepatch.sh -dbhome  /u01/app/oracle/product/11.2.0.4----database home	
	
5)Apply db patches--oracle user	----database home
opatch napply -oh /u01/app/oracle/product/11.2.0.4 -local /rmana/PATCH_TWE_OCT17/26550684/26610246/26609929/custom/server/26609929	
opatch apply -oh /u01/app/oracle/product/11.2.0.4 -local /rmana/PATCH_TWE_OCT17/26550684/26610246/26609445	
	
6)Postpatch script--oracle user	----database home
/rmana/PATCH_TWE_OCT17/26550684/26610246/26609929/custom/server/26609929/custom/scripts/postpatch.sh -dbhome /u01/app/oracle/product/11.2.0.4	
	
7)Root user	
/u01/app/grid/product/11.2.0/rdbms/install/rootadd_rdbms.sh	
/u01/app/grid/product/11.2.0/crs/install/roothas.pl -patch	
	
8)Start home--oracle user	
srvctl start home -o  /u01/app/oracle/product/11.2.0.4 -s /u01/Patches/HomeStatus.log	
	
9)Postpatch installation on Databases:	
startup;	
@?/rdbms/admin/catbundle.sql psu apply	
@?/rdbms/admin/utlrp.sql


shut IMMEDIATE ;








sqlplus  / AS SYSDBA
startup upgrade
@postdeinstall.sql
shutdown
startup