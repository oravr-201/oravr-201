--- Expdp/Impdp monitoring
select SID,username,OPNAME,SOFAR,TOTALWORK,SOFAR/TOTALWORK*100 "Work Done %",
	to_char(START_TIME,'mm/dd/yyyy hh24:mi:ss') "start_time",
	to_char(sysdate + TIME_REMAINING/3600/24,'mm/dd/yyyy hh24:mi:ss') "End_at",
	to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')Date_Now
from v$session_longops
where sofar!=TOTALWORK 
  and totalwork!=0
  
  
-- Oracle DataPump Utility



-- Once the job has started the status can be checked using.
system@db10g> select * from dba_datapump_jobs;


-- Oracles export import utilities helps to move data between schemas and databases. With export and import feature one can 
-- backup data in operating system files, restore data if required. Following example explains exactly how EXPORT and IMPORT utilities 
-- are used to perform above mentioned activities.

exp test_user/test_user@dev file=TLD_test_0805.dmp log=TLD_test_0805_exp.log statistics=none tables=employee

-- In the above example, only employee table will be exported to dump file from test_user schema. If you want to do EXPORT for multiple 
-- tables, add names of tables within parenthesis separated by comma [tables=(emp,dept)]. We can further filter by adding query parameter. 
-- Data which satisfies the given condition are only exported to file. The example with QUERY parameter is as follows:

exp test_user/test_user@dev file=TLD_test_0805.dmp log=TLD_test_0805_exp.log statistics=none tables=employee query=\"where emp_city=\'PUNE\'\"

-- In the above example, only employee whose city is PUNE will be filtered and retrieved to the dump file.

exp test_user/test_user@dev owner=test_user file=TLD_test_0805.dmp log=TLD_test_0805_exp.log statistics=none

-- In the above example export will be performed on OWNER test_user. All the objects and data of test_user will be exported. If you do not 
-- want to export rows then mention ROWS=N. By default ROWS=Y.

-- The original EXPORT IMPORT is a default feature in ORACLE. Now ORACLE has introduced Data Pump from 10g onwards which replaces export import utility.

------------------------------------------------------------------------------------------------------------------------------------------------------------


/* 				ORACLE - DATA PUMP
	
A very high speed utility for moving data and meta-data from one database to another database.

Fast Data Movement between databases (Twice the speed when compared to EXPORT utility and twenty to thirty times faster when performing IMPORT.

Only time you would/ should use the original (exp & imp) is when you need backward compatibility to an earlier version that does not have Data 
Pump export & import (expdp & impdp). 

Basically if you wanted to import a 10g export into a pre-10g database or import into a 10g database from a pre-10g database.
DATA PUMP � ORACLE 10G

New feature in ORACLE 10g that replaces normal export/import even though exp/imp are supported.

First we must create a directory object which will be accessed for export of mentioned tables. The directory object will be mapped to directory 
location where the dump files will be held.

create directory dir_obj as '/home/oracle/dir';

Here a directory object named dir_obj has been created which points to directory location /home/oracle/dir where the dump files are held. 
ORACLE introduced a default directory called DATA_PUMP_DIR which can also be used for dump files. But the user show have the privilege to 
use the default directory.

Once the directory object has been created, READ and WRITE privileges are to be granted on the directory object to the users who will be 
accessing for export/import activities.

grant read, write on directory dir_obj to test_user;

In the above statement test_user has been granted with read and write privileges on dir_obj. Now test_user can write dump files to dir_obj 
and even read existing dump files for doing import.

*/

-- Now to perform EXPORT of employee table from test_user schema:

expdp test_user/test_user@dev10g directory=dir_obj tables=employee dumpfile=test_user.dmp logfile=test_user_exp.log

OR

expdp test_user/test_user@dev10g tables=employee dumpfile=dir_obj:test_user.dmp logfile=dir_obj:test_user_exp.log

OR

expdp tables=employee dumpfile=dir_obj:test_user.dmp logfile=dir_obj:test_user_exp.log


-- All the above 3 examples perform same action, ie., make dump file of employee table from test_user schema. When E3 is run, the username and 
-- password is prompted.

-- Now if we want to further filter and we want only selected rows in a table which meets the condition, then the following export statement with 
-- the help of QUERY parameter retrieves only the data matching condition to dump file.

expdp test_user/test_user@dev10g dumpfile=dp_dir:TU_Q.dmp logfile=dp_dir:TU_Q_exp.log tables=airport query=airport:\'\"where airport_code=1\"\'

expdp system/sys88qadb@qadb dumpfile=tu_q.dmp logfile=imp_tu_q.log tables=transhms.DOWNLOAD_DOC_CATEGORY_MAPPING query=transhms.DOWNLOAD_DOC_CATEGORY_MAPPING:\'\"where DESCRIPTION=\'Application Form\'\"\'


-- You can use Data Pump Export utility to export multiple tables. The following example shows the syntax to export tables:
expdp test_user/test_user@dev10g DIRECTORY=dp_dir 
DUMPFILE=multiple_tbls.dmp LOGFILE=multiple_tbls_exp.log 
TABLES=employees,jobs,departments

-- And adding QUERY again on one table when using multiple tables:
expdp test_user/test_user@dev10g 
DIRECTORY=dp_dir 
DUMPFILE=multiple_tbls.dmp 
LOGFILE=multiple_tbls_exp.log 
TABLES=employees,jobs,departments 
QUERY=jobs:\'\�where job_id = 407\�\'

-- In the above case both the departments and jobs tables are completely exported and employee records of jod_id 407 are exported from employee table.

expdp test_user/test_user@dev10g 
schemas=test_user 
include=TABLE:\"IN (\'EMP\', \'DEPT\')\" 
directory=TEST_DIR 
dumpfile=include_test.dmp 
logfile=include_test_expdp.log

-- In the above example from the schema test_user only objects which are mentioned in INCLUDE parameter are exported. Rest are ignored.

expdp test_user/test_user@dev10g 
schemas=test_user 
EXCLUDE=SEQUENCE, TABLE:\�IN (\'EMP,\ 'DEPT\')\�  --'
directorty=test_dir 
dumpfile=exclude_test.dmp 
logfile=exclude_test_exp.log 

-- In the above example, EXCLUDE parameter has been used. Here EXCLUDE parameter does not export sequences and tables mentioned. Rest of 
-- all the objects for test_user schema are exported.

 
-->> Table Import:

-- As we have seen how to do Export on a particular table, set of tables and also using QUERY parameter, now let us see how to do the import 
-- of the dump files being created in the directory through directory object.

-- Performing Data pump IMPORT is quite easy and twenty to thirty times faster than original IMPORT. Following examples give a clear picture 
-- of IMPORT Data Pump Utility.

impdp test_user/test_user@qadb86 tables=emp_s dumpfile=dp_dir:test.dmp logfile=dp_dir:test.log 
-- In the above example we are doing import of same schema but of different databases.

impdp system/sysdev@dev10g tables=emp_s dumpfile=dp_dir:test.dmp logfile=dp_dir:test.log remap_schema=test_user:test_2 transhms:transhms_reg
-- Lets assume that we have done export of a table emp_s from test_user schema and now we want to do import of the table to test_2 schema. In 
-- this case we use the above syntax where remap_schema keyword has been used. It is similar to fromuser & touser in original import.

-- Let us now import more than one tables.

impdp test_user/test_user@dev10g tables=employee,dept,course dumpfile=test_dir:test.dmp logfile=test_dir:test_imp.log
-- In the above example the dumpfile will be imported to test_user schema to tables employee, dept and course. Note that the table structure is 
-- same as of the tables exported from.

impdp test_user/test_user@dev10g schemas=test_user include=function, package, procedure, table:�='emp'� dumpfile=test.dmp logfile=test_imp.dmp
-- In the above example the include parameter will only import functions, packages, procedures owned by test_user schema and employee table and all its dependent objects.

expdp rchaudhari@r1 
directory=oradata8 
dumpfile=expdp_Device_24Apr2012.dmp 
logfile=log_Device_24Apr2012.log 
tables=snox4transnox_gca.device 
query=snox4transnox_gca.device:\"where device_id in\(SELECT DEVICE_ID FROM TRANSNOX_gca.TRANSACTION X WHERE X.TIME_STAMP BETWEEN TO_DATE\(\'02\/28\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND  TO_DATE\(\'04\/02\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\)\" 
include=table,table_data,statistics,constraint 
compression=all

expdp rchaudhari@r1 
directory=oradata8 
dumpfile=expdp_ADMIN_TRANSACTION_24Apr2012.dmp 
logfile=log_ADMIN_TRANSACTION_24Apr2012.log 
tables=transnox_gca.ADMIN_TRANSACTION 
query=transnox_gca.ADMIN_TRANSACTION:\"where TIME_STAMP BETWEEN TO_DATE\(\'02\/28\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'04\/02\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" 
include=table,table_data,statistics,constraint 
REUSE_DUMPFILES=y 
CONTENT=all


expdp bdas directory=dash 
dumpfile=exp_trans_13m.dmp 
logfile=exp_trans_13m.log 
schemas=transnox_gca 
include=table:\"like \'TRANS%\'\" 
query=\"where transaction_id \>\= 2111429013\"

expdp rchaudhari directory=dash 
dumpfile=exp_trans_13m.dmp 
logfile=exp_trans_13m.log 
schemas=transnox_gca 
include=table:\"like \'TRANS%\'\" 
query=\"where transaction_id \>\= 2111429013\" 
content=data_only 
compression=all 
reuse_dumpfiles=y


expdp rchaudhari/isplN01805@COL122 
directory=arch 
dumpfile=expdp_trans_response_info_12052015.dmp 
logfile=expdp_trans_response_info_12052015.log 
tables=TRANSNOX_GCA.TRANS_RESPONSE_INFO 
query=TRANSNOX_GCA.TRANS_RESPONSE_INFO:\" WHERE TRANSACTION_ID \>\ 2381397201\" 
content=data_only 
compression=all 
reuse_dumpfiles=y
 
expdp rchaudhari@r1 
directory=oradata8 
dumpfile=expdp_ADMIN_TRANS_CASH_BALANCE_24Apr2012.dmp 
logfile=log_ADMIN_TRANS_CASH_BALANCE_24Apr2012.log 
tables=transnox_gca.ADMIN_TRANS_CASH_BALANCE 
query=transnox_gca.ADMIN_TRANS_CASH_BALANCE:\"where ADMIN_TRANS_ID in\(select ADMIN_TRANS_ID from TRANSNOX_GCA.ADMIN_TRANSACTION where TIME_STAMP BETWEEN TO_DATE\(\'02\/28\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'04\/02\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\)\" 
include=table,table_data,statistics,constraint 
REUSE_DUMPFILES=y 
CONTENT=all

expdp rchaudhari@r1 
directory=oradata8 
dumpfile=expdp_DEVICE_PROCESSOR_INFO_24Apr2012.dmp 
logfile=log_DEVICE_PROCESSOR_INFO_24Apr2012.log 
tables=TRANSNOX_GCA.DEVICE_PROCESSOR_INFO

expdp rchaudhari@r1 
directory=oradata8 
dumpfile=expdp_CUST_ADDRESS_24Apr2012.dmp 
logfile=log_CUST_ADDRESS_24Apr2012.log 
tables=transnox_gca.CUST_ADDRESS 
query=transnox_gca.CUST_ADDRESS:\"where CUSTOMER_CODE in\(select CUSTOMER_CODE from transnox_gca.task where task_id in\(select task_id from TRANSNOX_GCA.TRANSACTION where TIME_STAMP BETWEEN TO_DATE\(\'02\/28\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'04\/02\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\)\)\" 
include=table,table_data,statistics,constraint 
REUSE_DUMPFILES=y 
CONTENT=all

expdp rchaudhari 
directory=ora6 
dumpfile=app_mer_doc_moneris.dmp 
logfile=app_mer_doc_moneries.log 
tables=transmoneris.app_mer_documents 
include=table,table_data 
compression=all 
query=transmoneris.app_mer_documents:\" where Application_id in\(100849,100836,95759,95472,95932,95917,95789,93689,82794,82854,82848,94455\)\"

expdp rchaudhari@r1 
directory=oradata8 
dumpfile=expdp_CARD_NUMBER_MASTER_24Apr2012.dmp 
logfile=log_CARD_NUMBER_MASTER_24Apr2012.log 
tables=transnox_gca.CARD_NUMBER_MASTER 
query=transnox_gca.CARD_NUMBER_MASTER:\"where CARD_SEQNO in\(select CARD_NUMBER from Transnox_GCA.TRANS_CARD where TRANSACTION_ID in\(select TRANSACTION_ID from TRANSNOX_GCA.TRANSACTION where TIME_STAMP BETWEEN TO_DATE\(\'02\/28\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'04\/02\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\)\)\" 
include=table,table_data,statistics,constraint 
REUSE_DUMPFILES=y 
CONTENT=all

expdp rchaudhari@r1 
directory=oradata8 
dumpfile=expdp_MERCHANT_24Apr2012.dmp 
logfile=log_MERCHANT_24Apr2012.log 
tables=snox4transnox_gca.MERCHANT 
query=snox4transnox_gca.MERCHANT:\"where MERCHANT_ID in\(select MERCHANT_ID from SNOX4Transnox_GCA.DEVICE where DEVICE_ID in\(select DEVICE_ID from TRANSNOX_GCA.TRANSACTION where TIME_STAMP BETWEEN TO_DATE\(\'02\/28\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'04\/02\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\)\)\" 
include=table,table_data,statistics,constraint 
REUSE_DUMPFILES=y 
CONTENT=all


-- If export is done by table level and one of the table failed to import the data�
expdp / directory=bkup 
dumpfile=exp_tnox_gca_org1.dmp 
logfile=exp_tnox_gca_org.log  
tables=transnox_gca.TRANS_RESPONSE_INFO_ORG1,transnox_gca.TRANSACTION_ORG1,transnox_gca.TRANS_CARD_ORG1,transnox_gca.TRANS_CARD_HISTORY_ORG1,transnox_gca.TASK_TIME_LOG_ORG,transnox_gca.TASK_ORG1  
include=table,table_data 
compression=all

-- then you can import the table separately� 
impdp / directory=tbackup 
dumpfile=exp_tnox_gca_org1.dmp 
logfile=impdp_exp_tnox_gca_org12.log 
remap_schema=transnox_gca:transnox_gca_22a 
tables=transnox_gca.trans_response_info_org1 
remap_tablespace=trans_data3:tgca_22_data




-->> Schema Export:

-- Following examples will explain how to perform export of a schema.

expdp test_user/test_user@dev10g schemas=test_user directory=test_dir dumpfile=schema_test.dmp logfile=schema_test_exp.dmp
-- In the above example export is performed on all the objects, data and meta-data of test_user schema .

expdp system/sysdev@dev10g schemas=test_user,test_1,test_2 dumpfile=test_dir:multiple_schemas.dmp logfile=test_dir:multiple_schemas_exp.log
-- In the above example we are performing export of objects from more than one schema.



-->> Schema Import:

-- Following examples will explain about the import procedure of schema.

-- Below is the example we have performed import of schema from the dump file test.dmp which was accessed from test_dir directory.
impdp system/sysdev@dev10g 
schemas=test_user 
dumpfile=test_dir:test.dmp 
logfile=test_dir:test_imp.log 
remap_schema=test_user:test_2 
REMAP_SCHEMA=FROM:TO

impdp test_user/test_user@dev10g 
schemas=test_user 
directory=test_dir 
dumpfile=test.dmp 
logfile=test.log 
EXCLUDE=TABLE:\"LIKE \'DEF%\'\" 

 expdp / directory=bkup dumpfile=expdp_bkup_UAT_12661_21Sep2015.dmp logfile=expdp_bkup_UAT_12661_21Sept2015.log full=y 
 exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\" compression=all 
-- and

-- Exporting the schema tables without some tables like SN_TEMP, statistics
expdp system@dev11g 
directory=data_pump_dir 
dumpfile=dev11g231_84.dmp 
logfile=dev11g231_84.log 
schemas=OFAC,SNOX_BS,SNOX4TRANSNOX_API,SNOXGCA_91X_20101P,TNOXGCA_91X_20101P,TRANSNOX_API,TRANSNOX_BS,TRANSNOX_CNW,TRANSNOX_GLORY,TRANSNOX_IOX,TRANSNOX_WM 
exclude=statistics,TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\" 
compression=all 
reuse_dumpfiles=y

-- Importing the schema with selected objects and selected tables data
impdp test_user/test_user@dev10g 
schemas=test_user 
directory=test_dir 
dumpfile=test.dmp 
logfile=test.log 
INCLUDE=procedure,table 
QUERY=emp:\'\�where deptid=30\�\'


-- We have used INCLUDE parameter when performing import, which means that only mentioned objects are imported to schema while rest are not. 
-- We have also used QUERY. Hence only data satisfying the condition are actually imported.

-- REMAP_TABLESPACE option has been used to import objects of one tablespace to another tablespace by giving the following command
impdp test_user/test_user@dev10g 
DIRECTORY=test_dir 
DUMPFILE=test.dmp 
LOGFILE=test_exp.log 
REMAP_TABLESPACE=users:sales


-- One of the most important feature available with Data Pump is the job feature. The data pump process work as a background job in 
-- database. We can detach ourself from the session and re-attach to monitor the session. Also we can stop or pause the job.


expdp test_user/test_user@dev10g schemas=test_user dumpfile=test_dir:test_job.dmp logfile=test_dir:test_job.log job_name=test parallel=4
-- In the above example we have added two parameters (job_name & parallel). We have named the job name as test and we are running parallel 
-- processing for export.

/*
	When the export starts, we can press Control+C to get the interactive prompt (Export>). If we try the same in normal export/import 
we will get some error message and the process will fail.

When we are in interactive mode we can issue status command and various details. Also we can query following views:

�	DBA_DATAPUMP_JOBS - all active Data Pump jobs and the state of each job
�	USER_DATAPUMP_JOBS � summary of the user�s active Data Pump jobs
�	DBA_DATAPUMP_SESSIONS � all active user sessions that are attached to a Data Pump job
�	V$SESSION_LONGOPS � shows all progress on each active Data Pump job

We can also stop the running job at anytime and resume after sometime when required. The job_name is first detached from the 
running data pump session by firing stop_job command. The job is stopped now.

*/

-- When we want to start the job again where it was left off, it can be done in oracle 10g data pump. It is done as follows:

expdp test_user/test_user@dev10g attach=job_name





-->> INCLUDE=<include_list>

-- The job is again started where it was left off. This is one of the most important advantage of using data pump over normal export/import utility.

expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo20.dmp INCLUDE=table

expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo21.dmp INCLUDE=\"IN ('SERVERS', 'SERV_INST')\"

expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo22.dmp INCLUDE=procedure

expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo23.dmp INCLUDE=INDEX:\"LIKE 'PK%\" --'

EXCLUDE=<exclude_criterion>

-- exclude all (nonreferential) constraints, except for NOT NULL constraints and any constraints needed for successful table creation and loading
expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo12.dmp EXCLUDE=constraint

-- exclude referential integrity (foreign key) constraints
expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo13.dmp EXCLUDE=ref_constraint

-- exclude object grants on all object types and system priv grants
expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo14.dmp EXCLUDE=grant


-- excludes the definitions of users
expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo15.dmp EXCLUDE=user

-- excludes views
expdp uwclass/uwclass SCHEMAS=uwclass DIRECTORY=data_pump_dir DUMPFILE=demo16.dmp EXCLUDE=view,package,function

--To exclude a specific user and all objects of that user, specify a filter such as the following (where hr is the schema name of the user you want to exclude):
expdp uwclass/uwclass FULL=y DIRECTORY=data_pump_dir DUMPFILE=demo17.dmp EXCLUDE=SCHEMA:\"='HR'\"

-- Take full backup and exclude list of schemas
expdp / directory=BKUP_ARCH dumpfile=expdp_121_reportingDB_03Mar2016.dmp logfile=expdp_Server121_reportingDB_03Mar2016.log full=y compression=all exclude=SCHEMA:\" in \(\'ANONYMOUS\',\'APEX_030200\',\'APEX_PUBLIC_USER\',\'APPQOSSYS\',\'CTXSYS\',\'DBSNMP\',\'DIP\',\'EXFSYS\',\'FLOWS_FILES\',\'MDDATA\',\'MDSYS\',\'MGMT_VIEW\',\'OLAPSYS\',\'OPS$DBJOBS\',\'ORACLE_OCM\',\'ORDDATA\',\'ORDPLUGINS\',\'ORDSYS\',\'OUTLN\',\'OWBSYS\',\'OWBSYS_AUDIT\',\'SCOTT\',\'SI_INFORMTN_SCHEMA\',\'SPATIAL_CSW_ADMIN_USR\',\'SPATIAL_WFS_ADMIN_USR\',\'SQLTXADMIN\',\'SQLTXPLAIN\',\'SYS\',\'SYSMAN\',\'SYSTEM\',\'WMSYS\',\'XDB\',\'XS$NULL\'\)\"

The EXCLUDE and INCLUDE parameters are mutually exclusive.
It is not possible to specify both the INCLUDE parameter and the EXCLUDE parameter in the same job.
Incorrect syntax (error: UDE-00011):
expdp scott/tiger@dev dumpfile=exp_test.dmp INCLUDE=TABLE:"IN ('EMP', 'DEPT')" EXCLUDE=INDEX:"= 'PK_EMP'"

--- Exclude and Include expdp/impdp contains the below objects which can be export/import �ed
 
USER
SYSTEM_GRANT
ROLE_GRANT
DEFAULT_ROLE
TABLESPACE_QUOTA
PROCACT_SCHEMA
SYNONYM
SEQUENCE
OBJECT_GRANT
TABLE
OBJECT_GRANT
INDEX
CONSTRAINT
PACKAGE_SPEC
FUNCTION
OBJECT_GRANT
PROCEDURE
OBJECT_GRANT
ALTER_PACKAGE_SPEC
ALTER_FUNCTION
ALTER_PROCEDURE
VIEW
OBJECT_GRANT
PACKAGE_BODY
REF_CONSTRAINT
TRIGGER
INDEX
MATERIALIZED_VIEW
JOB
REFRESH_GROUP
PROCACT_SCHEMA




-->> TRANSPORT_TABLESPACES=<tablespace_name [, ...]>

--The default tablespace of the user performing the export must not be set to one of the tablespaces being transported
expdp uwclass/uwclass 
DIRECTORY=data_pump_dir 
DUMPFILE=demo05.dmp
LOGFILE=demo5.log
TRANSPORT_TABLESPACES=users,example 
TRANSPORT_FULL_CHECK=y 


conn / as sysdba

ALTER TABLESPACE users READ ONLY;
ALTER TABLESPACE example READ ONLY;

expdp uwclass/uwclass 
DIRECTORY=data_pump_dir 
DUMPFILE=demo05.dmp
TRANSPORT_TABLESPACES=users,example 
TRANSPORT_FULL_CHECK=y LOGFILE=demo5.log

ALTER TABLESPACE users READ WRITE;
ALTER TABLESPACE example READ WRITE;



-->> QUERY=<[schema.][table_name:]query_where_clause>

expdp uwclass TABLES=airplanes DUMPFILE=data_pump_dir:demo30.dmp QUERY=airplanes:\"WHERE program_id = ''737''\"

--to export using joining the tables
expdp rchaudhari@qadb 
directory=ORADATA1 dumpfile=expdp_trans_response_info logfile=expdp_trans_response_info tables=transnox_gca.trans_response_info 
query=transnox_gca.trans_response_info:\" where transaction_id in \(SELECT transaction_id FROM TRANSNOX_GCA.TRANSACTION WHERE transnox_gca.TRANSACTION.time_stamp BETWEEN TO_DATE\(\'01/01/2011 00:00:00\',\'mm/dd/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12/19/2011 23:59:59\',\'mm/dd/yyyy hh24:mi:ss\'\)\)\" 
include=table,table_data 
reuse_dumpfiles=y

--- use objects to exclude/include in expdp/impdp
statistics,
procedure,
function,
package,
package_body,
trigger,
index,
index_partition,
materialized_view,
sequence,
synonym,
type,
view,
index_statistics,
ref_constraint,
object_grant,
job




-->> Network import 

-- With network mode imports, one doesn't need any intermediate dump files (GREAT, no more FTP'ing of dump files). Data is exported across 
-- a database link and imported directly into the target database. 

Example: 

SQL> create user new_scott identified by tiger;

User created.

SQL> grant connect, resource to new_scott;

Grant succeeded.

SQL> grant read, write on directory dmpdir to new_scott;

Grant succeeded.

SQL> grant create database link to new_scott;

Grant succeeded.

SQL> conn new_Scott/tiger

Connected.

SQL> create database link old_scott connect to scott identified by tiger using 'orcl.oracle.com';

Database link created.

impdp new_scott/tiger DIRECTORY=dmpdir NETWORK_LINK=old_scott remap_schema=scott:new_scott

impdp system/sys88qadb@qadb 
dumpfile=  
logfile=imp_transnox_gateway_logs.log 
schemas=transnox_cpass,snox4transnox_cpass,tnoxpass_gway_00513,snoxpass_gway_00513 
remap_schema=snox4transnox_cpass:snox4transnox_api_escrow 
remap_schema=transnox_cpass:transnox_iox_escrow 
remap_schema=tnoxpass_gway_00513:tnoxpass_gway_00513_escrow 
remap_schema=snoxpass_gway_00513:snoxpass_gway_00513_escrow 
exclude=grant,synonym

-- All work is performed on the target system. The only reference to the source systems is via the database link. 

-->> COMPRESSION

-- The COMPRESSION parameter allows you to decide what, if anything, you wish to compress in your export. The syntax is shown below.
-- COMPRESSION={ALL | DATA_ONLY | METADATA_ONLY | NONE}

/* The available options are:
    * ALL: Both metadata and data are compressed.
    * DATA_ONLY: Only data is compressed.

    * METADATA_ONLY: Only metadata is compressed. This is the default setting.
    * NONE: Nothing is compressed.
*/

-- Here is an example of the COMPRESSION parameter being used.

expdp test/test schemas=TEST directory=TEST_DIR dumpfile=TEST.dmp logfile=expdpTEST.log

-- compression=all
-- The COMPATIBLE initialization parameter should be set to "11.0.0" or higher to use these options, except for the METADATA_ONLY option, 
-- which is available with a COMPATIBLE setting of "10.2".


-->> PARTITION_OPTIONS

-- The PARTITION_OPTIONS parameter determines how partitions will be handled during export and import operations. The syntax is shown below.
-- PARTITION_OPTIONS={none | departition | merge}

/* The allowable values are:

    * NONE: The partitions are created exactly as they were on the system the export was taken from.
    * DEPARTITION: Each partition and sub-partition is created as a separate table, named using a combination of the table and (sub-)partition name.
    * MERGE: Combines all partitions into a single table.

The NONE and MERGE options are not possible if the export was done using the TRANSPORTABLE parameter with a partition or subpartition filter. 
If there are any grants on objects being departitioned, an error message is generated and the objects are not loaded.
*/
    
-- export the partition options
expdp test/test directory=TEST_DIR  dumpfile=TEST.dmp  logfile=expdpTEST.log  tables=test.tab1  partition_options=merge
expdp test/test directory=TEST_DIR  dumpfile=TEST.dmp  logfile=expdpTEST.log  tables=test.tab1  partition_options=DEPARTITION
expdp test/test directory=TEST_DIR  dumpfile=TEST.dmp  logfile=expdpTEST.log  tables=test.tab1  partition_options=NONE


-- Take the export of muliple partition of the same table but exclude some objects
expdp / 
directory=dpump 
dumpfile=expdp_partition_table.dmp 
logfile=log_partition_table.log 
exclude=statistics,index,grant,object_grant,comment 
tables=('SNOX4TRANSNOX_CPASS."INFONOX_SERVICE_USAGE":SYS_P441', 'SNOX4TRANSNOX_CPASS."INFONOX_SERVICE_USAGE":SYS_P421')
REUSE_DUMPFILES=Y

expdp / 
directory=dpump 
dumpfile=expdp_partition_table.dmp 
logfile=log_partition_table.log 
exclude=statistics,index,grant,object_grant,comment 
tables=SNOX4TRANSNOX_CPASS.INFONOX_SERVICE_USAGE:SYS_P401,SNOX4TRANSNOX_CPASS.INFONOX_SERVICE_USAGE:SYS_P441 
REUSE_DUMPFILES=Y
 
-- import partition table in different non-partition table
impdp rchaudhari 
directory=dpump 
dumpfile=expdp_partition_table.dmp 
logfile=impdp_log_partition_table.log 
remap_schema=snox4transnox_cpass:rchaudhari 
remap_table=infonox_service_usage:infonox1 
partition_options=merge



--- Transending Archiving Example for export/import parition tables

-- Create all par file for future references..

#-- MERCHANTSCOUT_SCORES
directory=ORA11 
dumpfile=expdp_CAP1_MERCHANTSCOUT_SCORES_29Apr2014.dmp 
logfile=logs_expdp_CAP1_MERCHANTSCOUT_SCORES_29Apr2014.log 
exclude=STATISTICS,INDEX,GRANT,OBJECT_GRANT,COMMENT,REF_CONSTRAINT,CONSTRAINT 
TABLES=('TRANSCAPITALONE."MERCHANTSCOUT_SCORES":SYS_P1123','TRANSCAPITALONE."MERCHANTSCOUT_SCORES":SYS_P1183','TRANSCAPITALONE."MERCHANTSCOUT_SCORES":SYS_P1262') 
REUSE_DUMPFILES=Y 
COMPRESSION=ALL

#-- pre_set_transaction_state_log
directory=ORA11 
dumpfile=expdp_CAP1_PRE_SET_XTNS_STATE_LOG_29Apr2014.dmp 
logfile=logs_expdp_CAP1_PRE_SET_XTNS_STATE_LOG_29Apr2014.log 
exclude=STATISTICS,INDEX,GRANT,OBJECT_GRANT,COMMENT,REF_CONSTRAINT,CONSTRAINT 
TABLES=('TRANSCAPITALONE."PRE_SET_TRANSACTION_STATE_LOG":SYS_P1121','TRANSCAPITALONE."PRE_SET_TRANSACTION_STATE_LOG":SYS_P1181','TRANSCAPITALONE."PRE_SET_TRANSACTION_STATE_LOG":SYS_P1241') 
REUSE_DUMPFILES=Y 
COMPRESSION=ALL

#-- settlement_batch_history
directory=ORA11 
dumpfile=expdp_CAP1_SETTLEMENT_BATCH_HIST_29Apr2014.dmp 
logfile=logs_expdp_CAP1_SETTLEMENT_BATCH_HIST_29Apr2014.log 
exclude=STATISTICS,INDEX,GRANT,OBJECT_GRANT,COMMENT,REF_CONSTRAINT,CONSTRAINT 
TABLES=('TRANSCAPITALONE."SETTLEMENT_BATCH_HISTORY":SYS_P1122','TRANSCAPITALONE."SETTLEMENT_BATCH_HISTORY":SYS_P1182','TRANSCAPITALONE."SETTLEMENT_BATCH_HISTORY":SYS_P1261') 
REUSE_DUMPFILES=Y 
COMPRESSION=ALL

#-- transactions_merchantscout_det
directory=ORA11 
dumpfile=expdp_CAP1_XTNS_MERCSC_DET_29Apr2014.dmp 
logfile=logs_expdp_CAP1_XTNS_MERCSC_DET_29Apr2014.log 
exclude=STATISTICS,INDEX,GRANT,OBJECT_GRANT,COMMENT,REF_CONSTRAINT,CONSTRAINT 
TABLES=('TRANSCAPITALONE."TRANSACTIONS_MERCHANTSCOUT_DET":SYS_P1904','TRANSCAPITALONE."TRANSACTIONS_MERCHANTSCOUT_DET":SYS_P1905','TRANSCAPITALONE."TRANSACTIONS_MERCHANTSCOUT_DET":SYS_P1906') 
REUSE_DUMPFILES=Y 
COMPRESSION=ALL

#-- vital_daily_dt_hist
directory=ORA11 
dumpfile=expdp_CAP1_VITAL_DAILY_DT_HIST_29Apr2014.dmp 
logfile=logs_expdp_CAP1_VITAL_DAILY_DT_HIST_29Apr2014.log 
exclude=STATISTICS,INDEX,GRANT,OBJECT_GRANT,COMMENT,REF_CONSTRAINT,CONSTRAINT 
TABLES=('TRANSCAPITALONE."VITAL_DAILY_DT_HIST":SYS_P1141','TRANSCAPITALONE."VITAL_DAILY_DT_HIST":SYS_P1201','TRANSCAPITALONE."VITAL_DAILY_DT_HIST":SYS_P1281') 
REUSE_DUMPFILES=Y 
COMPRESSION=ALL

#-- vital_dt_extention_hist
directory=ORA11 
dumpfile=expdp_CAP1_VITAL_DT_EXTENTN_HIST_29Apr2014.dmp 
logfile=logs_expdp_CAP1_VITAL_DT_EXTENTN_HIST_29Apr2014.log 
exclude=STATISTICS,INDEX,GRANT,OBJECT_GRANT,COMMENT,REF_CONSTRAINT,CONSTRAINT 
TABLES=('TRANSCAPITALONE."VITAL_DT_EXTENTION_HIST":SYS_P1142','TRANSCAPITALONE."VITAL_DT_EXTENTION_HIST":SYS_P1202','TRANSCAPITALONE."VITAL_DT_EXTENTION_HIST":SYS_P1282') 
REUSE_DUMPFILES=Y 
COMPRESSION=ALL

#-- vital_transactions_hist
directory=ORA11 
dumpfile=expdp_CAP1_VITAL_XTNS_HIST_29Apr2014.dmp 
logfile=logs_expdp_CAP1_VITAL_XTNS_HIST_29Apr2014.log 
exclude=STATISTICS,INDEX,GRANT,OBJECT_GRANT,COMMENT,REF_CONSTRAINT,CONSTRAINT 
TABLES=('TRANSCAPITALONE."VITAL_TRANSACTIONS_HIST":SYS_P1161','TRANSCAPITALONE."VITAL_TRANSACTIONS_HIST":SYS_P1221','TRANSCAPITALONE."VITAL_TRANSACTIONS_HIST":SYS_P1301') 
REUSE_DUMPFILES=Y 
COMPRESSION=ALL

#-- xtn_upload_stats
directory=ORA11 
dumpfile=expdp_CAP1_XTN_UPLOAD_STATS_29Apr2014.dmp 
logfile=logs_expdp_CAP1_XTN_UPLOAD_STATS_29Apr2014.log 
exclude=STATISTICS,INDEX,GRANT,OBJECT_GRANT,COMMENT,REF_CONSTRAINT,CONSTRAINT 
TABLES=('TRANSCAPITALONE."XTN_UPLOAD_STATS":SYS_P1864','TRANSCAPITALONE."XTN_UPLOAD_STATS":SYS_P1865','TRANSCAPITALONE."XTN_UPLOAD_STATS":SYS_P1866') 
REUSE_DUMPFILES=Y 
COMPRESSION=ALL


#-- MERCHANTSCOUT_SCORES
SYS_P1123
SYS_P1183
SYS_P1262

#-- pre_set_transaction_state_log
SYS_P1121
SYS_P1181
SYS_P1241

#-- SETTLEMENT_BATCH_HISTORY
SYS_P1122
SYS_P1182
SYS_P1261

#-- transactions_merchantscout_det
SYS_P1904
SYS_P1905
SYS_P1906

#-- vital_daily_dt_hist
SYS_P1141
SYS_P1201
SYS_P1281

#-- vital_dt_extention_hist
SYS_P1142
SYS_P1202
SYS_P1282

#-- vital_transactions_hist
SYS_P1161
SYS_P1221
SYS_P1301

#-- xtn_upload_stats
SYS_P1864
SYS_P1865
SYS_P1866



ALTER TABLE TRANSCAPITALONE.MERCHANTSCOUT_SCORES
  DROP PARTITION SYS_P1123
  UPDATE GLOBAL INDEXES
  PARALLEL 2;

ALTER TABLE TRANSCAPITALONE.MERCHANTSCOUT_SCORES
  DROP PARTITION SYS_P1183
  UPDATE GLOBAL INDEXES
  PARALLEL 2;

ALTER TABLE TRANSCAPITALONE.MERCHANTSCOUT_SCORES
  DROP PARTITION SYS_P1262
  UPDATE GLOBAL INDEXES
  PARALLEL 2;
  


FILE_UPLOAD_DATA_HIST
MERCHANTSCOUT_SCORES
PRE_SET_TRANSACTION_STATE_LOG
SETTLEMENT_BATCH_HISTORY
TRANSACTIONS_MERCHANTSCOUT_DET
VITAL_DAILY_DT_HIST
VITAL_DT_EXTENTION_HIST
VITAL_TRANSACTIONS_HIST
XTN_UPLOAD_STATS


-- import partition table in different non-partition table
impdp rchaudhari directory=ORADATA10 
dumpfile=expdp_CAP1_MERCHANTSCOUT_SCORES_13OCT2013.dmp 
logfile=logs_impdp_CAP1_MERCHANTSCOUT_SCORES_13OCT2013.log  
remap_table=MERCHANTSCOUT_SCORES:MERCHANTSCOUT_SCORES_13OCT2013 






-->> REUSE_DUMPFILES

-- The REUSE_DUMPFILES parameter can be used to prevent errors being issued if the export attempts to write to a dump file that already exists.
-- REUSE_DUMPFILES={Y | N}

-- When set to "Y", any existing dumpfiles will be overwritten. When the default values of "N" is used, an error is issued if the dump file already exists.

expdp test/test schemas=TEST directory=TEST_DIR dumpfile=TEST.dmp logfile=expdpTEST.log reuse_dumpfiles=y



-->> REMAP_TABLE

-- This parameter allows a table to be renamed during the import operations performed using the TRANSPORTABLE method. It can also be used to
-- alter the base table name used during PARTITION_OPTIONS imports. The syntax is shown below.

-- REMAP_TABLE=[schema.]old_tablename[.partition]:new_tablename

-- An example is shown below.

impdp test/test tables=TAB1 directory=TEST_DIR dumpfile=TEST.dmp logfile=impdpTEST.log remap_table=TEST.TAB1:TAB2

-- Existing tables are not renamed, only tables created by the import.


-->> DATA_OPTIONS

--SKIP_CONSTRAINT_ERRORS

-- During import operations using the external table acces method, setting the DATA_OPTIONS parameter to SKIP_CONSTRAINT_ERRORS allows 
-- load operations to continue through non-deferred constraint violations, with any violations logged for future reference. Without this, 
-- the default action would be to roll back the whole operation. The syntax is shown below.

-- DATA_OPTIONS=SKIP_CONSTRAINT_ERRORS

-- An example is shown below.
impdp test/test tables=TAB1 directory=TEST_DIR dumpfile=TEST.dmp logfile=impdpTEST.log data_options=SKIP_CONSTRAINT_ERRORS

/* This parameter has no impact on deferred constraints, which still cause the operation to be rolled back once a violation is detected. 
If the object being loaded has existing unique indexes or constraints, the APPEND hint will not be used, which may adversely affect performance.
XML_CLOBS
During an export, if XMLTYPE columns are currently stored as CLOBs, they will automatically be exported as uncompressed CLOBs. If on 
the other hand they are currently stored as any combination of object-relational, binary or CLOB formats, they will be exported in 
compressed format by default. Setting the DATA_OPTIONS parameter to XML_CLOBS specifies that all XMLTYPE columns should be exported as 
uncompressed CLOBs, regardless of the default action. The syntax is shown below.
*/

-- DATA_OPTIONS=XML_CLOBS

-- An example is shown below.
expdp test/test tables=TAB1 directory=TEST_DIR dumpfile=TEST.dmp logfile=expdpTEST.log version=11.1 data_options=xml_clobs

-- Both the export and import must use the same XML schema and the job version must be set to 11.0.0 or higher.


-->> REMAP_DATA

-- During export and import operations, the REMAP_DATA parameter allows you to associate a remap packaged function that will accept the 
-- column value as a parameter and return a modified version of the data. The syntax is shown below.

-- REMAP_DATA=[schema.]tablename.column_name:[schema.]pkg.function

-- This can be used to mask sensitive data during export and import operations by replacing the original data with random alternatives. 
-- The mapping is done on a column-by-column basis, as shown below.

expdp test/test 
tables=TAB1 
directory=TEST_DIR 
dumpfile=TEST.dmp 
logfile=expdpTEST.log 
remap_data:tab1.col1:remap_pkg.remap_col1 
remap_data:tab1.col2:remap_pkg.remap_col2

-- The remapping function must return the same datatype as the source column and it must not perform a commit or rollback.

--Export Only users with their grants..
Expdp system directory=dpump dumpfile=exp_tsys_employee.dmp logfile=exp_tsys_employee.log include=users,grant schemas=<user list to export>


-->> CONTENT

-- Below e.g. takes the Structural export dump only and not the data from the tables
expdp rahulc@aqprod 
directory=expdp_dir 
dumpfile=exp_bkups_of_gcaSchemas_4_ICP.dmp 
logfile=exp_bkups_of_gcaSchemas_4_ICP.log 
exclude=statistics 
schemas=transnox_gca,snox4transnox_gca,tnoxgca_91x_20101p,snoxgca_91x_20101p,tnoxgca59,snoxgca59 
content=metadata_only 
compression=all


--export the schemas including all objects but not tables objects
expdp rahulc@tempe_parallel 
directory=ora4 
dumpfile=exp_transmoneris_str_bkups.dmp 
logfile=exp_transmoneris_str_bkups.log 
include=function,index,index_partition,materialized_view,package,package_body,procedure,sequence,synonym,trigger,type,view 
schemas=transmoneris


-- Take the Export of Tables and Import them in different schema of other DB
expdp rchaudhari@tempe_22 
directory=dpump 
dumpfile=expdp_load_Details.dmp 
logfile=expdp_load_Details.log 
exclude=statistics,grants 
tables=tnoxgca_91x_20103n4.LOAD_DETAILS


-- Import command which import the table from x schema to Y schema�s table, if the table exists in Y schema then use the option 
-- TABLE_EXISTS_ACTION={SKIP,APPEND,REPLACE,TRUNCATE} to import in same tables it�s like ignore=y from normal export/import command
impdp rchaudhari 
dumpfile=ld_3n4.dmp 
directory=dpump 
logfile=impdp_ld_3n4.log 
tables=load_details 
remap_schema=tnoxgca_91x_20103n4:TNOXGCA_91X_20103 
TABLE_EXISTS_ACTION=append


-- Export of multiple schemas and import only one table from one schema.
expdp / 
directory=ora3 
dumpfile=expdp_QCPW_15Nov2011_QCPWDB62.dmp 
logfile=expdp_QCPW_15Nov2011_QCPWDB62.log 
schemas=acm,checkcash,qcp,qcredit,wumt 
exclude=statistics,table:" like 'SC_TEMP%'",table:" like 'SN_TEMP%'" 
compression=all
 

impdp / directory=qcp62_ora3 
dumpfile=expdp_QCPW_15Nov2011_QCPWDB62.dmp 
logfile=impdp_expdp_QCPW_15Nov2011_QCPWDB62.log  
tables=QCREDIT.RELEASE_HISTORY 
remap_schema=QCREDIT:rchaudhari


-- table the export of the table 
expdp rahulc directory=ora4 dumpfile=expdp_CUSTOMER_FINGUREPRINT.dmp logfile=expdp_CUSTOMER_FINGUREPRINT.log tables=qcp.CUSTOMER_FINGERPRINTS data_options=xml_clobs exclude=statistics,index,ref_constraint,constraint,grant,object_grant,trigger compression=all
 
-- truncate the table and then import it
impdp rchaudhari directory=ORADATA2 dumpfile=expdp_CUSTOMER_FINGUREPRINT.dmp logfile=logs_expdp_telecheck_sign.log TABLE_EXISTS_ACTION=truncate content=data_only

expdp rahulc directory=ora4 dumpfile=expdp_data1.dmp logfile=expdp_data1.log tables=qcp.customer_signatures data_options=XML_CLOBS exclude=statistics,index,ref_constraint,constraint,grant,object_grant,trigger compression=all content=data_only

impdp rchaudhari directory=ORADATA2 dumpfile=expdp_data1.dmp logfile=logs_expdp_data1.log TABLE_EXISTS_ACTION=truncate content=data_only

expdp rahulc directory=ora4 dumpfile=expdp_data2.dmp logfile=expdp_data12.log tables=checkcash.limit_enrollment_response data_options=XML_CLOBS exclude=statistics,index,ref_constraint,constraint,grant,object_grant,trigger compression=all content=data_only

impdp rchaudhari directory=ORADATA2 dumpfile=expdp_data2.dmp logfile=logs_expdp_data2.log TABLE_EXISTS_ACTION=truncate content=data_only



expdp rahulc directory=ORA10 dumpfile=expdp_data4.dmp logfile=expdp_data124.log tables=snox4transnox_oneview.snox_user_access data_options=XML_CLOBS exclude=statistics,index,ref_constraint,constraint,grant,object_grant,trigger compression=all content=data_only




---- tablespace level export
expdp bert/bert directory=data_pump_dir dumpfile=multi_tablespace.dmp tablespaces=users,sysaux


-- Network_Link import example.
-- DB link on importing DB server should be present, like here txnDCW1 is DBLink which is created on txnDCE1 - importing DB server
impdp rchaudhari directory=bkup NETWORK_LINK=txnDCW1 flashback_scn=2096060466 logfile=impdp_NTlink_txnDCW1_txnDCE1.log schemas=transnox_cpass,snox4transnox_cpass,webfort exclude=table:\"like \'SN_TEMP%\'\",statistics


-- Creating New vbs for TransIT DB
expdp rchaudhari directory=bkup dumpfile=expdp_new_vbs_08Mar2015_release.dmp logfile=expdp_new_vbs_08Mar2015_release.log schemas=TRANSIT_GATEWAY_SNOX_316,TRANSIT_GATEWAY_TNOX_316,TRANSIT_FE_SNOX_316,TRANSIT_FE_TNOX_316,TRANSIT_SMSNOX_SNOX_315,TRANSIT_SMSNOX_TNOX_315 exclude=TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\"


-- export the selected transactionids
expdp rchaudhari directory=BKUPS dumpfile=expdp_cust_sign.dmp logfile=expdp_cust_sign_log.log tables=qcp.CUSTOMER_SIGNATURES query=\"where transactionid IN \(\'300283\',\'897098\',\'992043\',\'1559588\',\'1774103\',\'2050258\',\'2936041\',\'3219944\',\'3243896\',\'4650705\',\'6844593\',\'7301975\',\'8749677\',\'8860928\',\'9009792\',\'9598699\',\'9600281\',\'9614545\',\'9616078\',\'9616889\',\'9866422\',\'9871298\',\'9877193\',\'9994409\',\'10262644\',\'10459858\',\'10476630\',\'10586635\',\'10656846\',\'10698516\',\'10749517\',\'10839025\',\'10898043\',\'10899594\',\'10959197\',\'10996111\',\'11176047\',\'11180216\',\'11561230\',\'11561653\',\'11710481\',\'11711240\',\'11711503\',\'11720150\',\'11735567\',\'11862460\',\'12008756\',\'12181719\',\'12189951\',\'12204386\',\'12247412\',\'12256532\',\'12271466\',\'12359546\',\'12386062\',\'12403906\',\'12446770\',\'12491288\',\'12524752\',\'12531560\',\'12564861\',\'12593246\',\'12662850\',\'12678807\',\'12703048\',\'12704055\',\'12709764\',\'12853403\',\'12899304\',\'13049878\',\'13113885\',\'13156073\',\'13170434\',\'13229310\',\'13229829\',\'13264966\',\'13456260\',\'13497928\',\'13500596\',\'13607573\',\'13611337\',\'13615656\',\'13617238\',\'13654372\',\'13761565\',\'13804760\',\'13966105\',\'13966684\',\'13978932\',\'14038170\',\'14070698\',\'14088254\',\'14163381\',\'14386857\',\'14391784\',\'14415779\',\'14428247\',\'14445144\',\'14524988\',\'14567446\',\'14741092\',\'14742041\',\'14783898\',\'14836642\',\'15067498\',\'15069144\',\'15498121\',\'15511487\',\'15548910\',\'15738936\',\'15758209\',\'15922900\',\'16010971\',\'16183385\',\'16221152\',\'16239806\',\'16393081\',\'16460913\',\'16527979\',\'16706587\',\'16708070\',\'16851685\',\'26088799\',\'26176656\',\'26647712\',\'26685105\',\'26944534\',\'27213326\',\'27285890\',\'27355083\',\'28560280\',\'29787471\',\'30220346\',\'30561392\',\'30687462\',\'30892171\',\'31081923\',\'31631615\',\'31770551\',\'33620693\',\'34583124\',\'35255025\',\'36103919\',\'36115290\',\'36585697\',\'36598726\',\'36719386\',\'36867014\',\'36871367\',\'36993684\',\'37074443\',\'141131630\',\'141214627\',\'141409955\',\'141799970\',\'142205236\',\'142326889\',\'142717163\',\'142829582\',\'142910341\',\'142912869\',\'143523932\',\'244936277\',\'245723906\',\'246069808\',\'4246958309\',\'4249345343\',\'4249946376\',\'4249950653\',\'4250021670\',\'4251891814\',\'4650082513\',\'4650152451\',\'4650674263\',\'4650792157\',\'4652483637\',\'4652661852\',\'4654121823\',\'4654181853\',\'4654816056\',\'4654985300\',\'4654999563\',\'4674910640\',\'4676610187\',\'4677086298\',\'4677473048\',\'4677555363\',\'4677805338\',\'4678664930\',\'4678708530\',\'4679436832\',\'4679739818\',\'4680414319\',\'4680656767\',\'4682502633\',\'4683244716\',\'4894337781\',\'4894740527\',\'4895250424\',\'4895684789\',\'4895883301\',\'4896702787\',\'4897229133\',\'4898660869\',\'4900690561\',\'4901060429\',\'4902204274\',\'4903965767\',\'4906622013\',\'6930350138\',\'6931136626\',\'6938714706\',\'6943186734\',\'6949673341\',\'6952281654\'\)\"


expdp rchaudhari@rptdce directory=bkups dumpfile=try_merging_ptables.dmp logfile=try_merging_ptables.log tables=transnox_cpass.TRANS_ADDITIONAL_INFO exclude=index,constraint,REF_CONSTRAINT


-- Take only user's (schemas only) backups
expdp rchaudhari directory=bkup dumpfile=expdp_tsysusers.dmp logfile=expdp_tsysusers.log schemas=adutta,bkupdata,bsager,buchhold,dbaudit,dcurrier,djoshi,dmuley,gpipatanangkura,hyadav,jdecker,jlayani,jpatel,ksingh,leblance,maheshchadare,mbadhe,mchauhan,monideeparoy,nitesha,nmohanty,pgupta,pong,ppadmanabhan,rgadewar,rhalverson,rkanti,romanwar,rraghav,rshiwalkar,rtuscher,sagrawal,sbhamare,schemadiff,sduggirala,sgadewar,sgayam,sgurav,skamble,skumar,skumbhare,ssuryavanshi,uachanta,vchanda,zhongchy include=user,role_grant,grant,object_grant reuse_dumpfiles=y

-- Exlcude one table from the schema backup
expdp rchaudhari directory=ora11 dumpfile=expdp_app_mer_documents_16Feb2016.dmp logfile=impdp_expdp_app_mer_docs_16Feb2016.log schemas=transsigue compression=all exclude=statistics,table:\"=\'APP_MER_DOCUMENTS\'\"

-----------------------------------------------------------------------------------------------------------------
-- Oracle DBMS_DATAPUMP API
-- http://www.morganslibrary.org/reference/pkgs/dbms_datapump.html

-- Add the file to the data pump import/export file set
 
PROCEDURE add_file (
    handle       IN  NUMBER,
    filename     IN  VARCHAR2,
    directory    IN  VARCHAR2 DEFAULT NULL,
    filesize     IN  VARCHAR2 DEFAULT NULL,
    filetype     IN  NUMBER DEFAULT KU$_FILE_TYPE_DUMP_FILE,
    reusefile    IN  NUMBER DEFAULT NULL
  );
 
-- Attach the current database session to a data pump job process
 
FUNCTION attach (
    job_name     IN  VARCHAR2 DEFAULT NULL,
    job_owner    IN  VARCHAR2 DEFAULT NULL
  )
  RETURN NUMBER;
 
-- Permits the specification of data pump job table data filtering
 
PROCEDURE data_filter (
    handle        IN  NUMBER,
    name          IN  VARCHAR2,
    value         IN  NUMBER | CLOB | VARCHAR2,
    table_name    IN  VARCHAR2 DEFAULT NULL,
    schema_name   IN  VARCHAR2 DEFAULT NULL
  );
 
-- Detach the current database session to a data pump job process
 
PROCEDURE detach (
    handle    IN  NUMBER
  );
 
-- Returns the extended data pump file information
 
PROCEDURE get_dumpfile_info (
    filename      IN     VARCHAR2,
    directory     IN     VARCHAR2,
    info_table    OUT    ku$_dumpfile_info,
    filetype      OUT    NUMBER
  );
 
-- Returns the status of a data pump job
 
FUNCTION get_status (
    handle     IN  NUMBER,
    mask       IN  INTEGER,
    timeout    IN  NUMBER DEFAULT NULL
  )
  RETURN ku$_Status;
 
PROCEDURE get_status (
    handle        IN  NUMBER,
    mask          IN  INTEGER,
    timeout       IN  NUMBER DEFAULT NULL,
    job_state     OUT VARCHAR2,
    status        OUT ku$_Status1010 | ku$_Status1020
  );
 
-- Permits the insertion of a message into the log file
 
PROCEDURE log_entry (
    handle          IN  NUMBER,
    message         IN  VARCHAR2,
    log_file_only   IN  NUMBER DEFAULT 0
  );
 
-- Permits the specification of data pump job metadata filtering
 
PROCEDURE metadata_filter (
    handle         IN  NUMBER,
    name           IN  VARCHAR2,
    value          IN  VARCHAR2 | CLOB,
    object_path    IN  VARCHAR2 DEFAULT NULL,
    object_type    IN  VARCHAR2 DEFAULT NULL
  );
  
1. To include or exclude individual named objects (e.g., tables, procedures, etc.) use the NAME_EXPR or NAME_LIST filter along with the object_path parameter:
DBMS_DATAPUMP.METADATA_FILTER(h1,'NAME_EXPR','LIKE PAYROLL%','VIEW');

Result: the only views exported in the job are those with names that begin with �PAYROLL�. (As you might imagine, the filter value �LIKE PAYROLL%� is 
		used in a SQL expression in the query used to fetch the view definitions.) As I mentioned in the earlier post, the object_path parameter �VIEW� 
		will cause the correct dependent objects (grants, etc.) to be included/excluded along with the views.

2. To include or exclude an entire object type, use INCLUDE_PATH_EXPR, EXCLUDE_PATH_EXPR, INCLUDE_PATH_LIST, EXCLUDE_PATH_LIST. For example, if you want to 
   exclude all functions, procedures and packages from the job:

DBMS_DATAPUMP.METADATA_FILTER(h1,'EXCLUDE_PATH_EXPR','IN (''FUNCTION'', ''PROCEDURE'',''PACKAGE'')');

(If you wanted to exclude a particular named procedure you would use the NAME_EXPR filter with the �PROCEDURE� object path.)

One last point: be clear about the difference between INCLUDE and EXCLUDE. If you use an EXCLUDE_PATH_* filter, everything except the object 
types specified by the filter value will be in the job. If you use an INCLUDE_PATH_* filter, only the object types specified by the filter value 
will be in the job.

DBMS_DATAPUMP.METADATA_FILTER(h1,'SCHEMA_EXPR','IN (''HR'')');

or

DBMS_DATAPUMP.METADATA_FILTER(h1,'SCHEMA_LIST','''HR''');
DBMS_DATAPUMP.METADATA_FILTER(h1,'SCHEMA_LIST','''HR''');
DBMS_DATAPUMP.METADATA_FILTER(h1,'SCHEMA_LIST','''HR''');
DBMS_DATAPUMP.METADATA_FILTER(h1,'SCHEMA_LIST','''HR''');
DBMS_DATAPUMP.METADATA_FILTER(h1,'SCHEMA_LIST','''HR''');

-- Permits the specification of data pump job object re-mappings
 
PROCEDURE metadata_remap (
    handle         IN  NUMBER,
    name           IN  VARCHAR2,
    old_value      IN  VARCHAR2,
    value          IN  VARCHAR2,
    object_type    IN  VARCHAR2 DEFAULT NULL
  );
 
-- Permits the specification of data pump job metadata transformations
 
PROCEDURE metadata_transform (
    handle         IN  NUMBER,
    name           IN  VARCHAR2,
    value          IN  VARCHAR2 | NUMBER,
    object_type    IN  VARCHAR2 DEFAULT NULL
  );
 
-- Declares a new data pump job returning handle required for other API calls
 
FUNCTION open (
    operation      IN  VARCHAR2,
    job_mode       IN  VARCHAR2,
    remote_link    IN  VARCHAR2 DEFAULT NULL,
    job_name       IN  VARCHAR2 DEFAULT NULL,
    version        IN  VARCHAR2 DEFAULT 'COMPATIBLE',
    compression    IN  NUMBER DEFAULT KU$_COMPRESS_METADATA
  )
  RETURN NUMBER;
 
-- Permits the specification of data pump job parallelization degree
 
PROCEDURE set_parallel (
    handle     IN  NUMBER,
    degree     IN  NUMBER
  );
 
-- Permits the specification of data pump job-processing options
 
PROCEDURE set_parameter (
    handle     IN  NUMBER,
    name       IN  VARCHAR2,
    value      IN  NUMBER | VARCHAR2
  );
 
-- Begin or resume the execution of a data pump job
 
PROCEDURE start_job (
    handle          IN  NUMBER,
    skip_current    IN  NUMBER DEFAULT 0,
    abort_step      IN  NUMBER DEFAULT 0,
    cluster_ok      IN  NUMBER DEFAULT 1,
    service_name    IN  VARCHAR2 DEFAULT NULL
  );
 
-- Terminate the execution of a data pump job
 
PROCEDURE stop_job (
    handle         IN  NUMBER,
    immediate      IN  NUMBER DEFAULT 0,
    keep_master    IN  NUMBER DEFAULT NULL,
    delay          IN  NUMBER DEFAULT 60
  );
 
-- Runs a data pump job until it completes or aborts
 
PROCEDURE wait_for_job (
    handle        IN  NUMBER,
    job_state     OUT VARCHAR2
  );
 
Here is the command line version of the schema export once again that is the slightly more involved version utilizing PL/SQL API coding as the interface.
 
C:\> expdp bert/bert directory=data_pump_dir dumpfile=multi_schema.dmp schemas=bert,movies
 
DECLARE
  handle NUMBER;
  status VARCHAR2(20);
BEGIN
  handle := DBMS_DATAPUMP.OPEN ('EXPORT', 'SCHEMA');
  DBMS_DATAPUMP.ADD_FILE (handle, 'multi_schema.dmp', 'DATA_PUMP_DIR');
  DBMS_DATAPUMP.METADATA_FILTER (handle, 'SCHEMA_EXPR', 'IN (''BERT'',''MOVIES'')');
  DBMS_DATAPUMP.START_JOB (handle);
  DBMS_DATAPUMP.WAIT_FOR_JOB (handle, status);
END;
/



CONNECT SYSTEM/password

DECLARE
  ind NUMBER;              -- Loop index
  h1 NUMBER;               -- Data Pump job handle
  percent_done NUMBER;     -- Percentage of job complete
  job_state VARCHAR2(30);  -- To keep track of job state
  le ku$_LogEntry;         -- For WIP and error messages
  js ku$_JobStatus;        -- The job status from get_status
  jd ku$_JobDesc;          -- The job description from get_status
  sts ku$_Status;          -- The status object returned by get_status
BEGIN

-- Create a (user-named) Data Pump job to do a "full" import (everything
-- in the dump file without filtering).

  h1 := DBMS_DATAPUMP.OPEN('IMPORT','FULL',NULL,'EXAMPLE2');

-- Specify the single dump file for the job (using the handle just returned)
-- and directory object, which must already be defined and accessible
-- to the user running this procedure. This is the dump file created by
-- the export operation in the first example.

  DBMS_DATAPUMP.ADD_FILE(h1,'example1.dmp','DMPDIR');

-- A metadata remap will map all schema objects from HR to BLAKE.

  DBMS_DATAPUMP.METADATA_REMAP(h1,'REMAP_SCHEMA','HR','BLAKE');

-- If a table already exists in the destination schema, skip it (leave
-- the preexisting table alone). This is the default, but it does not hurt
-- to specify it explicitly.

  DBMS_DATAPUMP.SET_PARAMETER(h1,'TABLE_EXISTS_ACTION','SKIP');

-- Start the job. An exception is returned if something is not set up properly.

  DBMS_DATAPUMP.START_JOB(h1);

-- The import job should now be running. In the following loop, the job is 
-- monitored until it completes. In the meantime, progress information is 
-- displayed. Note: this is identical to the export example.
 
 percent_done := 0;
  job_state := 'UNDEFINED';
  while (job_state != 'COMPLETED') and (job_state != 'STOPPED') loop
    dbms_datapump.get_status(h1,
           dbms_datapump.ku$_status_job_error +
           dbms_datapump.ku$_status_job_status +
           dbms_datapump.ku$_status_wip,-1,job_state,sts);
    js := sts.job_status;

-- If the percentage done changed, display the new value.

     if js.percent_done != percent_done
    then
      dbms_output.put_line('*** Job percent done = ' ||
                           to_char(js.percent_done));
      percent_done := js.percent_done;
    end if;

-- If any work-in-progress (WIP) or Error messages were received for the job,
-- display them.

       if (bitand(sts.mask,dbms_datapump.ku$_status_wip) != 0)
    then
      le := sts.wip;
    else
      if (bitand(sts.mask,dbms_datapump.ku$_status_job_error) != 0)
      then
        le := sts.error;
      else
        le := null;
      end if;
    end if;
    if le is not null
    then
      ind := le.FIRST;
      while ind is not null loop
        dbms_output.put_line(le(ind).LogText);
        ind := le.NEXT(ind);
      end loop;
    end if;
  end loop;

-- Indicate that the job finished and gracefully detach from it. 

  dbms_output.put_line('Job has completed');
  dbms_output.put_line('Final job state = ' || job_state);
  dbms_datapump.detach(h1);
END;
/




-- COMPRESSION
dbms_datapump.set_parameter(handle => l_dp_handle, name => 'COMPRESSION', value => 'ALL');
dbms_datapump.set_parameter(handle => l_dp_handle, name => 'COMPRESSION', value => 'DATA_ONLY');
dbms_datapump.set_parameter(handle => l_dp_handle, name => 'COMPRESSION', value => 'METADATA_ONLY');

-- CONTENT
dbms_datapump.set_parameter(handle => h1, name => 'INCLUDE_METADATA', value => 1); ALL
dbms_datapump.set_parameter(handle => h1, name => 'INCLUDE_METADATA', value => 0); DATA_ONLY
dbms_datapump.data_filter(handle => h1, name => 'INCLUDE_ROWS', value => 0); METADATA_ONLY

-- DATA_OPTIONS
dbms_datapump.set_parameter(handle => l_dp_handle, name => 'DATA_OPTIONS', value => dbms_datapump.KU$_DATAOPT_XMLTYPE_CLOB);

-- EXCLUDE
dbms_datapump.metadata_filter(l_dp_handle, 'SCHEMA_EXPR', '<> (''SCHEMANAME'')');
dbms_datapump.metadata_filter(l_dp_handle, 'EXCLUDE_PATH_EXPR', 'IN (''INDEX'', ''SYNONYMS'', ''GRANTS'', ''STATISTICS'')');

-- INCLUDE
dbms_datapump.metadata_filter(l_dp_handle, 'SCHEMA_EXPR', 'IN (''SCHEMANAME'')');

-- PARALLEL
dbms_datapump.set_parallel(handle => h1, degree => n);

-- REMAP_DATA
dbms_datapump.data_remap(handle => h1, name => 'COLUMN_FUNCTION', table_name => 'TAB1', column => 'COL1', function => 'UWCLASS.TESTPACKAGE.SETTESTID', schema => 'UWCLASS');

-- QUERY
dbms_datapump.data_filter(handle => h1, name => 'SUBQUERY', value => 'WHERE col1 = 1', table_name => null, schema_name => null);

-- REUSE_DUMPFILES
dbms_datapump.add_file(handle => l_dp_handle, filename => 'test.dmp', directory => 'CTEMP', reusefile => 1);

-- SCHEMAS
dbms_datapump.metadata_filter(l_dp_handle, 'SCHEMA_LIST', '''ALIGNE''');

-- TABLES
dbms_datapump.metadata_filter(handle => h1, name => 'NAME_EXPR', value => 'IN (''TEST'',''TEST2'')', object_type => 'TABLE');

-- export create user statement in schema mode (only if datapump_exp_full_database role is granted)
dbms_datapump.set_parameter(handle => h1, name => 'USER_METADATA', value => 1); 

-- don't export create user statement in schema mode
dbms_datapump.set_parameter(handle => h1, name => 'USER_METADATA', value => 0); 

-- INCLUDE_PATH_EXPR and EXCLUDE_PATH_EXPR
Defines which object paths are included in, or excluded from, the job. You use these filters to select only certain object types from 
the database or dump file set. Objects of paths satisfying the condition are included (INCLUDE_PATH_EXPR) or excluded (EXCLUDE_PATH_EXPR) 
from the operation. The object_path parameter is not supported for these filters.

-- REMAP_SCHEMA
OBJECT TYPE = SCHEMA OBJECTS
Any schema object in the job that matches the object_type parameter and was located in the old_value schema will be moved to the value schema.


-----------------------------------------------------------------------------------------------------------------

-- expdp/impdp using PL/SQL
DECLARE
     l_dp_handle           NUMBER;
     l_last_job_state           VARCHAR2(30) := 'UNDEFINED';
     l_job_state           VARCHAR2(30) := 'UNDEFINED';
     l_sts                KU$_STATUS;
     v_file_handle          UTL_FILE.FILE_TYPE;
     v_exists               BOOLEAN;
     v_dbname               VARCHAR2(12);
     v_expfile               VARCHAR2(32);
     v_explog               VARCHAR2(32);
     v_expfile1               VARCHAR2(32);
     v_explog1               VARCHAR2(32);
     v_expfile2               VARCHAR2(32);
     v_explog2               VARCHAR2(32);
     v_length               NUMBER;
     v_blocksize               NUMBER;
     v_jobstate               VARCHAR2(30);
     v_jobstatus               KU$_JOBSTATUS;
     v_status               KU$_STATUS;
     v_scn                    NUMBER;
BEGIN
     SELECT name
INTO v_dbname
     FROM v$database;

     v_expfile := v_dbname||'_exp.dmp';
     v_explog := v_dbname||'_exp.log';
     v_expfile1 := v_dbname||'1_exp.dmp';
     v_explog1 := v_dbname||'1_exp.log';
     v_expfile2 := v_dbname||'2_exp.dmp';
     v_explog2 := v_dbname||'2_exp.log';

     DBMS_OUTPUT.ENABLE(1000000);
     -- See if old file exists and if so rename
     UTL_FILE.FGETATTR('DUMP_FILES',v_expfile1,v_exists, v_length, v_blocksize);
     IF v_exists
     THEN
          dbms_output.put_line('Renaming '||v_expfile1||' to '||v_expfile2);
          UTL_FILE.FRENAME(src_location => 'DUMP_FILES', src_filename => v_expfile1, dest_location => 'DUMP_FILES', dest_filename => v_expfile2, overwrite => TRUE);
          dbms_output.put_line('Renaming '||v_explog1||' to '||v_explog2);
          UTL_FILE.FRENAME(src_location => 'DUMP_FILES', src_filename => v_explog1, dest_location => 'DUMP_FILES', dest_filename => v_explog2, overwrite => TRUE);
          dbms_output.put_line('Files renamed.');
     END IF;
     --Rename current file
     UTL_FILE.FGETATTR('DUMP_FILES',v_expfile,v_exists, v_length, v_blocksize);
     IF v_exists
     THEN
          dbms_output.put_line('Renaming '||v_expfile||' to '||v_expfile1);
          UTL_FILE.FRENAME(src_location => 'DUMP_FILES', src_filename => v_expfile, dest_location => 'DUMP_FILES', dest_filename => v_expfile1, overwrite => TRUE);
          dbms_output.put_line('Renaming '||v_explog||' to '||v_explog1);
          UTL_FILE.FRENAME(src_location => 'DUMP_FILES', src_filename => v_explog, dest_location => 'DUMP_FILES', dest_filename => v_explog1, overwrite => TRUE);
          dbms_output.put_line('Files renamed.');
     END IF;

     --Begin Full export
     dbms_output.put_line('Beginning Export');     
     -- Get current database SCN

     SELECT current_scn
     INTO v_scn
     FROM v$database;

     l_dp_handle := dbms_datapump.open(operation => 'EXPORT',job_mode => 'FULL', remote_link => NULL, job_name =>'NIGHTLY_EXPORT', version => 'LATEST');
     dbms_datapump.add_file(handle => l_dp_handle, filename =>v_expfile, directory => 'DUMP_FILES', filetype => DBMS_DATAPUMP.KU$_FILE_TYPE_DUMP_FILE);
     dbms_datapump.add_file(handle => l_dp_handle, filename =>v_explog, directory => 'DUMP_FILES', filetype => DBMS_DATAPUMP.KU$_FILE_TYPE_LOG_FILE);
     dbms_datapump.set_parameter(handle => l_dp_handle, name => 'FLASHBACK_SCN', value => v_scn); -- Same as running consistent mode in traditional export
     dbms_datapump.start_job(l_dp_handle);
     --Begin loop to determine if job has completed
     v_jobstate := 'UNDEFINED';
     WHILE(v_jobstate != 'COMPLETED') and (v_jobstate != 'STOPPED')
     LOOP
          DBMS_DATAPUMP.GET_STATUS(
               handle => l_dp_handle,
               mask => 15, -- DBMS_DATAPUMP.ku$_status_job_error + DBMS_DATAPUMP.ku$_status_job_stats + DBMS_DATAPUMP.ku$_status_wip
               timeout => NULL,
               job_state => v_jobstate,
               status => v_status
          );
          v_jobstatus := v_status.job_status;
     END LOOP; 

     dbms_output.put_line('Export completed with state: '||v_jobstate);
     dbms_datapump.detach(l_dp_handle);
END;











