******************************************************************************
-- Below are the pre-requisite of the patch
******************************************************************************
https://intercallapac.webex.com/join/pr25567173
ww930\A652766
-- check the hostname of the server where you are applying the patch
hostname
uname -a
cat /etc/oratab
 cat /etc/oraInst.loc
ps -ef|grep pmon
ps -ef|grep tns

-- check the services running on the listeners
lsnrctl status <<listener name which you will get from above ps -ef|grep tns command>>

lsnrctl services lsnrctl status <<listener name which you will get from above ps -ef|grep tns command>>

-- take the version of the current database and applied patches details

IMP=====>
-----if dba_registry stus invalid Run catalog.sql and catupgrade.sql must be run to validating complonant.

sqlplus "/as sysdba"

set sqlprompt "_date':'_user'@'_connect_identifier> "
SET linesize 32000 pagesize 200 
col action_time FOR a28 
col version FOR a10 
col comments FOR a35 
col action FOR a25 
col namespace FOR a12 
SELECT * FROM sys.registry$history order by action_time DESC;
/



set sqlprompt "_date':'_user'@'_connect_identifier> "
SET LINESIZE 400
SET PAGESIZE 100
COLUMN action_time FORMAT A20
COLUMN action FORMAT A10
COLUMN status FORMAT A10
COLUMN description FORMAT A40
COLUMN version FORMAT A10
COLUMN bundle_series FORMAT A10

SELECT TO_CHAR(action_time, 'DD-MON-YYYY HH24:MI:SS') AS action_time,
action,
status,
description,
version,
patch_id,
bundle_series
FROM   sys.dba_registry_sqlpatch
ORDER by action_time ;


--19c 

SELECT description,ACTION,STATUS,TARGET_BUILD_TIMESTAMP from dba_registry_sqlpatch;


col OBJECT_NAME for a20
col OWNER for a15
col LAST_DDL_TIME for a15
col STATUS for a8
select OWNER,OBJECT_ID,OBJECT_NAME,LAST_DDL_TIME,STATUS from dba_objects where status='INVALID';
-- take the information of ASM/Cluster if present
ps -ef |grep pmon
--------select +ASM
. oraenv (+ASM)
crsctl stat res -t


-- take the opatch version
$ORACLE_HOME/OPatch/./opatch version

-- take the lsinventory details
$ORACLE_HOME/OPatch/./opatch lsinventory | grep applied

$ORACLE_HOME/OPatch/./opatch lspatches
-- take the prereq check of the patch to be applied from it's location
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /u03/Patch/JULY2017_PATCH/26031209/26027154

tar -cvf  /appl/oracle/PATCHES/CSMPRD_DB_JUNE_2018.tar /oracle/product/v12102
 du -sh * | sort -hr | head -n10

$ORACLE_HOME/OPatch/./opatch apply

$ORACLE_HOME/OPatch/./datapatch -verbose

@?/rdbms/admin/catbundle.sql psu apply
@?/rdbms/admin/utlrp.sql
opatch apply -skip_subset -skip_duplicate 


$ORACLE_HOME/OPatch/./opatch rollback -id 28432129

28432129


$ORACLE_HOME/jdk/bin/./java -version


/dbb/temp_patch/26635834
windows patch 

Prerequisite check “CheckActiveFilesAndExecutables” failed

Tasklist /m *ora*
taskkill /pid processid_number /F

move source Target 

HP unzip /opt/java6/bin/jar -xvf p29252208_112040_HPUX-IA64.zip 

-- backup the Oracle Home folder if possible for safe purpose (not required but in-case)

-- take the location of the patch folder/directory

****************************************************************************************************
 /opt/app/oracle/product/11.2.0/db_1/OPatch/ocm/bin/emocmrsp -no_banner -output /opt/app/software/ocm.rsp



 $ORACLE_HOME/OPatch/./opatch auto /recovery/oracle/software/q120/30501155 -oh $ORACLE_HOME  -ocmrf $ORACLE_HOME/dbs/ocm.rsp