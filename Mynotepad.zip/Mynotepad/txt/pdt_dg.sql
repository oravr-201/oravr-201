create configuration IMC as primary database is imcpdb1_dxb1r3 connect identifier is IMCPDB1_DXB1R3;

add database  imcpdb1_dxb15j as connect identifier is IMCPDB1_DXB15J  maintained as physical;



edit database imcpdb1_dxb1r3 set property FastStartFailoverTarget = 'imcpdb1_dxb15j' ;



edit database imcpdb1_dxb15j set property FastStartFailoverTarget = 'imcpdb1_dxb1r3' ;

DGMGRL> edit database imcpdb1_dxb1r3 set property staticconnectidentifier='(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = imcprddbbkp1.prodprv.imcnet.oraclevcn.com)(PORT = 1521)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = imcpdb1_dxb15j.prodprv.imcnet.oraclevcn.com) (UR = A)))';
DGMGRL> edit database imcpdb1_dxb15j set property staticconnectidentifier='(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = imcprddbbkp1.prodprv.imcnet.oraclevcn.com)(PORT = 1521)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = imcpdb1_dxb15j.prodprv.imcnet.oraclevcn.com) (UR = A)))';






sqlplus system/PDTdB#dmin21#@"(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = imcprddbbkp1.prodprv.imcnet.oraclevcn.com)(PORT = 1521)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = imcpdb1_dxb15j.prodprv.imcnet.oraclevcn.com) (UR = A)))"



sqlplus system/PDTdB#dmin21#@"(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = imcprddb1.prodprv.imcnet.oraclevcn.com)(PORT = 1521)) (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = imcpdb1_dxb1r3.prodprv.imcnet.oraclevcn.com) (UR = A)))"


dgmgrl -logfile $HOME/observer.log sys/PDTdB#dmin21#@IMCPDB1_DXB1R3 "start observer" &






DGMGRL> edit database imcpdb1_dxb15j set property 'logXptMode'='SYNC';
DGMGRL> edit database imcpdb1_dxb1r3 set property 'logXptMode'='SYNC';
DGMGRL> edit configuration set protection mode as maxavailability;




DGMGRL> switchover to imcpdb1_dxb15j;
DGMGRL> switchover to imcpdb1_dxb1r3;


#connect to standby before failover:

DGMGRL> connect sys/PDTdB#dmin21#@imcpdb1_dxb15j
DGMGRL> failover to imcpdb1_dxb15j
DGMGRL> reinstate database imcpdb1_dxb1r3

#connect to primary before failover:

DGMGRL> connect sys/<sys password>@imcpdb1_dxb1r3
DGMGRL> failover to imcpdb1_dxb1r3
DGMGRL> reinstate database imcpdb1_dxb15j












