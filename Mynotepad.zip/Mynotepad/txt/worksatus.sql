==================================
31-JAN-2018
==================================

Shah, Preksha 06:13
hi
call
?
Connected to Shah, Preksha (preksha.shah@atos.net). 
Shah, Preksha 06:14
Siemens         RE: UC4 Healthcare [UC4V11P dB not available] **memory leak issue       Tue 23-01-2018 20:08    need to raise SR 3-16760649350 
---password not working for upload files 

OT50 || ORA-600 error ||  INC3543476    Mon 29-01-2018 22:13    raised sev 1 SR 3-16753231131 , need to monitor
 ----updated 
 
RE: USARAV197 Issues    Tue 30-01-2018 21:44    Please monitor SR  3-16760024681       
 ----updated---
Re: INC21884564 - CHG138147 : Focus User Access Review - 2018-Q1 (Database) - Update accounts   Tue 30-01-2018 00:38    need to work   
 
IM96053 - Archive Log backup failures
RE: ATF:I8382990  - Allow grantee to use Functions      Sat 27-01-2018 01:09    need to work on it.    
 ---pritam is working on it 
Call with Shah, Preksha (preksha.shah@atos.net) has ended. Duration : 00:05:13 
This conversation is saved in the Conversations tab in Lync and in the Conversation History folder in Outlook.


1.Siemens         RE: UC4 Healthcare [UC4V11P dB not available] **memory leak issue SR 3-16760649350 
2.OT50 || ORA-600 error ||  INC3543476  SR 3-16753231131
3.RE: USARAV197 Issues   3-16760024681     
4.Re: INC21884564 - CHG138147 : Focus User Access Review - 2018-Q1 (Database) - Update accounts  
	---check with sam 
5.RE: ATF:I8382990  - Allow grantee to use Functions  
	----need to work on priory 
6.IM96053 - Archive Log backup failures

Hi ,
	below is work status of 31-JAN-2018 in MS.
	
	
	INC002697714		 REsolve
	INC002700130         REsolve
	INC002701297         REsolve
	INC002701298         REsolve
	INC002701284         REsolve
	INC002701352         REsolve
	INC002701283         REsolve
	INC002701281         REsolve
	INC002701296         REsolve
	INC002701294         REsolve
	INC002701287         REsolve
	INC002700953         REsolve
	INC002701819         REsolve
	INC002700421         REsolve
	INC002700433         REsolve
	INC002700958         REsolve
	INC002700629         REsolve
	
	oralce database instaltion 
	TWE venator patching 
	
	Venator_Pa99word_123


EMEASV466	h108346/h108346	
EMEAAV112	h108346/h108346	
EMEASV459	h108346/h108346	

	

	
	
==================================
3-FEB-2018  193.56.47.20
==================================
	
	
INC002736973
ATF:I8631993
ATF:I8631994
ATF:I8631992
ATF:I8631991
ATF:I8631840
ATF:I8631475
ATF:I8631840	
venator : copy patch below serves  source ( EMEAAV112:/u01/temp_patch)

EMEASV463			
EMEASV464			
EMEASV465				



INC002737353		Resolve
INC002737352        Resolve
INC002688354        Resolve
INC002688342        Resolve
INC002741990        Resolve
INC002742069        Resolve
INC002742067        Resolve
INC002741833        Resolve
INC002741833        Resolve
INC002688348        Resolve
INC002742054        Resolve
INC002742056        Resolve
INC002742358        Resolve
INC002742058        Resolve
INC002741798        Resolve
INC002741868        Resolve
INC002741564        Resolve
INC002741869        Resolve
INC002742535        Resolve
INC002742068        Resolve
INC002742275        Resolve
ATF:I8639799        Resolve
ATF:I8640257        Resolve
ATF:I8640256        Resolve
ATF:I8640255        Resolve
ATF:I8639957        Resolve
ATF:I8639711        Resolve
INC002736973        Resolve
ATF:I8631993        Resolve
ATF:I8631994        Resolve
ATF:I8631992        Resolve
ATF:I8631991        Resolve
ATF:I8631840        Resolve
ATF:I8631475        Resolve
ATF:I8631840        Resolve	
	
	
==================================
6-FEB-2018  193.56.47.20
==================================
	
	
NC002751455	     Vishal		Resolve	
INC002751457	 Vishal		Resolve
INC002751458	 Vishal		Resolve
INC002751460	 Vishal		Resolve
INC002751565	 Vishal		Resolve 
INC002751567	 Vishal		Resolve
INC002751572	 Vishal		Resolve
INC002742169	 Vishal		updated 
INC002752453	 Vishal		need to ask sam
INC002752653	 Vishal		Resolve
INC002752881	 Vishal		Resolve
INC002754121	 Vishal		Resolve
INC002754125	 Vishal		Resolve
INC002754533	 Vishal		Resolve
INC002755225	 Vishal		transfer
INC002755226	 Vishal		transfer
INC002755286	 Vishal		Resolve
INC002755785	 Vishal		Resolve
INC002755931	 Vishal		Resolve
INC002755932	 Vishal		Resolve
INC002756022	 Vishal		Resolve
INC002757787	 Vishal		Resolve
INC002757992	 Vishal		Resolve
INC002758004	 Vishal		Resolve
INC002742878				Resolve
INC002742879				Resolve
INC002742882				Resolve
INC002745989				Resolve
INC002745660				Resolve
INC002757787				Resolve


==================================
8-FEB-2018  193.56.47.20
==================================	 
INC002688346	Vishal	 	 updated
INC002770658	Vishal	 	 Resolve
INC002773164	Vishal	 	 Resolve	 
INC002773166	Vishal	 	 Resolve
INC002774772	Vishal	 	 Resolve
INC002774773	Vishal	 	 Resolve
INC002774775	Vishal	 	 Resolve
INC002775649	Vishal	 	 Resolve
INC002775648	Vishal	 	 Resolve 
INC002775715	Vishal	 	 Resolve
INC002734923	Vishal	 	 Resolve	 
INC002770949	Vishal	 	 Resolve
INC002770976	Vishal	 	 Resolve
INC002763099	Vishal	 	 updated
INC002776206	Vishal	 	 updated
INC002777568	Vishal	 	 Resolve




==================================
9-FEB-2018  193.56.47.20
==================================




INC002787117	 Resolve
INC002787167     Resolve
INC002779352     Resolve
INC002787728     Resolve
INC002788154     Resolve
INC002787261     Resolve
INC002788323     Resolve
                 




==================================
16-FEB-2018 MS 193.56.47.20
==================================

log in 199 server for TWE patching activity to take oracle home backup 


ATF:I8811343		Resolve
INC002846114 		Resolve
INC002846169        Resolve
INC002846845        Resolve
INC002847539		Resolve




==================================
18-FEB-2018 MS 193.56.47.20
==================================
INC002860244
INC002860195
INC002860963


	 
 
==================================
23-FEB-2018 MS 193.56.47.20
==================================	 
ATF:I8828703		Resolve 
ATF:I8828189		Resolve
ATF:I8827035		Resolve
ATF:I8821670		Resolve
ATF:I8818087		MSSQL
ATF:I8818102		MSSQL
ATF:I8817083		MSSQL
ATF:I8812409		Resolve
ATF:I8811716		Resolve
ATF:I8809168		Resolve
ATF:I8808695		MSSQL
ATF:I8791848		MSSQL
ATF:I8789899 **		ASK VIHANG
INC002868803		Resolve 
INC002868461        Resolve 
INC002868156        Resolve 
INC002868235	 	Resolve  





usdxslpplmdb1
usdxslpplmdb1 





==================================
24-FEB-2018 MS 193.56.47.20
==================================

INC002928611		RESOLVE
INC002928479        RESOLVE
INC002928277        RESOLVE
INC002920915        RESOLVE
INC002923664        RESOLVE
INC002922773        RESOLVE
INC002922831        RESOLVE
INC002922129        RESOLVE
INC002920443        RESOLVE
INC002920395        RESOLVE
INC002922164        RESOLVE
INC002922066        RESOLVE
INC002922662        RESOLVE
INC002920445        RESOLVE
INC002926134        RESOLVE

INC002927246	----Transfer
INC002927261        Transfer
INC002927261        Transfer
INC002927090        Transfer


INC002929085		RESOLVE
INC002929038        RESOLVE
INC002929805        RESOLVE






==================================
26-FEB-2018 MS 193.56.47.20
==================================


INC002900696	Vishal		Resolve
INC002936271	Vishal		RESOLVE
INC002936826	Vishal		Resolve
INC002936827	Vishal		Resolve
INC002743028	Vishal		updated
INC002911115	Vishal		Resolve
INC002911847	Vishal		Resolve
INC002493784	Vishal		updated
INC002916922	Vishal		updated
INC002546220	Vishal		updated
INC002685100	Vishal		updated
INC002918227	Vishal		Resolve
INC002919570	Vishal		updated
INC002917631	Vishal
INC002921895	Vishal		Resolve
INC002928654	Vishal		updated

INC002941656				Resolve
INC002941681				Resolve
	

==================================
05-March-2018 MS 193.56.47.20
==================================

INC002999851	Resolve
INC002999998    Resolve
INC003000441    Resolve
INC003000439    Resolve
INC003000470    Resolve
INC003000471    Resolve
INC003000320    Resolve
INC003000319    Resolve
INC003000318    Resolve
INC003000610    Resolve
INC003000604    Resolve
INC003000611    Resolve
INC003000605    Resolve
INC003001145    Resolve

IT-Solutions gmin-india-backupsupport_nongain-backup <gmin-india-backupsupport_nongain-backup@atos.net

[‎08-‎03-‎2018 03:31] Steger, Aymee: 
Vishal - do you know who is on shift right now supporting SQL for Siemens?


nohup mv /oracle/exp1/FOCUSPRF/expdp/expdp_FOCUSPRF_FOCUS_table_02FEB2018_02.dmp /oracle/FOCUSDEV/index1/dump &

                Resolve 
INC003049695	Resolve 
INC003050270    Resolve 
INC003050269    Resolve 
INC003050630    Resolve 
INC003050632    Resolve 
INC003050631    Resolve 
INC003050273    Resolve 
INC003052939    Resolve 
INC003052975    Resolve 
INC003053355    Resolve 
INC003048268    Resolve 
INC003041135    Resolve 
INC003031440    Resolve 
INC003055270    Resolve 
INC003054792    Resolve 
INC003055281    Resolve 
INC003054968    Resolve 
INC003054799    Resolve 
INC003054802    Resolve 
INC003054784    Resolve 
INC003054785    Resolve 
INC003054786    Resolve 
INC003054801    Resolve 
INC003054798    Resolve 
INC003054797    Resolve 
INC003054815-   Resolve 
INC003055271    Resolve 




RKDBHryv12$









==================================
17-March-2018 MS 193.56.47.20
==================================





RE: << Close TWE Changes >> CHG000131149 & CHG000131166 Thu 15-03-2018 04:01Need to check and closed the changes ---- Govind
RE: Ref#INC3763866( DB Parameters update) --- Preksha
RE: IM96053 - Archive Log backup failures Please monitor the space utilization ( refer email from Tushar ) --- Vishal
RE: CHG000156026: Schedule Script on sfvepdb01/02 to Switch the logfile on RAC node --- Vishal
RE: Siemens || OSI request 914551 USGPR00002USRV ---Govind





IM96053 - Archive Log backup failures Please monitor the space utilization

ATF:I9237457	Vishal		Resolve 
ATF:I9236449	Vishal		Resolve
ATF:I9235707	Vishal		Resolve
ATF:I9234938	Vishal		Resolve 
ATF:I9234518	Vishal		RESOLVE
ATF:I9234450	Vishal		RESOLVE
ATF:I9234194 	Vishal		RESOLVE
ATF:I9232287	Vishal		resolve
ATF:I9230749	Vishal		Resolve 
ATF:I9229475	Vishal		
ATF:I9229410	Vishal		Resolve 
ATF:I9228423	Vishal		Transfer 
ATF:I9242002 				Resolve
ATF:I9241041				Resolve


scp /u01/app/oracle/local/sql/switch_onlinelog.sql oracle@sfpepdb02:/u01/app/oracle/local/sql/switch_onlinelog.sql 

##00 00,02,04,06,08,10,12,14,16,18,20,22 * * * /u01/app/oracle/local/scripts/utilities/switch_online_log.sh

pcpepdb01 172.28.2.201
pcpepdb02 172.28.2.202
sfpepdb01 172.29.2.201
sfpepdb02 172.29.2.202

==================================
21-March-2018 MS 193.56.47.20
==================================
INC003151567		Resolve 
INC003150932		Resolve 
INC003126239        Resolve 
INC003124478        Resolve 
INC003151582        Resolve 
INC003141849        Resolve 
INC003141849        Resolve 
INC003141402        Resolve 
INC003141404        Resolve 
INC003141605        Resolve 
INC003152303        Resolve 
INC003152182        Resolve 
INC003141352        Resolve 
INC003142194        Resolve 

==================================
22-March-2018 MS 193.56.47.20
==================================


INC003161509		resolve 
INC003161509        resolve 
INC003162254        resolve 
INC003162171        resolve 
INC003162727        resolve 


==================================
23-March-2018 MS 193.56.47.20
==================================
INC003172167
INC003171957
INC003172966
INC003172825
INC003173573
INC003159173

WO1551193

REQ000003442201 


==================================
25-March-2018 MS 193.56.47.20
==================================

INC003172167	Resolve
INC003171957    Resolve
INC003172966    Resolve
INC003172825    Resolve
INC003173573    Resolve
INC003159173    Resolve
INC003182386	Resolve
INC003182882    Resolve
INC003181519    Resolve
INC003181542    Resolve
INC003183613    Resolve
INC003184151    Resolve
ATF:I9364988    Resolve
ATF:I9365320    Resolve
ATF:I9364987    Resolve
ATF:I9364809    Resolve
ATF:I9166234 	updated
INC003169064 	Resolve
INC003168962    Resolve
INC003168962    Resolve
INC003189884    Resolve
INC003189749    Resolve
INC003149771    Resolve
INC003142720	Resolve
INC003190615    Resolve
INC003191514    Resolve
INC003191261    Resolve
INC003150793    Resolve
MARCO Azmitia de leon
MARCO Azmitia de leon
==================================
2-April-2018 DS 193.56.47.20
=================================
INC003066979	Vishal		monsanto
INC003177006	Vishal		transfer
INC003082611	Vishal
INC003116126	Vishal		transfer
INC003116135	Vishal  	transfer
INC003179212	Vishal		updated
INC003112914	Vishal		updated 
INC003241002	Vishal		updated
INC003257264	Vishal		transfer
INC002725285	Vishal		updated
INC003231158	Vishal		updated
INC003260012	Vishal		transfer
INC003262478	Vishal		resolve
INC003261279	Vishal		transfer
INC003262729	Vishal		Resolve
INC003262820	Vishal		resolve
ATF:I9516016				Resolve
ATF:I9516759                Resolve
ATF:I9516755                Resolve
ATF:I9516755                Resolve
ATF:I9516756                Resolve
ATF:I9516757                Resolve
ATF:I9516758                Resolve
ATF:I9517306                Resolve
ATF:I9517101                Resolve

DWS 2-APril-2018 ( Vishal Bhandwalkar )

RE: INC003241002 : Please swivel IM101203 to the Atos Oracle DBA queue  / HTM : IM101203 : TNS-12535: TNS:operation timed
RE: SMS Patching 2018/04 USTXCA3002VSRV RFC:-C4263676
RE: RE: RE: INC003112914 USARAV199 (DYAMON - ORAMON - ASM_DISKGROUP_USED%) DATA : ALERT : ORAMON-ASM_DISKGROUP_USED% : ASM_DISKGROUP_USED% > 95 (=99.81).type=EXTERN
RE: INC003231158 : UAR Creation for 64614 - New User - Focusprf - 03/26/2018 - Alam, Qamre
RE: Extend Tablespace
RE: FOCUSPRD: Re-Run OPERATIONAL_SCHOOL_ARRIVAL_KPI  (March 28)
RE: Ref#INC3840302(Installation of FTPS certificates in OT50 wallet)
RE: Enable port on usaodba1
NYBC and UNIFY backup report 1 APR 2018
ATOS_FUSION_backup_report 01-APR 2018.
==================================
3-April-2018 DS 193.56.47.20
==================================
INC003066979	Vishal			monsanto
INC003179212	Vishal			need to ask sam 
INC003231158	Vishal			Resolve
INC003241002	Vishal			updated 
INC002725285	Vishal			sam 
INC003112914	Vishal			updated
INC003265356	Vishal			Resolve
INC003270679	Vishal			RESOLVE
INC003270630	Vishal			RESOLVE
INC003267943	Vishal			RESOLVE
INC003271075	Vishal			updated 
ATF:I9525158	Vishal			Resolve
Re: FOCUSPRD: Re-Run OPERATIONAL_SCHOOL_ARRIVAL_KPI (March 28)
RE: INC003241002 : Please swivel IM101203 to the Atos Oracle DBA queue / HTM : IM101203 : TNS-12535: TNS:operation timed
RE: Ref#INC3840302(Installation of FTPS certificates in OT50 wallet)
INC003273824
==================================
4-April-2018 DS 193.56.47.20
==================================

INC003082611	Vishal			updated 
INC003179212	Vishal			updated 
INC003241002	Vishal			updated
INC003271075	Vishal			RESOLVE
INC003112914	Vishal			Resolve
INC003282670	Vishal			Resolve
INC003278819	Vishal			updated
INC003283421	Vishal			Resolve 
	


	
==================================
6-April-2018 MS 
==================================	
INC003112914	Vishal			Resolve
INC003282670	Vishal			Resolve
INC003278819	Vishal			updated
INC003283421	Vishal			Resolve 

RE: FOCUSPRD: Re-Run OPERATIONAL_SCHOOL_ARRIVAL_KPI  (March 28)	
INC003302331 : USCRLVDTOY (DYAMON - ORA - alert_SID) ALERT : ORA-1652: unable to extend temp segment by 4 in tablespace SYSTEM
RE: FGA FOCUS.DAILY_STOP ORA-00600 [kdsgrp1] INC003300609
RE: Export Vendavo Production DB dump


==================================
7-April-2018 MS 
==================================	
INC003082611	Vishal			updated 
INC003179212	Vishal			updated 
INC003241002	Vishal			updated
INC003271075	Vishal			RESOLVE

NAM HO from 07-March-2018 MS
RE: ASC#63 - Linux Linux Quarterly Patching - March 2018 - DB Team
RE: FGA FOCUS.DAILY_STOP ORA-00600 [kdsgrp1] INC003300609
RE: Ref#INC3840302(Installation of FTPS certificates in OT50 wallet)
RE: SDC Unix patching for this cycle
RE: FOCUSPRD: Re-Run OPERATIONAL_SCHOOL_ARRIVAL_KPI  (March 28)

	
==================================
8-April-2018 MS 
==================================
INC003309371		Resolve
INC003315412        Resolve
INC003318743        Resolve
INC003318739        Resolve
INC003319487        Resolve

RE: FGA FOCUS.DAILY_STOP ORA-00600 [kdsgrp1] INC003300609
Weekly Database SYNC check report 08-April-2018
RE: Starting: 2018/04 SPG Linux Patching USLZUA4003QSRV  RFC:-C4263676
RE: SDC Unix patching for this cycle
RE: Starting: 2018/04 SPG Linux Patching USLZUA4003QSRV  RFC:-C4263676
RE: SDC Unix patching for this cycle (Resources) | siemens | DB Stop

=================================
9-April-2018 DS
==================================

INC002725285	Vishal			need to discuss with sam 
INC003179212	Vishal			need to discuss with sam
INC003299780	Vishal			updated working on SR 
INC003300609	Vishal			updated need to ask sam for close 
INC003241002	Vishal			amey is working on it 	
INC003310142	Vishal			Resolve
INC003062558	Vishal			Resolve
INC003062385	Vishal			Resolve 
INC003328901					Resolve 
INC003330455					Resolve 


RE: FGA FOCUS.DAILY_STOP ORA-00600 [kdsgrp1] INC003300609
RE: FOCUSPRD: Re-Run OPERATIONAL_SCHOOL_ARRIVAL_KPI  (March 28)

=================================
15-April-2018 MS
==================================

INC003388376		Resolve 
INC003371541        Resolve 
INC003387437        Resolve 
INC003382877        Resolve 

RE: Tablespace Freespace Avaialibity for SLRT
Weekly Database SYNC check report 14-April-2018

=================================
16-April-2018 MS
==================================

INC003395874 : Need account Unlock
INC003395938 : Need password for user account
INC003392654 : FGPDCPFOCDB01 (DYAMON - ORAMON - TBS-MAX_USED%) AQ : ALERT : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 90 (=90.09)
RE: TWE : APR-2018 DEV 
pracheck TWE DEV
FGA FOCUSPRD GPSC_Data/GPSC_IDX/LRG_DATA  Tablespace Growth Report 


=================================
17-April-2018 MS
==================================

INC003402892		updated 
INC003406899		Resolve
INC003407185        Resolve
INC003407186        Resolve
INC003300805 		updated 
INC003409968		updated 



RE: INC003300805 Huntsman servers as mentioned below are reported having a critical vulnerability : Oracle TNS Poison Vulnerability 
RAC auto patching script : 11g + 12c 
RE: TWE : APR-2018 DEV 



=================================
17-April-2018 MS
==================================


INC003419109		Resolve 
INC003415742        Resolve 
INC003421696        Resolve 
INC003423964        Resolve 
INC003422804        Resolve 
INC003422185        Resolve 
INC003419523        Resolve 
INC003419978        Resolve 
INC003419978        Resolve 
INC003421439        Resolve 
INC003421260        Resolve 
INC003421625        Resolve 
INC003420393		Resolve

INC003415742 : PCVEPDB02 (DYAMON - ORAMON - ASM_DISKGROUP_USED%) PLUSARCH : ALERT : ORAMON-ASM_DISKGROUP_USED% : ASM_DISKGROUP_USED% > 95 (=95.42).type=EXTERN
RE: FOCUS QA Database Refresh (2018-Q2)
=================================
19-April-2018 MS
==================================
@Vishal:-Fw: FOCUS QA Database Refresh (2018-Q2)     								      Tue 17-04-2018 22:07       take help from UNIX Team to expidate space addition change, and start restore
@Vishal:-RE: Regarding the Mobile Audit Log on eProgesa PRD database server               Wed 18-04-2018 21:45       Scheduled for Friday April 20 2AM EDT to 3AM EDT (sfpepdb01, sfpepdb02)
INC003425512 <https://atosglobal.service-now.com/incident.do?sys_id=7faf06e5dba193c474b105e3ca96192c&sysparm_view=>  
INC003386409	Vishal		Resolve			 	 
INC003386408	Vishal	 	Resolve	 
INC003415308	Vishal	 	Resolve	 
INC003402926	Vishal	 	updated 
INC003430440				Resolve
INC003425512 				Resolve
INC003433911				transfer
INC003430177				Resolve 
RE: INC003402429 | USMASOHX001DAT (DYAMON - ORAMON - LISTENER_STATE) CRITICAL : ORAMON-LISTENER_STATE : LISTENER_STATE == 0 (=0.00).no listener found
RE: FGA INC003415308 FOCUS QA Database Refresh (2018-Q2)
RE: INC003428811 | Space requisition on server |
RE: Ashland and Valvoline Access status ( Oracle )*****CID access on Ashland / Valvoline servers 
RE: New DATA PROTECTION TRAINING E - LEARNING LAUNCHED - MANDATORY TRAINING 
RE: CO AHS Local Mandatory Completion Report as on 19-March-2018 -ISA -100 Pending
=================================
24-April-2018 NS
==================================
INC003475213
INC003476568
INC003471821
INC003469212		transfer
INC003470466
RE: FOCUS QA Database Refresh (2018-Q2)
FW: FOCUSPRF Restore......
RE: FOCUS : Restore archive logs 
=================================
28-April-2018 MS
==================================
INC003524430 :USARAV199 (DYAMON - ORAMON - NB) Indexes statistics < 1 month : ALERT : Number of : NB == 0 (=0.00)
INC003525320 : US1EDIP4 (DYAMON - ORAMON - INSTANCE-STATE) CRITICAL : ORAMON-INSTANCE-STATE : INSTANCE-STATE == 0 (=0.00).no Oracle process found;
INC003523894 :USSEA313 (DYAMON - ORAMON - TBS-MAX_USED%) SYSAUX : ALERT : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 98 (=98.01)
INC003526413 :US1EDIP4-ORAINST-ISFTPROD AVAILABILITY CRITICAL 
RE: D&T - FOCUS Oracle DB Profile Request (Activity Report)
INC003524430	Resolve
INC003525320    Resolve
INC003523894    Resolve
INC003526413    Resolve
=================================
29-April-2018 MS
==================================
INC003531559 : NTDEV050-ORAINST-SLRCT AVAILABILITY CRITICAL 
INC003531986 : USCRLVDTOY (DYAMON - ORA - alert_SID) ALERT : ORA-1652: unable to extend temp segment by 4 in tablespace SYSTEM
FGA FOCUSPRD GPSC_Data/GPSC_IDX/LRG_DATA  Tablespace Growth Repor
Weekly Database SYNC check report 29-April-2018
RE: SEI OP17 Alert - uslzua4a0ksrv - OP17 not in sync with standby
RE: Siemens : apply oracle April 2018 security patch for database ot17 on USLZUA4009BSRV server 
RE: CHG000184374 -Approval DownTime
RE: Starting : 2018/04 Meltdown Patching Activity USMLVA4001BSRV RFC:-C4064071
RE: Siemens || Apr 2018 PSU Patching || ATF:C4640943
INC003533736 :testctlm (PROBLEM) CRITICAL: testctlm Filesystem_/oracle/CTRLM/backup Filesystem /oracle/CTRLM/backup use 95% of Diskspace
INC003531986		Resolve
INC003533736        Resolve
INC003531559        Resolve
CHG000184374		updated
=================================
30-April-2018 MS
==================================
INC003538148
INC003539555
INC003540224
INC003549445
INC003550512
RE: Enable port on usaodba1
RE: Extend Tablespace 
RE: D&T - FOCUS Oracle DB Profile Request (Activity Report)
=================================
04-May-2018 NS
==================================
INC003590992
RE: Siemens || Apr 2018 PSU Patching || ATF:C4698554
NYBC patch : pcpepdb01/02
RE: Action Item: Change Manager wants CHG000187132 updated before CAB in 2 hours
INC003596747
INC003593413
=================================
04-May-2018 NS
==================================
RE: FGA Linux quarterly patching - May18   Fri 04-05-2018 12:23  need to stop FOCUS PROD - DB on 6th May 7:30IST                         
CHG000187132  - : we need to apply Bug  security patch for standby databases on server pcpepdb01/02-----------need to get it approve (patch copied )
RE: Ref#INC3840302(Installation of FTPS certificates in OT50 wallet) Thu 26-04-2018 12:06 need to install same certificates on OT17 as on OT50.                     SR 3-17414780521 updated, need to monitor                                   -----------------------monitor SR .
Action Item:  NYBC CMDB database check to our supported databases      Fri 04-05-2018 07:43  need to work                                                    
FW: TWE Apr 2018------------copy patches 
INC003613439

=================================
05-May-2018 NS
==================================
RE: SEI OP17 Alert - uslzua4a0ksrv - OP17 not in sync with standby
RE: SMS Patching 2018/05 USDXSLDPLMDB1 USMLVA3003TSRV USIRVA30020SRV RFC:-C4452555
RE: Siemens : apply oracle April 2018 security patch for database dtp21,ptp21 on USMLVA3006JSRV server
RE: Siemens || Apr 2018 PSU Patching || ATF:C4698554


=================================
06-May-2018 NS
==================================
RE: Siemens || Apr 2018 PSU Patching || ATF:C4698554
RE: Weekly Database SYNC check report 06-May-2018
RE: Huntsman | INC003601783 | uscrlvdtoy  /rman_backupN 90%
RE: Siemens : apply oracle april 2018 security patch for database ptp2 on usdfstptp2 server 


=================================
10-May-2018 MS
==================================
INC003638929			Resolve
INC003632152            Resolve
INC003631990            Resolve
INC003633815            Resolve
INC003639041            updated
INC003640102            Resolve

NAM HO from MS – 10-May-2018
RE: FAILURE: uslzua4a0ksrv: /oracle utilzation too high 100%, error level 85% on Thu May 10 02:00:01 EDT 2018
RE: PRD online backup : Time : 10/05/2018 @ 3:30 AM IST.
INC003627426  : Please rebuild indexes on sysadm.customer_names in PRD4
INC003632152 : EMEASV125 (DYAMON - ORA - alert_SID) ALERT : TNS-12535: TNS:operation timed out

=================================
11-May-2018 MS
==================================

INC003645953		Resolve
INC003644146		RESOLVE
INC003644052		Resolve
INC003644007		Resolve
INC003649460		Resolve

NAM HO from MS – 11-May-2018
RE: TWE Apr 2018
RE: FAILURE: uslzua4a0ksrv: /oracle utilzation too high 92%, error level 85% on Fri May 11 02:00:01 EDT 2018
RE: Siemens : apply oracle April 2018 security patch for databases TCRY,TCRDEV,TCRS01 on CAMISS0144ASRV server
Change CHG000174436   Middleware  support

=================================
12-May-2018 MS
==================================
RE: TWE APR 2018 PROD
RE: patch time 
RE: Project Longhorn: Requesting Assistance with Bringing MySQL Up on USLZUA2009MSRV and Health Check
RE: Project Longhorn: Oracle DBA is Needed to Shutdown MySQL on a Server

=================================
19-May-2018 MS
==================================

RE: Venator TWE : Oracle Resources to be allocated 

=================================
20-May-2018 MS
==================================
RE: Planned Maintenance – UC4 (P40 Job Processing) - Oracle Security Patching - Sunday May 20, 2018
RE: AtosBridge | Siemens | WARNING | IRVING | Applications 1 | UC4 Production Oracle Server (USIRVA3002PSRV) || ATF:I10227886
RE: SPG Patching 2018/05 USLZUA4002USRV & USLZUA4A0MSRV RFC:-C4452551
RE: Weekly Database SYNC check report  20-May-2018
INC003739662 : US1EDIP4-ORAINST-ISFTPROD AVAILABILITY CRITICAL 
INC003736985 : EMEASV125 (DYAMON - ORA - alert_SID) ALERT : TNS-12535: TNS:operation timed out
INC003736974 : EMEASV124 (DYAMON - ORA - alert_SID) ALERT : TNS-12535: TNS:operation timed out
INC003737464 : EMEASV123 (DYAMON - ORA - alert_SID) ALERT : TNS-12535: TNS:operation timed out

=================================
21-May-2018 DS
==================================
INC003751366	Vishal	 	Resolve
INC003751629	Vishal	 	Resolve
INC003751630	Vishal	 	Resolve
INC003751841	Vishal		updated 
ATF:I10175358	Vishal	 	Resolve


RE: I10175358  : Full Schema Export/Import DTP 19 
DATA protection traning :
ATF:I10175358  : Full Schema Export/Import

=================================
22-May-2018 DS
==================================

INC003457746	Vishal	 	updated
INC003458093	Vishal	 	updated
INC003496945	Vishal	 	updated
INC003402926	Vishal	 	updated
INC003751841	Vishal		Resolve 
INC003705271	Vishal		updated	 
INC003747984	Vishal		updated 
INC003759935	Vishal	 	transfer
INC003757861	Vishal	 	Resolve
 RE:  *IMPORTANT* - Mandatory Training   "Ashland Overview" ID 18261
RE: INC003705271 : HTM : IM104892 | OMPP1 OEM Agent is un rechable between  OMPP1@usarav201  and  USARAV103
HTM : IM104892 | OMPP1 OEM Agent is un rechable between  OMPP1@usarav201  and  USARAV103
RE: PROD Certificate Failing now...
=================================
23-May-2018 DS
==================================
INC003769955	Vishal		Resolve
INC003770454	Vishal		Resolve
INC003776036	Vishal		Resolve
INC003777088	Vishal		Resolve
INC003775635	Vishal		Resolve
ATF:P9889741	Vishal		updated 
INC003780514				Resolve
INC003780513				Resolve
ATF:I10245276				Resolve
INC003697153				Resolve
ATF:I10245276  : Shutdown of OP17 for Migration activities 5/25/2018 @8pm
RE: MMSA_IMO89 - USRCH00001FSRV - Filesystem Layout
INC003780513 :USARAV201-ORADB-OMPP1 AVAILABILITY CRITICAL 
RE: please remove the killed session from OS on OP17
RE: PRD online backup : Time : 25/05/2018 @ 3:30 AM IST.
INC003769955 : uscrlvdtoy (PROBLEM) WARNING: uscrlvdtoy Filesystem_/rman_backupN Filesystem /rman_backupN use 90% of Diskspace
RE: INC003697153:HTM : IM104883 : SOX - Intrust Alert
Re: INC003655371:HTM : IM104521 | Sabrix SBX Stage Load failures - USCAVDSAB1/SXBED
=================================
24-May-2018 DS
==================================

ATF:P9889741	Vishal			updated
INC003655371	Vishal			updated 
INC003402926	Vishal			updated
INC003705271	Vishal			updated 
INC003768398	Vishal			updated 
INC003780966	Vishal			Resolve
INC003783423	Vishal			Resolve 

Re: INC003655371:HTM : IM104521 | Sabrix SBX Stage Load failures - USCAVDSAB1/SXBED
RE: MMSA_IMO89 - USRCH00001FSRV - Filesystem Layout
RE: HTM : INC003705271 IM104892 | OMPP1 OEM Agent is un rechable between  OMPP1@usarav201  and  USARAV103
RE: INC003790170  |  bebmspop (PROBLEM) WARNING: bebmspop Filesystem_/export Filesystem /export use 86% of Diskspace
Severity 3          SR 3-17556289311 : ORA-20200: No ASH samples exist for Database/Instance
RE: INC003787253:ussea313 Filesystem_/home Filesystem /home use 90% of Diskspace
=================================
28-May-2018 DS
==================================
INC003824542	RESOLVE
INC003402926	Vishal		updated 
INC003768398	Vishal		updated wait for 1 week for action 
INC003705271	Vishal		updated 
INC003824462	Vishal		not in our scope 
INC003824542	Vishal		Resolve
INC003804013	Vishal		Resolve
INC003822390				Resolve
INC003817601				Resolve

=================================
29-May-2018 DS
==================================

=================================
30-May-2018 DS
==================================


INC003861126		transfer 
INC003856096		Resolve 
INC003856091


=================================
2-june-2018 DS
==================================

INC003883067
INC003883128
ATF:C4925628 		created 
INC003881515
INC003880099
INC003880529

=================================
3-june-2018 DS
==================================

INC003888463
INC003889729
INC003879747
INC003888351
INC003884947

=================================
3-june-2018 DS
=================================
INC003884213		RESOLVE 48B3F30A69CB042A
INC003894748		RESOLVE
INC003897479		RESOLVE
INC003896722		updated 5B6D9E33A857B46A
INC003804013		Resolve
INC003888347
INC003888701

Mumbai$123

h99879 

INC003906765
INC003910302
INC003904404

=================================
9-june-2018 DS
=================================

INC003964003 

=================================
16-june-2018 DS
=================================
INC004043736
INC004024326

RE: SEA Patching 2018/06 USLZUA200KMSRV RFC:-C495976
INC004036138 : USCRLVDTOY (DYAMON - ORAMON - TBS-MAX_USED%) SYSTEM : CRITICAL : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 99 (=101.33)
RE: INC003929386 - PCPEPDB01 (DYAMON - ORAMON - ASM_DISKGROUP_USED%) AUDDATA : ALERT : ORAMON-ASM_DISKGROUP_USED% : ASM_DISKGROUP_USED% > 95 (=95.01).type=EXTERN
RE: Starting: 2018/06 SEA Patching USLZUA200JWSRV RFC:-C4959767   

=================================
17-june-2018 DS
=================================
INC004062755			transfer 
INC004059380			RESOLVE
INC004058860			RESOLVE
INC004058860			RESOLVE
INC004060903			RESOLVE

INC004060903 : USSEA313 (DYAMON - ORAMON - TBS-MAX_USED%) AUTOMIC_DATA : ALERT : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 98 (=98.02)
RE: SMS Patching 2018/06 USDXSLPPLMDB1 USMLVA3003USRV & USIRVA30021SRV RFC:-C4959767 
RE: SMS Patching 2018/06 USDXSLPPLMDB1 USMLVA3003USRV & USIRVA30021SRV RFC:-C4959767   
RE: INC003929386 - PCPEPDB01 (DYAMON - ORAMON - ASM_DISKGROUP_USED%) AUDDATA : ALERT : ORAMON-ASM_DISKGROUP_USED% : ASM_DISKGROUP_USED% > 95 (=95.01).type=EXTERN

=================================
18-june-2018 DS
=================================
RE: SMS Patching 2018/06 USMLVA3003QSRV RFC:-C4959767
RE: SMS Patching 2018/06 USMLVA3003QSRV RFC:-C4959767
RE: Huntsman | INC004021345 | HTM : IM107248 : (OPTOP) Increase table space in EDW DEV

=================================
19-june-2018 DS
=================================

INC004079259   RESOLVE
INC004086907   RESOLVE
INC004087774   RESOLVE

INC004086907 : BEBMA892 (DYAMON - ORAMON - TBS-MAX_USED%) EDW_IND_LG : ALERT : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 98 (=98.07)
INC004087774 : BEBMA892 (DYAMON - ORAMON - TBS-MAX_USED%) EDW_IND_LG : CRITICAL : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 99 (=99.
RE: INC004085869  |  emeasv163 (PROBLEM) WARNING: emeasv163 Filesystem_/bca Filesystem /bca use 85% of Diskspace
RE: ACTION FOR YOU: Complete ALL mandatory Monsanto training ( Oracle )
=================================
20-june-2018 DS
=================================

INC004091147	RESOLVE
INC004085281	RESOLVE
INC004085282    RESOLVE
INC004085480    RESOLVE
INC004102243    RESOLVE
INC004102242	RESOLVE
			
ACTION REQUIRED:  Ticket dump for Huntsman	--- need to Give update before 6:30 pm IMP

=================================
22-june-2018 MS
=================================

INC004115433		Resolve
INC004115380		Transfer
INC004104226		Resolve
INC004115858		RESOLVE
INC004116609		Resolve

INC004115433 : CEAIX02-ORAINST-LBPA AVAILABILITY CRITICAL 
INC004115858 : EMEAAV258 (DYAMON - ORA - alert_SID) ALERT : TNS-12535: TNS:operation timed out
RE: [dl-na-ashvalv-oraclesupport] EM Incident: Critical:New: - 99% of archive area /oracle/VPD/oraarch/ is used.
RE: Request for Support Resources for Project Longhorn WAVE 33.JUN22
RE: INC004103263-EMEAAV500.dom01.local (PROBLEM) WARNING: EMEAAV500.dom01.local Filesystem_D: Filesystem D: use 85% of Diskspace
RE: Database Tablespace report for NJCAPRD

=================================
22-june-2018 MS
=================================
INC004126200		Resolve
INC004123938		Resolve
INC004119841		Resolve
INC004125643		Resolve

RE: INC004126067: beevssd1 CPU CRITICAL: CPU usage = 100%
INC004123938 :uscrlvdtoy (PROBLEM) WARNING: uscrlvdtoy Filesystem_/rman_backupN Filesystem /rman_backupN use 90% of Diskspace
Re: FOCUS non-production database (FOCUSPRF) data purge - June 22
RE: ASC#63 - Linux Quarterly Patching - June 2018
	
=================================
27-june-2018 MS
=================================
ATF:I10754317 	Resolve 
ATF:I10689768	Updated 

ATF:I10754317 : USLZUA200KMSRV (DYAMON - ORAMON - TBS-MAX_USED%) DWMERGE_DATA : ALERT : Used space % relative to max size of tablespace : TBS...
RE: ATF:I10689768  myIT Ticket INC4320146: apply changes to TDMS Oracle QA database TDMSX

=================================
28-june-2018 MS
=================================
INC004177982			Transfer
INC004178268			Resolve 
INC004177903			Resolve 
INC004179317			Resolve 

RE: INC004165013 - INC000002661169  FW: Monsanto INC004164232 2 - High opened and assigned to ZZ.Database.Oracle
INC004177903 : CEAIX02-ORAINST-LBPA AVAILABILITY CRITICAL 
RE: CSMB CSMS00065-CSMPRD Apply Apr 2018 Oracle Combo Patch
RE: RF531498 - EDW Table Migration

=================================
29-june-2018 MS
=================================

INC004190444		Resolve
INC004191148		TRANSFER

RE: [dl-na-ashvalv-oraclesupport] CHG000212185 

=================================
30-june-2018 MS
=================================

INC004201654		Transfer 
INC004201593		Transfer
INC004199567		Transfer
INC004201844		Resolve 
INC004201026		Resolve 
INC004202810		Resolve 

RE: Weekend Activity | NAM + Mirror + Monsanto
RE: TDMS:2.1_Heads Up_Help Needed to run the DB script INC4373622.
RE: PRD online backup : Time : 30/06/2018 @ 3:30 AM IST.
RE: Siemens : apply oracle April 2018 security patch for database oup on server USMLVA30042SRV
INC004201026 : USSEA313 (DYAMON - ORAMON - TBS-MAX_USED%) SYSAUX : ALERT : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 98 (=98.07)

=================================
1-july-2018 MS
=================================

INC004203870		updated 
INC004204282 		Resolve 
INC004209717		updated 
INC004210390
INC004210657

INC004204282 : CEAIX02-ORAINST-LBPA AVAILABILITY CRITICAL
RE: RE: ORADEV02 AIX Patching 2018/06 Meltdown Activity RFC:
RE: Weekly Database SYNC check report 1-July-2018.
RE: Starting: 2018/06 mlvvul3u MOE1A6   AIX Meltdown Activity-
RE: TDMS:2.1_Heads Up_Help Needed to run the DB script INC4373622.
RE: siebeldev AIX Patching 2018/06 Meltdown Activity RFC:-
RE: CSMB CSMS00065-Apply Apr 2018 Oracle Combo PatchCSMPRD  (ATF:C5032292  )
INC004210390 : testctlm (PROBLEM) CRITICAL: testctlm Filesystem_/oracle/CTRLM/backup Filesystem /oracle/CTRLM/backup use 95% of Diskspace

=================================
12-july-2018 DS
=================================
ATF:I10975062	Vishal			Updated 		MSSQL 
ATF:I10974889	Vishal			Resolve 		Ts increased 
ATF:I10934378	Vishal			updated 		servermanagment 
ATF:I10915788	Vishal			Resolve 		housekeep done 

=================================
13-july-2018 DS
=================================
INC004341718		Updated 		Transfer to SAP
INC004338841		Resolve 		House keep done 
INC004340283		Resolve 		Workdone on archivelog issue 
INC004340750		Resolve 		workdone on file creattion (arch)
INC004341812		Updated 		Transfer to SAP
INC004341810		Updated			Transfer to SAP
INC004342034		Resolve 		workdone on file creattion (arch)
INC004341808		Updated 		Transfer to SAP	
INC004340289		Resolve 		workdone on file creattion (arch)
INC004340290		Resolve 		Housekeep done 
INC004342791		Updated 		Transfer to SAP


NAM BACKUP REPORT till 12th July 2018
RE: Vendavo SII QA DB Issue 
RE: SEA Patching 2018/07 USLZUA200KMSRV RFC:-C5202179
RE: SEA Patching 2018/07 USLZUA200JWSRV RFC:-C5202179 

=================================
16-july-2018 MS
=================================

INC004361814		Resolve
INC004361821		Resolve
INC004361927		Resolve
INC004364037		Resolve 

RE: APEX Dev Env. DOWN - INC4472398
INC004364037 : testctlm (PROBLEM) WARNING: testctlm Filesystem_/oracle/CTRLM/backup Filesystem /oracle/CTRLM/backup use 92% of Diskspace

=================================
17-july-2018 MS
=================================
INC004374153		Resolve 		backup done 
INC004374203		Resolve 		housekeep done 

RE: Inputs required for /dba,/dbb,/bca
RE: USFLAF0PV3ASRV : not able to log in 
RE: AtosBridge | Siemens | WARNING | FLANDERS | Applications 1 | Windchill 11.0 app (USFLAF0PV3ASRV) | ATF:I11003791
RE: IM508409 - Access issue in EDW Database
RE: AtosBridge | Siemens | WARNING | FLANDERS | Applications 1 | Windchill 11.0 app (USFLAF0PV3ASRV) | ATF:I11003791
RE: Please fill in "Quality Quiz-NAM"

=================================
18-july-2018 MS
=================================


ATF:I11055676			Vihang 		Missing update authorization in Oracle
INC004383710			Resolve 
RE: Prepare your calendar for TWE VNTR 
Z003S40T:CERT/IPINS: (TEST) "Activity  : “VENDAVO” schema refresh from “ OP56 on USLZUA4003QSRV “ to  “ VNPSPGPR on sn1D9001 “ . 
RE: INC4487937 - DB dump export and import"

=================================
19-july-2018 MS
=================================

INC004397430	resolve 
INC004397790	Resolve 
INC004387913	Resolve
INC004398839    Resolve
                
INC004397430 : CEAIX02-ORAINST-LBPA AVAILABILITY CRITICAL 
HMT : TWE prechecks  backup clean-up July 2018
ctmprdb8 : ctrlm  home backup 

=================================
20-july-2018 NS
================================

RE: Huntsman :STOP Monitoring for Database UCMP1,MPBE,AVAR1 on server USARAV201
RE: CHG146104: FOCUS production database (FOCUSPRD) data purge - July 20



=================================
23-july-2018 MS
================================
INC004422846			Resolve 
INC004422845            Resolve 
INC004422844            Resolve 
INC004422843            Resolve 
INC004422841            Resolve 
INC004422840            Resolve 
ATF:I11118061           transfer 
INC004433461 			Resolve
INC004433388            Resolve
INC004434025            Resolve
INC004434032            Resolve
INC004434932            Resolve
INC004433524            Resolve
INC004433452            Resolve
INC004433976            Resolve
INC004433979            Resolve
INC004433445            Resolve
INC004433456            Resolve
INC004435478            Resolve
INC004435489            Resolve
INC004435589            Resolve



RE: CHG146104: FOCUS production database (FOCUSPRD) data purge - July 20
RE: TWE : huntsman DEV servers Aug 2018 
FW: First Draft Master TWE Release Plan - C78005
RE: HMT : TWE prechecks  backup clean-up July 2018
RE: Confirm APEX on bebma891 is running
RE: Extend tablespace 



=================================
24-july-2018 MS
================================
RE: HMT : TWE prechecks  backup clean-up July 2018




=================================
26-july-2018 DS
================================
TASK000993941	Vishal	 		server confiured in OEM
TASK001000831	Vishal	 		server confiured in OEM
CHG000213114	Vishal	 		Change has been scheduled on 2018-07-30 05:30:00 (IST)
CHG000213115	Vishal	 		need to ping tabatha and close this change 
CHG000213118	Vishal	 		Change has been scheduled on 2018-08-18 22:00:00(IST)
CHG000222484	Vishal	 		need to ask Kumar singh 

RE: INC004462181----CEAIX02 (DYAMON - RMAN - END-STATUS) DB INCR TO SBT_TAPE : ALERT : Final status : END-STATUS == ALERT (=ALERT).FAILED
RE: RITM000601997  : Add the following three server BEEVSDWQ, BEBMA664  and  BEEVSCO to Oracle Enterprise Manager on usarav103
ATF:I11152637 : please create QA instance of database STAGESDB on server 10.80.100.103 
RE: FOCUSPRF: CintraSnap_v17.1
RE: NYBC ticket
DB COUNT TWE
RE:  Ticket and Changes need Update 26July2018 DS
NAM HO from 26 July -2018 DS
 
=================================
28-july-2018 NS
================================
INC004498074		Resolve 
INC004498044        Resolve 
INC004498963        Resolve 
INC004498993        Resolve 
INC004498988		Resolve 

RE: SP_FOCUS_DATA_PURGE_ONCE: NOTE: 4 (Loop 108) - END
RE: Not able to connect to Jump hosts  155.45.72.115 / 116
RE:  SPG Unix Patching 2018/07 USLZUA4009BSRV RFC:-C5202179
NAM HO from 28 July -2018 NS


=================================
29-july-2018 NS
================================

INC004501266		Resolve 
INC004460051        Resolve 
INC004460051        Resolve 
INC004504273		transfer
INC004505140		transfer
INC004505139        transfer
INC004505137        transfer
INC004505138        transfer

RE: TWE : huntsman QA servers Aug 2018 
RAC auto patching script : 11g 
RE: TWE : huntsman QA servers Aug 2018 
NAM HO from 29 July -2018 NS
=================================
30-july-2018 NS
================================
RE: INC4563220 

RE: Reg : ATF:I11230117
RE: INC4563220 
RE: TWE : huntsman QA servers Aug 2018 
RE: AtosBridge | Siemens | WARNING | DX DIRECT RD | Applications 1 | Oracle DB Server for Available Instruments Promise Global Database(USMLVA3006JSRV)  || ATF:I11212012 

=================================
31-july-2018 NS
================================


INC004529727		updated 		transfer 
INC004530849		updated 		transfer
INC004529578		Resolve 		housekeep done
INC004529178		resolve 		TS increased 
ATF:I11233848		Transfer to sap
ATF:I11232507		Transfer to service desk
ATF:I11232006		Resolve 
ATF:I11220137	
ATF:I11212012		Resolve 

RE: FGA FOCUSPRD hot/log/logdel backup Jul 27 - 28, 2018 restore request to FOCUSPRF Performance
RE:  SMS Patching 2018/08 USDXSLPRMAN1 & USDXSLPRMAN2 RFC:-C5202179 
RE: INC4563220 
INC004529178:BEEVSDWQ (DYAMON - ORAMON - TBS-MAX_USED%) ATLI01 : ALERT : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 98 (=98.10)
RE: SMS Patching 2018/08 USMLVA3006JSRV RFC:-C5202179 
RE: SPG Patching 2018/08 USLZUA4003QSRV RFC:-C5202179 
RE: FGA FOCUSPRD hot/log/logdel backup Jul 27 - 28, 2018 restore request to FOCUSPRF Performance ( Ticket no -  INC004518115 )
 NAM HO from 31 July -2018 NS

=================================
1-Aug-2018 NS
================================

INC004534032			REsolve 

RE: FGA FOCUSPRD hot/log/logdel backup Jul 27 - 28, 2018 restore request to FOCUSPRF Performance ( Ticket no -  INC004518115 )
RE: Siemens : apply oracle July 2018 security patch for databases eqtest,tctest on USGPR00002USRV  server

=================================
4-Aug-2018 MS
================================

INC004572519		Resolve 

RE: Siemens : apply oracle July 2018 security patch for database dtp29 on USMLVA3003QSRVserver 
RE: Siemens : apply oracle July 2018 security patch for database dtp19,+ ASM on USIRVA30020SRV 
RE: Siemens : apply oracle July 2018 security patch for database dtp19,+ ASM on usdxsldplmdb1 server 
INC004572519 : BEEVSDWP (DYAMON - ORAMON - TBS-MAX_USED%) ATLI01 : ALERT : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 98 (=98.01)
RE: DBA SharePoint Space
RE: CRITICAL: Filesystem_/oracle Filesystem /oracle use 90% of Diskspace
RE: Energy Patching 2018/08 USRCH00001FSRV RFC:-C5202179
RE: Siemens : apply oracle July 2018 security patch for database dtp29 on USMLVA3003QSRVserver 
RE: Weekend Activity | NAM + Mirror + Monsanto



=================================
5-Aug-2018 MS
================================

INC004585313			Resolve


RE: Siemens : apply oracle July 2018 security patch for database ptp2 on usdfstptp2 server 
Weekly Database SYNC check report 05 Aug 2018
RE: Siemens : apply oracle July 2018 security patch for database dtp19,+ ASM on USIRVA30020SRV server 
RE: Siemens : apply oracle July 2018 security patch for database dtp19,+ ASM on USIRVA30020SRV server 
RE: Weekend Activity | NAM + Mirror + Monsanto

=================================
6-Aug-2018 MS
================================
INC004588677		REsolve 
INC004588676        REsolve 
INC004589586        REsolve 
INC004590100        REsolve 
INC004584463        REsolve 
INC004563032        REsolve 
INC004563032        REsolve

usirva3008qn01 not able to connect  : patching 
RE: Weekend Activity | NAM + Mirror + Monsanto
RE: Backup failure on usaodba1.arl.us.ao-srv.com ; ref#INC004590896 
RE: SMS Patching 2018/08 USTXCA3002VSRV RFC:-C5202179 
=================================
7-Aug-2018 MS
================================
 ATF:I11330667 		Resolve 
 INC004606186		Resolve 
 INC004605345		Resolve 
 INC004605125		Resolve 
 INC004606404		REsolve 
 INC004603266		REsolve 
 
RE: MPP - H2 -2018 - Target to complete by 31st Aug18
RE: IM111225 - tablespace error
=================================
8-Aug-2018 MS
================================
INC004614389		REsolve
INC004606213 		Resolve  
INC004605662		Resolve 

RE: Atos Bridge| Siemens | WARNING | IRVING | Applications 1 | UC4 Test Oracle Server (usirva3002usrv) || ATF:I11345911
INC004606213 : uscavdsab1.int.huntsman.com (PROBLEM) WARNING: uscavdsab1.int.huntsman.com Filesystem_/home Filesystem /home use 90% of 
INC004614389 :uscrlvdtoy (PROBLEM) WARNING: uscrlvdtoy Filesystem_/rman_backupN Filesystem /rman_backupN use 90% of Diskspace
RE: Venator Production  TWE on 11-Aug-2018




=================================
11-Aug-2018 MS
================================
INC004666037		Transfer 
INC004666957        Transfer 
INC004666120        Transfer 
INC004666879        Transfer 

INC004665709		Resolve 
INC004666777		Resolve
INC004666594        Resolve
INC004666465        Resolve
INC004666406        Resolve
INC004666405        Resolve
INC004666404        Resolve
INC004666403        Resolve
INC004666383        Resolve
INC004666376        Resolve
INC004666374        Resolve
INC004666359        Resolve
INC004666355        Resolve
INC004666263        Resolve
INC004666260        Resolve
INC004666252        Resolve
INC004666246        Resolve
INC004666230        Resolve
INC004666137        Resolve
INC004666095        Resolve
INC004666084        Resolve
INC004666083        Resolve
INC004666082        Resolve
INC004666081        Resolve
INC004665967        Resolve
INC004665940        Resolve
INC004665930        Resolve
INC004665920        Resolve
INC004665881        Resolve
INC004665880        Resolve
INC004665843        Resolve
INC004665842        Resolve
INC004665840        Resolve
INC004665839        Resolve
INC004665838        Resolve
INC004665837        Resolve
INC004665836        Resolve
INC004665835        Resolve
INC004665834        Resolve
INC004665831        Resolve
INC004665830        Resolve
INC004665829        Resolve
INC004665782        Resolve
INC004665781        Resolve
INC004665780        Resolve
INC004665779        Resolve
INC004665762        Resolve
INC004665761        Resolve
INC004665760        Resolve
INC004665758        Resolve
INC004665755        Resolve


RE: Venator | Aug TWE - DB PROD 
RE: SEA Patching 2018/08 USLZUA200J7SRV RFC:-C5202179 
RE: Weekend Activity | NAM + Mirror + Monsanto
RE: Siemens : apply oracle July 2018 security patch for databases ptp19, + ASM on usdxslpplmdb1 server 
RE: Siemens : apply oracle July 2018 security patch for databases ptp19, + ASM on USIRVA30021SRV server 



=================================
12-Aug-2018 MS
================================
INC004672787		
INC004672761
INC004672760
INC004669707
INC004669712
INC004669737
INC004669738


RE: Weekend Activity | NAM + Mirror + Monsanto
RE: Siemens : apply oracle July 2018 security patch for databases WINHYPDEV,dmsmdev,Dwhsdev,Dwstdev,Wfdev,Hypdev on Uslzua200j7srv server 
RE: Siemens : apply oracle July 2018 security patch for databases WINHYPDEV,dmsmdev,Dwhsdev,Dwstdev,Wfdev,Hypdev on Uslzua200j7srv server 
RE: SPG Patching 2018/08 USLZUA4003QSRV RFC:-C5202179 
 Weekly Database SYNC check report 12 Aug 2018	


=================================
13-Aug-2018 MS
================================
INC004674121		Resolve
INC004666569		updated 

RE: Siemens : apply oracle July 2018 security patch for databases slb801, +ASM on USTXCA3002VSRV  server
RE: Siemens : apply oracle July 2018 security patch for databases slb801, +ASM on USTXCA3002VSRV  server
RE: Weekend Activity | NAM + Mirror + Monsanto

=================================
15-Aug-2018 MS
================================
INC004707226			Transfer 


RE: Action Item: URGENT: Oracle warns of CVE-2018-3110 Critical Vulnerability in Oracle Database product, patch it now! CVSS score of 9.9
HTM : TWE prechecks  backup clean-up Aug 2018 -PROD

=================================
16-Aug-2018 MS
================================
INC004714793		Resolve 
INC004714487        Resolve 
ATF:I11453405       Resolve 

ATF:I11453405 : USLZUA4003QSRV (DYAMON - ORAMON - TBS-MAX_USED%) VDV_DATA : CRITICAL : Used space % relative to max size of tablespace : TBS-...
RE: usaodba1: aorman12: Quarterly Combo PSU July-2018 + OJVM, RMAN catalog database Aug 16, 2018 8 am – 11am CDT CHG000232179
RE: NAM Overdue CHANGE Report - 15th Aug 2018


=================================
17-Aug-2018 MS
================================
INC004731093	Resolve	
INC004731090	Resolve
INC004733248	Resolve 
INC004732926	Resolve 
INC004732924	Resolve 
INC004732054	Resolve 
INC004732055	Resolve 
INC004731832	Resolve 
INC004731900	Resolve 
INC004731788	Resolve 
INC004731090	Resolve 
INC004731403	Resolve 
ATF:I11432577 	mail droped to user updated  
ATF:I11435459 	transfer 
ATF:I11466685	Resolve 
INC004730733	Resolve

RE: HTM : TWE prechecks  backup clean-up Aug 2018 -PROD
prechecks Monsanto
ATF:I11432577DB objects

=================================
18-Aug-2018 MS
================================
RE: || Huntsman || P1 RMAN backups not initiating in all Oracle servers
RE: HTM | TWE PROD | DB servers Aug-2018
RE: FGA - Hitachi to EMC storage migration - CHG000236109
RE: TWE prod 


=================================
20-Aug-2018 DS
================================
INC004745749		Resolve 
INC004745746        Resolve 
INC004753303        Resolve 
INC004740539        Resolve 
INC004753278        Resolve 
INC004743651        Resolve 
INC004739368        Resolve 
INC004745748        Resolve 
INC004743651        Resolve 

Re:  || Huntsman || INC004747030 RMAN backups not initiating in all Oracle servers
FW: Huntsman : Daily Full & INCR Database backup Report for Non-SAP databases
RE: Database Health Checks
RE: TASK001030690(SNOW)/REQ000591078 --- Create two Informatica Databases in the Oracle 12c ServersServer USCAAV285/USARAV286 is ready need to start working on it


================================
28-Aug-2018 NS
================================
TASK001076719 		Resolve 
INC004856999		Resolve 
INC004858720		Resolve

INC004856999 :BEEVSDWP (DYAMON - ORAMON - TBS-MAX_USED%) ADMI01 : ALERT : ORAMON-TBS-MAX_USED% : TBS-MAX_USED% > 98 (=98.01)
RE: Oracle Details
NAM HO from 28 Aug -2018 NS

===============================
29-Aug-2018 NS
===============================

 NAM HO from 29Aug -2018 NS
 RE: ATF:I11624764 | SIEMENS | Database server issue at sites ,running out of space and unable to extend table size 
 backup NAM

===============================
30-Aug-2018 NS
===============================
INC004884012		Resolve 
RE: TASK001030690(SNOW)/REQ000591078 --- Create two Informatica Databases in the Oracle 12c Servers

===============================
31-Aug-2018 NS
===============================
INC004884012	Resolve

RE: FAILURE: usdxsldplmdb1.ww005.siemens.net: /u01 utilzation too high 82%, error level 80% on Fri Aug 31 16:00:01 EDT 2018
RE: FOCUSPRF: Full Database Export (Aug 31, 2018) : INC004898989
RE: NAM HO from 31 Aug -2018 NS

===============================
1-Sep-2018 NS
===============================
NAM HO from 1 sep  -2018 NS
RE: Weekend Activity | NAM + Mirror + Monsanto
RE: Siemens : apply oracle July 2018 security patch for databases TDMSX,TDMST,TDMSD,CDB1,ACWT,ARRET on MOE1A5  server 
RE: SMS Patching 2018/09 USDXSLDPLMDB1 USMLVA3003TSRV USIRVA30020SRV RFC:-C5455149

===============================
2-Sep-2018 DS
===============================
INC004902422	Resolve 
INC004900155    Resolve 
INC004913648    Resolve 
INC004898989	Resolve

NAM HO from 2 SEP  -2018 DS
RE: fOCUS PRD/QA ACCESS - logon failed
RE: Weekend Activity | NAM + Mirror + Monsanto
RE: Siemens : apply oracle July 2018 security patch for databases EQPROD,TCPROD on USGPR00002QSRV server
ATF:I11665733 : USLZUA200KMSRV (DYAMON - ORAMON - TBS-MAX_USED%) DWHIST_DATA : ALERT : Used space % relative to max size of tablesp

===============================
3-Sep-2018 DS
===============================
INC004871806	Vishal		Resolve 
INC004873153	Vishal		Resolve 
INC004877182	Vishal
INC004886942	Vishal		hold up to 7 sep 
INC004912800	Vishal		Resolve 
INC004915195	Vishal		Resolve
INC004916777	Vishal		Resolve
TASK001030690	Vishal		updated wating for hector reply 
TASK001055227	Vishal		updated wating for hector reply
TASK001055694	Vishal		MSSQL transfer


RE: Uslzua200m2srv  : not able to connect 
Knowledge Transfer to Vishal Kadam--DAY1
RE: Knowledge Transfer to Vishal Kadam
RE: SMS Patching 2018/09 USTXCA3002VSRV RFC:-C5455149
RE: Hun : RITM000643908 TASK001055227 Release free space allocated to ASM on USARAV201
RE: Siemens : apply oracle July 2018 security patch for databases TDMSX,TDMST,TDMSD,CDB1,ACWT,ARRET on MOE1A5  server 
RE: INC004873153 - UAR Creation for 75307 - New User - Focus Database - 08/29/18 - Edwards, Chiloh
RE: H1 2018 - Appraisal Status
RE: TASK001030690(SNOW)/REQ000591078 --- Create two Informatica Databases in the Oracle 12c Servers


===============================
4-Sep-2018 DS
===============================
ATF:I11432337	Vishal		updated wating for cutomer reply
ATF:I11612394	Vishal		updated wating for cutomer reply 
ATF:I11614440	Vishal		updated by vaibhav
ATF:I11643441	Vishal		updated wating for cutomer reply (jose is working on it )
ATF:I11644688	Vishal		updated wating for cutomer reply 
ATF:I11695966	Vishal		transfter to service desk 
ATF:I11692018	Vishal		jose is working on it 
INC004802299	Vishal		updated wating for end user reply 
INC004840478	Vishal		updated 

RE: Hun : RITM000643908 TASK001055227 Release free space allocated to ASM on USARAV201
RE: Ticket and Changes need Update 4Sep2018 DS
RE: Knowledge Transfer to Vishal Kadam
RE: Knowledge Transfer to Vishal Kadam--DAY1
RE: INC004872042 | CRITICAL: arlhp01 CPU CRITICAL: CPU usage = 100%
RE: FOCUSPRF: Full Database Export (Aug 31, 2018) : INC004898989
RE: INC004802299 - UAR Creation for 74113 - New User - Focus Servers - 08/14/18 - Gujral, Shubhi
RE: Ticket and Changes need Update  3Sep2018 DS

===============================
5-Sep-2018 DS
===============================
INC004802299	Vishal		updated mail sent
INC004840478	Vishal		monitoring 
INC004856447	Vishal		updated mail sent watinfg for reply 
INC004870929	Vishal		UPDATED Vailbhav is working on it 
INC004877182	Vishal
INC004886942	Vishal		updated by subodh 
INC004934372	Vishal		Resolve 
INC004936435	Vishal
INC004938099	Vishal

 RE: Hun : RITM000643908 TASK001055227 Release free space allocated to ASM on USARAV201
 Nam backup report till 3rd sept 2018.
 RE: INC004856447:Eprogesa: Running Slow
 RE: RMAN Backup failure on "usaodba1.arl.us.ao-srv.com"  ref#INC004744607
 RE: SMS Patching 2018/09 USMLVA3006JSRV RFC:-C5455149
 RE: SPG Patching 2018/09 USLZUA4003QSRV RFC:-C5455149
 RE: SMS Patching 2018/08 USDXSLPRMAN1 & USDXSLPRMAN2 RFC:-C5455149
 RE: SEA Patching 2018/09 USLZUA200J7SRV RFC:-C5455149
 RE: Account Locked

 
===============================
9-Sep-2018 DS
===============================


RE: SMS Patching 2018/09 USMLVA3006JSRV RFC:-C5455149
RE: servers 
RE: CNA snow access tracker

INC004988822                Resolve 
ATF:I11643441   Vishal        vaibhav is working on it 
INC004840478   Vishal        Resolve 
INC004956636   Vishal        mail drop to the kumar

 
===============================
10-Sep-2018 DS
===============================

INC004988822			Resolve 
ATF:I11643441   Vishal	vaibhav is working on it 
INC004840478	Vishal 	Resolve 
INC004956636	Vishal	mail drop to the kumar 

RE: SEA Patching 2018/09 USLZUA200JWSRV RFC:-C5455149
RE: Create change for database hosted on server usarav185.
RE: FW: INC004079259/ INC004243186  : USSEA313 (DYAMON - ORA - alert_SID) ALERT : ORA-01555 caused by SQL statement below (SQL ID: 9qkfny1aax1hg, SCN: 0x0236.a69f1e7d):
RE: SPG Patching 2018/09 USLZUA4002USRV RFC:-C5455149
RE: SBT Patching 2018/09 USIRVA2002GSRV RFC:-C5455149
RE: SMS Unix Patching 2018/09 USMLVA30020SRV RFC:-C5455149
RE: SMS Patching 2018/09 USDFSTPTP2 RFC:-C5455149
RE: Ticket and Changes need Update 10Sep2018 DS



===============================
11-Sep-2018 DS
===============================
INC005006744	Vishal		Resolve 
INC005012859	Vishal		Transfer to service desk 
CHG000246794	Vishal		CIP attached  
CHG000246869	Vishal		need to create CIP 
CHG000246618	Vishal		updated mail drop to Kumar 

@Vishal:- Finolex             RE: Password required   Mon 10-09-2018 21:44   Please check email from Rahul Dukare and work accordingly. we have changed password for user SAPSR3 on database PRD (hostname:eccprddb ). once they complete the migration we need to set password back to original value as below. "alter user SAPSR3 identified by values 'S:AB5B1F23E928D56F104A0C9367BE1B3E92B2F745118733BC4CBF486FAD9B;0DF2189CC35798A3'; " 
-----wating for reply 
@Vishal:- CHG000246869  HTM : C79973 : Internal Audit actions needed for database UCP1 and INFAP1 Mon 10-09-2018 10:53          awaiting reply from user
cip need to create 
NAM HO from 11 Sep -2018 DS
RE: Ticket and Changes need Update 11Sep2018 DS

===============================
15-Sep-2018 NS
===============================
RE: Atos Bridge| Siemens | WARNING | IRVING | Applications 1 | UC4 Test Oracle Server (usirva3002usrv) || ATF:I11851925 
connection issue : Huntsman JH (10.200.85.43)
RE: SEA Patching 2018/09 USLZUA200JWSRV RFC:-C5455149
RE: SEA Patching 2018/09 USLZUA200KMSRV RFC:-C5455149
RE: CHG000246720 | CPU and RAM reduction on Linux DB servers

ATF:I11851925	Resolve

==============================		=
16-Sep-2018 NS
===============================

RE: SMS Patching 2018/09 USDXSLPPLMDB1 USMLVA3003USRV & USIRVA30021SRV RFC:-C5455149
NAM HO from 16 Sep -2018 NS

ATF:I11851925 		Resolve 
INC005076259        Resolve 
INC005068184        Resolve 
INC005082887        Resolve 

===============================
17-Sep-2018 NS
===============================

RE:   DBA Quality awareness Quiz_Sep_2018
RE: Transport No Show
RE: Starting: 2018/09 SMS Patching USMLVA3003QSRV RFC:-C5455149
NAM HO from 17 Sep -2018 NS
RE: FOCUSPRF: Restore annual cold backup of FOCUSPRD

ATF:I11851925 		Resolve 
INC005076259        Resolve 
INC005068184        Resolve 
INC005082887        Resolve 

===============================
18-Sep-2018 NS
===============================

INC005111488		Resolve 
INC005111521		Resolve
INC005113799		UPDATED 
INC005113800		UPDATED 

RE: INC005068390/INC005090398 - sosusospdbprd01/stlup06prd01 MEMORY WARNING: MEMORY usage = 93%
 Monsanto_HO_18_Sep2018_NS
 
===============================
19-Sep-2018 NS
===============================
INC005126376		updated 	
INC005126500		updated 
INC004959314		updated 
CHG000248214		updated 

RE: [ATOS] INC004959134 INC004959314 Assigned to your group ZZ.Database.Oracle CHG000248214



===============================
20-Sep-2018 NS
===============================
INC005233539		updated	
INC005234424        updated
INC005248173        updated
INC005248398        updated
INC005257425        updated

===============================
21-OCT-2018 NS
===============================

INC005414615		UDPATED 

===============================
25-OCT-2018 DS
===============================

INC005594533			Resolve 
INC005599182			updated 
INC005599174			updated 
INC005596766			REsolve 
INC005594955			Resolve 
INC005594955			Resolve 
INC005570863			Updated 
INC005599182			updated 
INC005599174			updated
INC005602341			Resolve  
INC005603699			Resolve 
INC005603700			Resolve


===============================
10-NOV-2018 DS
===============================



INC005855400			REsolve 
INC005854712            REsolve 
INC005854714            REsolve 
INC005855001            REsolve 
INC005855002            REsolve 
INC005855002            REsolve 
INC005854711            REsolve 
INC005855294            REsolve 
INC005855297            REsolve 
INC005855519            REsolve 
INC005852317            REsolve 
INC005852668            REsolve 
INC005839372            REsolve 
INC005839324            REsolve 
INC005839326            REsolve 
INC005839374            REsolve 
INC005837410            REsolve 
INC005837434            REsolve 
INC005837510            REsolve 
INC005837587            REsolve 
INC005837738            REsolve 
INC005835532            REsolve 
INC005838835            REsolve 
INC005838639            REsolve 
INC005838615            REsolve 
INC005838488            REsolve 
INC005838395            REsolve 
INC005834858			REsolve
INC005835347            REsolve
INC005836795            REsolve
INC005835977            REsolve
INC005836702            REsolve
INC005840760            REsolve
INC005855920			REsolve











Vishal.Bhandwalkar@cna.com




















DLINO-SQLDBA (DLINO-SQLDBA.it-solutions@atos.net (DLINO-SQLDBA.it-solutions%40atos.net)) 



https://www.planmoneytax.com/partially-withdraw-pf-without-leaving-job/ <https://www.planmoneytax.com/partially-withdraw-pf-without-leaving-job/>  









mysql -u root -p 's3aAdm1n!' 

Sweethome$1234

p's3aAdm1n

eight$Action201

ad001\w99au4b0	
seven$Action201
can you please login to USIRVA2002XSRV server
using url 
https://emea-de-033.asn.saacon.net/vpn/index.html
ad001
ad001\w99au4b0	
seven$Action201
and from there RD to USIRVA2002XSRV 


linkdn : ISPL_201$201
gmail  : ISPL_201
facebook : ISPL_201
YOUtube : ISPL_201
blog     : ISPL_201


www.linkedin.com/in/vrtraning 
https://oravr.blogspot.com/
https://www.facebook.com/vr.tranings
VRTRANING@GMAIL.COM

+91 9960902388
+91 9552561326

9552561316
9552561316







263142
208056
196400
794187286



J@n01062018
aug$Action2018


Name
AWS Account details :
vishalvilas
Account

321036802274