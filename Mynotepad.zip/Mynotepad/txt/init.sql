
--- ********************************************************HELP****************************************************************************

--w 						: Database status 										: w
--w1						: your clint session details 							: w1
--ps						: your session details 									: ps 
--redo						: redo log member and greoups 							: redo
--resource					: current uses sess and process 						: resource
--scountuser				: user sessoin count 									: resource 
--archhist					: history archive log 									: archhist days 
--archhistcount				: count history archivelog 								: archhistcount days 
--asmclint					: asm connected client 									: asmclint
--diskgroup					: asm diskgroup											: asm diskgroup
--asmfiles					: asm files 											: asm files 
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--
--












-- define verialbes 
-- def SQLPATH='/home/oracle/sql' 
----def SQLPATH='/home/oracle/sql' 
----@&SQLPATH/init.sql
alias init=@&SQLPATH/init.sql
-- column
col db_name new_value db_name

--set 
set echo off 
SET SQLFORMAT ansiconsole

--alter sessions 
alter session set nls_date_format='ddmmyy';
alter session set global_names=false;

select name db_name from v$database;
set sqlprompt "@|blue _USER|@@@|green &db_name|@@|red >|@ "

--*********************************************************Alias**********************************************************************

alias w=select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from gv$instance I,gv$database D ;
alias w1=SELECT to_char(SYSDATE,'dd-mm-yyyy hh24:mi:ss') "DATE",SYS_CONTEXT('USERENV','SERVER_HOST') AS DB_HOSTNAME ,SYS_CONTEXT('USERENV','DB_NAME') AS INSTANCE,SYS_CONTEXT('USERENV','HOST') AS CLIENTHOST FROM DUAL;
alias ps =SELECT SID, SERIAL#    FROM GV$SESSION    WHERE AUDSID = Sys_Context('USERENV', 'SESSIONID')      AND INST_ID = USERENV('Instance'); 
alias redo=SELECT     a.group#   , a.member   , sum(b.bytes/1024/1024 ) "size_mb"   , null   , TO_NUMBER(null)   , TO_NUMBER(null) FROM     v$logfile a   , v$log b WHERE     a.group# = b.group# group by a.group#,member order by 1;
alias resource=SELECT    TO_NUMBER(a.value) max_sess_allowed  , TO_NUMBER(count(*)) num_sessions  , LPAD(ROUND((count(*)/a.value)*100,0) || '%', 19)  pct_utl FROM  v$session    b, v$parameter  a WHERE    a.name = 'sessions' GROUP BY     a.value;
alias scountuser=SELECT     lpad(nvl(sess.username, '[B.G. Process]'), 15) username   , count(*) num_user_sess   , nvl(act.count, 0)   count_a   , nvl(inact.count, 0) count_i FROM     v$session sess   , (SELECT    count(*) count, nvl(username, '[B.G. Process]') username      FROM      v$session      WHERE     status = 'ACTIVE'      GROUP BY  username)   act   , (SELECT    count(*) count, nvl(username, '[B.G. Process]') username      FROM      v$session      WHERE     status = 'INACTIVE'      GROUP BY  username) inact WHERE          nvl(sess.username, '[B.G. Process]') = act.username (+)      and nvl(sess.username, '[B.G. Process]') = inact.username (+) GROUP BY     sess.username   , act.count   , inact.count ;
alias archhist=select thread#, trunc(completion_time) as "date", to_char(completion_time,'Dy') as "Day", count(1) as "total", sum(decode(to_char(completion_time,'HH24'),'00',1,0)) as "00", sum(decode(to_char(completion_time,'HH24'),'01',1,0)) as "01", sum(decode(to_char(completion_time,'HH24'),'02',1,0)) as "02", sum(decode(to_char(completion_time,'HH24'),'03',1,0)) as "03", sum(decode(to_char(completion_time,'HH24'),'04',1,0)) as "04", sum(decode(to_char(completion_time,'HH24'),'05',1,0)) as "05", sum(decode(to_char(completion_time,'HH24'),'06',1,0)) as "06", sum(decode(to_char(completion_time,'HH24'),'07',1,0)) as "07", sum(decode(to_char(completion_time,'HH24'),'08',1,0)) as "08", sum(decode(to_char(completion_time,'HH24'),'09',1,0)) as "09", sum(decode(to_char(completion_time,'HH24'),'10',1,0)) as "10", sum(decode(to_char(completion_time,'HH24'),'11',1,0)) as "11", sum(decode(to_char(completion_time,'HH24'),'12',1,0)) as "12", sum(decode(to_char(completion_time,'HH24'),'13',1,0)) as "13", sum(decode(to_char(completion_time,'HH24'),'14',1,0)) as "14", sum(decode(to_char(completion_time,'HH24'),'15',1,0)) as "15", sum(decode(to_char(completion_time,'HH24'),'16',1,0)) as "16", sum(decode(to_char(completion_time,'HH24'),'17',1,0)) as "17", sum(decode(to_char(completion_time,'HH24'),'18',1,0)) as "18", sum(decode(to_char(completion_time,'HH24'),'19',1,0)) as "19", sum(decode(to_char(completion_time,'HH24'),'20',1,0)) as "20", sum(decode(to_char(completion_time,'HH24'),'21',1,0)) as "21", sum(decode(to_char(completion_time,'HH24'),'22',1,0)) as "22", sum(decode(to_char(completion_time,'HH24'),'23',1,0)) as "23" from v$archived_log where first_time > trunc(sysdate-:day) and dest_id = (select dest_id from V$ARCHIVE_DEST_STATUS where status='VALID' and type='LOCAL') group by thread#, trunc(completion_time), to_char(completion_time, 'Dy') order by 2,1;
alias archhistcount=SELECT THREAD# AS "T", TRUNC(completion_time) AS "DATE" , COUNT(1) num , TRUNC(SUM(BLOCKS*block_size)/1024/1024/1024) AS GB , TRUNC(SUM(BLOCKS*block_size)/1024/1024) AS MB , SUM(BLOCKS*block_size)/1024 AS KB FROM v$archived_log WHERE first_time > TRUNC(SYSDATE-1) AND dest_id = (SELECT dest_id FROM V$ARCHIVE_DEST_STATUS WHERE status='VALID' AND TYPE='LOCAL') GROUP BY THREAD#, TRUNC(completion_time) ORDER BY 2,1;
alias asmclint=SELECT     a.name              disk_group_name   , c.instance_name     instance_name   , c.db_name           db_name   , c.status            status FROM     v$asm_diskgroup a JOIN v$asm_client c USING (group_number) ORDER BY     a.name ;
alias diskgroup=SELECT name group_name,sector_size sector_size,block_size block_size,allocation_unit_size allocation_unit_size,state state, type type, total_mb total_mb   , (total_mb - free_mb) used_mb , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used FROM v$asm_diskgroup WHERE total_mb != 0  ORDER BY name ;
alias asmfiles=SELECT NVL(a.name, '[CANDIDATE]') disk_group_name   , b.path disk_file_path   , b.name disk_file_name   , b.failgroup disk_file_fail_group   , b.total_mb total_mb   , (b.total_mb - b.free_mb) used_mb   , b.free_mb free_mb   , ROUND((1- (b.free_mb / b.total_mb))*100, 2) pct_used FROM     v$asm_diskgroup a RIGHT OUTER JOIN v$asm_disk b USING (group_number) ORDER BY a.name ;
alias dba_dir=SELECT     owner   , directory_name   , directory_path FROM     dba_directories ORDER BY     owner   , directory_name ;




--*********************************************************Alias**********************************************************************
alias dbadir=@&SQLPATH/dbadir.sql;










-- files 
alias role=@&SQLPATH/role.sql ;
alias redohistory=@$SQLPATH/redohistory.sql;

----load data 

w
w1
ps


cle scr 

