RUN {
set until time "to_date('29-09-2017 03:20:00','DD-MM-YYYY HH24:MI:SS')";
allocate channel ch1 type disk;
allocate channel ch2 type disk;
allocate channel ch3 type disk;
allocate channel ch4 type disk;
set newname for datafile '/appl/oracle/FOCUSPRD/system1/ora_FOCUSPRD_system01.dbf' to '/appl/oracle/FOCUSPRF/system1/ora_FOCUSPRF_system01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_01.dbf' to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/system1/ora_FOCUSPRD_sysaux01.dbf' to '/appl/oracle/FOCUSPRF/system1/ora_FOCUSPRF_sysaux01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_users01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_users01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_AQ_01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_AQ_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_09.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_10.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_11.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_11.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_08.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_09.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LOB_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LOB_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_12.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_12.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_10.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_11.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_11.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_12.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_12.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_21.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_21.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_SML_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_SML_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_22.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_22.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_26.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_26.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_23.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_23.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_24.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_24.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_25.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_25.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_16.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_16.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_17.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_17.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_18.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_18.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_27.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_27.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_28.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_28.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_29.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_29.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_30.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_30.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_02.dbf' to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_31.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_31.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_32.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_32.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_19.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_19.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_03.dbf' to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_04.dbf' to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_20.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_20.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_05.dbf' to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_05.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_06.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_07.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_08.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_01.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_02.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_03.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_04.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_05.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_06.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_07.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_05.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_06.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_07.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_08.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_09.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_10.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_01.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_02.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_03.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_04.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_05.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_06.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_07.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_08.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_09.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_10.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_11.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_11.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_12.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_12.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_13.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_13.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_14.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_14.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_15.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_15.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_05.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_06.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_07.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_MED_DATA_08.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_MED_DATA_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_MED_IDX_01.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_MED_IDX_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_MED_IDX_02.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_MED_IDX_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_03.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_04.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_05.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_06.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_07.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_21.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_21.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_11.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_11.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_12.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_12.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_13.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_13.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_14.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_14.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_15.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_15.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_16.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_16.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_17.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_17.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_SML_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_SML_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_SML_IDX_01.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_SML_IDX_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LOB_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LOB_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_18.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_18.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_DBADMIN_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_DBADMIN_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_19.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_19.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_20.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_20.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_22.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_22.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_33.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_33.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_34.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_34.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_23.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_23.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_24.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_24.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_35.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_35.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_25.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_25.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_26.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_26.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_27.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_27.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_36.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_36.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_37.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_37.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_38.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_38.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_39.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_39.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_28.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_28.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_40.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_40.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_29.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_29.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_41.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_41.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_42.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_42.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_30.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_30.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_31.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_31.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_32.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_32.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_33.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_33.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_43.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_43.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_44.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_44.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_34.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_34.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_45.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_45.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_35.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_35.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_36.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_36.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_37.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_37.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_46.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_46.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_47.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_47.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_38.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_38.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_48.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_48.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_49.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_49.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_39.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_39.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_40.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_40.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_50.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_50.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_41.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_41.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_51.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_51.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_42.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_42.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_43.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_43.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_44.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_44.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_45.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_45.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_46.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_46.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_52.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_52.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_53.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_53.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_54.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_54.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_47.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_47.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_JBM_01.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_JBM_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_13.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_13.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_48.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_48.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_13.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_13.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_14.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_14.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_14.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_14.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_SML_IDX_02.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_SML_IDX_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_49.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_49.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_50.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_50.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_51.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_51.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_SML_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_SML_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_tools_01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_tools_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_LOB_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_LOB_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_55.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_55.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_56.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_56.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_AQ_03.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_AQ_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_AQ_02.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_AQ_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LOB_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LOB_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LOB_DATA_05.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LOB_DATA_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_MED_DATA_09.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_MED_DATA_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_MED_DATA_10.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_MED_DATA_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_08.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_AQ_04.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_AQ_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_06.dbf'  to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_06.dbf';
switch datafile all;
release channel ch1;
release channel ch2;
release channel ch3;
}




















RUN {
 set until time "to_date('29-09-2017 03:20:00','DD-MM-YYYY HH24:MI:SS')";
 allocate channel ch1 type disk;
 allocate channel ch2 type disk;
 allocate channel ch3 type disk;
 allocate channel ch4 type disk;
 set newname for datafile 29 to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_02.dbf';
 set newname for datafile 2 to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_01.dbf';
 set newname for datafile 34 to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_04.dbf';
 set newname for datafile 36 to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_05.dbf';
 set newname for datafile 33 to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_03.dbf';
 set newname for datafile 179  to '/oracle/data2/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_06.dbf';
 set newname for datafile 3 to '/appl/oracle/FOCUSPRF/system1/ora_FOCUSPRF_sysaux01.dbf';
 restore DATAFILE 29,2,34,36,33,179,3 ;
 release channel ch1;
 release channel ch2;
 release channel ch3;
 release channel ch4;
 }

RUN {
 set until time "to_date('29-09-2017 03:20:00','DD-MM-YYYY HH24:MI:SS')";
 allocate channel ch1 type disk;
 allocate channel ch2 type disk;
 allocate channel ch3 type disk;
 allocate channel ch4 type disk;
 set newname for datafile 28 to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_30.dbf';
 restore DATAFILE 28;
 release channel ch1;
 release channel ch2;
 release channel ch3;
 release channel ch4;
 }


RUN {
 set until time "to_date('29-09-2017 03:20:00','DD-MM-YYYY HH24:MI:SS')";
 allocate channel ch1 type disk;
 allocate channel ch2 type disk;
 allocate channel ch3 type disk;
 allocate channel ch4 type disk;
 set newname for datafile 30 to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_31.dbf';
 set newname for datafile 58 to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_07.dbf';
 set newname for datafile 59 to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_08.dbf';
 restore DATAFILE 30,58,59;
 release channel ch1;
 release channel ch2;
 release channel ch3;
 release channel ch4;
 }


RUN {
 set until time "to_date('29-09-2017 03:20:00','DD-MM-YYYY HH24:MI:SS')";
 allocate channel ch1 type disk;
 allocate channel ch2 type disk;
 allocate channel ch3 type disk;
 allocate channel ch4 type disk;
 set newname for datafile 93 to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_11.dbf';
 set newname for datafile 94 to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_12.dbf';
 set newname for datafile 109 to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_34.dbf';
 set newname for datafile 112 to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_35.dbf';
 restore DATAFILE 93,94,109,112;
 release channel ch1;
 release channel ch2;
 release channel ch3;
 release channel ch4;
 }




RUN {
 set until time "to_date('29-09-2017 03:20:00','DD-MM-YYYY HH24:MI:SS')";
 allocate channel ch1 type disk;
 allocate channel ch2 type disk;
 allocate channel ch3 type disk;
 allocate channel ch4 type disk;
 set newname for datafile 95 to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_13.dbf';
 set newname for datafile 96 to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_14.dbf';
 set newname for datafile 116 to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_36.dbf';
 set newname for datafile 117 to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_37.dbf';
 restore DATAFILE 95,96,116,117;
 release channel ch1;
 release channel ch2;
 release channel ch3;
 release channel ch4;
 }



RUN {
 set until time "to_date('29-09-2017 03:20:00','DD-MM-YYYY HH24:MI:SS')";
 allocate channel ch1 type disk;
 allocate channel ch2 type disk;
 allocate channel ch3 type disk;
 allocate channel ch4 type disk;
 set newname for datafile 162 to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_49.dbf';
 restore DATAFILE 162;
 release channel ch1;
 release channel ch2;
 release channel ch3;
 release channel ch4;
 }



RUN {
 set until time "to_date('29-09-2017 03:20:00','DD-MM-YYYY HH24:MI:SS')";
 allocate channel ch1 type disk;
 allocate channel ch2 type disk;
 allocate channel ch3 type disk;
 allocate channel ch4 type disk;
 set newname for datafile 171 to '/oracle/index2/FOCUSPRF/data2/ora_FOCUSPRF_AQ_03.dbf';
 set newname for datafile 175 to '/oracle/index3/FOCUSPRF/ora_FOCUSPRF_FOCUS_MED_DATA_09.dbf';
 set newname for datafile 176 to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_MED_DATA_10.dbf';
 restore DATAFILE 171,175,176;
 release channel ch1;
 release channel ch2;
 release channel ch3;
 release channel ch4;
 }
















