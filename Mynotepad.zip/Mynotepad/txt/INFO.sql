=======================================================================================================================================		
													ORA-600 space leak 			
=======================================================================================================================================		
How do I handle a space leak?
Step 1. Review the alert.log to verify the error and obtain the trace file information. 

The alert.log will report an error similar to the following:
Sat Dec 02 21:52:17 2006 
Errors in file d:\oracle\admin\testdb\udump\testdb_ora_5928.trc: 
ORA-00600: internal error code, arguments: [729], [152], [space leak], [], [], [], [], [] 

a. the first bracketed number [729] is the common argument for space leak problems. 
b. the second number [152] is the number of bytes leaked by the error. 
c. the third argument is always [space leak].

Step 2. Open the associated trace file.
Below the operating system and Oracle process header information, you will see the following:
*** 2006-12-13 02:01:13.859 
*** SESSION ID:(54.11635) 2006-12-13 02:01:13.859 
******** ERROR: UGA memory leak detected 152 ******** 
****************************************************** 



Class of Secure Transport (COST) to Restrict Instance Registration (Doc ID 1453883.1)

The above error states: 

a. the memory was leaked from the UGA area 
b. the amount leaked is reported again in the text (152 bytes).

https://asanga-pradeep.blogspot.com/2016/03/changing-hostname-in-standalone-db.html

EM 12c, 13c: Agent installation Failed with base directory not being owned by root or installation user (Doc ID 1517731.1)
Script to Collect Data Guard Physical and Active Standby Diagnostic Information for Version 10g and above (Including RAC) (Doc ID 1577406.1)
Script to Collect Data Guard Primary Site Diagnostic Information for Version 10g and Above (Including RAC). (Doc ID 1577401.1)
How To Relink The Oracle Grid Infrastructure Standalone (Restart) Installation Or Oracle Grid Infrastructure RAC/Cluster Installation (11.2 or 12c). (Doc ID 1536057.1)




Tablespace encryption ;
