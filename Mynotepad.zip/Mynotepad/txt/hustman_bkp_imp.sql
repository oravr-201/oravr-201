#!/bin/sh
# =========================================================================== #
# RMAN do archivelog backup for each running pmon on the server                         #
# Written: 03/26/2014 For HM                                               #
# =========================================================================== #
#  for i in `cat /home/oracle/rman/sidlists/arch_sidlist1`
LOG_FOLDER=/home/oracle/scripts/rman/logs
BACKUP_TIME=`date '+%m%d%H%M%S'`
export NLS_DATE_FORMAT='YYYY-MM-DD:hh24:mi:ss'
TDPO_LOG=/home/oracle/tdpoerror.log
TDPO_LOG_HIST=/home/oracle/tdpoerror.log_hist
# TDPO_RUN_TIME=`date '+%m/%d/%Y'`
# TDPO_RUN_TIME=$TDPO_RUN_TIME' '`date '+%T'`
if [ -f $TDPO_LOG_HIST ] ; then
   cat $TDPO_LOG >> $TDPO_LOG_HIST
else
   touch $TDPO_LOG_HIST
   cat $TDPO_LOG >> $TDPO_LOG_HIST
fi
> $TDPO_LOG
export ORACLE_HOME=/u01/app/oracle/product/11.2.0.4
export TNS_ADMIN=/u01/app/oracle/admin/config
echo $ORACLE_HOME
DBLIST=`ps -ef | grep pmon | grep -v "grep pmon" | grep -v "+ASM" | cut -f3 -d_`
for dbname in $DBLIST
do
export ORACLE_SID=$dbname
echo $ORACLE_SID
RMAN_SCHEMA_LOG=/home/oracle/scripts/rman/logs/UCP1_arch_schema.log
RMAN_BACKUP_LOG=/home/oracle/scripts/rman/logs/UCP1_arch_backup.log
/u01/app/oracle/product/11.2.0.4/bin/rman <<EOF
   connect target /;
   connect catalog rman/Summer2014@RMANPRD;
   SPOOL LOG TO /home/oracle/scripts/rman/logs/UCP1_arch_schema.log
   REPORT SCHEMA;
   SPOOL LOG OFF
   SPOOL LOG TO /home/oracle/scripts/rman/logs/UCP1_arch_backup.log
   crosscheck archivelog all;
   delete force noprompt expired archivelog all;
   sql 'alter system archive log current';
   backup archivelog all format '%d_AL_%T_%u_s%s_p%p' delete input;
   list backup;
   #####report obsolete;
   delete noprompt obsolete;
   #####resync catalog;
   SPOOL LOG OFF;
   host 'echo "Recovery Manager complete." >> ${RMAN_BACKUP_LOG}';
   exit;
EOF
done
cp $TDPO_LOG $LOG_FOLDER
cp $TDPO_LOG_HIST $LOG_FOLDER
exit

