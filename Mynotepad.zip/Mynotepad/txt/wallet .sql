wallet :


orapki wallet create -wallet /u01/app/oracle/product/11.2.0/dbhome_2/wallet -pwd Monsanto$.1 -auto_login

orapki wallet display -wallet /oracle/app/oracle/product/12.1.0/db_1/owm/wallets/oracle -pwd 0raclewallet

orapki wallet add -wallet /u02/app/oracle/wallet/prod -trusted_cert -cert "/u02/app/oracle/wallet/prod/4.cer" -pwd 0raclewallet

orapki wallet add -wallet /u02/app/oracle/wallet/prod -request "/u02/app/oracle/wallet/prod/4.cer" -cert "/u02/app/oracle/wallet/prod/4.cer" -validity 3650 -pwd 0raclewallet



orapki wallet remove -wallet . -dn  'pkgopp0d-OPP.eps.siemens.com' -trusted_cert pkgopp0d-OPP.cer -pwd 0raclewallet 
orapki wallet remove -wallet /u02/app/oracle/wallet/prod -trusted_cert_all -pwd 0raclewallet


orapki wallet remove -dn "CN=pkgopp0d-OPP.eps.siemens.com,C=DE,O=Siemens,OU=E IT F PR" -trusted_cert -wallet "/oracle/app/oracle/product/12.1.0/db_1/owm/wallets/oracle" -pwd 0raclewallet





SELECT UTL_HTTP.REQUEST ('https://usi.oci.siemens.com/',NULL,'file:/oracle/app/oracle/product/12.1.0/db_1/owm/wallets/oracle','0raclewallet') FROM DUAL;




UTL_HTTP.SET_WALLET('file:/u02/app/oracle/wallet/prod', '0raclewallet');


SET SERVEROUTPUT ON
EXEC UTL_HTTP.set_wallet('/u02/app/oracle/wallet/prod', '0raclewallet');
EXEC show_html_from_url('https://usi.oci.siemens.com/');



 SELECT UTL_HTTP.REQUEST ('https://usi.oci.siemens.com/',NULL,'file:/u02/app/oracle/wallet/prod/','0raclewallet <https://usi.oci.siemens.com/%27%2cNULL%2c%27file:/u02/app/oracle/wallet/prod/%27%2c%270raclewallet> '


col acl for a30
col principal for a30
col is_grant for a30
col start_date for a15
col end_date for a15
col privilege for a10
col dba_network_acl_privileges for a15
SELECT acl, 
       principal, 
       privilege, 
       is_grant, 
       TO_CHAR(start_date, 'DD-MON-YYYY') AS start_date, 
       TO_CHAR(end_date, 'DD-MON-YYYY') AS end_date 
FROM   dba_network_acl_privileges where principal='PGDATA_WP'


select table_name from dba_tab_privs
where grantee='PGDATA_WP'
and privilege ='EXECUTE'
and table_name in
('UTL_FILE', 'UTL_SMTP', 'UTL_TCP', 'UTL_HTTP',
'DBMS_RANDOM', 'DBMS_LOB', 'DBMS_SQL',
'DBMS_SYS_SQL', 'DBMS_JOB',
'DBMS_BACKUP_RESTORE',
'DBMS_OBFUSCATION_TOOLKIT');







CONNECT scott/tiger

SET serveroutput ON

DECLARE
    HTTP_REQ      UTL_HTTP.REQ;
    HTTP_RESP     UTL_HTTP.RESP;
    URL_TEXT      VARCHAR2(32767);
BEGIN
    DBMS_OUTPUT.ENABLE(1000000);

    UTL_HTTP.SET_WALLET('file:/u02/app/oracle/racdb/wallet', 'wallet_password');

    HTTP_REQ  := UTL_HTTP.BEGIN_REQUEST('https://www.centos.org/');
    UTL_HTTP.SET_HEADER(HTTP_REQ, 'User-Agent', 'Mozilla/4.0');
    HTTP_RESP := UTL_HTTP.GET_RESPONSE(HTTP_REQ);

    -- Process Request
    LOOP
        BEGIN
            URL_TEXT := null;
            UTL_HTTP.READ_LINE(HTTP_RESP, URL_TEXT, TRUE);
            DBMS_OUTPUT.PUT_LINE(URL_TEXT);

            EXCEPTION
                WHEN OTHERS THEN EXIT;
        END;
    END LOOP;

    UTL_HTTP.END_RESPONSE(HTTP_RESP);
END;
/


-- DBMS_SYSTEM.KSDWRT Write messages to Oracle alert log 
-- Oracle provides a procedure to insert messages to the alert log and/or trace files for testing/development purposes.  

-- This can be used to check the effectiveness of the monitoring tools/scripts used in the environment, to understand how 

-- well the monitoring tool captures the messages in the alert log. 
SQL> exec dbms_system.ksdwrt(1, 'This message goes to trace file in the udump location'); 
  
PL/SQL procedure successfully completed. 
  
SQL> exec dbms_system.ksdwrt(2, 'This message goes to the alert log'); 
  
PL/SQL procedure successfully completed. 
  
SQL> exec dbms_system.ksdwrt(3, 'This message goes to the alert log and trace file in the udump location'); 

exec dbms_system.ksdwrt(3, 'Error Vishal is working in DS shift');  









=========================================================================================================

TABLESPACE ENCRYPTION :

  select * from v$encryption_wallet;
  administer key management create keystore '/u00/app/oracle/local/wallet' identified by manager;
  administer key management set keystore open identified by manager  container =all;
  

1 . create wallete 
2 . add entry on sqlnet.ora

	ENCRYPTION_WALLET_LOCATION=(SOURCE=(METHOD=FILE)(METHOD_DATA=(DIRECTORY=/u01/app/oracle/admin/DB11G/encryption_wallet/)))
	
3. set password for encryption :

	CONN sys/password@db11g AS SYSDBA
	ALTER SYSTEM SET ENCRYPTION KEY IDENTIFIED BY "myPassword";
	
4. query to open wallet 
	ALTER SYSTEM SET ENCRYPTION WALLET OPEN IDENTIFIED BY "myPassword";
	ALTER SYSTEM SET ENCRYPTION WALLET CLOSE;
	
5. CREATE TABLESPACE :
	CREATE TABLESPACE encrypted_ts
	DATAFILE '/u01/app/oracle/oradata/DB11G/encrypted_ts01.dbf' SIZE 128K
	AUTOEXTEND ON NEXT 64K
	ENCRYPTION USING 'AES256'
	DEFAULT STORAGE(ENCRYPT);
	
	ALTER USER test QUOTA UNLIMITED ON encrypted_ts;
	
	SELECT tablespace_name, encrypted FROM dba_tablespaces;
	
7. CREATE TABLE AND ADD SOME RECORDS .


	CREATE TABLE ets_test (id NUMBER(10),data  VARCHAR2(50)) TABLESPACE encrypted_ts;

	CREATE INDEX ets_test_idx ON ets_test(data) TABLESPACE encrypted_ts;

	INSERT INTO ets_test (id, data) VALUES (1, 'This is a secret!');
	COMMIT;
	
8. Flush the buffer cache to make sure the data is written to the datafile.

  	ALTER SYSTEM FLUSH BUFFER_CACHE;
  	
9 . RESTART THE DATABASE 

	SELECT * FROM test.ets_test;
	
	select * from test.ets_test
	                   *
	ERROR at line 1:
	ORA-28365: wallet is not open

10 . MUST BE OPEN WALLET 	
SQL> ALTER SYSTEM SET ENCRYPTION WALLET OPEN IDENTIFIED BY "myPassword";
	
	System altered.
	
	sys@db11g> select * from test.ets_test;




====================================================================================================

--RMAN ENCRYPTION :

1 .  set encryption on identified by 'test' only;
2 .

	RMAN> restore tablespace users;
	ORA-19913: unable to decrypt backup
	ORA-28365: wallet is not open
	
3. set decryption identified by 'test';

4 .configure encryption algorithm 'AES256';
5 .onfigure encryption for database clear;




-------------------------------------------

-- imp 
ADMINISTER KEY MANAGEMENT SET KEY USING TAG 'rotate_key' FORCE KEYSTORE IDENTIFIED BY "WPOra1_adm1N#T3aM" WITH BACKUP USING 'backup_key';


ADMINISTER KEY MANAGEMENT CREATE AUTO_LOGIN KEYSTORE FROM KEYSTORE '/opt/oracle/dcs/commonstore/wallets/tde/pdtwpnt_lhr13h/' IDENTIFIED BY "Ph03ni#Digit#1";
-- Open
ADMINISTER KEY MANAGEMENT SET KEYSTORE OPEN IDENTIFIED BY "Ph03ni#Digit#1" CONTAINER=ALL;

-- Close
ADMINISTER KEY MANAGEMENT SET KEYSTORE CLOSE IDENTIFIED BY "Ph03ni#Digit#1" CONTAINER=ALL;

ADMINISTER KEY MANAGEMENT SET KEY IDENTIFIED BY "Ph03ni#Digit#1" WITH BACKUP CONTAINER='PDTWPNT_PDB1';


ADMINISTER KEY MANAGEMENT SET KEYSTORE OPEN IDENTIFIED BY "Ph03ni#Digit#1";


ALTER SYSTEM SET "_db_discard_lost_masterkey"=TRUE SCOPE=MEMORY;




