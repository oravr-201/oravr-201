set head off verify off echo off pages 150 linesize 120 feedback off
alter session set nls_date_format='DD-MM-YYYY HH24:MI:SS';
select distinct
'DATABASE_NAME..............................................: '|| NAME             ,
'INSTANCE NAME..............................................: '|| INSTANCE_NAME    ,
'LOG_MODE...................................................: '|| LOG_MODE         ,
'OPEN MODE..................................................: '|| OPEN_MODE        ,
'INSTANCE_NAME..............................................: '|| INSTANCE_NAME    ,
'HOSTNAME...................................................: '|| HOST_NAME        ,
'STATUS.....................................................: '|| STATUS           ,
'LOGINS.....................................................: '|| LOGINS           ,
'STARTUP-TIME...............................................: '|| STARTUP_TIME     ,
'DATAGUARD BROKER...........................................: '|| DATAGUARD_BROKER ,
'GUARD STATUS...............................................: '|| GUARD_STATUS     ,
'FLASHBACK ON...............................................: '|| FLASHBACK_ON     ,
'PROTECTION MODE............................................: '|| PROTECTION_MODE  ,
'CONTROLFILE TYPE...........................................: '|| CONTROLFILE_TYPE
from gv$instance i, v$database d
-- where 1=1  
-- and i.inst_id=d.inst_id
order by 2;
set head on verify on echo on feedback on