rman target=/ rcvcat rman/rman@catdb 

 create catalog; 
 register database; 
 grant catalog for database odel11 to odel11;
 
 Now connect using the virtual catalog owner (odel11), and issue the statement create virtual catalog:

$ rman target=/ rcvcat odel11/odel11@catdb

RMAN> create virtual catalog;

Now, register a different database (PRONE3) to the same RMAN repository and create a virtual catalog owner "prone3" for its namesake database.

RMAN> grant catalog for database prone3 to prone3;

$ rman target=/ rcvcat prone3/prone3@catdb

RMAN> create virtual catalog;
 
 
 
 BASE catalog :
 
$ rman target=/ rcvcat=rman/rman@catdb

list db_unique_name all;


As expected, it showed both the registered databases. Now, connect as ODEL11 and issue the same command:

$ rman target=/ rcvcat odel11/odel11@catdb

list db_unique_name all;


Note how only one database was listed, not both. This user (odel11) is allowed to see only one database (ODEL11), and that's what it sees. You can confirm this by connecting to the catalog as the other owner, PRONE3: '

$ rman target=/ rcvcat prone3/prone3@catdb
 
RMAN> list db_unique_name all;
 
 
 
 
 
 
 
 
 
 
 
 
=========================================================================================================================================
CATALOG MERGE FROM VIRTUAL CATALOG :


 You are most likely using a catalog database for the RMAN repository. If you are not, you should seriously consider using one. There are several advantages, such as reporting, simpler recovery in case the controlfile is damaged, and so on.
Now comes the next question: How many catalogs? Generally, it makes sense to have only one catalog database as the repository for all databases. However, that might not be a good approach for security. A catalog owner will be able to see all the repositories of all databases. Since each database to be backed up may have a separate DBA, making the catalog visible may not be acceptable.
So, what's the alternative? Of course, you could create a separate catalog database for each target database, which is probably impractical due to cost considerations. The other option is to create only one database for catalog yet create a virtual catalog for each target database. Virtual catalogs are new in Oracle Database 11g. Let's see how to create them.
First, you need to create a base catalog that contains all the target databases. The owner is, say, "RMAN". From the target database, connect to the catalog database as the base user and create the catalog.
$ rman target=/ rcvcat rman/rman@catdb 
Recovery Manager: Release 11.1.0.6.0 - Production on Sun Sep 9 21:04:14 2007 Copyright (c) 1982, 2007, Oracle. All rights reserved. 

connected to target database: ODEL11 (DBID=2836429497) 
connected to recovery catalog database 
RMAN> create catalog; 
recovery catalog created 
RMAN> register database; 
database registered in recovery catalog 

starting full resync of recovery catalog 
full resync complete 

This is called the base catalog, owned by the user named "RMAN". Now, let's create two additional users who will own the respective virtual catalogs. For simplicity, let's gives these users the same name as the target database. While still connected as the base catalog owner (RMAN), issue these statement:

RMAN> grant catalog for database odel11 to odel11;
 
Grant succeeded.


Now connect using the virtual catalog owner (odel11), and issue the statement create virtual catalog:

$ rman target=/ rcvcat odel11/odel11@catdb

RMAN> create virtual catalog;
 
found eligible base catalog owned by RMAN
created virtual catalog against base catalog owned by RMAN


Now, register a different database (PRONE3) to the same RMAN repository and create a virtual catalog owner "prone3" for its namesake database.

RMAN> grant catalog for database prone3 to prone3;
 
Grant succeeded.

$ rman target=/ rcvcat prone3/prone3@catdb

RMAN> create virtual catalog;
 
found eligible base catalog owned by RMAN
created virtual catalog against base catalog owned by RMAN


Now, connecting as the base catalog owner (RMAN), if you want to see the databases registered, you will see:

$ rman target=/ rcvcat=rman/rman@catdb

RMAN> list db_unique_name all;
 
List of Databases
DB Key  DB Name  DB ID            Database Role    Db_unique_name
-------    -------     -----------------        ---------------         ------------------
285     PRONE3   1596130080       PRIMARY          PRONE3              
1       ODEL11   2836429497       PRIMARY          ODEL11   


As expected, it showed both the registered databases. Now, connect as ODEL11 and issue the same command:

$ rman target=/ rcvcat odel11/odel11@catdb
 
RMAN> list db_unique_name all;
 
 
List of Databases
DB Key  DB Name  DB ID            Database Role    Db_unique_name
-------    -------     -----------------        ---------------         ------------------
1       ODEL11   2836429497       PRIMARY          ODEL11  


Note how only one database was listed, not both. This user (odel11) is allowed to see only one database (ODEL11), and that's what it sees. You can confirm this by connecting to the catalog as the other owner, PRONE3: 

$ rman target=/ rcvcat prone3/prone3@catdb
 
RMAN> list db_unique_name all;
 
 
List of Databases
DB Key  DB Name  DB ID            Database Role    Db_unique_name
-------    ------- -   ----------------         ---------------         ------------------
285     PRONE3   1596130080       PRIMARY          PRONE3              


Virtual catalogs allow you to maintain only one database for the RMAN repository catalog yet establish secure boundaries for individual database owners to manage their own virtual repositories. A common catalog database makes administration simpler, reduces costs, and enables the database to be highly available, again, at less cost.
 
Merging Catalogs
While on the subject of multiple catalogs, let's consider another issue. Now that you've learned how to create virtual catalogs on the same base catalogs, you may see the need to consolidate all these independent repositories into a single one.
One option is to deregister the target databases from their respective catalogs and re-register them to this new central catalog. However, doing so also means losing all those valuable information stored in those repositories. You can, of course, sync the controlfiles and then sync back to the catalog, but that will inflate the controlfile and be impractical.
Oracle Database 11g offers a new feature: merging the catalogs. Actually, it's importing a catalog from one database to another, or in other words, "moving" catalogs.
Let's see how it is done. Suppose you want to move the catalog from database CATDB1 to another database called CATDB2. First, you connect to the catalog database CATDB2 (the target):

$ rman target=/ rcvcat rman/rman@catdb2
 
Recovery Manager: Release 11.1.0.6.0 - Production on Sun Sep 9 23:12:07 2007
 
Copyright (c) 1982, 2007, Oracle.  All rights reserved.
 
connected to target database: ODEL11 (DBID=2836429497)
connected to recovery catalog database


If this database already has a catalog owned by the user "RMAN", then go on to the next step of importing; otherwise, you will need to create the catalog:

RMAN> create catalog;
 
recovery catalog created


Now, you import from the remote catalog (catdb1):

RMAN> import catalog rman/rman@catdb1;
 
Starting import catalog at 09-SEP-07
connected to source recovery catalog database
import validation complete
database unregistered from the source recovery catalog
Finished import catalog at 09-SEP-07
starting full resync of recovery catalog
full resync complete


There are several important information in the above output. Note how the target database got de-registered from its original catalog database. Now if you check the database names in this new catalog:

RMAN> list db_unique_name all;
 
 
List of Databases
DB Key  DB Name  DB ID            Database Role    Db_unique_name
-------    -------     -----------------        ---------------         ------------------
286     PRONE3   1596130080       PRIMARY          PRONE3              
2       ODEL11   2836429497       PRIMARY          ODEL11              


You will notice that the DB Key has changed. ODEL11 was 1 earlier; it's 2 now.

The above operations will import the catalogs of all target databases registered to the catalog database. Sometimes you may not want that—rather, you may want to import only one or two databases. Here is a command to do that:

RMAN> import catalog rman/rman@catdb3 db_name = odel11;


Doing so changes the DB Key again.

What if you don't want to deregister the imported database from the source database during import? In other words, you want to keep the database registered in both catalog databases. You will need to use the "no unregister" clause:

RMAN> import catalog rman/rman@catdb1 db_name = odel11 no unregister;'
 