a

196400_794187286.arc

find . -type f -name "*.196400_794187286.arc" -mtime +5 -print -exec ls -altr  {} \;