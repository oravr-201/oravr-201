#!/bin/bash
export ORACLE_HOME=/u01/app/oracle/product/11.2.0/dbhome_2
export ORACLE_SID=rmandb2
#echo $ORACLE_SID
#echo $ORACLE_HOME
#set -x


count=0                                 # Initialise a counter

while [ $count -lt 3 ]                  # Set up a loop control
do                                      # Begin the loop
    count=`expr $count + 1`             # Increment the counter

date >>/home/oracle/dba/log/rmandb2_online.log
$ORACLE_HOME/bin/rman nocatalog cmdfile=$ORACLE_HOME/rman/rmandb2_online.rman log=/home/oracle/dba/log/rmandb2_online.log append
date >>/home/oracle/dba/log/rmandb2_online.log
echo "=========================" >>/home/oracle/dba/log/rmandb2_online.log


if [ ` tail -31 /home/oracle/dba/log/rmandb2_online.log |grep -i error |wc -l` -ne 0 ]
   then
    LOGMSG="DATABASE BACKUP ENDED IN ERROR"
    sleep 600
   else
    LOGMSG="DATABASE BACKUP COMPLETED SUCESSFULLY"
    count=`expr $count + 3`
fi

done

echo $LOGMSG >> /home/oracle/dba/log/rmandb2_online.log
chage -l oracle >> /home/oracle/dba/log/rmandb2_online.log

TAILED_RMAN_LOG_FILE=/tmp/rman-sitescope-onlinebk-$ORACLE_SID.log
tail -4 /home/oracle/dba/log/rmandb2_online.log > $TAILED_RMAN_LOG_FILE
