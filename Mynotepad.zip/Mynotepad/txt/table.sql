SAPSR3
J_2IEXTRCT

SELECT COUNT(*) FROM DBA_TABLES WHERE OWNER=upper('SAPSR3') AND TABLE_NAME=UPPER('J_2IEXTRCT');

set linesize 190
set pagesize 1000
set feedback off
set trim on
set echo off
col TABLE_NAME for a45
select TABLE_NAME FROM DBA_TABLES WHERE OWNER=upper('SAPSR3') AND TABLE_NAME like UPPER('%J_2IEXTRCT%');

set pages 100
PROMPT
PROMPT General Info:
PROMPT -------------

set linesize 190
col "OWNER.TABLE" for a35
col tablespace_name for a30
col "READONLY" for a8
select t.owner||'.'||t.table_name "OWNER.TABLE",t.TABLESPACE_NAME,t.PCT_FREE
--,t.PCT_USED,d.extents,t.MAX_EXTENTS,t.COMPRESSION,t.READ_ONLY "READONLY",o.created,t.LAST_ANALYZED
,t.PCT_USED,d.extents,t.MAX_EXTENTS,t.COMPRESSION,t.STATUS,o.created,t.LAST_ANALYZED
from dba_tables t, dba_objects o, dba_segments d
where t.owner= upper('SAPSR3')
and t.table_name = upper('J_2IEXTRCT')
and o.owner=t.owner
and o.object_name=t.table_name
and o.owner=d.owner
and t.table_name=d.SEGMENT_NAME;

PROMPT
PROMPT Column Details:
PROMPT ---------------

col Name for a30
desc SAPSR3.J_2IEXTRCT

set pages 0
set echo off heading off feedback off
PROMPT
PROMPT Getting Number of ROWS ...
PROMPT -----------------------

select count(*) from SAPSR3.J_2IEXTRCT;

PROMPT
PROMPT
PROMPT Getting Table Size ...
PROMPT -------------------

--select SUM(BYTES/1024/1024)||'MB' FROM SYS.DBA_EXTENTS WHERE  OWNER = upper('SAPSR3') AND  SEGMENT_NAME = upper('J_2IEXTRCT') GROUP  BY SEGMENT_NAME;
SELECT TRUNC(sum(bytes)/1024/1024)||' MB'
FROM   (SELECT segment_name table_name, owner, bytes
	FROM dba_segments
	WHERE segment_type = 'TABLE'
	UNION ALL
	SELECT l.table_name, l.owner, s.bytes
	FROM dba_lobs l, dba_segments s
	WHERE s.segment_name = l.segment_name
	AND   s.owner = l.owner
	AND   s.segment_type = 'LOBSEGMENT')
WHERE owner in UPPER('SAPSR3')
AND table_name in UPPER('J_2IEXTRCT');


PROMPT
PROMPT
PROMPT INDEXES On the Table:
PROMPT ---------------------

set pages 100
set heading on
COLUMN OWNER FORMAT A25 heading "Index Owner"
COLUMN INDEX_NAME FORMAT A35 heading "Index Name"
COLUMN COLUMN_NAME FORMAT A30 heading "On Column"
COLUMN COLUMN_POSITION FORMAT 9999 heading "Pos"
COLUMN "INDEX" FORMAT A40
COLUMN TABLESPACE_NAME FOR A25
COLUMN INDEX_TYPE FOR A15
SELECT IND.OWNER||'.'||IND.INDEX_NAME "INDEX",
       IND.INDEX_TYPE,
       COL.COLUMN_NAME,
       COL.COLUMN_POSITION,
       IND.TABLESPACE_NAME,
       IND.STATUS,
       IND.UNIQUENESS,
       IND.LAST_ANALYZED
FROM   SYS.DBA_INDEXES IND,
       SYS.DBA_IND_COLUMNS COL
WHERE  IND.TABLE_NAME = upper('J_2IEXTRCT')
AND    IND.TABLE_OWNER = upper('SAPSR3')
AND    IND.TABLE_NAME = COL.TABLE_NAME
AND    IND.OWNER = COL.INDEX_OWNER
AND    IND.TABLE_OWNER = COL.TABLE_OWNER
AND    IND.INDEX_NAME = COL.INDEX_NAME;

PROMPT
PROMPT
PROMPT CONSTRAINTS On the Table:
PROMPT -------------------------

col type format a10
col constraint_name format a40
COL COLUMN_NAME FORMAT A25 heading "On Column"
select	decode(d.constraint_type,
		'C', 'Check',
		'O', 'R/O View',
		'P', 'Primary',
		'R', 'Foreign',
		'U', 'Unique',
		'V', 'Check view') type
,	d.constraint_name
,       c.COLUMN_NAME
,	d.status
,	d.last_change
from	dba_constraints d, dba_cons_columns c
where	d.owner = upper('SAPSR3')
and	d.table_name = upper('J_2IEXTRCT')
and	d.OWNER=c.OWNER
and	d.CONSTRAINT_NAME=c.CONSTRAINT_NAME
order by 1;

PROMPT
PROMPT
PROMPT Foreign Keys WITHOUT INDEX: [Recommended to Index them to Avoid Bad Performance (On OLTP only)]
PROMPT ---------------------------

col constraint_name format a40
COL COLUMN_NAME FORMAT A25 heading "On Column"
select 	acc.CONSTRAINT_NAME,
	acc.COLUMN_NAME,
	acc.POSITION,
	'No Index' Problem
from   	dba_cons_columns acc, 
	dba_constraints ac
where  	ac.CONSTRAINT_NAME = acc.CONSTRAINT_NAME
and   	ac.CONSTRAINT_TYPE = 'R'
and     acc.OWNER =upper('SAPSR3')
and	acc.TABLE_NAME =upper('J_2IEXTRCT')
and     not exists (
        select  'TRUE' 
        from    dba_ind_columns b
        where   b.TABLE_OWNER = acc.OWNER
        and     b.TABLE_NAME = acc.TABLE_NAME
        and     b.COLUMN_NAME = acc.COLUMN_NAME
        and     b.COLUMN_POSITION = acc.POSITION)
order   by acc.OWNER, acc.CONSTRAINT_NAME, acc.COLUMN_NAME, acc.POSITION;

PROMPT
PROMPT
PROMPT DMLs On the Table:
PROMPT -------------------

col TRUNCATED for a9
col LAST_DML_DATE for a13
select INSERTS,UPDATES,DELETES,TRUNCATED,TIMESTAMP LAST_DML_DATE from DBA_TAB_MODIFICATIONS where TABLE_OWNER= upper('SAPSR3') and TABLE_NAME= upper('J_2IEXTRCT');

PROMPT
PROMPT
PROMPT Last ROW In the Table:
PROMPT ----------------------

select * from SAPSR3.J_2IEXTRCT where rowid=(select max(rowid) from SAPSR3.J_2IEXTRCT);
PROMPT
