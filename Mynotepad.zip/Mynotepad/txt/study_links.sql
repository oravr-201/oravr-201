ASM proxy instance 	:	 https://www.hhutzler.de/blog/flex-asm-new-12c-feature/
			 https://www.red-gate.com/simple-talk/sql/oracle/asm-proxy-new-instance-type-in-oracle-12c/
		
multitinanet  12c 	:	 http://www.oracle.com/technetwork/articles/database/multitenant-part1-pdbs-2193987.html


Linux Sccripts colors 	: https://misc.flogisoft.com/bash/tip_colors_and_formatting

oracle on Ec2 	 	:https://arthurdayton.com/2016/02/03/deploying-oracle-database-12c-on-aws-ec2-instance/

		        	https://www.youtube.com/watch?v=Vcdf8qSndOs&t=836s

SQL INJECTION 		: http://www.red-database-security.com/whitepaper/oracle_security_whitepaper.html


















