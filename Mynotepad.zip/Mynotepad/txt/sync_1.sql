select current_scn from v$database;

select current_scn from v$database;


select scn_to_timestamp(1.5882E+10) from dual;
select scn_to_timestamp(1301571) from dual;



stand by:


alter database recover managed standby database cancel;

Shutdown the standby database



primary:

RMAN> run { 
2> allocate channel c1 type disk format '/u01/oraback/%U.rmb'; 
3> backup incremental from scn 1301571 database;
4> }


alter database create standby controlfile as '/u01/oraback/DEL1_standby.ctl';


Copy these files to standby host:

oracle@oradba1 /u01/oraback# scp *.rmb *.ctl oracle@oradba2:/u01/oraback
oracle@oradba2's password:
06l16u1q_1_1.rmb 100% 43MB 10.7MB/s 00:04 
DEL1_standby.ctl 100% 43MB 10.7MB/s 00:04




stand by:
startup nomount
show parameter control_files
copy ctl 

 alter database mount standby database;


rman target=/

catalog start with '/u01/oraback';

recover database;
alter database recover managed standby database disconnect from session;


select current_scn from v$database;
select current_scn from v$database;







