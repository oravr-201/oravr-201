FRA
								show parameter reco
								
								select * from v$flash_recovery_area_usage;
								
								
								sho parameter reco
								SELECT NAME,TO_CHAR(SPACE_LIMIT, '999,999,999,999') AS SPACE_LIMIT,TO_CHAR(SPACE_LIMIT - SPACE_USED + SPACE_RECLAIMABLE,
								'999,999,999,999') AS SPACE_AVAILABLE,
								ROUND((SPACE_USED - SPACE_RECLAIMABLE)/SPACE_LIMIT * 100, 1)
								AS PERCENT_FULL FROM V$RECOVERY_FILE_DEST;
								
								select * from v$flash_recovery_area_usage;
								select sum(PERCENT_SPACE_USED) from v$FLASH_RECOVERY_AREA_USAGE;
								
								set pages 9999
								set lines 200
								SELECT * FROM V$FLASH_RECOVERY_AREA_USAGE;
								
								
								
								
								
								
col name for a50
SELECT NAME,
ROUND(SPACE_LIMIT / 1048576) SPACE_LIMIT_MB,
ROUND(SPACE_USED / 1048576) SPACE_USED_MB,
ROUND(((SPACE_USED / 1048576) * 100) / (SPACE_LIMIT / 1048576), 2) PRC_USED
FROM V$RECOVERY_FILE_DEST;
 


