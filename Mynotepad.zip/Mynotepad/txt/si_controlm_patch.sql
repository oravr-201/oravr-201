scp vishalbh@10.100.101.20:/software/oracle/SOFTWARE/OPatch/Q1_2020/p30464119_121020_Linux-x86-64.zip .

scp vishalbh@10.100.101.20:/software/oracle/SOFTWARE/OPatch/Q1_2020/p30298532_112040_HPUX-IA64.zip .

wpl1tsysdbs01  	       epl1tsysdbs01        
controlm			   ctlmsbe1					alter system set log_archive_dest_state_2=ENABLE;
ccprodw				   ccprode					alter system set log_archive_dest_state_2=ENABLE;
ccarchw				   ccarche					alter system set log_archive_dest_state_2=ENABLE;
cchistw
rcat
ccarche


cchistw
wpl1tsysdbs01
/opt/oracle/product/12.1.0.2/bin/lsnrctl start  LISTENER 
/opt/oracle/product/12.1.0.2/bin/lsnrctl start  lstnr_ccprodw 
/opt/oracle/product/12.1.0.2/bin/lsnrctl start  lstnr_cchistw 
/opt/oracle/product/12.1.0.2/bin/lsnrctl start  lstnr_rcat 
/opt/oracle/product/12.1.0.2/bin/lsnrctl start  LSTNR_CCARCH 
 
epl1tsysdbs01.vitalps.com
/opt/oracle/product/12.1.0.2/bin/lsnrctl start LSTNR_ctlmsbe1
/opt/oracle/product/12.1.0.2/bin/lsnrctl start LSTNR_ccprod 
/opt/oracle/product/12.1.0.2/bin/lsnrctl start LSTNR_ccarch 
/opt/oracle/product/12.1.0.2/bin/lsnrctl start LSTNR_ctlmptch 
/opt/oracle/product/12.1.0.2/bin/lsnrctl start LSTNR_rcat 
/opt/oracle/product/12.1.0.2/bin/lsnrctl start LSTNR_CCHISTE 




dcwhan03			eph1tsysdbs01

siprod				sipsbe1					alter system set log_archive_dest_state_2=ENABLE;
											alter system set log_archive_dest_state_3=ENABLE;
a



/opt/oracle/product/11.2.0.4/bin/lsnrctl start   LSTNR_siprod 
/opt/oracle/product/11.2.0.4/bin/lsnrctl start  LSTNR_rcat 



/opt/oracle/product/11.2.0.4/bin/lsnrctl start  LSTNR_rcat 
/opt/oracle/product/11.2.0.4/bin/lsnrctl start  LSTNR_sipeast 
/opt/oracle/product/11.2.0.4/bin/lsnrctl start  LSTNR_sipsbe1
/opt/oracle/product/11.2.0.4/bin/lsnrctl start  LISTENER 


 