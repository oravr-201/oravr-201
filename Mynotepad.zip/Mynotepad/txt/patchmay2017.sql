select comp_id, comp_name, status, version from dba_registry; 
select owner, count(*)  from dba_objects where status<>'VALID' group by owner; 
select * from registry$history; 
export PATH=$PATH:$ORACLE_HOME/OPatch
export PATH=$ORACLE_HOME/OPatch:$PATH
rmandb2:/home/oracle> !sq
sqlplus / as sysdba

SQL*Plus: Release 11.2.0.4.0 Production on Tue May 9 22:34:20 2017

Copyright (c) 1982, 2013, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.4.0 - 64bit Production
With the Partitioning, OLAP and Data Mining options

SQL> alter system swich logfile;
alter system swich logfile
             *
ERROR at line 1:
ORA-02065: illegal option for ALTER SYSTEM


SQL> alter system switch logfile;

System altered.

SQL> /

System altered.

SQL> /

System altered.

SQL> alter system checkpoint;

System altered.

SQL> /

System altered.
