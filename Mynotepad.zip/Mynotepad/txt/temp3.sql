$ORACLE_HOME/OPatch/ocm/bin/emocmrsp  -no_banner -output $ORACLE_HOME/dbs/ocm.rsp
$ORACLE_HOME/OPatch/ocm/bin/emocmrsp  -no_banner -output $ORACLE_HOME/OPatch/ocm/bin/ocm.rsp

ls -altr $ORACLE_HOME/dbs/ocm.rsp

GRID_DB_PATCH=27475913	
OJVM_PATCH=27475598		
DIR=/dbb/JULY_TWE_PATCHES/27726505	

 sh auto11g.sh  27475913 27475598 /rmana1/patch_bkp_aug_2018_twe/27726505

Atos@12345 

alter user INFA_REPO identified by Q2w3e4r5t6y account unlock ;


BEEVSCOP	H117419	Welcome123

c807194
Aug@2018
c805629
Zapak123$


July2018@12345&12345
ad001\w99aq640

https://www.morganslibrary.org/reference/pkgs/dbms_ash_internal.html




http://www.dbaexpert.com/blog/category/vmware/
https://stefanpanek.wordpress.com/2015/04/21/exadata-faked-storage-server-setup/
https://www.dba.bg/forum/oracle-rdbms-server/server-database-administration/exadata/5055-install-exadata-12-1-2-1-1-150316-2-on-oracle-linux-7-with-oracle-vm-server-manager-3-3-1-for-own-testing-and-preparation-for-exadata-exam-oracle-linux-7-0-installation
https://dbaesp.wordpress.com/2014/01/25/exadata-simulator-2way-rac-1-storage-cell/
http://oracletechdba.blogspot.com/2014/07/oracle-11gr2-installation-in-standalone.html
http://oracletechdba.blogspot.com/2014/06/building-exadata-in-vm-for-learning.html#more
http://oracletechdba.blogspot.com/2014/06/building-exadata-in-vm-for-learning.html

https://oraclegurukul.blogspot.com/2016/11/oracle-exa-data-simulation-setup.html
http://oraclequestionsanswers.blogspot.com/2016/10/steps-to-create-exadata-cell-on-oracle.html
/opt/oracle/cell12.1.2.3.2_LINUX.X64_160721/.install_log.txt


/opt/oracle/cell12.1.2.3.2_LINUX.X64_160721/cellsrv/deploy/wls/wlserver_10.3/common/bin

rpm -ivh jdk-1_5_0_15-linux-amd64.rpm
rpm -ivh cell-11.2.3.2.1_LINUX.X64_130109-1.x86_64.rpm

rpm -Uvh rds-tools-2.0.7-1.12.el5.x86_64.rpm
rpm -Uvh perl-XML-Simple-2.14-4.fc6.0.1.noarch.rpm
rpm -Uvh net-snmp-libs-5.3.2.2-20.0.2.el5.i386.rpm
rpm -Uvh net-snmp-utils-5.3.2.2-20.0.2.el5.x86_64.rpm
rpm -Uvh net-snmp-5.3.2.2-20.0.2.el5.x86_64.rpm
rpm -Uvh perl-XML-Parser-2.34-6.1.2.2.1.x86_64.rpm


https://jongsma.wordpress.com/category/oracle/exadata/



http://exadataengineering.blogspot.com/2017/07/exadatahalf-rack-image-upgrade-rolling.html
https://uhesse.com/exadata/



EVNON

-- Monsanto$2

00018887117717


India7012$
















RUN
{
SET COMMAND ID TO 'RMAN-HOT';
ALLOCATE CHANNEL t1 TYPE 'SBT_TAPE' PARMS="BLKSIZE=262144" format '%d_RMAN-HOT_%U_%s.dbf';
ALLOCATE CHANNEL t2 TYPE 'SBT_TAPE' PARMS="BLKSIZE=262144" format '%d_RMAN-HOT_%U_%s.dbf';
ALLOCATE CHANNEL t3 TYPE 'SBT_TAPE' PARMS="BLKSIZE=262144" format '%d_RMAN-HOT_%U_%s.dbf';
ALLOCATE CHANNEL t4 TYPE 'SBT_TAPE' PARMS="BLKSIZE=262144" format '%d_RMAN-HOT_%U_%s.dbf';
SEND 'NB_ORA_SERV=aopdcmst01,NB_ORA_CLIENT=fgpdcpfocdb01';
RECOVER DATABASE UNTIL TIME '2018-07-28:04:17:48' USING BACKUP CONTROLFILE;
release channel t1;
release channel t2;
release channel t3;
release channel t4;
}
















CNA
vishal-vilas.bandwalkar@atos.net	 Help Help	Sign Out Sign Out
  
From:	melisa.smith@cna.com (Authenticated by cna.com)  Valid Signature Valid Signature (Help)
To:	vishal-vilas.bandwalkar@atos.net
Sent:	Mon Aug 6, 2018 11:13 PM (7 hours ago)
Subject:	[CNA Encrypted E-Mail] CNA New Hire Virtual Machine Details
Attached:	
1. Passage Registration-smartphone.pdf (515k) - View, Download

2. Installing receiver.pdf (220k) - View, Download

3. Passage from outside CNA.PDF (622k) - View, Download

   
Email Encryption Provided by Voltage SecureMail. Learn More
Email Security Powered by Voltage IBE™
© 2009 Continental Casualty Company. CNA is a service mark registered with the United States Patent and Trademark Office.


Virtual Machine Host Name

VW7MSPATSP1142

CID: CAE0735

Employee Id:  238908

Dummy SSN: 777-02-4175 






#ACWT:/ora01/app/oracle/product/10.2_b:Y
RMANDB:/ora01/app/oracle/product/11.2.0/db_1:Y
RMANT1:/ora01/app/oracle/product/11.2.0/db_1:Y
ACWT:/ora01/app/oracle/product/12.1_b:Y
TDMSD:/ora01/app/oracle/product/12.1_b:Y
TDMSX:/ora01/app/oracle/product/12.1_b:Y
TDMST1:/ora01/app/oracle/product/12.1_b:Y
TDMST:/ora01/app/oracle/product/12.1_b:Y
ARRET:/ora01/app/oracle/product/12.1_b:Y
TDMSQ:/ora01/app/oracle/product/12.1_b:Y
*:/ora01/app/oracle/product/10.2_b:N
11.2.0:ora01/app/oracle/product/11.2.0:N
MISCD:/ora01/app/oracle/product/10.2_b:Y
CDB1:/ora01/app/oracle/product/12.1_b:N
TDMSDEV:/ora01/app/oracle/product/12.1_b:N
oracle@moe1a5:/software10G>
oracle@moe1a5:/software10G>


/software10G/combo_patch_april2018

tar -cvf  /software10G/combo_patch_april2018/homebackup1sep2018.tar /ora01/app/oracle/product/12.1_b








USERNAME                  PASSWORD                  ACCOUNT_STATUS          PROFILE         DEFAULT_TABLESPACE   TEMPORARY_TABLESPACE
------------------------- ------------------------- ----------------------- --------------- -------------------- --------------------
DHOOG                     CE92E51C5ED631D9          EXPIRED & LOCKED(TIMED) PROFILE_FGA_USE USERS                USER_TEMP
                                                                            R

alter user DHOOG identified by Dhoog$2018# account unlock;



USERNAME          ACCOUNT_STATUS          PROFILE         DEFAULT_TABLESPACE   TEMPORARY_TABLESPACE
----------------- ----------------------- --------------- -------------------- --------------------
DHOOG             OPEN                    PROFILE_FGA_USE USERS                USER_TEMP
                                          R


										  
										  
										  
										  
										  
										  
										  
										  
										  
										  USERNAME                  PASSWORD                  ACCOUNT_STATUS
------------------------- ------------------------- -----------------------
PROFILE         DEFAULT_TABLESPACE   TEMPORARY_TABLESPACE
--------------- -------------------- --------------------
DHOOG                     CE92E51C5ED631D9          EXPIRED & LOCKED(TIMED)
PROFILE_FGA_USE USERS                USER_TEMP
R

Y:\MgdDB\GF_DBA\oracle\dbms\Windows\64bit\12cR1\12.1.0.2\ojvm\12.1.0.2.180717
Y:\MgdDB\GF_DBA\oracle\dbms\Windows\64bit\12cR1\12.1.0.2\psu\12.1.0.2.180717



d:\app\oracle\product\12.1.0\dbhome_1\OPatch\opatch lsinventory  > D:\JUL_PATCH2018\123.txt


d:\app\oracle\product\12.1.0\dbhome_1\OPatch\datapatch -verbose

D:\JUL_PATCH2018\p27937907_121020_MSWIN-x86-64\27937907\files\bin\oran12.dll 

rename-item "d:\app\oracle\product\12.1.0\dbhome_1\bin\oran12.dll" "d:\app\oracle\product\12.1.0\dbhome_1\bin\oran12vb.dll"
rename-item  "d:\app\oracle\product\12.1.0\dbhome_1\bin\orantcps12.dll"  "d:\app\oracle\product\12.1.0\dbhome_1\bin\orantcps12vb.dll"
rename-item "d:\app\oracle\product\12.1.0\dbhome_1\bin\orantcp12.dll" "d:\app\oracle\product\12.1.0\dbhome_1\bin\orantcp12vb.dll"
rename-item d:\app\oracle\product\12.1.0\dbhome_1\bin\oranl12.dll d:\app\oracle\product\12.1.0\dbhome_1\bin\oranl12vb.dll
rename-item d:\app\oracle\product\12.1.0\dbhome_1\bin\orancrypt12.dll d:\app\oracle\product\12.1.0\dbhome_1\bin\orancrypt12vb.dll



D:\JUL_PATCH2018

D:\JUL_PATCH2018