---------------------------------------------------------------------
----				DATABASE creation CDB TO PDB 	-----
---------------------------------------------------------------------

    1.Put Non CDB in read only
    2.Create XML File
    3.Shutdown Non CDB
    4.Plug in Non CDB as PDB
	
	
	--source : CDB
	
		SQL> startup mount;
		SQL> select name, cdb , open_mode from v$database;         -------(cdb = no and db must be read only or mounted  )
		
	--Run below PLSQL for creating .XML file :
	
		BEGIN
			DBMS_PDB.DESCRIBE(
			pdb_descr_file => '/home/oracle/noncdb.xml');
		END;
		/
		
		cat /home/oracle/noncdb.xml (verify the contents )
		
		SQL> shutdown immediate;
		
		
	--TARGET :  PDB 
			select name, cdb from v$database; 
			
				--check noncdb database datafile location  "/home/oracle/noncdb/datafiles/"
				--create one directory to new pdb database "ls -ltr /home/oracle/pdb1/datafiles/ "
				
		-- before start plugable creation we need to check .xml file is valid or not if valid then you can proceed 
			
				
		set serveroutput on
		DECLARE
			compatible BOOLEAN := FALSE;
		BEGIN  
			compatible := DBMS_PDB.CHECK_PLUG_COMPATIBILITY(
			pdb_descr_file => '/home/oracle/noncdb.xml');
			if compatible then
				DBMS_OUTPUT.PUT_LINE('Is pluggable PDB1 compatible? YES');
			else DBMS_OUTPUT.PUT_LINE('Is pluggable PDB1 compatible? NO');
			end if;
		END;
		/
		
		

		SQL> CREATE PLUGGABLE DATABASE db1 USING '/home/oracle/noncdb.xml'
			 MOVE 
			 FILE_NAME_CONVERT = ('/home/oracle/noncdb/datafiles/', '/home/oracle/pdb1/datafiles/');
			 
	
			--check new pdb datafile "ls -ltr /home/oracle/pdb1/datafiles/"
		
			--once this process will complete  then logon to pdb database 
			
			SQL> alter session set container =pdb1;
			
			--execute the below script (which convert nocdb to pdb )
			
			SQL> @$ORACLE_HOME/rdbms/admin/noncdb_to_pdb.sql
			
			select name, open_mode from v$pdbs; --mounted 
			
			alter pluggable database pdb1 open;
			
			
			
			
			
			
			
			
			
please check below web pages for more reference :

http://www.oracle.com/webfolder/technetwork/tutorials/obe/db/12c/r1/pdb/pdb_unplug_plug/pdb_unplug_plug.html
https://community.toadworld.com/platforms/oracle/b/weblog/archive/2016/04/17/oracle-12c-know-and-understand-your-pdb-s-history
			 --plug or 
			 create pluggable database pdb_plug_nocopy using '/u01/app/oracle/oradata/pdb1.xml'
			 NOCOPY
			 TEMPFILE REUSE;
			 




-------------------------------------------------------------------------------------------------------

----TRIGGER TO OPEN PDBS ON STARTUP 

CREATE OR REPLACE TRIGGER open_pdbs 
  AFTER STARTUP ON DATABASE 
BEGIN 
   EXECUTE IMMEDIATE 'ALTER PLUGGABLE DATABASE ALL OPEN'; 
END open_pdbs;
/

	

CHECK PLUGGABLE DATABABSE HISTORY ;

col PDB_NAME for a20
col CLONED_FROM_PDB_NAME for a20
col DB_NAME for a10
select CON_ID,PDB_NAME,PDB_DBID,OP_TIMESTAMP,OPERATION,CLONED_FROM_PDB_NAME,DB_NAME
from cdb_pdb_history order by con_id;



























