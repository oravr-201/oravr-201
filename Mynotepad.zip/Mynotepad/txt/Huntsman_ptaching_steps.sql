

oracle@beevsdwq PATCH_TWE_OCT17]$ cd 26550684
[oracle@beevsdwq 26550684]$ dir
26027154  26610246  README.html

[oracle@beevsdwq 26027154]$ dir
custom  etc  files  patchmd.xml  postdeinstall.sql  postinstall.sql  README.html  README.txt

[oracle@beevsdwq 26610246]$ dir
22502505  26609445  26609929  bundle.xml  PatchSearch.xml  README.html  README.txt
[oracle@beevsdwq 26610246]$




Patch 26610246 - Oracle Grid Infrastructure Patch Set Update 11.2.0.4.160719 (Oct2017) (Includes Database PSU 11.2.0.4.160719)	
	
DB PSU: 26609445	
OCW:  26609929	
ACFS:  22502505	
	
	
26609445	DB PSU 11.2.0.4.160719 
26609929	OCW PSU 11.2.0.4.160719 
22502505	ACFS PSU 11.2.0.4.160419
 	
ORACLE_HOME:  /u01/app/oracle/product/11.2.0.4	
GRID_HOME:   /u01/app/grid/product/11.2.0.4	
	
1] Shutdown databases and listeners.	
	
2] Take backup of Oracle Home and Grid home using root user.	

cd /dbb/HOME_BKP_OCT17
export GRID_HOME=/u01/app/grid/product/11.2.0.4
tar -cvf grid_homebkp_oct17.tar $GRID_HOME/

	
cp -rp /u01/app/oracle/product/11.2.0.4 /u01/HOME_BKPS/	
	
1)DB Environment:	
srvctl stop home -o /u01/app/oracle/product/11.2.0.4/db_home -s /u01/Patches/HomeStatus.log	
	
2)Root user:	
/u01/app/grid/product/11.2.0.4/crs/install/roothas.pl -unlock	
	
3)Apply OCW ==>ACFS==> DB PSU patch on grid home .	
As GI home owner:--oracle	
Cd /u07/PATCH/23274134	
opatch napply -oh /u01/app/grid/product/11.2.0.4 -local /dbb/PATCH_TWE_OCT17/26550684/26610246/26609929	
opatch napply -oh /u01/app/grid/product/11.2.0.4 -local /dbb/PATCH_TWE_OCT17/26550684/26610246/22502505	
opatch napply -oh /u01/app/grid/product/11.2.0.4 -local /dbb/PATCH_TWE_OCT17/26550684/26610246/26609445	
	
	
	
4)Prepatch---Oracle user	
/dbb/PATCH_TWE_OCT17/26550684/26610246/26609929/custom/server/26609929/custom/scripts/prepatch.sh -dbhome  /u01/app/oracle/product/11.2.0.4	
	
5)Apply db patches--oracle user	
opatch napply -oh /u01/app/oracle/product/11.2.0.4 -local /dbb/PATCH_TWE_OCT17/26550684/26610246/26609929/custom/server/26609929	
opatch apply -oh /u01/app/oracle/product/11.2.0.4 -local /dbb/PATCH_TWE_OCT17/26550684/26610246/26609445	
	
6)Postpatch script--oracle user	
/dbb/PATCH_TWE_OCT17/26550684/26610246/26609929/custom/server/26609929/custom/scripts/postpatch.sh -dbhome /u01/app/oracle/product/11.2.0.4	
	
7)Root user	
/u01/app/grid/product/11.2.0.4/rdbms/install/rootadd_rdbms.sh	
/u01/app/grid/product/11.2.0.4/crs/install/roothas.pl -patch	
	
8)Start home--oracle user	
srvctl start home -o  /u01/app/oracle/product/11.2.0.4/db_home -s /u01/Patches/HomeStatus.log	
	
9)Postpatch installation on Databases:	
startup;	
@?/rdbms/admin/catbundle.sql psu apply	
@?/rdbms/admin/utlrp.sql	



SET linesize 200 pagesize 200�
col action_time FOR a28�
col version FOR a10�
col comments FOR a35�
col action FOR a25�
col namespace FOR a12�
SELECT * FROM registry$history;
select OWNER,OWNER,OBJECT_ID,OBJECT_NAME,LAST_DDL_TIME,STATUS from dba_objects where status='INVALID';
