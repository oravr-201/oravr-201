	SET ECHO        OFF
	SET FEEDBACK    6
	SET HEADING     ON
	SET LINESIZE    180
	SET PAGESIZE    50000
	SET TERMOUT     ON
	SET TIMING      OFF
	SET TRIMOUT     ON
	SET TRIMSPOOL   ON
	SET VERIFY      OFF

	CLEAR COLUMNS
	CLEAR BREAKS
	CLEAR COMPUTES

	COLUMN status      FORMAT a9                 HEADING 'Status'
	COLUMN name        FORMAT a30                HEADING 'Tablespace Name'
	COLUMN type        FORMAT a15                HEADING 'TS Type'
	COLUMN extent_mgt  FORMAT a10                HEADING 'Ext. Mgt.'
	COLUMN segment_mgt FORMAT a10                HEADING 'Seg. Mgt.'
	COLUMN ts_size     FORMAT 9,999,999,999,999.99  HEADING 'Tablespace Size'
	COLUMN used        FORMAT 9,999,999,999,999.99  HEADING 'Used (in bytes)'
	COLUMN free        FORMAT 9,999,999,999,999.99  HEADING 'Free (in bytes)'
	COLUMN pct_used    FORMAT 999.99                HEADING 'Pct. Used'


	BREAK ON report

	COMPUTE sum OF ts_size  ON report
	COMPUTE sum OF used     ON report
	COMPUTE sum OF free     ON report
	COMPUTE avg OF pct_used ON report
	SELECT
	    d.status                                            status
	  , d.tablespace_name                                   name
	  , d.contents                                          type
	  , d.extent_management                                 extent_mgt
	  , d.segment_space_management                          segment_mgt
	  , NVL(a.bytes/1024/1024, 0)                                     ts_size
	  , NVL(a.bytes/1024/1024 - NVL(f.bytes/1024/1024, 0), 0)                   used
	  -- , NVL(f.bytes, 0)                                     free
	  , NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0) pct_used
	FROM
	    sys.dba_tablespaces d
	  , ( select tablespace_name, sum(bytes) bytes
	      from dba_data_files
	      group by tablespace_name
	    ) a
	  , ( select tablespace_name, sum(bytes) bytes
	      from dba_free_space
	      group by tablespace_name
	    ) f
	WHERE
	      d.tablespace_name = a.tablespace_name(+)
	  AND d.tablespace_name = f.tablespace_name(+)
	  AND NOT (
	    d.extent_management like 'LOCAL'
	    AND
	    d.contents like 'TEMPORARY'
	  )
	UNION ALL
	SELECT
	    d.status                         status
	  , d.tablespace_name                name
	  , d.contents                       type
	  , d.extent_management              extent_mgt
	  , d.segment_space_management       segment_mgt
	  , NVL(a.bytes/1024/1024, 0)                  ts_size
	  , NVL(t.bytes/1024/1024, 0)                  used
	  -- , NVL(a.bytes/1024/1024 - NVL(t.bytes,0), 0) free
	  , NVL(t.bytes / a.bytes * 100, 0)  pct_used
	FROM
	    sys.dba_tablespaces d
	  , ( select tablespace_name, sum(bytes) bytes
	      from dba_temp_files
	      group by tablespace_name
	    ) a
	  , ( select tablespace_name, sum(bytes_cached) bytes
	      from v$temp_extent_pool
	      group by tablespace_name
	    ) t
	WHERE
	      d.tablespace_name = a.tablespace_name(+)
	  AND d.tablespace_name = t.tablespace_name(+)
	  AND d.extent_management like 'LOCAL'
	  AND d.contents like 'TEMPORARY'
	ORDER BY
	  2;






---TO CHECK TABLESPACE SPACE GREATER THAN 85%


comp sum of totsiz avasiz usage on report
set TAB off
break on report         skip 3
break on page           skip 3
col tsname  format         a25 justify c heading 'Tablespace'
col totsiz  format 999,999,990 justify c heading 'Total|(KB)'
col usage   format 999,999,990 justify c heading 'Used |(KB)'
col pctusd  format         990 justify c heading 'Pct|Used'
col avasiz  format 999,999,990 justify c heading 'Available|(KB)'
col pctAva  format         990 justify c heading 'Pct|Available'

select
  total.tablespace_name                            tsname,
  total.bytes/1024                                 totsiz,
  (total.bytes/1024)-(nvl(sum(free.bytes)/1024,0)) usage,
  (1-nvl(sum(free.bytes),0)/total.bytes)*100       pctusd,
  nvl(sum(free.bytes)/1024,0)                      avasiz,
  ((nvl(sum(free.bytes)/1024,0))/(total.bytes/1024))*100   pctAva
from
  aps_data_files  total,
  dba_free_space  free
where
  total.tablespace_name = free.tablespace_name(+)
AND
  total.tablespace_name != 'UNDO'
group by
  total.tablespace_name
, total.bytes
having
(total.bytes/1024 >= 140000000 and (1-nvl(sum(free.bytes),0)/total.bytes)*100 >= 95)
or
(total.bytes/1024 < 140000000 and (1-nvl(sum(free.bytes),0)/total.bytes)*100 >= 90)
order by tsname
/























tablespace space details 	:
								SELECT TABLESPACE_NAME,SUM(BYTES)/1024/1024 "FREE SPACE(MB)" FROM DBA_FREE_SPACE GROUP BY TABLESPACE_NAME;
								
								select FILE_NAME,BYTES/1024/1024/1024,file_id from dba_data_files where TABLESPACE_NAME='&Tablespace_name' order by FILE_ID;
								
tablespace space percetage :
									
								
								
								set lines 500
								col tablespace_name for a25
								SELECT a.tablespace_name, ROUND (a.bytes_alloc / 1024 / 1024, 2) ALLOCATED_MB,
								ROUND (NVL (b.bytes_free, 0) / 1024 / 1024, 2) FREE_MB,
								ROUND ((a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024,2) USED_MB,
								ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) "% FREE",
								100 - ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) "% USED",
								ROUND (maxbytes / 1048576, 2) MAXBYTES,
								round(100-(ROUND ((a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024,2)*100/ROUND (maxbytes / 1048576, 2)),2) "% MAX_Free"
								FROM
								(SELECT f.tablespace_name, SUM (f.BYTES) bytes_alloc,SUM (DECODE (f.autoextensible,'YES', f.maxbytes,'NO', f.BYTES)) maxbytes FROM dba_data_files f GROUP BY tablespace_name) a,
								(SELECT f.tablespace_name, SUM (f.BYTES) bytes_free FROM dba_free_space f GROUP BY tablespace_name) b�
								WHERE a.tablespace_name = b.tablespace_name(+)
								and a.tablespace_name='&TBS_NAME'

										
								
tablespace file_id				select FILE_NAME,bytes/1024/1024 from dba_DATA_files where tablespace_name='SYSAUX' order by file_id
								
								
														
													
							
								set pagesize 2000 line 150
								col tablespace_name for a20
								SELECT SUBSTR(df.tablespace_name,1,20) tablespace_name, df.bytes/1024/1024 allocated_mb,(df.bytes-nvl(dfs.bytes,0))/1024/1024 used_mb,
								NVL(dfs.bytes/1024/1024,0) free_space_mb, round((df.bytes-nvl(dfs.bytes,0))/df.bytes*100,2) percent_used
								FROM (select sum(bytes) bytes, tablespace_name from dba_data_files group by tablespace_name) df,
								(select sum(bytes) bytes,tablespace_name from dba_free_space group by tablespace_name) dfs
								WHERE df.tablespace_name = dfs.tablespace_name (+) and df.tablespace_name='&TABLESPACE_NAME';
								
								
								
								SELECT a.tablespace_name, ROUND(a.totsize/1024/1024,0) "Tot Size (MB)",ROUND(NVL(b.used,0)/1024/1024,0) "Used (MB)",
								100 - ROUND(((a.totsize - NVL(b.used,0)) / a.totsize) * 100,0) "% Used", ROUND(((a.totsize -
								NVL(b.used,0)) / a.totsize) * 100,0) "% sFree"
								FROM
								SELECT tablespace_name, SUM(bytes) totsize FROM dba_data_files GROUP BY tablespace_name) a,
								SELECT tablespace_name, SUM(bytes) used FROM dba_segments
								GROUP BY tablespace_name) b
								WHERE a.tablespace_name=b.tablespace_name (+)
								ORDER BY 1;
							
Tablespace Growth
								set linesize 120
								column name format a15
								column variance format a20
								alter session set nls_date_format='yyyy-mm-dd';
								with t as (
								select ss.run_time,ts.name,round(su.tablespace_size*dt.block_size/1024/1024/1024,2) alloc_size_gb,
								round(su.tablespace_usedsize*dt.block_size/1024/1024/1024,2) used_size_gb
								from
								dba_hist_tbspc_space_usage su,
								(select trunc(BEGIN_INTERVAL_TIME) run_time,max(snap_id) snap_id from dba_hist_snapshot 
								group by trunc(BEGIN_INTERVAL_TIME) ) ss,
								v$tablespace ts,
								dba_tablespaces dt
								where su.snap_id = ss.snap_id
								and su.tablespace_id = ts.ts#
								and ts.name =upper('&TABLESPACE_NAME')
								and ts.name = dt.tablespace_name )
								select e.run_time,e.name,e.alloc_size_gb,e.used_size_gb curr_used_size_gb,b.used_size_gb prev_used_size_gb,
								case when e.used_size_gb > b.used_size_gb then to_char(e.used_size_gb - b.used_size_gb)
									when e.used_size_gb = b.used_size_gb then '***NO DATA GROWTH'
									when e.used_size_gb < b.used_size_gb then '******DATA PURGED' end variance
								from t e, t b
								where e.run_time = b.run_time + 1
								order by 1;				
					
					
Undo Tablespace


select s.username,s.sid, t.XIDusn "Undo seg no.",t.ubafil "uba file no.",t.ubablk 
"uba blk no.",(t.used_ublk*8)/1024 "Undo Blocks Used",t.LOG_IO,t.PHY_IO
from v$session s ,v$transaction t where s.saddr=t.ses_addr;

	
	
col sid_serial for a15
SELECT
--r.name rbs,
��������nvl(s.username, 'None') oracle_user,
-- s.osuser client_user,
-- p.username unix_user,
��������to_char(s.sid)||','||to_char(s.serial#) as sid_serial,
-- p.spid unix_pid,
-- TO_CHAR(s.logon_time, 'mm/dd/yy hh24:mi:Ss') as login_time,
-- TO_CHAR(sysdate - (s.last_call_et) / 86400,'mm/dd/yy hh24:mi:Ss') as last_txn,
��������round(t.used_ublk * TO_NUMBER(x.value)/1024/1024,2) as undo_mb,(SELECT ROUND(SUM(max_mb)) MAX_SZ_MB
FROM ( SELECT tablespace_name, SUM(bytes)/1024/1024 FREE_MB, 0 TOTAL_MB, 0 MAX_MB FROM dba_free_space GROUP BY tablespace_name UNION
SELECT tablespace_name, 0 CURRENT_MB,
SUM(bytes)/1024/1024 TOTAL_MB,
SUM(DECODE(maxbytes,0,bytes, maxbytes))/1024/1024 MAX_MB FROM dba_data_files GROUP BY tablespace_name)
where tablespace_name=(select value from v$parameter where name='undo_tablespace') ) AS UNDO_SIZE FROM v$process p,
��������v$rollname r,
��������v$session s,
��������v$transaction t,
��������v$parameter x
��WHERE s.taddr = t.addr
����AND s.paddr = p.addr(+)
����AND r.usn = t.xidusn(+)
����AND x.name = 'db_block_size'
��ORDER BY r.name;
							
							
							
							
Temp
							select tablespace_name,sum(bytes/1024/1024) from dba_temp_files group by tablespace_name;
							
							select file_name,bytes/1024/1024 from dba_temp_files;
							
							
							
							
							select file_name,tablespace_name,ROUND(sum(bytes)/1024/1024/1024) from dba_temp_files where tablespace_name='&TMP3'  group by file_name,tablespace_name
							
							select file_name,tablespace_name ,AUTOEXTENSIBLE  from dba_temp_files where tablespace_name='&TMP4';
							
							alter database tempfile '/cub/oradata39/TMP3_04.gm' resize 10g;
							
							
							alter database tempfile '/cub/oradata39/TMP3_04.gm' AUTOEXTEND ON MAXSIZE UNLIMITED;
							
			
							
							
							
select 'ALTER index ' || OWNER || '.' || INDEX_NAME || ' rebuild ;' from dba_indexes where owner = 'PERFSTAT';
select 'ALTER table ' || OWNER || '.' || TABLE_NAME || ' enable row movement;' from dba_tables where owner = 'PERFSTAT';
select 'ALTER table ' || OWNER || '.' || TABLE_NAME || ' shrink space;' from dba_tables where owner = 'PERFSTAT';
	
							
							
							
							
------------------------------------------------------------------------------------------------------------
					
TEmp used space :
------------------------------------------------------------------------------------------------------------
set lines 152
col FreeSpaceGB format 999.999
col UsedSpaceGB format 999.999
col TotalSpaceGB format 999.999
col host_name format a30
col tablespace_name format a30
select tablespace_name,
(free_blocks*8)/1024/1024 FreeSpaceGB,
(used_blocks*8)/1024/1024 UsedSpaceGB,
(total_blocks*8)/1024/1024 TotalSpaceGB,
i.instance_name,i.host_name
from gv$sort_segment ss,gv$instance i where ss.tablespace_name in (select tablespace_name
from dba_tablespaces where contents='TEMPORARY') and i.inst_id=ss.inst_id;						
	

col name for a20
SELECT d.status "Status", d.tablespace_name "Name", d.contents "Type", d.extent_management
"ExtManag",
TO_CHAR(NVL(a.bytes / 1024 / 1024, 0),'99,999,990.900') "Size (M)", TO_CHAR(NVL(t.bytes,
0)/1024/1024,'99999,999.999') ||'/'||TO_CHAR(NVL(a.bytes/1024/1024, 0),'99999,999.999') "Used (M)",
TO_CHAR(NVL(t.bytes / a.bytes * 100, 0), '990.00') "Used %"
FROM sys.dba_tablespaces d, (select tablespace_name, sum(bytes) bytes from dba_temp_files group by
tablespace_name) a,
(select tablespace_name, sum(bytes_cached) bytes from
v$temp_extent_pool group by tablespace_name) t
WHERE d.tablespace_name = a.tablespace_name(+) AND d.tablespace_name = t.tablespace_name(+)
AND d.extent_management like 'LOCAL' AND d.contents like 'TEMPORARY';







cursor bigtemp_sids is
select * from (
select s.sid,
s.status,
s.sql_hash_value sesshash,
u.SQLHASH sorthash,
s.username,
u.tablespace,
sum(u.blocks*p.value/1024/1024) mbused ,
sum(u.extents) noexts,
nvl(s.module,s.program) proginfo,
floor(last_call_et/3600)||':'||
floor(mod(last_call_et,3600)/60)||':'||
mod(mod(last_call_et,3600),60) lastcallet
from v$sort_usage u,
v$session s,
v$parameter p
where u.session_addr = s.saddr
and p.name = 'db_block_size'
group by s.sid,s.status,s.sql_hash_value,u.sqlhash,s.username,u.tablespace,
nvl(s.module,s.program),
floor(last_call_et/3600)||':'||
floor(mod(last_call_et,3600)/60)||':'||
mod(mod(last_call_et,3600),60)
order by 7 desc,3)
where rownum < 11;
	
------------------------------------------------------------------------------------------------------------
							
							
							
							
							
							
							
							