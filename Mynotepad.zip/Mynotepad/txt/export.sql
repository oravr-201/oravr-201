expdp =AUTOMIC estimate_only=y


create directory VB_DUMPS  as '/opt/oracle/gi_software/vb_dumps';
GRANT read, write ON DIRECTORY VB_DUMPS TO public; 

expdp "'/ as sysdba'" directory=exp_AUTOMIC_bkp dumpfile=exp_AUTOMIC_ODSBEP1_bkp_26Jan17_%U.dmp logfile=exp_AUTOMIC_ODSBEP1_bkp.log   schemas=AUTOMIC   parallel=3 job_name=xyz & 

expdp "'/ as sysdba'"  full=y estimate_only=y






Sie6_orac6e_db6 
March$123 - a548609 




nohup impdp '"/ as sysdba"' directory=DP_DIR dumpfile=EXPDP_1649788_EPROG_Schemarefresh.dmp logfile=IMPDP_1649788_EPROG_Schemarefresh.log schemas=EPROG  STATISTICS=NONE &


select 'alter system kill session ''||SID||'',''||SERIAL#||'' IMMEDIATE;' from v$session where username='EPROG';


select 'alter system kill session '''||SID||','||SERIAL#||' IMMEDIATE '';' from v$session where username = 'EPROG' ;

select 'alter system kill session ''||SID||','||SERIAL#||'' IMMEDIATE;' from v$session where username='EPROG';





nohup expdp "'/ as sysdba'" DIRECTORY=EXPORT_26_MAY_17_CHEMMATE dumpfile=expdp_21jun17_CHEMMATE_%U.dmp logfile=expdp_21jun17_CHEMMATE.log schemas=CHEMMATE parallel=6 job_name=expdp_21jun17 &


nohup impdp "'/ as sysdba'" directory=EXPDIR dumpfile=expdp_21jun17_CHEMMATE_%U.dmp parallel=6 logfile=impdp_dtp19_CHEMMATE_21June2017_new.log schemas=CHEMMATE job_name=impdp_chemmate &




























baan1=green
tail -10f impdp_baan1_24Mar2017.log
=================================================================================================================================
export ====bann2=white
nohup expdp "'/ as sysdba'" full=Y directory=BAAN2_EXPORT_DIR dumpfile=baan2_fullexport_23March2017.dmp logfile=baan2_fullexport_23March2017.log job_name=baan2_fullbackup &
16301
nohup scp baan2_fullexport_23March2017.dmp oracle@136.157.166.36:/exp/baan2 &
==================================================================================================================================
import  ====baan3=pink                                                            
nohup impdp "'/ as sysdba'" directory=export dumpfile=baan3_fullexport_24March2017.dmp logfile=baan3_fullexport_24March2017.log full=Y &
1196
=================================================================================================================================