
----ASm Disk addition :

1. check the disk status :

	col PATH for a40
	set lines 150
	set pages 100
	col NAME for a20
	col ASM_GROUP for a10
	
	select adg.name ASM_GROUP, ad.disk_number, ad.name,ad.header_status, ad.mode_status,ad.REDUNDANCY, ad.path, ad.voting_file
	from v$asm_diskgroup adg, v$asm_disk ad where   adg.group_number = ad.group_number and adg.name='TEST' order by adg.name,ad.disk_number; 

2. You can add disk in disk group using three ways mention below.

	a.asmca -silent -addDisk -diskGroupName AUDDATA -disk '/dev/rhdisk417' -diskName AUDDATA_0000 -redundancy EXTERNAL 
	b.using asmca GUI  Please find attached screen print for same. 
	
	c.ALTER DISKGROUP AUDDATA ADD DISK '/DEV/RHDISK417' NAME AUDDATA_0000; 
	
3. Increase rebalancing :

	select operation, state,power, actual, sofar, est_work, est_minutes from v$asm_operation;

	ALTER DISKGROUP <DISK GROUP NAME> REBALANCE POWER 4; 			---- we can increase powe up to 12
	
4. Drop disk 
	we can drop after all rebancing opration performed .
	
	ALTER DISKGROUP AUDDATA DROP  DISK '<DISK_NAME>' ;

5. check the disk status :
	
	select disk_number, header_status, mode_status, path, voting_file 
	from v$asm_disk;
	--where header_status = 'FORMER' order by disk_number; ---- which was the part of diskgroup
	--where header_status = 'MEMBER' order by disk_number; -----wchich is the part of diskgroup currently uning 
	--where header_status = 'CANDIDATE' order by disk_number;---fresh disk 
	--where header_status = 'FORMER' order by disk_number;----Disk is not part of a disk group and may be added to a disk group with the ALTER
	
	
	



----ASM COPY FILES :


copy command : 
		ASM to filesystem -->
		ASMCMD> cp dumpfile1.dmp dumpfile1.dmp dumpfile1.dmp /oracle/backup/testdb/expdp
				copying +FRA/TESTDB/EXPDP/dumpfile1.dmp -> /oracle/backup/testdb/expdp/dumpfile1.dmp
				copying +FRA/TESTDB/EXPDP/dumpfile2.dmp -> /oracle/backup/testdb/expdp/dumpfile2.dmp
				copying +FRA/TESTDB/EXPDP/dumpfile3.dmp -> /oracle/backup/testdb/expdp/dumpfile3.dmp	
		
		�File system to asm : -->
		ASMCMD> cp /oracle/backup/testdb/expdp/dumpfile1.dmp '+FRA/TESTDB/EXPDP/'
				copying /oracle/backup/testdb/expdp/dumpfile1.dmp -> +FRA/TESTDB/EXPDP/dumpfile1.dmp
		ASMCMD> cp /oracle/backup/testdb/expdp/dumpfile2.dmp '+FRA/TESTDB/EXPDP/'
				copying /oracle/backup/testdb/expdp/dumpfile2.dmp -> +FRA/TESTDB/EXPDP/dumpfile2.dmp
		ASMCMD> cp /oracle/backup/testdb/expdp/dumpfile3.dmp '+FRA/TESTDB/EXPDP/'
				copying /oracle/backup/testdb/expdp/dumpfile3.dmp -> +FRA/TESTDB/EXPDP/dumpfile3.dmp 
		ASMCMD> ls
				dumpfile1.dmp
				dumpfile2.dmp
				dumpfile3.dmp
		
		OR  
				set timing on
				BEGIN
				dbms_file_transfer.get_file('SOURCE_DUMP',
				'test.dmp',
				'SOURCEDB',
				'TARGET_DUMP',
				'test.dmp');
				END;
				/
				
		OR
		
		RMAN> copy datafile '/u01/oradata/racdb/trtst01.dbf' to '+DATADG';
		
		RMAN> COPY DATAFILE '+ASMDISK2/orcl/datafile/users.256.565313879' TO '+ASMDISK1';

	�If you have used RMAN (method 4 b) use the following option of RMAN 
		RMAN>
		run 
		{ 
		set newname for datafile '+ASMDISK2/orcl/datafile/users.256.565313879' 
		to '+ASMDISK1/orcl/datafile/users.259.565359071'; 
		switch datafile all; 
		} 
		
	�Delete the datafile from its original location.

		SQL> ALTER DISKGROUP ASMDISK2 DROP FILE users.256.565313879;
		or
		ASMCMD> rm -rf <filename>
		
		
		
