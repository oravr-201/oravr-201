-- Purging time -- on all four databases.

select trunc(created_date),ROUND ( (  TO_DATE ( TO_CHAR (Batch_End_Time, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy hh24:mi:ss') - TO_DATE ( TO_CHAR (Batch_start_Time, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy hh24:mi:ss')) * (24 * 60), 2) Puring_Time_in_Min
 from Purgedata.Trns_Purge_Batch_Info
 order by 1 desc;
 
 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 -- Average transaction processing Report -- TE or TW

select TRUNC(SERVER_TIMESTAMP) server_date, round(avg(processing_time_in_sec),2) average_processing_time 
from transnox_iox.REQUEST_AUDIT_TRAIL
WHERE SERVER_TIMESTAMP >= TO_DATE ('15-01-2019  00:00:00', 'dd-mm-yyyy  hh24:mi:ss') -- AND TO_DATE ('22-Sep-2019 23:59:59', 'dd-mon-yyyy hh24:mi:ss')
and SUBSERVICE_CODE = 'AUTH'
         AND ADAPTOR_PROCESSING_TIME_IN_SEC > 0.5
           AND PROCESSING_TIME_IN_SEC- ADAPTOR_PROCESSING_TIME_IN_SEC  > 0.5 
           and  processing_time_in_sec < 5
group by TRUNC(SERVER_TIMESTAMP)
order by 1 desc;    

 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 
-- Total time outs in a day for reporting RPT

SELECT report_date, SUM (timeout_counts) total_time_outs
    FROM (  SELECT report_date,
                   REPLACE (report_id_1, ',', '') report_id,
                   COUNT (1) timeout_counts
              FROM (SELECT report_date,
                           Report_id,
                           (CASE
                               WHEN SUBSTR (report_id,
                                            1,
                                            INSTR (report_id, ' ', 1))
                                       IS NULL
                               THEN
                                  report_id
                               WHEN SUBSTR (report_id,
                                            1,
                                            INSTR (report_id, ' ', 1))
                                       IS NOT NULL
                               THEN
                                  SUBSTR (report_id,
                                          1,
                                          INSTR (report_id, ' ', 1))
                            END)
                              report_id_1,
                           TO_NUMBER (
                              TRIM (REPLACE (processing_time, 'Sec', '')))
                              processing_time
                      FROM (SELECT TRUNC (start_date) report_date,
                                   SUBSTR (parameter_list,
                                           INSTR (parameter_list, '=>', 1) + 3,
                                           35)
                                      Report_id,
                                   processing_time
                              FROM TRANSNOX_IOX.REPORT_USAGE_AUDITTRAIL rua
                             WHERE     rua.start_date >=
                                          TO_DATE ('15-01-2020 00:00:00',
                                                   'DD-MM-YYYY HH24:MI:SS')
                                   --rua.start_date BETWEEN TO_DATE ('01-01-2020  00:00:00', 'DD-MM-YYYY  HH24:MI:SS') AND TO_DATE ('22-SEP-2019 23:59:59', 'DD-MON-YYYY HH24:MI:SS')
                                   AND processing_time IS NOT NULL AND length(processing_time)<15))
             WHERE report_id IS NOT NULL AND processing_time > 180
          GROUP BY report_id_1, report_date)
GROUP BY report_date;
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 -- Deadlock count --TXN
 select trunc(EXECUTEDON), count(1) from TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP
where OBJECT_NAME ='CAPTURE_HARMONY_SETTLE_PRE'
and output_msg <> 'Success'
group by trunc(EXECUTEDON)
order by 1 desc

 
 
SELECT TRUNC (EXECUTEDON), COUNT (1)
    FROM TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP
   WHERE     OBJECT_NAME = 'CAPTURE_HARMONY_SETTLE_PRE'
         AND output_msg <> 'SUCCESS'
         AND EXECUTEDON >=
                TO_DATE ('15-01-2020  00:00:00', 'DD-MM-YYYY  HH24:MI:SS')
GROUP BY TRUNC (EXECUTEDON)
ORDER BY 1 DESC
 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 
-----  Transaction taking more than 10 seconds to process Report

select trunc(transacting_date), sum(gateway_processing_tran_count) gateway_processing_tran_count, sum(adaptor_processing_tran_count) adaptor_processing_tran_count, sum(total_processing_time) total_processing_time_count
from
(
select transacting_date, (case when gateway_processing_time > 10 then 1 else 0 end) gateway_processing_tran_count, (case when ADAPTOR_PROCESSING_TIME_IN_SEC>10 then 1 else 0 end) adaptor_processing_tran_count, ( case when PROCESSING_TIME_IN_SEC > 10 then 1 else 0 end ) total_processing_time
from
(
select  to_date(to_char(SERVER_TIMESTAMP,'MM/DD/YYYY HH24:MI'),'MM/DD/YYYY HH24:MI') transacting_date,transaction_id, (PROCESSING_TIME_IN_SEC-ADAPTOR_PROCESSING_TIME_IN_SEC)  gateway_processing_time,ADAPTOR_PROCESSING_TIME_IN_SEC, PROCESSING_TIME_IN_SEC
from TRANSNOX_IOX.REQUEST_AUDIT_TRAIL RAT
where RAT.SERVER_TIMESTAMP >= TO_DATE ('15-01-2020  00:00:00', 'dd-mm-yyyy  hh24:mi:ss') --between trunc(sysdate-1) and trunc(sysdate)
and REQUEST_MESSAGE  in ('TransactionAdjustment','Auth','Void','CardAuthentication','Capture','CardRQ','CheckRQ','Sale','Ach','TipAdjustment','CardVerification','CashSale','DebitSale','Return','ForcedAuth') 
and PROCESSING_TIME_IN_SEC > 10 and (PROCESSING_TIME_IN_SEC IS NOT NULL AND ADAPTOR_PROCESSING_TIME_IN_SEC IS NOT NULL)
)
)
group by trunc(transacting_date)
order by 1 desc;
 
 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 --sattelment TXN
 
 select recon_time||':45:00' recon_time,groups_created,total_transaction_count,batches_posted,db_execution_time,JOB_START_TIME,JOB_END_TIME,total_job_exec_time_in_sec, settled_transaction_count
from 
(
select to_char(to_date(substr(input_string,52,19),'DD-MM-YYYY HH24:MI:SS'),'MM/DD/YYYY HH24') recon_time,sum(rec_count) total_transaction_count,max(execution_time) db_execution_time,count(1) groups_created
from TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP 
where object_name  = 'CAPTURE_HARMONY_SETTLE_PRE' and  executedon  > to_date('01/15/2019 00:00:00','MM/DD/YYYY HH24:MI:SS')  and OUTPUT_MSG = 'Success'
group by to_char(to_date(substr(input_string,52,19),'DD-MM-YYYY HH24:MI:SS'),'MM/DD/YYYY HH24') 
) a,
(
select job_execution_id, job_date,JOB_START_TIME,JOB_END_TIME,
  EXTRACT(Day FROM(JOB_END_TIME-JOB_START_TIME) DAY TO SECOND)*86400 +
 EXTRACT(HOUR FROM(JOB_END_TIME-JOB_START_TIME) DAY TO SECOND)*3600 +
 EXTRACT(Minute FROM (JOB_END_TIME-JOB_START_TIME) DAY TO SECOND)*60 +
 EXTRACT(SECOND FROM(JOB_END_TIME-JOB_START_TIME) DAY TO SECOND) as total_job_exec_time_in_sec
 from
 (
 select job_execution_id,to_char(START_TIME,'MM/DD/YYYY HH24') job_date, min(START_TIME)  JOB_START_TIME,  max(end_time) JOB_END_TIME
 from TRANSNOX_IOX.BATCH_STEP_EXECUTION where step_name like 'slave%' and status  = 'COMPLETED' and START_TIME  > to_date('01/15/2019 00:00:00','MM/DD/YYYY HH24:MI:SS') 
 group by job_execution_id,to_char(START_TIME,'MM/DD/YYYY HH24')
 )
) b,
(
select to_char(settle_date,'MM/DD/YYYY HH24') settle_date,batch_status,count(distinct ssb.batch_seq_id) batches_posted,count(ts.transaction_id) settled_transaction_count 
from TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH ssb, transnox_iox.trans_settlement ts 
where SSB.BATCH_SEQ_ID = TS.BATCH_SEQ_ID and batch_status = 'SUCCESS' and settle_date > to_date('01/15/2019 00:00:00','MM/DD/YYYY HH24:MI:SS') and time_stamp >  to_date('01/15/2019 00:00:00','MM/DD/YYYY HH24:MI:SS')
group by to_char(settle_date,'MM/DD/YYYY HH24'),batch_status
) c
where a.recon_time = b.job_date and a.recon_time = c.settle_date
order by job_start_time desc
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------