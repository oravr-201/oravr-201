--------------------------------------------------------------
------ TO CHECK FILE SYSTEM SPACE AND -----------------------
--------------------------------------------------------------

#!/bin/bash  

# User specific environment and startup programs 
. ~/.bash_profile 

#ecking the /data disk partition space where archive files are getting created 
VAL=`df -h | grep "/ora4" | awk '{print $5}'|sed 's/%//g'` 

if [ "$VAL" -gt "65" ] 
then 
    echo "Disk value $VAL" 
    echo "Disk space above 60%" 

    cd /ora4/oracle/aqprod/archive 

    find *.dbf -type f -mtime +1 -exec ls -l {} \; > temp_file.sh 

    for fn in `cat temp_file.sh |awk '{print $9}'` 
     do 
       echo "$fn" 
       # deleting non tar files 
       rm -f $fn 
    done 

    rm -f temp_file.sh 
else 
    echo "$VAL" 
    echo "Disk space is below 60%" 
fi 
=========================================================================================================

CHECK disk SPACE (MULTIPLE)

#!/bin/bash 
for ID in `df -h | grep -v none | grep -v Filesystem | grep -v "/" | grep -v -w "home"| awk '{if ($5 > "80%") print $1 " " $5}' | sed 's/ /=/g'` 

do 
        echo $ID | sed 's/=/ /g' 
        excecute the script 
done 

=========================================================================================================



#ORACLE_SID=FOCUSPRF;
#ORACLE_HOME=/appl/oracle/product/v102;
#export $ORACLE_SID
#export $ORACLE_HOME
. /appl/oracle/dba/bin/setoraenv FOCUSPRD
OUTPUT=/appl/oracle/result.out
cd /appl/oracle
sqlplus -s "/as sysdba" << EOF > $OUTPUT
@/appl/oracle/Analyze_DAILY_STOP.sql

spool /appl/oracle/Analyze_DAILY_STOP.log
set time on
set timing on
select name,open_mode,log_mode from v$database;
set time on
set timing on
ANALYZE TABLE FOCUS.DAILY_STOP VALIDATE STRUCTURE CASCADE ONLINE;
spool off













