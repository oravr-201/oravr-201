wpl1tsysdbs01.vitalps.com:/home/oracle> crontab -l
## Production CONTROLM Crontab ######
#00 22 * * * /home/oracle/scripts/backup/DBbkup.ksh controlm >/tmp/bkup_cm 2>&1
00 21 * * * /home/oracle/scripts/backup/DBbkup.ksh controlm >/tmp/bkup_cm 2>&1
15 0,12 * * * /home/oracle/scripts/backup/REDObkup.ksh controlm 0 >/tmp/bkup_fcm 2>&1
15 4,8,16,20 * * * /home/oracle/scripts/backup/REDObkup.ksh controlm 1 >/tmp/bkup_icm 2>&1

# Flush controlm shared pool every 4 hours - rwh 08/09/11
# 0,15,30,45 * * * * /home/oracle/scripts/FLUSHsp.sh controlm > /tmp/flush_cm 2>&1
00 04 * * * /home/oracle/scripts/DBexport.sh controlm >/tmp/exp_controlm 2>&1
05,15,25,35,45,55 * * * * /home/oracle/scripts/CHKdbup.sh controlm >/tmp/up_cm 2>&1
05,15,25,35,45,55 * * * * /home/oracle/scripts/CHKdbup.sh ccprodw >/tmp/up_cmprod 2>&1
05,15,25,35,45,55 * * * * /home/oracle/scripts/CHKdbup.sh ccarchw >/tmp/up_cmarch 2>&1
01,16,31,46 * * * * /home/oracle/scripts/CHKFSspace.sh controlm >/tmp/chfs_cm 2>&1

20 3 * * 0 /home/oracle/scripts/ORADBhealthchk.sh controlm > /tmp/hchk_cm 2>&1
20 3 * * 0 /home/oracle/scripts/ORADBhealthchk.sh ccprodw > /tmp/hchk_cmprod 2>&1
20 3 * * 0 /home/oracle/scripts/ORADBhealthchk.sh ccarchw > /tmp/hchk_cmarch 2>&1

00 17 * * * /home/oracle/scripts/UPDstats.sh controlm >/tmp/stat_cm 2>&1
00 18 * * * /home/oracle/scripts/UPDstats.sh ccprodw >/tmp/stat_cmprod 2>&1
00 19 * * * /home/oracle/scripts/UPDstats.sh ccarchw >/tmp/stat_cmarch 2>&1
1,31 * * * * /home/oracle/scripts/DB_go.ksh -d controlm  -p switch_log  >/tmp/switch_cm 2>&1

15,45 * * * * /home/oracle/scripts/CHKstandby.sh controlm  >/tmp/stby_cm 2>&1
45 09 * * * /home/oracle/scripts/CHKdg.sh controlm  >/tmp/dg_cm 2>&1
15,45 * * * * /home/oracle/scripts/CHKstandby.sh ccprodw  >/tmp/stby_cmprod 2>&1
45 09 * * * /home/oracle/scripts/CHKdg.sh ccprodw  >/tmp/dg_cmprod 2>&1
15,45 * * * * /home/oracle/scripts/CHKstandby.sh ccarchw  >/tmp/stby_cmarch 2>&1
45 09 * * * /home/oracle/scripts/CHKdg.sh ccarchw  >/tmp/dg_cmarch 2>&1

30 13 * * * /home/oracle/scripts/backup/DBbkup.ksh controlm >/tmp/bkup_cm 2>&1

###################################################################
# Oracle Rman backups - FULL - Note some are tape bkups           #
###################################################################
00 04 *  *  * /home/oracle/scripts/tape_man_bkups.sh -i env.ccprodw            >> /dev/null 2>&1
00 02 *  *  * /home/oracle/scripts/man_bkups.sh -i env.ccarchw                     >> /dev/null 2>&1
# 00 03 *  *  * /home/oracle/scripts/man_bkups.sh -i env.cchistw                     >> /dev/null 2>&1



###################################################################
# Oracle Rman backups - arch - Note some are tape bkups           #
###################################################################
00 16 *  *  * /home/oracle/scripts/tape_man_bkups.sh -i env.ccprodw -t a       >> /dev/null 2>&1
00 14 *  *  * /home/oracle/scripts/man_bkups.sh -i env.ccarchw -t a -g 1           >> /dev/null 2>&1
# 00 15 *  *  * /home/oracle/scripts/man_bkups.sh -i env.cchistw -t a -g 1           >> /dev/null 2>&1

###################################################################
# Flush shared pool                                               #
###################################################################
01,16,31,46        *  *  *  * /home/oracle/scripts/flush_sp.sh    -i env.controlm             >> /dev/null 2>&1

###################################################################
# Check status of instances                                       #
###################################################################
01,11,21,31,41,51  *  *  *  * /home/oracle/scripts/chk_db_stat.sh -i env.ccprodw              >> /dev/null 2>&1
01,11,21,31,41,51  *  *  *  * /home/oracle/scripts/chk_db_stat.sh -i env.ccarchw              >> /dev/null 2>&1
01,11,21,31,41,51  *  *  *  * /home/oracle/scripts/chk_db_stat.sh -i env.controlm             >> /dev/null 2>&1
## 01,11,21,31,41,51  *  *  *  * /home/oracle/scripts/chk_db_stat.sh -i env.cchistw              >> /dev/null 2>&1

###################################################################
# Perform monthly maintenance on log files for all oracle DB's    #
###################################################################
59 23 28  *  *                /home/oracle/scripts/ora_log_rotate.sh                          >> /dev/null 2>&1

###################################################################
# Scan alert logs for any errors and email results                #
###################################################################
55 23  *  *  *                /home/oracle/scripts/alert_log_scan.sh                          >> /dev/null 2>&1

###################################################################
# Perform maintenance of AWR to keep sysaux from overgrowing      #
###################################################################
16  *  *  *  *               /home/oracle/scripts/awr_maint.sh -i env.ccprodw                >> /dev/null 2>&1
46  *  *  *  *               /home/oracle/scripts/awr_maint.sh -i env.ccprodw                >> /dev/null 2>&1
01  *  *  *  *               /home/oracle/scripts/awr_maint.sh -i env.ccarchw                >> /dev/null 2>&1
31  *  *  *  *               /home/oracle/scripts/awr_maint.sh -i env.ccarchw                >> /dev/null 2>&1
10  *  *  *  *               /home/oracle/scripts/awr_maint.sh -i env.cchistw                >> /dev/null 2>&1
40  *  *  *  *               /home/oracle/scripts/awr_maint.sh -i env.cchistw                >> /dev/null 2>&1
# 00  *  *  *  *               /home/oracle/scripts/awr_maint.sh -i env.controlm               >> /dev/null 2>&1

###################################################################
# Perform maintenance of DBREAD tables for Prashant
###################################################################
01 00  *  *  *               /home/oracle/scripts/ccprod_rpt_maint.sh -i env.ccprodw         >> /dev/null 2>&1

#########################################################
# Periodic check to make sure agent are running
#########################################################
#30  *  *  *  *     /home/oracle/scripts/CHKagentstatus.sh             > /dev/null 2>&1

#############################################################################################
#  Added for Auditing Reports. Runs at 1st day of every month at 1AM
#############################################################################################

0 0 1 * * /home/oracle/scripts/audit_reports/Patch_report.sh        > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/Profile_Security.sh    > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/All_Logins.sh          > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/DBA_Role.sh            > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/User_Grants.sh         > /dev/null 2>&1


0 0 1 * * /home/oracle/scripts/audit_reports/ccarchw/Patch_report.sh      > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/ccarchw/Profile_Security.sh   > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/ccarchw/All_Logins.sh          > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/ccarchw/DBA_Role.sh            > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/ccarchw/User_Grants.sh         > /dev/null 2>&1

0 0 1 * * /home/oracle/scripts/audit_reports/ccprodw/Patch_report.sh        > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/ccprodw/Profile_Security.sh    > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/ccprodw/All_Logins.sh          > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/ccprodw/DBA_Role.sh            > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/ccprodw/User_Grants.sh         > /dev/null 2>&1

0 0 1 * * /home/oracle/scripts/audit_reports/cchistw/Patch_report.sh        > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/cchistw/Profile_Security.sh     > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/cchistw/All_Logins.sh           > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/cchistw/DBA_Role.sh             > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/cchistw/User_Grants.sh          > /dev/null 2>&1
##############################################################################################
wpl1tsysdbs01.vitalps.com:/home/oracle> cat /home/oracle/scripts/audit_reports/Patch_report.sh
#!/bin/bash


export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=controlm
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH
export FHOST=${HOST}
export FNAME=${FHOST%%.*}_${ORACLE_SID}_Patch_Report_${SDATE}
export SUBJ=${FNAME}

 cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv

sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1
SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'This is PSU Patch Report on monthly basis.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT ' ' from dual;

SELECT RPAD('ACTION_TIME',30,' ')||','||
       RPAD('ACTION',25,' ')||','||
       RPAD('STATUS',25,' ')||','||
       RPAD('DESCRIPTION',25,' ')||','||
       RPAD('VERSION',25,' ')||','||
           RPAD('PATCH_ID',20,' ')||','||
           RPAD('BUNDLE_SERIES',20,' ')||','||
       RPAD('COMMENTS',30,' ')
  FROM DUAL;

SELECT ' ' FROM DUAL;

SELECT TO_CHAR(action_time, 'DD-MON-YYYY HH24:MI:SS')||','||action||','||status||','||description||','||version||','||patch_id||','||bundle_series FROM   sys.dba_registry_sqlpatch ORDER by action_time;

-- select  rg.ACTION_TIME  ||','||rg.ACTION ||','|| rg.NAMESPACE ||','|| rg.VERSION ||','|| rg.ID ||','||  rg.BUNDLE_SERIES ||','|| rg.COMMENTS  from  sys.registry\$history rg;

EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv |wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv  /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi

wpl1tsysdbs01.vitalps.com:/home/oracle> cat /home/oracle/scripts/audit_reports/Profile_Security.sh
#!/bin/bash

export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=controlm
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

export FHOST=${HOST}
export FNAME=${FHOST%%.*}_${ORACLE_SID}_Profile_Security_${SDATE}
export SUBJ=${FNAME}

#export FNAME=${HOST}_Profile_Security_${SDATE}

cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv


sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1
SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'This is the audit profile Security.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT ' ' from dual;

SELECT RPAD('PROFILE',30,' ')||','||
       RPAD('RESOURCE NAME',25,' ')||','||
           RPAD('RESOURCE TYPE',30,' ')||','||
           RPAD('LIMIT',30,' ')
  FROM DUAL;

SELECT ' ' FROM DUAL;


Select  p.PROFILE ||','|| p.RESOURCE_NAME ||','|| p.RESOURCE_TYPE ||','|| p.LIMIT  from dba_profiles p where resource_type = 'PASSWORD' order by  p.PROFILE;


EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv |wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi

wpl1tsysdbs01.vitalps.com:/home/oracle> cat /home/oracle/scripts/audit_reports/All_Logins.sh
#!/bin/bash

export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=controlm
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH



export FHOST=${HOST}
export FNAME=${FHOST%%.*}_${ORACLE_SID}_All_Logins_${SDATE}
export SUBJ=${FNAME}

# export FNAME=${HOST}_All_Logins__${SDATE}

cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv

sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1
SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'This is the audit requirement on monthly basis.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT ' ' from dual;

SELECT RPAD('USER NAME',30,' ')||','||
       RPAD('ACCOUNT STATUS',15,' ')||','||
           RPAD('CREATION DATE',13,' ')||','||
       RPAD('LOCK DATE',10,' ')||','||
       RPAD('EXPIRY DATE',25,' ')||','||
          RPAD('PTIME',20,' ')||','||
           RPAD('LAST LOGIN',20,' ')||','||
       RPAD('DEFAULT TABLESPACE',20,' ')||','||
           RPAD('PROFILE',20,' ')
  FROM DUAL;

SELECT ' ' FROM DUAL;

select du.username ||','|| du.account_status ||','|| du.created ||','|| du.lock_date ||','|| du.expiry_date ||','||
 u.ptime ||','||du.last_login||','|| du.default_tablespace ||','|| du.profile
from dba_users du, sys.user$ u
where du.username = u.name
order by du.profile;

EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv |wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi

wpl1tsysdbs01.vitalps.com:/home/oracle> cat /home/oracle/scripts/audit_reports/DBA_Role.sh
#!/bin/bash

export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=controlm
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

export FHOST=${HOST}
export FNAME=${FHOST%%.*}_${ORACLE_SID}_DBA_Role_${SDATE}
export SUBJ=${FNAME}

# export FNAME=${HOST}_DBA_Role_${SDATE}

cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv


sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1
SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'Please approve  - Active DBA  Users Listing Report' from DUAL;
SELECT 'This is the audit requirement on monthly basis.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT ' ' from dual;

SELECT ' ' FROM DUAL;

SELECT RPAD('USER NAME',30,' ')||','||
       RPAD('CREATION DATE',13,' ')||','||
       RPAD('PWD CHG DATE',13,' ')||','||
       RPAD('PROFILE',25,' ')||','||
       RPAD('ACCOUNT STATUS',15,' ')||','||
       RPAD('PRIVS TYPE',10,' ')||','||
       RPAD('PRIVILEGES',25,' ')||','||
         RPAD('APPROVED Y or N',20,' ')||','||
       RPAD('APPROVED BY',20,' ')
  FROM DUAL;
-- union
SELECT ' ' FROM DUAL;
-- union
SELECT RPAD(y.username,30,' ')||','||
      RPAD(TO_CHAR(TRUNC(z.ctime),'DD-MON-YYYY'), 13, ' ')||','||
      NVL(RPAD(TO_CHAR(TRUNC(z.ptime),'DD-MON-YYYY'), 13, ' '), '             ')||','||
      RPAD(y.profile, 25,' ')||','||
      RPAD(y.account_status,15,' ')||','||
      RPAD('ROLE',10,' ')||','||
      RPAD(x.granted_role, 25,' ')
 FROM dba_role_privs x
    , dba_users y
    , sys.user$ z
WHERE z.name = y.username
  AND (x.GRANTED_ROLE = 'DBA' OR y.username IN ('TRIPWIRE', 'DB_ENVISION','UCMDB', 'ACN_ORA_MONITOR', 'PERFSTAT'))
  AND x.GRANTEE=y.username
ORDER BY y.profile,y.username;


EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv|wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl  /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi
wpl1tsysdbs01.vitalps.com:/home/oracle> cat /home/oracle/scripts/audit_reports/User_Grants.sh
#!/bin/bash



export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=controlm
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH



export FHOST=${HOST}
export FNAME=${FHOST%%.*}_${ORACLE_SID}_User_Grants_${SDATE}
export SUBJ=${FNAME}

# export FNAME=${HOST}_Users_Grants_${SDATE}

cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv


sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1

SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250

SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'Please approve  - Active App Team DB Users Listing with Assigned Users and Privileges' from DUAL;
SELECT 'This is the audit requirement on monthly basis.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT '======================================' from dual;

SELECT ' ' FROM DUAL;

SELECT RPAD('USER NAME',20,' ')||','||
       RPAD('CREATION DATE',13,' ')||','||
       RPAD('PWD CHG DATE',13,' ')||','||
       RPAD('PROFILE',25,' ')||','||
       RPAD('ACCOUNT STATUS',15,' ')||','||
       RPAD('PRIVS TYPE',10,' ')||','||
       RPAD('PRIVILEGES',25,' ')||','||
          RPAD('APPROVED Y or N',20,' ')||','||
       RPAD('APPROVED BY',20,' ')
  FROM DUAL;

SELECT RPAD('=',20,'=')||','||
       RPAD('=',13,'=')||','||
       RPAD('=',13,'=')||','||
       RPAD('=',25,'=')||','||
       RPAD('=',15,'=')||','||
       RPAD('=',10,'=')||','||
       RPAD('=',25, '=') ||','||
           RPAD('=',20, '=')||','||
         RPAD('=',20, '=')
  FROM DUAL;

SELECT RPAD(a.name,20,' ') ||','||
       RPAD(TO_CHAR(TRUNC(a.ctime),'DD-MON-YYYY'), 13, ' ') ||','||
       NVL(RPAD(TO_CHAR(TRUNC(a.ptime),'DD-MON-YYYY'), 13, ' '), '             ') ||','||
       RPAD(c.profile, 25,' ')  ||','||
       RPAD(c.account_status,15,' ') ||','||
       RPAD('ROLE',10,' ')  ||','||
       RPAD(b.granted_role,25, ' ')
  FROM sys.user$ a,
       DBA_ROLE_PRIVS b,
       DBA_USERS c
 WHERE a.name = B.GRANTEE
   AND a.name = c.Username
   AND (c.account_status NOT LIKE 'LOCKED' AND c.account_status NOT LIKE ('EXPIRED '||'&'||' LOCKED') AND c.account_status NOT LIKE ('EXPIRED(GRACE) '||'&'||' LOCKED'))
   AND (B.granted_role NOT LIKE 'DBA')
   AND a.name NOT IN ('TRIPWIRE', 'DB_ENVISION','UCMDB', 'ACN_ORA_MONITOR','PERFSTAT','XDO', 'SQLTXPLAIN' , 'SYS', 'SYSTEM', 'SYSMAN', 'DBSNMP','STRMADMIN','OPS$ORACLE')
   AND C.PROFILE NOT LIKE '%DBA%'
UNION
SELECT RPAD(a.name,20,' ') ||','||
       RPAD(TO_CHAR(TRUNC(a.ctime),'DD-MON-YYYY'), 13, ' ') ||','||
       NVL(RPAD(TO_CHAR(TRUNC(a.ptime),'DD-MON-YYYY'), 13, ' '), '             ')||','||
       RPAD(c.profile, 25,' ')  ||','||
       RPAD(c.account_status,15,' ') ||','||
       RPAD('SYSTEM',10,' ') ||','||
       RPAD(b.privilege,30, ' ')
  FROM sys.user$ a,
       DBA_SYS_PRIVS b,
       DBA_USERS c
 WHERE a.name = B.GRANTEE
   AND a.name = c.username
   AND (c.account_status NOT LIKE 'LOCKED' AND c.account_status NOT LIKE ('EXPIRED '||'&'||' LOCKED') AND c.account_status NOT LIKE ('EXPIRED(GRACE) '||'&'||' LOCKED'))
   AND a.name NOT IN ('TRIPWIRE', 'DB_ENVISION', 'UCMDB', 'ACN_ORA_MONITOR', 'PERFSTAT','XDO', 'SQLTXPLAIN', 'SYS', 'SYSTEM', 'SYSMAN', 'DBSNMP','STRMADMIN','OPS$ORACLE')
   AND C.PROFILE NOT LIKE '%DBA%'
ORDER BY 1;


EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv|wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi

wpl1tsysdbs01.vitalps.com:/home/oracle> cat /home/oracle/scripts/audit_reports/perlmail.pl
#!/usr/bin/perl


use MIME::Lite;
use Net::SMTP;

#my $FILE_NAME=$ARGV[0];


### Adjust sender, recipient and your SMTP mailhost
my $from_address = 'ifx-dbalerts@tsys.com';
# my $to_address = 'baidhardas@tsys.com';
my $to_address = 'baidhardas@tsys.com,SWorachek@tsys.com,leblance@tsys.com';
my $mail_host = 'smtpwest.tas.corp';
#
### Adjust subject and body message

#$subject = "Audit Report" ;
$subject = $ARGV[2];

my $message_body = "Hello All,

Please see attached report for Database Audit.

Thanks and Regards,
DBA Team

";



### Adjust the filenames
my $my_attach_file_path =$ARGV[1];
# my $my_attach_file ="$my_attach_file_path/$ARGV[0]";
my $my_attach_file ="$ARGV[0]";


### Create the multipart container
$msg = MIME::Lite->new (
From => $from_address,
To => $to_address,
Subject => $subject,
Type =>'multipart/mixed'
) or die "Error creating multipart container: $i\n";

    ### Add the text message part
    $msg->attach (
    Type => 'TEXT/HTML',
    Data => $message_body
    ) or die "Error adding the text message part: $!\n";

#    ### Add the ZIP file
    $msg->attach (
      Type => 'TEXT/PLAIN',
      Path => $my_attach_file_path,
      Filename => $my_attach_file,
      Disposition => 'attachment'
      ) or die "Error adding $file_zip: $!\n";

### Send the Message
MIME::Lite->send('smtp', $mail_host, Timeout=>60);
$msg->send;

wpl1tsysdbs01.vitalps.com:/home/oracle>
