 P5 tasks
--- as per updated date 
-- send next reminder atleast after 24 hrs 
--- mention strike info in OH reason 
--- as per updated date 
--- check properly \n it shud be work completed task \n if any reply from user that he having issues then change to P3 WIP
--- close after 3 reminders and inform user that as per 3 strike we are closing ( for work completd only tickets )

Pawar\n Kulbhushan 16:01
IT Solutions: Order Close Notice - Order ID SIEQP43001126082 / 2039425 / Workstation\n Modify workstation data for Kulbhushan Pawar
IT Solutions: Order Confirmation SIEQP43001126082 / 2039425 / Workstation\n Modify workstation data for Kulbhushan Pawar

\\155.45.163.189\ts_emea$
201105    1234
A595069
+917572900649
sysbrhypprd

08597674867   kumar singh 
oracle : mails.raj@gmail.com / 9902209090 -----
I:\MgdDB\GF_DBA\oracle\dbms\Linux\64bit\
\\155.45.163.189\dsl_emea$

America$26
161.89.164.8---directly connect from .218 putty
Username: oracle password: orainst

sysbrhypprd
https://join.myatos.net/meet/samuel.fung/2HR0MRBV 

100978395291
https://unifiedportal-mem.epfindia.gov.in/memberinterface/
	
printer pass:962247   MC000zqP
monsanto call :+18887117717			-----------http://portals.monsanto.com/technology/techconnect/ProductsandServices/Documents/Registering%20Your%20Smart%20Phone.pdf <http://portals.monsanto.com/technology/techconnect/ProductsandServices/Documents/Registering%20Your%20Smart%20Phone.pdf> 
JH .218 = june$2017
Lifeline : AmeyLA1985

Monsento Helpdesk No:0001 8887117717	

nilesh avaya
263142	1234
h99879 - U5MfMyu5Z9$D
june$Action2017
may$Action19930117
may$Action20170117
Hotline No: +91 226 219 4217
2262194005	
Jun@2018 


ATF:I5333550
AmeyLA1985A594446
Hafyu_123udn7%asd	

snow : chandrakant : ATOSA435715/Chandu$1234


CDT SHIFT :

7:30PM-3:30 AM	morning 
3:30 AM -11:30 AM	day 
11:30AM-7:30PM	night 

username: Philips_DCO 
Password = Philip$DC012 
https://access.redhat.com/downloads/ 

-----------------------------------------------------------------------------------------------------------------------------------------	
	NAME 					HUSTMAN							SIEMEMNS				oracle suport 					



	amey lad :				SPECIALTIES\h117419										lad.amey@atos.net
							Dragon12$												Zapak123$

	kulbhushan pawar 		SPECIALTIES\h117418
							Jackman@56
							
	Nilsesh lathiya 										a610192
															January123456@123456
															
	amit mahalle 			SPECIALTIES\h118451
							Huntsman6						
							
	dimple patel			SPECIALTIES\h117415
							March@2017

	preksha shaha 			SPECIALTIES\h99879	
							Huntsman12				
	HEMANT PETHE 			hemant.pethe@atos.net			Lara$123
	AMEY LAD				amey.lad@atos.net			    Zapak123$	


	Metalink Details For NAM
DFW-Midrange-DBA@atosorigin.com
Qazws@123

-------------------------------------------------------------------------------------------------------------------------------------------	
bebma397 	h99879 		Mumbai$123 
usarav198	h117419		Atos@1234/
usarav185   h117419		Dangal123$  

BMC\I9SHAHP     Apr12345&12345 
BMC\I9NIRMAC	Atos@12345
10.200.211.20	 	
BMC\I9LADA	Dragon6$	
OEM Link	https://nj62pcc1.benjaminmoore1.com:7802/em	 	 	
 	sysman	oemprdsysman500	 	 	 	
 	 	 	 	 	 	 	
 	161.89.145.220 	 	161.89.145.210	161.89.145.214	
 	 	 	 	 	 	 	
 	10.200.211.20	 	 	 	 	 	
 	BMC\I9LADA	Dragon6$	


manoj Mondesk : MSSHAR/@Smkl1hM

America$26
I9NIRMAC
Atos@12345

pritam 218
a639606
MNp@1234 

ATOS24497 
	
	
	Eae*Vg4g 
	
	
	
ATF:C1953935
	
ATF:C1953935
bebma490 h117415 A1234@atos  
a639606/TRjt&12$GEnr#55 

 
10.80.96.18 - USMLVA3003QSRV - dtp29

a610192 - Ai[joTVVqj6o
 
h117419
Dragon12$
********************
tushar 			   *
stenly			   *
a569880			   *
Atos@1234 		   *
********************

NYBC\spatil		Dhoom19$$
NYBC\apendse  	nov$Action2017
NYBC\kyerawar	nov$Action2017
NYBC\vbhandwa	nov$Action2017


hpethe\April@2017

Bristow

domain.olog\oracledba Gold$1234

clarify :
*************************************************************************
https://i-web.it-solutions.myatos.net/Citrix/XenApp/site/default.aspx	*
																		*
Citrix	azl054	Dragon7$												*
Clarify	alad	Dragon6$												*
*************************************************************************
cerner :

10.74.75.60
http://citrixweb.diag.local/Siemens/Citrix/auth/login.aspx?CTX_FromLoggedoutPage=1

---------------------------------------------------------
venator :

10.199.52.10 / 10.199.52.11	
 	
DOM01\h117418 : Jackman@11	

iamGroot$124421879



10.199.52.10 or 10.199.52.11

DOM01\H117437 Airoli$1234!@#$
EMEAAV106 h117437 h117437
EMEAAV107 h117437 h117437

-------------------------------------------------------------







BEBMA490 --- oracle/ PncpSecret77& ---------- h117415 A1234@atos  ----------PncpSecret77& 


Gaurav siemens :
a646569
@Appledore007

philips :
us1edip3	a519185	March$2015	
Userid :a591590 Password :Welcome@123	
Userid :a591590 Password :Welcome@2017	

US1EDIP3, a435715/March$2015 
US1EDIP4 a435715/March$2015
a595121/Test@123

Bristow
domain.olog\oracledba Gold$1234


BEEVSDWQ - h99879/Mumbai$123 										 
BEBEA124  h117418/Nov@2015                                                                     OP17	Uslzua4a0kn0	161.134.154.199	a519185	abcd1234
																							   OP17	Uslzua4a0kn01	161.134.154.199	a519185	abcd1234
																	 	                                                                    
                                                    
************************************											                     
-------------------------						                     
DDCRDAP550n2 	a600386												 
DDCRDAP550n3	Atos@123                                             
DDCRDAP550n1 
--------------------------                                                                                                                                                                                          
DDCRDAP560		a610192/Hello@123                                    
*************************************                                                                   
																	 
-------------------------											 
BEEVSDWP 		h117419/Atos@1234											 														 
--------------------------											 
USCRLVDTOY		Atos@1234											 
--------------------------											 
USARAV237		h99879/Mumbai$123													 
----------------------------										 
USARVPSAB1  h117418		h117415 									 
			h117418		Atos@1234									 
---------------------------------									                                               
Servers		User ID	Password                     
ussea616	h117418	U5MfMyu5Z9$D                 
ussea615	 	                                 
ussef336	 	                                 
ussea432	 	                                 
ussea340	 	                                 
ussea312	 	                                 
ussea313 prod	 	                             
ussea433	 	       
h118451
Atos@1234                          
------------------------------------
usarav199       h117419/Atos@1234      
USCAVDSAB1      h117419/h117419 
USSEA313        h117419/Welcome2NAM+


^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^					                                                 
stenely :		a600386/Welcome15  ^                                                                                                                            
                a569880/Atos@1234  ^                                           
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ ^                         

BEBMA511
BMC\I9SHAHP 	Apr12345&12345


INC2917187

check on OEM  NYBC :
https://edoem.nybc.org:7799/em
sysman/sysadm1n	

Hunstsman OEM :

https://10.201.64.26:7802/em/    	 	
 	 	
huntsmandba	cr3tic1l	
sysman	Summer2014	


***************************************************                                                                     
siemens                                                              
a610192	June123@20!6	Atos123@20!6Atos                             
*****************************************************                                                                    
a186526        March123@20!7      
 
a610192 June123@20!6 Atos123@20!6Atos                                
a569880---password reset                                             
136.157.166.6	                                                     
                                                                     
a639606 June123@20!6                                                 
N6F4u<Es_b6j                                                         
 uswlla20011srv 161.134.194.57 a435715 / March@2017                                                                 
                                                                     
                                                                     
NORTH_AMERICA                                                        
                                                                     
https://mondesk.monsanto.com/                                        
Monsanto - Daily Backup report                                       
**************************************                               
monsanto                                                             
***************************************                              
kp                                                                   
userid : kkkb                                                        
pass : Monsanto.1                                                    
---------                                                            
sudo -u oracle -s                                                    
                                                                     
cd                                                                   
bash                                                                 
. .\profile                                                          
ps -ef|grep pmon                                                     
. oraenv                                                             
                                                                     
**************************************                               
***************************************                                                                              
                                                                                                                            
				                                                     
-------------------------------------                                           
Atos aorman	usaodba1                                                     
a523053 / Atos@1234                                                  
                                                                     
CSM Bakery	USTXSS264                                                
CSM Bakery	CSMS00052                                                
CSM Bakery	CSMS00065                                                
CSM Account     CORP\ext_DalalP Pariyank!29    
Database Login  Oracle         
Password        gold$1234    
                                               
----------------------------------                                   
usdfstptp2                                                           
a649491/seven$Action1978                                             
                                                                     
Uslzua200kmsrv	                                                     
a186526/ArchieS@657                                                  
		                                                             
	AmeyLA1985 vb				                                                 

unify  = a_alad/Dragon9$                                       
					                                                 
Atos	usaodba1                                                     
a523053 / Atos@1234                                                  
                                                                     
                                                                     
CSM Bakery	USTXSS264                                                
CSM Bakery	CSMS00052                                                
CSM Bakery	CSMS00065   
                                             
CSM Account     CORP\ext_DalalP Pariyank!29    
Database Login  Oracle         
Password        gold$1234                                            
                                                                     
Fga\kulbhushan.pawar                                                 
Jackman@88                                                           
                                                                                                                                      
fga\oracledba : Gold$1234                                            
                                                                     
https://desktop.pingone.com/Monsanto/Selection?cmd=selection         
                                                                     
paste it                                                             
  http://155.45.60.170/DDMRemediateCDP/InfoExQuery.aspx <http://155.45.60.170/DDMRemediateCDP/InfoExQuery.aspx>  
                                                                   
                                                                     
DBA_BATCH/UvTuRQyNvJ1L@rprd1.monsanto.com                            Jackman@22
sqlplus DBA_BATCH/UvTuRQyNvJ1L@USMDMD.monsanto.com                   
 
 apanchal	iamGroot$124421879	

------------------------------------
April123456@2017
 
 
saacon\a575154
Monsoon$123456

ww900\w9a94f80		Newpwd12345&12345
ad001   w99aq5x0        Borivali12345&12345   
ad001\w99aq5x0	Zapak12345&12345
w9a95qm0

Newpwd12345&12345

IamAmeyLad12345&12345

ww900\apanchal	Kabil&54321&54321	
ww900\w9a97sr0

ww900\w9a95qm0			-----nilesh
July123456@12345


ww900\rchaudhari
ten$Thousand201


129.73.128.195-----siemens GUI


Cerner login :

136.157.7.55
ww900\w9a980s0
Atos@1234567810

Username- DIAG-LOCAL\A591590
Password- Qhdv-123456

----------------------------------------
                         
usarav197	Atos@1234                            
		\\155.45.163.189\ts_emea$			                                                 
					                                                					                                                 
ASHLAND                                                              
                                                                     
BRISTOW:
					                                                 
DOMAIN\pshah	February$1234
 
Sie6_orac6e_db6 
March$123 - a548609 

------------------------
Terum0bct
VPVISORA01
VTVISORA01					                                                 
------------------------		                                                 
					                                                 
Username: DIAG-LOCAL\A519185   
Password: Dragon1$
                                
nybc:
vega = oracle/At0sDBA
JH .125 & .126
			                                                 
NYBC\cnirmal	 Atos@12345	

a511411 / April@017 
a610192 - Ai[joTVVqj6o 
  

172.17.156.55 - a511411 / &:y8@N44JHY@?(Z 

AD001				ad001\w99atng0	DBa6xnZiP3i1boL	
AD005				ad005\w99atnf0	P9FuKsZZWKynyX1	
AD009				ad009\w99atne0	r37C8FYVTK9SggF	
						

a523053 \n Jan@017

a575154 - ^trwTmL1

a610192

June123@20!6

uslzua200kmsrv.ww004.siemens.net
a569880
Magarpatta$1
161.134.187.40
Magarpatta$12

ww900\w9a981r0
Appledore@1234567890

136.157.212.83 

nilesh 218 :
a610192
June@2017


saacon\A186526	
urFake$98989898	

saacon\a519185
Ghatak12345&12345

aug$Action20170117

vijay :


saacon\a567548
Neninthe12345&12345

saacon\a610192
august123456@12345

10.87.192.7	 	
finolexind\alad	
Spark2$	



orainst
==========================================================================================================================================					                                                 
											ATOS INTERNAL LOGINS 
==========================================================================================================================================

Atos Internal				masd003x								155.45.63.77				a511411 	Atos@123
Atos Internal				MASD007X								155.45.63.114				a511411 	Atos@123
Atos Internal				MASD021X								155.45.63.163				a511411 	Atos@123
Atos Internal				MASD057X								155.45.63.190				a511411 	Atos@123
Atos Internal				MZSD023X								155.45.63.151				a511411 	Atos@123
Atos Internal				MASD020X								155.45.63.153				a511411 	Atos@123			
Atos Internal				OHCLRP03								155.45.63.83				a511411 	Atos@123
Atos Internal				OHCLRP06								155.45.63.109				
Atos Internal				OHERSP01								155.45.63.30				a511411 	Atos@123
Atos Internal				MASD058X								155.45.65.88				a511411 	Atos@123
Atos Internal				USLZUA0001UDAT							155.45.121.160				
Atos Internal				USLZUA0006USRV							155.45.145.44 				
Atos Internal				USLZUC1P703DAT							155.45.119.139				a511411 	Atos@123	
Atos Internal				USLZUILX001DAT							155.45.120.235				
Atos Internal				USMASA00017DAT							155.45.61.231				a511411 	Atos@123
Atos Internal				USMASA0003ZSRV							155.45.61.39				a511411 	Atos@123
Atos Internal				USMASOHX001DAT							155.45.59.69				a511411 	Atos@123 
Atos Internal				USLZUA000E6SRV							10.85.153.163				 
Atos Internal				MASD077X								155.45.63.1	 			

wel@123
india123
==========================================================================================================================================					                                                 
											SIEMENS LOGINS DETAILS 
==========================================================================================================================================
ljkjjkji$&ju(9

a569880 Atos@1234 


a575154/Pani12345&12345
a610192 - Ai[joTVVqj6o
  

MLVVUL5U         10.80.100.102             a519185			Zapak123$
oradev02 		 10.80.100.56 			   a519185 			Borivali123$
MOE1A5 									   a435715			Atos@123 Chandu$2017


MOE1A6		a569880 Akola@123456

				 161.134.154.199		   a186526          fkjshedfk$$232847KFHB	
																												
Siemess helthcare 			usmlva3004msrv														a519185		Oracle$6789						  
Siemess helthcare 			uslzua4002usrv														a567548		Sundar123$		Dravid123# 								
Siemess helthcare 			USLZUA4003QSRV														oracle		Sie6_orac6e_db6                       
Siemess helthcare 			USLZUA4A0KSRV.scsm.siemens.com										a519185		abcd1234								
Siemess helthcare 			uslzua4a0msrv.scsm.siemens.com										a519185		aug$Action2017								
Siemess helthcare 			USLZUA4009BSRV							137.223.149.235				a519185		Sie6_orac6e_db6						
Siemess helthcare 			Usmlva0001usrv				161.134.221.105				a519185		February$123			              
Siemess helthcare 			usmlva0001ysrv.scsm.siemens.com								    	                                                  
Siemess helthcare 			Uslzua200kmsrv							161.134.187.40				a519185		Sundar123$								
Siemess helthcare 			Uslzua200jwsrv							161.134.187.20				a519185		Sundar123$								
Siemess helthcare 			Uslzua4a0kn01							161.134.154.199				a519185		abcd1234								
Siemess helthcare 			Uslzua4a0kn02							161.134.154.201				a519185		Sairat123$								
Siemess helthcare 			usdxsldplmdb1							165.226.210.48  			a519185		November123$							
Siemess helthcare 			usdxslporcdb1 							165.226.210.213				oracle		Sie6_orac6e_db6							
Siemess helthcare 			usdxslpplmdb1							165.226.210.49				a519185		Oracle$6789								
							USDXSLPRMAN2						    10.80.97.80 				a435715     April@2016  
Siemess helthcare 			Usmlva30020srv 							10.80.96.111				a186526		Sie6_orac6e_db6					
Siemess helthcare 			Usmlva3003qsrv  						10.12345.96.18				a519185		chiggywiggy123$   /one$Action2017                
Siemess helthcare 			USIRVA30020SRV	   						136.157.166.6				a519185		Sundar123$								
Siemess helthcare 			usirva2002gsrv 							136.157.166.36  			oracle 		Sie6_orac6e_db6 						
Siemess helthcare 			USIRVA30023SRV.scsm.siemens.com						                                                              
Siemess helthcare 			usmlva4a09srv 														oracle		Sie6_orac6e_db6 						
		---------------------------------------------------------------------------------------------------
		---------------------------------------------------------------------------------------------------

Siemess helthcare			Uslzua4a0kn01							161.134.154.199				a186526		Welcome@987654321
Siemess helthcare			Uslzua4a0kn02							161.134.154.201				a186526		Atos@123
Siemess helthcare			uslzua4a0msrv							161.134.154.196				a186526		Atos$456
Siemess helthcare			Usmlva0001usrv							161.134.221.105				a186526		sdfvkl@sLdk123
Siemess helthcare			usmlva0001ysrv							161.134.221.103				a186526		Atos@123
Siemess helthcare			USLZUA4009BSRV							161.134.154.47				a186526		sdfvkl@sLdk123
Siemess helthcare			                                                        			a186526		
Siemess helthcare			usdxsldplmdb1 							165.226.210.48  			a186526		ArchieS@657
Siemess helthcare			usdxslpplmdb1 							165.226.210.49				a186526		Atos@123
Siemess helthcare			usdxsldebsdb1 							172.17.196.20				a186526		decomm
Siemess helthcare			usdxslpebsdb1 							172.17.196.4				a186526		decomm
Siemess helthcare			usdxslporcdb1 							165.226.210.213				a186526		sdksjcvnl$$11567KLDKD
Siemess helthcare			usdxslprman1  							172.17.192.19				a186526		a435715/m{K)70C3w]Yy$qa
Siemess helthcare			usdxslprman2  							165.226.210.43				a186526		abcd1234
Siemess helthcare			Usmlva30020srv							10.80.96.111				a186526		sdksjcvnl$$11567KLDKD
Siemess helthcare			Usmlva3003qsrv		 					165.226.211.61				a186526		ArchieS@657
Siemess helthcare			Usmlva3004msrv							10.80.100.58				a186526		ArchieS@657
Siemess helthcare			                                                        			a186526		
Siemess helthcare			uslzua200j7srv							161.134.135.53				a186526		usdxsldplMD$12b1
Siemess helthcare			Uslzua200jwsrv							161.134.187.20				a186526		ArchieS@657
Siemess helthcare			Uslzua200kmsrv							161.134.187.40				a186526		noive$123nArch
Siemess helthcare			uslzua200kzsrv 							161.134.187.44				a186526		as34fuend@384fgKJH
Siemess helthcare			Ussaca20024srv							129.73.110.141				a186526		Atos@123
Siemess helthcare			Ussaca20025srv							129.73.110.58  				a186526		Max@1234
Siemess helthcare			uswlla20011srv							161.134.194.57							Atos@1234	ArchieS@657




moe1a6	10.74.75.61	July456@20!8
MOE1A5	10.74.75.60	Qwerty@XYZ@$$2016
 
a610192


moe1a6 	a575154		nov$Action2017 
MOE1A5 	a575154		nov$Action2017
 
toad:

 NA1000PRDDST01

41483061-0614
==========================================================================================================================================					                                                 
											FGA LOGINS DETAILS 
==========================================================================================================================================
161.89.145.218
NAM Inventory:		"D:\DBA\Atos\Inventory"
password :			 CEsduflp!
a186526/Jackman@00

FGA							fgsdcdcacdb01							10.158.17.105				a652766			Atos@123	 	ORADEV01
FGA																																CADEV
FGA																																BAGSDEV
FGA										
FGA							fgpdcpcacdb01							10.200.57.105				a652766			Atos@123		BAGSPRD:/oracle/product/9.2.0:N
FGA																																CAPRD:/oracle/product/9.2.0:N
FGA																																HEATPRD:/oracle/product/9.2.0:N
FGA										
FGA							fgpdcdjskap44							10.200.57.95				a652766			Atos@123		NJUSTST:/oracle/product/9.2:Y
FGA																																NJUSDEV:/oracle/product/9.2:Y
FGA																																NJCADEV:/oracle/product/9.2:Y
FGA																																NJCATST:/oracle/product/9.2:Y
FGA										
FGA							fgpdcpjskap44							10.200.57.90				a652766			Atos@123		NJPRD:/oracle/product/9.2.0:Y
FGA										
FGA							fgpdcpjskap46																						NJPRD:/oracle/product/9.2.0:Y
FGA																								a652766			Atos@123		NJCAPRD:/oracle/product/9.2.0:Y
FGA										
FGA							fgpdcpfocdb01							10.200.44.38				a652766			Atos@123		FOCUSPRD:/appl/oracle/product/v102:Y
FGA										
FGA							fgsdcqfocdb01							10.200.48.29				a652766			Atos@123	
FGA										
FGA											
FGA							fgsdcrfocdb01							10.200.48.28				a652766			Atos@123		FOCUSPRF:/appl/oracle/product/v102:Y
FGA																																FOCUSPRD:/appl/oracle/product/v102:Y
FGA										
FGA							fgpdcpkrodb01							10.200.56.125 				a652766			Atos@123		FNPRD:/appl/oracle/product/v102:Y
FGA																																KRONOSPD
FGA										
FGA							fgabumpx								10.200.44.208				a652766			Atos@123		HRUSADEV:/DEV/oracle/products/9.2.0:Y
FGA																																HRCANDEV:/DEV/oracle/products/9.2.0:Y
FGA																																HRUSATST:/QA/oracle/products/9.2.0:Y
FGA																																HRCANTST:/QA/oracle/products/9.2.0:Y
FGA																																ADPIDEV:/DEV/oracle/products/10.2.0:Y
FGA																																HRDMO:/DEV/oracle/products/9.2.0:N
FGA							pil01db3								10.200.56.177				a652766			Atos@123		HRUSAPRD:/PRO/oracle/products/9.2.0:Y
FGA																																HRCANPRD:/PRO/oracle/products/9.2.0:Y
FGA																																
FGA							lescxa07								10.200.56.167				a652766			Atos@123		DWDEV:/DEV/oracle/product/10.2.0:Y
FGA																																RMANDEV:/DEV/oracle/product/10.2.0:Y
FGA																																DWRPTDEV:/DEV/oracle/product/10.2.0:Y
FGA																																XETLDEV:/DEV/oracle/product/10.2.0:Y
FGA																																GENDB:/DEV/oracle/product/10.2.0:Y
FGA																																
FGA							lescxa0b								10.200.56.169				a652766			Atos@123		DWPRD:/PRO/oracle/product/10.2.0:Y
FGA																																DWRPTPRD:/PRO/oracle/product/10.2.0:Y
FGA																																XETLPRD:/PRO/oracle/product/10.2.0:Y
FGA																																RMANPRD:/PRO/oracle/product/10.2.0:Y
FGA																																ADPIPRD:/PRO/oracle/product/10.2.0:Y
FGA																																
FGA							lescxa0c								10.200.56.168				a652766			Atos@123		XETLSYS:/QA/oracle/product/10.2.0:Y
FGA\adm-pshah																													DWSYS:/QA/oracle/product/10.2.0:Y
																																GENDBSYS:/QA/oracle/product/10.2.0:Y
																																ADPITST:/QA/oracle/product/10.2.0:Y
																																
							NTDEV050										10.200.56.107				FGA\oracledba	F!rstA0r!giN
 
							OPWORAIMG02A							10.158.10.109				FGA\oracledba	F!rstA0r!giN
FGA  JH	 10.200.44.132  	  	 FGA\amey.lad	 FGA@9999	
==============================================================================================================================================
									Huntsman acess :
									Domain: 	SPECIALTIES
									Username: 	Vishal Bhandwalkar_AO_1
									H Account: 	H127379
									Password: 	tBM9ahv8J			june$Action2017			ATF:I5656540		
================================================================================================================================================
h99879/Huntsman14
vntr : h117418/Aata6sr374$234	

https://itap.myatos.net/itapportal/

h124540 
Huntsman_1
[‎22-‎01-‎2018 13:45] Choudhari, Pritam: 
Gjsdkklsd34$dim# 
bebma490	Gjsdkklsd34$dim#


bebma625	TRjt&12$GEnr#55
bebma490	TRjt&12$GEnr#55			
BEBMA397	TRjt&12$GEnr#55
bebma891	TRjt&12$GEnr#55
BEBMA626	TRjt&12$GEnr#55
BEBEA124	TRjt&12$GEnr#55
BEBMA892	TRjt&12$GEnr#55
Beevsdwq	GPc@1234

usarav185	GPc@1234

uscaav550	GPc@1234

uscaav549	GPc@1234

Beevsdwp	TRjt&12$GEnr#55
uscavdsab1	GPc@1234

usarav102	GPc@1234

usarav103	GPc@1234

USARAV237	GPc@1234

USCRLVDTOY	GPc@1234

usarvpsab1	GPc@1234

usarav199	TRjt&12$GEnr#55

usarav198	GPc@1234

usarav197	GPc@1234

ussea433	TRjt&12$GEnr#55
ussea313	TRjt&12$GEnr#55
ussea312	TRjt&12$GEnr#55
ussea340	TRjt&12$GEnr#55
ussea432	TRjt&12$GEnr#55
ussef336	TRjt&12$GEnr#55

USARAV201  h117418	Mumbai$123
h118451
Atos@1234  
=========================================================

bebma625 			aug$Action2017		 March$Action2018		
bebma490            aug$Action2017       March$Action2018
BEBMA397            aug$Action2017       March$Action2018
bebma891            aug$Action2017       March$Action2018
BEBMA626            aug$Action2017       March$Action2018
BEBEA124            aug$Action2017       March$Action2018
BEBMA892            aug$Action2017       March$Action2018
Beevsdwq            aug$Action2017       March$Action2018
usarav185           aug$Action2017       March$Action2018
uscaav550           aug$Action2017       March$Action2018
uscaav549           aug$Action2017       March$Action2018
Beevsdwp            aug$Action2017       March$Action2018
uscavdsab1          aug$Action2017       March$Action2018
usarav102           aug$Action2017       March$Action2018
usarav103           aug$Action2017       March$Action2018
USARAV237           aug$Action2017       March$Action2018
USCRLVDTOY          March$Action2018
usarvpsab1          March$Action2018
usarav199           March$Action2018	
usarav198           March$Action2018
usarav197           March$Action2018
ussea433            aug$Action2017       March$Action2018
ussea313            ussea313$Action2018
ussea312            aug$Action2017       March$Action2018
ussea340            aug$Action2017       March$Action2018
ussea432            ussea432$Action2018
ussef336            aug$Action2017       March$Action2018



beevscop (205.235.107.78 )---------- H117437/ Atos@1234
H117415 aABCDEFG@2016
beevscop login H117415 aABCDEFG@2016


beevscop (205.235.107.78 )---------- h117437/ Qwer$1234

snowball8

****************************************************
corpval\c805630
corpash\c805630
for JH ----password : Aug@2017
for server----password : Nov@2017

c805643/Aug@2017	


for oracle user

password : dbastaf1

and for ctrlm user 
password : bmcbmc1

VALVOLINE :
NATXIRRMAN101.CORP.VALVOLINE.COM 
USR: oracle
PWD: RMAN_VALVOLIN3

ASHLAND :
NATXIRRMAN201.CORP.ASHLAND.COM 
USR: oracle
PWD: RMAN_A5H1AN0


*******************************************************
CORP.ASHLAND.COM	
                                                Admingate (MGMT)	
NATXIRVJH101                  10.202.173.51	
NATXIRVJH102                  10.202.173.52	
NATXIRVJH103                  10.202.173.53	
NATXIRVJH104                  10.202.173.54 	
 	
 	
 	
 	
CORP.VALVOLINE.COM	
                                                Admingate (MGMT)	
NATXIRVJH201                  10.202.176.221	
NATXIRVJH202                  10.202.176.222	
NATXIRVJH203                  10.202.176.223	
NATXIRVJH204                  10.202.176.224  = Being fixed	

 	
	


BMC UNIX :

BMTX62-P-ARDB1	10.100.150.89
BMTX62-Q-ARDB1	10.101.150.77
BMTX61-D-ARDB1	10.101.150.76

 	 	 	 	 	
oracle/Atos@123	

login as: dboemprd
dboemprd	oemprd500	



cerner : link
http://10.80.94.135/Siemens/Citrix/auth/silentDetection.aspx

from local IE
https://admingate-emea.saacon.net/Citrix/XenApp/auth/login.aspx
DIAG-LOCAL\A610192 August@2017

ww900\w9a981r0
Appledore@1234567890


136.157.212.83 

id pass :
Username- DIAG-LOCAL\A591590
Password- Qhdv-1234567
 


DIAG-LOCAL      A610192 Atos@2017 
diag.local\yeraki00	Qhdv-1234

SIEQP43001006646	exicution 
 
SIEQP43001006652 	risk

SIEQP43001006694	work area

			
UserName : Sponge Uk/tCA 
Registration Code : C2573-CE608
-------------------------------------------
editplus keys :

UserName : Sponge Uk/tCA 
Registration Code : C2573-CE608
User Name: jb51.net
Key: 5D72F-84A30-60Z78-5FW59-7ATD8

User Name: kanshule.com
Key: B1D92-5AB08-6EZ0C-FEWCB-88TC4

User Name: reterry
Key: 156C1-F60A0-EAZ29-1FW79-1BTE4
---------------------------------------------

AD001==> SIEQP12575881
AD002==> SIEQP12575884
AD003==> SIEQP12575886

AD005==>SIEQP12575907
AD009==>SIEQP12575908



SPECIALTIES\ H115651
Huntsman8 


it desk
muhammadirfan.manjit@atos.net
timeshit:
Fegade\n Sunil <sunil.fegade@atos.net>
BHAGAT\n PRIYA <priya.bhagat@atos.net>
http://www.oracle-dba-online.com/recover-datafile-by-renaming.htm

