 
 @ECHO OFF
 rem set datef=%date:~-4%%date:~3,2%%date:~0,2%_%time:~0,2%%time:~3,2%%time:~6,2%
 rem set datef=%DATE:~0,2%%DATE:~3,2%%DATE:~6,4%-%TIME:~0,2%%TIME:~3,2%%TIME:~6,2%
 set datef=%DATE:~4,2%%DATE:~7,2%%DATE:~10,4%
 call :MySQLBackups > "E:\mysql_backups\mysql_ALLDBs_bkup_logfile.log"
 exit /b
 
 :MySQLBackups
 echo starting MySQL database backups Date: %date% %time%
  mysql --login-path=client -e"show databases"
  mysqldump --login-path=clinet --all-databases --skip-lock-tables --result-file="E:\mysql_backups\mysql_ALLDBs_bkup_%datef%.sql"
 echo Ending MySQL database backups Date: %date% %time%
 echo MySQL databases has been Backup successfully
 REM below command will delete 3 day older *.sql files
 REM forfiles /P "E:\mysql_backups" /M *.sql /D -3 /C "cmd /c del /F @path"
