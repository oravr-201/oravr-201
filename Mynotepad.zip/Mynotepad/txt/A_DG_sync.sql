==============================
check DG gap :
===============================
STANDBY:
---------
SELECT ARCH.THREAD# "Thread", ARCH.SEQUENCE# "Last Sequence Received", APPL.SEQUENCE# "Last Sequence Applied", (ARCH.SEQUENCE# - APPL.SEQUENCE#) "Difference"
FROM (SELECT THREAD# ,SEQUENCE# FROM V$ARCHIVED_LOG WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$ARCHIVED_LOG GROUP BY THREAD#)) ARCH,
(SELECT THREAD# ,SEQUENCE# FROM V$LOG_HISTORY WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$LOG_HISTORY GROUP BY THREAD#)) APPL
WHERE ARCH.THREAD# = APPL.THREAD# ORDER BY 1;
https://oracle-sid.blogspot.com/2015/07/data-guard-sync-status.html
PRIMARY:
---------



select pr.thread# "Node", pr.primary "Primary",dr.Standby "DR",pr.primary-dr.Standby "Difference"
from 
(select thread#,max(sequence#) as primary from v$archived_log where 
resetlogs_change#=(select resetlogs_change# from v$database) group by thread#) Pr,
(select thread#,max(sequence#) as Standby from v$archived_log where 
resetlogs_change#=(select resetlogs_change# from v$database) and applied='YES' group by thread#) dr 
where 
pr.thread#=dr.thread#;



set pages 50000 lines 32767Set scan off
Set feed off
BREAK ON ROW SKIP 1
COL "THREAD" for a10
COL "PR-ARCHIVED" for a15
COL "STBY-ARCHIVED" for a15
COL "STBY-APPLIED" for a 15
COL "SHIPPING GAP(PR -> STBY)" for a20
COL "APPLIED GAP(STBY -> STBY)" for a20
set head off
select 'sysdate: '|| to_char(sysdate,'DD-Mon-YYYY Hh24:Mi:ss') from dual;
select '****************Standby Log ship and Log Apply Status*****************' from dual;
set head on
select DEST_ID,DESTINATION,TARGET,STATUS from V$ARCHIVE_DEST where DESTINATION is not null;
select * from (
select
lpad(t1,4,' ') "Thread",
lpad(pricre,9,' ') "PR - Archived",
lpad(stdcre,10,' ') "STBY - Archived",
lpad(stdnapp,9,' ') "STBY - Applied",
lpad(pricre-stdcre,13,' ') "Shipping GAP (PR -> STBY)",
lpad(stdcre-stdnapp,15,' ') "Applied GAP (STBY -> STBY)"
from
(select max(sequence#) stdcre, thread# t1 from v$archived_log where standby_dest='YES'  and resetlogs_id in (select max(RESETLOGS_ID) from v$archived_log) and thread# in (1,2,3,4) group by thread#) a,
(select max(sequence#) stdnapp, thread# t2 from v$archived_log where standby_dest='YES'  and resetlogs_id in (select max(RESETLOGS_ID) from v$archived_log) and thread# in (1,2,3,4) and applied='YES' group by thread#) b,
(select max(sequence#) pricre, thread# t3 from v$archived_log where standby_dest='NO' and resetlogs_id in (select max(RESETLOGS_ID) from v$archived_log) and  thread# in (1,2,3,4) group by thread#) c
where a.t1=b.t2 and b.t2=c.t3 and c.t3=a.t1) order by 1
/
=============================================================================================================

SQL>  select name , database_role,open_mode  from v$database;

NAME      DATABASE_ROLE
--------- ----------------
EPPRD     PHYSICAL STANDBY

SQL> SELECT ARCH.THREAD# "Thread", ARCH.SEQUENCE# "Last Sequence Received", APPL.SEQUENCE# "Last Sequence Applied", (ARCH.SEQUENCE# - APPL.SEQUENCE#) "Difference"                                                                                      
     FROM (SELECT THREAD# ,SEQUENCE# FROM V$ARCHIVED_LOG WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$ARCHIVED_LOG GROUP BY THREAD#)) ARCH,                                                                                    
     (SELECT THREAD# ,SEQUENCE# FROM V$LOG_HISTORY WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$LOG_HISTORY GROUP BY THREAD#)) APPL                                                                                            
     WHERE ARCH.THREAD# = APPL.THREAD# ORDER BY 1;                                                                          
	 
	 
	 SELECT PROCESS, STATUS, THREAD#, SEQUENCE#, BLOCK#, BLOCKS FROM V$MANAGED_STANDBY;

	 
	 
alter system set log_archive_dest_state_2=DEFER;
alter system set log_archive_dest_state_3=DEFER;
 
	
alter system set log_archive_dest_state_2=ENABLE;
alter system set log_archive_dest_state_3=ENABLE;
 
	
select max(sequence#) from v$log_history;
	
select INST_ID,PROCESS,THREAD#,sequence#,STATUS from gv$managed_standby

	 
	 
	 
	 
	 select INST_ID,PROCESS,THREAD#,sequence#,STATUS from gv$managed_standby
	 
	 
	 
	 
	 
	 PROD:  
sfpepdb02:             
sfpepdb01:             
       
PROD DR:       
pcpepdb01:     
pcpepdb02:     
       
===========    
VAL:   
sfvepdb01:             
sfvepdb02:             
       
VAL DR:
pcvepdb01:     
pcvepdb02:     
       
===========    
TEST:  
pctepdb01:             
pctepdb02:             
       
pctepmdb01:    
pcnepdb01:     
 

	 
alter database recover managed standby database using current logfile disconnect from session;	 
	 
	 
	 
	 
	 
	 

    Thread Last Sequence Received Last Sequence Applied Difference
---------- ---------------------- --------------------- ----------
         1                 168114                167742        372
         2                 142225                141818        407

SQL>  SELECT to_char(CURRENT_SCN) FROM V$DATABASE;

TO_CHAR(CURRENT_SCN)
----------------------------------------
13055047812

SQL> select min(fhscn) from x$kcvfh;

MIN(FHSCN)
----------------
13046276636

SQL> select min(f.fhscn) from x$kcvfh f, v$datafile d where f.hxfil =d.file# and d.enabled != 'READ ONLY';
  
MIN(F.FHSCN)
----------------
13046276636

SQL> exit

**** Take backup from primary with above SCN and scp to STANDBY
RMAN> BACKUP INCREMENTAL FROM SCN 13055047812 DATABASE FORMAT '/u02/rman_bkp/ForStandby_%U' tag 'FORSTANDBY';

{edprddb1:oracle}/u02/rman_bkp > scp ForStandby3oct* oracle@epprddb1:/u02/rman_bkp
****


{edprddb1:oracle}/u02 > cd rman_bkp
{edprddb1:oracle}/u02/rman_bkp > ls
		standby_mupnqg0o_1_1
		standby_ulpqb13j_1_1
		control.ctl_17Nov2014
        standby_umpqb13k_1_1

{edprddb1:oracle}/u02/rman_bkp > ps -ef|grep mrp
  oracle  7143570        1   0   Dec 20      -  0:10 ora_mrp0_epprd1
  oracle  8913100  7078060   1 07:24:49  pts/3  0:00 grep mrp
{edprddb1:oracle}/u02/rman_bkp >
{edprddb1:oracle}/u02/rman_bkp > sqldba

SQL*Plus: Release 11.2.0.2.0 Production on Tue Dec 23 07:24:57 2014

Copyright (c) 1982, 2010, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.2.0 - 64bit Production
With the Partitioning, Real Application Clusters, Automatic Storage Management, OLAP,
Data Mining and Real Application Testing options

SQL> select name , database_role from v$database;

NAME      DATABASE_ROLE
--------- ----------------
EPPRD     PHYSICAL STANDBY

SQL>  ALTER DATABASE RECOVER MANAGED STANDBY DATABASE CANCEL;

Database altered.

SQL> spool datafile_names_3oct.txt
set lines 200
col name format a60
set pagesize 30
select file#, name from v$datafile order by file# ;
spool off

     FILE# NAME
---------- ------------------------------------------------------------
         1 +DATA/edprd/datafile/system.273.775683991
         2 +DATA/edprd/datafile/sysaux.292.775683987
         3 +DATA/edprd/datafile/undo2a.266.775683075
         4 +DATA/edprd/datafile/users.263.775683123
         5 +DATA/edprd/datafile/boss_data.267.775683093
         6 +DATA/edprd/datafile/eprogesa_audit.270.775683097
         7 +DATA/edprd/datafile/eprogesa_audit.272.775683973
         8 +DATA/edprd/datafile/eprogesa_audit.262.775683107
         9 +DATA/edprd/datafile/eprogesa_audit.274.775683977
        10 +DATA/edprd/datafile/eprogesa_audit.278.775683115
        11 +DATA/edprd/datafile/eprogesa_data.271.775682983
        12 +DATA/edprd/datafile/eprogesa_data.276.775683885
        13 +DATA/edprd/datafile/eprogesa_data.260.775683945
        14 +DATA/edprd/datafile/eprogesa_data.268.775683915
        15 +DATA/edprd/datafile/eprogesa_data.265.775683047
        16 +DATA/edprd/datafile/eprogesa_ind.297.775682949
        17 +DATA/edprd/datafile/eprogesa_ind.264.775683783
        18 +DATA/edprd/datafile/eprogesa_ind.269.775683817
        19 +DATA/edprd/datafile/eprogesa_ind.275.775683851
        20 +DATA/edprd/datafile/eprogesa_ind.259.775683015
        21 +DATA/edprd/datafile/undo1a.298.775682911
        22 +DATA/edprd/datafile/eprogesa_ind.337.853390339
        23 +DATA/edprd/datafile/boss_data.320.861429473

23 rows selected.

SQL> show parameter control

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
control_file_record_keep_time        integer     7
control_files                        string      +DATA/edprd/controlfile/curren
                                                 t.299.775682877, +ARCH/edprd/c
                                                 ontrolfile/current.809.7756828
                                                 77
control_management_pack_access       string      DIAGNOSTIC+TUNING
SQL> exit

{edprddb1:oracle}/u02/rman_bkp >
{edprddb1:oracle}/u02/rman_bkp > su - grid
grid's Password:
{edprddb1:grid}/home/grid >
{edprddb1:grid}/home/grid > asmcmd -p
ASMCMD [+] > cp +DATA/edprd/controlfile/current.299.775682877 /tmp
copying +DATA/edprd/controlfile/current.299.775682877 -> /tmp/current.299.775682877
ASMCMD [+] > exit

{edprddb1:oracle}/u02/rman_bkp >

{edprddb1:oracle}/u02/rman_bkp > ls -lrt ForStandby_0*
-rw-r-----    1 oracle   oinstall 1503526912 Dec 23 08:25 ForStandby_0bpqs9m3_1_1
-rw-r-----    1 oracle   oinstall    2588672 Dec 23 08:27 ForStandby_0dpqsb2d_1_1
-rw-r-----    1 oracle   oinstall 1192574976 Dec 23 08:27 ForStandby_0cpqs9m4_1_1
{edprddb1:oracle}/u02/rman_bkp >


{edprddb1:oracle}/u02/rman_bkp > rman

Recovery Manager: Release 11.2.0.2.0 - Production on Tue Dec 23 09:03:41 2014

Copyright (c) 1982, 2009, Oracle and/or its affiliates.  All rights reserved.

RMAN> connect target /

connected to target database: EPPRD (DBID=825479143, not open)

RMAN> catalog start with '/u02/rman_bkp/ForStandby_0' ;

using target database control file instead of recovery catalog
searching for all files that match the pattern /u02/rman_bkp/ForStandby_0

List of Files Unknown to the Database
=====================================
File Name: /u02/rman_bkp/ForStandby_0bpqs9m3_1_1
File Name: /u02/rman_bkp/ForStandby_0cpqs9m4_1_1
File Name: /u02/rman_bkp/ForStandby_0dpqsb2d_1_1

Do you really want to catalog the above files (enter YES or NO)? YES
cataloging files...
cataloging done

List of Cataloged Files
=======================
File Name: /u02/rman_bkp/ForStandby_0bpqs9m3_1_1
File Name: /u02/rman_bkp/ForStandby_0cpqs9m4_1_1
File Name: /u02/rman_bkp/ForStandby_0dpqsb2d_1_1



RMAN> recover database noredo;

Starting recover at 23-DEC-14
allocated channel: ORA_DISK_1
channel ORA_DISK_1: SID=995 instance=epprd1 device type=DISK
allocated channel: ORA_DISK_2
channel ORA_DISK_2: SID=1193 instance=epprd1 device type=DISK
channel ORA_DISK_1: starting incremental datafile backup set restore
channel ORA_DISK_1: specifying datafile(s) to restore from backup set
destination for restore of datafile 00001: +DATA/edprd/datafile/system.273.775683991
destination for restore of datafile 00002: +DATA/edprd/datafile/sysaux.292.775683987
destination for restore of datafile 00003: +DATA/edprd/datafile/undo2a.266.775683075
destination for restore of datafile 00005: +DATA/edprd/datafile/boss_data.267.775683093
destination for restore of datafile 00006: +DATA/edprd/datafile/eprogesa_audit.270.775683097
destination for restore of datafile 00008: +DATA/edprd/datafile/eprogesa_audit.262.775683107
destination for restore of datafile 00010: +DATA/edprd/datafile/eprogesa_audit.278.775683115
destination for restore of datafile 00012: +DATA/edprd/datafile/eprogesa_data.276.775683885
destination for restore of datafile 00015: +DATA/edprd/datafile/eprogesa_data.265.775683047
destination for restore of datafile 00017: +DATA/edprd/datafile/eprogesa_ind.264.775683783
destination for restore of datafile 00020: +DATA/edprd/datafile/eprogesa_ind.259.775683015
destination for restore of datafile 00023: +DATA/edprd/datafile/boss_data.320.861429473
channel ORA_DISK_1: reading from backup piece /u02/rman_bkp/ForStandby_0cpqs9m4_1_1
channel ORA_DISK_2: starting incremental datafile backup set restore
channel ORA_DISK_2: specifying datafile(s) to restore from backup set
destination for restore of datafile 00004: +DATA/edprd/datafile/users.263.775683123
destination for restore of datafile 00007: +DATA/edprd/datafile/eprogesa_audit.272.775683973
destination for restore of datafile 00009: +DATA/edprd/datafile/eprogesa_audit.274.775683977
destination for restore of datafile 00011: +DATA/edprd/datafile/eprogesa_data.271.775682983
destination for restore of datafile 00013: +DATA/edprd/datafile/eprogesa_data.260.775683945
destination for restore of datafile 00014: +DATA/edprd/datafile/eprogesa_data.268.775683915
destination for restore of datafile 00016: +DATA/edprd/datafile/eprogesa_ind.297.775682949
destination for restore of datafile 00018: +DATA/edprd/datafile/eprogesa_ind.269.775683817
destination for restore of datafile 00019: +DATA/edprd/datafile/eprogesa_ind.275.775683851
destination for restore of datafile 00021: +DATA/edprd/datafile/undo1a.298.775682911
destination for restore of datafile 00022: +DATA/edprd/datafile/eprogesa_ind.337.853390339
channel ORA_DISK_2: reading from backup piece /u02/rman_bkp/ForStandby_0bpqs9m3_1_1
channel ORA_DISK_1: piece handle=/u02/rman_bkp/ForStandby_0cpqs9m4_1_1 tag=FORSTANDBY
channel ORA_DISK_1: restored backup piece 1
channel ORA_DISK_1: restore complete, elapsed time: 00:02:15
channel ORA_DISK_2: piece handle=/u02/rman_bkp/ForStandby_0bpqs9m3_1_1 tag=FORSTANDBY
channel ORA_DISK_2: restored backup piece 1
channel ORA_DISK_2: restore complete, elapsed time: 00:02:25

Finished recover at 23-DEC-14

RMAN>

**** connect to the PRIMARY database and create a standby control file backup:

RMAN> BACKUP CURRENT CONTROLFILE FOR STANDBY FORMAT '/u02/rman_bkp/ForStandbyCTRL_3oct.ctl';

scp to standby database

{edprddb1:oracle}/u02/rman_bkp > scp ForStandbyCTRL_3oct.ctl oracle@epprddb1:/u02/rman_bkp

**** 


RMAN> catalog start with '/u02/rman_bkp/control_23dec14.ctl' ;

searching for all files that match the pattern /u02/rman_bkp/control_23dec14.ctl

List of Files Unknown to the Database
=====================================
File Name: /u02/rman_bkp/control_23dec14.ctl

Do you really want to catalog the above files (enter YES or NO)? YES
cataloging files...
cataloging done

List of Cataloged Files
=======================
File Name: /u02/rman_bkp/control_23dec14.ctl

RMAN> exit


Recovery Manager complete.
You have mail in /usr/spool/mail/oracle


{edprddb1:oracle}/u02/rman_bkp > srvctl status database -d edprd
Instance epprd1 is running on node edprddb1
Instance epprd2 is running on node edprddb2
{edprddb1:oracle}/u02/rman_bkp > srvctl stop database -d edprd
{edprddb1:oracle}/u02/rman_bkp >
{edprddb1:oracle}/u02/rman_bkp >
{edprddb1:oracle}/u02/rman_bkp > rman

Recovery Manager: Release 11.2.0.2.0 - Production on Tue Dec 23 09:13:17 2014

Copyright (c) 1982, 2009, Oracle and/or its affiliates.  All rights reserved.

RMAN> connect target /

connected to target database (not started)

RMAN> startup nomount

Oracle instance started

Total System Global Area   10288615424 bytes

Fixed Size                     2228552 bytes
Variable Size               6241128120 bytes
Database Buffers            4026531840 bytes
Redo Buffers                  18726912 bytes

RMAN> restore standby controlfile from '/u02/rman_bkp/control_23dec14.ctl';

Starting restore at 23-DEC-14
using target database control file instead of recovery catalog
allocated channel: ORA_DISK_1
channel ORA_DISK_1: SID=795 instance=epprd1 device type=DISK

channel ORA_DISK_1: copied control file copy
output file name=+DATA/edprd/controlfile/current.299.775682877
output file name=+ARCH/edprd/controlfile/current.809.775682877
Finished restore at 23-DEC-14

RMAN> shutdown

Oracle instance shut down

RMAN> startup mount

connected to target database (not started)
Oracle instance started
database mounted

Total System Global Area   10288615424 bytes

Fixed Size                     2228552 bytes
Variable Size               6241128120 bytes
Database Buffers            4026531840 bytes
Redo Buffers                  18726912 bytes

RMAN> catalog start with '+DATA/edprd/datafile/';

searching for all files that match the pattern +DATA/edprd/datafile/

List of Files Unknown to the Database
=====================================
File Name: +data/edprd/DATAFILE/UNDO1A.298.775682911
File Name: +data/edprd/DATAFILE/EPROGESA_IND.297.775682949
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.271.775682983
File Name: +data/edprd/DATAFILE/EPROGESA_IND.259.775683015
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.265.775683047
File Name: +data/edprd/DATAFILE/UNDO2A.266.775683075
File Name: +data/edprd/DATAFILE/BOSS_DATA.267.775683093
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.270.775683097
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.262.775683107
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.278.775683115
File Name: +data/edprd/DATAFILE/USERS.263.775683123
File Name: +data/edprd/DATAFILE/EPROGESA_IND.264.775683783
File Name: +data/edprd/DATAFILE/EPROGESA_IND.269.775683817
File Name: +data/edprd/DATAFILE/EPROGESA_IND.275.775683851
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.276.775683885
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.268.775683915
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.260.775683945
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.272.775683973
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.274.775683977
File Name: +data/edprd/DATAFILE/SYSAUX.292.775683987
File Name: +data/edprd/DATAFILE/SYSTEM.273.775683991
File Name: +data/edprd/DATAFILE/EPROGESA_IND.337.853390339
File Name: +data/edprd/DATAFILE/BOSS_DATA.320.861429473

Do you really want to catalog the above files (enter YES or NO)? YES
cataloging files...
cataloging done

List of Cataloged Files
=======================
File Name: +data/edprd/DATAFILE/UNDO1A.298.775682911
File Name: +data/edprd/DATAFILE/EPROGESA_IND.297.775682949
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.271.775682983
File Name: +data/edprd/DATAFILE/EPROGESA_IND.259.775683015
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.265.775683047
File Name: +data/edprd/DATAFILE/UNDO2A.266.775683075
File Name: +data/edprd/DATAFILE/BOSS_DATA.267.775683093
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.270.775683097
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.262.775683107
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.278.775683115
File Name: +data/edprd/DATAFILE/USERS.263.775683123
File Name: +data/edprd/DATAFILE/EPROGESA_IND.264.775683783
File Name: +data/edprd/DATAFILE/EPROGESA_IND.269.775683817
File Name: +data/edprd/DATAFILE/EPROGESA_IND.275.775683851
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.276.775683885
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.268.775683915
File Name: +data/edprd/DATAFILE/EPROGESA_DATA.260.775683945
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.272.775683973
File Name: +data/edprd/DATAFILE/EPROGESA_AUDIT.274.775683977
File Name: +data/edprd/DATAFILE/SYSAUX.292.775683987
File Name: +data/edprd/DATAFILE/SYSTEM.273.775683991
File Name: +data/edprd/DATAFILE/EPROGESA_IND.337.853390339
File Name: +data/edprd/DATAFILE/BOSS_DATA.320.861429473

RMAN> SWITCH DATABASE TO COPY;

datafile 1 switched to datafile copy "+DATA/edprd/datafile/system.273.775683991"
datafile 2 switched to datafile copy "+DATA/edprd/datafile/sysaux.292.775683987"
datafile 3 switched to datafile copy "+DATA/edprd/datafile/undo2a.266.775683075"
datafile 4 switched to datafile copy "+DATA/edprd/datafile/users.263.775683123"
datafile 5 switched to datafile copy "+DATA/edprd/datafile/boss_data.267.775683093"
datafile 6 switched to datafile copy "+DATA/edprd/datafile/eprogesa_audit.270.775683097"
datafile 7 switched to datafile copy "+DATA/edprd/datafile/eprogesa_audit.272.775683973"
datafile 8 switched to datafile copy "+DATA/edprd/datafile/eprogesa_audit.262.775683107"
datafile 9 switched to datafile copy "+DATA/edprd/datafile/eprogesa_audit.274.775683977"
datafile 10 switched to datafile copy "+DATA/edprd/datafile/eprogesa_audit.278.775683115"
datafile 11 switched to datafile copy "+DATA/edprd/datafile/eprogesa_data.271.775682983"
datafile 12 switched to datafile copy "+DATA/edprd/datafile/eprogesa_data.276.775683885"
datafile 13 switched to datafile copy "+DATA/edprd/datafile/eprogesa_data.260.775683945"
datafile 14 switched to datafile copy "+DATA/edprd/datafile/eprogesa_data.268.775683915"
datafile 15 switched to datafile copy "+DATA/edprd/datafile/eprogesa_data.265.775683047"
datafile 16 switched to datafile copy "+DATA/edprd/datafile/eprogesa_ind.297.775682949"
datafile 17 switched to datafile copy "+DATA/edprd/datafile/eprogesa_ind.264.775683783"
datafile 18 switched to datafile copy "+DATA/edprd/datafile/eprogesa_ind.269.775683817"
datafile 19 switched to datafile copy "+DATA/edprd/datafile/eprogesa_ind.275.775683851"
datafile 20 switched to datafile copy "+DATA/edprd/datafile/eprogesa_ind.259.775683015"
datafile 21 switched to datafile copy "+DATA/edprd/datafile/undo1a.298.775682911"
datafile 22 switched to datafile copy "+DATA/edprd/datafile/eprogesa_ind.337.853390339"
datafile 23 switched to datafile copy "+DATA/edprd/datafile/boss_data.320.861429473"

RMAN>

RMAN> exit

Recovery Manager complete.

{edprddb1:oracle}/u02/rman_bkp > srvctl start database -d edprd -o mount -n edprddb2
{edprddb1:oracle}/u02/rman_bkp > sqldba

SQL*Plus: Release 11.2.0.2.0 Production on Tue Dec 23 09:24:35 2014

Copyright (c) 1982, 2010, Oracle.  All rights reserved.


Connected to:
Oracle Database 11g Enterprise Edition Release 11.2.0.2.0 - 64bit Production
With the Partitioning, Real Application Clusters, Automatic Storage Management, OLAP,
Data Mining and Real Application Testing options

SQL> select name from v$datafile;

+DATA/edprd/datafile/system.273.775683991
+DATA/edprd/datafile/sysaux.292.775683987
+DATA/edprd/datafile/undo2a.266.775683075
+DATA/edprd/datafile/users.263.775683123
+DATA/edprd/datafile/boss_data.267.775683093
+DATA/edprd/datafile/eprogesa_audit.270.775683097
+DATA/edprd/datafile/eprogesa_audit.272.775683973
+DATA/edprd/datafile/eprogesa_audit.262.775683107
+DATA/edprd/datafile/eprogesa_audit.274.775683977
+DATA/edprd/datafile/eprogesa_audit.278.775683115
+DATA/edprd/datafile/eprogesa_data.271.775682983
+DATA/edprd/datafile/eprogesa_data.276.775683885
+DATA/edprd/datafile/eprogesa_data.260.775683945
+DATA/edprd/datafile/eprogesa_data.268.775683915
+DATA/edprd/datafile/eprogesa_data.265.775683047
+DATA/edprd/datafile/eprogesa_ind.297.775682949
+DATA/edprd/datafile/eprogesa_ind.264.775683783
+DATA/edprd/datafile/eprogesa_ind.269.775683817
+DATA/edprd/datafile/eprogesa_ind.275.775683851
+DATA/edprd/datafile/eprogesa_ind.259.775683015
+DATA/edprd/datafile/undo1a.298.775682911
+DATA/edprd/datafile/eprogesa_ind.337.853390339
+DATA/edprd/datafile/boss_data.320.861429473

23 rows selected.

SQL>
SQL> alter database recover managed standby database disconnect;

alter database recover managed standby database using current logfile disconnect from session;
Database altered.

SQL>
SQL> SELECT ARCH.THREAD# "Thread", ARCH.SEQUENCE# "Last Sequence Received", APPL.SEQUENCE# "Last Sequence Applied", (ARCH.SEQUENCE# - APPL.SEQUENCE#) "Difference"                                                                                      
    FROM (SELECT THREAD# ,SEQUENCE# FROM V$ARCHIVED_LOG WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$ARCHIVED_LOG GROUP BY THREAD#)) ARCH,                                                                                    
   (SELECT THREAD# ,SEQUENCE# FROM V$LOG_HISTORY WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$LOG_HISTORY GROUP BY THREAD#)) APPL                                                                                            
WHERE ARCH.THREAD# = APPL.THREAD# ORDER BY 1;                                                                               
  4
    Thread Last Sequence Received Last Sequence Applied Difference
---------- ---------------------- --------------------- ----------
         1                 168119                168116          3
         2                 142230                142226          4



    Thread Last Sequence Received Last Sequence Applied Difference
---------- ---------------------- --------------------- ----------
         1                 168119                168119          0
         2                 142230                142229          1

SQL>













Primary: 	 			select thread#,max(sequence#) from v$archived_log group by thread#;
Standby:	 			select thread#,max(sequence#) from v$archived_log where applied='YES' group by thread#;
9i  for both same	 	select max(sequence#) from v$log_history;
 



'
 
 
 
 
 
 
 
-- data guard status : 
 
PROMPT
PROMPT
PROMPT Run on Standby Database. This script checks last log applied and last log received time
PROMPT
PROMPT
col time format a40
select 'Last applied  : ' Logs, to_char(next_time,'DD-MON-YY:HH24:MI:SS') Time
    from v$archived_log
    where sequence# = (select max(sequence#) from v$archived_log where applied='YES')
    union
    select 'Last received : ' Logs, to_char(next_time,'DD-MON-YY:HH24:MI:SS') Time
    from v$archived_log
   where sequence# = (select max(sequence#) from v$archived_log);


PROMPT last sequence# received and the last sequence# applied to standby database.
PROMPT
select al.thrd "Thread", almax "Last Seq Received", lhmax "Last Seq Applied"
from (select thread# thrd, max(sequence#) almax
from v$archived_log
where resetlogs_change#=(select resetlogs_change# from v$database)
group by thread#) al,
(select thread# thrd, max(sequence#) lhmax
from v$log_history
where first_time=(select max(first_time) from v$log_history)
group by thread#) lh
where al.thrd = lh.thrd;




SELECT ARCH.THREAD# "Thread", ARCH.SEQUENCE# "Last Sequence Received", APPL.SEQUENCE# "Last Sequence Applied", (ARCH.SEQUENCE# - APPL.SEQUENCE#) "Difference"
FROM
(SELECT THREAD# ,SEQUENCE# FROM V$ARCHIVED_LOG WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$ARCHIVED_LOG GROUP BY THREAD#)) ARCH,
(SELECT THREAD# ,SEQUENCE# FROM V$LOG_HISTORY WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$LOG_HISTORY GROUP BY THREAD#)) APPL
WHERE
ARCH.THREAD# = APPL.THREAD#
ORDER BY 1;






















----incr recover 



restore archivelog from logseq=4127;


Stand by :


SELECT CURRENT_SCN FROM V$DATABASE;

CURRENT_SCN
-----------
1132161151

SQL> select min(checkpoint_change#) from v$datafile_header
where file# not in (select file# from v$datafile where enabled = 'READ ONLY');  2

MIN(CHECKPOINT_CHANGE#)
-----------------------
             1132161152
		
		
	
Primary :
alter database recover managed standby database using current logfile disconnect from session;
	
BACKUP INCREMENTAL FROM SCN 1132161151 DATABASE FORMAT '/oracle/recovery/vb/ForStandby_%U' tag 'FORSTANDBY';

BACKUP CURRENT CONTROLFILE FOR STANDBY FORMAT '/oracle/recovery/vb/ForStandbyCTRL.bck';

RESTORE STANDBY CONTROLFILE FROM '/oracle/recovery/vb/ForStandbyCTRL.bck';

scp /oracle/recovery/vb/ForStandby_* eml2tsysdbs01.tas.corp:/oracle/recovery/vb/


RESTORE STANDBY CONTROLFILE FROM '/oracle/recovery/vb/ForStandbyCTRL.bck';

stand by :

RESTOER DATABASE NOREDO;

RESTORE STANDBY CONTROLFILE FROM '/oracle/recovery/vb/ForStandbyCTRL.bck';

spool standby_datafile_names.txt
set pagesize 1000;
set lines 200
col name format a60
select file#, name from v$datafile order by file# ;
spool off