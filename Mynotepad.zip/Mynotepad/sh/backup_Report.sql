# #################################################
# Backup Report Statistics On RMANRED .
# To be run by ORACLE user                   
#                                       #   #     #
# Author:       Vishal Bhandwalkar         # # # #   ###
# Created:      28-JULY-2017         #   #   # #   #
#                                              
#
# #################################################

export ORACLE_HOME=/appl/oracle/product/v11203
export PATH=$PATH:$ORACLE_HOME/bin
export ORACLE_SID=aorman11
export Day=`date +%y%m%d`
cd /appl/oracle/BACKUPREPORT
sqlplus "/ as sysdba" << EOF 
@/appl/oracle/BACKUPREPORT/bkp.sql
exit
EOF
mailx -s "NAM Backup_Report_$Day " -a /appl/oracle/BACKUPREPORT/DATABASE_AORMAN11_$Day.html vishal-vilas.bandwalkar@atos.net < /appl/oracle/BACKUPREPORT/Email_body.txt
#mail -s "test backup " -a /appl/oracle/BACKUPREPORTBackup_Final_$Day.log  -a  /home/oracle/BackupReport/Backup_Final_$Day.xls  dba

======================================================================================================================================






prompt

define reportHeader="<font size=+3 color=darkgreen><b>BACKUP REPORT <i> </i> VANATOR </b></font><hr> DLINO-NAIMO-ORACLE-SUPPORT VENAOR (<a target=""_blank"" href=""DLINO-NAIMO-ORACLE-SUPPORT.it-solutions@atos.net"">DLINO-NAIMO-ORACLE-SUPPORT</a>)<p>"


-- +----------------------------------------------------------------------------+
-- |                           SCRIPT SETTINGS                                  |
-- +----------------------------------------------------------------------------+

set termout       off
set echo          off
set feedback      off
set heading       off
set verify        off
set wrap          on
set trimspool     on
set serveroutput  on
set escape        on

set pagesize 50000
set linesize 175
set long     2000000000

clear buffer computes columns breaks

define fileName=DATABASE BACKUP
define versionNumber=5.3


-- +----------------------------------------------------------------------------+
-- |                   GATHER DATABASE REPORT INFORMATION                       |
-- +----------------------------------------------------------------------------+

COLUMN tdate NEW_VALUE _date NOPRINT
SELECT TO_CHAR(SYSDATE,'MM/DD/YYYY') tdate FROM dual;

COLUMN time NEW_VALUE _time NOPRINT
SELECT TO_CHAR(SYSDATE,'HH24:MI:SS') time FROM dual;

COLUMN date_time NEW_VALUE _date_time NOPRINT
SELECT TO_CHAR(SYSDATE,'MM/DD/YYYY HH24:MI:SS') date_time FROM dual;

COLUMN date_time_timezone NEW_VALUE _date_time_timezone NOPRINT
SELECT TO_CHAR(systimestamp, 'Mon DD, YYYY (') || TRIM(TO_CHAR(systimestamp, 'Day')) || TO_CHAR(systimestamp, ') "at" HH:MI:SS AM') || TO_CHAR(systimestamp, ' "in Timezone" TZR') date_time_timezone
FROM dual;

COLUMN spool_time NEW_VALUE _spool_time NOPRINT
SELECT TO_CHAR(SYSDATE,'YYMMDD') spool_time FROM dual;

COLUMN dbname NEW_VALUE _dbname NOPRINT
SELECT name dbname FROM v$database;

COLUMN dbid NEW_VALUE _dbid NOPRINT
SELECT dbid dbid FROM v$database;

COLUMN platform_id NEW_VALUE _platform_id NOPRINT
SELECT platform_id platform_id FROM v$database;

COLUMN platform_name NEW_VALUE _platform_name NOPRINT
SELECT platform_name platform_name FROM v$database;

COLUMN global_name NEW_VALUE _global_name NOPRINT
SELECT global_name global_name FROM global_name;

COLUMN blocksize NEW_VALUE _blocksize NOPRINT
SELECT value blocksize FROM v$parameter WHERE name='db_block_size';

COLUMN startup_time NEW_VALUE _startup_time NOPRINT
SELECT TO_CHAR(startup_time, 'MM/DD/YYYY HH24:MI:SS') startup_time FROM v$instance;

COLUMN host_name NEW_VALUE _host_name NOPRINT
SELECT host_name host_name FROM v$instance;

COLUMN instance_name NEW_VALUE _instance_name NOPRINT
SELECT instance_name instance_name FROM v$instance;

COLUMN instance_number NEW_VALUE _instance_number NOPRINT
SELECT instance_number instance_number FROM v$instance;

COLUMN thread_number NEW_VALUE _thread_number NOPRINT
SELECT thread# thread_number FROM v$instance;

COLUMN cluster_database NEW_VALUE _cluster_database NOPRINT
SELECT value cluster_database FROM v$parameter WHERE name='cluster_database';

COLUMN cluster_database_instances NEW_VALUE _cluster_database_instances NOPRINT
SELECT value cluster_database_instances FROM v$parameter WHERE name='cluster_database_instances';

COLUMN reportRunUser NEW_VALUE _reportRunUser NOPRINT
SELECT user reportRunUser FROM dual;



-- +----------------------------------------------------------------------------+
-- |                   GATHER DATABASE REPORT INFORMATION                       |
-- +----------------------------------------------------------------------------+

set heading on

set markup html on spool on preformat off entmap on -
head ' -
  <title>Database Report</title> -
  <style type="text/css"> -
    body              {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;} -
    p                 {font:9pt Arial,Helvetica,sans-serif; color:black; background:White;} -
    table,tr,td       {font:9pt Arial,Helvetica,sans-serif; color:Black; background:#C0C0C0; padding:0px 0px 0px 0px; margin:0px 0px 0px 0px;} -
    th                {font:bold 9pt Arial,Helvetica,sans-serif; color:#336699; background:#cccc99; padding:0px 0px 0px 0px;} -
    h1                {font:bold 12pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; border-bottom:1px solid #cccc99; margin-top:0pt; margin-bottom:0pt; padding:0px 0px 0px 0px;} -
    h2                {font:bold 10pt Arial,Helvetica,Geneva,sans-serif; color:#336699; background-color:White; margin-top:4pt; margin-bottom:0pt;} -
    a                 {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.link            {font:9pt Arial,Helvetica,sans-serif; color:#663300; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLink          {font:9pt Arial,Helvetica,sans-serif; color:#663300; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkBlue      {font:9pt Arial,Helvetica,sans-serif; color:#0000ff; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkBlue  {font:9pt Arial,Helvetica,sans-serif; color:#000099; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkRed       {font:9pt Arial,Helvetica,sans-serif; color:#ff0000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkRed   {font:9pt Arial,Helvetica,sans-serif; color:#990000; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkGreen     {font:9pt Arial,Helvetica,sans-serif; color:#00ff00; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
    a.noLinkDarkGreen {font:9pt Arial,Helvetica,sans-serif; color:#009900; text-decoration: none; margin-top:0pt; margin-bottom:0pt; vertical-align:top;} -
  </style>' -
body   'BGCOLOR="#C0C0C0"' -
table  'WIDTH="90%" BORDER="1"'

spool &FileName._&_dbname._&_spool_time..html

set markup html on entmap off


-- +----------------------------------------------------------------------------+
-- |                             - REPORT HEADER -                              |
-- +----------------------------------------------------------------------------+

prompt <a name=top></a>
prompt &reportHeader





-- +============================================================================+
-- |                                                                            |
-- |        <<<<<     Database and Instance Information    >>>>>                |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Database and Instance Information</u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                            - REPORT HEADER -                               |
-- +----------------------------------------------------------------------------+

prompt
prompt <a name="report_header"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Report Header</b></font><hr align="left" width="460">

prompt <table width="90%" border="1"> -
<tr><th align="left" width="20%">Report Name</th><td width="80%"><tt>&FileName._&_dbname._&_spool_time..html</tt></td></tr> -
<tr><th align="left" width="20%">Snapshot Database Version</th><td width="80%"><tt>&versionNumber</tt></td></tr> -
<tr><th align="left" width="20%">Run Date / Time / Timezone</th><td width="80%"><tt>&_date_time_timezone</tt></td></tr> -
<tr><th align="left" width="20%">Host Name</th><td width="80%"><tt>&_host_name</tt></td></tr> -
<tr><th align="left" width="20%">Database Name</th><td width="80%"><tt>&_dbname</tt></td></tr> -
<tr><th align="left" width="20%">Database ID</th><td width="80%"><tt>&_dbid</tt></td></tr> -
<tr><th align="left" width="20%">Global Database Name</th><td width="80%"><tt>&_global_name</tt></td></tr> -
<tr><th align="left" width="20%">Platform Name / ID</th><td width="80%"><tt>&_platform_name / &_platform_id</tt></td></tr> -
<tr><th align="left" width="20%">Clustered Database?</th><td width="80%"><tt>&_cluster_database</tt></td></tr> -
<tr><th align="left" width="20%">Clustered Database Instances</th><td width="80%"><tt>&_cluster_database_instances</tt></td></tr> -
<tr><th align="left" width="20%">Instance Name</th><td width="80%"><tt>&_instance_name</tt></td></tr> -
<tr><th align="left" width="20%">Instance Number</th><td width="80%"><tt>&_instance_number</tt></td></tr> -
<tr><th align="left" width="20%">Thread Number</th><td width="80%"><tt>&_thread_number</tt></td></tr> -
<tr><th align="left" width="20%">Database Startup Time</th><td width="80%"><tt>&_startup_time</tt></td></tr> -
<tr><th align="left" width="20%">Database Block Size</th><td width="80%"><tt>&_blocksize</tt></td></tr> -
<tr><th align="left" width="20%">Report Run User</th><td width="80%"><tt>&_reportRunUser</tt></td></tr> -
</table>

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- SET TIMING ON




-- +----------------------------------------------------------------------------+
-- |                                 - VERSION -                                |
-- +----------------------------------------------------------------------------+

prompt <a name="version"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Version</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN banner   FORMAT a120   HEADING 'Banner'

SELECT * FROM v$version;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +----------------------------------------------------------------------------+
-- |                         - DATABASE REGISTRY -                              |
-- +----------------------------------------------------------------------------+

prompt <a name="database_registry"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Registry</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN comp_id       FORMAT a75   HEADING 'Component ID'       ENTMAP off
COLUMN comp_name     FORMAT a75   HEADING 'Component Name'     ENTMAP off
COLUMN version                    HEADING 'Version'            ENTMAP off
COLUMN status        FORMAT a75   HEADING 'Status'             ENTMAP off
COLUMN modified      FORMAT a75   HEADING 'Modified'           ENTMAP off
COLUMN control                    HEADING 'Control'            ENTMAP off
COLUMN schema                     HEADING 'Schema'             ENTMAP off
COLUMN procedure                  HEADING 'Procedure'          ENTMAP off

SELECT
    '<font color="#336699"><b>' || comp_id    || '</b></font>' comp_id
  , '<div nowrap>' || comp_name || '</div>'                    comp_name
  , version
  , DECODE(   status
            , 'VALID',   '<div align="center"><b><font color="darkgreen">' || status || '</font></b></div>'
            , 'INVALID', '<div align="center"><b><font color="#990000">'   || status || '</font></b></div>'
            ,            '<div align="center"><b><font color="#663300">'   || status || '</font></b></div>' ) status
  , '<div nowrap align="right">' || modified || '</div>'                      modified
  , control
  , schema
  , procedure
FROM dba_registry
ORDER BY comp_name;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>






-- +----------------------------------------------------------------------------+
-- |                           - INSTANCE OVERVIEW -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="instance_overview"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Instance Overview</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN instance_name_print       FORMAT a75    HEADING 'Instance|Name'       ENTMAP off
COLUMN instance_number_print     FORMAT a75    HEADING 'Instance|Num'        ENTMAP off
COLUMN thread_number_print                     HEADING 'Thread|Num'          ENTMAP off
COLUMN host_name_print           FORMAT a75    HEADING 'Host|Name'           ENTMAP off
COLUMN version                                 HEADING 'Oracle|Version'      ENTMAP off
COLUMN start_time                FORMAT a75    HEADING 'Start|Time'          ENTMAP off
COLUMN uptime                                  HEADING 'Uptime|(in days)'    ENTMAP off
COLUMN parallel                  FORMAT a75    HEADING 'Parallel - (RAC)'    ENTMAP off
COLUMN instance_status           FORMAT a75    HEADING 'Instance|Status'     ENTMAP off
COLUMN database_status           FORMAT a75    HEADING 'Database|Status'     ENTMAP off
COLUMN logins                    FORMAT a75    HEADING 'Logins'              ENTMAP off
COLUMN archiver                  FORMAT a75    HEADING 'Archiver'            ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>' || instance_name || '</b></font></div>'         instance_name_print
  , '<div align="center">' || instance_number || '</div>'                                           instance_number_print
  , '<div align="center">' || thread#         || '</div>'                                           thread_number_print
  , '<div align="center">' || host_name       || '</div>'                                           host_name_print
  , '<div align="center">' || version         || '</div>'                                           version
  , '<div align="center">' || TO_CHAR(startup_time,'mm/dd/yyyy HH24:MI:SS') || '</div>'             start_time
  , ROUND(TO_CHAR(SYSDATE-startup_time), 2)                                                         uptime
  , '<div align="center">' || parallel        || '</div>'                                           parallel
  , '<div align="center">' || status          || '</div>'                                           instance_status
  , '<div align="center">' || logins          || '</div>'                                           logins
  , DECODE(   archiver
            , 'FAILED'
            , '<div align="center"><b><font color="#990000">'   || archiver || '</font></b></div>'
            , '<div align="center"><b><font color="darkgreen">' || archiver || '</font></b></div>') archiver
FROM gv$instance
ORDER BY instance_number;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +----------------------------------------------------------------------------+
-- |                           - DATABASE OVERVIEW -                            |
-- +----------------------------------------------------------------------------+

prompt <a name="database_overview"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Overview</b></font><hr align="left" width="460">

CLEAR COLUMNS BREAKS COMPUTES

COLUMN name                            FORMAT a75     HEADING 'Database|Name'              ENTMAP off
COLUMN dbid                                           HEADING 'Database|ID'                ENTMAP off
COLUMN db_unique_name                                 HEADING 'Database|Unique Name'       ENTMAP off
COLUMN creation_date                                  HEADING 'Creation|Date'              ENTMAP off
COLUMN platform_name_print                            HEADING 'Platform|Name'              ENTMAP off
COLUMN current_scn                                    HEADING 'Current|SCN'                ENTMAP off
COLUMN log_mode                                       HEADING 'Log|Mode'                   ENTMAP off
COLUMN open_mode                                      HEADING 'Open|Mode'                  ENTMAP off
COLUMN force_logging                                  HEADING 'Force|Logging'              ENTMAP off
COLUMN flashback_on                                   HEADING 'Flashback|On?'              ENTMAP off
COLUMN controlfile_type                               HEADING 'Controlfile|Type'           ENTMAP off
COLUMN last_open_incarnation_number                   HEADING 'Last Open|Incarnation Num'  ENTMAP off

SELECT
    '<div align="center"><font color="#336699"><b>'  || name  || '</b></font></div>'          name
  , '<div align="center">' || dbid                   || '</div>'                              dbid
  , '<div align="center">' || db_unique_name         || '</div>'                              db_unique_name
  , '<div align="center">' || TO_CHAR(created, 'mm/dd/yyyy HH24:MI:SS') || '</div>'           creation_date
  , '<div align="center">' || platform_name          || '</div>'                              platform_name_print
  , '<div align="center">' || current_scn            || '</div>'                              current_scn
  , '<div align="center">' || log_mode               || '</div>'                              log_mode
  , '<div align="center">' || open_mode              || '</div>'                              open_mode
  , '<div align="center">' || force_logging          || '</div>'                              force_logging
  , '<div align="center">' || flashback_on           || '</div>'                              flashback_on
  , '<div align="center">' || controlfile_type       || '</div>'                              controlfile_type
  , '<div align="center">' || last_open_incarnation# || '</div>'                              last_open_incarnation_number
FROM v$database;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>




-- +============================================================================+
-- |                                                                            |
-- |                      <<<<<     BACKUPS     >>>>>                           |
-- |                                                                            |
-- +============================================================================+


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Backup HOT and INCR </u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                           - RMAN BACKUP JOBS FGA -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_jobs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Details for FGA </b></font><hr align="left" width="460">

prompt <b> </b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN backup_name           FORMAT a130   HEADING 'Backup Name'          ENTMAP off
COLUMN start_time            FORMAT a75    HEADING 'Start Time'           ENTMAP off
COLUMN elapsed_time          FORMAT a75    HEADING 'Elapsed Time'         ENTMAP off
COLUMN status                              HEADING 'Status'               ENTMAP off
COLUMN input_type                          HEADING 'Input Type'           ENTMAP off
COLUMN output_device_type                  HEADING 'Output Devices'       ENTMAP off
COLUMN input_size                          HEADING 'Input Size'           ENTMAP off
COLUMN output_size                         HEADING 'Output Size'          ENTMAP off
COLUMN output_rate_per_sec                 HEADING 'Output Rate Per Sec'  ENTMAP off

SELECT unique
    '<div nowrap><b><font color="#336699">' || r.DB_NAME                                   || '</font></b></div>'  DB_NAME
	,'<div nowrap><b><font color="#336699">' || r.HOSTNAME                                   || '</font></b></div>'  HOSTNAME
                , '<div nowrap align="right">'            || TO_CHAR(r.start_time, 'mm/dd/yyyy HH24:MI:SS') || '</div>'             start_time
  , '<div nowrap align="right">'            || r.time_taken_display                           || '</div>'             elapsed_time
  , DECODE(   r.status
            , 'COMPLETED'
            , '<div align="center"><b><font color="darkgreen">' || r.status || '</font></b></div>'
            , 'RUNNING'
            , '<div align="center"><b><font color="#000099">'   || r.status || '</font></b></div>'
            , 'FAILED'
            , '<div align="center"><b><font color="#990000">'   || r.status || '</font></b></div>'
            , '<div align="center"><b><font color="#663300">'   || r.status || '</font></b></div>'
    )                                                                                       status
  , r.input_type                                                                            input_type
  , r.output_device_type                                                                    output_device_type
  , '<div nowrap align="right">' || r.input_bytes_display           || '</div>'  input_size
  , '<div nowrap align="right">' || r.output_bytes_display          || '</div>'  output_size
  , '<div nowrap align="right">' || r.output_bytes_per_sec_display  || '</div>'  output_rate_per_sec
FROM
    (select
         b.command_id
           , b.DB_NAME
           , i.HOSTNAME
       , b.start_time
       , b.time_taken_display
       , b.status
       , b.input_type
       , b.output_device_type
       , b.input_bytes_display
       , b.output_bytes_display
       , b.output_bytes_per_sec_display
           , b.SESSION_KEY
     from RMAN_FGA.RC_RMAN_BACKUP_JOB_DETAILS b ,RMAN_FGA.RC_HOST  i WHERE b.DB_KEY=i.DB_KEY  AND b.DB_NAME IN ('ADPIDEV ','HRCANDEV','HRCANTST','HRUSADEV','HRUSATST','NJCADEV','NJCATST','NJUSDEV','NJUSTST','CAPRD','HEATPRD','BAGSPRD','FOCUSPRD','NJPRD' ,'NJCAPRD','FNPRD','KRONOSPD','CADEV','ORADEV01','BAGSDEV','FOCUSDEV','FOCUSDEV','FOCUSPRF','GENDB','DWDEV','DWRPTDEV','RMANDEV','XETLDEV', 'ADPIPRD','DWPRD','DWRPTPRD','RMANPRD','XETLPRD','ADPITST','DWSYS','GENDBSYS','XETLSYS','IMGT','SLRCT','SLRT','SLRCP','SLRP','PRD4', 'HRCANPRD','HRUSAPRD')
     order by start_time DESC
    ) r
WHERE
       regexp_like(input_type,'incr|full','i') and start_time > sysdate-1 order by start_time;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +----------------------------------------------------------------------------+
-- |                           - RMAN BACKUP JOBS DRG -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_jobs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Details for DRG </b></font><hr align="left" width="460">

prompt <b> </b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN backup_name           FORMAT a130   HEADING 'Backup Name'          ENTMAP off
COLUMN start_time            FORMAT a75    HEADING 'Start Time'           ENTMAP off
COLUMN elapsed_time          FORMAT a75    HEADING 'Elapsed Time'         ENTMAP off
COLUMN status                              HEADING 'Status'               ENTMAP off
COLUMN input_type                          HEADING 'Input Type'           ENTMAP off
COLUMN output_device_type                  HEADING 'Output Devices'       ENTMAP off
COLUMN input_size                          HEADING 'Input Size'           ENTMAP off
COLUMN output_size                         HEADING 'Output Size'          ENTMAP off
COLUMN output_rate_per_sec                 HEADING 'Output Rate Per Sec'  ENTMAP off

SELECT unique
    '<div nowrap><b><font color="#336699">' || r.DB_NAME                                   || '</font></b></div>'  DB_NAME
	,'<div nowrap><b><font color="#336699">' || r.HOSTNAME                                   || '</font></b></div>'  HOSTNAME
                , '<div nowrap align="right">'            || TO_CHAR(r.start_time, 'mm/dd/yyyy HH24:MI:SS') || '</div>'             start_time
  , '<div nowrap align="right">'            || r.time_taken_display                           || '</div>'             elapsed_time
  , DECODE(   r.status
            , 'COMPLETED'
            , '<div align="center"><b><font color="darkgreen">' || r.status || '</font></b></div>'
            , 'RUNNING'
            , '<div align="center"><b><font color="#000099">'   || r.status || '</font></b></div>'
            , 'FAILED'
            , '<div align="center"><b><font color="#990000">'   || r.status || '</font></b></div>'
            , '<div align="center"><b><font color="#663300">'   || r.status || '</font></b></div>'
    )                                                                                       status
  , r.input_type                                                                            input_type
  , r.output_device_type                                                                    output_device_type
  , '<div nowrap align="right">' || r.input_bytes_display           || '</div>'  input_size
  , '<div nowrap align="right">' || r.output_bytes_display          || '</div>'  output_size
  , '<div nowrap align="right">' || r.output_bytes_per_sec_display  || '</div>'  output_rate_per_sec
FROM
    (select
         b.command_id
           , b.DB_NAME
           , i.HOSTNAME
       , b.start_time
       , b.time_taken_display
       , b.status
       , b.input_type
       , b.output_device_type
       , b.input_bytes_display
       , b.output_bytes_display
       , b.output_bytes_per_sec_display
           , b.SESSION_KEY
     from RMAN_DRG.RC_RMAN_BACKUP_JOB_DETAILS b ,RMAN_DRG.RC_HOST  i WHERE b.DB_KEY=i.DB_KEY  AND b.DB_NAME IN ('PDSAFEUS','QDSAFEUS','PILMADM','QILMADM','DDSAFEUS')
     order by start_time DESC
    ) r
WHERE
       regexp_like(input_type,'incr|full','i') and start_time > sysdate-1 order by start_time;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>


prompt
prompt <center><font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b><u>Backup HOT and INCR </u></b></font></center>


-- +----------------------------------------------------------------------------+
-- |                           - RMAN BACKUP JOBS ARCHIVE -                             |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_jobs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Details for FGA </b></font><hr align="left" width="460">

prompt <b> </b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN backup_name           FORMAT a130   HEADING 'Backup Name'          ENTMAP off
COLUMN start_time            FORMAT a75    HEADING 'Start Time'           ENTMAP off
COLUMN elapsed_time          FORMAT a75    HEADING 'Elapsed Time'         ENTMAP off
COLUMN status                              HEADING 'Status'               ENTMAP off
COLUMN input_type                          HEADING 'Input Type'           ENTMAP off
COLUMN output_device_type                  HEADING 'Output Devices'       ENTMAP off
COLUMN input_size                          HEADING 'Input Size'           ENTMAP off
COLUMN output_size                         HEADING 'Output Size'          ENTMAP off
COLUMN output_rate_per_sec                 HEADING 'Output Rate Per Sec'  ENTMAP off

SELECT unique
    '<div nowrap><b><font color="#336699">' || r.DB_NAME                                   || '</font></b></div>'  DB_NAME
	,'<div nowrap><b><font color="#336699">' || r.HOSTNAME                                   || '</font></b></div>'  HOSTNAME
                , '<div nowrap align="right">'            || TO_CHAR(r.start_time, 'mm/dd/yyyy HH24:MI:SS') || '</div>'             start_time
  , '<div nowrap align="right">'            || r.time_taken_display                           || '</div>'             elapsed_time
  , DECODE(   r.status
            , 'COMPLETED'
            , '<div align="center"><b><font color="darkgreen">' || r.status || '</font></b></div>'
            , 'RUNNING'
            , '<div align="center"><b><font color="#000099">'   || r.status || '</font></b></div>'
            , 'FAILED'
            , '<div align="center"><b><font color="#990000">'   || r.status || '</font></b></div>'
            , '<div align="center"><b><font color="#663300">'   || r.status || '</font></b></div>'
    )                                                                                       status
  , r.input_type                                                                            input_type
  , r.output_device_type                                                                    output_device_type
  , '<div nowrap align="right">' || r.input_bytes_display           || '</div>'  input_size
  , '<div nowrap align="right">' || r.output_bytes_display          || '</div>'  output_size
  , '<div nowrap align="right">' || r.output_bytes_per_sec_display  || '</div>'  output_rate_per_sec
FROM
    (select
         b.command_id
           , b.DB_NAME
           , i.HOSTNAME
       , b.start_time
       , b.time_taken_display
       , b.status
       , b.input_type
       , b.output_device_type
       , b.input_bytes_display
       , b.output_bytes_display
       , b.output_bytes_per_sec_display
           , b.SESSION_KEY
     from RMAN_FGA.RC_RMAN_BACKUP_JOB_DETAILS b ,RMAN_FGA.RC_HOST  i WHERE b.DB_KEY=i.DB_KEY  AND b.DB_NAME IN ('ADPIDEV ','HRCANDEV','HRCANTST','HRUSADEV','HRUSATST','NJCADEV','NJCATST','NJUSDEV','NJUSTST','CAPRD','HEATPRD','BAGSPRD','FOCUSPRD','NJPRD' ,'NJCAPRD','FNPRD','KRONOSPD','CADEV','ORADEV01','BAGSDEV','FOCUSDEV','FOCUSDEV','FOCUSPRF','GENDB','DWDEV','DWRPTDEV','RMANDEV','XETLDEV', 'ADPIPRD','DWPRD','DWRPTPRD','RMANPRD','XETLPRD','ADPITST','DWSYS','GENDBSYS','XETLSYS','IMGT','SLRCT','SLRT','SLRCP','SLRP','PRD4', 'HRCANPRD','HRUSAPRD')
     order by start_time DESC
    ) r
WHERE
       regexp_like(input_type,'ARCHIVELOG','i') and start_time > sysdate-1 order by start_time;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +----------------------------------------------------------------------------+
-- |                           - RMAN BACKUP JOBS DRG (ARCHIVE)-                             |
-- +----------------------------------------------------------------------------+

prompt <a name="rman_backup_jobs"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>RMAN Backup Details for DRG </b></font><hr align="left" width="460">

prompt <b> </b>

CLEAR COLUMNS BREAKS COMPUTES

COLUMN backup_name           FORMAT a130   HEADING 'Backup Name'          ENTMAP off
COLUMN start_time            FORMAT a75    HEADING 'Start Time'           ENTMAP off
COLUMN elapsed_time          FORMAT a75    HEADING 'Elapsed Time'         ENTMAP off
COLUMN status                              HEADING 'Status'               ENTMAP off
COLUMN input_type                          HEADING 'Input Type'           ENTMAP off
COLUMN output_device_type                  HEADING 'Output Devices'       ENTMAP off
COLUMN input_size                          HEADING 'Input Size'           ENTMAP off
COLUMN output_size                         HEADING 'Output Size'          ENTMAP off
COLUMN output_rate_per_sec                 HEADING 'Output Rate Per Sec'  ENTMAP off

SELECT unique
    '<div nowrap><b><font color="#336699">' || r.DB_NAME                                   || '</font></b></div>'  DB_NAME
	,'<div nowrap><b><font color="#336699">' || r.HOSTNAME                                   || '</font></b></div>'  HOSTNAME
                , '<div nowrap align="right">'            || TO_CHAR(r.start_time, 'mm/dd/yyyy HH24:MI:SS') || '</div>'             start_time
  , '<div nowrap align="right">'            || r.time_taken_display                           || '</div>'             elapsed_time
  , DECODE(   r.status
            , 'COMPLETED'
            , '<div align="center"><b><font color="darkgreen">' || r.status || '</font></b></div>'
            , 'RUNNING'
            , '<div align="center"><b><font color="#000099">'   || r.status || '</font></b></div>'
            , 'FAILED'
            , '<div align="center"><b><font color="#990000">'   || r.status || '</font></b></div>'
            , '<div align="center"><b><font color="#663300">'   || r.status || '</font></b></div>'
    )                                                                                       status
  , r.input_type                                                                            input_type
  , r.output_device_type                                                                    output_device_type
  , '<div nowrap align="right">' || r.input_bytes_display           || '</div>'  input_size
  , '<div nowrap align="right">' || r.output_bytes_display          || '</div>'  output_size
  , '<div nowrap align="right">' || r.output_bytes_per_sec_display  || '</div>'  output_rate_per_sec
FROM
    (select
         b.command_id
           , b.DB_NAME
           , i.HOSTNAME
       , b.start_time
       , b.time_taken_display
       , b.status
       , b.input_type
       , b.output_device_type
       , b.input_bytes_display
       , b.output_bytes_display
       , b.output_bytes_per_sec_display
           , b.SESSION_KEY
     from RMAN_DRG.RC_RMAN_BACKUP_JOB_DETAILS b ,RMAN_DRG.RC_HOST  i WHERE b.DB_KEY=i.DB_KEY  AND b.DB_NAME IN ('PDSAFEUS','QDSAFEUS','PILMADM','QILMADM','DDSAFEUS')
     order by start_time DESC
    ) r
WHERE
       regexp_like(input_type,'ARCHIVELOG','i') and start_time > sysdate-1 order by start_time;

prompt <center>[<a class="noLink" href="#top">Top</a>]</center><p>



-- +----------------------------------------------------------------------------+
-- |                            - END OF REPORT -                               |
-- +----------------------------------------------------------------------------+

SPOOL OFF

SET MARKUP HTML OFF

SET TERMOUT ON

prompt
prompt Output written to: &FileName._&_dbname._&_spool_time..html

EXIT;


