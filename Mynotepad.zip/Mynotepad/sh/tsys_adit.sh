###############################################################################
0 0 1 * * /home/oracle/scripts/audit_reports/Patch_report.sh                    > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/Profile_Security.sh                > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/All_Logins.sh                              > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/DBA_Role.sh                                > /dev/null 2>&1
0 0 1 * * /home/oracle/scripts/audit_reports/User_Grants.sh                     > /dev/null 2>&1
wpl2mltidbs01.tsysacquiring.org:/home/oracle> ll /home/oracle/scripts/audit_reports/Patch_report.sh
-rwxr-xr-x 1 oracle oinstall 1486 Mar 22 18:50 /home/oracle/scripts/audit_reports/Patch_report.sh
wpl2mltidbs01.tsysacquiring.org:/home/oracle> cat /home/oracle/scripts/audit_reports/Patch_report.sh
#!/bin/bash


export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=oemrep
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH
export FHOST=${HOST}
export FNAME=${FHOST%%.*}_Patch_Report_${SDATE}
export SUBJ=${FNAME}

 cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv

sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1
SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'This is PSU Patch Report on monthly basis.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT ' ' from dual;

SELECT RPAD('ACTION_TIME',30,' ')||','||
       RPAD('ACTION',25,' ')||','||
       RPAD('NAMESPACE',25,' ')||','||
       RPAD('VERSION',25,' ')||','||
           RPAD('ID',20,' ')||','||
           RPAD('BUNDLE_SERIES',20,' ')||','||
       RPAD('COMMENTS',30,' ')
  FROM DUAL;

SELECT ' ' FROM DUAL;



select  rg.ACTION_TIME  ||','||rg.ACTION ||','|| rg.NAMESPACE ||','|| rg.VERSION ||','|| rg.ID ||','||  rg.BUNDLE_SERIES ||','|| rg.COMMENTS  from  sys.registry\$history  rg;

EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv |wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv  /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi

wpl2mltidbs01.tsysacquiring.org:/home/oracle> cat /home/oracle/scripts/audit_reports/perlmail.pl
#!/usr/bin/perl


use MIME::Lite;
use Net::SMTP;

#my $FILE_NAME=$ARGV[0];


### Adjust sender, recipient and your SMTP mailhost
my $from_address = 'ifx-dbalerts@tsys.com';
# my $to_address = 'baidhardas@tsys.com';
my $to_address = 'baidhardas@tsys.com,SWorachek@tsys.com,leblance@tsys.com';
my $mail_host = 'smtpwest.tas.corp';
#
### Adjust subject and body message

#$subject = "Audit Report" ;
$subject = $ARGV[2];

my $message_body = "Hello All,

Please see attached report for Database Audit.

Thanks and Regards,
DBA Team

";



### Adjust the filenames
my $my_attach_file_path =$ARGV[1];
# my $my_attach_file ="$my_attach_file_path/$ARGV[0]";
my $my_attach_file ="$ARGV[0]";


### Create the multipart container
$msg = MIME::Lite->new (
From => $from_address,
To => $to_address,
Subject => $subject,
Type =>'multipart/mixed'
) or die "Error creating multipart container: $i\n";

    ### Add the text message part
    $msg->attach (
    Type => 'TEXT/HTML',
    Data => $message_body
    ) or die "Error adding the text message part: $!\n";

#    ### Add the ZIP file
    $msg->attach (
      Type => 'TEXT/PLAIN',
      Path => $my_attach_file_path,
      Filename => $my_attach_file,
      Disposition => 'attachment'
      ) or die "Error adding $file_zip: $!\n";

### Send the Message
MIME::Lite->send('smtp', $mail_host, Timeout=>60);
$msg->send;

wpl2mltidbs01.tsysacquiring.org:/home/oracle> cat /home/oracle/scripts/audit_reports/Profile_Security.sh
#!/bin/bash

export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=oemrep
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

export FHOST=${HOST}
export FNAME=${FHOST%%.*}_Profile_Security_${SDATE}
export SUBJ=${FNAME}

#export FNAME=${HOST}_Profile_Security_${SDATE}

cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv


sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1
SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'This is the audit profile Security.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT ' ' from dual;

SELECT RPAD('PROFILE',30,' ')||','||
       RPAD('RESOURCE NAME',25,' ')||','||
           RPAD('RESOURCE TYPE',30,' ')||','||
           RPAD('LIMIT',30,' ')
  FROM DUAL;

SELECT ' ' FROM DUAL;


Select  p.PROFILE ||','|| p.RESOURCE_NAME ||','|| p.RESOURCE_TYPE ||','|| p.LIMIT  from dba_profiles p where resource_type = 'PASSWORD'  order by p.PROFILE;


EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv |wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi

wpl2mltidbs01.tsysacquiring.org:/home/oracle> cat /home/oracle/scripts/audit_reports/All_Logins.sh
#!/bin/bash

export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=oemrep
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH



export FHOST=${HOST}
export FNAME=${FHOST%%.*}_All_Logins_${SDATE}
export SUBJ=${FNAME}

# export FNAME=${HOST}_All_Logins__${SDATE}

cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv

sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1
SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'This is the audit requirement on monthly basis.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT ' ' from dual;

SELECT RPAD('USER NAME',30,' ')||','||
       RPAD('ACCOUNT STATUS',15,' ')||','||
           RPAD('CREATION DATE',13,' ')||','||
       RPAD('LOCK DATE',10,' ')||','||
       RPAD('EXPIRY DATE',25,' ')||','||
          RPAD('PTIME',20,' ')||','||
           RPAD('LAST LOGIN',20,' ')||','||
       RPAD('DEFAULT TABLESPACE',20,' ')||','||
           RPAD('PROFILE',20,' ')
  FROM DUAL;

SELECT ' ' FROM DUAL;

select du.username ||','|| du.account_status ||','|| du.created ||','|| du.lock_date ||','|| du.expiry_date ||','||
 u.ptime ||','|| v.last_login||','|| du.default_tablespace ||','|| du.profile
from dba_users du, sys.user$ u ,
 (select user_name, max(event_date) last_login
from sys.users_last_logon
group by user_name) v
where du.username = u.name
 and u.name= v.USER_NAME(+)
order by du.profile;

EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv |wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi

wpl2mltidbs01.tsysacquiring.org:/home/oracle> cat /home/oracle/scripts/audit_reports/DBA_Role.sh
#!/bin/bash

export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=oemrep
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH

export FHOST=${HOST}
export FNAME=${FHOST%%.*}_DBA_Role_${SDATE}
export SUBJ=${FNAME}

# export FNAME=${HOST}_DBA_Role_${SDATE}

cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv


sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1
SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'Please approve  - Active DBA  Users Listing Report' from DUAL;
SELECT 'This is the audit requirement on monthly basis.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT ' ' from dual;

SELECT ' ' FROM DUAL;

SELECT RPAD('USER NAME',30,' ')||','||
       RPAD('CREATION DATE',13,' ')||','||
       RPAD('PWD CHG DATE',13,' ')||','||
       RPAD('PROFILE',25,' ')||','||
       RPAD('ACCOUNT STATUS',15,' ')||','||
       RPAD('PRIVS TYPE',10,' ')||','||
       RPAD('PRIVILEGES',25,' ')||','||
         RPAD('APPROVED Y or N',20,' ')||','||
       RPAD('APPROVED BY',20,' ')
  FROM DUAL;
-- union
SELECT ' ' FROM DUAL;
-- union
SELECT RPAD(y.username,30,' ')||','||
      RPAD(TO_CHAR(TRUNC(z.ctime),'DD-MON-YYYY'), 13, ' ')||','||
      NVL(RPAD(TO_CHAR(TRUNC(z.ptime),'DD-MON-YYYY'), 13, ' '), '             ')||','||
      RPAD(y.profile, 25,' ')||','||
      RPAD(y.account_status,15,' ')||','||
      RPAD('ROLE',10,' ')||','||
      RPAD(x.granted_role, 25,' ')
 FROM dba_role_privs x
    , dba_users y
    , sys.user$ z
WHERE z.name = y.username
  AND (x.GRANTED_ROLE = 'DBA' OR y.username IN ('TRIPWIRE', 'DB_ENVISION','UCMDB', 'ACN_ORA_MONITOR', 'PERFSTAT'))
  AND x.GRANTEE=y.username
ORDER BY y.profile,y.username;


EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv|wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi
wpl2mltidbs01.tsysacquiring.org:/home/oracle> cat /home/oracle/scripts/audit_reports/User_Grants.sh
#!/bin/bash



export SDATE=`date +%Y%m%d`
export HOST=`uname -a | awk '{print $2}'`
ORACLE_SID=oemrep
export ORACLE_SID
ORACLE_HOME=`cat /etc/oratab|grep ^$ORACLE_SID:|cut -f2 -d':'`
export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$PATH
export PATH



export FHOST=${HOST}
export FNAME=${FHOST%%.*}_User_Grants_${SDATE}
export SUBJ=${FNAME}

# export FNAME=${HOST}_Users_Grants_${SDATE}

cat /dev/null > /home/oracle/scripts/audit_reports/log/${FNAME}.csv


sqlplus -s "/ as sysdba" << EOF >> /home/oracle/scripts/audit_reports/log/${FNAME}.csv 2>&1

SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250

SET FEEDBACK OFF
SET HEADING ON
SET ECHO OFF
SET PAGESIZE 0
SET LINESIZE 250


SELECT 'Please approve  - Active App Team DB Users Listing with Assigned Users and Privileges' from DUAL;
SELECT 'This is the audit requirement on monthly basis.' FROM DUAL;
SELECT '        ' FROM DUAL;

SELECT 'Execution Date : '|| TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') FROM DUAL;
SELECT '======================================' from dual;

SELECT ' ' FROM DUAL;

SELECT RPAD('USER NAME',20,' ')||','||
       RPAD('CREATION DATE',13,' ')||','||
       RPAD('PWD CHG DATE',13,' ')||','||
       RPAD('PROFILE',25,' ')||','||
       RPAD('ACCOUNT STATUS',15,' ')||','||
       RPAD('PRIVS TYPE',10,' ')||','||
       RPAD('PRIVILEGES',25,' ')||','||
          RPAD('APPROVED Y or N',20,' ')||','||
       RPAD('APPROVED BY',20,' ')
  FROM DUAL;

SELECT RPAD('=',20,'=')||','||
       RPAD('=',13,'=')||','||
       RPAD('=',13,'=')||','||
       RPAD('=',25,'=')||','||
       RPAD('=',15,'=')||','||
       RPAD('=',10,'=')||','||
       RPAD('=',25, '=') ||','||
           RPAD('=',20, '=')||','||
         RPAD('=',20, '=')
  FROM DUAL;

SELECT RPAD(a.name,20,' ') ||','||
       RPAD(TO_CHAR(TRUNC(a.ctime),'DD-MON-YYYY'), 13, ' ') ||','||
       NVL(RPAD(TO_CHAR(TRUNC(a.ptime),'DD-MON-YYYY'), 13, ' '), '             ') ||','||
       RPAD(c.profile, 25,' ')  ||','||
       RPAD(c.account_status,15,' ') ||','||
       RPAD('ROLE',10,' ')  ||','||
       RPAD(b.granted_role,25, ' ')
  FROM sys.user$ a,
       DBA_ROLE_PRIVS b,
       DBA_USERS c
 WHERE a.name = B.GRANTEE
   AND a.name = c.Username
   AND (c.account_status NOT LIKE 'LOCKED' AND c.account_status NOT LIKE ('EXPIRED '||'&'||' LOCKED') AND c.account_status NOT LIKE ('EXPIRED(GRACE) '||'&'||' LOCKED'))
   AND (B.granted_role NOT LIKE 'DBA')
   AND a.name NOT IN ('TRIPWIRE', 'DB_ENVISION','UCMDB', 'ACN_ORA_MONITOR','PERFSTAT','XDO', 'SQLTXPLAIN' , 'SYS', 'SYSTEM', 'SYSMAN', 'DBSNMP','STRMADMIN','OPS$ORACLE')
   AND C.PROFILE NOT LIKE '%DBA%'
UNION
SELECT RPAD(a.name,20,' ') ||','||
       RPAD(TO_CHAR(TRUNC(a.ctime),'DD-MON-YYYY'), 13, ' ') ||','||
       NVL(RPAD(TO_CHAR(TRUNC(a.ptime),'DD-MON-YYYY'), 13, ' '), '             ')||','||
       RPAD(c.profile, 25,' ')  ||','||
       RPAD(c.account_status,15,' ') ||','||
       RPAD('SYSTEM',10,' ') ||','||
       RPAD(b.privilege,30, ' ')
  FROM sys.user$ a,
       DBA_SYS_PRIVS b,
       DBA_USERS c
 WHERE a.name = B.GRANTEE
   AND a.name = c.username
   AND (c.account_status NOT LIKE 'LOCKED' AND c.account_status NOT LIKE ('EXPIRED '||'&'||' LOCKED') AND c.account_status NOT LIKE ('EXPIRED(GRACE) '||'&'||' LOCKED'))
   AND a.name NOT IN ('TRIPWIRE', 'DB_ENVISION', 'UCMDB', 'ACN_ORA_MONITOR', 'PERFSTAT','XDO', 'SQLTXPLAIN', 'SYS', 'SYSTEM', 'SYSMAN', 'DBSNMP','STRMADMIN','OPS$ORACLE')
   AND C.PROFILE NOT LIKE '%DBA%'
ORDER BY 1;


EOF

RESULT=`cat /home/oracle/scripts/audit_reports/log/${FNAME}.csv|wc -l`
if [ ${RESULT} -gt 0 ]
then
        perl /home/oracle/scripts/audit_reports/perlmail.pl ${FNAME}.csv /home/oracle/scripts/audit_reports/log/${FNAME}.csv ${SUBJ}
fi

wpl2mltidbs01.tsysacquiring.org:/home/oracle>
