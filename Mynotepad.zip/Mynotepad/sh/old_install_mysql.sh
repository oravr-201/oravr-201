#!/bin/sh
# ************************************************************************
# ************************************************************************
# ** SCRIPT   : install_mysql
# **            UNIX-Shellscript zur Installation einer MySQL-Datenbank
# ** Version  : 1.6
# **======================================================================
# ** AUTOR             : SIS GO AO G DB th
# ** ERSTELLT AM       : 22.08.2006 th
# ** MACHT             : .profile erstellen
# **                   : Verzeichnisstruktur anlegen
# **                   : Software installieren
# **                   : my.cnf anlegen
# **                   : Datenbank (mit/ohne INNODB-Engine) anlegen
# **                   : Datenbank-User mysql und backup anlegen
# **                   : mysql.server anpassen
# **                   : mysqlctl erstellen
# **======================================================================
# ** MACHT NICHT       : logfile-maintenaince script
# **                   : backup script erstellen
# **                   : cronjobs erstellen
# **======================================================================
# ** AENDERUNGEN
# ** 14.08.2007 th     : Variable EDITOR in .profile exportiert
# ** 27.09.2007 th     : Rechte in mysql/bin korrigiert
# ** 22.03.2008 th     : Default Port 6200
# ** 25.03.2008 th     : skip_bdb ab V. 5.1.x auskommentiert, da obsolete
# ** 12.08.2008 th     : error-log und slow-log auch nach $HOME/mysqllog
# ** 19.11.2008 th     : innodb_log_arch_dir (depreciated) entfernt
# ** 22.12.2008 th     : bin-logs nach $HOME/mysqlbinlog
# **                   : log-slow-queries (depreciated ab 5.1)-> slow_query_log
# **                   : 5.1: start event scheduler y/n
# ** 23.12.2010 th     : $PATH v. System ans Ende (wg. ev. mysql-rpms)
# **                   : 5.5. aufgenommen
# ** 12.07.2011 th     : bugfixes (Versionsweiche, MANPATH, rm unneeded, socket)
# **                   : jetzt auch f. Shared DB-Server
# ** 07.11.2011 th     : rcscript mit "touch /var/lock/subsys/mysqlctl"
# ************************************************************************
# ************************************************************************

AUTHOR="AIS MS ICS G EBDB3 th"

### setting/checking prerequisites #######################################

stty erase '^h' intr '^c' kill '^u' susp '^z'
export EDITOR=vi

export FAT=`tput smso`
export NORM=`tput rmso`

if [ `echo $SHELL |grep bash` ]; then ECHO="echo -e"
else ECHO="echo"
fi

if [ $# -eq 0 ]
then $ECHO "\n Insufficient arguments(0) - Usage: $0 [i|install|r|remove] \n"
exit
fi

if ([ $1 = install ] || [ $1 = i ])
then
	MYSQL_ARCHIVE=`ls -1 *.tar.gz| tail -1`
	# MYSQL_HOME=`echo $MYSQL_ARCHIVE | sed 's/.tar.gz$//'`
	MYSQL_HOME=${MYSQL_ARCHIVE:0:${#MYSQL_ARCHIVE}-7}
	MYSQL_VERSION=`echo $MYSQL_ARCHIVE |cut -f2 -d'-'`
fi

OS=`uname -s`
case $OS in
        Linux) TAR="tar xvfz $MYSQL_ARCHIVE"
        ;;
        SunOS) if [ -f /usr/sfw/bin/gtar ]
                 then TAR="/usr/sfw/bin/gtar xvfz $MYSQL_ARCHIVE"
                 else $ECHO "\n GNU-Tar not found - exiting..."
                      exit
               fi
        ;;
        HP-UX) TAR="gzip -dc $MYSQL_ARCHIVE | tar xf -"
        ;;
        *) echo "Unknown Operating System"
        ;;
esac

### begin functions ######################################################

function_create_profile(){
OUT=".profile"
echo "# *****************************************************************************" > $OUT
echo "# *****************************************************************************" >> $OUT
echo "# ** SCRIPT            : .profile" >> $OUT
echo "# **                   : UNIX-Loginscript fuer den MySQL-DBA-Account \"mysql\"" >> $OUT
echo "# ** ==========================================================================" >> $OUT
echo "# ** HOST              : `hostname`" >> $OUT
echo "# ** OS                : `uname -s`  " >> $OUT
echo "# ** MySQL-VERSION     : `echo $MYSQL_VERSION | cut -f1,2 -d'.'`" >> $OUT
echo "# ** AUTOR             : $AUTHOR" >> $OUT
echo "# ** ERSTELLT AM       : `date`" >> $OUT
echo "# ** LETZTE AENDERUNG  :" >> $OUT
echo "# ** SONSTIGES         :" >> $OUT
echo "# *****************************************************************************" >> $OUT
echo "# *****************************************************************************" >> $OUT
echo "" >> $OUT
echo "# ----- Search Path -----------------------------------------------------------" >> $OUT
echo "" >> $OUT
echo "PATH=\$PATH:.:/usr/local/bin:/usr/sbin:/sbin;   export PATH" >> $OUT
echo "" >> $OUT
echo "# ----- Terminal Setup --------------------------------------------------------" >> $OUT
echo "" >> $OUT
echo "TERM=\"vt100\"; export TERM" >> $OUT
echo "stty erase \"^H\" kill \"^U\" intr \"^C\" eof \"^D\"" >> $OUT
echo "stty hupcl ixon ixoff" >> $OUT
echo "" >> $OUT
echo "" >> $OUT
echo "# ----- Shell Environment -----------------------------------------------------" >> $OUT
echo "" >> $OUT
echo "umask 007" >> $OUT
echo "ulimit -c 0" >> $OUT
echo "trap \"echo 'logout'\" 0" >> $OUT
echo "alias l='ls -alh'" >> $OUT
echo "alias ll='ls -alh | more'" >> $OUT
echo "alias c='clear'" >> $OUT
echo "alias md='mkdir -p'" >> $OUT
echo "alias p='ps -efa | more'" >> $OUT
echo "alias d='df -h'" >> $OUT
echo "alias rcmysql='$HOME/scripts/mysql.server'" >> $OUT
echo "" >> $OUT
echo "# ----- Environment Variables -------------------------------------------------" >> $OUT
echo "" >> $OUT
echo "EDITOR=vi                                      ; export EDITOR" >> $OUT
echo "PS1=\"\`uname -n\` [\$LOGNAME] \$ \"           ; export PS1" >> $OUT
echo "" >> $OUT
echo "# ----- MySQL specific -------------------------------------------------------" >> $OUT
echo "PORT=\`grep \"^port\" \$HOME/config/my.cnf |uniq| awk '{if (\$2==\"=\") print \$3;}'\`" >> $OUT
echo "SOCKET=\`grep \"^socket\" \$HOME/config/my.cnf |uniq| awk '{if (\$2==\"=\") print \$3;}'\`" >> $OUT
echo "MYSQL_HOME=`pwd`                         ;export MYSQL_HOME" >> $OUT
echo "PATH=\$MYSQL_HOME/mysql/bin:\$HOME/scripts:\$PATH     ; export PATH" >> $OUT
echo "MANPATH=\$MANPATH:\$MYSQL_HOME/mysql/man" >> $OUT
echo "" >> $OUT
echo "clear" >> $OUT
echo "uname -a" >> $OUT
echo "echo \"--------------------------------------------------------------------------\"" >> $OUT
echo "echo \"\"" >> $OUT
echo "echo \"MySQL (Software) HOME:  \" \$MYSQL_HOME" >> $OUT
echo "echo \"MySQL Datafiles      :  \" \$HOME/mysqldata" >> $OUT
echo "echo \"MySQL Port           :  \" \$PORT" >> $OUT
echo "echo \"MySQL socket         :  \" \$SOCKET" >> $OUT
echo "echo" >> $OUT
chmod 660 $OUT
echo " .profile created."
}

###############################################################################


function_remove(){
        $ECHO "\nREMOVING complete MySQL-Installation incl. mysqldata and mysqlbackup - not stage!  Are You Sure? (y/n) \c"
	read des1
	case $des1 in
		y|Y) $ECHO "Stopping Database ...\n"
		     $HOME/scripts/mysql.server stop
		     $ECHO "Performing: rm -rf config/ cron/ mysql* scripts/ temp/ ..."
		     chmod -R 777 mysql-*
		     rm -rf .my.cnf config/ cron/ mysql* scripts/ temp/
        	     $ECHO "done. \n"
		     exit
		;;
		n|N) $ECHO "\n OK - doing nothing and exiting\n"
		     exit
		;;
		*) $ECHO "\n Answer not recognized - exiting\n"
		   exit
		;;
	esac
}

###############################################################################

function_configure_db(){
	$ECHO "\n Choose configuration type: [s|small||m|medium||l|large||h|huge]  \c"
	read des3
	case $des3 in
		s|small) MY_CNF=my-small.cnf
		;;
		m|medium) MY_CNF=my-medium.cnf
		;;
		l|large) MY_CNF=my-large.cnf
		;;
		h|huge) MY_CNF=my-huge.cnf
		;;
		*) $ECHO "\n Answer not recognized - try again or abort with Strg C\n"
		   function_configure_db
		;;
	esac
	cd $HOME
	$ECHO "\n OK - using config-type $des3\n"
	cp config/$MY_CNF config/my.cnf
	ln -s config/my.cnf $HOME/.my.cnf
	$ECHO "\n mc.cnf copied.\n"
}

###############################################################################

function_create_mysqlctl(){
OUT=$HOME/scripts/mysqlctl
echo "#!/bin/sh" > $OUT
echo "# ************************************************************************" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "# ** SCRIPT   : mysqlctl" >> $OUT
echo "# **            UNIX-Shellscript f. Start/Stop d. MySQL-Instanz" >> $OUT
echo "# ** Version  : 2.2" >> $OUT
echo "# **======================================================================" >> $OUT
echo "# ** HOST              : `hostname`" >> $OUT
echo "# ** AUTOR             : $AUTHOR" >> $OUT
echo "# ** ERSTELLT AM       : `date`" >> $OUT
echo "# **" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "" >> $OUT
echo "## 4 RedHat" >> $OUT
echo "# chkconfig: 3 97 03" >> $OUT
echo "# description: Start and Stop MySQL-Database" >> $OUT
echo "## end 4 RedHat" >> $OUT
echo "" >> $OUT
echo "## 4 SuSE" >> $OUT
echo "### BEGIN INIT INFO" >> $OUT
echo "# Provides: mysql" >> $OUT
echo "# Required-Start: \$local_fs \$network sshd" >> $OUT
echo "# Required-Stop: \$local_fs \$network" >> $OUT
echo "# Default-Start:  3 5" >> $OUT
echo "# Default-Stop :  0 1 6" >> $OUT
echo "# Description:  Start and Stop MySQL-Database" >> $OUT
echo "### END INIT INFO" >> $OUT
echo "" >> $OUT
echo "" >> $OUT
echo "VERSION=\"MySQL start/stop-script 2.2\"" >> $OUT
echo "PATH=\$PATH:/usr/sbin:/usr/bin:/sbin:/bin" >> $OUT
echo "export PATH" >> $OUT
echo "MYSQL_HOME=$HOME" >> $OUT
echo "export MYSQL_HOME" >> $OUT
echo "" >> $OUT
echo "start_modul() {" >> $OUT
echo "  su - mysql -c \"\$MYSQL_HOME/scripts/mysql.server start\"" >> $OUT
echo "  touch /var/lock/subsys/mysqlctl" >> $OUT
echo "}" >> $OUT
echo "" >> $OUT
echo "stop_modul() {" >> $OUT
echo "  su - mysql -c \"\$MYSQL_HOME/scripts/mysql.server stop\"" >> $OUT
echo "}" >> $OUT
echo "" >> $OUT
echo "case \$1 in" >> $OUT
echo "  'start_msg')" >> $OUT
echo "               echo \"Starting MySQL-Database\"" >> $OUT
echo "               ;;" >> $OUT
echo "   'stop_msg')" >> $OUT
echo "               echo \"Stopping MySQL-Database\"" >> $OUT
echo "               ;;" >> $OUT
echo "      'start')" >> $OUT
echo "               start_modul \"Starting\"" >> $OUT
echo "               exit 0" >> $OUT
echo "               ;;" >> $OUT
echo "       'stop')" >> $OUT
echo "               stop_modul \"Stopping\"" >> $OUT
echo "               exit 0" >> $OUT
echo "               ;;" >> $OUT
echo "    'restart')" >> $OUT
echo "               stop_modul \"Stopping\"" >> $OUT
echo "               sleep 3" >> $OUT
echo "               start_modul \"Restarting\"" >> $OUT
echo "               ;;" >> $OUT
echo "" >> $OUT
echo "      'check')" >> $OUT
echo "         \$MYSQL_HOME/mysql/bin/mysql -u dummy -p\"<dummy_pwd>\" -e \"status;\"" >> $OUT
echo "         exit" >> $OUT
echo "         ;;" >> $OUT
echo "" >> $OUT
echo "" >> $OUT
echo "         '-v')" >> $OUT
echo "               echo \$VERSION" >> $OUT
echo "               exit 0" >> $OUT
echo "               ;;" >> $OUT
echo "            *)" >> $OUT
echo "               echo \"usage: \$0 [start|stop|restart]\"" >> $OUT
echo "               exit 1" >> $OUT
echo "               ;;" >> $OUT
echo "esac" >> $OUT
echo "exit 0" >> $OUT
chmod 770 $OUT
 }

###############################################################################

function_edit_mysql_server(){
	MS=$HOME/scripts/mysql.server
	MS_ORIG=$HOME/scripts/mysql.server.orig
	DIR=`echo $HOME | sed  's/\//\\\\\//g'`
	sed -e "s/^basedir=/basedir=$DIR\/mysql/" \
	    -e "s/^datadir=/datadir=$DIR\/mysqldata/" \
    	    -e "s/^pid_file=/pid_file=$DIR\/mysqldata\/mysql.pid/" \
	    -e "s/^server_pid_file=/server_pid_file=$DIR\/mysqldata\/mysqlserver.pid/" $MS_ORIG > $MS

	chmod 770 $MS
	$ECHO "\n mysql.server configured \n"
}

###############################################################################


function_edit_my_cnf(){
	MY_CNF=$HOME/config/my.cnf
	DIR=`echo $HOME | sed  's/\//\\\\\//g'`

	$ECHO "\n Create database with innodb-Engine? (y/n) ?  \c"
	read des4

	$ECHO "\n What TCP-Port the database should listen? [RETURN = 6200] \c"
	read des5
	if [ $des5 ]
 	 then PORT=$des5
 	else PORT=6200
	fi

	$ECHO "\n What socket the database should listen? [RETURN = mysql.sock] \c"
	read des_sock
	if [ $des_sock ]
 	 then SOCK=$des_sock
 	else SOCK="mysql.sock"
	echo $SOCK
	fi



######### 5.5
	if [ `echo $MYSQL_VERSION | cut -c -3` = "5.5" ]
	 then
	  $ECHO "\n entering 5.5 mode";
	  $ECHO "\n Should the event scheduler be started (y/n) ? \c"
	    read des6
	    case $des6 in
		n|N) ES="event_scheduler = OFF"	;;
		y|Y) ES="event_scheduler = ON"	;;
		*) ES="event_scheduler = OFF"	;;
	    esac

	  case $des4 in
        	n|N) sed -e "s/^#password.*$/password/" \
		         -e "s/^port.*$/port            = $PORT/" \
		         -e "s/^socket.*$/socket          = \/tmp\/$SOCK/" \
                         -e "s/^log-bin.*$/log-bin=$DIR\/mysqlbinlog\/mysql-bin�log-warning�log-error=$DIR\/mysqllog\/mysql.err�slow_query_log=$DIR\/mysqllog\/mysql-slow.log/" \
                         -e "s/^#skip-networking/#skip-networking�skip-innodb�default-storage-engine = myisam��$ES��/" $MY_CNF > config/my.cnf.temp
        	;;
        	y|Y) sed -e "s/^#password.*$/password/" \
			 -e "s/^port.*$/port            = $PORT/" \
		         -e "s/^socket.*$/socket          = \/tmp\/$SOCK/" \
			 -e "s/^log-bin.*$/log-bin=$DIR\/mysqlbinlog\/mysql-bin�log-warning�log-error=$DIR\/mysqllog\/mysql.err�slow_query_log=$DIR\/mysqllog\/mysql-slow.log/" \
			 -e "s/^#skip-networking/#skip-networking��$ES��/" \
               		 -e "s/^#innodb/innodb/" \
			 -e "/^innodb_log_group_/c\innodb_log_group_home_dir = $DIR\/mysqlbinlog/" \
			 -e "/^innodb_data_home_/c\innodb_data_home_dir = $DIR\/mysqldata/" \
			 $MY_CNF > config/my.cnf.temp
        	;;
                *) $ECHO "\n Unknown answer, try again or abort with Strg C\n"
		    function_edit_my_cnf
        	;;
	  esac
	fi

######### 5.1
	if [ `echo $MYSQL_VERSION | cut -c -3` = "5.1" ]
	 then
	  $ECHO "\n entering 5.1 mode";
	  $ECHO "\n Should the event scheduler be started (y/n) ? \c"
	    read des6
	    case $des6 in
		n|N) ES="event_scheduler = OFF"	;;
		y|Y) ES="event_scheduler = ON"	;;
		*) ES="event_scheduler = OFF"	;;
	    esac

	  case $des4 in
        	n|N) sed -e "s/^#password.*$/password/" \
		         -e "s/^port.*$/port            = $PORT/" \
		         -e "s/^socket.*$/socket          = \/tmp\/$SOCK/" \
                         -e "s/^log-bin.*$/log-bin=$DIR\/mysqlbinlog\/mysql-bin�log-warning�log-error=$DIR\/mysqllog\/mysql.err�slow_query_log=$DIR\/mysqllog\/mysql-slow.log/" \
                         -e "s/^#skip-networking/#skip-networking�skip-innodb��$ES��/" $MY_CNF > config/my.cnf.temp
        	;;
        	y|Y) sed -e "s/^#password.*$/password/" \
			 -e "s/^port.*$/port            = $PORT/" \
		         -e "s/^socket.*$/socket          = \/tmp\/$SOCK/" \
			 -e "s/^log-bin.*$/log-bin=$DIR\/mysqlbinlog\/mysql-bin�log-warning�log-error=$DIR\/mysqllog\/mysql.err�slow_query_log=$DIR\/mysqllog\/mysql-slow.log/" \
			 -e "s/^#skip-networking/#skip-networking��$ES��/" \
               		 -e "s/^#innodb/innodb/" \
			 -e "/^innodb_log_arch_dir/c\##innodb_log_arch_dir (depreciated)" \
			 -e "/^innodb_log_group_/c\innodb_log_group_home_dir = $DIR\/mysqlbinlog/" \
			 -e "/^innodb_data_home_/c\innodb_data_home_dir = $DIR\/mysqldata/" \
			 $MY_CNF > config/my.cnf.temp
        	;;
                *) $ECHO "\n Unknown answer, try again or abort with Strg C\n"
		    function_edit_my_cnf
        	;;
	  esac
	fi

######### 5.0
	if [ `echo $MYSQL_VERSION | cut -c -3` = "5.0" ]
	 then
	  $ECHO "\n entering 5.0 mode";
	  case $des4 in
        	n|N) sed -e "s/^#password.*$/password/" \
		         -e "s/^port.*$/port            = $PORT/" \
		         -e "s/^socket.*$/socket          = \/tmp\/$SOCK/" \
                         -e "s/^log-bin.*$/log-bin=$DIR\/mysqlbinlog\/mysql-bin�log-warning�log-error=$DIR\/mysqllog\/mysql.err�log-slow-queries=$DIR\/mysqllog\/mysql-slow.log/" \
                         -e "s/^#skip-networking/#skip-networking�skip-bdb�skip-innodb/" $MY_CNF > config/my.cnf.temp
        	;;
        	y|Y) sed -e "s/^#password.*$/password/" \
			 -e "s/^port.*$/port            = $PORT/" \
		         -e "s/^socket.*$/socket          = \/tmp\/$SOCK/" \
			 -e "s/^log-bin.*$/log-bin=$DIR\/mysqlbinlog\/mysql-bin�log-warning�log-error=$DIR\/mysqllog\/mysql.err�log-slow-queries=$DIR\/mysqllog\/mysql-slow.log/" \
			 -e "s/^#skip-networking/#skip-networking�skip-bdb/" \
               		 -e "s/^#innodb/innodb/" \
			 -e "/^innodb_log_arch_dir/c\##innodb_log_arch_dir/" \
			 -e "/^innodb_log_group_/c\innodb_log_group_home_dir = $DIR\/mysqlbinlog/" \
			 -e "/^innodb_data_home_/c\innodb_data_home_dir = $DIR\/mysqldata/" \
			 $MY_CNF > config/my.cnf.temp
        	;;
                *) $ECHO "\n Unknown answer, try again or abort with Strg C\n"
		    function_edit_my_cnf
        	;;
	  esac
	fi

##########
	tr '�' '\n' < config/my.cnf.temp > config/my.cnf
	rm config/my.cnf.temp
	$ECHO "\n my.cnf adjusted. If you need non-standard values, please edit my.cnf manually\n"
}

###############################################################################

function_cr_dbuser(){
	$ECHO "\n Now starting db and creating users ...\n"

	$HOME/scripts/mysql.server start
	$ECHO "\n please give mysql (DB-user) password: \c"
	read mysql_passwd
	$ECHO "\n please give backup (DB-user for backup) password: \c"
	read backup_passwd

mysql/bin/mysql -u root --password= << EOF
use mysql;
delete from user;
grant all privileges on *.* to mysql@"%" identified by '$mysql_passwd' with grant option;
grant select, reload, file, lock tables,show databases on *.* to 'backup'@'localhost' identified by '$backup_passwd';
flush privileges;
delete from db;
drop database test;
EOF
	$ECHO "\nDatabase is now up and ready to use\n"
}

###############################################################################

function_install(){
	$ECHO "\n Install $FAT$MYSQL_ARCHIVE$NORM in $FAT$MYSQL_HOME$NORM ? (y/n) \c"
	read des2
	case $des2 in
		y|Y) $ECHO "\n OK - starting installation ...\n"
			function_create_profile
			$ECHO "\n creating directories ... \n"
			mkdir stage config scripts temp cron mysqlbackup mysqllog mysqlbinlog

			$ECHO "\n unpacking archive ... \n"
			$TAR
			mv $MYSQL_ARCHIVE stage
			ln -s $MYSQL_HOME ./mysql

			$ECHO "\n setting permissions, removing unneeded files ... \n"
			chmod 755 $MYSQL_HOME
			cd $MYSQL_HOME
			rm -rf COPYING INSTALL-BINARY README mysql-test sql-bench
			chmod 770 bin/*
			chmod 775 bin bin/mysql bin/mysqldump include/ lib/ man/ man/man1/
			chmod 644 include/* lib/* man/man1/*

			$ECHO "\n setting up database ... \n"
			./scripts/mysql_install_db
			cp -r data ../mysqldata
			cd
			cp mysql/support-files/*.cnf ./config
			cp mysql/support-files/mysql.server ./scripts/mysql.server.orig
			$ECHO "\n Database is created.\n"
		;;
		n|N) $ECHO "\n Cannot continue via script - please install manually\n"
		     $ECHO "$FAT Please abort with Strg C $NORM\n"
			# todo: automatisch parent beenden
		     return 2
		;;
		*) $ECHO "\n Answer not recognized - try again or abort with Strg C\n"
		   function_install
                ;;
	esac
  }

### end functions ########################################################

case $1 in
	r|remove) function_remove
	;;
	i|install)
		function_install | tee -a install.log
		function_configure_db | tee -a install.log
		function_create_mysqlctl | tee -a install.log
		function_edit_mysql_server | tee -a install.log
		function_edit_my_cnf | tee -a install.log
		function_cr_dbuser | tee -a install.log
		. ./.profile
		 $ECHO "\n $FAT Installation completed $NORM \n"
		 $ECHO "Logfile of installation is $HOME/install.log\n"
		 $ECHO "Please check the my.cnf and perform additional customizing\n"
		 $ECHO "Set up backup and log-maintenaince manually\n"
	;;
	debug)
		export MYSQL_VERSION=`ls -1 | grep "mysql-5" | cut -f2 -d'-'`
		$ECHO "\n$FAT DEBUG enabled $NORM\n"
	 	$ECHO "function_install $FAT 1 $NORM"
		$ECHO "function_configure_db $FAT 2 $NORM"
		$ECHO "function_edit_mysql_server $FAT 3 $NORM"
		$ECHO "function_edit_my_cnf $FAT 4 $NORM"
		$ECHO "function_cr_db_user $FAT 5 $NORM"
		$ECHO "Choose function number:  \c"
		read step
		case $step in
			1) function_install ;;
			2) function_configure_db ;;
			3) function_edit_mysql_server ;;
			4) function_edit_my_cnf	;;
			5) function_cr_db_user	;;
			*) $ECHO "$step is No valid function\n"
			   exit
			   ;;
		esac
	;;
	*) $ECHO "\n Unknown argument - Usage: $0 [i|install|r|remove] \n"
	   exit
	;;
esac

# todo: backup-script generieren

