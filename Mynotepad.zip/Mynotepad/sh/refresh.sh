SAGE="USAGE: REFRESH_FOCUSPRF.sh [ORACLE_SID]"
if [ $# -ne 1 ]
then
 echo $USAGE
 exit
else
ORACLE_SID=$1; export ORACLE_SID
fi

###########################################
# Set environment variables
##########################################

. /appl/oracle/dba/bin/setoraenv $ORACLE_SID
STAMP=`date '+%m%d%y_%H%M%S'`
#NOTIFY=VIJAYAKRISHNA.BOLISETTY@ATOS.NET
NOTIFY=DLINO-NAIMO-ORACLE-SUPPORT.it-solutions@atos.net
NLS_DATE_FORMAT='Mon DD YYYY HH24:MI:SS';export NLS_DATE_FORMAT
NLS_LANG=american;export NLS_LANG
STAMP=`date '+%m%d%y_%H%M%S'`

#############################################
# Actual rman refresh script
#############################################

rman target sys/At0$F1rstD3a@FOCUSPRD   auxiliary / << EOF > /appl/oracle/FOCUSPRF/exp1/hot/REFRESH_FOCUSPRF.$STAMP.log
connect catalog rman_fga/rman_FGA@aorman11;
run{
set until time "to_date('02-09-2016 06:01:16','DD-MM-YYYY HH24:MI:SS')";
allocate auxiliary channel ch1 type disk;
allocate auxiliary channel ch2 type disk;
allocate auxiliary channel ch3 type disk;
allocate auxiliary channel ch4 type disk;
set newname for datafile '/appl/oracle/FOCUSPRD/system1/ora_FOCUSPRD_system01.dbf' to '/appl/oracle/FOCUSPRF/system1/ora_FOCUSPRF_system01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_01.dbf' to '/appl/oracle/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/system1/ora_FOCUSPRD_sysaux01.dbf' to '/appl/oracle/FOCUSPRF/system1/ora_FOCUSPRF_sysaux01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_users01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_users01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_AQ_01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_AQ_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_09.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_10.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_11.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_11.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_08.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_09.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LOB_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LOB_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_12.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_12.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_10.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_11.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_11.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_12.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_12.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_21.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_21.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_SML_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_SML_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_22.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_22.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_26.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_26.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_23.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_23.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_24.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_24.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_25.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_25.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_16.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_16.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_17.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_17.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_18.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_18.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_27.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_27.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_28.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_28.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_29.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_29.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_30.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_30.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_02.dbf' to '/appl/oracle/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_31.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_31.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_32.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_32.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_19.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_19.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_03.dbf' to '/appl/oracle/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_04.dbf' to '/appl/oracle/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_20.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_20.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/undo/undo1/ora_FOCUSPRD_undotbs1_05.dbf' to '/appl/oracle/FOCUSPRF/undo/undo1/ora_FOCUSPRF_undotbs1_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_05.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_06.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_07.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_08.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_01.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_02.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_03.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_04.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_05.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_06.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_07.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_05.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_06.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_07.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_08.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_09.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_10.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_01.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_02.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_03.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_04.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_05.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_06.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_07.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_08.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_09.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_10.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_11.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_11.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_12.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_12.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_13.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_13.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_14.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_14.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_15.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_15.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_05.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_06.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_MED_DATA_07.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_MED_DATA_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_MED_DATA_08.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_MED_DATA_08.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_MED_IDX_01.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_MED_IDX_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_MED_IDX_02.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_MED_IDX_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_03.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_04.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_05.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_06.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_06.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_07.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_07.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_21.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_21.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_11.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_11.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_12.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_12.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_13.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_13.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_14.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_14.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_15.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_15.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_16.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_16.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_17.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_17.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_SML_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_SML_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_SML_IDX_01.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_SML_IDX_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LOB_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LOB_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_18.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_18.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_DBADMIN_DATA_01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_DBADMIN_DATA_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_19.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_19.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_LRG_DATA_20.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_LRG_DATA_20.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_22.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_22.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_33.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_33.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_34.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_34.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_23.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_23.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_24.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_24.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_35.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_35.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_25.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_25.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_26.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_26.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index2/ora_FOCUSPRD_FOCUS_LRG_IDX_27.dbf' to '/appl/oracle/FOCUSPRF/index2/ora_FOCUSPRF_FOCUS_LRG_IDX_27.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_36.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_36.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_37.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_37.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_38.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_38.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LRG_DATA_39.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LRG_DATA_39.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_28.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_28.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_40.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_40.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_29.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_29.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_41.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_41.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_42.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_42.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_30.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_30.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_31.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_31.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_32.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_32.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_33.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_33.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_43.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_43.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_44.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_44.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_34.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_34.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_45.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_45.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_35.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_35.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_36.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_36.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_37.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_37.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_46.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_46.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_47.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_47.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_38.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_38.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_48.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_48.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_49.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_49.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_39.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_39.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_40.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_40.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_50.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_50.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_41.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_41.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_51.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_51.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_42.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_42.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_43.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_43.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_44.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_44.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_45.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_45.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_46.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_46.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_52.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_52.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_53.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_53.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_54.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_54.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_LRG_IDX_47.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_LRG_IDX_47.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_JBM_01.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_JBM_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_13.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_13.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_48.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_48.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_13.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_13.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_GPSC_DATA_14.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_GPSC_DATA_14.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index1/ora_FOCUSPRD_FOCUS_GPSC_IDX_14.dbf' to '/appl/oracle/FOCUSPRF/index1/ora_FOCUSPRF_FOCUS_GPSC_IDX_14.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_SML_IDX_02.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_SML_IDX_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_49.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_49.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_50.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_50.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_LRG_IDX_51.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_LRG_IDX_51.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_SML_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_SML_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_tools_01.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_tools_01.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_FOCUS_LOB_DATA_02.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_FOCUS_LOB_DATA_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_55.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_55.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LRG_DATA_56.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LRG_DATA_56.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_AQ_03.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_AQ_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data1/ora_FOCUSPRD_AQ_02.dbf' to '/appl/oracle/FOCUSPRF/data1/ora_FOCUSPRF_AQ_02.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LOB_DATA_03.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LOB_DATA_03.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data4/ora_FOCUSPRD_FOCUS_LOB_DATA_04.dbf' to '/appl/oracle/FOCUSPRF/data4/ora_FOCUSPRF_FOCUS_LOB_DATA_04.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data3/ora_FOCUSPRD_FOCUS_LOB_DATA_05.dbf' to '/appl/oracle/FOCUSPRF/data3/ora_FOCUSPRF_FOCUS_LOB_DATA_05.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_MED_DATA_09.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_MED_DATA_09.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/data2/ora_FOCUSPRD_FOCUS_MED_DATA_10.dbf' to '/appl/oracle/FOCUSPRF/data2/ora_FOCUSPRF_FOCUS_MED_DATA_10.dbf';
set newname for datafile '/appl/oracle/FOCUSPRD/index3/ora_FOCUSPRD_FOCUS_MED_IDX_08.dbf' to '/appl/oracle/FOCUSPRF/index3/ora_FOCUSPRF_FOCUS_MED_IDX_08.dbf';
DUPLICATE TARGET DATABASE TO FOCUSPRF;
release channel ch1;
release channel ch2;
release channel ch3;
release channel ch4;
}

