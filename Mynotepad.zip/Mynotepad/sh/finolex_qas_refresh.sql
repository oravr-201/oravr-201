
run{
allocate channel ch1 type disk;
allocate channel ch2 type disk;
allocate channel ch3 type disk;
allocate channel ch4 type disk;
set newname for datafile '/oracle/PRD/sapdata1/system_1/system.data1' to '/oracle/QAS/sapdata1/system_1/system.data1';        
set newname for datafile '/oracle/PRD/sapdata1/undo_1/undo.data1' to '/oracle/QAS/sapdata1/undo_1/undo.data1';             
set newname for datafile '/oracle/PRD/sapdata1/sysaux_1/sysaux.data1' to '/oracle/QAS/sapdata1/sysaux_1/sysaux.data1';         
set newname for datafile '/oracle/PRD/sapdata1/sr3_1/sr3.data1' to '/oracle/QAS/sapdata1/sr3_1/sr3.data1';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_2/sr3.data2' to '/oracle/QAS/sapdata1/sr3_2/sr3.data2';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_3/sr3.data3' to '/oracle/QAS/sapdata1/sr3_3/sr3.data3';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_4/sr3.data4' to '/oracle/QAS/sapdata1/sr3_4/sr3.data4';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_5/sr3.data5' to '/oracle/QAS/sapdata1/sr3_5/sr3.data5';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_6/sr3.data6' to '/oracle/QAS/sapdata1/sr3_6/sr3.data6';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_7/sr3.data7' to '/oracle/QAS/sapdata1/sr3_7/sr3.data7';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_8/sr3.data8' to '/oracle/QAS/sapdata1/sr3_8/sr3.data8';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_9/sr3.data9' to '/oracle/QAS/sapdata1/sr3_9/sr3.data9';               
set newname for datafile '/oracle/PRD/sapdata1/sr3_10/sr3.data10' to '/oracle/QAS/sapdata1/sr3_10/sr3.data10';            
set newname for datafile '/oracle/PRD/sapdata1/sr3_11/sr3.data11' to '/oracle/QAS/sapdata1/sr3_11/sr3.data11';            
set newname for datafile '/oracle/PRD/sapdata1/sr3_12/sr3.data12' to '/oracle/QAS/sapdata1/sr3_12/sr3.data12';            
set newname for datafile '/oracle/PRD/sapdata1/sr3_13/sr3.data13' to '/oracle/QAS/sapdata1/sr3_13/sr3.data13';            
set newname for datafile '/oracle/PRD/sapdata1/sr3_14/sr3.data14' to '/oracle/QAS/sapdata1/sr3_14/sr3.data14';            
set newname for datafile '/oracle/PRD/sapdata1/sr3_15/sr3.data15' to '/oracle/QAS/sapdata1/sr3_15/sr3.data15';            
set newname for datafile '/oracle/PRD/sapdata1/sr3_16/sr3.data16' to '/oracle/QAS/sapdata1/sr3_16/sr3.data16';            
set newname for datafile '/oracle/PRD/sapdata1/sr3_17/sr3.data17' to '/oracle/QAS/sapdata1/sr3_17/sr3.data17';            
set newname for datafile '/oracle/PRD/sapdata1/sr3_18/sr3.data18' to '/oracle/QAS/sapdata1/sr3_18/sr3.data18';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_19/sr3.data19' to '/oracle/QAS/sapdata2/sr3_19/sr3.data19';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_20/sr3.data20' to '/oracle/QAS/sapdata2/sr3_20/sr3.data20';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_21/sr3.data21' to '/oracle/QAS/sapdata2/sr3_21/sr3.data21';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_22/sr3.data22' to '/oracle/QAS/sapdata2/sr3_22/sr3.data22';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_23/sr3.data23' to '/oracle/QAS/sapdata2/sr3_23/sr3.data23';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_24/sr3.data24' to '/oracle/QAS/sapdata2/sr3_24/sr3.data24';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_25/sr3.data25' to '/oracle/QAS/sapdata2/sr3_25/sr3.data25';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_26/sr3.data26' to '/oracle/QAS/sapdata2/sr3_26/sr3.data26';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_27/sr3.data27' to '/oracle/QAS/sapdata2/sr3_27/sr3.data27';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_28/sr3.data28' to '/oracle/QAS/sapdata2/sr3_28/sr3.data28';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_29/sr3.data29' to '/oracle/QAS/sapdata2/sr3_29/sr3.data29';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_30/sr3.data30' to '/oracle/QAS/sapdata2/sr3_30/sr3.data30';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_31/sr3.data31' to '/oracle/QAS/sapdata2/sr3_31/sr3.data31';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_32/sr3.data32' to '/oracle/QAS/sapdata2/sr3_32/sr3.data32';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_33/sr3.data33' to '/oracle/QAS/sapdata2/sr3_33/sr3.data33';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_34/sr3.data34' to '/oracle/QAS/sapdata2/sr3_34/sr3.data34';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_35/sr3.data35' to '/oracle/QAS/sapdata2/sr3_35/sr3.data35';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_36/sr3.data36' to '/oracle/QAS/sapdata2/sr3_36/sr3.data36';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_37/sr3.data37' to '/oracle/QAS/sapdata2/sr3_37/sr3.data37';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_38/sr3.data38' to '/oracle/QAS/sapdata2/sr3_38/sr3.data38';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_39/sr3.data39' to '/oracle/QAS/sapdata2/sr3_39/sr3.data39';            
set newname for datafile '/oracle/PRD/sapdata2/sr3_40/sr3.data40' to '/oracle/QAS/sapdata2/sr3_40/sr3.data40';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_41/sr3.data41' to '/oracle/QAS/sapdata3/sr3_41/sr3.data41';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_42/sr3.data42' to '/oracle/QAS/sapdata3/sr3_42/sr3.data42';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_43/sr3.data43' to '/oracle/QAS/sapdata3/sr3_43/sr3.data43';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_44/sr3.data44' to '/oracle/QAS/sapdata3/sr3_44/sr3.data44';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_45/sr3.data45' to '/oracle/QAS/sapdata3/sr3_45/sr3.data45';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_46/sr3.data46' to '/oracle/QAS/sapdata3/sr3_46/sr3.data46';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_47/sr3.data47' to '/oracle/QAS/sapdata3/sr3_47/sr3.data47';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_48/sr3.data48' to '/oracle/QAS/sapdata3/sr3_48/sr3.data48';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_49/sr3.data49' to '/oracle/QAS/sapdata3/sr3_49/sr3.data49';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_50/sr3.data50' to '/oracle/QAS/sapdata3/sr3_50/sr3.data50';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_51/sr3.data51' to '/oracle/QAS/sapdata3/sr3_51/sr3.data51';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_52/sr3.data52' to '/oracle/QAS/sapdata3/sr3_52/sr3.data52';            
set newname for datafile '/oracle/PRD/sapdata3/sr3_53/sr3.data53' to '/oracle/QAS/sapdata3/sr3_53/sr3.data53';            
set newname for datafile '/oracle/PRD/sapdata4/sr3700_1/sr3700.data1' to '/oracle/QAS/sapdata4/sr3700_1/sr3700.data1';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_2/sr3700.data2' to '/oracle/QAS/sapdata4/sr3700_2/sr3700.data2';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_3/sr3700.data3' to '/oracle/QAS/sapdata4/sr3700_3/sr3700.data3';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_4/sr3700.data4' to '/oracle/QAS/sapdata4/sr3700_4/sr3700.data4';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_5/sr3700.data5' to '/oracle/QAS/sapdata4/sr3700_5/sr3700.data5';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_6/sr3700.data6' to '/oracle/QAS/sapdata4/sr3700_6/sr3700.data6';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_7/sr3700.data7' to '/oracle/QAS/sapdata4/sr3700_7/sr3700.data7';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_8/sr3700.data8' to '/oracle/QAS/sapdata4/sr3700_8/sr3700.data8';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_9/sr3700.data9' to '/oracle/QAS/sapdata4/sr3700_9/sr3700.data9';         
set newname for datafile '/oracle/PRD/sapdata4/sr3700_10/sr3700.data10' to '/oracle/QAS/sapdata4/sr3700_10/sr3700.data10';       
set newname for datafile '/oracle/PRD/sapdata4/sr3700_11/sr3700.data11' to '/oracle/QAS/sapdata4/sr3700_11/sr3700.data11';       
set newname for datafile '/oracle/PRD/sapdata4/sr3700_12/sr3700.data12' to '/oracle/QAS/sapdata4/sr3700_12/sr3700.data12';       
set newname for datafile '/oracle/PRD/sapdata4/sr3700_13/sr3700.data13' to '/oracle/QAS/sapdata4/sr3700_13/sr3700.data13';       
set newname for datafile '/oracle/PRD/sapdata4/sr3700_14/sr3700.data14' to '/oracle/QAS/sapdata4/sr3700_14/sr3700.data14';       
set newname for datafile '/oracle/PRD/sapdata4/sr3700_15/sr3700.data15' to '/oracle/QAS/sapdata4/sr3700_15/sr3700.data15';       
set newname for datafile '/oracle/PRD/sapdata4/sr3700_16/sr3700.data16' to '/oracle/QAS/sapdata4/sr3700_16/sr3700.data16';       
set newname for datafile '/oracle/PRD/sapdata4/sr3700_17/sr3700.data17' to '/oracle/QAS/sapdata4/sr3700_17/sr3700.data17';       
set newname for datafile '/oracle/PRD/sapdata4/sr3700_18/sr3700.data18' to '/oracle/QAS/sapdata4/sr3700_18/sr3700.data18';       
set newname for datafile '/oracle/PRD/sapdata4/sr3usr_1/sr3usr.data1' to '/oracle/QAS/sapdata4/sr3usr_1/sr3usr.data1';     
set newname for datafile '/oracle/PRD/sapdata3/sr3_54/sr3.data54' to '/oracle/QAS/sapdata3/sr3_54/sr3.data54';             
set newname for datafile '/oracle/PRD/sapdata3/sr3_55/sr3.data55' to '/oracle/QAS/sapdata3/sr3_55/sr3.data55';             
set newname for datafile '/oracle/PRD/sapdata3/sr3_56/sr3.data56' to '/oracle/QAS/sapdata3/sr3_56/sr3.data56';             
set newname for datafile '/oracle/PRD/sapdata3/sr3_57/sr3.data57' to '/oracle/QAS/sapdata3/sr3_57/sr3.data57';             
set newname for datafile '/oracle/PRD/sapdata5/sr3740_1/sr3740.data1' to '/oracle/QAS/sapdata5/sr3740_1/sr3740.data1';         
set newname for datafile '/oracle/PRD/sapdata5/sr3740_2/sr3740.data2' to '/oracle/QAS/sapdata5/sr3740_2/sr3740.data2';         
set newname for datafile '/oracle/PRD/sapdata5/sr3740_3/sr3740.data3' to '/oracle/QAS/sapdata5/sr3740_3/sr3740.data3';         
set newname for datafile '/oracle/PRD/sapdata5/sr3740_4/sr3740.data4' to '/oracle/QAS/sapdata5/sr3740_4/sr3740.data4';         
set newname for datafile '/oracle/PRD/sapdata3/sr3_57/sr3.data58' to '/oracle/QAS/sapdata3/sr3_57/sr3.data58';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_41/sr3.data41' to '/oracle/QAS/sapdata4/sr3_41/sr3.data41';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_42/sr3.data42' to '/oracle/QAS/sapdata4/sr3_42/sr3.data42';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_43/sr3.data43' to '/oracle/QAS/sapdata4/sr3_43/sr3.data43';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_44/sr3.data44' to '/oracle/QAS/sapdata4/sr3_44/sr3.data44';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_45/sr3.data45' to '/oracle/QAS/sapdata4/sr3_45/sr3.data45';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_46/sr3.data46' to '/oracle/QAS/sapdata4/sr3_46/sr3.data46';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_47/sr3.data47' to '/oracle/QAS/sapdata4/sr3_47/sr3.data47';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_48/sr3.data48' to '/oracle/QAS/sapdata4/sr3_48/sr3.data48';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_49/sr3.data49' to '/oracle/QAS/sapdata4/sr3_49/sr3.data49';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_50/sr3.data50' to '/oracle/QAS/sapdata4/sr3_50/sr3.data50';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_51/sr3.data51' to '/oracle/QAS/sapdata4/sr3_51/sr3.data51';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_52/sr3.data52' to '/oracle/QAS/sapdata4/sr3_52/sr3.data52';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_53/sr3.data53' to '/oracle/QAS/sapdata4/sr3_53/sr3.data53';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_54/sr3.data54' to '/oracle/QAS/sapdata4/sr3_54/sr3.data54';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_55/sr3.data55' to '/oracle/QAS/sapdata4/sr3_55/sr3.data55';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_55/sr3.data56' to '/oracle/QAS/sapdata4/sr3_55/sr3.data56';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_55/sr3.data57' to '/oracle/QAS/sapdata4/sr3_55/sr3.data57';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_56/sr3.data59' to '/oracle/QAS/sapdata5/sr3_56/sr3.data59';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_57/sr3.data60' to '/oracle/QAS/sapdata5/sr3_57/sr3.data60';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_58/sr3.data61' to '/oracle/QAS/sapdata5/sr3_58/sr3.data61';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_59/sr3.data62' to '/oracle/QAS/sapdata4/sr3_59/sr3.data62';             
set newname for datafile '/oracle/PRD/sapdata2/sr3_63/sr3.data63' to '/oracle/QAS/sapdata2/sr3_63/sr3.data63';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_64/sr3.data64' to '/oracle/QAS/sapdata4/sr3_64/sr3.data64';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_65/sr3.data65' to '/oracle/QAS/sapdata5/sr3_65/sr3.data65';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_66/sr3.data66' to '/oracle/QAS/sapdata5/sr3_66/sr3.data66';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_67/sr3.data67' to '/oracle/QAS/sapdata4/sr3_67/sr3.data67';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_68/sr3.data68' to '/oracle/QAS/sapdata5/sr3_68/sr3.data68';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_69/sr3.data69' to '/oracle/QAS/sapdata5/sr3_69/sr3.data69';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_70/sr3.data70' to '/oracle/QAS/sapdata5/sr3_70/sr3.data70';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_71/sr3.data71' to '/oracle/QAS/sapdata5/sr3_71/sr3.data71';             
set newname for datafile '/oracle/PRD/sapdata5/sr3_72/sr3.data72' to '/oracle/QAS/sapdata5/sr3_72/sr3.data72';             
set newname for datafile '/oracle/PRD/sapdata4/sr3_73/sr3.data73' to '/oracle/QAS/sapdata4/sr3_73/sr3.data73';             
set newname for datafile '/oracle/PRD/sapdata3/sr3_74/sr3.data74' to '/oracle/QAS/sapdata3/sr3_74/sr3.data74';             
set newname for datafile '/oracle/PRD/sapdata1/sr3_75/sr3.data75' to '/oracle/QAS/sapdata1/sr3_75/sr3.data75';             
set newname for datafile '/oracle/PRD/sapdata1/sr3_76/sr3.data76' to '/oracle/QAS/sapdata1/sr3_76/sr3.data76';             
set newname for datafile '/oracle/PRD/sapdata1/system_2/system.data2' to '/oracle/QAS/sapdata1/system_2/system.data2';        
set newname for datafile '/oracle/PRD/sapdata1/undo_2/undo.data2' to '/oracle/QAS/sapdata1/undo_2/undo.data2';            
set newname for datafile '/oracle/PRD/sapdata1/system_3/system.data3' to '/oracle/QAS/sapdata1/system_3/system.data3';        
set newname for datafile '/oracle/PRD/sapdata1/undo_3/undo.data3' to '/oracle/QAS/sapdata1/undo_3/undo.data3';             
set newname for datafile '/oracle/PRD/sapdata6/sr3_77/sr3.data77' to '/oracle/QAS/sapdata6/sr3_77/sr3.data77';             
set newname for datafile '/oracle/PRD/sapdata6/sr3_78/sr3.data78' to '/oracle/QAS/sapdata6/sr3_78/sr3.data78';             
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_1/sr3740x.data1' to '/oracle/QAS/sapdata6/sr3740x_1/sr3740x.data1';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_2/sr3740x.data2' to '/oracle/QAS/sapdata6/sr3740x_2/sr3740x.data2';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_3/sr3740x.data3' to '/oracle/QAS/sapdata6/sr3740x_3/sr3740x.data3';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_4/sr3740x.data4' to '/oracle/QAS/sapdata6/sr3740x_4/sr3740x.data4';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_5/sr3740x.data5' to '/oracle/QAS/sapdata6/sr3740x_5/sr3740x.data5';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_6/sr3740x.data6' to '/oracle/QAS/sapdata6/sr3740x_6/sr3740x.data6';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_7/sr3740x.data7' to '/oracle/QAS/sapdata6/sr3740x_7/sr3740x.data7';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_8/sr3740x.data8' to '/oracle/QAS/sapdata6/sr3740x_8/sr3740x.data8';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_9/sr3740x.data9' to '/oracle/QAS/sapdata6/sr3740x_9/sr3740x.data9';       
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_10/sr3740x.data10' to '/oracle/QAS/sapdata6/sr3740x_10/sr3740x.data10';    
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_11/sr3740x.data11' to '/oracle/QAS/sapdata6/sr3740x_11/sr3740x.data11';   
set newname for datafile '/oracle/PRD/sapdata6/sr3740x_12/sr3740x.data12' to '/oracle/QAS/sapdata6/sr3740x_12/sr3740x.data12';    
restore database;
switch datafile all;
recover database noredo;
release channel ch1;
release channel ch2;
release channel ch3;
release channel ch4;
}



=========================================================================================



/oracle/QAS/origlogA/log_g11m1.dbf
/oracle/QAS/mirrlogA/log_g11m2.dbf
/oracle/QAS/origlogB/log_g12m1.dbf
/oracle/QAS/mirrlogB/log_g12m2.dbf
/oracle/QAS/origlogA/log_g13m1.dbf
/oracle/QAS/mirrlogA/log_g13m2.dbf
/oracle/QAS/origlogB/log_g14m1.dbf
/oracle/QAS/mirrlogB/log_g14m2.dbf


nid target=sys/manager1$@PRD dbname=QAS setname=YES



SELECT v.file#, t.file_name, v.status FROM dba_temp_files t, v$tempfile v WHERE t.file_id = v.file#;


ALTER DATABASE TEMPFILE '/oracle/PRD/sapdata1/temp_1/temp.data' DROP INCLUDING DATAFILES;

alter database tempfile '/oracle/PRD/sapdata1/temp_1/temp.data1' drop including datafiles;





    GROUP# STATUS  TYPE    MEMBER                                                                 IS_
---------- ------- ------- ---------------------------------------------------------------------- ---
         1         ONLINE  /oracle/QAS/origlogA/log_g11m1.dbf                                     NO
         1         ONLINE  /oracle/QAS/mirrlogA/log_g11m2.dbf                                     NO
         2         ONLINE  /oracle/QAS/origlogB/log_g12m1.dbf                                     NO
         2         ONLINE  /oracle/QAS/mirrlogB/log_g12m2.dbf                                     NO
         3         ONLINE  /oracle/QAS/origlogA/log_g13m1.dbf                                     NO
         3         ONLINE  /oracle/QAS/mirrlogA/log_g13m2.dbf                                     NO
         4         ONLINE  /oracle/QAS/origlogB/log_g14m1.dbf                                     NO
         4         ONLINE  /oracle/QAS/mirrlogB/log_g14m2.dbf                                     NO


orapwd file=orapwQAS password=manager1$

manager1$


CREATE TEMPORARY TABLESPACE PSAPTEMP TEMPFILE '/oracle/QAS/sapdata1/temp_1/temp.data1' SIZE 10g autoextend on next 10g maxsize unlimited;

DROP TABLESPACE PSAPTEMP1 INCLUDING CONTENTS AND DATAFILES;


create undo tablespace PSAPUNDO datafile  '/oracle/QAS/sapdata1/undo_1/undo.data1'  size 3300m;


alter tablespace PSAPUNDO add datafile '/oracle/QAS/sapdata1/undo_1/undo.data3'  size 3300m;


    GROUP# STATUS  TYPE    MEMBER                                                                 IS_
---------- ------- ------- ---------------------------------------------------------------------- ---
         1         ONLINE  /oracle/QAS/origlogA/log_g11m1.dbf                                     NO
         1         ONLINE  /oracle/QAS/mirrlogA/log_g11m2.dbf                                     NO

         2         ONLINE  /oracle/QAS/origlogB/log_g12m1.dbf                                     NO
         2         ONLINE  /oracle/QAS/mirrlogB/log_g12m2.dbf                                     NO

         3         ONLINE  /oracle/QAS/origlogA/log_g13m1.dbf                                     NO
         3         ONLINE  /oracle/QAS/mirrlogA/log_g13m2.dbf                                     NO

         4         ONLINE  /oracle/QAS/origlogB/log_g14m1.dbf                                     NO
         4         ONLINE  /oracle/QAS/mirrlogB/log_g14m2.dbf                                     NO

8 rows selected.


alter database add logfile group 4('/oracle/QAS/origlogB/log_g14m1.dbf','/oracle/QAS/mirrlogB/log_g14m2.dbf')size 100m;

alter database drop logfile group 4;


alter database add logfile group 4('/oracle/QAS/origlogB/log_g14m3.dbf') size 50M;

alter system set undo_tablespace=PSAPUNDO2;

drop tablespace PSAPUNDO including contents and datafiles;




/oracle/PRD/mirrlogB

CREATE UNDO TABLESPACE PSAPUNDO datafile '/oracle/PRD/sapdata1/undo_2/' size 1000m autoextend on maxsize unlimited';



ALTER DATABASE RENAME FILE '  
ALTER DATABASE RENAME FILE '/oracle/PRD/mirrlogA/log_g11m2.dbf' to'/oracle/QAS/mirrlogA/log_g11m2.dbf';
ALTER DATABASE RENAME FILE '/oracle/PRD/origlogB/log_g12m1.dbf' to '/oracle/QAS/origlogB/log_g12m1.dbf';
ALTER DATABASE RENAME FILE '/oracle/PRD/mirrlogB/log_g12m2.dbf' to '/oracle/QAS/mirrlogB/log_g12m2.dbf';
ALTER DATABASE RENAME FILE '/oracle/PRD/origlogA/log_g13m1.dbf' to '/oracle/QAS/origlogA/log_g13m1.dbf';
ALTER DATABASE RENAME FILE '/oracle/PRD/mirrlogA/log_g13m2.dbf' to '/oracle/QAS/mirrlogA/log_g13m2.dbf';
ALTER DATABASE RENAME FILE '/oracle/PRD/origlogB/log_g14m1.dbf' to '/oracle/QAS/origlogB/log_g14m1.dbf';
ALTER DATABASE RENAME FILE '/oracle/PRD/mirrlogB/log_g14m2.dbf' to '/oracle/QAS/mirrlogB/log_g14m2.dbf';





ALTER DATABASE RENAME FILE '/oracle/PRD/origlogA/log_g11m1.dbf' TO '/oracle/QAS/origlogA/log_g11m1.dbf'';










/upgrade/PRD_Backup_20092017/QAS_20170920_210_1_CONTROL




select
  sid,
  start_time,
  totalwork
  sofar, 
 (sofar/totalwork) * 100 pct_done
from 
   v$session_longops
where 
   totalwork > sofar
AND 
   opname NOT LIKE '%aggregate%'
AND 
   opname like 'RMAN%';


select 
   sid, 
   spid, 
   client_info, 
   event, 
   seconds_in_wait, 
   p1, p2, p3
 from 
   v$process p, 
   v$session s
 where 
   p.addr = s.paddr
 and 
   client_info like 'rman channel=%';






