#!/bin/bash
#
# Script zur Konfiguration von cps und erstellung der cronjobs bzw. scripten
#
# v.0.0.0 hp mit script-zeilen von th
#
#############################################################################
#
# ** ERSTELLT AM       : 22.08.2006 th
# ** MACHT NICHT       : .profile erstellen
# **                   : Verzeichnisstruktur anlegen
# **                   : Software installieren
# **                   : my.cnf anlegen
# **                   : Datenbank (mit/ohne INNODB-Engine) anlegen
# **                   : Datenbank-User mysql und backup anlegen
# **                   : mysql.server anpassen
# **                   : mysqlctl erstellen
# **======================================================================
# ** MACHT             : create_cps_maint_script
# **                   : backup script erstellen
# **                   : cronjobs erstellen
# **  ln -s /opt/cps/RZA/protocols/cps.log cps.log
# **  ln -s /opt/cps/RZA/protocols/cps.prt cps.prt
# **======================================================================
# ** AENDERUNGEN
# ************************************************************************
# ************************************************************************
AUTHOR="SIS GO ICS G EBDB3 hp"

if [ `echo $SHELL |grep bash` ]; then ECHO="echo -e"
else ECHO="echo"
fi

######### functions

function_create_cps_maint_script(){

if [ -f "$HOME/scripts/maintenance_start.sh" ]
then
        echo "$HOME/scripts/maintenance_start.sh existiert bereits"
        exit 1
fi

OUT=$HOME/scripts/maintenance_start.sh
echo "#!/bin/sh" > $OUT
echo "# ************************************************************************" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "# ** SCRIPT   : mysqlctl" >> $OUT
echo "# **            UNIX-Shellscript f. Start/Stop d. Ueberwachung von mysql" >> $OUT
echo "# ** Version  : 2.1" >> $OUT
echo "# **======================================================================" >> $OUT
echo "# ** HOST              : `hostname`" >> $OUT
echo "# ** AUTOR             : $AUTHOR" >> $OUT
echo "# ** ERSTELLT AM       : `date`" >> $OUT
echo "# **" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "" >> $OUT
echo "## maintenance_start.sh" >> $OUT
echo "# " >> $OUT
echo "## DELETE funktioniert nur mit einer cps.HV, welche aber bei einem reboot geloescht wird !!!! deshalb hier copy !" >> $OUT
echo "## cps.* koennen nur mit COPY im Zielverzeichnisueberschrieben werden" >> $OUT
echo "## Copy funktioniert nur mit -auto!" >> $OUT
echo "# " >> $OUT
echo "sudo /opt/cps/RZA/bin/modify_cps_conf.pl -a copy -s $HOME/scripts/cps.mysql.par_maint -d cps.mysql.par -auto -restart" >> $OUT
echo "" >> $OUT
echo "" >> $OUT
chmod 770 $OUT
} 

function_create_cps_monitoring_script(){

if [ -f "$HOME/scripts/monitoring_start.sh" ]
then
        echo "$HOME/scripts/monitoring_start.sh existiert bereits"
        exit 1
fi


OUT=$HOME/scripts/monitoring_start.sh
echo "#!/bin/sh" > $OUT
echo "# ************************************************************************" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "# ** SCRIPT   : mysqlctl" >> $OUT
echo "# **            UNIX-Shellscript f. Start/Stop d. Ueberwachung von mysql" >> $OUT
echo "# ** Version  : 2.1" >> $OUT
echo "# **======================================================================" >> $OUT
echo "# ** HOST              : `hostname`" >> $OUT
echo "# ** AUTOR             : $AUTHOR" >> $OUT
echo "# ** ERSTELLT AM       : `date`" >> $OUT
echo "# **" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "# ************************************************************************" >> $OUT
echo "" >> $OUT
echo "## maintenance_start.sh" >> $OUT
echo "# " >> $OUT
echo "## DELETE funktioniert nur mit einer cps.HV, welche aber bei einem reboot geloescht wird !!!! deshalb hier copy !" >> $OUT
echo "## cps.* koennen nur mit COPY im Zielverzeichnisueberschrieben werden" >> $OUT
echo "## Copy funktioniert nur mit -auto!" >> $OUT
echo "# " >> $OUT
echo "sudo /opt/cps/RZA/bin/modify_cps_conf.pl -a copy -s $HOME/scripts/cps.mysql.par_moni -d cps.mysql.par -auto -restart" >> $OUT
echo "" >> $OUT
echo "" >> $OUT
chmod 770 $OUT
}

function_create_cps_mysql_par_maint(){

if [ -f "$HOME/scripts/cps.mysql.par_maint" ]
then
        echo "$HOME/scripts/cps.mysql.par_maint existiert bereits"
        exit 1
fi

OUT=$HOME/scripts/cps.mysql.par_maint
echo "#!/bin/sh" > $OUT
echo "# ************************************************************************" >> $OUT
echo "#                                                                         " >> $OUT
echo "# Prozess MySQL                                                           " >> $OUT
echo "# befindet sich in maintenance mode                                       " >> $OUT
echo "#                                                                         " >> $OUT
echo "# **======================================================================" >> $OUT

echo "" >> $OUT
chmod 770 $OUT
}


function_cps.mysql.par_moni(){


if [ -f "$HOME/scripts/cps.mysql.par_moni" ]
then
        echo "$HOME/scripts/cps.mysql.par_moni existiert bereits"
        exit 1
fi


OUT=$HOME/scripts/cps.mysql.par_moni
STRING_DATABASE=$HOST"_"$USER
STRING_FILESYSTEM=$HOST"_FILESYSTEM_"$USER
echo "#!/bin/sh" > $OUT
echo "# ************************************************************************" >> $OUT
echo "# cps.$USER.par                                                           " >> $OUT
echo "#                                                                         " >> $OUT
echo "# **======================================================================" >> $OUT
echo "#                                                                         " >> $OUT
echo "# Filesysteme                                                             " >> $OUT
echo "OBJ=CPS_MYS_RDBMS_FSUSAGE_$STRING_FILESYSTEM                              " >> $OUT
echo "TEST=SLICE($HOME,POLL,5,90)                                               " >> $OUT
echo "RUN                                                                       " >> $OUT
echo "#weitere Fileueberwachung                                                 " >> $OUT
echo "#OBJ=CPS_MYS_RDBMS_FSUSAGE_$STRING_FILESYSTEM                             " >> $OUT
echo "#TEST=SLICE($HOME,POLL,5,90)                                              " >> $OUT
echo "#RUN                                                                      " >> $OUT
echo "#                                                                         " >> $OUT
echo "####################                                                      " >> $OUT
echo "#                                                                         " >> $OUT
echo "#  Prozess $USER                                                          " >> $OUT
echo "#                                                                         " >> $OUT
echo "OBJ=CPS_MYSQL_RDBMS_PROCESSDOWN_$STRING_DATABASE                          " >> $OUT
echo "TEST=STA($USER,"$HOME/mysql/bin/mysqld*",1,POLL,5)                        " >> $OUT
echo "RUN                                                                       " >> $OUT
echo "#                                                                         " >> $OUT
echo "                                                                          " >> $OUT
chmod 770 $OUT
}


function_create_cps_maint_script
function_create_cps_monitoring_script
function_create_cps_mysql_par_maint
function_cps.mysql.par_moni


# links zu den cps logs erstellen  

if [ -f "/opt/cps/RZA/bin/cps" ]
then
	ln -s /opt/cps/RZA/protocols/cps.prt $HOME/scripts/cps.prt
        ln -s /opt/cps/RZA/protocols/cps.log $HOME/scripts/cps.log
        ln -s /opt/cps/conf/cps.$USER.par cps.$USER.par
fi

echo "NICHT VERGESSEN:   Ist das sudo-script schon angelegt worden?"
