# #################################################
# Retrieve the SQLTEXT + BIND VARIABLES + EXEC PLAN
# 					#   #     #
# Authors:	Mahmmoud ADEL	      # # # #   # #
# 		Farrukh Salman	     #  #   #  ####
# Created:	24-12-11	    #   #   # #   # 
# Modified:	31-12-13	     
#		Customized the script to run on
#		various environments.
#		06-05-14 Getting the Bind Variable
#			 info for the SQLID
#		05-11-15 Fix Divided by Zero error
#
#
# #################################################

# ###########
# Description:
# ###########
echo
echo "============================================================================"
echo "This script retrieves SQLTEXT + BIND VARIABLES VALUES + EXEC PLAN of a SQLID ..."
echo "============================================================================"
echo
sleep 1


# ###########################
# Listing Available Databases:
# ###########################

# Count Instance Numbers:
INS_COUNT=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|wc -l )

# Exit if No DBs are running:
if [ $INS_COUNT -eq 0 ]
 then
   echo No Database Running !
   exit
fi

# If there is ONLY one DB set it as default without prompt for selection:
if [ $INS_COUNT -eq 1 ]
 then
   export ORACLE_SID=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )

# If there is more than one DB ASK the user to select:
elif [ $INS_COUNT -gt 1 ]
 then
    echo
    echo "Select the ORACLE_SID:[Enter the number]"
    echo ---------------------
    select DB_ID in $( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )
     do
        if [ -z "${REPLY##[0-9]*}" ]
         then
          export ORACLE_SID=$DB_ID
	  echo
          echo Selected Instance:
          echo "********"
          echo $DB_ID
          echo "********"
	  echo
          break
         else
          export ORACLE_SID=${REPLY}
          break
        fi
     done

fi
# Exit if the user selected a Non Listed Number:
        if [ -z "${ORACLE_SID}" ]
         then
          echo "You've Entered An INVALID ORACLE_SID"
          exit
        fi

# #########################
# Getting ORACLE_HOME
# #########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|grep -v ASM|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep ${ORA_USER} /etc/passwd| cut -f6 -d ':'|tail -1`

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

# ########################################
# Exit if the user is not the Oracle Owner:
# ########################################
CURR_USER=`whoami`
        if [ ${ORA_USER} != ${CURR_USER} ]; then
          echo ""
          echo "You're Running This Sctipt with User: \"${CURR_USER}\" !!!"
          echo "Please Run This Script With The Right OS User: \"${ORA_USER}\""
          echo "Script Terminated!"
          exit
        fi

# ########################################
# SQLPLUS: Check SQL FULLTEXT & EXEC PLAN:
# ########################################
# Variables
echo 
echo "Enter the SQL_ID:"
echo "================"
read SQL_ID
	if [ -z "${SQL_ID}" ]
	 then
	  exit
	fi
${ORACLE_HOME}/bin/sqlplus -s '/ as sysdba' << EOF
set feedback off
set linesize 180
col SQL_FULLTEXT for a140

PROMPT *************************
PROMPT Statement Info:
PROMPT *************************
set linesize 190
col "ELAPSED|CPU TIME/EXC_SEC" for a24
col "PLSQL|JAVA TIME/EXEC_SEC" for a27
col "APP|USR_IO|CLS WAIT_T/EXEC_SEC" for a30
col "BUFF_GET|DISK_R|DIRECT_W/EXC" for a29
col MODULE for a15
VARIABLE A REFCURSOR;
DECLARE
l_cursor SYS_REFCURSOR;
BEGIN

open :A for

select executions,round((ELAPSED_TIME/executions)/1000000,2)||' | '||round((CPU_TIME/executions)/1000000,2) "ELAPSED|CPU TIME/EXC_SEC",
round((APPLICATION_WAIT_TIME/executions)/1000000,2)||' | '||round((USER_IO_WAIT_TIME/executions)/1000000,2)||' | '||round((CLUSTER_WAIT_TIME/executions)/1000000,2)
"APP|USR_IO|CLS WAIT_T/EXEC_SEC",
round((PLSQL_EXEC_TIME/executions)/1000000,2)||' | '||round((JAVA_EXEC_TIME/executions)/1000000,2) "PLSQL|JAVA TIME/EXEC_SEC",
round((ROWS_PROCESSED/executions),1) "ROWS_PROCESSED/EXEC",
round((BUFFER_GETS/executions),2)||' | '||round((DISK_READS/executions),2)||' | '||round((DIRECT_WRITES/executions),2) "BUFF_GET|DISK_R|DIRECT_W/EXC",
round(PERSISTENT_MEM/1024/1024,2) "P_MEM_MB", USERS_EXECUTING,substr(MODULE,1,15)"MODULE", FIRST_LOAD_TIME, LAST_LOAD_TIME
from v\$sql where SQL_ID='$SQL_ID';

END;
/
PRINT A;
/

PROMPT
PROMPT *************************
PROMPT BIND VARIABLES + SQL TEXT:
PROMPT *************************
set heading off
select 'VARIABLE '||trim (leading ':' from name)||' '||case when datatype_string= 'DATE' then 'VARCHAR2(60)' else datatype_string end||';' from v\$sql_bind_capture
where SQL_ID='$SQL_ID' and CHILD_NUMBER = (select max(CHILD_NUMBER) from v\$sql_bind_capture where SQL_ID='$SQL_ID');
select 'EXECUTE '||name||' := '||''''||value_string||''''||';' from v\$sql_bind_capture
where SQL_ID='$SQL_ID' and CHILD_NUMBER = (select max(CHILD_NUMBER) from v\$sql_bind_capture where SQL_ID='$SQL_ID');
select sql_fulltext from v\$sql where sql_id='$SQL_ID' and CHILD_NUMBER = (select max(CHILD_NUMBER) from v\$sql where SQL_ID='$SQL_ID');
set heading on

PROMPT
set heading off
select 'Notes: (11g Onwards)' from dual;
PROMPT -------

select
decode(IS_BIND_SENSITIVE,'Y','- The Bind Variables for this statement are Being CHANGED.','N','- The Bind Variables for this statement NEVER CHANGED.'),
decode(IS_BIND_AWARE,'Y','- Adaptive Cursor Sharing CHANGED the initial execution plan for that SQL_ID at least one time.','N',''),
'  Child Number: '||CHILD_NUMBER
from v\$sql where sql_id='$SQL_ID' and CHILD_NUMBER = (select max(CHILD_NUMBER) from v\$sql where SQL_ID='$SQL_ID');
set heading on

/*
PROMPT
PROMPT
PROMPT *********************
PROMPT BIND VARIABLE VALUES:
PROMPT *********************

col BIND_VARIABLE for a20
col VALUE for a100
col DATATYPE for a20
select name BIND_VARIABLE,value_string VALUE,datatype_string DATATYPE from v\$sql_bind_capture
where SQL_ID='$SQL_ID' and CHILD_NUMBER = (select max(CHILD_NUMBER) from v\$sql_bind_capture where SQL_ID='$SQL_ID');
*/

PROMPT
PROMPT
PROMPT *********************
PROMPT EXECUTION PLAN:
PROMPT *********************

col PLAN_TABLE_OUTPUT for a156
SELECT * FROM table(DBMS_XPLAN.DISPLAY_CURSOR(('$SQL_ID')));
EOF

# #############
# END OF SCRIPT
# #############
# REPORT BUGS to: <mahmmoudadel@hotmail.com>.
# DISCLAIMER: THIS SCRIPT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT WITHOUT ANY WARRANTY. IT IS PROVIDED "AS IS".
# DOWNLOAD THE LATEST VERSION OF DATABASE ADMINISTRATION BUNDLE FROM: http://dba-tips.blogspot.com/2014/02/oracle-database-administration-scripts.html
