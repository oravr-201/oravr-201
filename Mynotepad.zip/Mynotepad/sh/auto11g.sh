info ( )
{
echo -e $RED

echo '##################################################   '
echo '#            Created by                          #   '
echo '#       vishal Bhandwalkar                       #   '
echo '#        Mob : 9960902388                        #   '
echo '#------------------------------------------------#   '
echo '#                                                #   '
echo '#Please insert only database patch dir and number#   '
echo '#         GRID_DB_PATCH=27107360                 #   '
echo '#         OJVM_PATCH=26925532                    #   '
echo '#         DIR=/home/oracle/vb/                   #   '
echo '#                                                #   '
echo '#  NOTE : we need to Run this script from oralce #   '
echo '#  user but we need sudo root Access             #   '
echo '#  Please find the command  log on /tmp folder   #   '
echo '#                                              ###   '
echo '###################################################  '
echo "Please check the file for more details ====> /tmp/final_patch_status.log ...."
echo -e  $NC

}



echo
echo "==================================================="
echo "This script RAC + OJVM PATCHING           on 11G  ."
echo "==================================================="
echo
sleep 1
#############*****###############
# Description: Listener down   #
#                               #
#############*****###############
TNS_STOP( )
{

echo -e $CYAN
export ORACLE_SID=$ORACLE_SIDD
echo " Welcome to oravb wait 2 min "

echo $ORACLE_SID

if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

echo " Welcome to oravb "

#TNS_LIST=`ps -ef | grep tns | grep -inherit | awk '{print $9}'`

for TNS in $TNS_LIST
do
export TNS_NAME=$TNS
$ORACLE_HOME/bin/lsnrctl stop $TNS_NAME
done

echo -e $NC

}




#############*****###############
# Description: Listener start  # 
#                               #
#############*****###############

TNS_START( )
{

echo -e $CYAN
echo
echo "==================================================="
echo "This script start listener                      .  "
echo "==================================================="
echo
sleep 1

#############################
# Listing Available Databases:
#############################

export ORACLE_SID=$ORACLE_SIDD
echo " Welcome to oravb wait 2 min "

echo $ORACLE_SID

if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

echo " Welcome to oravb "

#TNS_LIST=`ps -ef | grep tns | grep -inherit | awk '{print $9}'`

for TNS in $TNS_LIST
do
export TNS_NAME=$TNS
$ORACLE_HOME/bin/lsnrctl start $TNS_NAME
done
echo -e $NC
}



#############************###############
# Description: start database patching #
#                                      #
#############************###############
database( )
{

echo -e $CYAN
echo
echo "==================================================="
echo "This script database patch                      .  "
echo "==================================================="
echo
sleep 1

#############################
# Listing Available Databases:
#############################


export ORACLE_SID=$ORACLE_SIDD
echo " Welcome to oravb wait 2 min "

echo $ORACLE_SID

if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

echo " 3"


echo " Welcome to oravb sleep 2 min "
sleep 90


echo " Database ls inventory  "

$ORACLE_HOME/OPatch/./opatch lsinventory | tee /tmp/pre_lsinventory_1.log


echo " start patch database "

sudo su - root -c "$ORACLE_HOME/OPatch/./opatch auto  $DIR/$GRID_DB_PATCH -oh $ORACLE_HOME  -ocmrf $ORACLE_HOME/dbs/ocm.rsp " -s /bin/sh oracle   | tee /tmp/patch_database.log

echo " Database OJVM_PATCH  "
cd $DIR/$OJVM_PATCH

$ORACLE_HOME/OPatch/opatch apply -silent -ocmrf $ORACLE_HOME/dbs/ocm.rsp


echo " Database ls post inventory  "

$ORACLE_HOME/OPatch/./opatch lsinventory | tee /tmp/post_lsinventory_1.log

sleep 90
echo -e $NC
}


#############************###############
# Description: start Grid     patching #
#                                      #
#############************###############
asm( )
{
echo -e $CYAN
echo
echo "==================================================="
echo "This script asm patch .  "
echo "==================================================="
echo
sleep 1

#############################
# Listing Available Databases:
#############################

# Count Instance Numbers:
INS_COUNT=$( ps -ef|grep pmon|grep -v grep|grep -v ora_pmon_|wc -l )

# Exit if No DBs are running:
if [ $INS_COUNT -eq 0 ]
 then
   echo No Database Running !
   exit
fi

# If there is ONLY one DB set it as default without prompt for selection:
if [ $INS_COUNT -eq 1 ]
 then
   export ORACLE_SID=$( ps -ef|grep pmon|grep -v grep|grep -v ora_pmon_|awk '{print $NF}'|sed -e 's/asm_pmon_//g'|grep -v sed|grep -v "s///g" )

# If there is more than one DB ASK the user to select:
elif [ $INS_COUNT -gt 1 ]
 then
    echo
    echo "Select the ORACLE_SID:[Enter the number]"
    echo ---------------------
    select DB_ID in $( ps -ef|grep pmon|grep -v grep|grep -v ora_pmon_|awk '{print $NF}'|sed -e 's/asm_pmon_//g'|grep -v sed|grep -v "s///g" )
     do
        if [ -z "${REPLY##[0-9]*}" ]
         then
          export ORACLE_SID=$DB_ID
          echo Selected Instance:
          echo
          echo "********"
          echo $DB_ID
          echo "********"
          echo
          break
         else
          export ORACLE_SID=${REPLY}
          break
        fi
     done

fi
# Exit if the user selected a Non Listed Number:
        if [ -z "${ORACLE_SID}" ]
         then
          echo "You've Entered An INVALID ORACLE_SID"
          exit
        fi

###########################
# Getting ORACLE_HOME
###########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|grep -v ora_pmon_|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep ${ORA_USER} /etc/passwd| cut -f6 -d ':'|tail -1`

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

##########################################
# Exit if the user is not the Oracle Owner:
##########################################
CURR_USER=`whoami`
        if [ ${ORA_USER} != ${CURR_USER} ]; then
          echo ""
          echo "You're Running This Sctipt with User: \"${CURR_USER}\" !!!"
          echo "Please Run This Script With The Right OS User: \"${ORA_USER}\""
          echo "Script Terminated!"
          exit
        fi

echo " Welcome to oravb "

echo -e $GREEN
$ORACLE_HOME/bin/sqlplus '/ as sysdba' <<EOF > /tmp/asm_disk.log
spool /tmp/asm_disk_1.log

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(sys_context('USERENV', 'INSTANCE_NAME'), 17) current_instance FROM dual;
SET TERMOUT ON;

PROMPT
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : ASM Disk Groups                                             |
PROMPT | Instance : &current_instance                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN group_name             FORMAT a25           HEAD 'Disk Group|Name'
COLUMN sector_size            FORMAT 99,999        HEAD 'Sector|Size'
COLUMN block_size             FORMAT 99,999        HEAD 'Block|Size'
COLUMN allocation_unit_size   FORMAT 999,999,999   HEAD 'Allocation|Unit Size'
COLUMN state                  FORMAT a11           HEAD 'State'
COLUMN type                   FORMAT a6            HEAD 'Type'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'Total Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'

BREAK ON report ON disk_group_name SKIP 1

COMPUTE sum LABEL "Grand Total: " OF total_mb used_mb ON report

SELECT
    name                                     group_name
  , sector_size                              sector_size
  , block_size                               block_size
  , allocation_unit_size                     allocation_unit_size
  , state                                    state
  , type                                     type
  , total_mb                                 total_mb
  , (total_mb - free_mb)                     used_mb
  , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used
FROM
    v\$asm_diskgroup
WHERE
    total_mb != 0
ORDER BY
    name;

spool off
EOF

echo -e $CYAN
echo " cluster status before asm patch   "

sudo su - root -c "$ORACLE_HOME/bin/./crsctl stat res -t " -s /bin/sh oracle | tee /tmp/pre_crs.log

$ORACLE_HOME/OPatch/./opatch lsinventory | tee /tmp/pre_lsinventory.log

echo " start patch asm "
sudo su - root -c "$ORACLE_HOME/OPatch/./opatch auto  $DIR/$GRID_DB_PATCH -oh $ORACLE_HOME  -ocmrf $ORACLE_HOME/dbs/ocm.rsp " -s /bin/sh oracle  | tee /tmp/patch_database.log

echo " lsinventory after asm patch   "
$ORACLE_HOME/OPatch/./opatch lsinventory | tee /tmp/post_lsinventory.log

echo " cluster status after sleep 5 minute "

sleep 90

echo " cluster status after asm patch   "
sudo su - root -c "$ORACLE_HOME/bin/./crsctl stat res -t " -s /bin/sh oracle | tee /tmp/post_crs.log


echo -e $GREEN
$ORACLE_HOME/bin/sqlplus '/ as sysdba' <<EOF > /tmp/asm_disk_post.log
spool /tmp/asm_disk_1_post.log

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(sys_context('USERENV', 'INSTANCE_NAME'), 17) current_instance FROM dual;
SET TERMOUT ON;

PROMPT
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : ASM Disk Groups                                             |
PROMPT | Instance : &current_instance                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN group_name             FORMAT a25           HEAD 'Disk Group|Name'
COLUMN sector_size            FORMAT 99,999        HEAD 'Sector|Size'
COLUMN block_size             FORMAT 99,999        HEAD 'Block|Size'
COLUMN allocation_unit_size   FORMAT 999,999,999   HEAD 'Allocation|Unit Size'
COLUMN state                  FORMAT a11           HEAD 'State'
COLUMN type                   FORMAT a6            HEAD 'Type'
COLUMN total_mb               FORMAT 999,999,999   HEAD 'Total Size (MB)'
COLUMN used_mb                FORMAT 999,999,999   HEAD 'Used Size (MB)'
COLUMN pct_used               FORMAT 999.99        HEAD 'Pct. Used'

BREAK ON report ON disk_group_name SKIP 1

COMPUTE sum LABEL "Grand Total: " OF total_mb used_mb ON report

SELECT
    name                                     group_name
  , sector_size                              sector_size
  , block_size                               block_size
  , allocation_unit_size                     allocation_unit_size
  , state                                    state
  , type                                     type
  , total_mb                                 total_mb
  , (total_mb - free_mb)                     used_mb
  , ROUND((1- (free_mb / total_mb))*100, 2)  pct_used
FROM
    v\$asm_diskgroup
WHERE
    total_mb != 0
ORDER BY
    name;

spool off
EOF

echo " End asm patch  "
echo -e $NC
}



SHUTDOWN( )
{
echo -e $CYAN
###########################
# Getting ORACLE_HOME
###########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|grep -v ASM|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep ${ORA_USER} /etc/passwd| cut -f6 -d ':'|tail -1`

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

##########################################
# Exit if the user is not the Oracle Owner:
##########################################
CURR_USER=`whoami`
        if [ ${ORA_USER} != ${CURR_USER} ]; then
          echo ""
          echo "You're Running This Sctipt with User: \"${CURR_USER}\" !!!"
          echo "Please Run This Script With The Right OS User: \"${ORA_USER}\""
          echo "Script Terminated!"
          exit
        fi

#######################
# Checking Datafiles:
#######################
echo -e $GREEN
$ORACLE_HOME/bin/sqlplus '/ as sysdba' <<EOF
set linesize 190
set pages 1000
set long 32000
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
col HOSTNAME for a15
col BLOCKED for a7
col STARTUP_TIME for a19
select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,
to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from v\$instance I ,v\$database D ;

alter system switch logfile ;
alter system switch logfile ;
alter system switch logfile ;
alter system switch logfile ;
alter system switch logfile ;

alter system checkpoint ;
alter system checkpoint ;

shut immediate;

EOF
echo -e $NC
}

####---------------------------------------------------------------------------------------------------#

STARTUP_UPGRADE( )
{
echo -e $CYAN
###########################
# Getting ORACLE_HOME
###########################
###########################
###########################

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

#######################
# Checking Datafiles:
#######################
echo -e $GREEN
$ORACLE_HOME/bin/sqlplus '/ as sysdba' <<EOF

startup

set linesize 190
set pages 1000
set long 32000
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
col HOSTNAME for a15
col BLOCKED for a7
col STARTUP_TIME for a19
select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,
to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from v\$instance I ,v\$database D ;


@?/rdbms/admin/catbundle.sql psu apply
@?/rdbms/admin/utlrp.sql

shut immediate;

startup upgrade ;

@$DIR/$OJVM_PATCH/postinstall.sql

shut immediate;


startup

set linesize 190
set pages 1000
set long 32000
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
col HOSTNAME for a15
col BLOCKED for a7
col STARTUP_TIME for a19
select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,
to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from v\$instance I ,v\$database D ;
EOF


echo -e $CYAN
}

####-------------------------------------------------------------------------------------------------#######

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'
CYAN='\033[0;96m'
YELLOW='\033[0;93m'

info
echo -e $RED
echo
echo "==================================================="
echo "This script Shows the DATAFILES Size on a database."
echo "==================================================="
echo
sleep 1
echo -e $NC

#############################
# Listing Available Databases:
#############################

echo -e $BLUE


ORACLE_SIDD=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" | head -1 )

ps -eaf | grep pmon | tee /tmp/pre_pmon.log
ps -eaf | grep tns | tee /tmp/pre_tns.log

TNS_LIST=`ps -ef | grep tns | grep -inherit | awk '{print $9}'`

echo " stop listener 1 ......................................   "
TNS_STOP
DBLIST=`ps -ef | grep pmon | grep -v "grep pmon" | grep -v "+ASM" | cut -f3 -d_`


for dbname in $DBLIST
do
export ORACLE_SID=$dbname
echo $ORACLE_SID
SHUTDOWN
done

GRID_DB_PATCH=$1	
OJVM_PATCH=$2		
DIR=$3	

echo " start Grid patch ......................................   "
asm
echo " end  Grid patch ......................................   "

echo " stop listener 2 ......................................   "

TNS_STOP

echo " start database patch ......................................   "

database

echo " End  database patch ......................................   "

echo " stop listener 3 ......................................   "

TNS_STOP

echo " start database and apply psu and postinstall ......................................   "

for dbname in $DBLIST
do
export ORACLE_SID=$dbname
echo $ORACLE_SID
STARTUP_UPGRADE
done


echo " start listener 1 ......................................   "

TNS_START
echo " post stutus......................................   "
ps -eaf | grep pmon | tee /tmp/post_pmon.log
ps -eaf | grep tns | tee /tmp/post_tns.log

echo " ....................patching completed Successfully ...................."
cat /tmp/post_pmon.log >> /tmp/final_patch_status.log
cat /tmp/post_tns.log >> /tmp/final_patch_status.log
cat /tmp/post_lsinventory.log >> /tmp/final_patch_status.log
cat /tmp/post_lsinventory_1.log>> /tmp/final_patch_status.log
HOST=`hostname`

# mailx -s "Patch completed on server $HOST  " vishal-vilas.bandwalkar@atos.net << EOF
# 
# Hi All,
# 	Please find the below output of patching .....
# 	
# 	`cat /tmp/final_patch_status.log`
# 	
# EOF 
clear
info 

echo -e $NC


