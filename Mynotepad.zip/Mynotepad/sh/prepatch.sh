
main( )
{
###########################
# Getting ORACLE_HOME
###########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|grep -v ASM|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep ${ORA_USER} /etc/passwd| cut -f6 -d ':'|tail -1`

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

##########################################
# Exit if the user is not the Oracle Owner:
##########################################
CURR_USER=`whoami`
        if [ ${ORA_USER} != ${CURR_USER} ]; then
          echo ""
          echo "You're Running This Sctipt with User: \"${CURR_USER}\" !!!"
          echo "Please Run This Script With The Right OS User: \"${ORA_USER}\""
          echo "Script Terminated!"
          exit
        fi

#######################
# Checking Datafiles:
#######################
touch  /home/oracle/prepatch.log
$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

spool /home/oracle/prepatch.log append



set linesize 190
set pages 1000
set long 32000
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
col HOSTNAME for a15
col BLOCKED for a7
col STARTUP_TIME for a19
select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,
to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from v\$instance I ,v\$database D ;


archive log list

set lines 120
select TABLESPACE_NAME,EXTENT_MANAGEMENT,contents from dba_tablespaces;

select tablespace_name,sum(bytes/1024/1024) from dba_temp_files group by tablespace_name;

select file_name,bytes/1024/1024 from dba_temp_files;

COLUMN comp_id    FORMAT a9    HEADING 'Component|ID'
COLUMN comp_name  FORMAT a35   HEADING 'Component|Name'
COLUMN version    FORMAT a13   HEADING 'Version'
COLUMN status     FORMAT a11   HEADING 'Status'
COLUMN modified                HEADING 'Modified'
COLUMN Schema     FORMAT a15   HEADING 'Schema'
COLUMN procedure  FORMAT a45   HEADING 'Procedure'

SELECT
    comp_id
  , comp_name
  , version
  , status
  , modified
  , schema
  , procedure
FROM
    dba_registry
ORDER BY
    comp_id;

show parameter NLS_LENGTH_SEMANTICS
show parameter CLUSTER_DATABASE
show parameter parallel_max_server
show parameter undo_management
show parameter job_queue_process
show parameter pool
show parameter remote_login_password
show parameter spfile
show parameter pga
show parameter disk_as

select object_type,count(*) from dba_objects group by object_type order by 1;
select owner,count(*) from dba_objects group by owner order by 1;

col owner for a15
col object_name for a35
select OWNER,OBJECT_NAME,OBJECT_TYPE,status from DBA_OBJECTS where status = 'INVALID';
select count(*) from dba_objects where status='INVALID';

col password for a20
col username for a15
col account_statu for a15
select USERNAME,PASSWORD,ACCOUNT_STATUS,PROFILE,EXPIRY_DATE from dba_users order by ACCOUNT_STATUS;

select * from v\$log;

set pages 200 lines 200
col PROPERTY_NAME for a40
col PROPERTY_VALUE for a40
select PROPERTY_NAME,PROPERTY_VALUE from database_properties;

set lines 200
set pages 200
col ACTION_TIME for a30
col ACTION for a10
col NAMESPACE for a10
col VERSION for a10
col COMMENTS for a20
select * from registry\$history;

SELECT DISTINCT owner 
       FROM DBA_DEPENDENCIES 
       WHERE referenced_name 
       IN ('UTL_TCP','UTL_SMTP','UTL_MAIL','UTL_HTTP','UTL_INADDR')
       AND owner NOT IN ('SYS','PUBLIC','ORDPLUGINS');


	   SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN comp_id    FORMAT a9    HEADING 'Component|ID'
COLUMN comp_name  FORMAT a35   HEADING 'Component|Name'
COLUMN version    FORMAT a13   HEADING 'Version'
COLUMN status     FORMAT a11   HEADING 'Status'
COLUMN modified                HEADING 'Modified'
COLUMN Schema     FORMAT a15   HEADING 'Schema'
COLUMN procedure  FORMAT a45   HEADING 'Procedure'

SELECT
    comp_id
  , comp_name
  , version
  , status
  , modified
  , schema
  , procedure
FROM
    dba_registry
ORDER BY
    comp_id;
	   
spool off;

EOF
}

echo
echo "==================================================="
echo "This script Shows the DATAFILES Size on a database."
echo "==================================================="
echo
sleep 1

#############################
# Listing Available Databases:
#############################

# Count Instance Numbers:
INS_COUNT=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|wc -l )

# Exit if No DBs are running:
if [ $INS_COUNT -eq 0 ]
 then
   echo No Database Running !
   exit
fi

# If there is ONLY one DB set it as default without prompt for selection:
if [ $INS_COUNT -eq 1 ]
 then
   export ORACLE_SID=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )

# If there is more than one DB ASK the user to select:
elif [ $INS_COUNT -gt 1 ]
 then

  DBLIST=`ps -ef | grep pmon | grep -v "grep pmon" | grep -v "+ASM" | cut -f3 -d_`
for dbname in $DBLIST
do
export ORACLE_SID=$dbname
echo $ORACLE_SID
main
done

fi



