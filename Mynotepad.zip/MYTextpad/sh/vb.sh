##################################################
#                                    		      #
#       vishal Bhandwalkar                      ###
###################################################

#############
# Description:
#############
info( )
{
echo
echo "==================================================="
echo "This script Shows ALL information about databaes.  "
echo "==================================================="
echo
sleep 1

#############################
# Listing Available Databases:
#############################

# Count Instance Numbers:
INS_COUNT=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|wc -l )

# Exit if No DBs are running:
if [ $INS_COUNT -eq 0 ]
 then
   echo No Database Running !
   exit
fi

# If there is ONLY one DB set it as default without prompt for selection:
if [ $INS_COUNT -eq 1 ]
 then
   export ORACLE_SID=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )

# If there is more than one DB ASK the user to select:
elif [ $INS_COUNT -gt 1 ]
 then
    echo
    echo "Select the ORACLE_SID:[Enter the number]"
    echo ---------------------
    select DB_ID in $( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )
     do
        if [ -z "${REPLY##[0-9]*}" ]
         then
          export ORACLE_SID=$DB_ID
          echo Selected Instance:
          echo
          echo "********"
          echo $DB_ID
          echo "********"
          echo
          break
         else
          export ORACLE_SID=${REPLY}
          break
        fi
     done

fi
# Exit if the user selected a Non Listed Number:
        if [ -z "${ORACLE_SID}" ]
         then
          echo "You've Entered An INVALID ORACLE_SID"
          exit
        fi

###########################
# Getting ORACLE_HOME
###########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|grep -v ASM|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep ${ORA_USER} /etc/passwd| cut -f6 -d ':'|tail -1`

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

##########################################
# Exit if the user is not the Oracle Owner:
##########################################
CURR_USER=`whoami`
        if [ ${ORA_USER} != ${CURR_USER} ]; then
          echo ""
          echo "You're Running This Sctipt with User: \"${CURR_USER}\" !!!"
          echo "Please Run This Script With The Right OS User: \"${ORA_USER}\""
          echo "Script Terminated!"
          exit
        fi

echo " Welcome to oravb "

}

TABLESPACE( )
{
while [ 1 ]
do
 #       tput clear
        echo -e "\n"
echo -e "\t\t\t$MESSAGE\t"
echo -e
#echo -e "\t\t\tConnected to Database- `tput smso`$Yellow$tns`tput rmso`\t"
echo -e "\t###################### TABLESPACE : ###################"
echo -e "\t"
echo -e "\t#######################################################"
echo -e "\t"
echo -e "\t(1) TABLESPACE ( KB )                                         "
echo -e "\t(2) TABLESPACE ( MB )                                          "
echo -e "\t(3) TABLESPACE ( GB )                                        "
echo -e "\t(4) TABLESPACE TO OWNER                                         "
echo -e "\t(5) DATAFILE ALL                                          "
echo -e "\t(6) DATAFILE ALL (Auto)                                         "
echo -e "\t(7) DATAFILE ALL (Arch)                                         "
echo -e "\t(6) DATAFILE ALL (Auto)                                         "
echo -e "\t(6) DATAFILE ALL (Auto)                                         "
echo -e "\t(6) DATAFILE ALL (Auto)                                         "
echo -e "\n"
echo -e "\tEnter your choice (q to quit): \c                             "
echo -e "\n"
echo -e "\t########################################################"
#tput cup 16 40
 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
#itput clear
              main
########################################tablespace KB #####################################################3
        elif [ "$CHOICE" = "1"  ]
        then

        rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : Tablespaces                                                 |
PROMPT | Instance : '&current_instance'                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN status      FORMAT a9                 HEADING 'Status'
COLUMN name        FORMAT a30                HEADING 'Tablespace Name'
COLUMN type        FORMAT a15                HEADING 'TS Type'
COLUMN extent_mgt  FORMAT a10                HEADING 'Ext. Mgt.'
COLUMN segment_mgt FORMAT a10                HEADING 'Seg. Mgt.'
COLUMN ts_size     FORMAT 9,999,999,999,999.99  HEADING 'Tablespace Size'
COLUMN used        FORMAT 9,999,999,999,999.99  HEADING 'Used (in bytes)'
COLUMN free        FORMAT 9,999,999,999,999.99  HEADING 'Free (in bytes)'
COLUMN pct_used    FORMAT 999.99                HEADING 'Pct. Used'


BREAK ON report

COMPUTE sum OF ts_size  ON report
COMPUTE sum OF used     ON report
COMPUTE sum OF free     ON report
COMPUTE avg OF pct_used ON report

SELECT
    d.status                                            status
  , d.tablespace_name                                   name
  , d.contents                                          type
  , d.extent_management                                 extent_mgt
  , d.segment_space_management                          segment_mgt
  , NVL(a.bytes, 0)                                     ts_size
  , NVL(a.bytes - NVL(f.bytes, 0), 0)                   used
  -- , NVL(f.bytes, 0)                                     free
  , NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0) pct_used
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_data_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes) bytes
      from dba_free_space
      group by tablespace_name
    ) f
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = f.tablespace_name(+)
  AND NOT (
    d.extent_management like 'LOCAL'
    AND
    d.contents like 'TEMPORARY'
  )
UNION ALL
SELECT
    d.status                         status
  , d.tablespace_name                name
  , d.contents                       type
  , d.extent_management              extent_mgt
  , d.segment_space_management       segment_mgt
  , NVL(a.bytes, 0)                  ts_size
  , NVL(t.bytes, 0)                  used
  -- , NVL(a.bytes - NVL(t.bytes,0), 0) free
  , NVL(t.bytes / a.bytes * 100, 0)  pct_used
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_temp_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes_cached) bytes
      from v\$temp_extent_pool
      group by tablespace_name
    ) t
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
ORDER BY 2
/
EOF
#tput clear
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################tablespace mb #####################################################3
elif [ "$CHOICE" = "2"  ]

then

rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : Tablespaces                                                 |
PROMPT | Instance : '&current_instance'                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN status      FORMAT a9                 HEADING 'Status'
COLUMN name        FORMAT a30                HEADING 'Tablespace Name'
COLUMN type        FORMAT a15                HEADING 'TS Type'
COLUMN extent_mgt  FORMAT a10                HEADING 'Ext. Mgt.'
COLUMN segment_mgt FORMAT a10                HEADING 'Seg. Mgt.'
COLUMN ts_size     FORMAT 9,999,999,999,999.99  HEADING 'Tablespace Size'
COLUMN used        FORMAT 9,999,999,999,999.99  HEADING 'Used (in bytes)'
COLUMN free        FORMAT 9,999,999,999,999.99  HEADING 'Free (in bytes)'
COLUMN pct_used    FORMAT 999.99                HEADING 'Pct. Used'


BREAK ON report

COMPUTE sum OF ts_size  ON report
COMPUTE sum OF used     ON report
COMPUTE sum OF free     ON report
COMPUTE avg OF pct_used ON report
SELECT
    d.status                                            status
  , d.tablespace_name                                   name
  , d.contents                                          type
  , d.extent_management                                 extent_mgt
  , d.segment_space_management                          segment_mgt
  , NVL(a.bytes/1024/1024, 0)                                     ts_size
  , NVL(a.bytes/1024/1024 - NVL(f.bytes/1024/1024, 0), 0)                   used
  -- , NVL(f.bytes, 0)                                     free
  , NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0) pct_used
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_data_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes) bytes
      from dba_free_space
      group by tablespace_name
    ) f
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = f.tablespace_name(+)
  AND NOT (
    d.extent_management like 'LOCAL'
    AND
    d.contents like 'TEMPORARY'
  )
UNION ALL
SELECT
    d.status                         status
  , d.tablespace_name                name
  , d.contents                       type
  , d.extent_management              extent_mgt
  , d.segment_space_management       segment_mgt
  , NVL(a.bytes/1024/1024, 0)                  ts_size
  , NVL(t.bytes/1024/1024, 0)                  used
  -- , NVL(a.bytes/1024/1024 - NVL(t.bytes,0), 0) free
  , NVL(t.bytes / a.bytes * 100, 0)  pct_used
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_temp_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes_cached) bytes
      from v\$temp_extent_pool
      group by tablespace_name
    ) t
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
ORDER BY
  2
/

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################tablespace GB #####################################################3
 
elif [ "$CHOICE" = "3"  ]

then

rep=""
      while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : Tablespaces                                                 |
PROMPT | Instance : '&current_instance'                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN status      FORMAT a9                 HEADING 'Status'
COLUMN name        FORMAT a30                HEADING 'Tablespace Name'
COLUMN type        FORMAT a15                HEADING 'TS Type'
COLUMN extent_mgt  FORMAT a10                HEADING 'Ext. Mgt.'
COLUMN segment_mgt FORMAT a10                HEADING 'Seg. Mgt.'
COLUMN ts_size     FORMAT 9,999,999,999,999.99  HEADING 'Tablespace Size'
COLUMN used        FORMAT 9,999,999,999,999.99  HEADING 'Used (in bytes)'
COLUMN free        FORMAT 9,999,999,999,999.99  HEADING 'Free (in bytes)'
COLUMN pct_used    FORMAT 999.99                HEADING 'Pct. Used'

BREAK ON report

COMPUTE sum OF ts_size  ON report
COMPUTE sum OF used     ON report
COMPUTE sum OF free     ON report
COMPUTE avg OF pct_used ON report
SELECT
    d.status                                            status
  , d.tablespace_name                                   name
  , d.contents                                          type
  , d.extent_management                                 extent_mgt
  , d.segment_space_management                          segment_mgt
  , NVL(a.bytes/1024/1024/1024, 0)                                     ts_size
  , NVL(a.bytes/1024/1024/1024 - NVL(f.bytes/1024/1024/1024, 0), 0)                   used
  -- , NVL(f.bytes, 0)                                     free
  , NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0) pct_used
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_data_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes) bytes
      from dba_free_space
      group by tablespace_name
    ) f
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = f.tablespace_name(+)
  AND NOT (
    d.extent_management like 'LOCAL'
    AND
    d.contents like 'TEMPORARY'
  )
UNION ALL
SELECT
    d.status                         status
  , d.tablespace_name                name
  , d.contents                       type
  , d.extent_management              extent_mgt
  , d.segment_space_management       segment_mgt
  , NVL(a.bytes/1024/1024/1024, 0)                  ts_size
  , NVL(t.bytes/1024/1024/1024, 0)                  used
  -- , NVL(a.bytes/1024/1024 - NVL(t.bytes,0), 0) free
  , NVL(t.bytes / a.bytes * 100, 0)  pct_used
FROM
    sys.dba_tablespaces d
  , ( select tablespace_name, sum(bytes) bytes
      from dba_temp_files
      group by tablespace_name
    ) a
  , ( select tablespace_name, sum(bytes_cached) bytes
      from v\$temp_extent_pool
      group by tablespace_name
    ) t
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
ORDER BY
  2
/

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done 
########################################tablespace to owner #####################################################3

elif [ "$CHOICE" = "4"  ]

then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : Tablespace to Owner                                         |
PROMPT | Instance : '&current_instance'                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN tablespace_name FORMAT a30                  HEADING "Tablespace Name"
COLUMN owner           FORMAT a20                  HEADING "Owner"
COLUMN segment_type    FORMAT a20                  HEADING "Segment Type"
COLUMN bytes           FORMAT 9,999,999,999,999.99    HEADING "Size (in MB)"
COLUMN seg_count       FORMAT 9,999,999,999.99        HEADING "Segment Count"

BREAK ON report ON tablespace_name SKIP 2

COMPUTE sum LABEL ""                OF seg_count bytes ON tablespace_name
COMPUTE sum LABEL "Grand Total: "   OF seg_count bytes ON report

SELECT
    tablespace_name
  , owner
  , segment_type
  , sum(bytes/1024/1024)  MB
  , count(*)    seg_count
FROM
    dba_segments
GROUP BY
    tablespace_name
  , owner
  , segment_type
ORDER BY
    tablespace_name
  , owner
  , segment_type
/

EOF



echo "Continue? ("q" to return to main menu)"
read rep
done
 
########################################all datafiles mb #####################################################3
elif [ "$CHOICE" = "5"  ]

then

rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : File Usage                                                  |
PROMPT | Instance : '&current_instance'                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    256
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN tablespace  FORMAT a18                 HEADING 'Tablespace Name'
COLUMN filename    FORMAT a75                 HEADING 'Filename'
COLUMN filesize    FORMAT 9,999,999,999,999.99   HEADING 'File Size'
COLUMN used        FORMAT 9,999,999,999,999.99   HEADING 'Used (in MB)'
COLUMN pct_used    FORMAT 999.99                 HEADING 'Pct. Used'

BREAK ON report

COMPUTE sum OF filesize  ON report
COMPUTE sum OF used      ON report
COMPUTE avg OF pct_used  ON report

SELECT /*+ ordered */
    d.tablespace_name                     tablespace
  , d.file_name                           filename
  , d.file_id                             file_id
  , d.bytes/1024/1024                               filesize
  , NVL((d.bytes/1024/1024 - s.bytes/1024/1024), d.bytes/1024/1024)     used
  , TRUNC(((NVL((d.bytes - s.bytes) , d.bytes)) / d.bytes) * 100)  pct_used
FROM
    sys.dba_data_files d
  , v\$datafile v
  , ( select file_id, SUM(bytes/1024/1024) bytes
      from sys.dba_free_space
      GROUP BY file_id) s
WHERE
      (s.file_id (+)= d.file_id)
  AND (d.file_name = v.name)
UNION
SELECT
    d.tablespace_name                       tablespace 
  , d.file_name                             filename
  , d.file_id                               file_id
  , d.bytes/1024/1024                                 filesize
  , NVL(t.bytes_cached/1024/1024, 0)                  used
  , TRUNC((t.bytes_cached / d.bytes) * 100) pct_used
FROM
    sys.dba_temp_files d
  , v\$temp_extent_pool t
  , v\$tempfile v
WHERE 
      (t.file_id (+)= d.file_id)
  AND (d.file_id = v.file#)
/

EOF

echo "Continue? ("q" to return to main menu)"
read rep
done
 
########################################dba all files auto  mb #####################################################3
elif [ "$CHOICE" = "6"  ]

then 
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : Data File Report (all physical files)                       |
PROMPT | Instance : '&current_instance'                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN tablespace      FORMAT a25                 HEADING 'Tablespace Name / File Class'
COLUMN filename        FORMAT a75                 HEADING 'Filename'
COLUMN filesize        FORMAT 9,999,999,999,999.99   HEADING 'File Size'
COLUMN autoextensible  FORMAT a3                  HEADING 'Auto'
COLUMN increment_by    FORMAT 999,999,999,999.99     HEADING 'Next'
COLUMN maxbytes        FORMAT 999,999,999.99     HEADING 'Max'

BREAK ON report

COMPUTE sum OF filesize  ON report

SELECT /*+ ordered */
    d.tablespace_name                     tablespace
  , d.file_name                           filename
  , d.bytes/1024/1024                               filesize
  , d.autoextensible                      autoextensible
  , d.increment_by/1024 *(e.value/1024)              increment_by
  , d.maxbytes/1024/1024                            maxbytes
FROM
    sys.dba_data_files d
  , v\$datafile v
  , (SELECT value
     FROM v\$parameter
     WHERE name = 'db_block_size') e
WHERE
  (d.file_name = v.name)
UNION
SELECT
    d.tablespace_name                     tablespace
  , d.file_name                           filename
  , d.bytes/1024/1024                               filesize
  , d.autoextensible                      autoextensible
  , d.increment_by/1024 * (e.value/1024)              increment_by
  , d.maxbytes/1024/1024                            maxbytes
FROM
    sys.dba_temp_files d
  , (SELECT value
     FROM v\$parameter
     WHERE name = 'db_block_size') e
UNION
SELECT
    '[ ONLINE REDO LOG ]'
  , a.member
  , b.bytes/1024/1024
  , null
  , TO_NUMBER(null)
  , TO_NUMBER(null)
FROM
    v\$logfile a
  , v\$log b
WHERE
    a.group# = b.group#
UNION
SELECT
    '[ CONTROL FILE    ]'
  , a.name
  , TO_NUMBER(null)
  , null
  , TO_NUMBER(null)
  , TO_NUMBER(null)
FROM
    v\$controlfile a
ORDER BY 1,2
/


EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################dba all files with archive log #####################################################3
elif [ "$CHOICE" = "7"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : File Usage                                                  |
PROMPT | Instance : '&current_instance'                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN db NEW_VALUE xdb NOPRINT FORMAT a1

COLUMN type        FORMAT a8                 HEADING 'Type'
COLUMN tablespace  FORMAT a30                HEADING 'Tablspace'
COLUMN filename    FORMAT a75                HEADING 'Filename'
COLUMN filesize    FORMAT 9,999,999,999,999  HEADING 'File Size'
COLUMN stat        FORMAT a10                HEADING 'Status'
COLUMN seq         FORMAT 9999999            HEADING 'Sequence'
COLUMN arc         FORMAT a4                 HEADING 'Archived'

SET TERMOUT OFF
SELECT name db
FROM   v\$database;
SET TERMOUT ON

SELECT
    'Data'                        type
  , tablespace_name               tablespace
  , REPLACE(file_name,'?','&xdb') filename
  , bytes/1024/1024                         filesize
  , DECODE(status,'AVAILABLE','Available','INVALID','Invalid','****') stat
  , 0                              seq
  , ''                             arc
FROM dba_data_files
UNION
SELECT
    'Redo'
  , 'Grp ' || a.group#
  , member
  , bytes/1024/1024
  , DECODE(b.status,'CURRENT','Current','INACTIVE','Inactive','UNUSED','Unused','****')
  , sequence#
  , archived
FROM
    v\$logfile  a
  , v\$log      b
WHERE
    a.group# = b.group#
UNION
SELECT
    'Parm'
  , 'Ctrl 1'
  , REPLACE(NVL(LTRIM(SUBSTR(value,1,instr(value||',',',',1,1)-1)),'  (none)'),
   '?','&xdb') file_name
  , 0
  , ''
  , 0
  , ''
FROM
    v\$parameter
WHERE
    name = 'control_files'
UNION
SELECT
    'Parm'
  , 'Ctrl 2'
  , REPLACE(nvl(ltrim(substr(value,instr(value||',',',',1,1)+1,
    instr(value||',',',',1,2)-instr(value||',',',',1,1)-1)),'  (none)'),
    '?' ,'&xdb') file_name
  , 0
  , ''
  , 0
  , ''
FROM
    v\$parameter
WHERE
    name = 'control_files'
UNION
SELECT
    'Parm'
  , 'Ctrl 3'
  , REPLACE(nvl(ltrim(substr(value,instr(value||',',',',1,2)+1,
    instr(value||',',',',1,3)-instr(value||',',',',1,2)-1)),'  (none)'),
    '?','&xdb') file_name
  , 0
  , ''
  , 0
  , ''
FROM
    v\$parameter
WHERE
    name = 'control_files'
UNION
SELECT
    'Parm'
  , 'Ctrl 4'
  , REPLACE(nvl(ltrim(substr(value,instr(value||',',',',1,3)+1,
    instr(value||',',',',1,4)-instr(value||',',',',1,3)-1)),'  (none)'),
    '?','&xdb') file_name
  , 0
  , ''
  , 0
  , ''
FROM
    v\$parameter
WHERE
    name = 'control_files'
UNION
SELECT
    'Parm'
  , 'Ifile'
  , REPLACE(value,'?','&xdb') file_name
  , 0
  , ''
  , 0
  , ''
FROM
    v\$parameter
WHERE
    name = 'ifile'
UNION
SELECT
    'Parm'
  , 'Archive'
  , DECODE(d.log_mode, 'ARCHIVELOG',
                       REPLACE(p.value,'?','&xdb') || ' - ENABLED',
                       REPLACE(p.value,'?','&xdb') || ' - Disabled') file_name
  , 0
  , ''
  , 0
  , ''
FROM
    v\$parameter p
  , v\$database  d
WHERE
    p.name = 'log_archive_dest'
UNION
SELECT 
    'Tempfile' type
  , tablespace_name
  , REPLACE(file_name,'?','$input{Oracle_SID_Name}') tempfile_name
  , bytes/1024/1024
  , DECODE(status,'AVAILABLE','Available','INVALID','Invalid','****') stat
  , 0
  , ''
FROM dba_temp_files
ORDER BY 1,2,3
/



EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
  
 
 
 
 
 
 
 
 
 
 
#####################################################################################
 else
               echo " thanks you "
        fi


done
}




unix_menu( )

{



MC=`uname -a|awk '{print $2}'|tr 'a-z' 'A-Z'`
MENU_NAME=${MENU_NAME:-"DBA Menu - $MC"}  
if [ -f /var/opt/oracle/oratab ]
then
        ORATAB=/var/opt/oracle/oratab; export ORATAB
elif [ -f /etc/oratab ]
then
        ORATAB=/etc/oratab; export ORATAB
else
        echo -e "Could not find oratab...quiting..."
        exit 1
fi              
#Get the list of databases
SID_LIST=`grep -v '^#' $ORATAB|awk -F':' '{print $1}'`
SID_COUNT=`echo -e $SID_LIST|wc -w`
SID_COUNT=`echo -e $SID_COUNT` 
L_Passwd=`awk '{print $0}' $SCRPT/monitor_passwd`
SCRPT=$ORACLE_BASE/scripts;export SCRPT
get_oratab_value()
{
        A=`grep -i "^"$1" *:" $ORATAB|awk -F':' '{print $'$2'}'`
        echo -e "$A\c"
}                                                      
oracle_home()
{
rep=""
while [ "$rep" != "q" ]
do
tput clear
echo -e '$ORACLE_HOME Locations:\n'
echo -e
echo -e "`cat $ORATAB | grep -v '^#'| awk -F: '{ print $2 }'|sort -u`"
echo -e                                                                
echo -e
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
machine_activity()
{
rep=""
while [ "$rep" != "q" ]
do
tput clear
up=`uptime |awk -F',' '{print $1}'`
load1=`uptime |awk -F',' '{print $4}'`
load2=`uptime |awk -F',' '{print $5}'`
load3=`uptime |awk -F',' '{print $6}'`        
echo -e  "\t\tMachine Load Statistics as on" $up
echo -e
echo -e "$load1 (last 1 minute), $load2 (last 5 minutes), $load3 (last 15 minutes)"
echo -e                                                                           
echo -e "Number Of Oracle Instances Running : `ps -ef |grep ora_pmon|grep -v grep|wc -l`"
echo -e
echo -e "Number of connected Oracle sessions (Dedicated):`ps -ef |grep -v ora_|grep LOCAL |wc -l`"
sleep 2
echo -e
echo -e Running vmstat command .....please wait 
sleep 5
echo -e 
vmstat 2 5
echo -e
echo -e Running the TOP command .....please wait
echo -e
top -b -n 1 > /tmp/top.out
cat /tmp/top.out |head -15
echo -e
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
machine ()
{
rep=""
while [ "$rep" != "q" ]
do
tput clear
echo -e "******************************************************************"
echo -e " Information for UNIX node : `hostname`"
echo -e "*****************************************************************"
echo -e
CPU=`grep "physical id"  /proc/cpuinfo |sort -u|wc -l`
MEM=`cat /proc/meminfo |grep MemTotal`
up=`uptime |awk -F',' '{print $1}'`
load1=`uptime |awk -F',' '{print $4}'`
load2=`uptime |awk -F',' '{print $5}'`
load3=`uptime |awk -F',' '{print $6}'`
last_reboot=`who -b`
echo -e "Machine Type: \n"
uname -a
echo -e
echo -e "Number of CPU's: \n"  
grep "physical id"  /proc/cpuinfo |sort -u|wc -l
echo -e
echo -e "RAM Available:\n"    
cat /proc/meminfo |grep MemTotal
echo -e
echo -e "Swap Space and Memory Usage: \n"
free -m   
echo -e                                         
echo -e "Last Reboot Time : \n"
who -b
#cat menu.log
echo -e
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

Yy()  # For reading y/n
{
        read ANS
        if [ "$ANS" = "Y" -o "$ANS" = "y" ]
        then
                echo -e y
        fi
}               
get_sga_dtl()
{
tput clear
echo -e "Querying each database on $MC .... Please wait\n"
echo -e > user1.log
for i in $SID_LIST
    do
   . $SCRPT/set$i 
    sqlplus -s -s monitor/watch1ng <<EOF >menu.log
       set head off
       set pagesize 5000
         select sum(round(value/1048576)) from v\$sga;   
EOF
    awk '{ sum += $1} END {printf  "Total SGA of %-7s is %6d \n","'$i'",sum}' menu.log >> user1.log

done
echo -e "**************************************************">>user1.log
tput clear
    cat user1.log |more 
    awk '{sum += $6} END {print "Total SGA Size (all databases) is "sum"MB"}' user1.log
}                 
check_disk_space()
{
rep=''
while [ "$rep" != "q" ]
do
tput clear
df -hP |grep -v var| awk '{  printf "%-5s %-10s %20s\n",  $5,$4,$6}' |tr -s '%' ' ' | awk '{if ($1 >= 90) printf "%5s%% %10s %20s\n", $1,$2,$3 } ' | sort -r >menu.log
cat menu.log |more
echo -e
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                   
check_free_space()
{
rep=''
while [ "$rep" != "q" ]
do
tput clear
df -hP |grep -v var|  awk '{  printf "%-20s %-10s %-10s %-10s %10s\n",  $6,$2,$3,$4,$5}' > menu.log
cat menu.log |more
echo -e
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_waits_segment()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log 
col sid format 99999
col event format a25
col p1text format a10
col p2text format a10
col p3text format a10
set pagesize 500
set linesize 500
select sid, event, p1text, p1, p2text , p2 
from  v\$session_wait
where
sid between 10 and 1000
and event not like 'SQL*Net%'
and event not like '%rdbms%'
;
EOF
cat menu.log |more
}
get_waits_segment_dtl()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log
col sid format 99999
col event format a25
col p1text format a10
col p2text format a10
col p3text format a10
set pagesize 500
set linesize 500
select sid, event, p1text, p1, p2text , p2
from  v\$session_wait
where
sid between 10 and 1000
and event  like 'db%'
;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]                
then
cat menu.log |more                        
echo -e
echo -e "Please Enter The Datafile#  (P1): \c"
read df
echo -e 
echo -e "Please Enter The Block Number (P2):  \c"
read block
echo -e
$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log 
set pagesize 500
set linesize 500
col owner format a20
col segment_type format a20
col segment_name format a30
col tablespace_name format a20
select owner, segment_name, segment_type, tablespace_name
from dba_extents
where file_id =$df
and $block  between block_id and block_id + blocks -1
/
EOF
cat menu.log |more 
fi
}
get_waits_io()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log    
SELECT s.sql_hash_value
  FROM V\$SESSION s, V\$SESSION_WAIT w
 WHERE w.event  in  ('db file scattered read','db file sequential read')
   AND w.sid = s.sid ;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]
then
cat menu.log |more
echo -e
echo -e "Please Enter The Hash Value#: \c"
read hash                               
$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log
select sql_text from v\$sqlarea where hash_value=$hash;
EOF
cat menu.log|more
fi
}
get_waits_session()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log   
col username format a15
col sid format 99999
col program format a30
col state format a15
col event format a25
col wait_time format 99999999
set pagesize 800
set linesize 800
select s.sid, s.username, s.program, se.event, se.state, se.wait_time
from v\$session s, v\$session_wait se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and se.event not like '%rdbms%'
and s.username is not null
order by se.wait_time;
EOF
cat menu.log |more 
}
get_waits_session_dtl()
{
echo -e 
echo -e "\t\t\tSession wait details ......."
echo -e "*************************************************************************"
$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log
col username format a15
col sid format 99999
col program format a30
col event format a25
col status format a10
col total_waits format 99999999
set pagesize 500
set linesize 500
select s.username, s.sid, se.event, se.total_waits
from v\$session s, v\$session_event se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and s.username is not null
and s.status='ACTIVE'
order by se.total_waits
/
EOF
cat menu.log |more 
}
get_waits_instance()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log
set pagesize 800
set linesize 800
col event format a30
select  event, total_waits, total_timeouts, time_waited
from v\$system_event
where event not like 'SQL*Net%'
order by total_waits;
EOF
cat menu.log |head -2
cat menu.log |tail -10

$ORACLE_HOME/bin/sqlplus -s -s monitor/monitor <<EOF >menu.log
Prompt 
Prompt "Class Of Waits Since Instance Startup"
prompt
select class,count from v\$waitstat order by count;
EOF
cat menu.log|more
}

setsid()
{
        if [ $# = 0 ]
        then
                return
        fi
        ORACLE_SID=$1; export ORACLE_SID
        ORACLE_HOME=`get_oratab_value $1 2`; export ORACLE_HOME
}                           
fn2()
{
tput clear
            check_disk_space 
}
fn1()
{
machine
}
fn3()
{
tput clear
check_free_space
}
fn4()
{
tput clear
machine_activity
}
fn5()
{
tput clear
oracle_home
}
fn6()
{
dba_assist.sh
}

fn7()
{
dba_menu.sh
}
###The choice loop
while [ 1 ]        
do
        tput clear
# echo -e "\n\n\n\t\t\t RECOVERY MANAGER MENU"

        echo -e "\n\n\t\tUNIX Node Information Menu - $MC"
	echo -e "\\t==================================================="
echo -e
	echo -e 
	echo -e "\t(1) General Machine Information"
	echo -e "\t(2) Mount Points > 90% Full "
	echo -e "\t(3) Mount Points Free Space"
	echo -e "\t(4) Monitor Machine Activity"
	echo -e "\t(5) ORACLE_HOME's On This Machine"
	echo -e ""
 	echo -e "\tEnter your choice (q to quit): \c"
 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
				main 
				#exit [ 0 ]
		else 		
        
        case $CHOICE in
                1) tput clear;machine ;;
                2) tput clear;check_disk_space ;;
                3) tput clear;check_free_space ;;
                4) tput clear;machine_activity ;;
                5) tput clear;oracle_home ;;
		6) get_sga_dtl;;
        esac
        if [ "$CHOICE2" = "q" -o "$CHOICE2" = "Q"  -o "$CHOICE2" = "END" ]
        then
                continue
        fi
#        echo -e "Hit return to continue\c"
#        #line                          
fi
done    
                                    



}



perfomance( )

{

MC=`uname -a|awk '{print $2}'|tr 'a-z' 'A-Z'`
MENU_NAME=${MENU_NAME:-"DBA Menu - $MC"}  
if [ -f /var/opt/oracle/oratab ]
then
        ORATAB=/var/opt/oracle/oratab; export ORATAB
elif [ -f /etc/oratab ]
then
        ORATAB=/etc/oratab; export ORATAB
else
        echo -e "Could not find oratab...quiting..."
        exit 1
fi              
#Get the list of databases
SID_LIST=`grep -v '^#' $ORATAB|awk -F':' '{print $1}'`
SID_COUNT=`echo -e $SID_LIST|wc -w`
SID_COUNT=`echo -e $SID_COUNT` 
L_Passwd=`awk '{print $0}' monitor_passwd`
get_tns_connect()
{
choice=""
until [ -n  "$choice" ]
do
echo -e "Please Enter The TNS Connect String "
read tns
awk '{
   if ($2 == "=" && $1 !~ /^\(/) print $1
   else
   if ($1 ~ /\=/ && $1 !~ /^\(/) {
        strng = substr($1,1,length($1)-1)
        print strng
        }
   }' $ORACLE_HOME/network/admin/tnsnames.ora |grep -iw $tns >/dev/null 
if [ $? -eq 0 ]
then
echo -e "Connecting to Database $tns ...."
choice=TRUE
else echo -e "Wrong TNS connect string"
fi
done
}
get_waits_segment_dtl()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba '<<EOF >menu.log
set linesize 120
SELECT count(*) NUM_WAITERS, p1 FILE#, p2 BLK#, p3 CLASS
FROM v\$session_wait
WHERE event = 'buffer busy waits'
GROUP BY p1, p2, p3
;
EOF
cat menu.log
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}



get_waits_segment()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba '<<EOF >menu.log
set pagesize 500
set linesize 200
col file_name format a40
col tablespace_name format a10
col event format a25
col sid format 9999
select sid, event,file_name,tablespace_name
from  v\$session_wait a, dba_data_files b
where
a.p1=b.file_id
and
sid between 10 and 1000
and event  like 'db%'
;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]
then
cat menu.log |more
fi
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                 
get_whats_on()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
SELECT count(*), event FROM v\$session_wait
WHERE wait_time = 0 
AND event NOT IN
('smon timer','pmon timer','rdbms ipc message',  				'SQL*Net message from client') 
GROUP BY event ORDER BY 1 DESC
;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_waits_seq_read()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
col username format a12
col sid format 9999
col state format a15
col event format a45
col wait_time format 99999999
set pagesize 800
set linesize 800
select s.sid, s.username, se.event
from v\$session s, v\$session_wait se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and se.event not like '%rdbms%'
and s.username is not null
order by 3;
EOF
more menu.log |more
echo -e "Please Enter The User Session's SID "
read SID
if test  -n "$SID" 
then
sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500
PROMPT=============================================================
PROMPT Current SQL statement this session executes
PROMPT=============================================================
col sql_text for a70 hea "Current SQL"
select q.sql_text
from v\$session s
,    v\$sql     q
WHERE s.sql_address = q.address
and   s.sql_hash_value + DECODE
                 (SIGN(s.sql_hash_value), -1, POWER( 2, 32), 0) = q.hash_value
AND   s.sid=$SID;
EOF
cat menu.log |more
fi
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_waits_by_class()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s  ' / as sysdba ' <<EOF > version.log
set heading off
set feedback off
select version from v\$instance;
EOF
cat version.log |grep -w "9.2"  > /dev/null
if test $? -eq 1
    then
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set linesize 120
col wait_class format a30
select  wait_class_id,wait_class,
   sum(total_waits), sum(time_waited)
from v\$session_wait_class
where wait_class !='Idle'
group by wait_class_id,wait_class
order by 4;
EOF
more menu.log |more
echo -e "Please Enter the Wait Class ID "
read waitid
if test  -n "$waitid"
then
sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set linesize 120
set pagesize 100
PROMPT
PROMPT Wait Class Event Details 
PROMPT
select event, total_waits, time_waited
from v\$system_event e, v\$event_name n
where n.event_id = e.event_id
and n.wait_class_id =$waitid
order by 3;
EOF
cat menu.log |more
fi
else echo -e "This Option Is Not Available For An Oracle 9i Database"
fi
echo -e ""
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}


get_waits_instance()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set pagesize 800
set linesize 800
col event format a30
select  event, total_waits, total_timeouts, time_waited
from v\$system_event
where event not like 'SQL*Net%'
order by total_waits;
EOF
cat menu.log |head -2
cat menu.log |tail -10
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                            
get_top5_latch_sleep ()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set pagesize 800
set linesize 800
col name format a30
select * from
 (select name, gets,misses,  sleeps
 from   v\$latch
 order by sleeps desc)
 where rownum < 11;
EOF
cat menu.log
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}


get_top5_latch_miss ()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set pagesize 800
set linesize 800
col name format a20
select * from
 (select name, gets,misses, immediate_gets,Immediate_misses
 from   v\$latch
 order by misses desc )
 where rownum < 11;
EOF
cat menu.log
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_waits_instance_time()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set pagesize 800
set linesize 120
col event format a40
col time_waited format 9999999999999999
select * from (select  event, total_waits, total_timeouts, time_waited
from v\$system_event
where event not like 'SQL*Net%'
order by time_waited desc) where rownum < 6;
EOF
tput clear
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_wait_class()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Checking Classes Of Waits Since Instance Startup ....."
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set pagesize 200
set linesize 132
Prompt
prompt
select class,count from v\$waitstat order by count;
EOF
cat menu.log|more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_waits_session()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
col username format a12
col sid format 9999
col state format a15
col event format a25
col wait_time format 99999999
set pagesize 800
set linesize 800
select s.sid, s.username, se.event, se.state, se.wait_time
from v\$session s, v\$session_wait se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and se.event not like '%rdbms%'
and s.username is not null
order by se.wait_time;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                           
get_waits_session_dtl()
{
echo -e
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
col username format a12
col sid format 9999
col event format a25
col status format a10
col total_waits format 99999999
set pagesize 500
set linesize 500
select s.username, s.sid, se.event, se.total_waits
from v\$session s, v\$session_event se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and s.username is not null
and s.status='ACTIVE'
order by se.total_waits
/                                  
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}        

get_waits_io ()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
SELECT s.sql_hash_value
  FROM V\$SESSION s, V\$SESSION_WAIT w
 WHERE w.event  in  ('db file scattered read','db file sequential read')
   AND w.sid = s.sid ;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]
then
cat menu.log |more
echo -e
echo -e "Please Enter The Hash Value#: \c"
read hash
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
select sql_text from v\$sqlarea where hash_value=$hash;
EOF
cat menu.log|more
fi
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_top_cpu_users()
{
echo -e "\t\t\t\tTop 10 CPU Users"
echo -e "***********************************************************************"
echo -e
uname -a |grep SUN > /dev/null
                if [ $? = 0 ]
                then
/usr/ucb/ps aux |head -10
else
ps aux |head -10
fi
echo -e "***********************************************************************"
echo -e
}              
get_top_sql_user()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The UNIX Process ID"
read SPID
sqlplus -s  ' / as sysdba ' <<EOF >menu.log
set pagesize 50000
set linesize 30000
set long 500000
set head off
select
       s.username su,
       substr(sa.sql_text,1,540) txt
from v\$process p,
     v\$session s,
     v\$sqlarea sa
where    p.addr=s.paddr
and      s.username is not null
and      s.sql_address=sa.address(+)
and      s.sql_hash_value=sa.hash_value(+)
and spid=$SPID;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                       
get_oratab_value()
{
        A=`grep -i "^"$1" *:" $ORATAB|awk -F':' '{print $'$2'}'`
        echo -e "$A\c"
}                                                      
oracle_home()
{
echo -e '$ORACLE_HOME Locations:\n'
echo -e
echo -e "`cat $ORATAB | awk -F: '{ print $2 }'|sort -u`"
echo -e                                                                
}

Yy()  # For reading y/n
{
        read ANS
        if [ "$ANS" = "Y" -o "$ANS" = "y" ]
        then
                echo -e y
        fi
}               

get_cached_blks()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log  
set pagesize 200
set linesize 200
col name format a45
col file# format 999999
col count(b.block#) heading "Blocks"
select f.name,f.file#,count(b.block#)
from v\$bh b, v\$dbfile f
where b.file#=f.file#
group by f.name, f.file#
order by 3;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_hit_ratios()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log           
Prompt This Script Will Give An Overview Of The System ....

prompt****************************************************
prompt Database Information
prompt****************************************************
prompt 
select name,log_mode  from v\$database;

Prompt Version Information ....
prompt
set head off
select banner  from v\$version;
set head on


Prompt SGA Information...
prompt
col sum(round(value/1048576)) heading "SGA Size (MB)"
 select sum(round(value/1048576)) from v\$sga;  


prompt****************************************************
prompt Hit Ratio Section 
prompt****************************************************
prompt 
prompt	========================= 
prompt	BUFFER HIT RATIO 
prompt	========================= 
prompt (should be > 90, else increase db_block_buffers in init.ora) 
 
col  "Consis Gets" format 999,999,999,999
col "Phys Reads" format 999,999,999,999,999
 SELECT 
   SUM(DECODE(name, 'consistent gets',value, 0))  "Consis Gets",
   SUM(DECODE(name, 'db block gets',value, 0))  "DB Blk Gets",
   SUM(DECODE(name, 'physical reads',value, 0))  "Phys Reads",
  (SUM(DECODE(name, 'consistent gets',value, 0))  
    + SUM(DECODE(name, 'db block gets',value, 0))  
    -  SUM(DECODE(name, 'physical reads',value, 0)))
						/
  (SUM(DECODE(name, 'consistent gets',value, 0)) 
     + SUM(DECODE(name, 'db block gets',value, 0))  )  * 100 "Hit Ratio" 
FROM v\$sysstat;
prompt 
prompt 
prompt	========================= 
prompt	DATA DICT HIT RATIO 
prompt	========================= 
prompt (should be higher than 90 else increase shared_pool_size in init.ora) 
prompt 
 
column "Data Dict. Gets"   format 999,999,999 
column "Data Dict. cache misses" format 999,999,999 
select sum(gets) "Data Dict. Gets", 
		sum(getmisses) "Data Dict. cache misses", 
	trunc((1-(sum(getmisses)/sum(gets)))*100) "DATA DICT CACHE HIT RATIO" 
from v\$rowcache; 

prompt 
prompt	========================= 
prompt	LIBRARY CACHE MISS RATIO 
prompt	========================= 
prompt (If > .1, i.e., more than 1% of the pins resulted in reloads, then increase the shared_pool_size in init.ora) 
prompt 
column "LIBRARY CACHE MISS RATIO" format 99.9999 
column "executions" format 999,999,999,999 
column "Cache misses while executing" format 999,999,999,999 
select sum(pins) "executions", sum(reloads) "Cache misses while executing", 
		(((sum(reloads)/sum(pins)))) "LIBRARY CACHE MISS RATIO" 
from v\$librarycache; 
 
prompt 
prompt	========================= 
prompt	Library Cache Section 
prompt	========================= 
prompt hit ratio should be > 85, and pin ratio > 90 ... 
prompt 
set pages 200
set lines 200
 
column "reloads" format 999,999,999 
select namespace, trunc(gethitratio * 100) "Hit ratio", 
trunc(pinhitratio * 100) "pin hit ratio", reloads "reloads" 
from v\$librarycache; 
prompt 
prompt 
prompt	========================= 
prompt	REDO LOG BUFFER 
prompt	========================= 
prompt 
set heading off 
column value format 999,999,999 
select substr(name,1,30), 
		value 
from v\$sysstat where name = 'redo log space requests'; 
 
set heading on 
prompt 
prompt 
prompt 
prompt 
prompt**************************************************** 
prompt Latch Section 
prompt**************************************************** 
prompt if miss_ratio or immediate_miss_ratio > 1 then latch 
prompt contention exists, decrease LOG_SMALL_ENTRY_MAX_SIZE in init.ora 
prompt 

set pages 200
set linesize 200
col substr(l.name,1,30) format a30
select substr(l.name,1,30) name, 
	(misses/(gets+.001))*100 "miss_ratio", 
	(immediate_misses/(immediate_gets+.001))*100 
		"immediate_miss_ratio" 
	from v\$latch l, v\$latchname ln 
	where l.latch# = ln.latch# 
	and ( 
	(misses/(gets+.001))*100 > .2 
or 
	(immediate_misses/(immediate_gets+.001))*100 > .2 
) 
order by l.name; 
 
prompt 
prompt 
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_shared_pool_objects()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log   
set pagesize 500
set linesize 500
column owner format a12
column name  format a40
column sharable_mem format 999,999,999
column executions   format 999,999,999
col kept format a8 heading "Pinned"
prompt  ' Memory Usage of Shared Pool - Biggest First' 
prompt
select  owner, name||' - '||type name, sharable_mem ,kept
  from v\$db_object_cache
 where sharable_mem > 10000
   and type in ('PACKAGE', 'PACKAGE BODY', 'FUNCTION', 'PROCEDURE')
order by sharable_mem desc;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_top5_disk_reads()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "\n\tTop 5 SQL Statements (disk reads) for database $tns" >menu.log
echo -e "\n" >>menu.log
sqlplus -s  ' / as sysdba ' <<EOF >>menu.log
alter session set sort_area_size=10485760;
set serverout on size 1000000
set feedback off
declare
top5 number;
text1 varchar2(4000);
x number;
len1 number;
Cursor c1 is
select disk_reads,substr(sql_text,1,4000)
from v\$sqlarea
order by disk_reads desc;
begin
dbms_output.put_line('Reads'||'  '||'                          Text');
dbms_output.put_line ('-----'||'  '||'--------------------------------------------------------------------');
dbms_output.put_line('      ');
open c1;
for i in 1 .. 5 loop
fetch c1 into top5, text1;
dbms_output.put_line(rpad(to_char(top5),9)|| ' '||substr(text1,1,66));
len1 :=length(text1);
x := 66;
while len1 > x-1 loop
dbms_output.put_line('"         '||substr(text1,x,64));
x := x+64;
end loop;
end loop;
end;
/
EOF
tput clear
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                  
get_top5_disk_reads_executions()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "\n\tTop 5 SQL Statements (disk reads per execution) for database $tns" >menu.log
echo -e "\n" >>menu.log
sqlplus -s  ' / as sysdba ' <<EOF >>menu.log
set serverout on size 1000000
set feedback off
declare
top5 number;
text1 varchar2(4000);
x number;
len1 number;
Cursor c1 is
select decode(executions,0,1,round(disk_reads/executions)),substr(sql_text,1,4000)
from v\$sqlarea
order by 1 desc;
begin
dbms_output.put_line('Reads/Exec'||'  '||'                          Text');
dbms_output.put_line ('---------'||'  '||'--------------------------------------------------------------------');
dbms_output.put_line('      ');
open c1;
for i in 1 .. 5 loop
fetch c1 into top5, text1;
dbms_output.put_line(rpad(to_char(top5),9)|| ' '||substr(text1,1,66));
len1 :=length(text1);
x := 66;
while len1 > x-1 loop
dbms_output.put_line('"         '||substr(text1,x,64));
x := x+64;
end loop;
end loop;
end;
/
EOF
tput clear
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                  
get_top5_executions()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "\n\tTop 5 SQL Statements (Executions) for database $tns" >menu.log
echo -e "\n" >>menu.log
sqlplus -s  ' / as sysdba ' <<EOF >>menu.log
set serverout on size 1000000
set feedback off
declare
top5 number;
text1 varchar2(4000);
x number;
len1 number;
Cursor c1 is
select executions,substr(sql_text,1,4000)
from v\$sqlarea
order by executions desc;
begin
dbms_output.put_line('Executions'||'  '||'                          Text');
dbms_output.put_line ('---------'||'  '||'--------------------------------------------------------------------');
dbms_output.put_line('      ');
open c1;
for i in 1 .. 5 loop
fetch c1 into top5, text1;
dbms_output.put_line(rpad(to_char(top5),9)|| ' '||substr(text1,1,66));
len1 :=length(text1);
x := 66;
while len1 > x-1 loop
dbms_output.put_line('"         '||substr(text1,x,64));
x := x+64;
end loop;
end loop;
end;
/
EOF
tput clear
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_top5_buffer_gets()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "\n" >menu.log
echo -e "\n\tTop 5 SQL Statements (Buffer Gets) for database $tns" >>menu.log
echo -e "\n" >>menu.log
sqlplus -s  ' / as sysdba ' <<EOF >>menu.log
set serverout on size 1000000
set feedback off
declare
top5 number;
text1 varchar2(4000);
x number;
len1 number;
Cursor c1 is
select buffer_gets,substr(sql_text,1,4000)
from v\$sqlarea
order by buffer_gets desc;
begin                         
dbms_output.put_line('Reads'||'  '||'                          Text');
dbms_output.put_line ('-----'||'  '||'--------------------------------------------------------------------');
dbms_output.put_line('      ');
open c1;
for i in 1 .. 5 loop
fetch c1 into top5, text1;
dbms_output.put_line(rpad(to_char(top5),9)|| ' '||substr(text1,1,66));
len1 :=length(text1);
x := 66;
while len1 > x-1 loop
dbms_output.put_line('"         '||substr(text1,x,64));
x := x+64;
end loop;
end loop;
end;
/
EOF
tput clear
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                             
setsid()
{
        if [ $# = 0 ]
        then
                return
        fi
        ORACLE_SID=$1; export ORACLE_SID
        ORACLE_HOME=`get_oratab_value $1 2`; export ORACLE_HOME
}                           
get_latches()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
select count(*), name latchname from v\$session_wait, v\$latchname       
where event='latch free' and state='WAITING' and p2=latch#       
group by name order by 1 desc;  
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_locks()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
SELECT DECODE(request,0,'Holder: ','Waiter: ')||sid sess, 
         id1, id2, lmode, request, type
    FROM V\$LOCK
   WHERE (id1, id2, type) IN
             (SELECT id1, id2, type FROM V\$LOCK WHERE request>0)
   ORDER BY id1, request
  ;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_engueue_sess()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
SELECT sid,chr(to_char(bitand(p1,-16777216))/16777215)||
         chr(to_char(bitand(p1, 16711680))/65535) "Lock",
         to_char( bitand(p1, 65535) )    "Mode"
    FROM v\$session_wait
   WHERE event = 'enqueue'
  ;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_engueue_system()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
SELECT  eq_type "Lock", 
                   total_wait# "Waits",
	  cum_wait_time
    FROM V\$enqueue_stat 
    WHERE Total_wait# > 0
order by 2
  ;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_engueue_obj()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
select c.sid waiter_sid, a.object_name, a.object_type
from   dba_objects a, v\$session b, v\$session_wait c
where  (a.object_id = b.row_wait_obj# or
        a.data_object_id = b.row_wait_obj#)
and    b.sid       = c.sid
and chr(bitand(c.p1,-16777216)/16777215)|| chr(bitand(c.p1, 16711680)/65535) ='TX'
and    c.event     = 'enqueue';
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_cbo_param()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
col name format a40
col value format a30
set pagesize 50
select name,value from v\$parameter where name in 
('optimizer_features_enable','optimizer_index_caching','optimizer_index_cost_adj',
'optimizer_max_permutations','optimizer_mode','hash_area_size','hash_join_enabled',
'hash_multiblock_io_count','sort_area_size','sort_area_retained_size',
'db_file_multiblock_read_count','optimizer_search_limit','morea_aggregate_target','workarea_size_policy')
;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_analyzed_tab()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
column "ANALYZED ON" format a10
column owner format a20
set pagesize 100
select owner,to_CHAR(LAST_ANALYZED,'DD-MON-YY') "ANALYZED ON",
COUNT(*)
FROM DBA_TABLES WHERE OWNER NOT IN ('SYS','SYSTEM','PERFSTAT')
GROUP BY OWNER,to_CHAR(LAST_ANALYZED,'DD-MON-YY');
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_analyzed_ind()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
column "ANALYZED ON" format a10
column owner format a20
set pagesize 100
select owner,to_CHAR(LAST_ANALYZED,'DD-MON-YY') "ANALYZED ON",
COUNT(*)
FROM DBA_indexes WHERE OWNER NOT IN ('SYS','SYSTEM','PERFSTAT')
GROUP BY OWNER,to_CHAR(LAST_ANALYZED,'DD-MON-YY');
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_topsegment ()
{
rep=""
while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s  ' / as sysdba ' <<EOF >menu.log
col segment_name format a40
col owner format a10 
set linesize 120
set pagesize 20
select segment_name,object_type,total_physical_reads
 from ( select owner||'.'||object_name as segment_name,object_type,
value as total_physical_reads
from v\$segment_statistics
 where statistic_name in ('physical reads')
 order by total_physical_reads desc)
 where rownum <=10;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}


###The choice loop
while [ 1 ]        
do
        tput clear
  echo -e "\n"
	echo -e "\t"
	echo -e "\t#######################################################"
	echo -e "\t\t\tDatabase Performance Menu - `tput smso`$Yellow$tns`tput rmso`\t"
	echo -e "\t#######################################################"
	echo -e "\t"
	echo -e "\t(1)  Waits - Instance Level (by time waited)"
	echo -e "\t(2)  Waits - By Class "
	echo -e "\t(3)  Waits - Waiting Session's SQL"
	echo -e "\t(4)  Waits - What are users currently waiting on?"
	echo -e "\t(5)  Waits - Datafile Level"
	echo -e "\t(6)  Buffer Busy Waits" 
	echo -e "\t(7)  Locked Sessions" 
	echo -e "\t(8)  Large Objects In Shared Pool " 
	echo -e "\t(9)  Hit Ratios - Quick Check" 
	echo -e "\t(10) Top 5 Problem Queries (Disk Reads)" 
	echo -e "\t(11) Top 5 Problem Queries (Buffer Gets)" 
	echo -e "\t(12) Top 5 Problem Queries (Disk Reads/Executions)" 
	echo -e "\t(13) Top 5 Queries (Executions)" 
	echo -e "\t(14) Top 5 Latch Waits (by sleeps)" 
	echo -e "\t(15) Top 5 Latch Waits (by misses)" 
	echo -e "\t(16) Current Waits On Latches" 
	echo -e "\t(17) Enqueue Waits - By Session" 
	echo -e "\t(18) Enqueue Waits - By Database" 
	echo -e "\t(19) Enqueue Waits - By Object" 
	echo -e "\t(20) Key CBO init.ora Parameters" 
	echo -e "\t(21) Tables ANALYZE Status" 
	echo -e "\t(22) Indexes ANALYZE Status" 
	echo -e "\t(23) Top Segments with most I/O" 
	echo -e "\n"
        echo -e "\tEnter your choice (q to quit): \c             "   
	echo -e "\n"
        echo -e "\t#######################################################"
tput cup 32 40
 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
				main 
				#exit [ 0 ]
		else 	
        case $CHOICE in
                1) tput clear;get_waits_instance_time;;
                2) tput clear;get_waits_by_class;;
                3) tput clear;get_waits_seq_read ;;
                4) tput clear;get_whats_on ;;
                5) tput clear;get_waits_segment;;
                6) tput clear;get_waits_segment_dtl;;
		7) tput clear;get_locks;;
		8) tput clear;get_shared_pool_objects;;
		9) tput clear;get_hit_ratios;;
		10) tput clear;get_top5_disk_reads;;
		11) tput clear;get_top5_buffer_gets;;
		12) tput clear;get_top5_disk_reads_executions;;
		13) tput clear; get_top5_executions;;
		14) tput clear; get_top5_latch_sleep;;
		15) tput clear; get_top5_latch_miss;;
		16) tput clear; get_latches;;
		17) tput clear; get_engueue_sess;;
		18) tput clear; get_engueue_system;;
		19) tput clear; get_engueue_obj;;
		20) tput clear; get_cbo_param;;
		21) tput clear; get_analyzed_tab;;
		22) tput clear; get_analyzed_ind;;
		23) tput clear; get_topsegment;;
        esac
        if [ "$CHOICE2" = "q" -o "$CHOICE2" = "Q"  -o "$CHOICE2" = "END" ]
        then
                continue
        fi
#        echo -e "Hit return to continue\c"
#        #line                          
fi
done                            




}

dbmon( )
{

MC=`uname -a|awk '{print $2}'|tr 'a-z' 'A-Z'`
MENU_NAME=${MENU_NAME:-"DBA Menu - $MC"}  
if [ -f /var/opt/oracle/oratab ]
then
        ORATAB=/var/opt/oracle/oratab; export ORATAB
elif [ -f /etc/oratab ]
then
        ORATAB=/etc/oratab; export ORATAB
else
        echo -e "Could not find oratab...quiting..."
        exit 1
fi              
#Get the list of databases
SID_LIST=`grep -v '^#' $ORATAB|awk -F':' '{print $1}'`
SID_COUNT=`echo -e $SID_LIST|wc -w`
SID_COUNT=`echo -e $SID_COUNT` 
L_Passwd=`awk '{print $0}' monitor_passwd`
get_tns_connect()
{
choice=""
until [ -n  "$choice" ]
do
echo -e "Please Enter The TNS Connect String "
read tns
awk '{
   if ($2 == "=" && $1 !~ /^\(/) print $1
   else
   if ($1 ~ /\=/ && $1 !~ /^\(/) {
        strng = substr($1,1,length($1)-1)
        print strng
        }
   }' $ORACLE_HOME/network/admin/tnsnames.ora |grep -iw $tns >/dev/null 
if [ $? -eq 0 ]
then
echo -e "Connecting to Database $tns ...."
choice=TRUE
else echo -e "Wrong TNS connect string"
fi
done
}
get_locked_objects()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500
col session_id format 99999 heading 'SID'
col oracle_username format a16 heading 'Username'
col os_user_name format a16 heading 'OS User'
col object_name format a25 heading 'Object'
select a.object_name,b.session_id,b.oracle_username,b.os_user_name,b.locked_mode from v\$locked_object b,dba_objects a
where a.object_id=b.object_id
order by a.object_name;
EOF
cat menu.log |more                    
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_sid_sql()
{
rep=""
while [ "$rep" != "q" ]
do
get_active_users
echo -e "Please Enter The User Session's SID "
read SID
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500
PROMPT=============================================================
PROMPT Current SQL statement this session executes
PROMPT=============================================================
col sql_text for a70 hea "Current SQL"
select q.sql_text
from v\$session s
,    v\$sql     q
WHERE s.sql_address = q.address
and   s.sql_hash_value + DECODE
		 (SIGN(s.sql_hash_value), -1, POWER( 2, 32), 0) = q.hash_value
AND   s.sid=$SID;
EOF
cat menu.log |more                    
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_idle_sessions()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please enter the number of minutes for idle time:"
read IDLE
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 140
col username format a15
col idle format a15
col program format a30


select
sid,username,status,
to_char(logon_time,'dd-mm-yy hh:mi:ss') "LOGON",
floor(last_call_et/3600)||':'||
floor(mod(last_call_et,3600)/60)||':'||
mod(mod(last_call_et,3600),60) "IDLE",
program
from
v\$session
where
type='USER'
and (LAST_CALL_ET / 60) > $IDLE
order by last_call_et;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_locks()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500
col waiting_session format 99999 heading 'Waiting|Session'
col holding_session format 99999 heading 'Holding|Session'
col mode_held format a20 heading 'Mode|Held'
col mode_requested format a20 heading 'Mode|Requested'
col lock_type format a20 heading 'Lock|Type'
prompt blocked objects from V\$LOCK and SYS.OBJ\$

set lines 132
col BLOCKED_OBJ format a35 trunc

select /*+ ORDERED */
    l.sid
,   l.lmode
,   TRUNC(l.ctime/60) min_blocked
,   u.name||'.'||o.NAME blocked_obj
from (select *
      from v\$lock
      where type='TM'
      and sid in (select sid
                  from v\$lock
                  where block!=0)) l
,     sys.obj\$ o
,     sys.user\$ u
where o.obj# = l.ID1
and   o.OWNER# = u.user#
/
prompt blocked sessions from V\$LOCK

select /*+ ORDERED */
   blocker.sid blocker_sid
,  blocked.sid blocked_sid
,  TRUNC(blocked.ctime/60) min_blocked
,  blocked.request
from (select *
      from v\$lock
      where block != 0
      and type = 'TX') blocker
,    v\$lock        blocked
where blocked.type='TX'
and blocked.block = 0
and blocked.id1 = blocker.id1
/
prompt blockers session details from V\$SESSION

set lines 132
col username format a10 trunc
col osuser format a12 trunc
col machine format a15 trunc
col process format a15 trunc
col action format a50 trunc

SELECT sid
,      serial#
,      username
,      osuser
,      machine
FROM v\$session
WHERE sid IN (select sid
      from v\$lock
      where block != 0
      and type = 'TX')
/
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                        
get_file_io()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
col  name format a40
select * from (
select name, phyrds,phywrts, phyrds + phywrts  "I/O"  from v\$datafile a, v\$filestat s
        where a.file# = s.file#
order by phyrds + phywrts desc ) where rownum <6;
EOF
cat menu.log|more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                        
get_jobs_running()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log      
set pagesize 80
ttitle -
  center  'List Submitted Jobs' skip 2

col jid  format 999  heading 'Id'
col subu format a10  heading 'Submitter'     trunc
col secd format a10  heading 'Security'      trunc
col proc format a30  heading 'Job'           word_wrapped
col lsd  format a5   heading 'Last|Ok|Date'
col lst  format a5   heading 'Last|Ok|Time'
col nrd  format a5   heading 'Next|Run|Date'
col nrt  format a5   heading 'Next|Run|Time'
col fail format 999  heading 'Errs'
col ok   format a2   heading 'Ok'

select
  job                        jid,
  log_user                   subu,
--  priv_user                  secd,
  what                       proc,
  to_char(last_date,'MM/DD') lsd,
  substr(last_sec,1,5)       lst,
  to_char(next_date,'MM/DD') nrd,
  substr(next_sec,1,5)       nrt,
  failures                   fail,
  decode(broken,'Y','N','Y') ok
from
  sys.dba_jobs
/                                                 
EOF
cat menu.log |more 
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_rbs_users()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
col o format a8 heading 'O/S|User'
col u format a10 heading 'Oracle|Userid'
col s format a12 heading 'R-S|Name'
col txt format a45 heading 'Current|Statement' word
select osuser o, username u,
       segment_name s, substr(sa.sql_text,1,200) txt
from v\$session s,
     v\$transaction t,
     dba_rollback_segs r,
     v\$sqlarea sa
where s.taddr=t.addr
and   t.xidusn=r.segment_id(+)
and   s.sql_address=sa.address(+)
order by segment_name;                          
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                             
get_top5_disk_reads()
{
echo -e "\n\tTop 5 SQL Statements (disk reads) for database $tns" >menu.log
echo -e "\n" >>menu.log
sqlplus -s ' / as sysdba ' <<EOF >>menu.log
set serverout on size 1000000
set feedback off
declare
top5 number;
text1 varchar2(4000);
x number;
len1 number;
Cursor c1 is
select disk_reads,substr(sql_text,1,4000)
from v\$sqlarea
order by disk_reads desc;
begin
dbms_output.put_line('Reads'||'  '||'                          Text');
dbms_output.put_line ('-----'||'  '||'--------------------------------------------------------------------');
dbms_output.put_line('      ');
open c1;
for i in 1 .. 5 loop                 
fetch c1 into top5, text1;
dbms_output.put_line(rpad(to_char(top5),9)|| ' '||substr(text1,1,66));
len1 :=length(text1);
x := 66;
while len1 > x-1 loop
dbms_output.put_line('"         '||substr(text1,x,64));
x := x+64;
end loop;
end loop;
end;
/
EOF
tput clear
cat menu.log |more
}                                               
get_top5_buffer_gets()
{
get_tns_connect
echo -e "\n" >menu.log
echo -e "\n\tTop 5 SQL Statements (Buffer Gets) for database $tns" >>menu.log
echo -e "\n" >>menu.log
sqlplus -s ' / as sysdba ' <<EOF >>menu.log
set serverout on size 1000000
set feedback off
declare
top5 number;
text1 varchar2(4000);
x number;
len1 number;
Cursor c1 is
select buffer_gets,substr(sql_text,1,4000)
from v\$sqlarea
order by buffer_gets desc;
begin
dbms_output.put_line('Reads'||'  '||'                          Text');
dbms_output.put_line ('-----'||'  '||'--------------------------------------------------------------------');
dbms_output.put_line('      ');
open c1;
for i in 1 .. 5 loop                 
fetch c1 into top5, text1;
dbms_output.put_line(rpad(to_char(top5),9)|| ' '||substr(text1,1,66));
len1 :=length(text1);
x := 66;
while len1 > x-1 loop
dbms_output.put_line('"         '||substr(text1,x,64));
x := x+64;
end loop;
end loop;
end;
/
EOF
tput clear
cat menu.log |more
}                                               
get_top_cpu_users()
{
echo -e "\t\t\t\tTop 10 CPU Users"
echo -e "***********************************************************************"
echo -e
uname -a |grep SUN > /dev/null
                if [ $? = 0 ]
                then
/usr/ucb/ps aux |head -10
else
ps aux |head -10
fi
echo -e "***********************************************************************"
echo -e
}              
get_top_sql_user1()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The UNIX Process ID"
read SPID
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 50000
set linesize 30000
set long 500000
set head off
select
       s.username su,
       substr(sa.sql_text,1,540) txt
from v\$process p,
     v\$session s,
     v\$sqlarea sa
where    p.addr=s.paddr
and      s.username is not null
and      s.sql_address=sa.address(+)
and      s.sql_hash_value=sa.hash_value(+)
and spid=$SPID;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                       
get_top_sql_user2()
{
rep=""
while [ "$rep" != "q" ]
do
get_active_users
echo -e "Please Enter The Oracle Username "
read username
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 50000
set linesize 30000
set long 500000
set head off
select
       s.username su,
       substr(sa.sql_text,1,540) txt
from v\$process p,
     v\$session s,
     v\$sqlarea sa
where    p.addr=s.paddr
and      s.username is not null
and      s.sql_address=sa.address(+)
and      s.sql_hash_value=sa.hash_value(+)
and s.username=upper('$username');
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                       
get_logswitch()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >version.log
select banner from v\$version;
EOF
cat version.log |egrep "8.1|9.2|9.0|10.1|10.2"|grep -v grep >/dev/null
if [ $? -eq 0 ]
then
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
col "01" format A4
col "02" format A4
col "03" format A4
col "04" format A4
col "05" format A4
col "06" format A4
col "07" format A4
col "08" format A4
col "09" format A4
col "10" format A4
col "11" format A4
col "12" format A4
col "13" format A4
col "14" format A4
col "15" format A4
col "16" format A4
col "17" format A4
col "18" format A4
col "19" format A4
col "20" format A4
col "21" format A4
col "22" format A4
col "23" format A4
col "00" format A4

prompt
col member format a40
select a.group#,member,bytes/1048576 "Size MB"
 from v\$log b, v\$logfile a
 where a.group# = b.group#
;
prompt
prompt "Morning .........."
select to_char(first_time,'DD/MON') day,
to_char(sum(decode(to_char(first_time,'HH24'),'07',1,0)),'000')"07",
to_char(sum(decode(to_char(first_time,'HH24'),'08',1,0)),'000')"08",
to_char(sum(decode(to_char(first_time,'HH24'),'09',1,0)),'000')"09",
to_char(sum(decode(to_char(first_time,'HH24'),'10',1,0)),'000')"10",
to_char(sum(decode(to_char(first_time,'HH24'),'11',1,0)),'000')"11",
to_char(sum(decode(to_char(first_time,'HH24'),'12',1,0)),'000')"12",
to_char(sum(decode(to_char(first_time,'HH24'),'13',1,0)),'000')"13",
to_char(sum(decode(to_char(first_time,'HH24'),'14',1,0)),'000')"14",
to_char(sum(decode(to_char(first_time,'HH24'),'15',1,0)),'000')"15",
to_char(sum(decode(to_char(first_time,'HH24'),'16',1,0)),'000')"16",
to_char(sum(decode(to_char(first_time,'HH24'),'17',1,0)),'000')"17",
to_char(sum(decode(to_char(first_time,'HH24'),'18',1,0)),'000')"18"
from v\$log_history
WHERE TRUNC(FIRST_TIME) > TRUNC(SYSDATE) - 7
group by to_char(first_time,'DD/MON');
prompt
prompt
Prompt "Evening ........"
prompt
select to_char(first_time,'DD/MON') day,
to_char(sum(decode(to_char(first_time,'HH24'),'19',1,0)),'000')"19",
to_char(sum(decode(to_char(first_time,'HH24'),'20',1,0)),'000')"20",
to_char(sum(decode(to_char(first_time,'HH24'),'21',1,0)),'000')"21",
to_char(sum(decode(to_char(first_time,'HH24'),'22',1,0)),'000')"22",
to_char(sum(decode(to_char(first_time,'HH24'),'23',1,0)),'000')"23",
to_char(sum(decode(to_char(first_time,'HH24'),'00',1,0)),'000') "00",
to_char(sum(decode(to_char(first_time,'HH24'),'01',1,0)),'000')"01",
to_char(sum(decode(to_char(first_time,'HH24'),'02',1,0)),'000')"02",
to_char(sum(decode(to_char(first_time,'HH24'),'03',1,0)),'000')"03",
to_char(sum(decode(to_char(first_time,'HH24'),'04',1,0)),'000')"04",
to_char(sum(decode(to_char(first_time,'HH24'),'05',1,0)),'000')"05",
to_char(sum(decode(to_char(first_time,'HH24'),'06',1,0)),'000')"06"
from v\$log_history
WHERE TRUNC(FIRST_TIME) > TRUNC(SYSDATE) - 7
group by to_char(first_time,'DD/MON');
EOF
else
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
col member format a40
prompt
prompt "Redo Log File Configuration"

select a.group#,member,bytes/1048576 "Size MB"
 from v\$log b, v\$logfile a
 where a.group# = b.group#
;
prompt
col "01" format A4
col "02" format A4
col "03" format A4
col "04" format A4
col "05" format A4
col "06" format A4
col "07" format A4
col "08" format A4
col "09" format A4
col "10" format A4
col "11" format A4
col "12" format A4
col "13" format A4
col "14" format A4
col "15" format A4
col "16" format A4
col "17" format A4
col "18" format A4
col "19" format A4
col "20" format A4
col "21" format A4
col "22" format A4
col "23" format A4
col "00" format A4


select substr(time,1,5) day,
to_char(sum(decode(substr(time,10,2),'07',1,0)),'00')"07",
to_char(sum(decode(substr(time,10,2),'08',1,0)),'00')"08",
to_char(sum(decode(substr(time,10,2),'09',1,0)),'00')"09",
to_char(sum(decode(substr(time,10,2),'10',1,0)),'00')"10",
to_char(sum(decode(substr(time,10,2),'11',1,0)),'00')"11",
to_char(sum(decode(substr(time,10,2),'12',1,0)),'00')"12",
to_char(sum(decode(substr(time,10,2),'13',1,0)),'00')"13",
to_char(sum(decode(substr(time,10,2),'14',1,0)),'00')"14",
to_char(sum(decode(substr(time,10,2),'15',1,0)),'00')"15",
to_char(sum(decode(substr(time,10,2),'16',1,0)),'00')"16",
to_char(sum(decode(substr(time,10,2),'17',1,0)),'00')"17",
to_char(sum(decode(substr(time,10,2),'18',1,0)),'00')"18"
from v\$log_history
group by substr(time,1,5);
prompt
Prompt "Evening ......."
prompt
select substr(time,1,5) day,
to_char(sum(decode(substr(time,10,2),'19',1,0)),'00')"19",
to_char(sum(decode(substr(time,10,2),'20',1,0)),'00')"20",
to_char(sum(decode(substr(time,10,2),'21',1,0)),'00')"21",
to_char(sum(decode(substr(time,10,2),'22',1,0)),'00')"22",
to_char(sum(decode(substr(time,10,2),'23',1,0)),'00')"23",
to_char(sum(decode(substr(time,10,2),'00',1,0)),'00') "00",
to_char(sum(decode(substr(time,10,2),'01',1,0)),'00')"01",
to_char(sum(decode(substr(time,10,2),'02',1,0)),'00')"02",
to_char(sum(decode(substr(time,10,2),'03',1,0)),'00')"03",
to_char(sum(decode(substr(time,10,2),'04',1,0)),'00')"04",
to_char(sum(decode(substr(time,10,2),'05',1,0)),'00')"05",
to_char(sum(decode(substr(time,10,2),'06',1,0)),'00')"06"
from v\$log_history
group by substr(time,1,5);
EOF
fi
cat menu.log|more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
getusers()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 120
SET PAGESIZE 500

column pu format a22 heading 'O/S|Login|ID' justify left
column su format a18 heading 'Oracle|User ID' justify left
column stat format a8 heading 'Session|Status' justify left
column ssid format 999999 heading 'Oracle|Session|ID' justify right
column sser format 999999 heading 'Oracle|Serial|No' justify right
column spid format a8 heading 'Process ID' 

select s.osuser pu,
       s.username su,
       s.status stat,
       s.sid ssid,
       s.serial# sser,
       lpad(p.spid,7) spid
from v\$process p,
     v\$session s
     where    p.addr=s.paddr
and      s.username is not null
order by s.status ;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_active_users()
{
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500

column pu format a8 heading 'O/S|Login|ID' justify left
column su format a16 heading 'Oracle|User ID' justify left
column ssid format 999999 heading 'Oracle|Session|ID' justify right
column sser format 999999 heading 'Oracle|Serial|No' justify right

select S.osuser pu,
       s.username su,
       s.status stat,
       s.sid ssid,
       s.serial# sser
from v\$process p,
     v\$session s
     where    p.addr=s.paddr
and      s.username is not null
and s.status='ACTIVE'
order by S.username ;
EOF
cat menu.log |more
}
get_rollback_info ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
col segment_name format a12 heading "Segment|Name"
col tablespace_name format a12 heading "Tablespace|Name"
col status format a10
col round(sum(initial_extent/1024)) Format 999,999 heading "Initial (Kb)"
col round(sum(next_extent/1024)) format 999,999 heading "Next (Kb)"
col max_extents format 9999999999 heading "Max|Extents"
select segment_name, tablespace_name, status,round(sum(initial_extent/1024)),
round(sum(next_extent/1024)),max_extents from dba_rollback_segs
group by segment_name, tablespace_name,status,max_extents;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_tablespace_info ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >version.log
select banner from v\$version;
EOF
cat version.log |egrep "8.1|9.2|9.0"|grep -v grep >/dev/null
if [ $? -eq 0 ]
then
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
col extent_management format a12 heading 'Extent|Management'
col allocation_type format a12 heading 'Allocation|Type'
select a.tablespace_name,a.status,contents,extent_management,
allocation_type, round(sum(b.bytes/1048576)) "Size (Mb)"
from
dba_tablespaces a, dba_data_files b
where a.tablespace_name=b.tablespace_name
group by a.tablespace_name,a.status,a.contents,a.extent_management,
a.allocation_type
order by  1;
EOF
cat menu.log |more
else
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
select a.tablespace_name,a.status,contents, 
round(sum(b.bytes/1048576)) "Size (Mb)"
from
dba_tablespaces a, dba_data_files b
where a.tablespace_name =b.tablespace_name
group by a.tablespace_name,a.status,contents
order by  1;
EOF
cat menu.log |more
fi
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_tablespace_info_7 ()
{
rep=""
while [ "$rep" != "q" ]
do
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
select tablespace_name,status,contents from
dba_tablespaces order by tablespace_name;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_full90 ()
{
rep=""
while [ "$rep" != "q" ]
do
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
  set pagesize 300
     set linesize 100
       column tablespace_name format a15 heading 'Tablespace'
    column sumb format 999,999,999
    column extents format 9999
    column bytes format 999,999,999,999
    column largest format 999,999,999,999
    column Tot_Size format 999,999 Heading 'Total Size(Mb)'
    column Tot_Free format 999,999,999 heading 'Total Free(Kb)'
    column Pct_Free format 999.99 heading '% Free'
         column Max_Free format 999,999,999 heading 'Max Free(Kb)'
ttitle center 'Tablespaces With Less Than 10% Free Space' skip 2
    set echo -e off


    select a.tablespace_name,sum(a.tots/1048576) Tot_Size,
    sum(a.sumb/1024) Tot_Free,
    sum(a.sumb)*100/sum(a.tots) Pct_Free
        from
    (
    select tablespace_name,0 tots,sum(bytes) sumb
      from dba_free_space a
    group by tablespace_name
    union
     select tablespace_name,sum(bytes) tots,0 from
      dba_data_files
     group by tablespace_name) a
     group by a.tablespace_name
having  sum(a.sumb)*100/sum(a.tots) < 10
order by pct_free;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_free_space()
{
rep=""
while [ "$rep" != "q" ]
do
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
      set linesize 500
        column tablespace_name format a15 heading 'Tablespace'
     column sumb format 999,999,999
     column extents format 9999
     column bytes format 999,999,999,999
     column largest format 999,999,999,999
     column Tot_Size format 999,999 Heading 'Total Size(Mb)'
     column Tot_Free format 999,999,999 heading 'Total Free(Kb)'
     column Pct_Free format 999.99 heading '% Free'
          column Max_Free format 999,999,999 heading 'Max Free(Kb)'


     select a.tablespace_name,sum(a.tots/1048576) Tot_Size,
     sum(a.sumb/1024) Tot_Free,
     sum(a.sumb)*100/sum(a.tots) Pct_Free
         from
     (
     select tablespace_name,0 tots,sum(bytes) sumb
       from dba_free_space a
     group by tablespace_name
     union
     select tablespace_name,sum(bytes) tots,0 from
      dba_data_files
     group by tablespace_name) a
     group by a.tablespace_name
order by pct_free;
EOF
cat menu.log|more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_oratab_value()
{
        A=`grep -i "^"$1" *:" $ORATAB|awk -F':' '{print $'$2'}'`
        echo -e "$A\c"
}                                                      
oracle_home()
{
echo -e '$ORACLE_HOME Locations:\n'
echo -e
echo -e "`cat $ORATAB | awk -F: '{ print $2 }'|sort -u`"
echo -e                                                                
}
get_db_files()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
Prompt
Prompt Control Files Location >>>>
col name  format a60 heading "Control Files"

select name
from   sys.v_\$controlfile
/

Prompt
Prompt Redo Log File Locations >>>>
Prompt

col Grp    format 9999
col member format a50 heading "Online REDO Logs"
col File#  format 9999
col name   format a50 heading "Online REDO Logs"
break on Grp
select group#,member
from   sys.v_\$logfile
/


Prompt Data Files Locations >>>>

col Tspace    format a15
col status    format a3  heading Sta
col Id        format 99
col Mbyte     format 9999
col name      format a50 heading "Database Data Files"
col Reads     format 99,999,999
col Writes    format 99,999,999

break on report
compute sum of Mbyte on report

select F.file_id Id,
       F.file_name name,
       F.bytes/(1024*1024) Mbyte,
       decode(F.status,'AVAILABLE','OK',F.status) status,
       F.tablespace_name Tspace
from   sys.dba_data_files F
order by tablespace_name;
EOF
cat menu.log |more
}
machine_activity()
{
up=`uptime |awk -F',' '{print $1}'`
load1=`uptime |awk -F',' '{print $4}'`
load2=`uptime |awk -F',' '{print $5}'`
load3=`uptime |awk -F',' '{print $6}'`        
echo -e  "\t\tMachine Load Statistics as on" $up
echo -e
echo -e "$load1 (last 1 minute), $load2 (last 5 minutes), $load3 (last 15 minutes)"
echo -e                                                                           
echo -e "Number Of Oracle Instances Running : `ps -ef |grep ora_pmon|grep -v grep|wc -l`"
echo -e
echo -e "Number of connected Oracle sessions (Dedicated):`ps -ef |grep -v ora_|grep LOCAL |wc -l`"
echo -e                 
echo -e
echo -e "\t\t\t\tTop 10 CPU Users"
echo -e "***********************************************************************"
echo -e                                                                          
uname -a |grep SUN > /dev/null
                if [ $? = 0 ]
                then
/usr/ucb/ps aux |head -10
else
ps aux |head -10                   
fi
}
machine ()
{
tput clear
echo -e "******************************************************************"
echo -e " Information for UNIX node : `hostname`"
echo -e "*****************************************************************"
echo -e
CPU=`psrinfo -v|grep "Status of processor"|wc -l`
MEM=`prtconf |grep -i mem|awk '{ if (NR == 1) print $0 }' `
up=`uptime |awk -F',' '{print $1}'`
load1=`uptime |awk -F',' '{print $4}'`
load2=`uptime |awk -F',' '{print $5}'`
load3=`uptime |awk -F',' '{print $6}'`
last_reboot=`who -b |awk '{ print $4" " $5" "$6 }'`
echo -e "Machine Type:`uname -a`"
echo -e
echo -e "Number of CPU's:"  $CPU
echo -e
echo -e  $MEM
echo -e
echo -e "Swap Space: `swap -s`"
echo -e                                         
echo -e "Last Reboot Time : $last_reboot"
}

Yy()  # For reading y/n
{
        read ANS
        if [ "$ANS" = "Y" -o "$ANS" = "y" ]
        then
                echo -e y
        fi
}               

check_disk_space()
{
df -ek |  awk '{  printf "%-5s %-20s %-50s\n",$5,$4,$6}' |tr -s '%' ' '|awk '{if ($1 >= 90) printf  "%5s%%  %-20s %-50s\n",$1,$2,$3 } ' | sort -r
}                   
check_free_space()
{
df -ek |awk '{  printf "%-20s %-15s %-15s %-5s\n",$6,$2,$4,$5}' |tr -s '%' ' '|awk '{if ($2 != 0) printf "%-20s %-15s  %-15s %5s%% \n",$1,$2,$3,$4 } ' | sort -n +2 |more
}

get_waits_segment()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log 
col sid format 99999
col event format a25
col p1text format a10
col p2text format a10
col p3text format a10
set pagesize 500
set linesize 500
select sid, event, p1text, p1, p2text , p2 
from  v\$session_wait
where
sid between 10 and 1000
and event not like 'SQL*Net%'
and event not like '%rdbms%'
;
EOF
cat menu.log |more
}
get_waits_segment_dtl()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
col sid format 99999
col event format a25
col p1text format a10
col p2text format a10
col p3text format a10
set pagesize 500
set linesize 500
select sid, event, p1text, p1, p2text , p2
from  v\$session_wait
where
sid between 10 and 1000
and event  like 'db%'
;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]                
then
cat menu.log |more                        
echo -e
echo -e "Please Enter The Datafile#  (P1): \c"
read df
echo -e 
echo -e "Please Enter The Block Number (P2):  \c"
read block
echo -e
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log 
set pagesize 500
set linesize 500
col owner format a20
col segment_type format a20
col segment_name format a30
col tablespace_name format a20
select owner, segment_name, segment_type, tablespace_name
from dba_extents
where file_id =$df
and $block  between block_id and block_id + blocks -1
/
EOF
cat menu.log |more 
fi
}
get_waits_io()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log    
SELECT s.sql_hash_value
  FROM V\$SESSION s, V\$SESSION_WAIT w
 WHERE w.event  in  ('db file scattered read','db file sequential read')
   AND w.sid = s.sid ;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]
then
cat menu.log |more
echo -e
echo -e "Please Enter The Hash Value#: \c"
read hash                               
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
select sql_text from v\$sqlarea where hash_value=$hash;
EOF
cat menu.log|more
fi
}
get_waits_session()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log   
col username format a15
col sid format 99999
col program format a30
col state format a15
col event format a25
col wait_time format 99999999
set pagesize 800
set linesize 800
select s.sid, s.username, s.program, se.event, se.state, se.wait_time
from v\$session s, v\$session_wait se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and se.event not like '%rdbms%'
and s.username is not null
order by se.wait_time;
EOF
cat menu.log |more 
}
get_longops()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500
col opname format a15
SELECT SID, SERIAL#, opname, SOFAR, TOTALWORK, ROUND(SOFAR/TOTALWORK*100,2) "% COMPLETE"
FROM   V\$SESSION_LONGOPS
WHERE  
--OPNAME LIKE 'RMAN%'
--AND    OPNAME NOT LIKE '%aggregate%'
--AND    
TOTALWORK != 0
AND    SOFAR <> TOTALWORK
order by 1;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_flashback ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF > version.log
set heading off
set feedback off
select version from v\$instance;
EOF
cat version.log |grep -w "9.2"  > /dev/null
if test $? -eq 1
    then
sqlplus -s ' / as sysdba ' <<EOF >menu.log
PROMPT How Far Back Can We Flashback To (Time)?
PROMPT
select to_char(oldest_flashback_time,'dd-mon-yyyy hh24:mi:ss') "Oldest Flashback Time"
 from v\$flashback_database_log;
PROMPT
PROMPT How Far Back Can We Flashback To (SCN)?
PROMPT
col oldest_flashback_scn format 99999999999999999999999999
select oldest_flashback_scn from v\$flashback_database_log;
PROMPT
PROMPT Flashback Area Usage
SELECT * FROM   V\$FLASH_RECOVERY_AREA_USAGE;
PROMPT
col ROUND(SPACE_LIMIT/1048576) heading "Space Allocated (MB)" format 999999
col round(space_used/1048576) heading "Space Used (MB)" format 99999
col name Heading "Flashback Location" format a40
select name, round(space_limit/1048576),round(space_used/1048576)
 from  v\$RECOVERY_FILE_DEST;
EOF
cat menu.log |more
else echo -e "This Option Is Not Available For An Oracle 9i Database"
fi
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_rmanbkp()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
col dbf format a40
set linesize 120

PROMPT Datafiles Backed up during past 24 Hours

SELECT dbf||' from '||nf "Datafiles backed up"
  FROM (select count(*) nf from sys.v_\$datafile),
       (select count(*) dbf
          from sys.v_\$backup_datafile a, sys.v_\$datafile b
         where a.file# = b.file#
           and a.completion_time > sysdate - 1)
;

PROMPT Archive log Files Backed up during past 24 Hours

SELECT backedup||' from '||archived "Archive log files backed up",
       ondisk "Archive log files on disk"
  FROM (select count(*) archived
          from sys.v_\$archived_log where completion_time > sysdate - 1),
       (select count(*) backedup from sys.v_\$archived_log
         where backup_count > 0
           and completion_time > sysdate - 1),
       (select count(*) ondisk from sys.v_\$archived_log
         where archived = 'YES' and deleted  = 'NO')
;

PROMPT RMAN Backups Still Running:

SELECT to_char(start_time,'DD-MON-YY HH24:MI') "BACKUP STARTED",
       sofar, totalwork,
       elapsed_seconds/60 "ELAPSE (Min)",
       round(sofar/totalwork*100,2) "Complete%"
FROM   sys.v_\$session_longops
WHERE  opname = 'dbms_backup_restore'
;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}



get_active_tran ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
col name format a8
col username format a8
col osuser format a8
col start_time format a17
col status format a12
tti 'Active transactions'
select sid,username, osuser,
t.start_time, r.name, t.used_ublk "ROLLB BLKS",
decode(t.space, 'YES', 'SPACE TX',
decode(t.recursive, 'YES', 'RECURSIVE TX',
decode(t.noundo, 'YES', 'NO UNDO TX', t.status)
)) status
from sys.v_\$transaction t, sys.v_\$rollname r, sys.v_\$session s
where t.xidusn = r.usn
and t.ses_addr = s.saddr
;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_sortusage ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 120
col tablespace_name format a12
PROMPT Temporary Tablespace Allocation
PROMPT
SELECT a.tablespace_name tablespace, e.mb_total,
SUM (a.used_blocks * e.block_size) / 1024 / 1024 mb_used,
e.mb_total-SUM (A.used_blocks * e.block_size) / 1024 / 1024 mb_free
FROM v\$sort_segment A,
(
SELECT B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
FROM v\$tablespace B, v\$tempfile C
WHERE B.ts#= C.ts#
GROUP BY B.name, C.block_size
) e
WHERE A.tablespace_name = e.name
GROUP by A.tablespace_name, e.mb_total;

PROMPT
PROMPT
PROMPT SORT SPACE USAGE AT SESSION LEVEL
PROMPT
col sid format 999999
col serial# format 999999
col username format a12
col osuser format a15
col spid format a10
col tablespace_name format a12
col program format a25

SELECT   S.sid,S.serial#, S.username, P.spid,
         S.program, SUM ((T.blocks) * (TBS.block_size)) / 1048576 mb_used, T.tablespace,
         COUNT(*) sort_ops
FROM     v\$sort_usage T, v\$session S, dba_tablespaces TBS, v\$process P
WHERE    T.session_addr = S.saddr
AND      S.paddr = P.addr
AND      T.tablespace = TBS.tablespace_name
GROUP BY S.sid, S.serial#, S.username, P.spid, 
         S.program, TBS.block_size, T.tablespace
ORDER BY 6;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_redogen ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
select trunc(completion_time) rundate
,count(*)  logswitch
,round((sum(blocks*block_size)/1024/1024)) "REDO PER DAY (MB)"
from v\$archived_log
where trunc(completion_time) > sysdate-31
group by trunc(completion_time)
order by 1;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}



get_sessio ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
 set linesize 120
col os_user format a10
col username format a15

col pid format 9999999999
PROMPT SESSIONS SORTED BY PHYSICAL READS
PROMPT
select
  OSUSER os_user,username,
    PROCESS pid,
    ses.SID sid,
    SERIAL#,
    PHYSICAL_READS,
     BLOCK_CHANGES
 from       v\$session ses,
   v\$sess_io sio
  where      ses.SID = sio.SID
and username is not null
and status='ACTIVE'
 order      by PHYSICAL_READS;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}

get_logship ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
SET PAGESIZE 124
COL DB_NAME FORMAT A8
COL HOSTNAME FORMAT A12
COL LOG_ARCHIVED FORMAT 999999
COL LOG_APPLIED FORMAT 999999
COL LOG_GAP FORMAT 9999
COL APPLIED_TIME FORMAT A12
SELECT DB_NAME, HOSTNAME, LOG_ARCHIVED, LOG_APPLIED,APPLIED_TIME,
LOG_ARCHIVED-LOG_APPLIED LOG_GAP
FROM
(
SELECT NAME DB_NAME
FROM V\$DATABASE
),
(
SELECT UPPER(SUBSTR(HOST_NAME,1,(DECODE(INSTR(HOST_NAME,'.'),0,LENGTH(HOST_NAME),
(INSTR(HOST_NAME,'.')-1))))) HOSTNAME
FROM V\$INSTANCE
),
(
SELECT MAX(SEQUENCE#) LOG_ARCHIVED
FROM V\$ARCHIVED_LOG WHERE DEST_ID=1 AND ARCHIVED='YES'
),
(
SELECT MAX(SEQUENCE#) LOG_APPLIED
FROM V\$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES'
),
(
SELECT TO_CHAR(MAX(COMPLETION_TIME),'DD-MON/HH24:MI') APPLIED_TIME
FROM V\$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES'
);
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}




get_waits_session_dtl()
{
echo -e 
echo -e "\t\t\tSession wait details ......."
echo -e "*************************************************************************"
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
col username format a15
col sid format 99999
col program format a30
col event format a25
col status format a10
col total_waits format 99999999
set pagesize 500
set linesize 500
select s.username, s.sid, se.event, se.total_waits
from v\$session s, v\$session_event se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and s.username is not null
and s.status='ACTIVE'
order by se.total_waits
/
EOF
cat menu.log |more 
}
get_waits_instance()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
set pagesize 800
set linesize 800
col event format a30
select  event, total_waits, total_timeouts, time_waited
from v\$system_event
where event not like 'SQL*Net%'
order by total_waits;
EOF
cat menu.log |head -2
cat menu.log |tail -10

$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
Prompt 
Prompt "Class Of Waits Since Instance Startup"
prompt
select class,count from v\$waitstat order by count;
EOF
cat menu.log|more
}

setsid()
{
        if [ $# = 0 ]
        then
                return
        fi
        ORACLE_SID=$1; export ORACLE_SID
        ORACLE_HOME=`get_oratab_value $1 2`; export ORACLE_HOME
}                           
fn2()
{
tput clear
 get_logswitch
}
fn1()
{
getusers
}
fn3()
{
tput clear
get_top_sql_user1
}
fn4()
{
tput clear
#get_active_users
get_top_sql_user2
}
fn5()
{
get_top5_buffer_gets
}
fn6()
{
get_rbs_users
}

fn7()
{
get_locks
}
fn8()
{
get_locked_objects
}
fn9()
{
get_file_io
}
###The choice loop
while [ 1 ]        
do
        tput clear
 echo -e "\n"
        echo -e "\t"
        echo -e "\t#######################################################"
        echo -e "\t\t\tDatabase Monitoring Menu - `tput smso`$Yellow$tns`tput rmso`\t"
        echo -e "\t#######################################################"
        echo -e "\t"
	echo -e "\t(1)  User Sessions "
	echo -e "\t(2)  Redo Log File Switches"
	echo -e "\t(3)  Current SQL (by Unix PID)"
	echo -e "\t(4)  Current SQL (by SID)"
	echo -e "\t(5)  Current SQL (by Oracle Username)"
	echo -e "\t(6)  Rollback Segment Usage"
	echo -e "\t(7)  Locked Sessions"
	echo -e "\t(8)  Locked Objects"
	echo -e "\t(9)  Datafile I/O "
	echo -e "\t(10) DBMS Jobs Status "
	echo -e "\t(11) View Long Operations "
	echo -e "\t(12) Active Transactions  "
	echo -e "\t(13) Idle Sessions  "
	echo -e "\t(14) Flashback Logging  "
	echo -e "\t(15) Sessions With High I/O  "
	echo -e "\t(16) Data Guard Log Shipping  "
	echo -e "\t(17) Redo Generation By Day "
	echo -e "\t(18) RMAN Backup Status "
	echo -e "\t(19) Sort Area Usage "
        echo -e "\n"
        echo -e "\tEnter your choice (q to quit): \c             "
        echo -e "\n"
        echo -e "\t#######################################################"
tput cup 28 40

 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
				main 
				#exit [ 0 ]
		else 	
        case $CHOICE in
                1) tput clear;getusers ;;
                2) tput clear;get_logswitch ;;
                3) tput clear ;fn3 ;;
	        4) tput clear;get_sid_sql;;
                5) tput clear; fn4 ;;
                6) tput clear; get_rbs_users ;;
                7) tput clear; get_locks ;;
                8) tput clear;get_locked_objects ;;
                9) tput clear; get_file_io ;;
                10) tput clear; get_jobs_running ;;
                11) tput clear; get_longops ;;
                12) tput clear; get_active_tran ;;
                13) tput clear; get_idle_sessions;;
                14) tput clear; get_flashback;;
                15) tput clear; get_sessio;;
                16) tput clear; get_logship ;;
                17) tput clear; get_redogen ;;
                18) tput clear; get_rmanbkp ;;
                19) tput clear; get_sortusage ;;
        esac
        if [ "$CHOICE2" = "q" -o "$CHOICE2" = "Q"  -o "$CHOICE2" = "END" ]
        then
                continue
        fi
#        echo -e "Hit return to continue\c"
#        #line                          
fi
done                            


}

user( )
{
#tns=`cat /tmp/nirtns`
MC=`uname -a|awk '{print $2}'|tr 'a-z' 'A-Z'`
MENU_NAME=${MENU_NAME:-"DBA Menu - $MC"}  
if [ -f /var/opt/oracle/oratab ]
then
        ORATAB=/var/opt/oracle/oratab; export ORATAB
elif [ -f /etc/oratab ]
then
        ORATAB=/etc/oratab; export ORATAB
else
        echo -e "Could not find oratab...quiting..."
        exit 1
fi              
#Get the list of databases
SID_LIST=`grep -v '^#' $ORATAB|awk -F':' '{print $1}'`
SID_COUNT=`echo -e $SID_LIST|wc -w`
SID_COUNT=`echo -e $SID_COUNT` 
L_Passwd=`awk '{print $0}' monitor_passwd`
get_tns_connect()
{
choice=""
until [ -n  "$choice" ]
do
echo -e "Please Enter The TNS Connect String "
read tns
awk '{
   if ($2 == "=" && $1 !~ /^\(/) print $1
   else
   if ($1 ~ /\=/ && $1 !~ /^\(/) {
        strng = substr($1,1,length($1)-1)
        print strng
        }
   }' $ORACLE_HOME/network/admin/tnsnames.ora |grep -iw $tns >/dev/null 
if [ $? -eq 0 ]
then
echo -e "Connecting to Database $tns ...."
choice=TRUE
else echo -e "Wrong TNS connect string"
fi
done
}
get_DBA_grantee()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500
 select grantee, granted_role from dba_role_privs
 where granted_role='DBA'
 order by grantee;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                        
get_default_tablespace()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
col default_tablespace format a10 heading 'Default'
col temporary_tablespace format a10 heading 'Temp'
select username, default_tablespace,temporary_tablespace 
from dba_users
where (default_tablespace='SYSTEM'
or temporary_tablespace='SYSTEM')
and username not in ('SYS','SYSTEM');
EOF
cat menu.log|more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                        
get_role_grantees()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The Role Name To Check Its Grantees"
read role
sqlplus -s ' / as sysdba ' <<EOF >menu.log   
col grantee heading 'Grantee' format a25;
col granted_role heading 'Role' format a20;
col admin_option heading 'Admin|Option?' format a7
col default_role heading 'Default|Role?' format a7
break on granted_role;
select  grantee,admin_option, default_role
from dba_role_privs 
where granted_role=upper('$role')
order by grantee;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                             
get_user_grantees()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The Username To Check Roles Granted"
read user
sqlplus -s ' / as sysdba ' <<EOF >menu.log   
col grantee heading 'Username' format a25;
col granted_role heading 'Role' format a20;
col admin_option heading 'Admin|Option?' format a7
col default_role heading 'Default|Role?' format a7
break on username;
select  grantee,granted_role,admin_option, default_role
from dba_role_privs 
where grantee=upper('$user')
order by grantee;
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                             
get_user_sys_privs()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The User Name or "ALL" For All Database Users"
read user
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500                                     
column Username format a30 heading 'User'
column privilege format a30 heading 'Privilege'
column opt format a6 heading 'Admin.|Option'
select  username, privilege, lpad(admin_option,4) "opt"
from dba_sys_privs, dba_users
where  username=grantee
and
username like decode(upper('$user'),'ALL','%',upper('$user'))
order by username, privilege;
EOF
tput clear
cat menu.log |more                           
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_table_privs()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The Table Name"
read tab
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500                                     
select grantee,privilege from dba_tab_privs
where table_name=upper('$tab')
order by grantee;
EOF
tput clear
cat menu.log |more                           
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_role_sys_privs()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The Role Name or "ALL" For All Database Roles"
read role
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
column role format a30 heading 'Role'
column privilege format a30 heading 'Privilege'
column opt format a6 heading 'Admin.|Option'
select  role, privilege, lpad(admin_option,4) "opt"
from dba_sys_privs, dba_roles
where  role=grantee
and
role like decode(upper('$role'),'ALL','%',upper('$role'))
order by role, privilege;
EOF
tput clear
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                                               
get_role_tab_privs()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e 'Please enter Grantee (User Or Role) : '
read grantee
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
col grantee format a10 heading 'Grantee'
col table_name format a35 heading 'Object Name'
col type format a12 heading 'Type'
select  t.grantee grantee,t.table_name table_name,   O.OBJECT_TYPE TYPE,
  max(decode( t.privilege,'SELECT','X',null)) S,
  max(decode( t.privilege,'INSERT','X',null))  I,
  max(decode( t.privilege,'UPDATE','X',null)) U,
  max(decode( t.privilege,'DELETE','X',null)) D,
  max(decode( t.privilege,'EXECUTE','X',null)) E
from 
 DBA_OBJECTS O , dba_tab_privs t
where
T.TABLE_NAME = O.OBJECT_NAME(+)
and t.owner = o.owner
and  grantee = upper('$grantee')
group by   T.table_name, T.grantee,OBJECT_TYPE 
order by 2;
EOF
tput clear
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                                               
get_top_cpu_users()
{
echo -e "\t\t\t\tTop 10 CPU Users"
echo -e "***********************************************************************"
echo -e
uname -a |grep SUN > /dev/null
                if [ $? = 0 ]
                then
/usr/ucb/ps aux |head -10
else
ps aux |head -10
fi
echo -e "***********************************************************************"
echo -e
}              
get_top_sql_user()
{
echo -e "Please Enter The UNIX Process ID"
read SPID
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 50000
set linesize 30000
set long 500000
set head off
select
       s.username su,
       substr(sa.sql_text,1,540) txt
from v\$process p,
     v\$session s,
     v\$sqlarea sa
where    p.addr=s.paddr
and      s.username is not null
and      s.sql_address=sa.address(+)
and      s.sql_hash_value=sa.hash_value(+)
and spid=$SPID;
EOF
cat menu.log |more
}                       
get_logswitch()
{
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >version.log
select banner from v\$version;
EOF
cat version.log |egrep "8.1|9.2|9.0"|grep -v grep >/dev/null
if [ $? -eq 0 ]
then
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
prompt
prompt "Morning .........."
select to_char(first_time,'DD/MON') day,
to_char(sum(decode(to_char(first_time,'HH24'),'07',1,0)),'000')"07",
to_char(sum(decode(to_char(first_time,'HH24'),'08',1,0)),'000')"08",
to_char(sum(decode(to_char(first_time,'HH24'),'09',1,0)),'000')"09",
to_char(sum(decode(to_char(first_time,'HH24'),'10',1,0)),'000')"10",
to_char(sum(decode(to_char(first_time,'HH24'),'11',1,0)),'000')"11",
to_char(sum(decode(to_char(first_time,'HH24'),'12',1,0)),'000')"12",
to_char(sum(decode(to_char(first_time,'HH24'),'13',1,0)),'000')"13",
to_char(sum(decode(to_char(first_time,'HH24'),'14',1,0)),'000')"14",
to_char(sum(decode(to_char(first_time,'HH24'),'15',1,0)),'000')"15",
to_char(sum(decode(to_char(first_time,'HH24'),'16',1,0)),'000')"16",
to_char(sum(decode(to_char(first_time,'HH24'),'17',1,0)),'000')"17",
to_char(sum(decode(to_char(first_time,'HH24'),'18',1,0)),'000')"18"
from v\$log_history
WHERE TRUNC(FIRST_TIME) > TRUNC(SYSDATE) - 7
group by to_char(first_time,'DD/MON');
prompt
prompt
Prompt "Evening ........"
prompt
select to_char(first_time,'DD/MON') day,
to_char(sum(decode(to_char(first_time,'HH24'),'19',1,0)),'000')"19",
to_char(sum(decode(to_char(first_time,'HH24'),'20',1,0)),'000')"20",
to_char(sum(decode(to_char(first_time,'HH24'),'21',1,0)),'000')"21",
to_char(sum(decode(to_char(first_time,'HH24'),'22',1,0)),'000')"22",
to_char(sum(decode(to_char(first_time,'HH24'),'23',1,0)),'000')"23",
to_char(sum(decode(to_char(first_time,'HH24'),'00',1,0)),'000') "00",
to_char(sum(decode(to_char(first_time,'HH24'),'01',1,0)),'000')"01",
to_char(sum(decode(to_char(first_time,'HH24'),'02',1,0)),'000')"02",
to_char(sum(decode(to_char(first_time,'HH24'),'03',1,0)),'000')"03",
to_char(sum(decode(to_char(first_time,'HH24'),'04',1,0)),'000')"04",
to_char(sum(decode(to_char(first_time,'HH24'),'05',1,0)),'000')"05",
to_char(sum(decode(to_char(first_time,'HH24'),'06',1,0)),'000')"06"
from v\$log_history
WHERE TRUNC(FIRST_TIME) > TRUNC(SYSDATE) - 7
group by to_char(first_time,'DD/MON');
EOF
else
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
select substr(time,1,5) day,
to_char(sum(decode(substr(time,10,2),'07',1,0)),'00')"07",
to_char(sum(decode(substr(time,10,2),'08',1,0)),'00')"08",
to_char(sum(decode(substr(time,10,2),'09',1,0)),'00')"09",
to_char(sum(decode(substr(time,10,2),'10',1,0)),'00')"10",
to_char(sum(decode(substr(time,10,2),'11',1,0)),'00')"11",
to_char(sum(decode(substr(time,10,2),'12',1,0)),'00')"12",
to_char(sum(decode(substr(time,10,2),'13',1,0)),'00')"13",
to_char(sum(decode(substr(time,10,2),'14',1,0)),'00')"14",
to_char(sum(decode(substr(time,10,2),'15',1,0)),'00')"15",
to_char(sum(decode(substr(time,10,2),'16',1,0)),'00')"16",
to_char(sum(decode(substr(time,10,2),'17',1,0)),'00')"17",
to_char(sum(decode(substr(time,10,2),'18',1,0)),'00')"18"
from v\$log_history
group by substr(time,1,5);
prompt
Prompt "Evening ......."
prompt
select substr(time,1,5) day,
to_char(sum(decode(substr(time,10,2),'19',1,0)),'00')"19",
to_char(sum(decode(substr(time,10,2),'20',1,0)),'00')"20",
to_char(sum(decode(substr(time,10,2),'21',1,0)),'00')"21",
to_char(sum(decode(substr(time,10,2),'22',1,0)),'00')"22",
to_char(sum(decode(substr(time,10,2),'23',1,0)),'00')"23",
to_char(sum(decode(substr(time,10,2),'00',1,0)),'00') "00",
to_char(sum(decode(substr(time,10,2),'01',1,0)),'00')"01",
to_char(sum(decode(substr(time,10,2),'02',1,0)),'00')"02",
to_char(sum(decode(substr(time,10,2),'03',1,0)),'00')"03",
to_char(sum(decode(substr(time,10,2),'04',1,0)),'00')"04",
to_char(sum(decode(substr(time,10,2),'05',1,0)),'00')"05",
to_char(sum(decode(substr(time,10,2),'06',1,0)),'00')"06"
from v\$log_history
group by substr(time,1,5);
EOF
cat menu.log|more
fi
}
getusers()
{
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500

column pu format a8 heading 'O/S|Login|ID' justify left
column su format a16 heading 'Oracle|User ID' justify left
column stat format a8 heading 'Session|Status' justify left
column ssid format 999999 heading 'Oracle|Session|ID' justify right
column sser format 999999 heading 'Oracle|Serial|No' justify right
column spid format 999999 heading 'UNIX|Process|ID' justify right

select S.osuser pu,
       s.username su,
       s.status stat,
       s.sid ssid,
       s.serial# sser,
       lpad(p.spid,7) spid
from v\$process p,
     v\$session s
     where    p.addr=s.paddr
and      s.username is not null
order by S.status ;
EOF
cat menu.log |more
}
get_rollback_info ()
{
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
col segment_name format a12 heading "Segment|Name"
col tablespace_name format a12 heading "Tablespace|Name"
col status format a10
col round(sum(initial_extent/1024)) Format 999,999 heading "Initial (Kb)"
col round(sum(next_extent/1024)) format 999,999 heading "Next (Kb)"
col max_extents format 9999999999 heading "Max|Extents"
select segment_name, tablespace_name, status,round(sum(initial_extent/1024)),
round(sum(next_extent/1024)),max_extents from dba_rollback_segs
group by segment_name, tablespace_name,status,max_extents;
EOF
cat menu.log |more
}
get_tablespace_info ()
{
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >version.log
select banner from v\$version;
EOF
cat version.log |egrep "8.1|9.2|9.0"|grep -v grep >/dev/null
if [ $? -eq 0 ]
then
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
col extent_management format a12 heading 'Extent|Management'
col allocation_type format a12 heading 'Allocation|Type'
select a.tablespace_name,a.status,contents,extent_management,
allocation_type, round(sum(b.bytes/1048576)) "Size (Mb)"
from
dba_tablespaces a, dba_data_files b
where a.tablespace_name=b.tablespace_name
group by a.tablespace_name,a.status,a.contents,a.extent_management,
a.allocation_type
order by  1;
EOF
cat menu.log |more
else
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
select a.tablespace_name,a.status,contents, 
round(sum(b.bytes/1048576)) "Size (Mb)"
from
dba_tablespaces a, dba_data_files b
where a.tablespace_name =b.tablespace_name
group by a.tablespace_name,a.status,contents
order by  1;
EOF
cat menu.log |more
fi
}
get_tablespace_info_7 ()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
select tablespace_name,status,contents from
dba_tablespaces order by tablespace_name;
EOF
cat menu.log |more
}

get_full90 ()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
  set pagesize 300
     set linesize 100
       column tablespace_name format a15 heading 'Tablespace'
    column sumb format 999,999,999
    column extents format 9999
    column bytes format 999,999,999,999
    column largest format 999,999,999,999
    column Tot_Size format 999,999 Heading 'Total Size(Mb)'
    column Tot_Free format 999,999,999 heading 'Total Free(Kb)'
    column Pct_Free format 999.99 heading '% Free'
         column Max_Free format 999,999,999 heading 'Max Free(Kb)'
ttitle center 'Tablespaces With Less Than 10% Free Space' skip 2
    set echo -e off


    select a.tablespace_name,sum(a.tots/1048576) Tot_Size,
    sum(a.sumb/1024) Tot_Free,
    sum(a.sumb)*100/sum(a.tots) Pct_Free
        from
    (
    select tablespace_name,0 tots,sum(bytes) sumb
      from dba_free_space a
    group by tablespace_name
    union
     select tablespace_name,sum(bytes) tots,0 from
      dba_data_files
     group by tablespace_name) a
     group by a.tablespace_name
having  sum(a.sumb)*100/sum(a.tots) < 10
order by pct_free;
EOF
cat menu.log |more
}
get_free_space()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
      set linesize 500
        column tablespace_name format a15 heading 'Tablespace'
     column sumb format 999,999,999
     column extents format 9999
     column bytes format 999,999,999,999
     column largest format 999,999,999,999
     column Tot_Size format 999,999 Heading 'Total Size(Mb)'
     column Tot_Free format 999,999,999 heading 'Total Free(Kb)'
     column Pct_Free format 999.99 heading '% Free'
          column Max_Free format 999,999,999 heading 'Max Free(Kb)'


     select a.tablespace_name,sum(a.tots/1048576) Tot_Size,
     sum(a.sumb/1024) Tot_Free,
     sum(a.sumb)*100/sum(a.tots) Pct_Free
         from
     (
     select tablespace_name,0 tots,sum(bytes) sumb
       from dba_free_space a
     group by tablespace_name
     union
     select tablespace_name,sum(bytes) tots,0 from
      dba_data_files
     group by tablespace_name) a
     group by a.tablespace_name
order by pct_free;
EOF
cat menu.log|more
}
get_oratab_value()
{
        A=`grep -i "^"$1" *:" $ORATAB|awk -F':' '{print $'$2'}'`
        echo -e "$A\c"
}                                                      
oracle_home()
{
echo -e '$ORACLE_HOME Locations:\n'
echo -e
echo -e "`cat $ORATAB | awk -F: '{ print $2 }'|sort -u`"
echo -e                                                                
}
get_db_files()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
Prompt
Prompt Control Files Location >>>>
col name  format a60 heading "Control Files"

select name
from   sys.v_\$controlfile
/

Prompt
Prompt Redo Log File Locations >>>>
Prompt

col Grp    format 9999
col member format a50 heading "Online REDO Logs"
col File#  format 9999
col name   format a50 heading "Online REDO Logs"
break on Grp
select group#,member
from   sys.v_\$logfile
/


Prompt Data Files Locations >>>>

col Tspace    format a15
col status    format a3  heading Sta
col Id        format 99
col Mbyte     format 9999
col name      format a50 heading "Database Data Files"
col Reads     format 99,999,999
col Writes    format 99,999,999

break on report
compute sum of Mbyte on report

select F.file_id Id,
       F.file_name name,
       F.bytes/(1024*1024) Mbyte,
       decode(F.status,'AVAILABLE','OK',F.status) status,
       F.tablespace_name Tspace
from   sys.dba_data_files F
order by tablespace_name;
EOF
cat menu.log |more
}
machine_activity()
{
up=`uptime |awk -F',' '{print $1}'`
load1=`uptime |awk -F',' '{print $4}'`
load2=`uptime |awk -F',' '{print $5}'`
load3=`uptime |awk -F',' '{print $6}'`        
echo -e  "\t\tMachine Load Statistics as on" $up
echo -e
echo -e "$load1 (last 1 minute), $load2 (last 5 minutes), $load3 (last 15 minutes)"
echo -e                                                                           
echo -e "Number Of Oracle Instances Running : `ps -ef |grep ora_pmon|grep -v grep|wc -l`"
echo -e
echo -e "Number of connected Oracle sessions (Dedicated):`ps -ef |grep -v ora_|grep LOCAL |wc -l`"
echo -e                 
echo -e
echo -e "\t\t\t\tTop 10 CPU Users"
echo -e "***********************************************************************"
echo -e                                                                          
uname -a |grep SUN > /dev/null
                if [ $? = 0 ]
                then
/usr/ucb/ps aux |head -10
else
ps aux |head -10                   
fi
}
machine ()
{
tput clear
echo -e "******************************************************************"
echo -e " Information for UNIX node : `hostname`"
echo -e "*****************************************************************"
echo -e
CPU=`psrinfo -v|grep "Status of processor"|wc -l`
MEM=`prtconf |grep -i mem|awk '{ if (NR == 1) print $0 }' `
up=`uptime |awk -F',' '{print $1}'`
load1=`uptime |awk -F',' '{print $4}'`
load2=`uptime |awk -F',' '{print $5}'`
load3=`uptime |awk -F',' '{print $6}'`
last_reboot=`who -b |awk '{ print $4" " $5" "$6 }'`
echo -e "Machine Type:`uname -a`"
echo -e
echo -e "Number of CPU's:"  $CPU
echo -e
echo -e  $MEM
echo -e
echo -e "Swap Space: `swap -s`"
echo -e                                         
echo -e "Last Reboot Time : $last_reboot"
}

Yy()  # For reading y/n
{
        read ANS
        if [ "$ANS" = "Y" -o "$ANS" = "y" ]
        then
                echo -e y
        fi
}               

check_disk_space()
{
df -ek |  awk '{  printf "%-5s %-20s %-50s\n",$5,$4,$6}' |tr -s '%' ' '|awk '{if ($1 >= 90) printf  "%5s%%  %-20s %-50s\n",$1,$2,$3 } ' | sort -r
}                   
check_free_space()
{
df -ek |awk '{  printf "%-20s %-15s %-15s %-5s\n",$6,$2,$4,$5}' |tr -s '%' ' '|awk '{if ($2 != 0) printf "%-20s %-15s  %-15s %5s%% \n",$1,$2,$3,$4 } ' | sort -n +2 |more
}

get_waits_segment()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log 
col sid format 99999
col event format a25
col p1text format a10
col p2text format a10
col p3text format a10
set pagesize 500
set linesize 500
select sid, event, p1text, p1, p2text , p2 
from  v\$session_wait
where
sid between 10 and 1000
and event not like 'SQL*Net%'
and event not like '%rdbms%'
;
EOF
cat menu.log |more
}
get_waits_segment_dtl()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
col sid format 99999
col event format a25
col p1text format a10
col p2text format a10
col p3text format a10
set pagesize 500
set linesize 500
select sid, event, p1text, p1, p2text , p2
from  v\$session_wait
where
sid between 10 and 1000
and event  like 'db%'
;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]                
then
cat menu.log |more                        
echo -e
echo -e "Please Enter The Datafile#  (P1): \c"
read df
echo -e 
echo -e "Please Enter The Block Number (P2):  \c"
read block
echo -e
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log 
set pagesize 500
set linesize 500
col owner format a20
col segment_type format a20
col segment_name format a30
col tablespace_name format a20
select owner, segment_name, segment_type, tablespace_name
from dba_extents
where file_id =$df
and $block  between block_id and block_id + blocks -1
/
EOF
cat menu.log |more 
fi
}
get_waits_io()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log    
SELECT s.sql_hash_value
  FROM V\$SESSION s, V\$SESSION_WAIT w
 WHERE w.event  in  ('db file scattered read','db file sequential read')
   AND w.sid = s.sid ;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]
then
cat menu.log |more
echo -e
echo -e "Please Enter The Hash Value#: \c"
read hash                               
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
select sql_text from v\$sqlarea where hash_value=$hash;
EOF
cat menu.log|more
fi
}
get_waits_session()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log   
col username format a15
col sid format 99999
col program format a30
col state format a15
col event format a25
col wait_time format 99999999
set pagesize 800
set linesize 800
select s.sid, s.username, s.program, se.event, se.state, se.wait_time
from v\$session s, v\$session_wait se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and se.event not like '%rdbms%'
and s.username is not null
order by se.wait_time;
EOF
cat menu.log |more 
}
get_waits_session_dtl()
{
echo -e 
echo -e "\t\t\tSession wait details ......."
echo -e "*************************************************************************"
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
col username format a15
col sid format 99999
col program format a30
col event format a25
col status format a10
col total_waits format 99999999
set pagesize 500
set linesize 500
select s.username, s.sid, se.event, se.total_waits
from v\$session s, v\$session_event se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and s.username is not null
and s.status='ACTIVE'
order by se.total_waits
/
EOF
cat menu.log |more 
}
get_waits_instance()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
set pagesize 800
set linesize 800
col event format a30
select  event, total_waits, total_timeouts, time_waited
from v\$system_event
where event not like 'SQL*Net%'
order by total_waits;
EOF
cat menu.log |head -2
cat menu.log |tail -10

$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
Prompt 
Prompt "Class Of Waits Since Instance Startup"
prompt
select class,count from v\$waitstat order by count;
EOF
cat menu.log|more
}

setsid()
{
        if [ $# = 0 ]
        then
                return
        fi
        ORACLE_SID=$1; export ORACLE_SID
        ORACLE_HOME=`get_oratab_value $1 2`; export ORACLE_HOME
}                           
fn2()
{
tput clear
 get_default_tablespace
}
fn1()
{
get_DBA_grantee
}
fn3()
{
tput clear
get_role_grantees
}
fn4()
{
get_user_grantees
}
fn5()
{
get_role_sys_privs
}
fn6()
{
get_user_sys_privs
}
fn7()
{
get_role_tab_privs
}

fn8()
{
get_locked_objects
}
fn9()
{
get_file_io
}
###The choice loop
while [ 1 ]        
do
        tput clear
 echo -e "\n"
        echo -e "\t"
        echo -e "\t#############################################################"
        echo -e "\t\t\tDatabase Security Menu - `tput smso`$Yellow$tns`tput rmso`\t"
        echo -e "\t#############################################################"
        echo -e "\t"
	echo -e "\t(1) Users Granted DBA Role "
	echo -e "\t(2) Users With "SYSTEM" Tablespace As Default"
	echo -e "\t(3) Roles ====>> Users"
	echo -e "\t(4) Users ====>> Roles"
	echo -e "\t(5) System Privileges Granted To Roles"
	echo -e "\t(6) System Privileges Granted To Users"
	echo -e "\t(7) Object Privileges Granted To Roles/Users (by user/role)"
	echo -e "\t(8) Object Privileges Granted To Roles/Users (by table)"
 echo -e "\n"
        echo -e "\tEnter your choice (q to quit): \c             "
        echo -e "\n"
        echo -e "\t#############################################################"
tput cup 17 40

 
        CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
				main 
				#exit [ 0 ]
		else
        case $CHOICE in
                1) tput clear;get_DBA_grantee ;;
                2) tput clear;get_default_tablespace ;;
                3) tput clear;get_role_grantees ;;
                4) tput clear;get_user_grantees ;;
                5) tput clear;get_role_sys_privs ;;
                6) tput clear;get_user_sys_privs ;;
                7) tput clear;get_role_tab_privs ;;
                8) tput clear; get_table_privs ;;
        esac
        if [ "$CHOICE2" = "q" -o "$CHOICE2" = "Q"  -o "$CHOICE2" = "END" ]
        then
                continue
        fi
#        echo -e "Hit return to continue\c"
#        #line                          
fi
done                             


}

object( )
{




MC=`uname -a|awk '{print $2}'|tr 'a-z' 'A-Z'`
MENU_NAME=${MENU_NAME:-"DBA Menu - $MC"}  
if [ -f /var/opt/oracle/oratab ]
then
        ORATAB=/var/opt/oracle/oratab; export ORATAB
elif [ -f /etc/oratab ]
then
        ORATAB=/etc/oratab; export ORATAB
else
        echo -e "Could not find oratab...quiting..."
        exit 1
fi              
#Get the list of databases
SID_LIST=`grep -v '^#' $ORATAB|awk -F':' '{print $1}'`
SID_COUNT=`echo -e $SID_LIST|wc -w`
SID_COUNT=`echo -e $SID_COUNT` 
L_Passwd=`awk '{print $0}' monitor_passwd`
get_tns_connect()
{
choice=""
until [ -n  "$choice" ]
do
echo -e "Please Enter The TNS Connect String "
read tns
awk '{
   if ($2 == "=" && $1 !~ /^\(/) print $1
   else
   if ($1 ~ /\=/ && $1 !~ /^\(/) {
        strng = substr($1,1,length($1)-1)
        print strng
        }
   }' $ORACLE_HOME/network/admin/tnsnames.ora |grep -iw $tns >/dev/null 
if [ $? -eq 0 ]
then
echo -e "Connecting to Database $tns ...."
choice=TRUE
else echo -e "Wrong TNS connect string"
fi
done
}
get_nospace_to_extend()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500
col owner format a15
col tablespace format a10
col obj_name format a20 heading 'Name'
col obj_type format a8 heading 'Type'
select 
 i.owner                 owner,
 i.tablespace       tablespace,
 i.obj_name,
 i.obj_type,
 nxt_ext ,
 biggest
 from  
(select max(bytes)/1024 biggest, tablespace_name 
 from dba_free_space group by tablespace_name) f  ,
(select 
 owner                 owner,
 tablespace_name       tablespace,
 segment_name          obj_name,
 segment_type          obj_type,
  max(bytes)/1024      nxt_ext
from dba_extents 
 group by owner, tablespace_name,
         segment_name, segment_type,
        bytes
) i
 where i.tablespace = f.tablespace_name
and nxt_ext > biggest
/
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                        
get_nearing_maxextents()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
column owner           format a12    heading 'OWNER'
column segment_type    format a5     heading 'TYPE'
column tablespace_name format a12    heading 'TABLESPACE'
column segment_name    format a20    heading 'NAME'
column max_extents     format 999    heading 'MAX'
column extents         format 999    heading 'EXTS'
column diff             format 999    heading 'DIFF'

break on owner skip 1 on tablespace_name on segment_type 

select  owner,
        tablespace_name,
        segment_type,
        segment_name,
        max_extents,
        extents,
(max_extents-extents) diff
          from  sys.dba_segments
 where  max_extents - extents       <  20
   and  segment_type != 'ROLLBACK'
   and  segment_type != 'CACHE'
 order  by owner,diff desc
;
EOF
cat menu.log|more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                        
get_invalid()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
Prompt Checking For ALL INVALID Objects .....
select owner,count(*) "Count(INVALID)" from dba_objects
where status='INVALID'
group by owner
/
EOF
cat menu.log |more
echo -e
echo -e
echo -e "Please Enter The Object Owner"
read ownr
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
col object_name format a25 heading Name
col object_type format a15 heading Type
col "Modified On" format a20
prompt
select object_type,object_name,to_char(last_ddl_time,'DD-MON-RR:HH24:Mi:ss') "Modified On" from dba_objects
where owner=upper('$ownr')
and status='INVALID'
order by  3
/
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                             
get_object_cnt()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The Schema Owner: "
read schema
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
select object_type,count(*) from dba_objects 
where owner=upper('$schema')
group by cube(object_type);
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_indexes()
{
rep=""
while [ "$rep" != "q" ]
do
echo -e "Please Enter The Name Of The Table Owner"
read ownr
echo -e
echo -e "Please Enter The Table Name:"
read tab
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
break on index_name skip 1
col a.index_name format a20 heading "Index"
col column_name format a15 heading "Column"
col column_position format 999 heading "Position"
select a.index_name, column_name,column_position 
 from dba_ind_columns b, dba_indexes a
where a.index_name=b.index_name
and a.owner=upper('$ownr')
and a.table_name = upper('$tab')
order by index_name, column_position 
/
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}                             


get_db_big_seg ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
col	owner format a15
col	segment_name format a30
col	segment_type format a15
col	mb format 999,999,999
select  owner
,	segment_name
,	segment_type
,	mb
from	(
	select	owner
	,	segment_name
	,	segment_type
	,	bytes / 1024 / 1024 "MB"
	from	dba_segments
	order	by bytes desc
	)
where	rownum < 11
/
EOF
cat menu.log |more
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}



get_tblspc_big_seg ()
{
rep=""
while [ "$rep" != "q" ]
do
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500                                     
col segment format a40
col tablespace format a12 heading "Tablespace"
col Segsize format a10 heading "Segment|Size(Mb)"
col tssize format a10 heading "Tablespace|Size(Mb)"
select a.ts tablespace,min(a.seg) || decode(count(*),1,'(none)',2,' ',' +') segment,
to_char(round(sum(a.segb/1048576)/decode(count(*),1,1,count(*)-1))) "SegSize",
   to_char(round(sum(a.tsb/1048576))) tssize,
   to_char(sum(a.segb)/decode(count(*),1,1,count(*)-1)/decode(sum(a.tsb),0,1,
      sum(a.tsb))*100,'990.99')
      "    PCT"
from (
   select tablespace_name ts,segment_name seg,
      sum(bytes) segb,00000000000000 tsb
   from dba_segments d
   where tablespace_name not in ('SYSTEM','RBS','TEMP','TOOLS')
      group by tablespace_name,segment_name
   having sum(bytes) = (
      select max(sum(bytes))
      from dba_segments c
      where c.tablespace_name = d.tablespace_name
          group by c.segment_name)
   union all
   select tablespace_name,'~',0,sum(bytes)
   from dba_segments
   where tablespace_name not in ('SYSTEM','RBS','TEMP','TOOLS')
   group by tablespace_name) a
group by a.ts
order by 5;
EOF
tput clear
cat menu.log |more                           
echo -e "Continue? ("q" to return to main menu)"
read rep
done
}
get_role_sys_privs()
{
get_tns_connect
echo -e "Please Enter The Role Name or "ALL" For All Database Roles"
read role
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
column role format a30 heading 'Role'
column privilege format a30 heading 'Privilege'
column opt format a6 heading 'Admin.|Option'
select  role, privilege, lpad(admin_option,4) "opt"
from dba_sys_privs, dba_roles
where  role=grantee
and
role like decode(upper('$role'),'ALL','%',upper('$role'))
order by role, privilege;
EOF
tput clear
cat menu.log |more
}                                               
get_role_tab_privs()
{
get_tns_connect
echo -e 'Please enter Grantee (User Or Role) : '
read grantee
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
col grantee format a10 heading 'Grantee'
col table_name format a35 heading 'Object Name'
col type format a12 heading 'Type'
select  t.grantee grantee,t.table_name table_name,   O.OBJECT_TYPE TYPE,
  max(decode( t.privilege,'SELECT','X',null)) S,
  max(decode( t.privilege,'INSERT','X',null))  I,
  max(decode( t.privilege,'UPDATE','X',null)) U,
  max(decode( t.privilege,'DELETE','X',null)) D,
  max(decode( t.privilege,'EXECUTE','X',null)) E
from 
 DBA_OBJECTS O , dba_tab_privs t
where
T.TABLE_NAME = O.OBJECT_NAME(+)
and t.owner = o.owner
and  grantee = upper('$grantee')
group by   T.table_name, T.grantee,OBJECT_TYPE 
order by 2;
EOF
tput clear
cat menu.log |more
}                                               
get_top_cpu_users()
{
echo -e "\t\t\t\tTop 10 CPU Users"
echo -e "***********************************************************************"
echo -e
uname -a |grep SUN > /dev/null
                if [ $? = 0 ]
                then
/usr/ucb/ps aux |head -10
else
ps aux |head -10
fi
echo -e "***********************************************************************"
echo -e
}              
get_top_sql_user()
{
echo -e "Please Enter The UNIX Process ID"
read SPID
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 50000
set linesize 30000
set long 500000
set head off
select
       s.username su,
       substr(sa.sql_text,1,540) txt
from v\$process p,
     v\$session s,
     v\$sqlarea sa
where    p.addr=s.paddr
and      s.username is not null
and      s.sql_address=sa.address(+)
and      s.sql_hash_value=sa.hash_value(+)
and spid=$SPID;
EOF
cat menu.log |more
}                       
get_logswitch()
{
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >version.log
select banner from v\$version;
EOF
cat version.log |egrep "8.1|9.2|9.0"|grep -v grep >/dev/null
if [ $? -eq 0 ]
then
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
prompt
prompt "Morning .........."
select to_char(first_time,'DD/MON') day,
to_char(sum(decode(to_char(first_time,'HH24'),'07',1,0)),'000')"07",
to_char(sum(decode(to_char(first_time,'HH24'),'08',1,0)),'000')"08",
to_char(sum(decode(to_char(first_time,'HH24'),'09',1,0)),'000')"09",
to_char(sum(decode(to_char(first_time,'HH24'),'10',1,0)),'000')"10",
to_char(sum(decode(to_char(first_time,'HH24'),'11',1,0)),'000')"11",
to_char(sum(decode(to_char(first_time,'HH24'),'12',1,0)),'000')"12",
to_char(sum(decode(to_char(first_time,'HH24'),'13',1,0)),'000')"13",
to_char(sum(decode(to_char(first_time,'HH24'),'14',1,0)),'000')"14",
to_char(sum(decode(to_char(first_time,'HH24'),'15',1,0)),'000')"15",
to_char(sum(decode(to_char(first_time,'HH24'),'16',1,0)),'000')"16",
to_char(sum(decode(to_char(first_time,'HH24'),'17',1,0)),'000')"17",
to_char(sum(decode(to_char(first_time,'HH24'),'18',1,0)),'000')"18"
from v\$log_history
WHERE TRUNC(FIRST_TIME) > TRUNC(SYSDATE) - 7
group by to_char(first_time,'DD/MON');
prompt
prompt
Prompt "Evening ........"
prompt
select to_char(first_time,'DD/MON') day,
to_char(sum(decode(to_char(first_time,'HH24'),'19',1,0)),'000')"19",
to_char(sum(decode(to_char(first_time,'HH24'),'20',1,0)),'000')"20",
to_char(sum(decode(to_char(first_time,'HH24'),'21',1,0)),'000')"21",
to_char(sum(decode(to_char(first_time,'HH24'),'22',1,0)),'000')"22",
to_char(sum(decode(to_char(first_time,'HH24'),'23',1,0)),'000')"23",
to_char(sum(decode(to_char(first_time,'HH24'),'00',1,0)),'000') "00",
to_char(sum(decode(to_char(first_time,'HH24'),'01',1,0)),'000')"01",
to_char(sum(decode(to_char(first_time,'HH24'),'02',1,0)),'000')"02",
to_char(sum(decode(to_char(first_time,'HH24'),'03',1,0)),'000')"03",
to_char(sum(decode(to_char(first_time,'HH24'),'04',1,0)),'000')"04",
to_char(sum(decode(to_char(first_time,'HH24'),'05',1,0)),'000')"05",
to_char(sum(decode(to_char(first_time,'HH24'),'06',1,0)),'000')"06"
from v\$log_history
WHERE TRUNC(FIRST_TIME) > TRUNC(SYSDATE) - 7
group by to_char(first_time,'DD/MON');
EOF
else
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
select substr(time,1,5) day,
to_char(sum(decode(substr(time,10,2),'07',1,0)),'00')"07",
to_char(sum(decode(substr(time,10,2),'08',1,0)),'00')"08",
to_char(sum(decode(substr(time,10,2),'09',1,0)),'00')"09",
to_char(sum(decode(substr(time,10,2),'10',1,0)),'00')"10",
to_char(sum(decode(substr(time,10,2),'11',1,0)),'00')"11",
to_char(sum(decode(substr(time,10,2),'12',1,0)),'00')"12",
to_char(sum(decode(substr(time,10,2),'13',1,0)),'00')"13",
to_char(sum(decode(substr(time,10,2),'14',1,0)),'00')"14",
to_char(sum(decode(substr(time,10,2),'15',1,0)),'00')"15",
to_char(sum(decode(substr(time,10,2),'16',1,0)),'00')"16",
to_char(sum(decode(substr(time,10,2),'17',1,0)),'00')"17",
to_char(sum(decode(substr(time,10,2),'18',1,0)),'00')"18"
from v\$log_history
group by substr(time,1,5);
prompt
Prompt "Evening ......."
prompt
select substr(time,1,5) day,
to_char(sum(decode(substr(time,10,2),'19',1,0)),'00')"19",
to_char(sum(decode(substr(time,10,2),'20',1,0)),'00')"20",
to_char(sum(decode(substr(time,10,2),'21',1,0)),'00')"21",
to_char(sum(decode(substr(time,10,2),'22',1,0)),'00')"22",
to_char(sum(decode(substr(time,10,2),'23',1,0)),'00')"23",
to_char(sum(decode(substr(time,10,2),'00',1,0)),'00') "00",
to_char(sum(decode(substr(time,10,2),'01',1,0)),'00')"01",
to_char(sum(decode(substr(time,10,2),'02',1,0)),'00')"02",
to_char(sum(decode(substr(time,10,2),'03',1,0)),'00')"03",
to_char(sum(decode(substr(time,10,2),'04',1,0)),'00')"04",
to_char(sum(decode(substr(time,10,2),'05',1,0)),'00')"05",
to_char(sum(decode(substr(time,10,2),'06',1,0)),'00')"06"
from v\$log_history
group by substr(time,1,5);
EOF
cat menu.log|more
fi
}
getusers()
{
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set linesize 500
SET PAGESIZE 500

column pu format a8 heading 'O/S|Login|ID' justify left
column su format a16 heading 'Oracle|User ID' justify left
column stat format a8 heading 'Session|Status' justify left
column ssid format 999999 heading 'Oracle|Session|ID' justify right
column sser format 999999 heading 'Oracle|Serial|No' justify right
column spid format 999999 heading 'UNIX|Process|ID' justify right

select S.osuser pu,
       s.username su,
       s.status stat,
       s.sid ssid,
       s.serial# sser,
       lpad(p.spid,7) spid
from v\$process p,
     v\$session s
     where    p.addr=s.paddr
and      s.username is not null
order by S.status ;
EOF
cat menu.log |more
}
get_rollback_info ()
{
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
col segment_name format a12 heading "Segment|Name"
col tablespace_name format a12 heading "Tablespace|Name"
col status format a10
col round(sum(initial_extent/1024)) Format 999,999 heading "Initial (Kb)"
col round(sum(next_extent/1024)) format 999,999 heading "Next (Kb)"
col max_extents format 9999999999 heading "Max|Extents"
select segment_name, tablespace_name, status,round(sum(initial_extent/1024)),
round(sum(next_extent/1024)),max_extents from dba_rollback_segs
group by segment_name, tablespace_name,status,max_extents;
EOF
cat menu.log |more
}
get_tablespace_info ()
{
get_tns_connect
sqlplus -s ' / as sysdba ' <<EOF >version.log
select banner from v\$version;
EOF
cat version.log |egrep "8.1|9.2|9.0"|grep -v grep >/dev/null
if [ $? -eq 0 ]
then
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
col extent_management format a12 heading 'Extent|Management'
col allocation_type format a12 heading 'Allocation|Type'
select a.tablespace_name,a.status,contents,extent_management,
allocation_type, round(sum(b.bytes/1048576)) "Size (Mb)"
from
dba_tablespaces a, dba_data_files b
where a.tablespace_name=b.tablespace_name
group by a.tablespace_name,a.status,a.contents,a.extent_management,
a.allocation_type
order by  1;
EOF
cat menu.log |more
else
sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
select a.tablespace_name,a.status,contents, 
round(sum(b.bytes/1048576)) "Size (Mb)"
from
dba_tablespaces a, dba_data_files b
where a.tablespace_name =b.tablespace_name
group by a.tablespace_name,a.status,contents
order by  1;
EOF
cat menu.log |more
fi
}
get_tablespace_info_7 ()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 200
 col tablespace_name format A20 heading "Tablespace|Name"
select tablespace_name,status,contents from
dba_tablespaces order by tablespace_name;
EOF
cat menu.log |more
}

get_full90 ()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
  set pagesize 300
     set linesize 100
       column tablespace_name format a15 heading 'Tablespace'
    column sumb format 999,999,999
    column extents format 9999
    column bytes format 999,999,999,999
    column largest format 999,999,999,999
    column Tot_Size format 999,999 Heading 'Total Size(Mb)'
    column Tot_Free format 999,999,999 heading 'Total Free(Kb)'
    column Pct_Free format 999.99 heading '% Free'
         column Max_Free format 999,999,999 heading 'Max Free(Kb)'
ttitle center 'Tablespaces With Less Than 10% Free Space' skip 2
    set echo -e off


    select a.tablespace_name,sum(a.tots/1048576) Tot_Size,
    sum(a.sumb/1024) Tot_Free,
    sum(a.sumb)*100/sum(a.tots) Pct_Free
        from
    (
    select tablespace_name,0 tots,sum(bytes) sumb
      from dba_free_space a
    group by tablespace_name
    union
     select tablespace_name,sum(bytes) tots,0 from
      dba_data_files
     group by tablespace_name) a
     group by a.tablespace_name
having  sum(a.sumb)*100/sum(a.tots) < 10
order by pct_free;
EOF
cat menu.log |more
}
get_free_space()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
      set linesize 500
        column tablespace_name format a15 heading 'Tablespace'
     column sumb format 999,999,999
     column extents format 9999
     column bytes format 999,999,999,999
     column largest format 999,999,999,999
     column Tot_Size format 999,999 Heading 'Total Size(Mb)'
     column Tot_Free format 999,999,999 heading 'Total Free(Kb)'
     column Pct_Free format 999.99 heading '% Free'
          column Max_Free format 999,999,999 heading 'Max Free(Kb)'


     select a.tablespace_name,sum(a.tots/1048576) Tot_Size,
     sum(a.sumb/1024) Tot_Free,
     sum(a.sumb)*100/sum(a.tots) Pct_Free
         from
     (
     select tablespace_name,0 tots,sum(bytes) sumb
       from dba_free_space a
     group by tablespace_name
     union
     select tablespace_name,sum(bytes) tots,0 from
      dba_data_files
     group by tablespace_name) a
     group by a.tablespace_name
order by pct_free;
EOF
cat menu.log|more
}
get_oratab_value()
{
        A=`grep -i "^"$1" *:" $ORATAB|awk -F':' '{print $'$2'}'`
        echo -e "$A\c"
}                                                      
oracle_home()
{
echo -e '$ORACLE_HOME Locations:\n'
echo -e
echo -e "`cat $ORATAB | awk -F: '{ print $2 }'|sort -u`"
echo -e                                                                
}
get_db_files()
{
get_tns_connect
        $ORACLE_HOME/bin/sqlplus -s ' / as sysdba ' <<EOF >menu.log
set pagesize 500
set linesize 500
Prompt
Prompt Control Files Location >>>>
col name  format a60 heading "Control Files"

select name
from   sys.v_\$controlfile
/

Prompt
Prompt Redo Log File Locations >>>>
Prompt

col Grp    format 9999
col member format a50 heading "Online REDO Logs"
col File#  format 9999
col name   format a50 heading "Online REDO Logs"
break on Grp
select group#,member
from   sys.v_\$logfile
/


Prompt Data Files Locations >>>>

col Tspace    format a15
col status    format a3  heading Sta
col Id        format 99
col Mbyte     format 9999
col name      format a50 heading "Database Data Files"
col Reads     format 99,999,999
col Writes    format 99,999,999

break on report
compute sum of Mbyte on report

select F.file_id Id,
       F.file_name name,
       F.bytes/(1024*1024) Mbyte,
       decode(F.status,'AVAILABLE','OK',F.status) status,
       F.tablespace_name Tspace
from   sys.dba_data_files F
order by tablespace_name;
EOF
cat menu.log |more
}
machine_activity()
{
up=`uptime |awk -F',' '{print $1}'`
load1=`uptime |awk -F',' '{print $4}'`
load2=`uptime |awk -F',' '{print $5}'`
load3=`uptime |awk -F',' '{print $6}'`        
echo -e  "\t\tMachine Load Statistics as on" $up
echo -e
echo -e "$load1 (last 1 minute), $load2 (last 5 minutes), $load3 (last 15 minutes)"
echo -e                                                                           
echo -e "Number Of Oracle Instances Running : `ps -ef |grep ora_pmon|grep -v grep|wc -l`"
echo -e
echo -e "Number of connected Oracle sessions (Dedicated):`ps -ef |grep -v ora_|grep LOCAL |wc -l`"
echo -e                 
echo -e
echo -e "\t\t\t\tTop 10 CPU Users"
echo -e "***********************************************************************"
echo -e                                                                          
uname -a |grep SUN > /dev/null
                if [ $? = 0 ]
                then
/usr/ucb/ps aux |head -10
else
ps aux |head -10                   
fi
}
machine ()
{
tput clear
echo -e "******************************************************************"
echo -e " Information for UNIX node : `hostname`"
echo -e "*****************************************************************"
echo -e
CPU=`psrinfo -v|grep "Status of processor"|wc -l`
MEM=`prtconf |grep -i mem|awk '{ if (NR == 1) print $0 }' `
up=`uptime |awk -F',' '{print $1}'`
load1=`uptime |awk -F',' '{print $4}'`
load2=`uptime |awk -F',' '{print $5}'`
load3=`uptime |awk -F',' '{print $6}'`
last_reboot=`who -b |awk '{ print $4" " $5" "$6 }'`
echo -e "Machine Type:`uname -a`"
echo -e
echo -e "Number of CPU's:"  $CPU
echo -e
echo -e  $MEM
echo -e
echo -e "Swap Space: `swap -s`"
echo -e                                         
echo -e "Last Reboot Time : $last_reboot"
}

Yy()  # For reading y/n
{
        read ANS
        if [ "$ANS" = "Y" -o "$ANS" = "y" ]
        then
                echo -e y
        fi
}               

check_disk_space()
{
df -ek |  awk '{  printf "%-5s %-20s %-50s\n",$5,$4,$6}' |tr -s '%' ' '|awk '{if ($1 >= 90) printf  "%5s%%  %-20s %-50s\n",$1,$2,$3 } ' | sort -r
}                   
check_free_space()
{
df -ek |awk '{  printf "%-20s %-15s %-15s %-5s\n",$6,$2,$4,$5}' |tr -s '%' ' '|awk '{if ($2 != 0) printf "%-20s %-15s  %-15s %5s%% \n",$1,$2,$3,$4 } ' | sort -n +2 |more
}

get_waits_segment()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log 
col sid format 99999
col event format a25
col p1text format a10
col p2text format a10
col p3text format a10
set pagesize 500
set linesize 500
select sid, event, p1text, p1, p2text , p2 
from  v\$session_wait
where
sid between 10 and 1000
and event not like 'SQL*Net%'
and event not like '%rdbms%'
;
EOF
cat menu.log |more
}
get_waits_segment_dtl()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
col sid format 99999
col event format a25
col p1text format a10
col p2text format a10
col p3text format a10
set pagesize 500
set linesize 500
select sid, event, p1text, p1, p2text , p2
from  v\$session_wait
where
sid between 10 and 1000
and event  like 'db%'
;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]                
then
cat menu.log |more                        
echo -e
echo -e "Please Enter The Datafile#  (P1): \c"
read df
echo -e 
echo -e "Please Enter The Block Number (P2):  \c"
read block
echo -e
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log 
set pagesize 500
set linesize 500
col owner format a20
col segment_type format a20
col segment_name format a30
col tablespace_name format a20
select owner, segment_name, segment_type, tablespace_name
from dba_extents
where file_id =$df
and $block  between block_id and block_id + blocks -1
/
EOF
cat menu.log |more 
fi
}
get_waits_io()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log    
SELECT s.sql_hash_value
  FROM V\$SESSION s, V\$SESSION_WAIT w
 WHERE w.event  in  ('db file scattered read','db file sequential read')
   AND w.sid = s.sid ;
EOF
cat menu.log |grep '^no'
if [ $? = 1 ]
then
cat menu.log |more
echo -e
echo -e "Please Enter The Hash Value#: \c"
read hash                               
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
select sql_text from v\$sqlarea where hash_value=$hash;
EOF
cat menu.log|more
fi
}
get_waits_session()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log   
col username format a15
col sid format 99999
col program format a30
col state format a15
col event format a25
col wait_time format 99999999
set pagesize 800
set linesize 800
select s.sid, s.username, s.program, se.event, se.state, se.wait_time
from v\$session s, v\$session_wait se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and se.event not like '%rdbms%'
and s.username is not null
order by se.wait_time;
EOF
cat menu.log |more 
}
get_waits_session_dtl()
{
echo -e 
echo -e "\t\t\tSession wait details ......."
echo -e "*************************************************************************"
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
col username format a15
col sid format 99999
col program format a30
col event format a25
col status format a10
col total_waits format 99999999
set pagesize 500
set linesize 500
select s.username, s.sid, se.event, se.total_waits
from v\$session s, v\$session_event se
where s.sid=se.sid
and se.event not like 'SQL*Net%'
and s.username is not null
and s.status='ACTIVE'
order by se.total_waits
/
EOF
cat menu.log |more 
}
get_waits_instance()
{
. set$ORACLE_SID
$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
set pagesize 800
set linesize 800
col event format a30
select  event, total_waits, total_timeouts, time_waited
from v\$system_event
where event not like 'SQL*Net%'
order by total_waits;
EOF
cat menu.log |head -2
cat menu.log |tail -10

$ORACLE_HOME/bin/sqlplus -s monitor/$L_Passwd <<EOF >menu.log
Prompt 
Prompt "Class Of Waits Since Instance Startup"
prompt
select class,count from v\$waitstat order by count;
EOF
cat menu.log|more
}

setsid()
{
        if [ $# = 0 ]
        then
                return
        fi
        ORACLE_SID=$1; export ORACLE_SID
        ORACLE_HOME=`get_oratab_value $1 2`; export ORACLE_HOME
}                           
fn2()
{
tput clear
 get_nearing_maxextents
}
fn1()
{
get_nospace_to_extend
}
fn3()
{
tput clear
get_invalid
}
fn4()
{
get_indexes
}
fn5()
{
get_tblspc_big_seg
}
fn6()
{
get_user_sys_privs
}
fn7()
{
get_role_tab_privs
}

fn8()
{
get_locked_objects
}
fn9()
{
get_file_io
}
###The choice loop
while [ 1 ]        
do
        tput clear
 echo -e "\n"
        echo -e "\t"
        echo -e "\t#######################################################"
        echo -e "\t\t\tDatabase Objects Menu - `tput smso`$Yellow$tns`tput rmso`\t"
        echo -e "\t#######################################################"
        echo -e "\t"
	echo -e "\t(1) Objects which cannot extend"
	echo -e "\t(2) Objects nearing MAXEXTENTS"
	echo -e "\t(3) INVALID Objects "
	echo -e "\t(4) Indexes and Indexed Columns on Tables"
	echo -e "\t(5) Largest Segments - By Tablespace"
	echo -e "\t(6) Largest Segments - By Database"
	echo -e "\t(7) Count of Objects - By Owner"
 echo -e "\n"
        echo -e "\tEnter your choice (q to quit): \c             "
        echo -e "\n"
        echo -e "\t#######################################################"
tput cup 16 40

 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
				main 
				#exit [ 0 ]
		else
		case $CHOICE in
                1) get_nospace_to_extend  ;;
                2) get_nearing_maxextents  ;;
                3) get_invalid  ;;
                4) get_indexes ;;
                5) get_tblspc_big_seg  ;;
                6) get_db_big_seg  ;;
                7) get_object_cnt  ;;
        esac
 if [ "$CHOICE2" = "q" -o "$CHOICE2" = "Q"  -o "$CHOICE2" = "END" ]
        then
                continue
        fi
#        echo -e "Hit return to continue\c"
#        #line                          
fi
done    
}

perfomance_2( )
{


while [ 1 ]
do
 #       tput clear
        echo -e "\n"
echo -e "\t\t\t$MESSAGE\t"
echo -e
#echo -e "\t\t\tConnected to Database- `tput smso`$Yellow$tns`tput rmso`\t"
echo -e "\t###################### TABLESPACE : ###################"
echo -e "\t"
echo -e "\t#######################################################"
echo -e "\t"
echo -e "\t(1) Latency histogram for event "db file sequential read" from V\$EVENT_HISTOGRAM                                         "
echo -e "\t(2) Displays significant event metrics                                          "
echo -e "\t(3) Displays files with significant IO activity                                        "
echo -e "\t(4) IO metric values 11g                                         "
echo -e "\t(5) IO metric values 11g all                                          "
echo -e "\t(6) Running jobs                                          "
echo -e "\t(7) load on instances                                          "
echo -e "\t(8) locks all                                         "
echo -e "\t(9) database sql id details                                          "
echo -e "\t(10) session logops                                         "
echo -e "\t(11) session logops all                                          "
echo -e "\t(12) SGA size                                           "
echo -e "\t(13) SGA size all                                          "
echo -e "\t(14) SGA componat size                                           "
echo -e "\t(15) shared_pool_size size                                          "
echo -e "\n"
echo -e "\tEnter your choice (q to quit): \c                             "
echo -e "\n"
echo -e "\t########################################################"
#tput cup 16 40
 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
#itput clear
              main
########################################tablespace KB #####################################################3
        elif [ "$CHOICE" = "1"  ]
        then

        rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

set serverout on
set verify off

COLUMN p1 NEW_VALUE 1
COLUMN p2 NEW_VALUE 2
set termout off	
SELECT null p1, null p2 FROM dual WHERE 1=2;
-- NOTE the default values for <delay> and <event> parameters are hard coded here
SELECT nvl('&1','5') p1, nvl('&2','db file sequential read') p2 from dual;  
set termout on

prompt
prompt Latency histograms for Oracle wait events on local instance.
prompt Usage: @ehm_local <delta time> <event>
prompt Please wait for &1 sec (DeltaT = &1 sec) for snapshot N.2 and script output.

DECLARE
  v_sleep_time                 number;
  v_event_name                 varchar2(50) := '&2';
  v_delta_waits                number;
  v_delta_waits_per_sec        number;
  v_delta_time_waited_estimate number;
  v_delta_time_waited_micro    number; 
  v_avg_wait_time_milli        number;
  v_latencybin                 varchar2(100);

  CURSOR c1 IS
    SELECT event, wait_time_milli, sum(wait_count) wait_count, max(last_update_time) last_update_time
    FROM v\$event_histogram
    WHERE event = v_event_name
	GROUP BY event, wait_time_milli
	ORDER BY event, wait_time_milli;
	
  CURSOR c2 IS
    SELECT event, sum(time_waited_micro) time_waited_micro, sum(total_waits) total_waits
    FROM v\$system_event
    WHERE event = v_event_name
	GROUP BY event
	ORDER BY event;

  TYPE EventHisto IS TABLE OF c1%ROWTYPE;
  TYPE SysEvent   IS TABLE OF c2%ROWTYPE;

  t0_histval  EventHisto;  -- nested table of records for t0 snapshot
  t1_histval  EventHisto;  -- nested table of records for t1 snapshot
  t0_eventval SysEvent;    -- nested table of records for t0 snapshot
  t1_eventval SysEvent;    -- nested table of records for t1 snapshot

BEGIN
  -- input validation
  BEGIN
     v_sleep_time := TO_NUMBER('&1');
	 IF (v_sleep_time <= 0) THEN
        raise value_error;
	 END IF;
  EXCEPTION	 
       WHEN value_error THEN
	     RAISE_APPLICATION_ERROR(-20001,'Wait time must be numeric and >0. Example use wait time = 10');
  END;

  -- collect t0 data
  OPEN c1;
  OPEN c2;
  FETCH c1 BULK COLLECT INTO t0_histval;
  FETCH c2 BULK COLLECT INTO t0_eventval; 
  CLOSE c1;
  CLOSE c2;

  IF t0_eventval.COUNT <=0 THEN
      RAISE_APPLICATION_ERROR(-20001,'Not enough data. Probably wrong event name. Tip, try event = "db file sequential read".');
  END IF;

  IF t0_eventval.COUNT >= 100 THEN
    RAISE_APPLICATION_ERROR(-20002,'Too many values, soft limit set to 100');
  END IF;

  -- put wait time here note user needs exec privilege on dbms_lock  
  sys.DBMS_LOCK.SLEEP (v_sleep_time);

  -- collect t1 data
  OPEN c1;
  OPEN c2;
  FETCH c1 BULK COLLECT INTO t1_histval;
  FETCH c2 BULK COLLECT INTO t1_eventval; 
  CLOSE c1;
  CLOSE c2;

  -- check and report error if number of points is different between the two snapshots
  -- (rare, but can happen if a new histogram bin has been created)
  IF t0_histval.COUNT <> t1_histval.COUNT THEN
     RAISE_APPLICATION_ERROR(-20003,'Number of histogram bins changed during collection. Cannot handle it.');
  END IF;

  -- print out results
  -- compute delta values and print. 
  -- format with rpad to keep column width constant

  -- Latency histogram from v\$event_histogram
  DBMS_OUTPUT.PUT_LINE(chr(13));
  DBMS_OUTPUT.PUT_LINE('Latency histogram for event "&2" from v\$EVENT_HISTOGRAM:');
  DBMS_OUTPUT.PUT_LINE(chr(13));
  DBMS_OUTPUT.PUT_LINE ('Latency Bucket    Num Waits/DeltaT  Wait Time/DeltaT  Event Name                 Last Update Time');
  DBMS_OUTPUT.PUT_LINE ('(millisec)        (Hz)              (millisec/sec)                                               ');
  DBMS_OUTPUT.PUT_LINE ('----------------  ----------------  ----------------  -------------------------  -----------------------------------');

  FOR i IN t1_histval.FIRST .. t1_histval.LAST LOOP
    v_delta_waits := t1_histval(i).wait_count - t0_histval(i).wait_count;
    v_delta_waits_per_sec := round(v_delta_waits / v_sleep_time,1);
	v_delta_time_waited_estimate := round(0.75 * t1_histval(i).wait_time_milli * v_delta_waits_per_sec,1);  -- estimated value
	IF (t1_histval(i).wait_time_milli <> 1) THEN
		v_latencybin := to_char(t1_histval(i).wait_time_milli/2) ||' -> ' || to_char(t1_histval(i).wait_time_milli);
    ELSE
		v_latencybin := '0 -> 1';
	END IF;
    DBMS_OUTPUT.PUT_LINE (
        rpad(v_latencybin,16,' ')||'  '||
        lpad(to_char(v_delta_waits_per_sec),16,' ')||'  '||
        lpad(to_char(v_delta_time_waited_estimate),16,' ')||'   '||
        rpad(t1_histval(i).event,24,' ') ||' '||
        t1_histval(i).last_update_time 
      );
    END LOOP;

  -- This is the summary from v\$system_event
  DBMS_OUTPUT.PUT_LINE(chr(13));
  DBMS_OUTPUT.PUT_LINE('Average values from v\$SYSTEM_EVENT:');
  DBMS_OUTPUT.PUT_LINE(chr(13));
  DBMS_OUTPUT.PUT_LINE ('Mean Wait Time    Num Waits/DeltaT  Wait Time/DeltaT  Event Name               ');
  DBMS_OUTPUT.PUT_LINE ('(millisec)        (Hz)              (millisec/sec)                             ');
  DBMS_OUTPUT.PUT_LINE ('----------------  ----------------  ----------------  -------------------------');

  FOR i IN t1_eventval.FIRST .. t1_eventval.LAST LOOP
    v_delta_time_waited_micro :=  t1_eventval(i).time_waited_micro - t0_eventval(i).time_waited_micro;
    v_delta_waits := t1_eventval(i).total_waits - t0_eventval(i).total_waits;
    v_delta_waits_per_sec := round(v_delta_waits / v_sleep_time, 1);
   IF v_delta_waits <> 0 then
       v_avg_wait_time_milli := round(v_delta_time_waited_micro/v_delta_waits/1000,1);
    ELSE
       v_avg_wait_time_milli := 0;
    END IF;
    DBMS_OUTPUT.PUT_LINE(
        rpad(to_char(v_avg_wait_time_milli),16,' ')||'  '||
        lpad(to_char(v_delta_waits_per_sec),16,' ')||'  '||
        lpad(to_char(round(v_delta_time_waited_micro/v_sleep_time/1000,1)),16,' ')||'  '||
        rpad(t1_histval(i).event,24,' ')
      );
  END LOOP;
  DBMS_OUTPUT.PUT_LINE(chr(13));
  
END;
/

EOF
#tput clear
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################tablespace mb #####################################################3
elif [ "$CHOICE" = "2"  ]

then

rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
/* 
   eventmetric.sql - sqlplus script - displays significant event metrics
   By Luca Jan 2011, 11g version Apr2012 
*/

col "Time /Delta" for a14
col name for a40
col INST_ID for 999
set linesize 140
set pagesize 1000

set wrap off 

select "Time /Delta",inst_id,name, 
        T_per_wait_fg*10 "Avg_FG_wait_ms", round(T_waited_fg/100,1) "Waited_FG_sec", W_count_fg "W_count_FG",
        round(T_waited/100,1) "Waited_tot_sec", W_count "W_count_tot"       
from (
  select to_char(min(begin_time),'hh24:mi:ss')||' /'||round(avg(intsize_csec/100),0)||'s' "Time /Delta",
       em.inst_id,en.name,
       sum(em.time_waited_fg) T_waited_fg, sum(em.time_waited) T_waited,sum(wait_count) W_count, sum(wait_count_fg) W_count_fg,
       sum(decode(em.wait_count, 0,0,round(em.time_waited/em.wait_count,2))) T_per_wait,
       sum(decode(em.wait_count_fg, 0,0,round(em.time_waited_fg/em.wait_count_fg,2))) T_per_wait_fg
  from gv\$eventmetric em, v\$event_name en
  where em.event#=en.event#
      and en.wait_class <>'Idle'
  group by em.inst_id,en.name,em.event_id
  order by T_waited_fg desc
  ) 
where rownum<=20;


set wrap on 


EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################tablespace GB #####################################################3
 
elif [ "$CHOICE" = "3"  ]

then

rep=""
      while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

col name for a60
col sec for 999
col file# for 99999

select sum(physical_block_writes) Phys_BLK_W, sum(physical_block_reads) Phys_BLK_R, round(avg(average_read_time)*10,1) AVG_read_ms,
       file_id file#, (select tablespace_name from dba_data_files ddf where ddf.file_id=fh.file_id) TBS_Name, 
       to_char(max(begin_time),'hh24:mi') time, round(max(intsize_csec)/100,0) sec
from gv\$filemetric_history fh
where begin_time >sysdate-1/24/3
group by inst_id,file_id
having sum(physical_block_writes) + sum(physical_block_writes) > 100
order by 1 desc;

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done 
########################################tablespace to owner #####################################################3

elif [ "$CHOICE" = "4"  ]

then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
-- iometric values in 11g
-- Luca Jan 2012

select min(begin_time) b_time, min(end_time) e_time, function_name,
       round(sum(small_read_iops+large_read_iops)) read_TOT_iops, round(sum(small_write_iops+large_write_iops)) write_TOT_iops, round(sum(large_read_mbps+small_read_mbps)) read_TOT_mbps, round(sum(large_write_mbps+small_write_mbps)) write_TOT_mbps
       from GV\$IOFUNCMETRIC
       group by rollup(function_name)
       having round(sum(small_read_iops+large_read_iops)) + round(sum(large_read_mbps+small_read_mbps)) + round(sum(small_write_iops+large_write_iops)) + round(sum(large_write_mbps+small_write_mbps))  >0
       order by function_name;
/
EOF



echo "Continue? ("q" to return to main menu)"
read rep
done
 
########################################all datafiles mb #####################################################3
elif [ "$CHOICE" = "5"  ]

then

rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

-- query to iofuncmetric view in 11g



select inst_id,begin_time,function_name,
       round(small_read_iops) RD_IOPS_sm, round(large_read_iops) RD_IOPS_lg, 
       round(small_read_mbps) RD_MBPS_sm, round(large_read_mbps) RD_MBPS_lg, 
       round(small_write_iops) WT_IOPS_sm, round(large_write_iops) WT_IOPS_lg, 
       round(small_write_mbps) WT_MBPS_sm, round(large_write_mbps) WT_MBPS_lg 
from GV\$IOFUNCMETRIC
--where function_name in ('Buffer Cache Reads','LGWR','DBWR','Direct Reads','Direct Writes','RMAN') 
--where round(small_read_iops+large_read_iops+small_write_iops+large_write_iops) >0
order by function_name,inst_id;

select min(begin_time) b_time, min(end_time) e_time, round(sum(small_read_iops+large_read_iops)) read_TOT_iops, round(sum(large_read_mbps+small_read_mbps)) read_TOT_mbps, round(sum(small_write_iops+large_write_iops)) write_TOT_iops, round(sum(large_write_mbps+small_write_mbps)) write_TOT_mbps from GV\$IOFUNCMETRIC;


/

EOF

echo "Continue? ("q" to return to main menu)"
read rep
done
 
########################################dba all files auto  mb #####################################################3
elif [ "$CHOICE" = "6"  ]

then 
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

col elapsed_time for a20
col cpu_used for a20
col inst_sid for a7

--dbms_schedule_jobs
select running_instance||'_'||session_id inst_sid,owner,job_name,elapsed_time,cpu_used from dba_SCHEDULER_RUNNING_JOBS;


--old fashioned jobs
select * from dba_jobs_running;
/


EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################dba all files with archive log #####################################################3
elif [ "$CHOICE" = "7"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

REM prints server load as in linux 'w'
REM Luca, Jan 2007

col host_name for a20

select ins.instance_name,ins.host_name,round(os.value,2) load 
from gv\$osstat os, gv\$instance ins
where os.inst_id=ins.inst_id and os.stat_name='LOAD'
order by 3 desc;
/



EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
  
#################################################################################################################
elif [ "$CHOICE" = "8"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
-- locks.sql locks and enqueue blocks for 11g
-- Luca Jan 2012


set feedback off
col oracle_username for a15
col owner for a15
col object_name for a15
col inst_sid_s# for a13
col username for a14
col obj_lck for a18
col blk_info for a14
col f_blk_info for a14
col event for a30
col s_wt for 9999
col chain_signature for a65
col Wsecs for 999



--who locks whoms (MASTER) 
SELECT Oracle_Username Username, owner Object_Owner, Object_Name, Object_Type, s.osuser, s.SID SID,
s.SERIAL# SERIAL,DECODE(l.BLOCK, 0, 'Not Blocking', 1, 'Blocking', 2, 'Global') STATUS,
DECODE(v.locked_mode, 0, 'None', 1, 'Null', 2, 'Row-S (SS)', 3, 'Row-X (SX)', 4, 'Share', 5, 'S/Row-X (SSX)', 6, 'Exclusive', TO_CHAR(lmode) ) MODE_HELD
FROM gv\$locked_object v, dba_objects d, gv\$lock l, gv\$session s
WHERE v.object_id = d.object_id
  AND (v.object_id = l.id1)
  AND v.session_id = s.SID
ORDER BY oracle_username, session_id;
 
--who locks whoms (child ) 		 
SELECT 
  oracle_username, os_user_name, locked_mode,
  object_name,object_type
FROM v\$locked_object a,DBA_OBJECTS b
WHERE a.object_id = b.object_id ;





prompt DML locks from current instance (dba_dml_locks)

select session_id sid, owner,name,mode_held,mode_requested from dba_dml_locks;

prompt
prompt sessions with lockwait from gv\$session

select inst_id||' '||sid||','||serial# inst_sid_s#, username, row_wait_obj#||','||row_wait_block#||','||row_wait_row# obj_lck, 
       blocking_session_Status||' '||blocking_instance||','||blocking_session blk_info,        
       final_blocking_session_Status||' '||final_blocking_instance||','||final_blocking_session f_blk_info, 
       event, seconds_in_wait s_wt
from gv\$session 
where lockwait is not null
order by inst_id;

prompt
prompt waitchains (all events)

select instance||' '||sid||','||sess_serial# inst_sid_s#, chain_signature,num_waiters wrs#,in_wait_secs Wsecs,row_wait_obj#||','||row_wait_block# obj_lck,
       blocker_is_valid||' '||blocker_instance||','||blocker_sid blk_info
from v\$wait_chains
where in_wait='TRUE' and blocker_is_valid='TRUE'
order by instance,chain_signature;



prompt
prompt final blockers from gv\$session_blockers


select * from Gv\$SESSION_BLOCKERS;


prompt
prompt final blockers from gv\$session (all events)

select final_blocking_instance f_blk_inst, final_blocking_session f_blk_sess, event, sql_id, row_wait_obj#||','||row_wait_block# obj_lck, count(*) num_blocked, round(max(wait_time_micro)/1000000,2) max_wait_sec
from gv\$session 
where final_blocking_session_Status='VALID'
group by final_blocking_instance, final_blocking_session, event, sql_id, row_wait_obj#||','||row_wait_block#
order by 1;




prompt global blocked locks

select * from  Gv\$GLOBAL_BLOCKED_LOCKS    ;

prompt TX locks

select * from gv\$transaction_enqueue;

prompt waiting sessions

select inst_id,sid,process,username,row_wait_obj#,LOCKWAIT,blocking_instance blk_inst, blocking_session blk_sid
from gv\$session 
where lockwait is not null;

prompt blocking sessions

select sid,username,row_wait_obj#,row_wait_block#,row_wait_row#,blocking_session  from gv\$session a where row_wait_obj#<>0 and blocking_Session is not null order by 2,1;

prompt blockers from gv\$Lock

select inst_id,sid,type,ctime LOCK_TIME,id1,id2
from gv\$lock
where block =1;




set feedback on

/



EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
  
 

#################################################################################################################
elif [ "$CHOICE" = "9"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

select S.USERNAME, s.sid, s.osuser, t.sql_id, sql_text
from v\$sqltext_with_newlines t,v\$SESSION s
where t.address =s.sql_address
and t.hash_value = s.sql_hash_value
and s.status = 'INACTIVE'
and s.username <> 'SYSTEM'
and s.sid=38
order by s.sid,t.piece;

REM This one shows SQL that is currently "ACTIVE":-

select S.USERNAME, s.sid, s.osuser, t.sql_id, sql_text
from v\$sqltext_with_newlines t,v\$SESSION s
where t.address =s.sql_address
and t.hash_value = s.sql_hash_value
and s.status = 'ACTIVE'
and s.username <> 'SYSTEM'
order by s.sid,t.piece;

--This shows locks. Sometimes things are going slow, but it's because it is blocked waiting for a lock':

select  object_name,   object_type,   session_id,  
type,   
lmode,        
request,  block,   
ctime        
from   v\$locked_object, all_objects, v\$lock
where
v\$locked_object.object_id = all_objects.object_id AND
v\$lock.id1 = all_objects.object_id AND
v\$lock.sid = v\$locked_object.session_id
order by  session_id, ctime desc, object_name;

COLUMN percent FORMAT 999.99 
SELECT sid, to_char(start_time,'hh24:mi:ss') stime, 
message,( sofar/totalwork)* 100 percent 
FROM v\$session_longops
WHERE sofar/totalwork < 1;





select s.username,s.sid,s.serial#,s.last_call_et/60 mins_running,q.sql_text from v\$session s 
join v\$sqltext_with_newlines q
on s.sql_address = q.address
 where -- status='ACTIVE'
 type <>'BACKGROUND'
-- and last_call_et> 60
and s.sid=38
order by sid,serial#,q.piece



 select s.sid,s.serial#, s.username,s.program,i.block_changes
  2  from v\$session s, v\$sess_io i
  3  where s.sid=38 and s.sid = i.sid;


select SID,username,OPNAME,SOFAR,TOTALWORK,SOFAR/TOTALWORK*100 "Work Done %",
  to_char(START_TIME,'mm/dd/yyyy hh24:mi:ss') "start_time",
  to_char(sysdate + TIME_REMAINING/3600/24,'mm/dd/yyyy hh24:mi:ss') "End_at",
  to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')Date_Now
from v\$session_longops
where sofar!=TOTALWORK 
  and totalwork!=0

  
*************
col REMAINING format a10
set pagesize 100
col ELAPSED format a10 
SELECT s.SID,
s.serial#,
s.machine,
ROUND(sl.elapsed_seconds/60) || ':' ||
MOD(sl.elapsed_seconds,60) elapsed,
ROUND(sl.time_remaining/60) || ':' ||
MOD(sl.time_remaining,60) remaining,
ROUND(sl.sofar/sl.totalwork*100, 2) progress_pct
FROM v\$session s,
v\$session_longops sl
WHERE s.SID = sl.SID
AND s.serial# = sl.serial#
ORDER BY 4 DESC

And then run the following query 

SELECT a.sql_text
FROM v\$sqltext a,
v\$session b
WHERE a.address = b.sql_address
AND a.hash_value = b.sql_hash_value
AND b.sid = &1 --> From above sql
ORDER BY a.piece; 

  
  
  
  
  
  
  
select a.sid,(a.sofar/a.totalwork)*100 "% Done",
to_char(a.last_update_time, 'HH24:MI:SS'),
a.username,a.time_remaining "Time Left",
a.opname ,s.sql_text
from v\$session_longops a, v\$session b, v\$sqltext s
where a.sid =b.sid and b.sql_address = s.address
and a.sofar <> a.totalwork
order by b.sid, last_update_time

  
  
  
  
  
  SELECT sesion.SID,
         sesion.username,
         SUM (
              ash.wait_time
            + ash.time_waited)
            ttl_wait_time
    FROM v\$active_session_history ash, v\$session sesion
   WHERE ash.sample_time BETWEEN SYSDATE - 60 / 2880 AND SYSDATE
         AND ash.session_id = sesion.SID
GROUP BY sesion.SID, sesion.username
ORDER BY 3 DESC;

  
  
  
  
 SELECT dba_objects.object_name,
         dba_objects.object_type,
         active_session_history.event,
         SUM (
              active_session_history.wait_time
            + active_session_history.time_waited)
            ttl_wait_time
    FROM v\$active_session_history active_session_history, dba_objects
   WHERE active_session_history.sample_time BETWEEN SYSDATE - 60 / 2880 AND SYSDATE
         AND active_session_history.current_obj# = dba_objects.object_id
GROUP BY dba_objects.object_name,
         dba_objects.object_type,
         active_session_history.event
ORDER BY 4 DESC;



/



EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
  
 

#################################################################################################################

elif [ "$CHOICE" = "10"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF


col remaining for 999999
col elapsed for 999999
col hash for 9999999999
col inst_sid_ser for a13
col username for a25
col message for a100
col exec_plan for a25
col hash for 9999999999
col sid for 9999
col opname for a15
col message for a45


prompt longops last day with daration > 60 sec

select inst_id||'_'||sid||' '||serial# inst_sid_ser,username,start_time,elapsed_seconds elapsed, sql_id,
       message
from gv\$session_longops
where time_remaining=0 
      and elapsed_seconds>60
      and start_time >sysdate-1 order by start_time desc;

	  

select inst_id,sid,username,time_remaining remaining, elapsed_seconds elapsed, sql_id, opname,message
from gv\$session_longops
where time_remaining>0;

	  

select inst_id||'_'||sid||' '||serial# inst_sid_ser,username,time_remaining remaining,elapsed_seconds elapsed, sql_id, 
       sql_plan_operation||'-'||sql_plan_options||', '||sql_plan_line_id exec_plan,
       message
from gv\$session_longops
where time_remaining>0;

/



EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
  
 

#################################################################################################################
elif [ "$CHOICE" = "11"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF


select * from (
  select inst_id, session_id sid, to_char(begin_time,'hh24:mi:ss') begTime, round(intsize_csec/100,0) D_sec,  cpu,          
         physical_reads PhyReads, logical_reads LogicalReads, pga_memory, hard_parses, soft_parses 
  from gv\$sessmetric
  order by cpu+physical_reads desc
)
where rownum<20;



/* 
   sysmetric_details.sql - sqlplus script - displays significant system metrics detailed per RAC instance
   By Luca Nov 2007 
*/

col "Time+Delta" for a14
col "Metric" for a40
col "Total" for a10
col metric_name for a25

set linesize 140
set pagesize 1000

set wrap off 
REM truncates the metric field to max length

 select to_char(min(begin_time),'hh24:mi:ss')||' /'||round(avg(intsize_csec/100),0)||'s' "Time+Delta",
       metric_name||' - '||metric_unit "Metric", 
       sum(value_inst1) inst1, sum(value_inst2) inst2, sum(value_inst3) inst3, sum(value_inst4) inst4,
       sum(value_inst5) inst5, sum(value_inst6) inst6
 from
  ( select begin_time,intsize_csec,metric_name,metric_unit,metric_id,group_id,
       case inst_id when 1 then round(value,1) end value_inst1,
       case inst_id when 2 then round(value,1) end value_inst2,
       case inst_id when 3 then round(value,1) end value_inst3,
       case inst_id when 4 then round(value,1) end value_inst4,
       case inst_id when 5 then round(value,1) end value_inst5,
       case inst_id when 6 then round(value,1) end value_inst6
  from gv\$sysmetric
  where metric_name in ('Host CPU Utilization (%)','Current OS Load', 'Physical Write Total IO Requests Per Sec',
        'Physical Write Total Bytes Per Sec', 'Physical Write IO Requests Per Sec', 'Physical Write Bytes Per Sec',
         'I/O Requests per Second', 'I/O Megabytes per Second',
        'Physical Read Total Bytes Per Sec', 'Physical Read Total IO Requests Per Sec', 'Physical Read IO Requests Per Sec',
        'CPU Usage Per Sec','Network Traffic Volume Per Sec','Logons Per Sec','Redo Generated Per Sec',
        'User Transaction Per Sec','Average Active Sessions','Average Synchronous Single-Block Read Latency',
        'Logical Reads Per Sec','DB Block Changes Per Sec')
  )
 group by metric_id,group_id,metric_name,metric_unit
 order by metric_name;

set wrap on 





/



EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
  
 

#################################################################################################################
elif [ "$CHOICE" = "12"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
COLUMN pool    HEADING "Pool"
COLUMN name    HEADING "Name"
COLUMN sgasize HEADING "Allocated" FORMAT 999,999,999
COLUMN bytes   HEADING "Free" FORMAT 999,999,999

SELECT
    f.pool
  , f.name
  , s.sgasize
  , f.bytes
  , ROUND(f.bytes/s.sgasize*100, 2) "% Free"
FROM
    (SELECT SUM(bytes) sgasize, pool FROM v\$sgastat GROUP BY pool) s
  , v\$sgastat f
WHERE
    f.name = 'free memory'
  AND f.pool = s.pool
/


EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
 

#################################################################################################################
elif [ "$CHOICE" = "13"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET LINESIZE 145
SET PAGESIZE 9999
SET FEEDBACK off
SET VERIFY   off

COLUMN bytes   FORMAT  999,999,999
COLUMN percent FORMAT  999.99999

break on report

compute sum of bytes on report
compute sum of percent on report

SELECT
    a.name
  , a.bytes
  , a.bytes/(b.sum_bytes*100)  Percent  
FROM sys.v_$sgastat a
   , (SELECT SUM(value)sum_bytes FROM sys.v_$sga) b 
ORDER BY bytes DESC
/

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done

#################################################################################################################
elif [ "$CHOICE" = "14"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET LINESIZE 145
SET PAGESIZE 9999
SET FEEDBACK off
SET VERIFY   off

COLUMN bytes   FORMAT  999,999,999
COLUMN percent FORMAT  999.99999

break on report

compute sum of bytes on report
compute sum of percent on report

SELECT
    a.name
  , a.bytes
  , a.bytes/(b.sum_bytes*100)  Percent  
FROM sys.v_$sgastat a
   , (SELECT SUM(value)sum_bytes FROM sys.v_$sga) b 
ORDER BY bytes DESC
/

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done

#################################################################################################################
elif [ "$CHOICE" = "15"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET LINESIZE 145
SET PAGESIZE 9999

COLUMN value       FORMAT 999,999,999,999 HEADING "Shared Pool Size"
COLUMN bytes       FORMAT 999,999,999,999 HEADING "Free Bytes"
COLUMN percentfree FORMAT 999             HEADING "Percent Free"

SELECT
    TO_NUMBER(p.value)       value
  , s.bytes                  bytes
  , (s.bytes/p.value) * 100  percentfree
FROM
    v\$sgastat    s
  , v\$parameter  p
WHERE
      s.name = 'free memory'
  AND s.pool = 'shared pool'
  AND p.name = 'shared_pool_size'
/

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done

#################################################################################################################

 
 
 
 
 
 
 
 
 
#####################################################################################
 else
               echo " thanks you "
        fi


done



}

fra( )
{


while [ 1 ]
do
 #       tput clear
        echo -e "\n"
echo -e "\t\t\t$MESSAGE\t"
echo -e
#echo -e "\t\t\tConnected to Database- `tput smso`$Yellow$tns`tput rmso`\t"
echo -e "\t###################### TABLESPACE : ###################"
echo -e "\t"
echo -e "\t#######################################################"
echo -e "\t"
echo -e "\t(1) FRA status                                          "
echo -e "\t(2) FRA file status                                          "
echo -e "\t(3) FRA alert                                      "
echo -e "\t(4) Controle file Record                                          "
echo -e "\t(5) Archive log history by hour                                          "
echo -e "\t(6) Archive log history by spific date                                           "
echo -e "\t(7) Archive per day (MB main )                                         "
echo -e "\t(8) ARchive log per hour (log discription)                                         "
echo -e "\t(9) Archive log per hour by thread#                                          "
echo -e "\n"
echo -e "\tEnter your choice (q to quit): \c                             "
echo -e "\n"
echo -e "\t########################################################"
#tput cup 16 40
 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
#itput clear
              main
########################################tablespace KB #####################################################3
        elif [ "$CHOICE" = "1"  ]
        then

        rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(sys_context('USERENV', 'INSTANCE_NAME'), 17) current_instance
FROM dual;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : FRA Status                                                  |
PROMPT | Instance : &current_instance                                           |
PROMPT | Notes    : Current location, disk quota, space in use, space           |
PROMPT |            reclaimable by deleting files, and number of files in the   |
PROMPT |            Flash Recovery Area.                                        |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN recovery_file_dest FORMAT a30                  HEADING 'Recovery File Dest'
COLUMN space_limit        FORMAT 99,999,999,999,999   HEADING 'Space Limit'
COLUMN space_used         FORMAT 99,999,999,999,999   HEADING 'Space Used'
COLUMN space_used_pct     FORMAT 999.99               HEADING '% Used'
COLUMN space_reclaimable  FORMAT 99,999,999,999,999   HEADING 'Space Reclaimable'
COLUMN pct_reclaimable    FORMAT 999.99               HEADING '% Reclaimable'
COLUMN number_of_files    FORMAT 999,999              HEADING 'Number of Files'

SELECT
    f.name                                              recovery_file_dest
  , f.space_limit                                       space_limit
  , f.space_used                                        space_used
  , ROUND((f.space_used / f.space_limit)*100, 2)        space_used_pct
  , f.space_reclaimable                                 space_reclaimable
  , ROUND((f.space_reclaimable / f.space_limit)*100, 2) pct_reclaimable
  , f.number_of_files                                   number_of_files
FROM
    v\$recovery_file_dest f
ORDER BY
    f.name;


COLUMN file_type                  FORMAT a30     HEADING 'File Type'
COLUMN percent_space_used                        HEADING 'Percent Space Used'
COLUMN percent_space_reclaimable                 HEADING 'Percent Space Reclaimable'
COLUMN number_of_files            FORMAT 999,999 HEADING 'Number of Files'

SELECT
    f.file_type
  , f.percent_space_used
  , f.percent_space_reclaimable
  , f.number_of_files
FROM
    v\$flash_recovery_area_usage f
ORDER BY
    f.file_type;




EOF
#tput clear
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################tablespace mb #####################################################3
elif [ "$CHOICE" = "2"  ]

then

rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(sys_context('USERENV', 'INSTANCE_NAME'), 17) current_instance
FROM dual;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : FRA Files                                                   |
PROMPT | Instance : &current_instance                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN name       FORMAT a80                  HEADING 'File Name'
COLUMN member     FORMAT a80                  HEADING 'File Name'
COLUMN handle     FORMAT a80                  HEADING 'File Name'
COLUMN bytes      FORMAT 999,999,999,999,999  HEADING 'File Size (Bytes)'

SELECT    name, (blocks*block_size) bytes
FROM      v\$datafile_copy
WHERE     is_recovery_dest_file = 'YES'
UNION
SELECT    name, null
FROM      v\$controlfile
WHERE     is_recovery_dest_file = 'YES'
UNION
SELECT    member, null
FROM      v\$logfile
WHERE     is_recovery_dest_file = 'YES'
UNION
SELECT    handle, bytes
FROM      v\$backup_piece
WHERE     is_recovery_dest_file = 'YES'
UNION
SELECT    name, (blocks*block_size) bytes
FROM      v\$archived_log
WHERE     is_recovery_dest_file = 'YES'
ORDER BY
    1
  , 2
/



EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################tablespace GB #####################################################3
 
elif [ "$CHOICE" = "3"  ]

then

rep=""
      while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(sys_context('USERENV', 'INSTANCE_NAME'), 17) current_instance
FROM dual;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : FRA Alerts                                                  |
PROMPT | Instance : &current_instance                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN object_type        FORMAT a12    HEADING 'Object Type'
COLUMN message_type       FORMAT a13    HEADING 'Message Type'
COLUMN message_level                    HEADING 'Message Level'
COLUMN reason             FORMAT a50    HEADING 'Reason'            WRAP
COLUMN suggested_action   FORMAT a50    HEADING 'Suggested Action'  WRAP

prompt 
prompt The database issues a warning alert when reclaimable space is less than
prompt 15% and a critical alert when relaimable space is less than 3%. To warn
prompt the DBA of this condition, an entry is added to the alert.log and to the
prompt DBA_OUTSTANDING_ALERTS table (used by Enterprise Manager). However, the
prompt database continues to consume space in the Flash Recovery Area until
prompt there is no reclaimable space left. When the Flash Recovery Area is
prompt completely full, the following error will be reported:
prompt
prompt ORA-19809: limit exceeded for recovery files
prompt ORA-19804: cannot reclaim nnnnn bytes disk space from mmmmm limit
prompt
prompt where nnnnn is the number of bytes required and mmmmm is the disk quota
prompt for the Flash Recovery Area.
prompt
prompt The following Error would be reported in the alert.log
prompt ORA-19815: WARNING: db_recovery_file_dest_size of "size of FRA configured"
prompt bytes is 100.00% used, and has 0 remaining bytes available.
prompt 

SELECT
    object_type
  , message_type
  , message_level
  , reason
  , suggested_action
FROM
    dba_outstanding_alerts
/


EOF
echo "Continue? ("q" to return to main menu)"
read rep
done 
########################################tablespace to owner #####################################################3

elif [ "$CHOICE" = "4"  ]

then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : Control File Records                                        |
PROMPT | Instance : &current_instance                                           |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN type           FORMAT           a30   HEADING "Record Section Type"
COLUMN record_size    FORMAT       999,999   HEADING "Record Size|(in bytes)"
COLUMN records_total  FORMAT       999,999   HEADING "Records Allocated"
COLUMN bytes_alloc    FORMAT   999,999,999   HEADING "Bytes Allocated"
COLUMN records_used   FORMAT       999,999   HEADING "Records Used"
COLUMN bytes_used     FORMAT   999,999,999   HEADING "Bytes Used"
COLUMN pct_used       FORMAT           B999  HEADING "% Used"
COLUMN first_index                           HEADING "First Index"
COLUMN last_index                            HEADING "Last Index"
COLUMN last_recid                            HEADING "Last RecID"

BREAK ON report

COMPUTE sum OF records_total ON report
COMPUTE sum OF bytes_alloc   ON report
COMPUTE sum OF records_used  ON report
COMPUTE sum OF bytes_used    ON report
COMPUTE avg OF pct_used      ON report

SELECT
    type
  , record_size
  , records_total
  , (records_total * record_size) bytes_alloc
  , records_used
  , (records_used * record_size) bytes_used
  , NVL(records_used/records_total * 100, 0) pct_used
  , first_index
  , last_index
  , last_recid
FROM v\$controlfile_record_section
ORDER BY type
/



EOF



echo "Continue? ("q" to return to main menu)"
read rep
done
 
########################################all datafiles mb #####################################################3
elif [ "$CHOICE" = "5"  ]

then

rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET LINESIZE 250
SET PAGESIZE 9999
SET TRIMSPOOL ON
SET VERIFY   off
COLUMN H00   FORMAT 999     HEADING '00'
COLUMN H01   FORMAT 999     HEADING '01'
COLUMN H02   FORMAT 999     HEADING '02'
COLUMN H03   FORMAT 999     HEADING '03'
COLUMN H04   FORMAT 999     HEADING '04'
COLUMN H05   FORMAT 999     HEADING '05'
COLUMN H06   FORMAT 999     HEADING '06'
COLUMN H07   FORMAT 999     HEADING '07'
COLUMN H08   FORMAT 999     HEADING '08'
COLUMN H09   FORMAT 999     HEADING '09'
COLUMN H10   FORMAT 999     HEADING '10'
COLUMN H11   FORMAT 999     HEADING '11'
COLUMN H12   FORMAT 999     HEADING '12'
COLUMN H13   FORMAT 999     HEADING '13'
COLUMN H14   FORMAT 999     HEADING '14'
COLUMN H15   FORMAT 999     HEADING '15'
COLUMN H16   FORMAT 999     HEADING '16'
COLUMN H17   FORMAT 999     HEADING '17'
COLUMN H18   FORMAT 999     HEADING '18'
COLUMN H19   FORMAT 999     HEADING '19'
COLUMN H20   FORMAT 999     HEADING '20'
COLUMN H21   FORMAT 999     HEADING '21'
COLUMN H22   FORMAT 999     HEADING '22'
COLUMN H23   FORMAT 999     HEADING '23'
COLUMN TOTAL FORMAT 999,999    HEADING 'Total'
SELECT
    SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH:MI:SS'),1,5)                                                               DAY
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'00',ROUND(((blocks*block_size)/1024/1024)),0)) H00
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'01',ROUND(((blocks*block_size)/1024/1024)),0)) H01
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'02',ROUND(((blocks*block_size)/1024/1024)),0)) H02
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'03',ROUND(((blocks*block_size)/1024/1024)),0)) H03
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'04',ROUND(((blocks*block_size)/1024/1024)),0)) H04
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'05',ROUND(((blocks*block_size)/1024/1024)),0)) H05
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'06',ROUND(((blocks*block_size)/1024/1024)),0)) H06
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'07',ROUND(((blocks*block_size)/1024/1024)),0)) H07
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'08',ROUND(((blocks*block_size)/1024/1024)),0)) H08
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'09',ROUND(((blocks*block_size)/1024/1024)),0)) H09
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'10',ROUND(((blocks*block_size)/1024/1024)),0)) H10
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'11',ROUND(((blocks*block_size)/1024/1024)),0)) H11
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'12',ROUND(((blocks*block_size)/1024/1024)),0)) H12
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'13',ROUND(((blocks*block_size)/1024/1024)),0)) H13
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'14',ROUND(((blocks*block_size)/1024/1024)),0)) H14
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'15',ROUND(((blocks*block_size)/1024/1024)),0)) H15
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'16',ROUND(((blocks*block_size)/1024/1024)),0)) H16
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'17',ROUND(((blocks*block_size)/1024/1024)),0)) H17
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'18',ROUND(((blocks*block_size)/1024/1024)),0)) H18
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'19',ROUND(((blocks*block_size)/1024/1024)),0)) H19
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'20',ROUND(((blocks*block_size)/1024/1024)),0)) H20
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'21',ROUND(((blocks*block_size)/1024/1024)),0)) H21
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'22',ROUND(((blocks*block_size)/1024/1024)),0)) H22
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'23',ROUND(((blocks*block_size)/1024/1024)),0)) H23
  , ROUND(SUM((blocks*block_size)/1024/1024))                                                                                                           TOTAL
FROM
  v\$archived_log  a
GROUP BY SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH:MI:SS'),1,5)
ORDER BY SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH:MI:SS'),1,5)
/
EOF

echo "Continue? ("q" to return to main menu)"
read rep
done
 
########################################dba all files auto  mb #####################################################3
elif [ "$CHOICE" = "6"  ]

then 
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET LINESIZE 145
SET PAGESIZE 9999
SET VERIFY   off

 PROMPT 'Enter start date (DD-MON-YYYY): '
 PROMPT 'Enter end date   (DD-MON-YYYY): '

COLUMN H00   FORMAT 999     HEADING '00'
COLUMN H01   FORMAT 999     HEADING '01'
COLUMN H02   FORMAT 999     HEADING '02'
COLUMN H03   FORMAT 999     HEADING '03'
COLUMN H04   FORMAT 999     HEADING '04'
COLUMN H05   FORMAT 999     HEADING '05'
COLUMN H06   FORMAT 999     HEADING '06'
COLUMN H07   FORMAT 999     HEADING '07'
COLUMN H08   FORMAT 999     HEADING '08'
COLUMN H09   FORMAT 999     HEADING '09'
COLUMN H10   FORMAT 999     HEADING '10'
COLUMN H11   FORMAT 999     HEADING '11'
COLUMN H12   FORMAT 999     HEADING '12'
COLUMN H13   FORMAT 999     HEADING '13'
COLUMN H14   FORMAT 999     HEADING '14'
COLUMN H15   FORMAT 999     HEADING '15'
COLUMN H16   FORMAT 999     HEADING '16'
COLUMN H17   FORMAT 999     HEADING '17'
COLUMN H18   FORMAT 999     HEADING '18'
COLUMN H19   FORMAT 999     HEADING '19'
COLUMN H20   FORMAT 999     HEADING '20'
COLUMN H21   FORMAT 999     HEADING '21'
COLUMN H22   FORMAT 999     HEADING '22'
COLUMN H23   FORMAT 999     HEADING '23'
COLUMN TOTAL FORMAT 999,999 HEADING 'Total'


SELECT
    SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH:MI:SS'),1,5)                          DAY
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'00',1,0)) H00
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'01',1,0)) H01
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'02',1,0)) H02
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'03',1,0)) H03
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'04',1,0)) H04
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'05',1,0)) H05
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'06',1,0)) H06
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'07',1,0)) H07
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'08',1,0)) H08
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'09',1,0)) H09
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'10',1,0)) H10
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'11',1,0)) H11
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'12',1,0)) H12
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'13',1,0)) H13
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'14',1,0)) H14
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'15',1,0)) H15
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'16',1,0)) H16
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'17',1,0)) H17
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'18',1,0)) H18
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'19',1,0)) H19
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'20',1,0)) H20
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'21',1,0)) H21
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'22',1,0)) H22
  , SUM(DECODE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH24:MI:SS'),10,2),'23',1,0)) H23
  , COUNT(*)                                                                      TOTAL
FROM
  v\$log_history  a
WHERE
    (TO_DATE(SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH:MI:SS'), 1,8), 'MM/DD/RR')
     >=
     TO_DATE('&startDate', 'DD-MON-YYYY')
     )
     AND
    (TO_DATE(substr(TO_CHAR(first_time, 'MM/DD/RR HH:MI:SS'), 1,8), 'MM/DD/RR')
     <=
     TO_DATE('&endDate', 'DD-MON-YYYY')
     )
GROUP BY SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH:MI:SS'),1,5)
ORDER BY SUBSTR(TO_CHAR(first_time, 'MM/DD/RR HH:MI:SS'),1,5)
;

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################dba all files with archive log #####################################################3
elif [ "$CHOICE" = "7"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET PAUSE ON
SET PAUSE 'Press Return to Continue'
SET PAGESIZE 60
SET LINESIZE 300
SET VERIFY OFF
 set pages 1000
select trunc(COMPLETION_TIME,'DD') Day, thread#, round(sum(BLOCKS*BLOCK_SIZE)/1048576) MB,count(*) Archives_Generated from gv\$archived_log
group by trunc(COMPLETION_TIME,'DD'),thread# order by 1;


EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
  
#################################################################################################################
elif [ "$CHOICE" = "8"  ]
then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
select trunc(COMPLETION_TIME,'HH') Hour,thread# , round(sum(BLOCKS*BLOCK_SIZE)/1048576) MB,count(*) Archives from gv\$archived_log
where COMPLETION_TIME >=sysdate-1 group by trunc( COMPLETION_TIME ,'HH' ),thread#   order by 1

/



EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
  
 

#################################################################################################################
 
 
 
 
 
 
#####################################################################################
 else
               echo " thanks you "
        fi


done

}


growth( )
{
while [ 1 ]
do
 #       tput clear
        echo -e "\n"
echo -e "\t\t\t$MESSAGE\t"
echo -e
#echo -e "\t\t\tConnected to Database- `tput smso`$Yellow$tns`tput rmso`\t"
echo -e "\t###################### TABLESPACE : ###################"
echo -e "\t"
echo -e "\t#######################################################"
echo -e "\t"
echo -e "\t(1) DATABASE GROWTH PER MONTH                                          "
echo -e "\t(2) DATABASE GROWTH PER DAY                                         "
echo -e "\t(3) DATABASE GROWTH TABLESPACE level                                        "
echo -e "\t(4) DATABASE TABLESPACE growth                                          "
echo -e "\t(5) Archive Growth                                          "
echo -e "\t(6) DATAFILE ALL (Auto)                                         "
echo -e "\n"
echo -e "\tEnter your choice (q to quit): \c                             "
echo -e "\n"
echo -e "\t########################################################"
#tput cup 16 40
 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
#itput clear
              main
########################################tablespace KB #####################################################3
        elif [ "$CHOICE" = "1"  ]
        then

        rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET LINESIZE 200
SET PAGESIZE 200
COL "Database Size" FORMAT a13
COL "Used Space" FORMAT a11
COL "Used in %" FORMAT a11
COL "Free in %" FORMAT a11
COL "Database Name" FORMAT a13
COL "Free Space" FORMAT a12
COL "Growth DAY" FORMAT a11
COL "Growth WEEK" FORMAT a12
COL "Growth DAY in %" FORMAT a16
COL "Growth WEEK in %" FORMAT a16
SELECT
(select min(creation_time) from v\$datafile) "Create Time",
(select name from v\$database) "Database Name",
ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2) || ' MB' "Database Size",
ROUND((SUM(USED.BYTES) / 1024 / 1024 ) - ROUND(FREE.P / 1024 / 1024 ),2) || ' MB' "Used Space",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 )) / ROUND(SUM(USED.BYTES) / 1024 / 1024 ,2)*100,2) || '% MB' "Used in %",
ROUND((FREE.P / 1024 / 1024 ),2) || ' MB' "Free Space",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - ((SUM(USED.BYTES) / 1024 / 1024 ) - ROUND(FREE.P / 1024 / 1024 )))/ROUND(SUM(USED.BYTES) / 1024 / 1024,2 )*100,2) || '% MB' "Free in %",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v\$datafile),2) || ' MB' "Growth DAY",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v\$datafile)/ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2)*100,3) || '% MB' "Growth DAY in %",
ROUND(((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v\$datafile)*7,2) || ' MB' "Growth WEEK",
ROUND((((SUM(USED.BYTES) / 1024 / 1024 ) - (FREE.P / 1024 / 1024 ))/(select sysdate-min(creation_time) from v\$datafile)/ROUND((SUM(USED.BYTES) / 1024 / 1024 ),2)*100)*7,3) || '% MB' "Growth WEEK in %"
FROM    (SELECT BYTES FROM V\$DATAFILE
UNION ALL
SELECT BYTES FROM V\$TEMPFILE
UNION ALL
SELECT BYTES FROM V\$LOG) USED,
(SELECT SUM(BYTES) AS P FROM DBA_FREE_SPACE) FREE
GROUP BY FREE.P;

SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : Database Growth                                             |
PROMPT | Instance : &current_instance                                           |
PROMPT | Note     : This script only tracks when a new data file was added to   |
PROMPT |            the database. Any data file that was manually increased or  |
PROMPT |            decreased in size or automatically increased using the      |
PROMPT |            AUTOEXTEND option is not tracked by this script.            |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN month        FORMAT a7                   HEADING 'Month'
COLUMN growth       FORMAT 999,999,999,999,999  HEADING 'Growth (Bytes)'

BREAK ON report

COMPUTE sum OF growth ON report

SELECT
    TO_CHAR(creation_time, 'RRRR-MM') day
  , SUM(bytes)                        growth
FROM     sys.v_\$datafile
GROUP BY TO_CHAR(creation_time, 'RRRR-MM')
ORDER BY TO_CHAR(creation_time, 'RRRR-MM')



/

EOF
#tput clear
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################tablespace mb #####################################################3
elif [ "$CHOICE" = "2"  ]

then

rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
SET TERMOUT OFF;
COLUMN current_instance NEW_VALUE current_instance NOPRINT;
SELECT rpad(instance_name, 17) current_instance FROM v\$instance;
SET TERMOUT ON;

PROMPT 
PROMPT +------------------------------------------------------------------------+
PROMPT | Report   : Database Growth                                             |
PROMPT | Instance : &current_instance                                           |
PROMPT | Note     : This script only tracks when a new data file was added to   |
PROMPT |            the database. Any data file that was manually increased or  |
PROMPT |            decreased in size or automatically increased using the      |
PROMPT |            AUTOEXTEND option is not tracked by this script.            |
PROMPT +------------------------------------------------------------------------+

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN month        FORMAT a7                   HEADING 'Month'
COLUMN growth       FORMAT 999,999,999,999,999  HEADING 'Growth (Bytes)'

BREAK ON report

COMPUTE sum OF growth ON report

SELECT
    TO_CHAR(creation_time, 'RRRR-DD') day
  , SUM(bytes)                        growth
FROM     sys.v_\$datafile
GROUP BY TO_CHAR(creation_time, 'RRRR-DD')
ORDER BY TO_CHAR(creation_time, 'RRRR-DD')


/

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done
########################################tablespace GB #####################################################3
 
elif [ "$CHOICE" = "3"  ]

then

rep=""
      while [ "$rep" != "q" ]
do
$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
select b.tsname tablespace_name , MAX(b.used_size_mb) cur_used_size_mb , round(AVG(inc_used_size_mb),2)avg_increas_mb  
from ( SELECT a.days,a.tsname , used_size_mb , used_size_mb - LAG (used_size_mb,1) OVER ( PARTITION BY a.tsname ORDER BY a.tsname,a.days) inc_used_size_mb
from ( SELECT TO_CHAR(sp.begin_interval_time,'MM-DD-YYYY') days  ,ts.tsname ,MAX(round((tsu.tablespace_usedsize* dt.block_size )/(1024*1024),2)) used_size_mb
from dba_hist_tbspc_space_usage  tsu , dba_hist_tablespace_stat  ts ,dba_hist_snapshot  sp, dba_tablespaces  dt   where tsu.tablespace_id= ts.ts# 
AND tsu.snap_id = sp.snap_id
AND ts.tsname = dt.tablespace_name AND sp.begin_interval_time > sysdate-7
GROUP BY TO_CHAR(sp.begin_interval_time,'MM-DD-YYYY'), ts.tsname 
ORDER BY ts.tsname, days ) a ) b GROUP BY b.tsname ORDER BY b.tsname
/

EOF
echo "Continue? ("q" to return to main menu)"
read rep
done 
########################################tablespace to owner #####################################################3

elif [ "$CHOICE" = "4"  ]

then
rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

----TABLESPACE GROWTH all


set serverout on
set verify off
set lines 200
set pages 2000
DECLARE
v_ts_id number;
not_in_awr EXCEPTION;
v_ts_block_size number;
v_begin_snap_id number;
v_end_snap_id number;
v_begin_snap_date date;
v_end_snap_date date;
v_numdays number;
v_ts_begin_size number;
v_ts_end_size number;
v_ts_growth number;
v_count number;
v_ts_begin_allocated_space number;
v_ts_end_allocated_space number;
cursor v_cur is select tablespace_name from dba_tablespaces where contents='PERMANENT';

BEGIN
FOR v_rec in v_cur
LOOP
BEGIN
SELECT ts# into v_ts_id FROM v\$tablespace where name = v_rec.tablespace_name;
SELECT count(*) INTO v_count FROM dba_hist_tbspc_space_usage where tablespace_id=v_ts_id;
IF v_count = 0 THEN 
RAISE not_in_awr;
END IF ;
SELECT block_size into v_ts_block_size FROM dba_tablespaces where tablespace_name = v_rec.tablespace_name;
SELECT min(snap_id), max(snap_id), min(trunc(to_date(rtime,'MM/DD/YYYY HH24:MI:SS'))), max(trunc(to_date(rtime,'MM/DD/YYYY HH24:MI:SS')))
into v_begin_snap_id,v_end_snap_id, v_begin_snap_date, v_end_snap_date from dba_hist_tbspc_space_usage where tablespace_id=v_ts_id;
v_numdays := v_end_snap_date - v_begin_snap_date;

SELECT round(max(tablespace_size)*v_ts_block_size/1024/1024,2) into v_ts_begin_allocated_space from dba_hist_tbspc_space_usage where tablespace_id=v_ts_id and snap_id = v_begin_snap_id;
SELECT round(max(tablespace_size)*v_ts_block_size/1024/1024,2) into v_ts_end_allocated_space from dba_hist_tbspc_space_usage where tablespace_id=v_ts_id and snap_id = v_end_snap_id;
SELECT round(max(tablespace_usedsize)*v_ts_block_size/1024/1024,2) into v_ts_begin_size from dba_hist_tbspc_space_usage where tablespace_id=v_ts_id and snap_id = v_begin_snap_id;
SELECT round(max(tablespace_usedsize)*v_ts_block_size/1024/1024,2) into v_ts_end_size from dba_hist_tbspc_space_usage where tablespace_id=v_ts_id and snap_id = v_end_snap_id;
v_ts_growth := v_ts_end_size - v_ts_begin_size;
DBMS_OUTPUT.PUT_LINE(CHR(10));
DBMS_OUTPUT.PUT_LINE(v_rec.tablespace_name||' Tablespace');
DBMS_OUTPUT.PUT_LINE('--------------------');
DBMS_OUTPUT.PUT_LINE('Tablespace Block Size: '||v_ts_block_size);
DBMS_OUTPUT.PUT_LINE('---------------------------');
DBMS_OUTPUT.PUT_LINE(CHR(10));
DBMS_OUTPUT.PUT_LINE('Summary');
DBMS_OUTPUT.PUT_LINE('========');
DBMS_OUTPUT.PUT_LINE('1) Allocated Space: '||v_ts_end_allocated_space||' MB'||' ('||round(v_ts_end_allocated_space/1024,2)||' GB)');
DBMS_OUTPUT.PUT_LINE('2) Used Space: '||v_ts_end_size||' MB'||' ('||round(v_ts_end_size/1024,2)||' GB)');
DBMS_OUTPUT.PUT_LINE('3) Used Space Percentage: '||round(v_ts_end_size/v_ts_end_allocated_space*100,2)||' %');
DBMS_OUTPUT.PUT_LINE(CHR(10));
DBMS_OUTPUT.PUT_LINE('History');
DBMS_OUTPUT.PUT_LINE('========');
DBMS_OUTPUT.PUT_LINE('1) Allocated Space on '||v_begin_snap_date||': '||v_ts_begin_allocated_space||' MB'||' ('||round(v_ts_begin_allocated_space/1024,2)||' GB)');
DBMS_OUTPUT.PUT_LINE('2) Current Allocated Space on '||v_end_snap_date||': '||v_ts_end_allocated_space||' MB'||' ('||round(v_ts_end_allocated_space/1024,2)||' GB)');
DBMS_OUTPUT.PUT_LINE('3) Used Space on '||v_begin_snap_date||': '||v_ts_begin_size||' MB'||' ('||round(v_ts_begin_size/1024,2)||' GB)' );
DBMS_OUTPUT.PUT_LINE('4) Current Used Space on '||v_end_snap_date||': '||v_ts_end_size||' MB'||' ('||round(v_ts_end_size/1024,2)||' GB)' );
DBMS_OUTPUT.PUT_LINE('5) Total growth during last '||v_numdays||' days between '||v_begin_snap_date||' and '||v_end_snap_date||': '||v_ts_growth||' MB'||' ('||round(v_ts_growth/1024,2)||' GB)');
IF (v_ts_growth <= 0 OR v_numdays <= 0) THEN
DBMS_OUTPUT.PUT_LINE(CHR(10));
DBMS_OUTPUT.PUT_LINE('!!! NO DATA GROWTH WAS FOUND FOR TABLESPACE '||v_rec.tablespace_name||' !!!');
ELSE
DBMS_OUTPUT.PUT_LINE('6) Per day growth during last '||v_numdays||' days: '||round(v_ts_growth/v_numdays,2)||' MB'||' ('||round((v_ts_growth/v_numdays)/1024,2)||' GB)');
DBMS_OUTPUT.PUT_LINE(CHR(10));
DBMS_OUTPUT.PUT_LINE('Expected Growth');
DBMS_OUTPUT.PUT_LINE('===============');
DBMS_OUTPUT.PUT_LINE('1) Expected growth for next 30 days: '|| round((v_ts_growth/v_numdays)*30,2)||' MB'||' ('||round(((v_ts_growth/v_numdays)*30)/1024,2)||' GB)');
DBMS_OUTPUT.PUT_LINE('2) Expected growth for next 60 days: '|| round((v_ts_growth/v_numdays)*60,2)||' MB'||' ('||round(((v_ts_growth/v_numdays)*60)/1024,2)||' GB)');
DBMS_OUTPUT.PUT_LINE('3) Expected growth for next 90 days: '|| round((v_ts_growth/v_numdays)*90,2)||' MB'||' ('||round(((v_ts_growth/v_numdays)*90)/1024,2)||' GB)');
END IF;
DBMS_OUTPUT.PUT_LINE('/\/\/\/\/\/\/\/\/\/\/\/ END \/\/\/\/\/\/\/\/\/\/\/\');

EXCEPTION
WHEN NOT_IN_AWR THEN
DBMS_OUTPUT.PUT_LINE(CHR(10));
DBMS_OUTPUT.PUT_LINE(v_rec.tablespace_name||' Tablespace');
DBMS_OUTPUT.PUT_LINE('--------------------');
DBMS_OUTPUT.PUT_LINE('Tablespace Block Size: '||v_ts_block_size);
DBMS_OUTPUT.PUT_LINE('---------------------------');
DBMS_OUTPUT.PUT_LINE(CHR(10));
DBMS_OUTPUT.PUT_LINE('!!! TABLESPACE USAGE INFORMATION NOT FOUND IN AWR !!!');
DBMS_OUTPUT.PUT_LINE('/\/\/\/\/\/\/\/\/\/\/\/ END \/\/\/\/\/\/\/\/\/\/\/\');
NULL;
END;
END LOOP;
END;
/

EOF



echo "Continue? ("q" to return to main menu)"
read rep
done
 
########################################all datafiles mb #####################################################3
elif [ "$CHOICE" = "5"  ]

then

rep=""
      while [ "$rep" != "q" ]
do

$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF

SET PAUSE ON
SET PAUSE 'Press Return to Continue'
SET PAGESIZE 60
SET LINESIZE 300
SET VERIFY OFF
 set pages 1000
select trunc(COMPLETION_TIME,'DD') Day, thread#, round(sum(BLOCKS*BLOCK_SIZE)/1048576) MB,count(*) Archives_Generated from gv\$archived_log
group by trunc(COMPLETION_TIME,'DD'),thread# order by 1;

EOF

echo "Continue? ("q" to return to main menu)"
read rep
done
 
 
 
 
 
 
 
#####################################################################################
 else
               echo " thanks you "
        fi


done
}





main( )
{
################################################################
############main loop###########################################
################################################################
$ORACLE_HOME/bin/sqlplus -s '/ as sysdba' <<EOF
set sqlprompt "_user'@'_connect_identifier> "
set linesize 190
set pages 1000
set long 32000
col name for a60
col OWNER for a25
col OBJECT_NAME for a40
col SPID for a10
col PROGRAM for a40
col TRACEID for a25
col TRACEFILE for a65
col inst_name for a20
col host_name for a30
col member for a70
col file_name for a70
col OS_USERNAME for a20
col username for a20
col userhost for a20
col TERMINAL for a15
col TIMESTAMP for a30
col ACTION_NAME for a10
col ACCOUNT_STATUS for a16
col tablespace_name for a40
-- Used by Trusted Oracle
COLUMN ROWLABEL FORMAT A15
-- Used for the SHOW ERRORS command
COLUMN LINE/COL FORMAT A8
COLUMN ERROR    FORMAT A65  WORD_WRAPPED
-- Used for the SHOW SGA command
COLUMN name_col_plus_show_sga FORMAT a24
-- Defaults for SHOW PARAMETERS
COLUMN name_col_plus_show_param FORMAT a36 HEADING NAME
COLUMN value_col_plus_show_param FORMAT a30 HEADING VALUE
-- Defaults for SET AUTOTRACE EXPLAIN report
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
--alter session set nls_date_format = 'DD-Mon-YYYY HH24:MI:SS';
col BLOCKED for a7
col STARTUP_TIME for a19
select instance_name INS_NAME,STATUS,DATABASE_STATUS DB_STATUS,LOGINS,BLOCKED,to_char(STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME 
from v\$instance;

/

set feedback off
set serverout on size 50000
declare 
cursor c1 is select version
from v\$instance;
cursor c2 is
    select
          host_name
       ,  instance_name
       ,  to_char(sysdate, 'HH24:MI:SS DD-MON-YY') currtime
       ,  to_char(startup_time, 'HH24:MI:SS DD-MON-YY') starttime
     from v\$instance;
cursor c3 is 
select platform_name 
from v\$database;
cursor c4 is
select * from (SELECT count(*) cnt, substr(event,1,50) event
FROM v\$session_wait
WHERE wait_time = 0
AND event NOT IN ('smon timer','pipe get','wakeup time manager','pmon timer','rdbms ipc message',
'SQL*Net message from client')
GROUP BY event
ORDER BY 1 DESC) where rownum <6;
cursor c5 is
select round(sum(value)/1048576) as sgasize from v\$sga;
cursor c6 is select round(sum(bytes)/1048576) as dbsize 
from v\$datafile;
begin
dbms_output.put_line ('Database Version');
dbms_output.put_line ('-----------------');
for rec in c1
loop
dbms_output.put_line(rec.version);
end loop;
dbms_output.put_line( chr(13) );
dbms_output.put_line('Hostname');
dbms_output.put_line ('----------');
for rec in c2
loop
     dbms_output.put_line(rec.host_name);
end loop;
dbms_output.put_line( chr(13) );
dbms_output.put_line('Platform');
dbms_output.put_line ('----------');
for rec in c3
loop
     dbms_output.put_line(rec.platform_name);
end loop;
dbms_output.put_line( chr(13) );
dbms_output.put_line('SGA Size (MB)');
dbms_output.put_line ('-------------');
for rec in c5
loop
     dbms_output.put_line(rec.sgasize);
end loop;
dbms_output.put_line( chr(13) );
dbms_output.put_line('Database Size (MB)');
dbms_output.put_line ('-----------------');
for rec in c6
loop
     dbms_output.put_line(rec.dbsize);
end loop;
dbms_output.put_line( chr(13) );
dbms_output.put_line('Instance start-up time');
dbms_output.put_line ('-----------------------');
for rec in c2 loop
 dbms_output.put_line( rec.starttime );
  end loop;
dbms_output.put_line( chr(13) );
  for b in
    (select total, active, inactive, system, killed
    from
       (select count(*) total from v\$session)
     , (select count(*) system from v\$session where username is null)
     , (select count(*) active from v\$session where status = 'ACTIVE' and username is not null)

     , (select count(*) inactive from v\$session where status = 'INACTIVE')
     , (select count(*) killed from v\$session where status = 'KILLED')) loop
dbms_output.put_line('Active Sessions');
dbms_output.put_line ('---------------');
dbms_output.put_line(b.total || ' sessions: ' || b.inactive || ' inactive,' || b.active || ' active, ' || b.system || ' system, ' || b.killed || ' killed ');

  end loop;
  dbms_output.put_line( chr(13) );
 dbms_output.put_line( 'Sessions Waiting' );
  dbms_output.put_line( chr(13) );
dbms_output.put_line('Count      Event Name');
dbms_output.put_line('-----      -----------------------------------------------------');
for rec in c4 
loop
dbms_output.put_line(rec.cnt||'          '||rec.event);
end loop;
dbms_output.put_line( chr(13) );

end;
/


COLUMN pool    HEADING "Pool"
COLUMN name    HEADING "Name"
COLUMN sgasize HEADING "Allocated" FORMAT 999,999,999
COLUMN bytes   HEADING "Free" FORMAT 999,999,999

SELECT
    f.pool
  , f.name
  , s.sgasize
  , f.bytes
  , ROUND(f.bytes/s.sgasize*100, 2) "% Free"
FROM
    (SELECT SUM(bytes) sgasize, pool FROM v\$sgastat GROUP BY pool) s
  , v\$sgastat f
WHERE
    f.name = 'free memory'
  AND f.pool = s.pool
/


PROMPT
PROMPT
PROMPT INSTALLED COMPONENTS IN THE DATABASE AND THEIR STATUS
PROMPT
SET LINESIZE 145
SET PAGESIZE 9999
SET VERIFY   OFF

COLUMN comp_id    FORMAT a9    HEADING 'Component|ID'
COLUMN comp_name  FORMAT a35   HEADING 'Component|Name'
COLUMN version    FORMAT a13   HEADING 'Version'
COLUMN status     FORMAT a11   HEADING 'Status'
COLUMN modified                HEADING 'Modified'
COLUMN Schema     FORMAT a8    HEADING 'Schema'
COLUMN procedure  FORMAT a41   HEADING 'Procedure'

SELECT
    comp_id
  , comp_name
  , version
  , status
  , modified
  , schema
FROM
    dba_registry;








EOF
while [ 1 ]
do
 #       tput clear
        echo -e "\n"
echo -e "\t\t\t$MESSAGE\t"
echo -e
#echo -e "\t\t\tConnected to Database- `tput smso`$Yellow$tns`tput rmso`\t"
echo -e "\t###################### MAIN MENU :#####################"
echo -e "\t#######################################################"
echo -e "\t"
echo -e "\t(1) TABLESPACE DETAILS                                         "
echo -e "\t(2) unix_information(mount monitor home genral info )        "
echo -e "\t(3) Perfomance tunning (All)                                         "
echo -e "\t(4) Database Security                                        "
echo -e "\t(5) User Managment                                          "
echo -e "\t(6) DATABASE OBJECT                                         "
echo -e "\t(7) perfomance_2                                         "
echo -e "\t(8) FRA                                         "
echo -e "\t(9) DATABASE GROTH                                        "
echo -e "\t(6) DATABASE OBJECT                                         "
echo -e "\t(6) DATABASE OBJECT                                         "
echo -e "\t(6) DATABASE OBJECT                                         "
echo -e "\t(6) DATABASE OBJECT                                         "
echo -e "\t(6) DATABASE OBJECT                                         "
echo -e "\t(6) DATABASE OBJECT                                         "
echo -e "\t(6) DATABASE OBJECT                                         "
echo -e "\n"
echo -e "\tEnter your choice (q to quit): \c                             "
echo -e "\n"
echo -e "\t########################################################"
#tput cup 16 40
 CHOICE=""
        read CHOICE
        if [ "$CHOICE" = "q" -o "$CHOICE" = "Q" ]
        then
                echo -e "Quitting..."
#itput clear
                exit [ 0 ]
        elif [ "$CHOICE" = "1"  ]
        then
                TABLESPACE
				
		elif [ "$CHOICE" = "2"  ]
        then
                unix_menu
				
		elif [ "$CHOICE" = "3"  ]
        then
                perfomance	
				
        elif [ "$CHOICE" = "4"  ]
        then
                dbmon	
		
		elif [ "$CHOICE" = "5"  ]
        then
                user	
	
		elif [ "$CHOICE" = "6"  ]
        then
                object	
				
		elif [ "$CHOICE" = "7"  ]
        then
                perfomance_2
				
		elif [ "$CHOICE" = "8"  ]
        then
                fra		
				
		elif [ "$CHOICE" = "9"  ]
        then
                growth				
		else
                echo " thanks you"
        fi

done
}



info
main
###############
###############
# REPORT BUGS to: <vishalvilas.b@gmail.com>.
# DISCLAIMER: THIS SCRIPT IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT WITHOUT ANY WARRANTY. IT IS PROVIDED "AS IS".
# DOWNLOAD THE LATEST VERSION OF DATABASE ADMINISTRATION BUNDLE FROM: http://vbtech.com
