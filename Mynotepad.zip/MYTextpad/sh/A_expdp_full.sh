#!/bin/sh

export host=`hostname`
export ORACLE_HOME=/u01/app/oracle/product/rac/11.2.0.4
PATH=$PATH:$HOME/bin:$ORACLE_HOME/bin
export PATH

export ORACLE_SID=EP2MPRD2

export BKUP_DATE=`date +%d_%m_%Y_%H%M`
export BKUP_DIR_PATH=/u02/bkup_EP2MPRD2_DB
export BKUP_DUMPFILE=expdp_bkup_${ORACLE_SID}_${BKUP_DATE}
export BKUP_LOGFILE=logfs_expdp_bkup_${ORACLE_SID}_${BKUP_DATE}

export BKUP_DIR_NAME=EXP_FULL_EP2MPRD2
export TAR_ZIP_BKUP_FILES=${BKUP_DUMPFILE}

# do cd to backup directory
cd ${BKUP_DIR_PATH}

# start full backup of EP2MPRD2 database
expdp \'/as sysdba\' DUMPFILE=${BKUP_DUMPFILE}.dmp LOGFILE=${BKUP_LOGFILE}.log directory=${BKUP_DIR_NAME} full=Y compression=all content=all

# compress the backup dump and log files using tar.gz command
tar -cvf ${TAR_ZIP_BKUP_FILES}.tar.gz ${BKUP_DUMPFILE} ${BKUP_LOGFILE}

# delete the 3 days older .tar.gz file to save the space
find ${TAR_ZIP_BKUP_FILES}.tar.gz -type f -mtime +3 -exec rm {} \;

# echo Backup Completed

# modify the script if the you see the ORA- errors in export backup .log file and
# send a mail to DLINO-NAIMO-ORACLE-SUPPORT.it-solutions@atos.net group
# echo "this is the body of the email" | mail -s "testing mail" rahul.chaudhari@atos.net

