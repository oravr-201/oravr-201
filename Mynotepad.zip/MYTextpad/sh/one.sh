mkdir /home/oracle/BackupReport

export ORACLE_HOME=/u01/app/oracle/product/rac/11.2.0.4
export PATH=$PATH:$ORACLE_HOME/bin
export ORACLE_SID=EP2PRD1
export Day=`date +%d%b%Y`
sqlplus "/ as sysdba" << EOF >/home/oracle/BackupReport/Backup_$Day.log
@aa.sql
EOF


export ORACLE_HOME=/u01/app/oracle/product/rac/11.2.0.4
export PATH=$PATH:$ORACLE_HOME/bin
export ORACLE_SID=EP2MPRD1
export Day=`date +%d%b%Y`
sqlplus "/ as sysdba" << EOF >>/home/oracle/BackupReport/Backup_$Day.log
@aa.sql
EOF

export ORACLE_HOME=/u01/app/oracle/product/rac/11.2.0.4
export PATH=$PATH:$ORACLE_HOME/bin
export ORACLE_SID=EP2AUD1
export Day=`date +%d%b%Y`
sqlplus "/ as sysdba" << EOF >>/home/oracle/BackupReport/Backup_$Day.log
@aa.sql
EOF

cat /home/oracle/BackupReport/Backup_$Day.log |grep -i complete > /home/oracle/BackupReport/Backup_Final_$Day.log
cat /home/oracle/BackupReport/Backup_$Day.log |grep -i fail >> /home/oracle/BackupReport/Backup_Final_$Day.log
cat /home/oracle/BackupReport/Backup_$Day.log |grep -i run >> /home/oracle/BackupReport/Backup_Final_$Day.log
#cp /oracle/oracle/BackupReport/Backup_Final_$Day.log /oracle/oracle/BackupReport/Backup_Final_$Day.csv
mail -s "test backup " -a /home/oracle/BackupReport/Backup_Final_$Day.log    vishal-vilas.bandwalkar@atos.net
#mail -s "Siemens_Backup_USLZUA4009BSRV_OT17 " -a /oracle/oracle/BackupReport/Backup_Final_$Day.log DLINO-NAIMO-ORACLE-SUPPORT.it-solutions@atos.net

