oracle> cat /home/oracle/backup_report.sh
cd
#bash
#. .profile
export ORACLE_HOME=/u01/app/oracle/product/12.1.0/dbhome_1
export PATH=$PATH:$ORACLE_HOME/bin
export ORACLE_SID=infradbp
export Day=`date +%d%b%Y`
sqlplus "/ as sysdba" << EOF >/home/oracle/BackupReport/Backup_$Day.log
@d.sql
EOF

cat /home/oracle/BackupReport/Backup_$Day.log |grep -i complete > /home/oracle/BackupReport/Backup_Final_$Day.log
cat /home/oracle/BackupReport/Backup_$Day.log |grep -i fail >> /home/oracle/BackupReport/Backup_Final_$Day.log
cat /home/oracle/BackupReport/Backup_$Day.log |grep -i run >> /home/oracle/BackupReport/Backup_Final_$Day.log




