1. introduction about "Oracle Checkpoint ".
	Our core areas 
	faculty names in short 
	our focus 
	our Goals
	our Tranings 
	



Part 1. prerequestites of oracle instaltion 
	1. requires hardware 
	2. required softwares
		optional & manditory 
	3. required Hardware Links and software Links.

	
Part 2. instation of Mandatory Software 
	Putty 
	winscp
	Vmware
	Mputty
	
	
part 3. instalation optional Softwares 
	vncserver 
	Acebackup
	Winscp
	VMware esxi
	
Part 4. Instalation of VMware
	1. workstation 
	2. ESxi
	
Part 5. OS isntation 
	How to download OS from Lunix web.
	How to isntall Rpm (external)
	RHEL 6.9
	Os required files for database adminstaration 
	files Location 
	How to Access Os from remote 
	

	
	
	
	
	oracle database instalation 12c 
	