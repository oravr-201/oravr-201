CREATE OR REPLACE PROCEDURE SNOX4TRANSNOX."PROC_REPLICATION_CHECK" (
   inDatabase           IN VARCHAR2,
   inLagAlertThreshold    IN NUMBER,
   outMessage           OUT VARCHAR2)
IS
   tmpVar          NUMBER;
   vDatabaseRole   DATABASE_INFO.DB_ROLE%TYPE;
   vLag            NUMBER;
   vDC             DATABASE_INFO.DC%TYPE;
         
/******************************************************************************
   NAME:       Proc_Replication_check
   PURPOSE:

  
   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     Proc_Replication_check
      Sysdate:         11/6/2015
      Date and Time:   11/6/2015, 12:51:07 PM, and 11/6/2015 12:51:07 PM
     Table Name:       (set in the "New PL/SQL Object" dialog)

******************************************************************************/
BEGIN
   tmpVar := 0;

   ----Check Database Role
   BEGIN
      SELECT db_role,DC
        INTO vDatabaseRole,vDC
        FROM DATABASE_INFO
       WHERE db_name = inDatabase;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         outMessage :=
               'No Data Found  Exception for Database '
            || inDatabase
            || ' from database_info Table';
         RETURN;
      WHEN TOO_MANY_ROWS
      THEN
         outMessage :=
               'Too Many Rows Exception for Database '
            || inDatabase
            || ' from database_info Table';
         RETURN;
      WHEN OTHERS
      THEN
         outMessage :=
               'Other Exception for Database '
            || inDatabase
            || ' from database_info Table';
         RETURN;
   END;

   IF vDatabaseRole = 'iPrimary'
   THEN
      BEGIN
         UPDATE REPLICATION_STATUS
            SET CURRENT_DATE1 = SYSDATE
          WHERE first_row = 1;

         IF SQL%ROWCOUNT = 0
         THEN
            INSERT INTO REPLICATION_STATUS
                 VALUES (1, SYSDATE);
         END IF;
      END;
   ELSE
      --Check Lag
      SELECT ROUND((SYSDATE - CURRENT_DATE1)*1440)
        INTO vLag
        FROM REPLICATION_STATUS
       WHERE first_row = 1;
       IF vLag >    inLagAlertThreshold  
       THEN 
       NULL;
       --Send Mail 
       transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','acq-tasc@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','ifx-dbalerts@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','acq-commandcenter@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','ACQ-Appl-ProductionSupport@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','TransITAlerts@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
        transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','replication-lag@tsysmerchant.pagerduty.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
--       transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','TSC_Management@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       --transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','SSuryavanshi@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       END IF; 
   END IF;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      NULL;
   WHEN OTHERS
   THEN
      -- Consider logging the error and then re-raise
      RAISE;
END PROC_REPLICATION_CHECK;   /* GOLDENGATE_DDL_REPLICATION */
/


























-----------------------------------------------------------------------------------------------





















CREATE OR REPLACE PROCEDURE TRANSITHA.sendmail_oracle (fromm    VARCHAR2,
                                      too      VARCHAR2,
                                      sub      VARCHAR2,
                                      body     VARCHAR2,
                                      port     NUMBER)
IS
   objConnection   UTL_SMTP.connection;
   vrData          VARCHAR2 (32000);
BEGIN
--   objConnection := UTL_SMTP.open_connection ('smtp.tsysacquiring.org', port);
--   UTL_SMTP.helo (objConnection, 'smtp.tsysacquiring.org');
   objConnection := UTL_SMTP.open_connection ('smtpwest.tas.corp', port);
   UTL_SMTP.helo (objConnection, 'smtpwest.tas.corp');
   UTL_SMTP.mail (objConnection, fromm);
   UTL_SMTP.rcpt (objConnection, too);
   UTL_SMTP.open_data (objConnection);
   /* ** Sending the header information */
   UTL_SMTP.write_data (objConnection, 'From: ' || fromm || UTL_TCP.CRLF);
   UTL_SMTP.write_data (objConnection, 'To: ' || too || UTL_TCP.CRLF);
   UTL_SMTP.write_data (objConnection, 'Subject: ' || sub || UTL_TCP.CRLF);
   UTL_SMTP.write_data (objConnection,
                        'MIME-Version: ' || '1.0' || UTL_TCP.CRLF);
   UTL_SMTP.write_data (objConnection, 'Content-Type: ' || 'text/html;');
   UTL_SMTP.write_data (
      objConnection,
      'Content-Transfer-Encoding: ' || '"8Bit"' || UTL_TCP.CRLF);
   UTL_SMTP.write_data (objConnection, UTL_TCP.CRLF);
   UTL_SMTP.write_data (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.write_data (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.write_data (
      objConnection,
         UTL_TCP.CRLF
      || '<span style="color: red; font-family: Courier New;">'
      || body
      || '</span>');
   UTL_SMTP.write_data (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.write_data (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.close_data (objConnection);
   UTL_SMTP.quit (objConnection);
EXCEPTION
   WHEN UTL_SMTP.transient_error OR UTL_SMTP.permanent_error
   THEN
      UTL_SMTP.quit (objConnection);
      DBMS_OUTPUT.put_line (SQLERRM);
   WHEN OTHERS
   THEN
      UTL_SMTP.quit (objConnection);
      DBMS_OUTPUT.put_line (SQLERRM);
END sendmail_oracle;  /* GOLDENGATE_DDL_REPLICATION */
/

-------------------------------------------------


ALTER TABLE SNOX4TRANSNOX.DATABASE_INFO
 DROP PRIMARY KEY CASCADE;

DROP TABLE SNOX4TRANSNOX.DATABASE_INFO CASCADE CONSTRAINTS;

CREATE TABLE SNOX4TRANSNOX.DATABASE_INFO
(
  DB_NAME  VARCHAR2(15 BYTE),
  DB_ROLE  VARCHAR2(15 BYTE),
  DC       VARCHAR2(3 BYTE),
  SUPPLEMENTAL LOG GROUP GGS_430722 (DB_NAME) ALWAYS,
  SUPPLEMENTAL LOG DATA (PRIMARY KEY) COLUMNS
)
TABLESPACE TNOX_DATA_CPASS
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--  There is no statement for index SNOX4TRANSNOX.SYS_C0066279.
--  The object is created when the parent object is created.

ALTER TABLE SNOX4TRANSNOX.DATABASE_INFO ADD (
  PRIMARY KEY
  (DB_NAME)
  USING INDEX
    TABLESPACE TNOX_DATA_CPASS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
  ENABLE VALIDATE);
  
  
  
  
  
  
  
  
  --------------------------------------------------------
  
  
 ALTER TABLE SNOX4TRANSNOX.REPLICATION_STATUS
 DROP PRIMARY KEY CASCADE;

DROP TABLE SNOX4TRANSNOX.REPLICATION_STATUS CASCADE CONSTRAINTS;

CREATE TABLE SNOX4TRANSNOX.REPLICATION_STATUS
(
  FIRST_ROW      NUMBER,
  CURRENT_DATE1  DATE,
  SUPPLEMENTAL LOG GROUP GGS_430721 (FIRST_ROW) ALWAYS,
  SUPPLEMENTAL LOG DATA (PRIMARY KEY) COLUMNS
)
TABLESPACE TNOX_DATA_CPASS
RESULT_CACHE (MODE DEFAULT)
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MAXSIZE          UNLIMITED
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


--  There is no statement for index SNOX4TRANSNOX.SYS_C0066280.
--  The object is created when the parent object is created.

ALTER TABLE SNOX4TRANSNOX.REPLICATION_STATUS ADD (
  PRIMARY KEY
  (FIRST_ROW)
  USING INDEX
    TABLESPACE TNOX_DATA_CPASS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MAXSIZE          UNLIMITED
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
                BUFFER_POOL      DEFAULT
                FLASH_CACHE      DEFAULT
                CELL_FLASH_CACHE DEFAULT
               )
  ENABLE VALIDATE);

  
  
  
  
  
  
