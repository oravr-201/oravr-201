---vi Editor all commands and shotcut for day to day DBA things 

https://www.cs.colostate.edu/helpdocs/vi.html

-- oracle dataguard commands :
https://oracle-sid.blogspot.com/2015/07/data-guard-sync-status.html