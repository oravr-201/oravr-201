---vi Editor all commands and shotcut for day to day DBA things 

https://www.cs.colostate.edu/helpdocs/vi.html

