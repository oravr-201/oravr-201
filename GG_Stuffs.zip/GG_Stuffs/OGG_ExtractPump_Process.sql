--
--                 TSYS
--
-- 
-- DCE Extract Pump Process Primary DB (PPTWRE)
-- 
-- This PUMP will replicate data from DCW Reporting DB to DCE Reporting DB
-- 
--
-- Set the runtime attributes for an Exract Data Pump which reads
-- from a local Extract Trail, then transmits the data to a Remote
-- file location (RMTTRAIL) on the target GoldenGate server..
--

-- EXTRACT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (PPTWRE.prm) must exist in the
-- dirprm directory/folder.
EXTRACT PPTWRE

-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
-- CHECKPARAMS

-- RMTHOST defines the target server Extract will transmit to.
-- <host/ipaddress> is the target server DNS name, or configured
-- tcp/ip address. MGRPORT is the GoldenGate Manager
-- Listener port configured in the target mgr.prm file. COMPRESS
-- states that outgoing blocks of records are to be compressed to
-- reduce bandwidth requirements. A 4:1 compressioin ratio, or more
-- is not uncommon; however additional CPU resource is required for
-- compression on the source side, and decmpression on the target.
-- Replace <host/ipaddress> with the target GoldenGate server
-- name or ip address.
RMTHOST epl1trandbrpt1.tsysacquiring.org, MGRPORT 15001, COMPRESS
		
-- RMTTRAIL indentifies thedirectory/folder and file identifier on the
-- target server where Extract will write its data. When the
-- file is created on disk, six digits are appended to the two
-- character identifier; starting with 000000. As the file reaches
-- maximum capacity a new file is created and Extract rolls to that
-- new file. A maximun of 999999 Extract Trail files may exist
-- per GoldenGate Extract; however, each file name set must be
-- unique for the server where the Extract runs.
RMTTRAIL /acfs/goldengate/dirdat/WC

-- PASSTHRU denotes that the Extract does not evaluate the data,
-- meaning that it does not log into the database and lookup the table
-- definitions. The data is read and passed through to the target server.
PASSTHRU

------------------------------------------------------------------------------------
-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 00:01

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 00:01

-- REPORTCOUNT denotes that every 60 seconds the Extract report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE
-- End of "best practices" section
------------------------------------------------------------------------------------


-- List of Sequences
SEQUENCE KEYNOX_CPASS.*;
SEQUENCE WEBFORT_CPASS.*;
SEQUENCE TRANSNOX_CAT.*;
SEQUENCE TRANSNOX_IOX.*;
SEQUENCE SNOX4TRANSNOX.*;
SEQUENCE TRANSTSYSPAYMENTGW.*;

-- List of Mother schemas
TABLE KEYNOX_CPASS.*;
TABLE SNOX4TRANSNOX.*;
TABLE TRANSNOX_CAT.*;
TABLE TRANSNOX_IOX.*;
TABLE WEBFORT_CPASS.*;
TABLE TRANSTSYSPAYMENTGW.*;

-- List of APP Schemas
TABLE ETLUPDATE.*;
TABLE SNOX4TRANSNOX_APP.*;
TABLE TRANSNOX_IOX_APP.*;
TABLE TRANSTSYSPAYMENTGWAPP.*;

-- Current VBS
TABLE SNOXPASS_GWAY_011.*;	
TABLE TNOXPASS_GWAY_011.*;
TABLE SNOXPASS_TFE_2016.*;	
TABLE TNOXPASS_TFE_2016.*;	
TABLE SNOXPASS_SMSNOX_306.*;
TABLE TNOXPASS_SMSNOX_306.*;	

-- Old VBS
TABLE TNOXPASS_GWAY_010.*;	
TABLE SNOXPASS_GWAY_010.*;	
TABLE SNOXPASS_SMSNOX_305.*;	
TABLE TNOXPASS_SMSNOX_305.*;
TABLE TNOXPASS_TFE_2015.*;
TABLE SNOXPASS_TFE_2015.*;
