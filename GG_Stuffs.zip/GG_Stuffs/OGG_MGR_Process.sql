-- PORT 15001

-- DYNAMICPORTLIST 15002-15025

-- PURGEOLDEXTRACTS /acfs/goldengate/dirdat/*, USECHECKPOINTS, MINKEEPDAYS 2

-- AUTORESTART ER *, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30


--<< START_OF_FILE
--
--
-- 				TSYS
--
-- GoldenGate Manager Parameter File (mgr.prm)
--
-- Set the runtime attributes for manager
-- Parameters are not case sensitive (can be lower, upper, or mixed case).
-- Directory and file names are case sensitive for Linux and UNIX only.

-- PORT sets the GoldenGate Manager Listener port.
-- Manager listens on this port for GoldenGate connection requests
-- These requests can come from Director or GoldenGate Extract.
-- Any other entity attemtpting to connect to this port will receive a
-- "refused" reply
-- Manger requires the port for running. By default manager port is 7809.
-- We can use different port for the same.
PORT 15001

-- DYNAMICPORTLIST sets the port, series, or range of ports where two way
-- communication will be allowed for Director or GoldenGate Extract. If the
-- connect request comes from GoldenGate Extract, Manager will spawn a
-- process of the Server executable. This process receives data transmitted
-- over TCP/IP by Extract and performs a disk operation into the designated
-- file location.
DYNAMICPORTLIST 15002-15025

-- User name and password to login to manager process
USERID ggate, PASSWORD tsys123

-- Autorestart if process terminates abnormally
-- RESETMINUTES <reset minutes> : The window of time, in minutes, during which retries are
-- counted. The default is 120 minutes (2 hours). After the time expires, the number
-- of retries reverts to zero.

-- RETRIES <max retries> : The maximum number of times that Manager should try to restart a
--                         process before aborting retry efforts. The default number of tries is 2.
-- WAITMINUTES <wait minutes> : The amount of time, in minutes, to pause between discovering that a process has
--                              terminated abnormally and restarting the process. Use this option to delay restarting
--                              until a necessary resource becomes available or some other
--                              event occurs. The default delay is 2 minutes.
-- RESETMINUTES <reset minutes> : The window of time, in minutes, during which retries are counted. The default is 120 minutes (2 hours).
--                               After the time expires, the number of retries reverts to zero.
-- E for Extract and R for Replicat
-- AUTORESTART ER *, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART EXTRACT EPRW, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART EXTRACT PPRERW, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30

AUTORESTART REPLICAT RPRW, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART REPLICAT RPRWTE, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART REPLICAT RPRWRE, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30

--Specifies maximum lag time in minutes after which a warning should be logged in the error log ggserror.log
LAGCRITICALMINUTES 5

-- Specifies maximum lag time in minutes after which the error should be logged
-- in the error log. Once the LAGCRITICALMINUTES time exceeds.
LAGINFOMINUTES 10

-- it is the time interval at which manager checks extract, pump or replicat process for lag.
LAGREPORTMINUTES 60

-- PURGEOLDEXTRACTS is used for housekeeping purposes.
-- Every 10 minutes Manager spawns a housekeeping process that checks for
-- amongst other things, files that are no longer needed. Any files in the designated
-- directory or folder will be purged if there are no GoldenGate processes that require
-- the file (holding a checkpoint to the file).
PURGEOLDEXTRACTS  /acfs/goldengate/dirdat/*, USECHECKPOINTS, MINKEEPDAYS 8

-->> END_Of_File