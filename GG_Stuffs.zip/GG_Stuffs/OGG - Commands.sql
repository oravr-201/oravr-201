-- Lag is introduced by:
- Extract in reading the archive log and writing the data to a trail (or remote host), 
- (optional) datapump reading the extract trail and writing (normally) to a remote host, 
- network, 
- collector (server.exe) on the target receiving network data and writing it to a local trail,
- replicat reading the local trail and writing to the database,
- database itself.
  
-- The status and info commands from ggsci show lag, as does the send <object>, lag command.
- The sum of these reported lags is the time OGG considers as LAG.
- Lag from an info command may differ from lag from a send command by small amounts.
- Lag from an info command is returned by the manager based on the last recorded checkpoint.
- Lag from a send command is returned by the <object> based on the row timestamp that the <object> is currently processing.
 
------------------------------------------------------------------------------------------------------------------------------------

-- 2015-02-22 03:56:02 WARNING OGG-01805 Oracle GoldenGate Capture for Oracle, 
--eptw.prm: Virtual memory allocation error: 12). 
CACHEMGR CACHESIZE 2GB, CACHEDIRECTORY /acfs/goldengate/dircache 


-- Setup a GoldenGet Replication

--create a folder for goldengate Home and add the path in .bash_profile
mkdir -p /opt/app/goldengate


-- Include all contents of oracle's .bash_profile into goldengate user's .bas_profile file
-- set the os env for OGG_HOME ~/.bas_profile for 
OGG_HOME=/opt/app/goldengate; export OGG_HOME
-- add the $OGG_HOME in PATH line and also in LD_LIBRARY_PATH


-- Once done, then install the golden software in $OGG_HOME folder
unzip 112101_fbo_ggs_Linux_x64_ora11g_64bit.zip
tar -xf fbo_ggs_Linux_x64_ora11g_64bit.tar


-- connect to goldengate user 
goldengate> mkdir /acfs/goldengate/discard

./ggsci

GGSCI> create subdirs
GGSCI> exit


-- connect to oracle user
oracle> sqlplus / as sysdba

SQL> ALTER DATABASE ADD SUPPLEMENTAL LOG DATA; 

SQL> ALTER DATABASE FORCE LOGGING;

SQL> ALTER SYSTEM SWITCH LOGFILE; 

/*

Below Might be required to be done

ALTER DATABASE ADD SUPPLEMENTAL LOG DATA;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (PRIMARY KEY) COLUMNS;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (UNIQUE) COLUMNS;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (FOREIGN KEY) COLUMNS;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (ALL) COLUMNS;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA FOR PROCEDURAL REPLICATION;

*/


SQL> SELECT FORCE_LOGGING, SUPPLEMENTAL_LOG_DATA_MIN FROM V$DATABASE;

FOR SUPPLEME
--- --------
YES YES

-- trun off recyclebin for handling ddl commands
SQL> ALTER SYSTEM SET RECYCLEBIN=OFF SCOPE=SPFILE;

SQL> ALTER TABLE SYS.SEQ$ ADD SUPPLEMENTAL LOG DATA (PRIMARY KEY) COLUMNS;

-- Check the GoldenGate Parameter ENABLE_GOLDENGATE_REPLICATION, if flase then enable it
SQL> ALTER SYSTEM SET ENABLE_GOLDENGATE_REPLICATION=TRUE SCOPE=BOTH;


-- Create a separate default tablespace for ggate user.
SQL> CREATE TABLESPACE GGATE_TBS DATAFILE 
>	   '+ASMTXNDATA' SIZE 1G AUTOEXTEND OFF,
>	   '+ASMTXNDATA' SIZE 2G AUTOEXTEND ON NEXT 2M MAXSIZE UNLIMITED
>	 LOGGING
>	 ONLINE
>	 EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
>	 BLOCKSIZE 8K
>	 SEGMENT SPACE MANAGEMENT AUTO
>	 FLASHBACK ON;

-- Create connecting and Administrator user on both the DBs primary and reporting for GoldenGet Replication 
SQL> CREATE USER GGATE IDENTIFIED BY tsys123 DEFAULT TABLESPACE GGATE_TBS TEMPORARY TABLESPACE TEMP;

SQL> GRANT CONNECT, RESOURCE, UNLIMITED TABLESPACE, DBA TO GGATE; 

SQL> GRANT EXECUTE ON UTL_FILE TO GGATE;

-- The DBA role is not sufficient for advanced scenarios; you must also run the DBMS_GOLDENGATE_AUTH package. 
-- When keying in the DBMS_GOLDENGATE_AUTH command, the entire string after EXEC is without spaces or line breaks.
SQL> EXEC DBMS_GOLDENGATE_AUTH.GRANT_ADMIN_PRIVILEGE (grantee=>'GGATE',privilege_type=>'capture',grant_select_privileges=>true, do_grants=>TRUE); 


-- TNSNames.ora entry should be present on both the DBs (Primary and Reporting DBs) if you are using connection string in extract,DataPump, replicat processes
pridb=
  (DESCRIPTION=
    (ADDRESS = (PROTOCOL=TCP)(HOST=wdl2mltidbs01.tsysacquiring.org)(PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=pridb.tsysacquiring.org)
    )
  )

reptdb=
  (DESCRIPTION=
    (ADDRESS= (PROTOCOL=TCP)(HOST=wdl2mltidbs02.tsysacquiring.org) (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=reptdb.tsysacquiring.org)
    )
  )

  
-- Execute the below scripts from $OGG_HOME in GGATE schema (run on both Primary and Reporting DBs)
oracle>cd $OGG_HOME

oracle> sqlplus / as sysdba

-- when prompt for GoldenGate schemaname, then give ggate 
SQL> @marker_setup
SQL> @ddl_setup
SQL> @role_setup
SQL> @ddl_enable
SQL> @ddl_pin ggate
SQL> @sequence


-- Extract Process on DCE Primary Database
ADD EXTRACT EPTE, TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LA, EXTRACT EPTE, MEGABYTES 100

-- Pump Process for replicating data in DCE reporting database
ADD EXTRACT PPTERE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LA
ADD RMTTRAIL /acfs/goldengate/dirdat/EA, EXTRACT PPTERE, MEGABYTES 100


-- create the process on different server where you want to replicate data
-- Replicat Process
ADD REPLICAT RPTETW, EXTTRAIL /acfs/goldengate/dirdat/EA


/*

-- On Site A (Capture Site)
ADD EXTRACT EPDCW, TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /ora3/goldengate/dirdat/DW, EXTRACT EPDCW, MEGABYTES 100

-- Pump Process for replicating data in DCE reporting database
ADD EXTRACT PPTWTE, EXTTRAILSOURCE /ora3/goldengate/dirdat/DW
ADD RMTTRAIL /ora3/goldengate/dirdat/WA, EXTRACT PPTWTE, MEGABYTES 100

-- on site B (Receiver Site)
ADD REPLICAT RPTETW, EXTTRAIL /ora3/goldengate/dirdat/WA
-- If you get error : ERROR: No checkpoint table specified for ADD REPLICAT.
-- Then execute below statement with checkpointtable
-- ADD REPLICAT RPTETW, EXTTRAIL /ora3/goldengate/dirdat/WA, CHECKPOINTTABLE GGATE.CHKPTAB


-- On Site B (Capture Site)
ADD EXTRACT EPDCE, TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /ora3/goldengate/dirdat/DE, EXTRACT EPDCE, MEGABYTES 100

-- Pump Process for replicating data in DCE reporting database
ADD EXTRACT PPTETW, EXTTRAILSOURCE /ora3/goldengate/dirdat/DE
ADD RMTTRAIL /ora3/goldengate/dirdat/EA, EXTRACT PPTETW, MEGABYTES 100

-- on site A (Receiver Site)
ADD REPLICAT RPTWTE, EXTTRAIL /ora3/goldengate/dirdat/EA

*/





-- connect to goldengate user
./ggsci

GGSCI> edit params ./GLOBALS
-- Starting the file ----------
GGSCHEMA GGATE
CHECKPOINTTABLE GGATE.CHKPTAB
-- Ending the file ------------

GGSCI> shell vi ./dirsql/dblogin.sql
-- in vi editor mode
dblogin userid ggate, password tsys123

-- command to login to ggate user
GGSCI>obey dirsql/dblogin.sql


-- The name of the check point table must be added to the GLOBALS file
-- Name of the table should be same as mentioned in ./GLOBALS file
-- if you don't remember the name then this "ADD CHECKPOINTTABLE" command 
-- will also create checkpoint table
-- Add this to Both DBs Primary and reporting
GGSCI> ADD CHECKPOINTTABLE GGATE.CHKPTAB

/*

-- For setting up the reporting database, followup the below process

start the extract and datapump processes on source database and take the export using flashback scn and import it to 
build target reporting db


-- Take the export of schemas using flashback_scn
SQL> SELECT 'flashback_scn=' || TO_CHAR(sys.DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER) FROM dual;

oracle> vi exp_test.par
DUMPFILE="LoadTestBackup_11454852.dmp"
LOGFILE="exp_LoadTestBackup_11454852.log"
DIRECTORY=BKUP
#FLASHBACK_SCN=11454852
flashback_scn=1136134
COMPRESSION=ALL
CONTENT=ALL
SCHEMAS=('SNOX4TRANSNOX_API','KEYNOX_FX','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_007','SNOXPASS_GWAY_008','SNOXPASS_TFE_2013','SNOXPASS_TFE_2014','TNOXPASS_GWAY_007','TNOXPASS_GWAY_008','TNOXPASS_TFE_2013','TRANSNOX_CPASS','TRANSNOX_IOX','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303')

--
oracke> expdp rchaudhari parfile=exp_test.par

oracle> vi impdp_test.par
DUMPFILE="LoadTestBackup_11454852_1.dmp"
LOGFILE="imp_LoadTestBackup_2_11454852.log"
DIRECTORY=BKUP
STREAMS_CONFIGURATION=n
TABLE_EXISTS_ACTION=SKIP
SKIP_UNUSABLE_INDEXES=y
CONTENT=ALL
PARTITION_OPTIONS=none

oracle> impdp rchaudhari parfile=impdp_test.par

--- we starting the extract and replicat process after import is done on reporting DB upto the flashback_scn
-- start extract
./ggsci
GGSCI> dblogin userid ggate,password ggate
GGSCI> start extract EPRW aftercsn 11454852

-- On reporting db start replicat
GGSCI> dblogin userid ggate,password ggate
GGSCI> start replicat RPRWCP02 aftercsn 1621973013

start replicat RPRWCP03 aftercsn 1621973013


start replicat RPRETW aftercsn 3546020732

start replicat RPRWTW aftercsn 3547182893

start replicat RPTETW aftercsn 3682712683

start replicat RPRETW aftercsn 3682712683

start replicat RPRETE aftercsn 3682712683
start replicat RPRERW aftercsn 3682712683

start replicat RPD2R aftercsn 1992821416


*/

-- Check information
Info All 



--- All Commands of GoldenGate


---------------------------------------------------------------------------------
-- INFO	
INFO MANAGER -- Provides details of the Manager process
INFO MGR -- Also provides details of the Manager process

-- Issue the following command to see if the trail was created.
INFO RMTTRAIL *

-- Issue the following command to see if the extract trail was created.
INFO EXTTRAIL *

---------------------------------------------------------------------------------
-- STATUS
STATUS MANAGER -- This command also display the info of manager

--->> It is used to check whether extract process is currently running or not.
STATUS EXTRACT e_src -- To check the status for extract "E_SRC"
STATUS EXTRACT e* -- To check the status for all extracts starting with "e"

--->> It is used to find whether replicat is running or not
STATUS REPLICAT r_trg -- To check the status for replicat "r_trg"
STATUS REPLICAT r*	-- To check the status for all replicat starting with "r"

---------------------------------------------------------------------------------
-- REFRESH	Command
REFRESH MANAGER -- Reloads from the Manager Parameter file
REFRESH MGR	 -- Reloads from the Manager Parameter file

---------------------------------------------------------------------------------
-- SEND	
SEND MANAGER CHILDSTATUS -- Displays status of processes, started by Manager.
SEND MANAGER CHILDSTATUS DEBUG	-- Return the ports numbers allocated by the Manager
SEND MANAGER GETPORTINFO -- Displays the list of currently allocated ports by Manager process
SEND MANAGER GETPORTINFO DETAIL -- Provides info on ports and process assigned to them.
SEND MANAGER GETPURGEOLDEXTRACTS -- Retrieves trail purge retention info.

--->> It is used to communicate with the running extract like sending requests for report creation, stats, to force extract to rollover to next trail etc
SEND EXTRACT finance, ROLLOVER	-- To increment the extract to next file in trail
SEND EXTRACT finance, STOP -- To stop the extract process
SEND EXTRACT finance, TRANLOGOPTIONS TRANSCLEANUPFREQUENCY 20 -- For the Oracle RAC, specify the time after which the OGG scan and delete the orphan transactions
SEND EXTRACT finance, SKIPTRANS 5.17.27634 THREAD 2	-- For skipping the transaction in the Oracle RAC environment
SEND EXTRACT e_src, SHOWTRANS	-- Display the info about the open transactions like checkpoint, extract group name, SCN, Redo log and RB, status etc
SEND EXTRACT e_src, SHOWTRANS COUNT 2	-- Display the info for two transactions only

--->> It is used to communicate with the running replicat process
SEND REPLICAT r_trg, HANDLECOLLISIONS --Enable the handlecollisions option of OGG used for error handling
SEND REPLICAT r_trg, REPORT HANDLECOLLISIONS r_* -- Generate statical report to replicat report file
SEND REPLICAT r_trg, GETLAG	-- Get the lag info in seconds


-- To Genrate the detail report
SEND EXTRACT EPTW, STATS
SEND EXTRACT EPTW,REPORT

SEND RPRWTW,REPORT

-- To view the detail report
VIEW EXTRACT EPTW,REPORT 

VIEW RPRWTE01, REPORT 
---------------------------------------------------------------------------------
-- STATS Command	
--->> It is used to display the stats for the extract process including the DDL and DML operations.
STATS e_src	
STATS EXTRACT e_src	-- stats will be displayed for the extract E_SRC""
STATS EXTRACT e_src REPORTRATE SEC	-- display the stats for the fetch opertions per sec
STATS EXTRACT e_src, TOTAL, DAILY	-- The total stats is shown since the start of the day
STATS EXTRACT e_src, TOTAL, HOURLY, REPORTRATE MIN, RESET, REPORTFETCH	-- By using comma between the keywords multiple options can be used for the stats command

--->> It is used to display the stats for the replicat process.
STATS r_trg	
STATS REPLICAT r_trg -- stats will be displayed for the REPLICAT r_trg""
STATS REPLICAT r_trg REPORTDETAIL SEC	-- display the stats for the opertaion that were not replicated due to errors
STATS REPLICAT r_trg, TOTAL, DAILY	-- The total stats is shown since the start of the day
STATS REPLICAT RPTETW, TOTAL, HOURLY, REPORTRATE MIN, RESET, NOREPORTDETAIL	-- By using comma between the keywords multiple options can be used for the stats command

-- below command will so the operation happen for that tables
stats <<process_name>> table <<schema_name>>.<<table_name>>  
for e.g.

stats RPTETW table transnox_iox.transaction

-- check the cdr report
STATS REPLICAT <group>, REPORTCDR
STATS RPTWTE, LATEST REPORTCDR

---------------------------------------------------------------------------------
-- START Command
--->> it is used to start manager/mgr process
START MANAGER	-- Starts the Manager Process
START MGR	-- Starts the Manager Process

--->> It is used to start the Extract process
START EXTRACT e_src	

--->> It is used to start the replicat process
START REPLICAT r_trg	
START REPLICAT r_trg, ATCSN 6454388	   -- To start the replicat process from the oracle-specific CSN number including the CSN no transaction
START REPLICAT r_trg, AFTERCSN 6454389 -- To start the replicat process from the oracle-specific CSN number, but ignoring that CSN no transaction

---------------------------------------------------------------------------------
-- STOP	
STOP MGR	Stops the Manager Process
STOP MANAGER !	-- Stops Manager without asking for user confirmation.
STOP MGR !	-- Stops Manager without asking for user confirmation.

--->> It is used to stop the running extract process
STOP EXTRACT e_src	-- To stop the extract "e_src"
STOP EXTRACT e*	-- To stop all of the running extract process whose name start with "e"
STOP EXTRACT *	-- To stop all of the running extract processes

--->> It is used to stop the running replicat process
STOP REPLICAT r_trg	-- To stop the replicat "r_trg"
STOP REPLICAT r*	-- To stop all of the running replicat process whose name start with "r"
STOP REPLICAT *	-- To stop all of the running replicat processes

---------------------------------------------------------------------------------
-- ADD Command	
--->>  It is used to Creates an Extract group.
ADD EXTRACT E_SRC, Tranlog, Begin Now	-- Used to specify transaction logs as data source for extract.
ADD EXTRACT E_SRC, Begin Now, Passive	-- Specifies the extract to be run in passive mode.
ADD EXTRACT E_SRC, Extseqno 000008 Extrba 287458, Begin Now	-- Specifies the extract process starting position
ADD EXTRACT E_SRC, SOURCEISTABLE	-- Extracts data from data tables for initial loading.

--->> It is used to create the replicat process by creating checkpoints
ADD REPLICAT INITLOAD, SPECIALRUN	-- It will create a special run replicat as task.
ADD REPLICAT r_trg, EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TT	-- Create the replicat with the trail
ADD REPLICAT r_trg, EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TT, CHECKPOINTTABLE OGG_USER.OGG_CHECKPOINT	-- Create the replicat with the trail and the checkpoint info like the DB table used to save checkpoint info.
ADD REPLICAT r_trg, EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TT, NODBCHECKPOINT	-- Create the replicat with the trail and specifying that this replicat did not write info to DB table

--->> It is used to create the local trail file for extract process on local system
ADD EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE, EXTRACT e_src, MEGABYTES 100	-- Create EXTTRAIL with the Prefix"SE", and the size of 100 mb
ADD EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE000009	-- To create the EXTTRAIL with specific sequence number
ADD RMTTRAIL	-- It is used to create the remote trail files for the extract or pump processes on remote systems
ADD RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TE, EXTRACT p_src, MEGABYTES 100	-- Create RMTTRAIL with the Prefix"TE", and the size of 100 mb
ADD RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE000009	-- To create the RMTTRAIL with specific sequence number

---------------------------------------------------------------------------------
-- ALTER Command	
ALTER EXTRACT e_src, BEGIN NOW	-- Instructs extract to start processing
ALTER EXTRACT e_src, BEGIN 2013-04-16	-- Instructs extract to start processing from specific date
ALTER EXTRACT PPTWTE, ETROLLOVER	-- Extract rolls over to next trail file
ALTER EXTRACT e_src, EXTSEQNO 9781, EXTRBA 5650944	-- Alters extract to start from the specific locaton in the trail
ALTER EXTRACT e_src, THREAD 4, BEGIN 2015-07-06 04:35:29	-- Alters extract thread & start date for RAC
ALTER EXTRACT e_src, LSN 1234:123:1	-- Altering extract for the SQL Server

--->> It is used to change the properties of the existing replicat process
ALTER REPLICAT r_trg, BEGIN NOW	 -- Alter replicat to start processing from now
ALTER REPLICAT r_trg, BEGIN 2013-05-11	-- Alter replicat to start processing from specific date
ALTER REPLICAT r_trg, BEGIN 2013-01-07 08:00:01	-- Alter replicat to start processing from specific date and time
ALTER REPLICAT r_trg, EXTSEQNO 00007	-- Alter replicat to start from the specific trail file
ALTER REPLICAT r_trg, EXTRBA 15640031	-- Alter replicat to start from the specific location in the trail


--  Both GETTRUNCATES and DDL replication are enabled.

ALTER PPTWTE, begin 2015-04-17 06:00:00

ALTER EXTTRAIL	-- It is used to change the options of the existing EXTTRAIL file for extract process on local system
ALTER EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE, EXTRACT e_src, MEGABYTES 50	

ALTER RMTTRAIL	-- It is used to change the options of the existing RMTTRAIL file of extract or pump processes on remote systems
ALTER RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TE, EXTRACT p_src, MEGABYTES 50	

---------------------------------------------------------------------------------
-- CLEANUP Command	
--->> It is used to clear the run history for the specific extract group
CLEANUP EXTRACT e_src	-- It purges all history of records except last
CLEANUP EXTRACT e_src, SAVE 10	-- It saves last 10 records and deletes all other

--->> It is used to clear the run history for the specific replicat process
CLEANUP REPLICAT r_trg	-- It purges all history of records except last
CLEANUP REPLICAT r_trg, SAVE 10	-- It saves last 10 records and deletes all other

---------------------------------------------------------------------------------
-- DELETE Command	
--->> It is used to delete the extract process, its checkpoints detail and unregister the extract group.
DELETE EXTRACT e_src --	deletes the extract process
DELETE EXTRACT e*	-- deletes all extract process whose name starts with e
DELETE EXTRACT e* !	-- deletes all extract process whose name starts with e without prompting

--->> It is used to delete the replicat process, by removing the checkpoints and freeing trail file for purging by manager. But the process must be stopped and user must be logged in using DBlogin command
DELETE REPLICAT r_trg -- deletes the replicat process

DELETE EXTRACT r* -- deletes all replicat process whose name starts with r
DELETE EXTRACT r* ! -- deletes all replicat process whose name starts with r without prompting

DELETE EXTTRAIL	 -- It is used to delete the exttrail assigned to the extract on local system by deleting its references from checkpoint file
DELETE EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE	

DELETE RMTTRAIL	 -- It is used to delete the exttrail for the extract or pump on remote system by deleting its references from checkpoint file
DELETE RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TE	

---------------------------------------------------------------------------------
-- INFO Command	
--->> It is used to display the info of the extract like its status, lag, checkpoint, run history, trail info etc
INFO EXTRACT e_src, SHOWCH	-- Display checkpoint info of extract
INFO EXTRACT EPTW, DETAIL	-- Display trail info, run history
INFO EXTRACT e_src, TASKS	-- Display extract tasks

--->> It is used to display the replicat info like processing history, status, appox lag, trail info, checkpoint info and environment of replicat.
INFO REPLICAT *, TASKS	-- It is used to display replicat tasks only.
INFO REPLICAT r_trg	-- It is used to display the information of replicat.
INFO REPLICAT r_trg, DETAIL	-- It display the detailed information of replicat.
INFO REPLICAT r_trg, SHOWCH	-- It displays the checkpoint table information, from checkpoint file and checkpoint table.

--->> It is used to display the info of local trail like name, associated extract, rba and file size etc
INFO EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE	-- Display info for specific exttrails
INFO EXTTRAIL *	-- Display info for all exttrails

INFO RMTTRAIL	-- It is used to display the info of remote trail like name, associated extract, rba and file size etc
INFO RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TE	-- Display info for specific rmttrails
INFO RMTTRAIL *	-- Display info for all rmttrails

---------------------------------------------------------------------------------
-- KILL Command	
--->> It is used to kill the extract that can not be stopped with STOP Command""
KILL EXTRACT e_src	

--->> It is used to kill the replicat that can not be stopped with "STOP Command", but checkpoint info remain unchanged and transactions are rolled back in DB
KILL REPLICAT r_trg	

---------------------------------------------------------------------------------
-- LAG Command	
--->> It is used to find the lag time between Extract and data source more precisely than the "INFO Command"
LAG EXTRACT e_src	-- To find lag for extract "e_src"
LAG EXTRACT *	-- To find lag for all of the extract processes

--->> It is used to find the lag time between Replicat and trail more precisely than the "INFO Command"
LAG REPLICAT r_trg	-- To find lag for replicat "r_trg"
LAG REPLICAT *	-- To find lag for all of the replicat processes

---------------------------------------------------------------------------------
-- REGISTER Command	
--->> It is used to register the extract process, so that it can retain the archive logs required for its recovery.
REGISTER EXTRACT e_src LOGRETENTION	-- To register extract "e_src"

---------------------------------------------------------------------------------
-- UNREGISTER Command	
--->> it is used to unregister the extract group by removing its registration from oracle DB.
UNREGISTER EXTRACT e_src LOGRETENTION	-- To unregister the extract e_src""

-- upgrade the check point table
UPGRADE CHECKPOINTTABLE GGATE.CHKPTAB
---------------------------------------------------------------------------------

-- ER Commands	
--->> They are used to control the multiple extract and replicat processes
INFO ER *	-- To info all of the process

KILL ER *	-- To kill all of the process

LAG ER *	-- To get lag info of all the process

SEND ER *	-- To use send command on all of the process

START ER *	-- To start all of the process

STATS ER *	-- To check the stats all of the process

STATUS ER *	-- To find status of all the process

STOP ER *	-- To stop all of the process

RBA 	-- Relative Byte Address 
SEQNO	-- Sequence Number 
---------------------------------------------------------------------------------
-- VIEW REPORT Command
VIEW REPORT e_src -- To view the report of extract
VIEW REPORT p_src -- To view the report of extract pump process 

VIEW REPORT r_tag -- To view the report of replicat

VIEW GGSEVT -- Viewing the GoldenGate error log,similar shell tail -f ggserr.log

-- To execute previous GGSCI command
ggsci> ! [n | -n | string]     
ggsci> !
ggsci> ! 6    -- To run the command 6 listed in the history
ggsci> ! -3
ggsci> ! sta
ggsci> help ! command

-- To display edit a previously issued GGSCI command and then execute it again
ggsci> FC [n | -n | string]  
ggsci> fc
ggsci> fc 9
ggsci> fc -3
ggsci> fc sta


-- To kill an Extract process running in regular or PASSIVE mode
ggsci> KILL EXTRACT group_name   
ggsci> kill extract fin

-- To kill a Replicat process
ggsci> KILL REPLICAT group_name  
ggsci> kill replicat fin

-- To forcefully terminate multiple Extract and Replicat groups as a unit
ggsci> KILL ER group_wildcard_specification  
ggsci> kill er *x*


------------------------------------------------------------------------------------------------------------------------------
My Datapump was abending after start, because It was looking for MISSING remote trailfile at perticular RBA , that trailfile was deleted and when I was trying to start
the extract pump it was giving below error in ggserr.log file and process was getting abended

2015-08-06 03:32:58 ERROR OGG-01496 Oracle GoldenGate Capture for Oracle, pprerw.prm: Failed to open target trail file /acfs/goldengate/dirdat/RA000002, at RBA 5403.
2015-08-06 03:32:58 ERROR OGG-01668 Oracle GoldenGate Capture for Oracle, pprerw.prm: PROCESS ABENDING.

if the extract/replicat processes are abending even after using "alter extract pprerw, begin now" command and getting the error like above. Verify all the stuff like
directory/folder file exists or not, try using begin now statement 2/3 times and try to start the process, after trying also it is not starting and giving same
error, then try with below steps.

-- Please be sure to use it, Transactions might get loss

ALTER EXTRACT PPRERW, ETROLLOVER
ALTER EXTRACT PPRERW, BEGIN NOW
START PPRERW

ALTER EXTRACT RPRERW, ETROLLOVER
ALTER EXTRACT RPRERW, BEGIN NOW
START RPRERW


INFO RMTTRAIL *

------------------------------------------------------------------------------------------------------------------------------


/*

Classic GoldenGate Replication does not support to COMPRESSION, So all the tables in the schemas (which needs to replicate) should be as nocompress.

Below are the queries will be generate the scripts for such tables.

SELECT  'ALTER table '||owner||'.'||table_name||' LOGGING;'
FROM dba_tables
WHERE owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','WEBFORT')
 AND LOGGING='NO'

SELECT 'ALTER table '||owner||'.'||table_name||' nocompress;'||CHR(10) ||
    'alter table '||owner||'.'||table_name||' move nocompress;' 
FROM dba_tables
WHERE owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','WEBFORT')
 AND COMPRESSION <> 'ENABLED'
 
SELECT *
FROM DBA_LOBS
WHERE owner IN ('WEBFORT','TRANSNOX_CPASS','TRANSNOX_CPASS')

 AND SEGMENT_NAME='SYS_IL0000250921C00002$$'
 
SELECT  * --'ALTER INDEX '||owner||'.'||INDEX_name||' REBUILD nocompress;'
FROM dba_indexes WHERE owner IN  ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','WEBFORT')
 AND status='UNUSABLE'
 
SELECT 'ALTER table '||dt.owner||'.'||dt.table_name||' nocompress;'||CHR(10) ||
       'ALTER table '||dt.owner||'.'||dt.table_name||' move nocompress;'||CHR(10) ||
       'ALTER INDEX '||di.owner||'.'||di.INDEX_name||' REBUILD nocompress;' oops
FROM dba_tables dt, dba_indexes di
WHERE dt.owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','WEBFORT')
  AND dt.table_name = DI.TABLE_NAME 
  AND dt.owner = di.owner
  AND dt.COMPRESSION <> 'ENABLED' 
  
SELECT * --'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' MOVE LOB ('||COLUMN_NAME||') STORE AS (TABLESPACE INDX);' indx 
FROM dba_tab_columns 
WHERE owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','WEBFORT')
 AND data_type IN ('BOLB','CLOB')
  


*/

/*

-- GoldenGate VIP Setup and Configurations

1. create application VIP run as root (rw_ggatevip -- DCW reporting)
/opt/app/11.2.0/grid_1/bin/appvipcfg create -network=1 -ip=10.150.50.180 -vipname=w-rpt-ggatevip.tsysacquiring.org -user=root

2. Give permissions for oracle to execute 
/opt/app/11.2.0/grid_1/bin/crsctl setperm resource w-rpt-ggatevip.tsysacquiring.org -u user:oracle:r-x

3. Start the resource from oracle
crsctl start resource w-rpt-ggatevip.tsysacquiring.org

4. check the status from oracle
crsctl status resource w-rpt-ggatevip.tsysacquiring.org

5. create action script and copy it into /acfs/goldengate/scripts/11gr2_gg_action.sh -- attached as 11gr2_gg_action.txt

6. Register cluster resource as oracle
crsctl add resource ggateapp -type cluster_resource -attr "ACTION_SCRIPT=/acfs/goldengate/scripts/11gr2_gg_action.sh,CHECK_INTERVAL=30, START_DEPENDENCIES='hard(w-rpt-ggatevip.tsysacquiring.org)pullup(w-rpt-ggatevip.tsysacquiring.org)', STOP_DEPENDENCIES='hard(w-rpt-ggatevip.tsysacquiring.org)'" 

7. Owner permissions run it as root
/opt/app/11.2.0/grid_1/bin/crsctl setperm resource ggateapp -o goldengate


8. start ggate resource  and we got the error wpl1trandbrpt1.tsysacquiring.org:/home/oracle> crsctl start resource ggateapp
CRS-2672: Attempting to start 'ggateapp' on 'wpl1trandbrpt1'
CRS-2674: Start of 'ggateapp' on 'wpl1trandbrpt1' failed
CRS-2679: Attempting to clean 'ggateapp' on 'wpl1trandbrpt1'
CRS-2681: Clean of 'ggateapp' on 'wpl1trandbrpt1' succeeded
CRS-2527: Unable to start 'ggateapp' because it has a 'hard' dependency on 'w-rpt-ggatevip.tsysacquiring.org'
CRS-2525: All instances of the resource 'w-rpt-ggatevip.tsysacquiring.org' are already running; relocate is not allowed because the force option was not specified
CRS-4000: Command Start failed, or completed with errors.
wpl1trandbrpt1.tsysacquiring.org:/home/oracle>


-- How to stop and Start

crsctl start resource w-txn-goldengate-vip

crsctl status resource w-txn-goldengate-vip

crsctl stop w-txn-goldengate-vip

crsctl stop res w-txn-goldengate-vip

crsctl relocate w-txn-ggatevip.tsysacquiring.org

-- relocate resource from one node/server to other node/server/cluster
(crsctl relocate resource w-txn-ggatevip.tsysacquiring.org -s wpl1trandbtxn1 -n wpl1trandbtxn2)

crsctl relocate resource w-txn-ggatevip.tsysacquiring.org
  

/opt/app/oracle/xag/bin/agctl stop  goldengate gg_wtxn

crsctl stat res -t

crsctl relocate resource w-txn-ggatevip.tsysacquiring.org

crsctl stat res -t

/opt/app/oracle/xag/bin/agctl start  goldengate gg_wtxn --node wpl1trandbtxn1

/opt/app/oracle/xag/bin/agctl stop  goldengate gg_wtxn

/opt/app/oracle/xag/bin/agctl stop  goldengate gg_wrpt
 
crsctl stat res -t

/opt/app/oracle/xag/bin/agctl start  goldengate gg_wtxn --node wpl1trandbtxn1

-- 
/opt/app/oracle/xag/bin/agctl start goldengate gg_wrpt --node wpl1trandbrpt1

crsctl stat res -t

/opt/app/oracle/xag/bin/agctl stop  goldengate gg_wtxn

-- check on last node
/opt/app/oracle/agent/agent_inst/bin/emctl status agent

*/


--  Patching on RPT DCW Production DB (10.150.50.171/172/173)

-- sftp the patches on all the Nodes from first node
 sftp oracle@wpl1trandbtxn1.tsysacquiring.org
 sftp oracle@wpl1trandbrpt2.tsysacquiring.org
 sftp oracle@wpl1trandbrpt3.tsysacquiring.org
 
-- check the opatch version
opatch version

-- check the inventroy
opatch lsinventory

-- unzip the patch 
cd /opt/app/software/

unzip p19380115_112040_Linux-x86-64.zip

-- create the ocm.rsp file, from oracle user and using $ORACLE_HOME
/opt/app/oracle/product/11.2.0/db_4/OPatch/ocm/bin/emocmrsp -no_banner -output /opt/app/software/ocm.rsp

-- Stop the goldengate replication 
/opt/app/oracle/xag/bin/agctl stop goldengate gg_wrpt (gg_wtxn, gg_erpt, gg_etxn)

-- from root user apply the patch on first Node1 (Once patche is install successfully on Node1, apply it on other nodes)
/opt/app/11.2.0/grid_1/OPatch/opatch auto /opt/app/software/112044/19380115 -ocmrf /opt/app/software/ocm.rsp

-- from oracle user start the goldengate replication on node1
/opt/app/oracle/xag/bin/agctl start goldengate gg_wrpt --node wpl1trandbrpt1

-- from oracle user, check the status of agent 
/opt/app/oracle/agent/agent_inst/bin/emctl status agent





--------------------------------------------------------------------------------------------------------------------------------------
--- Step to be followed while doing OS Patching on GoldenGate Replication databases

1) login to DCW primary and DCW reporting goldengate
   stop pump process which are replicating on DCE 
   
   and also login to DCE Primary and Reporting (One By One replication and pump can be stoped) to stop the replicat, manager and Jagent
   
-- Be sure note to stop mail DC site. this activity should be done on DR site only and so stop goldengate replication from DR site only   

/*

Once all the required goldengate related processes are sto, then you can ask system team to patch first on Node1. Here you are not stopping any
services, as all the services are auto-restart.

so from step 2 to 4, you might not woant to do.

I have stop services manually for safer side 

*/

2) stop xag vip configuration for goldengate 
/opt/app/oracle/xag/bin/agctl stop goldengate gg_erpt

3) stop first instance 
srvctl stop instance -d transitrptga -i transitr1


4) from root user stop the cluster software of node 1

/opt/app/11.2.0/grid_1/bin/crsctl stop cluster -n epl1trandbrpt1

-- check all the services are up and running...
crsctl stat res -t

5) Do the OS Patching

6) Once the OS Patching is done, start the instance. Clusterware should be already started as it will be auto start

-- if the ionstance is not started then, start it 
srvctl start instance -d transitrptga -i transitr1

7) check the goldengate vip which should be pointing to node 1, relocate untill it is pointing to node 1
crsctl relocate resource e-rpt-ggatevip.tsysacquiring.org

8) Once the goldengate vips are up and running on node1, start the xag on node1
/opt/app/oracle/xag/bin/agctl start goldengate gg_erpt --node epl1trandbrpt1

-- check the status of xag
/opt/app/oracle/xag/bin/agctl status goldengate gg_erpt --node epl1trandbrpt1

-- check all the services are up and running...
crsctl stat res -t

9) login to goldengate on DCE Reporting Node1 and you can alter the pumps and extract to begin now. this are the process which are not replicating currently

10) There is no need to stop the services on node2,node3 rebooting of server will take of the same, once the node is starte all the services 
	should start automatically. if node start one by one services on the nodes. Once all the OS patching is done on all the nodes start the goldengate replications

11) login to goldengate on DCW primary site and start the pump.
start <pump-name>

info all

sh tail -f ggserr.sh

12) login to replicating site and start the replications 
start r*

--------------------------------------------------------------------------------------------------------------------------------------


-- TABLEEXCLUDE
Use the TABLEEXCLUDE parameter with the TABLE and SEQUENCE parameters to explicitly exclude tables and sequences from a wildcard specification. 
The positioning of TABLEEXCLUDE in relation to parameters that specify files or trails determines its effect. Parameters that specify trails 
or files are: EXTFILE, RMTFILE, EXTTRAIL, RMTTRAIL.

-- exclude report_usage_seq
TABLEEXCLUDE TRANSNOX_CPASS.REPORT_USAGE_SEQ
TABLE TRANSNOX_CPASS.*;

--------------------------------------------------------------------------------------------------------------------------------------
/*
-- Oracle GoldenGate Conflict Detection and Resolution (CDR)

Setup CRDs

Edit your replicat parameter files on both the sides and add the following stanza.
MAP SCOTT.ORDERS, TARGET SCOTT.ORDERS,
COMPARECOLS (ON UPDATE ALL, ON DELETE ALL),
RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, USEMAX (DML_TIMESTAMP))),
RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, USEMAX (DML_TIMESTAMP)),
RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, IGNORE)),
RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, OVERWRITE)),
RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, DISCARD));

NOTE: In our Demo source and target schemas are same. If schema name is different on source and target you have to make sure that you define 
the correct mapping on source.

*/


1) Those tables which are already present and DMLs are working on it and PK/UK are not present. 
if we add any column after wards, then DMLs, will Replicated from DR site unless PK/UK is created on that table.

2) In Active-Active Replication, One of the site should be consider as a Trusted Site or say Master Site in the two site active-active configuration.

3) Sequences should be in incremental approch suggested by Sandip Tujare.
	3.1) Sequences replication shoul be off on both DCs.
	3.2) Every time we have to prepare two Sequences creation scripts for both DCs in rundbRelease.cmd.
	This way we are not replicating DDL operations on sequences.
	
Two main issues currently - 
1) Data Looping - If there is any Update/Delete happening on same time/seconds, then it will happen only for the latested one and not for the higher timestamp.
2) If tables columns is added on existing table then always we have to follow the steps
	1) stop extract/replicate processes on DR site DC
	2) Execute the DB release (Alter table add column)
	3) Restart the stopped extract/replicator processes from DR sites.
	

The time since checkpoint can increase if it is capturing a huge transaction. 


--*********************************************************************************--
--																				   --
--       Below are the steps to configure GoldenGate Replication software          --
--																				   --
--*********************************************************************************--


-- Below changes has to be done on both Parimary and Reporting Database.. (until -->EOF_Of_Script)


--create a folder for goldengate Home and add the path in .bash_profile
mkdir -p /opt/app/goldengate


-- Include all contents of oracle's .bash_profile into goldengate user's .bas_profile file
-- set the os env for OGG_HOME ~/.bas_profile for 
OGG_HOME=/opt/app/goldengate; export OGG_HOME
-- add the $OGG_HOME in PATH line and also in LD_LIBRARY_PATH


-- Once done, then install the golden software in $OGG_HOME folder
unzip 112101_fbo_ggs_Linux_x64_ora11g_64bit.zip
tar -xf fbo_ggs_Linux_x64_ora11g_64bit.tar

/*

--- best URL for GOLDEN GATE 
http://database.com.mk/wordpress/category/oracle/golden-gate/

--- Once you have Install Oracle and created database you will also need to install Oracle GoldenGate software

--create a folder ogg home under app/oracle/product folder path
mkdir -p /opt/app/oracle/product/ogg

--set the os env for OGG_HOME ~/.bas_profile for 
OGG_HOME=/opt/app/oracle/product/ogg; export OGG_HOME

-- add the $OGG_HOME in PATH line and also in LD_LIBRARY_PATH

-- Once done, then install the golden software in $OGG_HOME folder
unzip 112101_fbo_ggs_Linux_x64_ora11g_64bit.zip
tar -xf fbo_ggs_Linux_x64_ora11g_64bit.tar

-- start gg command line utility for creating sub directories in $OGG_HOME folder only
./ggsci

GGSCI>create subdirs
GGSCI>exit

oracle@db1>mkdir $OGG_HOME/discard


*/



-- ERROR: No checkpoint table specified for ADD REPLICAT � Oracle GoldenGate

-- This is just a quick note for myself to remember and reference for in case someone comes across this error while setting up Oracle GoldenGate.
-- While configuring the online synchronization replication, a default checkpoint table is created.The table�s name is mentioned in file named GLOBALS.

-- login to goldengate
./ggsci

GGSCI (anand-lab) 29> EDIT PARAMS ./GLOBALS

GGSCHEMA GG_OWNER
CHECKPOINTTABLE GG_OWNER.CKPTAB

GGSCI (anand-lab) 31> DBLOGIN USERID gg_owner,PASSWORD gg123
Successfully logged into database.

GGSCI (anand-lab) 33> ADD CHECKPOINTTABLE CKPTAB

Successfully created checkpoint table CKPTAB.

-- Now, when you try to create the Replicat group, the ADD REPLICAT command might produces an error

GGSCI (anand-lab) 41> ADD REPLICAT rep1, EXTTRAIL /media/sf_database/gg/dirdat/rt
ERROR: No checkpoint table specified for ADD REPLICAT.

-- The solution is simply to exit that GGSCI session and then start another one before issuing ADD REPLICAT.The ADD REPLICATE command fails 
-- if issued from the session where the GLOBALS file using the GGSCI command �EDIT PARAMS ./GLOBALS� was created.This is because the name of the 
-- checkpoint table is read from GLOBALS by GGSCI. The session in which the GLOBALS was created cannot read the file.











/*

GSSCI> info all

GSSCI> ADD EXTRACT EDCW,TRANLOG, THREADS 1, BEGIN NOW
GSSCI> ADD EXTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/PS, EXTRACT EPTW, MEGABYTES 100

GSSCI> ADD EXTRACT DPDCW, EXTTRAILSOURCE /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/PS
GSSCI> ADD RMTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/TR, EXTRACT DPDCW, MEGABYTES 100

GSSCI> ALTER EXTRACT EDCW TRANLOG BEGIN NOW
GSSCI> ALTER EXTRACT DPDCW TRANLOG BEGIN NOW

start replicat RPD2R aftercsn 1584241385
*/


/*

-- For setting up the reporting database, followup the below process

start the extract and datapump processes on source database and take the export using flashback scn and import it to 
build target reporting db


-- Take the export of schemas using flashback_scn
SQL> SELECT 'flashback_scn=' || TO_CHAR(sys.DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER) FROM dual;

oracle> vi exp_test.par
DUMPFILE="LoadTestBackup_11454852.dmp"
LOGFILE="exp_LoadTestBackup_11454852.log"
DIRECTORY=BKUP
FLASHBACK_SCN=11454852
COMPRESSION=ALL
CONTENT=ALL
SCHEMAS=('SNOX4TRANSNOX_API','KEYNOX_FX','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_007','SNOXPASS_GWAY_008','SNOXPASS_TFE_2013','SNOXPASS_TFE_2014','TNOXPASS_GWAY_007','TNOXPASS_GWAY_008','TNOXPASS_TFE_2013','TRANSNOX_CPASS','TRANSNOX_IOX','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303')

--
oracke> expdp rchaudhari parfile=exp_test.par

oracle> vi impdp_test.par
DUMPFILE="LoadTestBackup_11454852_1.dmp"
LOGFILE="imp_LoadTestBackup_2_11454852.log"
DIRECTORY=BKUP
STREAMS_CONFIGURATION=n
TABLE_EXISTS_ACTION=SKIP
SKIP_UNUSABLE_INDEXES=y
CONTENT=ALL
PARTITION_OPTIONS=none

oracle> impdp rchaudhari parfile=impdp_test.par

--- we starting the extract and replicat process after import is done on reporting DB upto the flashback_scn
-- start extract
./ggsci
GGSCI> dblogin userid ggate,password ggate
GGSCI> start extract EPRW aftercsn 2491452799

-- On reporting db start replicat
GGSCI> dblogin userid ggate,password ggate
GGSCI> start replicat RPRWCP02 aftercsn 1621973013

start replicat RPRWCP03 aftercsn 1621973013


start replicat RPRETW aftercsn 3546020732

start replicat RPD2R aftercsn 1968977355


alter eptw,extseqno 12382,extrba 88471842

*/


--***********************************************************************************************************

-------------------*******************************************************-----------------------------
--																									--
--          GoldenGate NOTES & COMMANDS													--
--																									--
-------------------*******************************************************-----------------------------

-- to refresh the manager
GGSCI>REFRESH MANAGER

--View latency between the records processed by Goldengate and the timestamp in the data source
send extract exttnox, getlag

-- for all extract processes
lag extract ext*


--Find the run status of a particular process
status manager

status extract exttnox

--Information on Child processes started by the Manager
send manager childstatus

--Detailed information of a particular process
info extract exttnox, detail


--Monitoring an Extract recovery 
send extract exttnox status

-- Monitoring command for ip details
-- the result show much more info of the data pump extract process
-- this command will show the result of dpump extract process only
send extract edcw gettcpstats


--Monitoring processing volume - Statistics of the operations processed 
stats extract exttnox


--View processing rate - can use 'hr','min' or 'sec' as a parameter
stats extract ECPASS reportrate hr

-- GGSCI Command 
show all
info all
start extract ext3
history
shell ls -ltrh -- it's works like host command in oracle sqlplus prompt
obey -- to process a file which contains the ggs commands. OBEY is useful for executing commands that are frequently used in sequence.
obey ./dirsql/dblogin.sql -- user login 


-- Do not delete archive files, else extract and replicator process will abeneded..
-- In case you have deleted the archive logs and replication is/was using them then your extract process will not start...
-- check the logs of replication and youwill find that it is checking for older archive logs which are not present now..
-- this case to restart the extract process

ALTER EXTRACT ecpass BEGIN <TIMESTAMP>
OR
alter extract ecpass begin now

start extract ecpass



--How to reset extract:
-- if you do not set an RBA it will begin from 0 at the trail file you specify for the replicat, and for the extract 
-- EXTSEQNO will be the current redo log which you can get from V$LOG
-- EXTSEQNO X and EXTRBA Y numbers will get from trail files
ALTER EXTRACT <NAME> EXTSEQNO X, EXTRBA Y

alter extarct edcw, extseqno 815, extrba 6124048

ALTER EXTRACT edcw, BEGIN 2014-01-08
ALTER EXTRACT edcw, THREAD 1, BEGIN 2014-01-08


/* How tO get the extseqno and extrba

GGSCI (dbserver2) 7> info REPLICAT ROLAP01, detail

REPLICAT  ROLAP01 Last Started 2010-04-01 15:35 Status STOPPED
Checkpoint Lag 00:00:00 (updated 00:12:43 ago)
Log Read Checkpoint File ./dirdat/tb000279 <------- SEQNO
2010-04-08 12:27:00.001016 RBA 43750979 <------- RBA

Extract Source 	        Begin 	        End
./dirdat/tb000279 	2010-04-01 	12:47 2010-04-08 12:27
./dirdat/tb000257 	2010-04-01 	04:30 2010-04-01 12:47
./dirdat/tb000255 	2010-03-30 	13:50 2010-04-01 04:30
./dirdat/tb000206 	2010-03-30 	13:50 First Record
./dirdat/tb000206 	2010-03-30 	04:30 2010-03-30 13:50
./dirdat/tb000184 	2010-03-30 	04:30 First Record
./dirdat/tb000184 	2010-03-30 	00:00 2010-03-30 04:30
./dirdat/tb000000 	*Initialized*   2010-03-30 00:00
./dirdat/tb000000 	*Initialized*   First Record

Adjust the new Replicat process ROLAP02 to adopt these values, so that the process knows where to start from on startup.

GGSCI (dbserver2) 8> alter replicat ROLAP02, extseqno 279
REPLICAT altered.

GGSCI (dbserver2) 9> alter replicat RPRWCP01, extrba 1191
REPLICAT altered.

*/




ALTER REPLICAT <NAME> EXTSEQNO X, EXTRBA Y

ALTER REPLICAT RDCE EXTSEQNO 279, EXTRBA 43750979

-- Start after scn
START REPLICAT <NAME>, AFTERCSN 5397864


START REPLICAT RPRETW, AFTERCSN 3280431038

-- The following alters Extract to start processing data from January 1, 2011.
ALTER EXTRACT finance, BEGIN 2011-01-01

-- The following alters Extract to start processing at a specific location in the trail.
ALTER EXTRACT finance, EXTSEQNO 26, EXTRBA 338

-- The following alters Extract in an Oracle RAC environment, and applies the new begin point only for redo thread 4.
ALTER EXTRACT accounts, THREAD 4, BEGIN 2011-01-01

-- The following alters Extract in a SQL Server environment to start at a specific LSN.
ALTER EXTRACT sales, LSN 3454:875:445

-- The following alters Extract to increment to the next file in the trail sequence.
ALTER EXTRACT finance, ETROLLOVER

-- The following alters Extract to upgrade to integrated capture.
ALTER EXTRACT finance, UPGRADE INTEGRATED TRANLOG

-- The following alters Extract to downgrade to classic capture in a RAC environment.
ALTER EXTRACT finance, DOWNGRADE INTEGRATED TRANLOG THREADS 3

-- The following alters Extract in an Oracle environment to start processing data from source database SCN 778899.
ALTER EXTRACT finance, SCN 778899

start replicat RPTECP01 aftercsn 1621973013

-- The following shows ALTER EXTRACT for an IBM for i journal start point.
ALTER EXTRACT finance, SEQNO 1234  JOURNAL accts/acctsjrn

-- The following shows ALTER EXTRACT for an IBM for i journal and receiver start point.
ALTER EXTRACT finance, SEQNO 1234 JOURNAL accts/acctsjrn JRNRCV accts/jrnrcv0005

ADD TRANDATA TRANSNOX_IOX.TRANS_DISCOUNT_INFO

-- Final Setup.. Run ADD TRANDATA SCHEMA_NAME.* without ; (smicolon) for all those schema which you want to add for replications

--Use ADD TRANDATA to enable GoldenGate to acquire the transaction information it needs from the transaction logs. Use the DBLOGIN
--command to establish a database connection before using this command

-- This has to be run first time and after each new table created in future...

--before running add trandata command we have to stop all the running processes

stop *

info all

-- we can keep manager rnning like that and run the below command.. once it is completed start all processes again

add trandata snox4transnox_cpass.* --- there is no smicolon (;)

start *

info all


-- if any running process is abended then exclude the below command by the process names
-- so consider that reptnox process on reporting side is abended, due to some errors
alter replicat reptnox begin now
start replicat reptnox 

info all


-- or try to stop the process first 
stop replicat reptnox
info all

-- then again try to start the process by above command

-- if you want to delete the replicat/extract process then login to ogg user and delete it.
dblogin userid ogg password ogg;
delete replicat reptnox;

--command to check DDL
GGSCI>DUMPDDL SHOW

/*

Enabling DDL Support

By default DDL replication support is:

disabled for the extract process
enabled for the replicat process
To enable DDL support, therefore, it is only necessary to specify the DDL parameter for the extract process.

In the following examples, the DDL parameter has also been set for the replicat process.

The DDL parameter can only be specified once in a parameter file. However, one or more DDL inclusion criteria can be specified to include 
or exclude DDL operations based on:

scope
object type
operation type
object name
strings in the DDL statement or comments
If multiple DDL filtering options are specified then all criteria must be true for the DDL to be included.

The syntax for the DDL parameter is as follows:


Parameter

DDL
Not available for datapump process
[
{INCLUDE | EXCLUDE}
[, MAPPED | UNMAPPED | OTHER | ALL]
[, OPTYPE <type>]
[, OBJTYPE '<type>']
[, OBJNAME <name>]
[, INSTR '<string>']
[, INSTRCOMMENTS '<comment_string>']
[, STAYMETADATA]
[, EVENTACTIONS (<action specification>)
]
 
DDLERROR
extract
DDLERROR [RESTARTSKIP <num skips>] [SKIPTRIGGERERROR <num errors>]
 
replicat
DDLERROR
{<error> | DEFAULT} {<response>}-response include abend / discard / ignore / retryop maxretries <n>
{INCLUDE <inclusion clause> | EXCLUDE <exclusion clause>}
[IGNOREMISSINGOBJECTS | ABENDONMISSINGOBJECTS]
 
DDLOPTIONS
DDLOPTIONS
[, ADDTRANDATA [ABEND | RETRYOP <RETRYDELAY <seconds> MAXRETRIES <retries>]
[, DEFAULTUSERPASSWORDPASSWORD <password>
[ENCRYPTKEY DEFAULT | ENCRYPTKEY <keyname>]]
[, GETAPPLOPS | IGNOREAPPLOPS]
[, GETREPLICATES | IGNOREREPLICATES]
[, IGNOREMAPPING]
[, MAPDERIVED | NOMAPDERIVED]
[, MAPSCHEMAS]
[, MAPSESSIONSCHEMA] <source_schema> TARGET <target_schema>
[, PASSWORD ENCRYPTKEY [DEFAULT | ENCRYPTKEY <keyname>]
[, REMOVECOMMENTS {BEFORE | AFTER}]
[, REPLICATEPASSWORD | NOREPLICATEPASSWORD]
[, REPORT | NOREPORT]
[, UPDATEMETADATA]
[, USEOWNERFORSESSION]
 
DDLTABLE
DDL history table name specified, the default is GGS_DDL_HIST

If an EXCLUDE clause is specified, then a corresponding INCLUDE clause must exist.

For example the following is valid as it contains both clauses:

DDL INCLUDE ALL, EXCLUDE OBJNAME "US03.*"
The following is valid as it includes an INCLUDE clause:

DDL INCLUDE OBJNAME "US03.*"
However the following is invalid as it only contains an EXCLUDE clause:

DDL EXCLUDE OBJNAME "US03.*"

EXCLUDE clauses have priority over INCLUDE clauses where both reference the same objects.

Basic DDL Configuration
The following example parameter files contain a minimal configuration that I use for testing. I would recommend specifying more restrictive 
parameters for non-test environments.


The DDLERROR parameter prevents the replicat process from abending if there is a mismatch between the source and target environments. 
This should not really happen under normal circumstances; in a test environment this parameter may be required to synchronize the objects 
between the databases.

Although the above configurations only replicate DML for the US03 schema, the DDL INCLUDE ALL command replicates DDL for all schemas. 
So if a new table is created under the US01 schema, this should be replicated to the same schema in the target database.


TO filter OUT More DDLs excluding then in ddl_Filter.sql function instead of extract process


NOTE: - Before modifying function ogg.filterDDL please disable sys.GGS_DDL_TRIGGER_BEFORE Trriger


You can write PL/SQL code to pass information about the DDL to a function that
computes whether or not the DDL is passed to Extract. By sending fewer DDL
operations to Extract, you can improve capture performance.

1. Copy the ddl_filter.sql file that is in the Oracle GoldenGate installation
directory to a test machine where you can test the code that you will be writing.
2. Open the file for editing. It contains a PL/SQL function named filterDDL, which
you can modify to specify if/then filter criteria. The information that is passed to
this function includes:

� ora_owner: 		the owner of the DDL object
� ora_name: 		the defined name of the object
� ora_objtype: 		the type of object, such as TABLE or INDEX
� ora_optype: 		the operation type, such as CREATE or ALTER
� ora_login_user: 	The user that executed the DDL
� retVal: 			can be either INCLUDE to include the DDL, or EXCLUDE to exclude the

DDL from Extract processing.
In the location after the 'compute retVal here' comment, write filter code for
each type of DDL that you want to be filtered. The following is an example:

if ora_owner='SYS' then
retVal:='EXCLUDE';
end if;
if ora_objtype='USER' and ora_optype ='DROP' then
retVal:='EXCLUDE';
end if;

if ora_owner='JOE' and ora_name like 'TEMP%' then
retVal:='EXCLUDE';
end if;

In this example, the following DDL is excluded from being processed by the DDL trigger:

� DDL for objects owned by SYS
� any DROP USER
� any DDL on JOE.TEMP%

3. (Optional) To trace the filtering, you can add the following syntax to each if/then
statement in the PL/SQL:

if ora_owner='JOE' and ora_name like 'TEMP%' then
retVal:='EXCLUDE';
if "&gg_user" .DDLReplication.trace_level >= 1 then
"&gg_user" .trace_put_line ('DDLFILTER', 'excluded JOE.TEMP%');
end if;

Make the changes and compile the back to ogg user

OR 

You can handle all the unwantted objects and owner in sys.GGS_DDL_TRIGGER_BEFORE Trriger, but be carefull for it



You can exclude DDL in three ways
1) using Function OGG.filterDDL
2) using Trigger sys.GGS_DDL_TRIGGER_BEFORE
3) Extract process like below code in extract exttnox file...

	--DDL support--
	ddl include ALL, exclude OBJTYPE USER, exclude OBJTYPE TABLESPACE, &
		exclude objtype 'DATABASE LINK', EXCLUDE OBJNAME TNOX.SN_TEMP*, &
		EXCLUDE OBJNAME snox.SN_TEMP*


*/


--- Just a Point
--There is a limitation of DDL for 2 MB replicating per objects at a time like Table,Packages,Procedure and Functions.


-- Command to check lagging
GGSCI> lag reptnox

-- Command to check/verify the tables
GGSCI> list tables transnox_cpass.*

OR

GGSCI> list tables snox4transnox_cpass.*


-- The ! command without arguments executes the most recent command.
GGSCI> !



-- You cannot use a wildcard in the schema name. 
-- for e.g..
MAP TNOXPASS_TFE_*.*, TARGET TNOXPASS_TFE_*.* ;
MAP SNOXPASS_TFE_*.*, TARGET SNOXPASS_TFE_*.* ;

MAP TNOXPASS_SMSNOX_*.*, TARGET TNOXPASS_SMSNOX_*.* ;
MAP SNOXPASS_SMSNOX_*.*, TARGET SNOXPASS_SMSNOX_*.* ;

MAP TNOXPASS_GWAY_*.*, TARGET TNOXPASS_GWAY_*.* ;
MAP SNOXPASS_GWAY_*.*, TARGET SNOXPASS_GWAY_*.* ;



-- Table Patition Replication....
* Create Table Partition is replicated
* DMLs on Table Partition is also replicated
* Drop partition is only working for user define partition names.
* Name generated by Oracle System for Table Partition will not be dropped (or any DDL related on it) as it 
  checks for the same name of the table partition on replication DB...
* In Interval Partition, system generated partition will not be dropped, name mismatches


-- register extract to the database
/*
   There are two types of CAPTURE's in GoldenGate Replication 
   1) CLASSIC CAPTURE 
   2) INTEGRATED CAPTURE
   
   If extract is register with database (Before starting any process -- mgr, extract, dpump) then it is 
   INTEGRATED CAPTURE, else it's CLASSIC CAPTURE
*/

--- it means we are enabling INTEGRATED CAPTURE replication mode
GGSCI> REGISTER EXTRACT EDCW DATABASE 



---- PARAMETERS for Extract Process

-- option to exclude the user name or ID that is used by Replicat to apply transactions. 
-- Multiple EXCLUDEUSER statements can be used. The specified user is subject to the rules of 
-- the GETREPLICATES or IGNOREREPLICATES parameter
* EXCLUDEUSER or EXCLUDEUSERID 


-- Controls whether or not data operations (DML) produced by business applications except 
-- Replicat are included in the content that Extract writes to a specific trail or file.
* GETAPPLOPS | IGNOREAPPLOPS


-- Controls whether or not DML operations produced by Replicat are included in the content 
-- that Extract writes to a specific trail or file.
* GETREPLICATES | IGNOREREPLICATES



-- command tocheck the replicat process
replicat paramfile /opt/app/goldengate/product/11.2.0/dbhome_1/dirprm/rdce.prm




----
-- To Check and try for the same


-- Create a GoldenGate replication configuration to run a SHELL SCRIPT
-- when an end-of-day processing record is replicated

--- So it will show who many records have been process through-out the day

-- On target(replication) site add the parameter in replicat process
STREQ(STATE, "EOD COMPLETE")=1, EVENACTIONS (Shell "Update_Balances.sh")

-- start replicat process again and check the same at EOD



-- Linux script to Monitor the Replication process is on page number 177-178-179
------------------------------------------------------------------------------
-- OGG Command Line Monitoring Script

-- Linux scripting

vi info_all_cpdb.sh

#!/bin/sh

#info_all.sh

ORACLE_HOSTNAME=$HOST; export ORACLE_HOSTNAME
ORACLE_UNQNAME=cpdb_ga; export ORACLE_UNQNAME
ORACLE_BASE=/opt/oracle; export ORACLE_BASE
GRID_HOME=/opt/oracle/product/11.2.0/grid; export GRID_HOME
DB_HOME=$ORACLE_BASE/product/11.2.0/dbhome_1; export DB_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
ORACLE_SID=cpdb; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
#Oracle Gloden Gate Software Home OGG_HOME
OGG_HOME=/archivelogs/goldengate; export OGG_HOME

BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH:$OGG_HOME; export PATH
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH


echo
echo �######################################################################�
echo `date +%d/%m/%Y\ %k:%M:%S`
echo
$OGG_HOME/ggsci <<EOF
info all
exit
EOF
echo �######################################################################�



epl1trandbrpt1.tsysacquiring.org:/acfs/goldengate> cat /acfs/goldengate/scripts/gglogerror.sh
#!/bin/bash
_logfile=/acfs/goldengate/ggserr.log
_emailFile=/tmp/ggora.$$
_date=`date +%Y-%m-%d`
_search="ORA-"
#_date="2015-10-18"
echo -e "\nSearching for $_search in $_logfile for $_date \n"
cat $_logfile | grep "^$_date" | grep "ORA-" > $_emailFile

if [[ -s $_emailFile ]];then
        perlemail.pl -f OGG_Replication_Err_Alters -t "baidhardas@tsys.com" -c "ifx-dbalerts@tsys.com" -s "$HOSTNAME : Goldengate replication error" -l $_emailFile
else
        echo -e "\nThere are no errors in Golden gate logs..\n"
fi
rm -f $_emailFile


ggserr.log |grep "2016-21-01"|grep "ORA-"

ggserr.log | grep "`date +%Y-%m-%d`" | grep "ORA-"

--**************************************************************************************************************************************************************
Handling GoldenGate Exceptions and Errors with REPERROR
We can use the REPERROR parameter in the Replicat parameter file to control the way that the replication process responds to or handles any errors 
encountered in any of the DML statements which it is trying to process.

We can use the keyword DEFAULT to set a global response for all errors except those for which explicit REPERROR statements have been specified.

In the example we will see how we are handling the ORA-00001: unique constraint violated error using an exception handler specified via the 
REPERROR (-1, EXCEPTION) clause of the Replicat parameter file.

By default, if the replicat process encounters any error condition it will abend.

The example shows how by using an exception handler, replicat process does not abend, but handles the exceptions appropriately and continues processing.

If we have a primary key defined on both the source and target tables and if a unique key violation does happen, then neither the Extract or Replicat 
process gets affected and processing is not halted on either end of the Goldengate environment.

But if we have a case where say there are duplicate key values on the source table, but on the target table there is a primary or unique constraint in place. 
When these duplicate rows get propagated to the target server via the extract trail and when the Replicat process does encounter these row violations of 
the primary key constraint in place on the target table, the replicat process will abend.

However, we can use the REPERROR parameter to specify how we will handle this specific error (or any other error or all errors).

In our example, we have created an �exception� table and the exception handler is to write information about any such rows which are violating the 
unique constraint to this exception table AND continue processing without abending the replicat process.

Without the exception handler in place, we will first see that the Replicat process terminates or abends.

SQL> /
Enter value for 1: 4001
Enter value for 2: KERRY
old   3:  (&1,'&2')
new   3:  (4001,'KERRY')
insert into emp
*
ERROR at line 1:
ORA-00001: unique constraint (IDIT_PRD.PK_EMP) violated



GGSCI (indb02) 5> info replicat myrep

REPLICAT   MYREP     Last Started 2011-04-15 12:18   Status ABENDED
Checkpoint Lag       00:00:00 (updated 00:00:17 ago)
Log Read Checkpoint  File ./dirdat/gg000016
                     2011-04-15 12:19:30.219092  RBA 1825

Using the VIEW REPORT command, we can see why the process has abended.

2011-04-15 12:22:27  WARNING OGG-01004  Aborted grouped transaction on 'IDIT_PRD.EMP', Database error 1 (ORA-00001: unique constraint (IDIT_PRD.PK_EMP) violated).

2011-04-15 12:22:27  WARNING OGG-01003  Repositioning to rba 1825 in seqno 16.

2011-04-15 12:22:27  WARNING OGG-01154  SQL error 1 mapping IDIT_PRD.EMP to IDIT_PRD.EMP OCI Error ORA-00001: unique constraint (IDIT_PRD.PK_EMP) 
violated (status = 1), SQL . 

--Now let us put in an exception handler into our replicat parameter file.

REPLICAT myrep
SETENV (NLS_LANG="AMERICAN_AMERICA.WE8ISO8859P1")
SETENV (ORACLE_SID=GGDB2)
ASSUMETARGETDEFS
USERID idit_prd,PASSWORD idit_prd
REPERROR (-1, EXCEPTION)
MAP idit_prd.emp, TARGET idit_prd.emp;
INSERTALLRECORDS
MAP idit_prd.emp, TARGET idit_prd.emp_exception,
EXCEPTIONSONLY,
COLMAP (USEDEFAULTS,
optype = @GETENV ("lasterr", "optype"),
dberr = @GETENV ("lasterr", "dberrnum"),
dberrmsg = @GETENV ("lasterr", "dberrmsg"));
So the REPERROR (-1, EXCEPTION) means that when we encounter the ORA-00001 error, the exception handler will kick in.


--***********************************************************************************************************

/* Add DDLERROR parameter in the replicat parameter file

See below the parameter DDLERROR where I choose to entirely IGNORE all �ORA-01432' errors. No retries (RETRYOP), 
no filtering on object names (OBJNAME).

edit params <replicat_process_name>

-- ignore all 'ORA-01432: public synonym to be dropped does' errors
-- This failed because, apparently, this public synonym is not present in the Replicat database. 
-- The result the Replicat process abended.
ddlerror 1432 ignore

*/




-------------------------------
-- Manager Process
GGSCI (vzwc1) 1> view params mgr  
  
PORT 7839    
DYNAMICPORTLIST 7840-7914    
USERID ggate, PASSWORD tsys1234   
--AUTOSTART EXTRACT *    
AUTORESTART EXTRACT *,RETRIES 3,WAITMINUTES 5,RESETMINUTES 10     
PURGEOLDEXTRACTS ./dirdat/*,usecheckpoints, minkeepdays 1     --*/  
PURGEDDLHISTORY MINKEEPDAYS 3, MAXKEEPDAYS 5     
PURGEMARKERHISTORY MINKEEPDAYS 3, MAXKEEPDAYS 5     
LAGREPORTHOURS 1    
LAGINFOMINUTES 30    
LAGCRITICALMINUTES 45  

-------------------------------




-- Applying database patches and upgrades when DDL support is enabled 
NOTE: Database patchesand upgrades usually invalidate the Oracle GoldenGate DDL trigger and otherOracle GoldenGate 	
DDL objects. Before applying a database patch, do the following.
	
1. Disable the Oracle GoldenGate DDLtrigger by running the following script.
	@ddl_disable
	
2. Apply the patch.

3. Enable the DDL trigger by running thefollowing script.
	@ddl_enable


-- Applying Oracle GoldenGate patches and upgrades when DDLsupport is enabled
NOTE: If there are instructionslike these in the release notes or upgrade instructions that accompany arelease, 
follow those instead of these. Do not use this procedure for anupgrade from an Oracle GoldenGate version that does not support 
DDL statementsthat are larger than 30K (pre-version 10.4).
 
	Follow these steps to apply a patch or upgrade to the DDL objects. This procedure may or maynot preserve the current DDL 
synchronization configuration, depending onwhether the new build requires a clean installation.
 
1. Run GGSCI. Keep the session open for theduration of this procedure.

2. Stop Extract to stop DDL capture.
	STOP EXTRACT<group>

3. Stop Replicat to stop DDL replication.
	STOP REPLICAT<group>

4. Download or extract the patch or upgradefiles according to the instructions provided by Oracle GoldenGate.

5. Change directories to the OracleGoldenGate installation directory.

6. Run SQL*Plus and log in as a user thathas SYSDBA privileges.

7. Disconnect all sessions that ever issuedDDL, including those of Oracle GoldenGate processes, SQL*Plus, businessapplications, 
   and any other software that uses Oracle. Otherwise the databasemight generate an ORA-04021 error.

8. Run the ddl_disable script to disablethe DDL trigger.

9. Run the ddl_setup script. You areprompted for:
	(1) The name of the Oracle GoldenGateDDL schema. If you changed the schema name, use the new one.
	(2) The installation mode: Selecteither NORMAL or INITIALSETUP mode, depending on what the installation orupgrade instructions require. 
		NORMAL mode recompiles the DDL environmentwithout removing DDL history. INITIALSETUP removes the DDL history.

10. Run the ddl_enable.sql script to enablethe DDL trigger.

11. In GGSCI, start Extract to resume DDLcapture.
	START EXTRACT<group>

12. Start Replicat to start DDLreplication.
	START REPLICAT<group>
	
	
------------------------------------------------------------------------------------

-- ORA-26723: user "GGATE" requires the role "DV_GOLDENGATE_REDO_ACCESS"
After shutting down the db, ran chopt on all the nodes --
abcde0025: (abncu1) /u01/abncu/admin> chopt disable dv

------------------------------------------------------------------------------------


/*
		PURGEOLDEXTRATCS does not work

* If not, add PURGEOLDEXTRACTS to the Manager parameter file to prevent old files from
accumulating.

* If you are using PURGEOLDEXTRACTS, make certain that the Manager user has the
authority to purge trail files, and make certain that the PURGEOLDEXTRACTS options are
used correctly. See the Oracle GoldenGate Windows and UNIX Reference Guide.

* Is there an obsolete Replicat group that is linked to the trail?

* A trail file will not be purged if another process has a checkpoint in it. Delete the
obsolete group with the DELETE REPLICAT command, so that the checkpoint records are
deleted.

* If a checkpoint table is being used for the group, log into the database with the DBLOGIN
command first, so that the checkpoint will be removed from the table.
DBLOGIN [TARGETDB <dsn>,] [USERID <user>, PASSWORD <pw>]
DELETE REPLICAT <group>>

*/	






-- Monitoring Steps
-- Step 1) Make the modification in .bash_prfile file

vi ~/.bash_profile

-- include the JAVA_HOME in top PATH 
JAVA_HOME=/opt/app/goldengate/java_jdk/jdk1.6.0_45; export JAVA_HOME
PATH=$JAVA_HOME/bin:$PATH:$HOME/bin

etc ...
-- other Env.. variables

:wq! -- save the .bash_profile


-- Step 2) Modify the jagent.prm of goldengate

cat $OGG_HOME/dirprm/jagent.prm
COMMAND export JAVA_HOME=/opt/app/goldengate/java_jdk/jdk1.6.0_45
COMMAND /opt/app/goldengate/java_jdk/jdk1.6.0_45/bin/java -jar -Xms64m -Xmx512m /opt/app/goldengate/dirjar/jagent.jar


-- Step 3) modify the ./GLOBALS file to include ENABLEMONITORING param
GGSCI> edit params ./GLOBALS
GGSCHEMA GGATE
CHECKPOINTTABLE GGATE.CHKPTAB
ENABLEMONITORING

:wq! -- save the file 

-- Step 4) create the datastore from goldengate prompt
GGCSI> create datastore

2015-07-07 00:20:37  INFO    OGG-06489  Datastore created.

-- Step 5) Configure password for passwordless monitoring. 
[goldengate@regdbnode1 goldengate]$ ./pw_agent_util.sh -create
Please create a password for Java Agent:
Please confirm password for Java Agent:
Please enter Monitor Server JMX password: ---- this is password for monitoring from JMX OGG-monitoring 
Please confirm Monitor Server JMX password:
Wallet is created successfully.
[goldengate@regdbnode1 goldengate]$

-- Step 6) Check the JAGENT process which should be displaying in OGG prompt
[goldengate@regdbnode1 goldengate]$ ./ggsci

Oracle GoldenGate Command Interpreter for Oracle
Version 11.2.1.0.9 17173672 OGGCORE_11.2.1.0.0OGGBP_PLATFORMS_130801.2015_FBO
Linux, x64, 64bit (optimized), Oracle 11g on Aug  2 2013 01:06:40

Copyright (C) 1995, 2013, Oracle and/or its affiliates. All rights reserved.


GGCSI> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      STOPPED
EXTRACT     STOPPED     EPREG       00:00:00      1824:56:38
EXTRACT     STOPPED     PPR2D       00:00:00      1824:56:31
REPLICAT    RUNNING     RPD2R       00:00:00      00:00:09


GGCSI> start jagent

Sending START request to MANAGER ...
GGCMD JAGENT starting


GGCSI> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     STOPPED     EPREG       00:00:00      1824:56:46
EXTRACT     STOPPED     PPR2D       00:00:00      1824:56:38
REPLICAT    RUNNING     RPD2R       00:00:00      00:00:06



-- Step 7) Check the goldengate logs if jagent is started properly
GGCSI> sh tail -f ggserr.log
2015-07-07 00:25:45  INFO    OGG-00975  Oracle GoldenGate Manager for Oracle, mgr.prm:  GGCMD JAGENT starting.
2015-07-07 00:25:45  INFO    OGG-00978  Oracle GoldenGate Command Tool for Oracle, jagent.prm:  GGCMD JAGENT is running.
2015-07-07 00:25:45  INFO    OGG-01927  Oracle GoldenGate Command Tool for Oracle, jagent.prm:  Child process started, process ID 7064, command line '/opt/app/goldengate/java_jdk/jdk1.6.0_45/bin/java -jar -Xms64m -Xmx512m /opt/app/goldengate/dirjar/jagent.jar'.
2015-07-07 00:25:47  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.

CTL+C -- come back to ogg prompt
GGCSI> 




----------------------------------------------------------------------------------------------------------------------------------
--> Upgrading goldengate version from 11.2.1.0.1 to 11.2.1.0.31


1 create a empty directory and give required privs to directory
	mkdir ogg_v1121031
	-- using root access
	chown -R goldengate:oinstall ogg_v1121031/
	chmod 775 -R ogg_v1121031/

2 unzip goldengate latest patch in ogg_v1121031

	unzip /home/uploads/p21158243_1121031_Linux-x86-64.zip

3 unzip fbo.* into ogg_v1121031 directory

	tar -xf fbo_ggs_Linux_x64_ora11g_64bit.tar
	
4 stop all ogg processes which are running including mgr and jagent

	stop epdec
	stop rpdec
	stop jagent
	stop mgr *!

-- this activity is not required, but just to be sure
* Stop the ogg pump process of target from soruce
	-- login to source and stop the pump process
	-- Once you stop the pump process, trail file will not get trasferred to target db
	stop PPTWTE
	
	info PPTWTE, SHOWCH

5 take the backup of checkpoint record, which will store the Current Checkpoint Detail - Sequence and RBA
	info RPTETW, showch
/*
	REPLICAT   RPTETW    Last Started 2015-09-01 00:11   Status STOPPED
	Checkpoint Lag       00:00:00 (updated 00:09:58 ago)
	Log Read Checkpoint  File /ora3/goldengate/dirdat/WA000270
						 2015-09-01 02:17:58.973890  RBA 427313

	Current Checkpoint Detail:

	Read Checkpoint #1

	  GGS Log Trail

	  Startup Checkpoint (starting position in the data source):
		Sequence #: 269
		RBA: 1971
		Timestamp: 2015-09-01 00:11:48.000000
		Extract Trail: /ora3/goldengate/dirdat/WA

	  Current Checkpoint (position of last record read in the data source):
		Sequence #: 270
		RBA: 427313
		Timestamp: 2015-09-01 02:17:58.973890
		Extract Trail: /ora3/goldengate/dirdat/WA

	CSN state information:
	  CRC: 33-9F-89-9D
	  Latest CSN: 278372151
	  Latest TXN: 5.33.430621
	  Latest CSN of finished TXNs: 278372151
	  Completed TXNs: 5.33.430621

	Header:
	  Version = 2
	  Record Source = A
	  Type = 1
	  # Input Checkpoints = 1
	  # Output Checkpoints = 0

	File Information:
	  Block Size = 2048
	  Max Blocks = 100
	  Record Length = 2048
	  Current Offset = 0

	Configuration:
	  Data Source = 0
	  Transaction Integrity = -1
	  Task Type = 0

	Database Checkpoint:
	  Checkpoint table = ggate.CHKPTAB
	  Key = 875367958 (0x342d0e16)
	  Create Time = 2015-03-17 04:40:54

	Status:
	  Start Time = 2015-09-01 00:11:52
	  Last Update Time = 2015-09-01 02:50:13
	  Stop Status = G
	  Last Result = 400
*/

6 check all the processes are stop on OGG upgrading site
	info all

7 Now take the backup of existing ogg directory
	-- once the you copy completed, you will see the new folder named as goldengate_01Sept2015 
	-- which will be copy of goldengate will all files and subfolders in it
	cp -fr goldengate goldengate_01Sept2015/

8 Now copy the latest verion of ogg files/folders into current working goldengate directory 
	alias cp='cp' --- this is for a session, this removes the -i which will not ask every time to overwrite the files
	cp -ar ogg_v1121031/* goldengate/          
	-- check all the files are got copied to new directory */	

9 loging to goldengate user
	sudo su -l goldengate
	info all -- all the processes are still in stop state
	
10 loging with ggate user in goldengate to upgrade the checkpoint table
	-- now loging with admin user whichi ggate, to update the checkpoint table
	obey dirsql/dblogin.sql
	
11 Now upgrade checkpointtable
	UPGRADE CHECKPOINTTABLE

12 Rebuilding an Oracle DDL environment to a clean state.
	a) Run the ddl_disable script to disable the DDL trigger
    b) Run the ddl_remove
    c) Run the marker_remove script
    d) Run the marker_setup script to reinstall
    e) Run the ddl_setup script
    f) Run the role_setup script to recreate the Oracle GoldenGate DDL role --EXEC DBMS_GOLDENGATE_AUTH.GRANT_ADMIN_PRIVILEGE (grantee=>'GGATE',privilege_type=>'capture',grant_select_privileges=>true, do_grants=>TRUE); 
    g) Grant the role to ggate user
    h) Run the ddl_pin ggate
	i) Run the Sequence
    h) Run the ddl_enable.sql script to enable the DDL trigger.

13 start the processes and check the data is replicating or not...
	
	-- You would have taken the backup of showch command of extract, dpump, replicat process at above level of steps and 
	-- from their you will get the RBA and SEQ number
	
	
	
	
/*	
	alter extract eprw, EXTSEQNO 19488, EXTRBA 17482752, thread 1
	alter extract eptw, EXTSEQNO 9696, EXTRBA 5768704, thread 2

	alter extract eptw,thread 2, begin 2015-09-02 01:15:23

	alter extract eptw,ETROLLOVER


	alter replicat rptetw, extseqno 4829, extrba 48925472

*/



-------------------------------------------------------------------------------------------------------------------------------------------------
-- Apply GoldenGate Patch version 11.2.1.0.31 on Goldengate version 11.2.1.0.22

* Download the latest goldengate patch version and check the ReadMe file

1) Log-In to Source Primary DB (TW) GoldenGate and stop the Pump Process
	
	OGG_GGSCI> STOP PPTWRE

2) Take the backup of RBA and Sequence number of Trail files
	
	OGG_GGSCI> send extract EPTW, showtrans
	
	OGG_GGSCI> info PPTWRE, showch -- This command will have the last sequence number. check for (Current Checkpoint (current write position)) line
	
3) Log-In to Source Reporting DB (RW) GoldenGate and stop the Pump Process
	
	OGG_GGSCI> STOP PPRWRE

4) Take the backup of RBA and Sequence number of Trail files

	OGG_GGSCI> info PPRWRE, showch
	
5) Log-In Target Reporting DB (RE) where you will be applying GoldenGate patch

	sudo su -l goldengate

6) Stop all replicat, extract, jagent processes on RE DB
	
	OGG_GGSCI> stop rp*
	OGG_GGSCI> stop epre
	OGG_GGSCI> stop jagent
	
7) Take the backup of showch command from all replicat

	OGG_GGSCI> info replicat RPRERW, showch
	OGG_GGSCI> info replicat RPRETE01, showch
	OGG_GGSCI> info replicat RPRETW01, showch

8) Log-In to Target DB RE, Oracle user and stop the xag and goldengate vip resources
	sudo su -l oracle
	
	ORACLE>  /opt/app/oracle/xag/bin/agctl stop goldengate gg_etxn

	ORACLE> crsctl stop resource e-txn-ggatevip.tsysacquiring.org -n epl1trandbtxn1
	
--	ORACLE> crsctl relocate resource e-txn-ggatevip.tsysacquiring.org -n epl1trandbtxn1	
--	ORACLE> /opt/app/oracle/xag/bin/agctl status goldengate gg_erpt
--	ORACLE> /opt/app/oracle/xag/bin/agctl stop goldengate gg_erpt
--	ORACLE> crsctl stop resource e-rpt-ggatevip.tsysacquiring.org
	
	ORACLE> crsctl stat res -t

 8.1) For safer side Please take the backup of GoldenGate user ggate from oracle.
 	
 	ORACLE> expdp rchaudhari directory=bkups dumpfile=expdp_ggatae_09092015.dmp logfile=expdp_ggate09092015.log schemas=ggate compression=all

9) Log-in to goldengate user on target DB RE and check if goldengate all processes are stopped
	sudo su -l goldengate
	
	OGG_GGSCI> info all

	OGG_GGSCI> exit -- from the ggsci prompt and come to shell of goldengate 
	
10) Take the backup of existing goldengate files and folder 
	
	cd /acsf/
	
	tar -cvf ogg_09sept2015.tar.gz goldengate/
	
11) unzip the latest version of goldengate patch to empty directory 
	
	mkdir ogg_112031
	
	cd ogg_112031
	
	unzip p21158243_1121031_Linux-x86-64.zip

12) Copy all files and folder from 
	
	alias cp='cp'
	cp -ar ogg_112031/* goldengate/  --*/

13)	log-in to goldengate and check the processes
	./ggsci
	
	OGG_GGSCI> info all
	
14) Update the checkpoint table of goldengate
	
	-- to update the checkpoint table you will have to loging with ggate admin user
	OGG_GGSCI> obey dirsql/dblogin.oby
	
	OGG_GGSCI> UPGRADE CHECKPOINTTABLE
	-- upgrading checkpoint might give error of column already exists, ignore it

15) Rebuild all the DDL scripts	

	OGG_GGSCI> sh sqlplus / as sysdba

SQL> @ddl_remove
SQL> @marker_remove
SQL> @marker_setup
SQL> @ddl_setup
	-- here you will get the error if there are any sessions locked of goldengate of others. Please kill them and rerun it
SQL> @ddl_setup
SQL> @role_setup
SQL> GRANT GGS_GGSUSER_ROLE TO ggate;
SQL> EXEC DBMS_GOLDENGATE_AUTH.GRANT_ADMIN_PRIVILEGE (grantee=>'GGATE',privilege_type=>'capture',grant_select_privileges=>true, do_grants=>TRUE);
SQL> @sequence
SQL> @ddl_enable.sql
SQL>exit;
	OGG_GGSCI> info all
	OGG_GGSCI> exit;

16) log-in to oracle user and start the xag and goldengate vip services
	
		sudo su -l oracle
		
		-- start the goldengate vip on node 1
		ORACLE> crsctl start resource e-rpt-ggatevip.tsysacquiring.org -n epl1trandbrpt1
		
		-- start the xag utility on node 1
		ORACLE> /opt/app/oracle/xag/bin/agctl start goldengate gg_erpt --node epl1trandbrpt1

 -- 		ORACLE> crsctl start resource e-txn-ggatevip.tsysacquiring.org -n epl1trandbtxn1
 --		ORACLE> /opt/app/oracle/xag/bin/agctl start goldengate gg_etxn --node epl1trandbtxn1

		
		ORACLE> crsctl stat res -t

17) log-in to goldengate and check the manager process is now started

	sudo su -l goldengate
	
	OGG_GGSCI> info all
	
	OGG_GGSCI> start jagent
	
	OGG_GGSCI> sh tail -f ggserr.log -- check any errors are coming while starting jagent

	OGG_GGSCI> start epre -- start the extract process of target db which should not have any data caputered as it's DR site DB
	
18) check the RMT trail file of target db and check the last file got transferd. Note-down the number
	This should be done before starting the Pump process of Source DB
	
	OGG_GGSCI> sh ls -ltrh dirdat/WS*	
		-rw-r----- 1 goldengate dba  96M Sep  7 01:02 WS000185
		-rw-r----- 1 goldengate dba  96M Sep  7 01:04 WS000186
		-rw-r----- 1 goldengate dba  96M Sep  7 03:51 WS000187
		-rw-r----- 1 goldengate dba  96M Sep  7 21:11 WS000188
		-rw-r----- 1 goldengate dba  96M Sep  8 01:03 WS000189
		-rw-r----- 1 goldengate dba  96M Sep  8 02:44 WS000190
		-rw-r----- 1 goldengate dba  96M Sep  8 07:13 WS000191
		-rw-r----- 1 goldengate dba  96M Sep  8 13:51 WS000192
		-rw-r----- 1 goldengate dba  96M Sep  8 21:05 WS000193
		-rw-r----- 1 goldengate dba  16M Sep  9 00:44 WS000194
		
19) log-in to source DB extracting DB (RW) and start the pumps
	
	-- first started the pump from RW, late the data get sync-up and do the activity on TW
	
	OGG_GGSCI> start PPRWRE
	OGG_GGSCI> info all 

20) log-in to target DB RE and check the rmt trail files are getting transfered from source extracting DB (RW)
	
	OGG_GGSCI> sh ls -ltrh dirdat/WS*	
	-rw-r----- 1 goldengate dba  96M Sep  7 01:02 WS000185
	-rw-r----- 1 goldengate dba  96M Sep  7 01:04 WS000186
	-rw-r----- 1 goldengate dba  96M Sep  7 03:51 WS000187
	-rw-r----- 1 goldengate dba  96M Sep  7 21:11 WS000188
	-rw-r----- 1 goldengate dba  96M Sep  8 01:03 WS000189
	-rw-r----- 1 goldengate dba  96M Sep  8 02:44 WS000190
	-rw-r----- 1 goldengate dba  96M Sep  8 07:13 WS000191
	-rw-r----- 1 goldengate dba  96M Sep  8 13:51 WS000192
	-rw-r----- 1 goldengate dba  96M Sep  8 21:05 WS000193
	-rw-r----- 1 goldengate dba  16M Sep  9 00:44 WS000194
	-rw-r----- 1 goldengate dba 1.5M Sep  9 00:44 WS000195
	
		
21) now start the target replicat by giving last transferred rmt trail files number
	
	OGG_GGSCI> alter replicat RPRERW, EXTSEQNO 000194
	OGG_GGSCI> start RPRERW
	OGG_GGSCI> info all
	OGG_GGSCI> sh tail -f ggserr.log -- check if there is any error while replicating the data to target database
	OGG_GGSCI> info all -- check the data is getting sync
	
22) Log-in to Toad and check if the data is getting replicated

	-- execute the same query on source db and target
	select max(transaction_id) from transnox_iox.trasnaction;

23) To start replicat process from TW to RE, Please follow similar steps #18 - #22 to get the extseqno to start the replicat process on
	target db and validate the replication data




--------------------------------------------------------------------------------------------------------------------------
-- logdump utility


-- get the latest RMT trail file by 
info replicat RPTETW,showch

info extract EPTW,showch

-- take the current log read checkpoint file
REPLICAT   RPTETW    Last Started 2015-09-14 01:20   Status RUNNING
Checkpoint Lag       00:00:00 (updated 00:00:00 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/WB004789
                     2015-09-15 05:35:52.019764  RBA 73422536
                     
                     
in OGG_HOME

./logdump

Logdump 1 >open /acfs/goldengate/dirdat/WB004789
Current LogTrail is /acfs/goldengate/dirdat/WB004789

--- so now we are at current log trail file for some investigation

-- The command count will return data for all records contain in the trail
-- this command will display the count of DML's
Logdump 1 >count

-- The command detail on tells Logdump to display the totals and averages shown above and then sort 
-- the data and display it for each unique table contained within the Trail.
Logdump 1 >detail on 
Logdump 1 >count




-- It will display the count of DDL, DML, DCL (Commit or Rollback) operations, etc.
-- Display count details
Logdump> COUNT DETAIL

-- Count of the records in trail file
Logdump> COUNT

-- Previously used commands in the current Logdump session
Logdump> HISTORY

-- Open the next trail file
Logdump> NEXTTRAIL

-- Record Header
Logdump> GHDR ON

-- Set Column Details on, It displays the list of columns, their ID, length, Hex values etc.
Logdump> DETAIL ON




FC [<num> | <string>]     - Edit previous command
HISTORY                   - List previous commands
OPEN | FROM  <filename>   - Open a Log file
RECORD | REC              - Display audit record
NEXT [ <count> ]          - Display next data record
SKIP [ <count> ] [FILTER] - Skip down <count> records
     FILTER               - Apply filter during skip
COUNT                     - Count the records in the file
      [START[time] <timestr>,]
      [END[time] <timestr>,]
      [INT[erval] <minutes>,]
      [LOG[trail] <wildcard-template>,]
      [FILE <wildcard-template>,]
      [DETAIL ]
       <timestr> format is
         [[yy]yy-mm-dd] [hh[:mm][:ss]]
POSITION [ <rba> | FIRST | LAST | EOF ] - Set position in file
         REVerse | FORward              - Set read direction
RECLEN [ <size> ]  - Sets max output length
EXIT | QUIT        - Exit the program
FILES | FI | DIR   - Display filenames
ENV                - Show current settings
VOLUME | VOL | V   - Change default volume
DEBUG              - Enter the debugger
GHDR  ON | OFF     - Toggle GHDR display
DETAIL ON | OFF | DATA - Toggle detailed data display
RECLEN <nnn>        - Set data display length
SCANFORHEADER (SFH)  [PREV]  - Search for the start of a header
SCANFORTYPE   (SFT) - Find the next record of <TYPE>
      <typename> | <typenumber>
      [,<filename-template>]
SCANFORRBA    (SFR) - Find the next record with <SYSKEY>
      <syskey>                - syskey = -1 scans for next record
      ,<filename-template>
SCANFORTIME  (SFTS) - Find the next record with timestamp
      <date-time string>
      [,<filename-template>]
         <date-time string> format is
           [[yy]yy-mm-dd] [hh[:mm][:ss]]
SCANFORENDTRANS (SFET) - Find the end of the current transaction
SCANFORNEXTTRANS (SFNT) - Find start of the next transaction
SHOW <option>       - Display internal information
      [OPEN]        - list open files
      [TIME]        - print current time in various formats
      [ENV]         - show current environment
      [RECTYPE]     - show list of record types
      [FILTER]      - show active filter items
BIO  <option>       - Set LargeBlock I/O info
      [ON]          - Enable LargeBlock I/O (default)
      [OFF]         - Disable LargeBlock I/O
      [BLOCK <nnnn>]- Set LargeBlock I/O size
TIMEOFFSET <option> - Set the time offset from GMT
      [LOCAL]            - Use local time
      [GMT]              - Use GMT time
      [GMT +/- hh[:mm]]  - Offset +/- from GMT
FILTER SHOW
FILTER ENABLE | ON   - Enable filtering
FILTER DISABLE | OFF - Disable filtering
FILTER CLEAR [ <filterid> | <ALL> ]
FILTER MATCH     ANY | ALL
FILTER [INClude | EXCLude] <filter options>
   <filter options> are
       RECTYPE  <type number | type name>
       STRING [BOTH] /<text>/ [<column range>]
       HEX      <hex string>  [<column range>]
       TRANSID  <TMF transaction identifier>
       FILENAME <filename template>
       PROCESS  <processname template>
       INT16    <16-bit integer>
       INT32    <32-bit integer>
       INT64    <64-bit integer>
       STARTTIME <date-time string>
       ENDTIME   <date-time string>
       SYSKEY   [<comparison>] <32/64-bit syskey>
       SYSKEYLEN [<comparison>] [<value>]
       TRANSIND [<comparison>] <nn>
       UNDOFLAG [<comparison>] <nn>
       RECLEN   [<comparison>] <nn>
       AUDITRBA [<comparison>] <nnnnnnnn>
       ANSINAME <ansi table name>
       GGSTOKEN <tokenname> [<comparison>] [<tokenvalue>]
       USERTOKEN <tokenname> [<comparison>] [<tokenvalue>]
       CSN | LogCSN [<comparison>] [<value>]
   <column range>
       <start column>:<end column>, ie  0:231
   <comparison>
       =, ==, !=, <>, <, >, <=, >=  EQ, GT, LE, GE, LE, NE
X <program> [string]  - Execute <program>
TRANSHIST nnnn        - Set size of transaction history
TRANSRECLIMIT nnnn    - Set low record count threshold
TRANSBYTELIMIT nnnn   - Set low byte count threshold
LOG {STOP} | { [TO] <filename> } - Write a session log
BEGIN <date-time>     - Set next read position using a timestamp
SAVEFILECOMMENT on | OFF  - Toggle comment records in a savefile
SAVE <savefilename> [!] <options>  - Write data to a savefile
   <options> are
   nnn RECORDS | nnn BYTES
   [NOCOMMENT]  - Suppress the Comment header/trailer recs, Default
   [COMMENT]    - Insert Comment header/trailer recs
   [OLDFORMAT]  - Force oldformat records
   [NEWFORMAT]  - Force newformat records
   [TRUNCATE ]  - purgedata an existing savefile
   [EXT ( <pri>, <sec> [,<max>])] - Savefile Extent sizes on NSK
   [MEGabytes <nnnn>]             - For extent size calculation
   [TRANSIND <nnn>]               - Set the transind field
   [COMMITTS <nnn>]               - Set the committs field
USERTOKEN     on  | OFF | detail  - Show user token info
HEADERTOKEN   on  | OFF | detail  - Show header token info
GGSTOKEN      on  | OFF | detail  - Show GGS token info
FILEHEADER    on  | OFF | detail  - Display file header contents
ASCIIHEADER   ON  | off           - Toggle header charset
EBCDICHEADER  on  | OFF           - Toggle header charset
ASCIIDATA     ON  | on            - Toggle user data charset
EBCDICDATA    on  | OFF           - Toggle user data charset
ASCIIDUMP     ON  | off           - Toggle charset for hex/ascii display
EBCDICDUMP    on  | OFF           - Toggle charset for hex/ascii display
TRAILFORMAT   old | new           - Force trail type
PRINTMXCOLUMNINFO  on | OFF       - Toggle SQL/MX columninfo display
TMFBEFOREIMAGE     on | OFF       - Toggle display of TMF before images
FLOAT  <value>                    - Interpret a floating point number
       [FORMAT <specifier>]       - sprintf format default %f


--------------------------------------------------------------------------------------------------------------------------

/*

GoldenGate Replication Processes

-- Extract process
ADD EXTRACT eprc, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/ss, EXTRACT eprc, MEGABYTES 100

-- Pump Process
ADD EXTRACT pprc, EXTTRAILSOURCE /acfs/goldengate/dirdat/ss
ADD RMTTRAIL /acfs/goldengate/dirdat/xy, EXTRACT pprc, MEGABYTES 100

-- Replication Process
ADD REPLICAT rprc, EXTTRAIL /acfs/goldengate/dirdat/xy


-- WEST
ADD REPLICAT RPRWTELG, EXTTRAIL /acfs/goldengate/dirdat/EC, CHECKPOINTTABLE GGATE.CHECKPOINT

ADD REPLICAT RPTWTELG, EXTTRAIL /acfs/goldengate/dirdat/EB, CHECKPOINTTABLE GGATE.CHECKPOINT

ADD REPLICAT RPRWTWLG, EXTTRAIL /acfs/goldengate/dirdat/WC, CHECKPOINTTABLE GGATE.CHECKPOINT

-- EAST
ADD REPLICAT RPTETWLG, EXTTRAIL /acfs/goldengate/dirdat/WB, CHECKPOINTTABLE GGATE.CHECKPOINT

ADD REPLICAT RPRETWLG, EXTTRAIL /acfs/goldengate/dirdat/WA, CHECKPOINTTABLE GGATE.CHECKPOINT

ADD REPLICAT RPRETELG, EXTTRAIL /acfs/goldengate/dirdat/EA, CHECKPOINTTABLE GGATE.CHECKPOINT

RPTWTE



SQLEXEC "alter session set commit_wait = 'NOWAIT'";



alter RPRWTELG, extseqno 263, extrba 17732418

*/


----------------------------------------------------------------------------------------------------------------------------

#RANGE Funcation for replicate and extract

-- best url *** http://gavinsoorma.com/2011/03/goldengate-performance-tuning-using-the-range-function/

--* How does GoldenGate Range Function @Range work?
-- The @Range function divides a workload into multiple, randomly distributed groups of data. It determines the 
-- group that the range falls in, by computing a hash against the primary key or user-defined columns. It guarantees 
-- that the same row is always processed by the same process group.

-- The @Range function can be used on either the TABLE or the MAP parameter of Extract and Replicat parameter respectively. 
-- The @Range function is used along with the FILTER clause.

--* Limitations of @Range
-- You can�t use @Range function, if primary key updates are performed on the database.

--* Replicat processes on Target System
-- Here we will create 3 Replicat processes, with each Replicat group processing one-third of the data in the GoldenGate trail based on the primary key.

-- Replicat - 1
$ cd $GG_HOME
$ ./ggsci

GGSCI> EDIT PARAMS Rrange1
Replicat Rrange1
USERID GGS, Password oracle
DISCARDFILE ./dirrpt/Rrange1.dsc, Append
ASSUMETARGETDEFS
MAP Scott.EMP, TARGET Scott.EMP, FILTER (@RANGE (1,3));
MAP Scott.DEPT, TARGET Scott.DEPT, FILTER (@RANGE (1,3));

GGSCI> ADD Replicat Rrange1, EXTTRAIL ./dirdat/rt

GGSCI> Start Rrange1

GGSCI> Info Rrange1

-- Replicat - 2
GGSCI> EDIT PARAMS Rrange2
Replicat Rrange2
USERID GGS, Password oracle
DISCARDFILE ./dirrpt/Rrange2.dsc, Append
ASSUMETARGETDEFS
MAP Scott.EMP, TARGET Scott.EMP, FILTER (@RANGE (2,3));
MAP Scott.DEPT, TARGET Scott.DEPT, FILTER (@RANGE (2,3));

GGSCI> ADD Replicat Rrange2, EXTTRAIL ./dirdat/rt

GGSCI> Start Rrange2

GGSCI> Info Rrange2

-- Replicat � 3
GGSCI> EDIT PARAMS Rrange3
Replicat Rrange3
USERID GGS, Password oracle
DISCARDFILE ./dirrpt/Rrange3.dsc, Append
ASSUMETARGETDEFS
MAP Scott.EMP, TARGET Scott.EMP, FILTER (@RANGE (3,3));
MAP Scott.DEPT, TARGET Scott.DEPT, FILTER (@RANGE (3,3));

GGSCI> ADD Replicat Range3, EXTTRAIL ./dirdat/rt

GGSCI> Start Rrange3

GGSCI> Info Rrange3






Example 1   
--In the following example, the replication workload is split into three ranges (between three Replicat processes) 
--based on the ID column of the source acct table.

--(Replicat group 1 parameter file)

MAP sales.acct, TARGET sales.acct, FILTER (@RANGE (1, 3, ID));
--(Replicat group 2 parameter file)

MAP sales.acct, TARGET sales.acct, FILTER (@RANGE (2, 3, ID));
--(Replicat group 3 parameter file)

MAP sales.acct, TARGET sales.acct, FILTER (@RANGE (3, 3, ID));

Example 2   
--In the following example, one Extract process splits the processing load into two trails. Since no columns were 
--defined on which to base the range calculation, Oracle GoldenGate will use the primary key columns.

RMTTRAIL /ggs/dirdat/aa
TABLE fin.account, FILTER (@RANGE (1, 2));
RMTTRAIL /ggs/dirdat/bb
TABLE fin.account, FILTER (@RANGE (2, 2));

Example 3   
--In the following example, two tables have relative operations based on an order_ID column. The order_master table 
--has a key of order_ID, and the order_detail table has a key of order_ID and item_number. Because the key order_ID establishes 
--relativity, it is used in @RANGE filters for both tables to preserve referential integrity. The load is split into two ranges.

--(Parameter file #1)

MAP sales.order_master, TARGET sales.order_master, FILTER (@RANGE (1, 2, order_ID));
MAP sales.order_detail, TARGET sales.order_detail,FILTER (@RANGE (1, 2, order_ID));

--(Parameter file #2)

MAP sales.order_master, TARGET sales.order_master,FILTER (@RANGE (2, 2, order_ID));
MAP sales.order_detail, TARGET sales.order_detail,FILTER (@RANGE (2, 2, order_ID));
----------------------------------------------------------------------------------------------------------------------------


----
#!/bin/bash
_logfile=/acfs/goldengate/ggserr.log
_emailFile=/tmp/ggora.$$
_date=`date +%Y-%m-%d`
_search="ORA-"
#_date="2015-10-18"
echo -e "\nSearching for $_search in $_logfile for $_date \n"
cat $_logfile | grep "^$_date" | grep "ORA-" > $_emailFile

if [[ -s $_emailFile ]];then
        perlemail.pl -f OGG_Replication_Err_Alters -t "baidhardas@tsys.com" -c "ifx-dbalerts@tsys.com" -s "$HOSTNAME : Goldengate replication error" -l $_emailFile
else
        echo -e "\nThere are no errors in Golden gate logs..\n"
fi
rm -f $_emailFile



----------------------------------------------------------------------------------------------------------------------------
Rate = number of records processed since startup / total time since startup
Delta = number of records since last report / time since last report




----------------------------------------------------------------------------------------------------------------------------

-- Adding new tables to an existing Oracle GoldenGate replication
1) Stop the extract on Source DB
2) stop the source replicators on target DBs
3) Make the DB release for the new tables
4) add those newly add tables to extract source db and all replicators target db
5) start extract and replicators

----------------------------------------------------------------------------------------------------------------------------

-- Resynchronizing an out-of-sync table - Oracle Golden Gate

1) Comment out the out-of-sync table in the original Replicat parameter file.
2) Stop the original Replicat and start it again so it continues processing the tables that are not out-of-sync.

STOP REPLICAT <groupA>
START REPLICAT <groupA>

3) Check the lags on replicating DB, let the lag gets completed. Here we are replicating all the tables except the out-of-sycn table (which
wew have commented out in replicat of target DB)

5) Take the export(datapump) of the single table with flashback_SCN from source database

-- on Source DB
-- Take the export of schemas using flashback_scn
SQL> SELECT 'flashback_scn=' || TO_CHAR(sys.DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER) FROM dual;

11454852

----------------

oracle> vi exp_test.par
DUMPFILE="LoadTestBackup_11454852.dmp"
LOGFILE="exp_LoadTestBackup_11454852.log"
DIRECTORY=BKUP
FLASHBACK_SCN=11454852
COMPRESSION=ALL
CONTENT=ALL
TABLES=TRANSNOX_IOX.EMPLOYEE

6) Transfer the dump file on Target DB

-- On Traget DB

6) Import the dump file on Target DB using DataPump import.

7) create new replicat process (from the same trail file, which groupA replicat process has) on Target DB which will be only replicating out-of-sync table

8) Start the replicate process with after, that flashback_scn

for e.g..

start replicat RPRETW aftercsn 11454852

let the lag gets completed...

-- for more details check the below URL ....
http://arpitagrawaloracle.blogspot.in/2014/04/resynchronizing-out-of-sync-table.html

----------------------------------------------------------------------------------------------------------------------------