
--
--                   TSYS
--
--
-- DCW Replicat Process Reporting DB(RPCPTE01)
--
-- Replicating Data from DCW Primary DB to DCE Primary DB
--
--
--
-- Set the runtime attributes for a Replicat which reads
-- from a GoldenGate Remote Trail and applies the data
-- to a target set of tables
--

-- REPLICAT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (RPCPTE01.prm) must exist in the
-- dirprm directory/folder.
REPLICAT RPTETW01

-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
-- CHECKPARAMS

-- Set environment
-- This area is used for creating and monitoring environments
-- Must set environments
-- If you change servers you will need to change SID
-- IF fails, do a view report SEVICE-NAME to see env
-- SETENV (ORACLE_SID  = "transitr1")
SETENV (ORACLE_HOME = "/opt/app/oracle/product/11.2.0/dbhome_2")

-- Import Language Settings
-- SETENV (NLS_LANG="AMERICAN_AMERICA.US7ASCII")

-- The login credentials GoldenGate is to use to access the database.
USERID ggate@TRANSITTXNGA, PASSWORD tsys123

-- BATCHSQL BATCHESPERQUEUE 1000, OPSPERBATCH 100000

-- The ASSUMETARGETDEFS means that the target table schema is
-- the same as the source. For this to be valid, the column names,
-- and data types, are the same and they appear in the same order
-- as the source tables.
ASSUMETARGETDEFS

-- DBOPTIONS SUPPRESSTRIGGERS parameter to prevent triggers on target
-- when user is GoldenGate user (oraclegg). Package
-- dbms_goldengate_auth.grant_admin_privilege must be run for GoldenGate user
--    exec dbms_goldengate_auth.grant_admin_privilege(grantee => 'ORACLEGG', grant_select_privileges => TRUE);
DBOPTIONS SUPPRESSTRIGGERS

-- Error Handling
-- DDLERROR is a catch all for DDL to just ignore all DDL errors.
-- use this only for troubleshooting
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
-- DDLERROR RESTARTSKIP 1
DDLERROR DEFAULT IGNORE

-- DDL Parameter
-- DDL INCLUDE ALL, EXCLUDE OBJNAME TRANSNOX_IOX.REPORT_USAGE_SEQ, EXCLUDE OBJNAME GGATE.EXCEPTIONS
DDL INCLUDE ALL, EXCLUDE OBJNAME GGATE.EXCEPTIONS


-- End of "best practices" section

-- The DISCARD file is where Replicat writes transaction information
-- when it encounters a data issue
DISCARDFILE /acfs/goldengate/discard/RPTETW01.dsc, APPEND, MEGABYTES 500

----------------------------------------------------------------------------------
-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 00:01

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 00:01

-- REPORTCOUNT denotes that every 60 seconds the Replicat report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE
----------------------------------------------------------------------------------

-- Overlap Mode Processing
-- Handlecollisions and End Runtime are to be used only when the target
-- database is being instantiated. Once the initial load extract and replicat
-- complete, we start change data replicat with these options.
-- Handlecollisions sets the replicat to ignore missing data in the target
-- and to overlay the row if it already exists.
-- End Runtime sets replicat to terminate normally whenever it encounters
-- a record that matches, or is after the process start time.
-- This has to be only ENABLE in Bidirectional replications to handle Overlapping process
--HANDLECOLLISIONS

ALLOWNOOPUPDATES

-- Handling GoldenGate Exceptions and Errors with REPERROR
REPERROR (-1403, DISCARD)
REPERROR (DEFAULT, EXCEPTION)
REPERROR (DEFAULT2, EXCEPTION)
REPERROR (-1, EXCEPTION)

--
-- The MAP statement sets the correlation between the source and
-- target tables. The source schema and tables are identified on the left
-- hand side of the statement and the target schema and tables are
-- identified after the keyword TARGET. Wildcards are allowed, and the
-- * wildcard denotes all tables. The MAP statement must be terminated
-- by a semi-colon.

-- By default, Oracle GoldenGate synchronizes insert, update, and delete operations. You can
-- use the following parameters in the Extract or Replicat parameter file to control which
-- kind of operations are processed, such as only inserts or only inserts and updates.
-- IGNOREINSERTS | GETINSERTS
-- IGNOREUPDATES | GETUPDATES
-- IGNOREDELETES | GETDELETES
--- If you want to ignore DELETE DML on any table

-- Mother Schemas
-- MAP RCHAUDHARI.*, TARGET RCHAUDHARI.*, FILTER(@RANGE(1,3));


MAP OEMTESTING.*, TARGET OEMTESTING.*;

-- List of Mother schemas
MAP KEYNOX_CPASS.*, TARGET KEYNOX_CPASS.*;
MAP WEBFORT_CPASS.*, TARGET WEBFORT_CPASS.*;

MAPEXCLUDE TRANSNOX_CAT.SN_TEMP*
MAPEXCLUDE TRANSNOX_CAT.SC_TEMP*
MAP TRANSNOX_CAT.*, TARGET TRANSNOX_CAT.*;

MAPEXCLUDE TRANSNOX_IOX.SN_TEMP*
MAPEXCLUDE TRANSNOX_IOX.SC_TEMP*
MAP TRANSNOX_IOX.*, TARGET TRANSNOX_IOX.*;

MAPEXCLUDE SNOX4TRANSNOX.SN_TEMP*
MAPEXCLUDE SNOX4TRANSNOX.SNOX_POSTOFFICE_IDM_STATUS
MAPEXCLUDE SNOX4TRANSNOX.SC_TEMP*
MAP SNOX4TRANSNOX.*, TARGET SNOX4TRANSNOX.*;
MAP TRANSTSYSPAYMENTGW.*, TARGET TRANSTSYSPAYMENTGW.*;
---------------------------------------------------------------------
-- APP Schemas
MAP ETLUPDATE.*, TARGET ETLUPDATE.*;
MAPEXCLUDE TRANSNOX_IOX_APP.SN_TEMP*
MAPEXCLUDE TRANSNOX_IOX_APP.SC_TEMP*
MAP TRANSNOX_IOX_APP.*, TARGET TRANSNOX_IOX_APP.*;
MAPEXCLUDE SNOX4TRANSNOX_APP.SN_TEMP*
MAPEXCLUDE SNOX4TRANSNOX_APP.SC_TEMP*
MAP SNOX4TRANSNOX_APP.*, TARGET SNOX4TRANSNOX_APP.*;
MAP TRANSTSYSPAYMENTGWAPP.*, TARGET TRANSTSYSPAYMENTGWAPP.*;
---------------------------------------------------------------------
-- Schemas Used for Socket Getway
MAPEXCLUDE SNOXPASS_SMSNOX_20195.SN_TEMP*
MAPEXCLUDE SNOXPASS_SMSNOX_20195.SC_TEMP*
MAP SNOXPASS_SMSNOX_20195.*, TARGET SNOXPASS_SMSNOX_20195.*;
MAPEXCLUDE TNOXPASS_SMSNOX_20195.SN_TEMP*
MAPEXCLUDE TNOXPASS_SMSNOX_20195.SC_TEMP*
MAP TNOXPASS_SMSNOX_20195.*, TARGET TNOXPASS_SMSNOX_20195.*;
MAPEXCLUDE SNOXPASS_GWAY_00526.SN_TEMP*
MAPEXCLUDE SNOXPASS_GWAY_00526.SC_TEMP*
MAP SNOXPASS_GWAY_00526.*, TARGET SNOXPASS_GWAY_00526.*;
MAPEXCLUDE TNOXPASS_GWAY_00526.SN_TEMP*
MAPEXCLUDE TNOXPASS_GWAY_00526.SC_TEMP*
MAP TNOXPASS_GWAY_00526.*, TARGET TNOXPASS_GWAY_00526.*;
---------------------------------------------------------------------
-- NOTE: SC_TEMP and SN_TEMP s are not created in *SMSNOX* VBS

-- VBS for Release Date 23Jun2014
MAPEXCLUDE TNOXPASS_GWAY_013.SN_TEMP*
MAPEXCLUDE TNOXPASS_GWAY_013.SC_TEMP*
MAP TNOXPASS_GWAY_013.*, TARGET TNOXPASS_GWAY_013.*;

MAPEXCLUDE SNOXPASS_GWAY_013.SN_TEMP*
MAPEXCLUDE SNOXPASS_GWAY_013.SC_TEMP*
MAP SNOXPASS_GWAY_013.*, TARGET SNOXPASS_GWAY_013.*;

MAPEXCLUDE TNOXPASS_TFE_2017.SN_TEMP*
MAPEXCLUDE TNOXPASS_TFE_2017.SC_TEMP*
MAP TNOXPASS_TFE_2017.*, TARGET TNOXPASS_TFE_2017.*;

MAPEXCLUDE SNOXPASS_TFE_2017.SN_TEMP*
MAPEXCLUDE SNOXPASS_TFE_2017.SC_TEMP*
MAP SNOXPASS_TFE_2017.*, TARGET SNOXPASS_TFE_2017.*;

MAPEXCLUDE SNOXPASS_SMSNOX_307.SN_TEMP*
MAPEXCLUDE SNOXPASS_SMSNOX_307.SC_TEMP*
MAP SNOXPASS_SMSNOX_307.*, TARGET SNOXPASS_SMSNOX_307.*;

MAPEXCLUDE TNOXPASS_SMSNOX_307.SN_TEMP*
MAPEXCLUDE TNOXPASS_SMSNOX_307.SC_TEMP*
MAP TNOXPASS_SMSNOX_307.*, TARGET TNOXPASS_SMSNOX_307.*;

-- VBS for Release Date 08Sep2014
MAPEXCLUDE TRANSIT_FE_SNOX_314.SN_TEMP*
MAPEXCLUDE TRANSIT_FE_SNOX_314.SC_TEMP*
MAP TRANSIT_FE_SNOX_314.*, TARGET TRANSIT_FE_SNOX_314.*;

MAPEXCLUDE TRANSIT_FE_TNOX_314.SN_TEMP*
MAPEXCLUDE TRANSIT_FE_TNOX_314.SC_TEMP*
MAP TRANSIT_FE_TNOX_314.*, TARGET TRANSIT_FE_TNOX_314.*;

MAP TRANSIT_SMSNOX_TNOX_314.*, TARGET TRANSIT_SMSNOX_TNOX_314.*;
MAP TRANSIT_SMSNOX_SNOX_314.*, TARGET TRANSIT_SMSNOX_SNOX_314.*;

MAPEXCLUDE TRANSIT_GATEWAY_SNOX_314.SN_TEMP*
MAPEXCLUDE TRANSIT_GATEWAY_SNOX_314.SC_TEMP*
MAP TRANSIT_GATEWAY_SNOX_314.*, TARGET TRANSIT_GATEWAY_SNOX_314.*;

MAPEXCLUDE TRANSIT_GATEWAY_TNOX_314.SN_TEMP*
MAPEXCLUDE TRANSIT_GATEWAY_TNOX_314.SC_TEMP*
MAP TRANSIT_GATEWAY_TNOX_314.*, TARGET TRANSIT_GATEWAY_TNOX_314.*;

--SEQUENCE Schema
MAPEXCLUDE SEQUENCE_REPL.SN_TEMP*
MAPEXCLUDE SEQUENCE_REPL.SC_TEMP*
MAP SEQUENCE_REPL.*, TARGET SEQUENCE_REPL.*;


