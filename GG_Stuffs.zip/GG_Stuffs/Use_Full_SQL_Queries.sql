--- Final scripts for generating the script for Active-Active replications

-- Tables list with PK/UK Key Constraints, excluding the tables which has CLOB/BLOB data types columns
SELECT 'TABLE '||owner||'.'|| OBJECT_NAME||';' Extracts, 
	   'MAP '||owner||'.'||OBJECT_NAME||', TARGET '||owner||'.'||OBJECT_NAME||';' Replicators
FROM 
 (
    SELECT UNIQUE dtc.owner, dtc.OBJECT_NAME 
    FROM 
       (
          SELECT OWNER, OBJECT_NAME 
            FROM DBA_OBJECTS 
           WHERE OBJECT_NAME NOT IN (SELECT DISTINCT TABLE_NAME 
                                          FROM dba_tab_columns dtc 
                                         WHERE DATA_TYPE IN ('CLOB', 'BLOB', 'LONG', 'RAW') 
                                           AND OWNER IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS')) 
             AND OWNER IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS') 
             AND OBJECT_TYPE = 'TABLE'
       ) DTC, 
       (                                 
           -- Query to get PK constraint table 
          SELECT dc.OWNER, dc.TABLE_NAME
              FROM dba_constraints dc
             WHERE dc.owner IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
               AND dc.constraint_type = 'P'
             GROUP BY dc.owner, dc.table_name, CONSTRAINT_TYPE
             UNION ALL
            SELECT dc_otr.owner, dc_otr.table_name
              FROM dba_constraints dc_otr
             WHERE dc_otr.owner IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
               AND dc_otr.constraint_type = 'U'
               AND NOT EXISTS (SELECT 1 
                                 FROM dba_constraints dc_inr
                                WHERE dc_inr.owner = dc_otr.owner 
                                  AND dc_inr.table_name = dc_otr.table_name
                                  AND constraint_type='P')
             GROUP BY dc_otr.owner, dc_otr.table_name, CONSTRAINT_TYPE
       ) inri 
    WHERE dtc.owner = inri.owner 
     AND dtc.OBJECT_NAME = inri.TABLE_name 
     AND NOT (REGEXP_LIKE ( dtc.OBJECT_NAME, '\$|s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE|^TODROP_', 'i')) 
    ORDER BY owner DESC, OBJECT_NAME ASC
 );

-- Tables with CLOB/BLOB, but having pk/uk key contraints
SELECT  'TABLE '||owner||'.'|| OBJECT_NAME||';' Extracts, 
	    'MAP '||owner||'.'||OBJECT_NAME||', TARGET '||owner||'.'||OBJECT_NAME||';'Replicators
  FROM DBA_OBJECTS 
 WHERE OBJECT_NAME  IN (SELECT DISTINCT TABLE_NAME 
						  FROM dba_tab_columns dtc 
					     WHERE DATA_TYPE IN ('CLOB', 'BLOB', 'LONG', 'RAW') 
						   AND OWNER IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS')) 
   AND OWNER IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS') 
   AND OBJECT_TYPE = 'TABLE'
   AND (owner,object_name)  IN (
								 SELECT owner, table_name
								 FROM ( SELECT dc.OWNER, dc.TABLE_NAME
										  FROM dba_constraints dc
										 WHERE dc.owner IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
										   AND dc.constraint_type = 'P'
										 GROUP BY dc.owner, dc.table_name, CONSTRAINT_TYPE
										 UNION ALL
										SELECT dc_otr.owner, dc_otr.table_name
										  FROM dba_constraints dc_otr
										 WHERE dc_otr.owner IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
										   AND dc_otr.constraint_type = 'U'
										   AND NOT EXISTS (SELECT 1 
															 FROM dba_constraints dc_inr
															WHERE dc_inr.owner = dc_otr.owner 
															  AND dc_inr.table_name = dc_otr.table_name
															  AND constraint_type='P')
										 GROUP BY dc_otr.owner, dc_otr.table_name, CONSTRAINT_TYPE
									  ) 
							   )
  ORDER BY owner DESC, object_name ASC;

-- Tables list without PK/UK key constraint, which includes clob/blob tables also
SELECT 'TABLE '||owner||'.'|| TABLE_NAME||';'Extracts, 'MAP '||owner||'.'||TABLE_NAME||', TARGET '||owner||'.'||TABLE_NAME||';'Replicators
FROM 
 (
    SELECT dt.OWNER, dt.TABLE_NAME
      FROM DBA_TABLES dt, dba_objects doj
     WHERE  dt.owner = doj.owner AND dt.table_name = doj.object_name AND
       NOT EXISTS (SELECT  'TRUE'
                     FROM DBA_CONSTRAINTS dc
                     WHERE dc.TABLE_NAME = dt.TABLE_NAME
                       AND dc.owner = dt.owner
                       AND dc.CONSTRAINT_TYPE IN ('P','U'))
       AND dt.OWNER  IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
       AND NOT (REGEXP_LIKE (dt.TABLE_NAME,'\$|s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
       AND doj.object_type='TABLE'
     ORDER BY OWNER DESC, TABLE_NAME ASC
 )


SELECT 'TABLE '||owner||'.'|| TABLE_NAME||';'Extracts, 'MAP '||owner||'.'||table_name||', TARGET '||owner||'.'||table_name||';'Replicators
FROM dba_tables
WHERE owner LIKE '%3113' 
ORDER BY owner DESC, table_name ASC


SELECT 'TABLE '||owner||'.'|| TABLE_NAME||';'Extracts, 'MAP '||owner||'.'||table_name||', TARGET '||owner||'.'||table_name||';'Replicators
FROM dba_tables
WHERE owner IN  ('SNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20195','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526')
ORDER BY owner DESC, table_name ASC

-------------------------------------------------------------------------------------------------------------------
-- For Production DBs and with CDR Params

MAP rahulc, TARGET rahulc, 
 COMPARECOLS (ON UPDATE ALL), 
  RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, IGNORE)), 
  RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, DISCARD));
  
-- Tables list with PK/UK Key Constraints, excluding the tables which has CLOB/BLOB data types columns
SELECT OWNER, OBJECT_NAME,
       'TABLE '||OWNER||'.'||OBJECT_NAME ||', GETBEFORECOLS(ON UPDATE ALL, ON DELETE ALL);' Extract_Params,
       'MAP '||OWNER||'.'||OBJECT_NAME ||', TARGET '||OWNER||'.'||OBJECT_NAME ||', COMPARECOLS (ON UPDATE ALL, ON DELETE ALL), '||CHR(13)||
       ' RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, IGNORE)), '||CHR(13)||
       ' RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, IGNORE)), RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, OVERWRITE)), '||CHR(13)||
       ' RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, IGNORE)), RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, DISCARD));'  TrustedSource_REPL,
       'MAP '||owner||'.'||OBJECT_NAME||', TARGET '||owner||'.'||OBJECT_NAME||';' NonTrustedSource_REPL           
FROM 
 (
    SELECT UNIQUE dtc.owner, dtc.OBJECT_NAME 
    FROM 
       (
          SELECT OWNER, OBJECT_NAME 
            FROM DBA_OBJECTS 
           WHERE OBJECT_NAME NOT IN (SELECT DISTINCT TABLE_NAME 
                                          FROM dba_tab_columns dtc 
                                         WHERE DATA_TYPE IN ('CLOB', 'BLOB', 'LONG', 'RAW') 
                                           AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX')) 
             AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX') 
             AND OBJECT_TYPE = 'TABLE'
       ) DTC, 
       (                                 
           -- Query to get PK constraint table 
          SELECT dc.OWNER, dc.TABLE_NAME
              FROM dba_constraints dc
             WHERE dc.owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
               AND dc.constraint_type = 'P'
             GROUP BY dc.owner, dc.table_name, CONSTRAINT_TYPE
             UNION ALL
            SELECT dc_otr.owner, dc_otr.table_name
              FROM dba_constraints dc_otr
             WHERE dc_otr.owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
               AND dc_otr.constraint_type = 'U'
               AND NOT EXISTS (SELECT 1 
                                 FROM dba_constraints dc_inr
                                WHERE dc_inr.owner = dc_otr.owner 
                                  AND dc_inr.table_name = dc_otr.table_name
                                  AND constraint_type='P')
             GROUP BY dc_otr.owner, dc_otr.table_name, CONSTRAINT_TYPE
       ) inri 
    WHERE dtc.owner = inri.owner 
     AND dtc.OBJECT_NAME = inri.TABLE_name 
     AND NOT (REGEXP_LIKE ( dtc.OBJECT_NAME, '\$|s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE|^TODROP_', 'i')) 
    ORDER BY owner DESC, OBJECT_NAME ASC
 );

-- Tables with CLOB/BLOB, but having pk/uk key contraints
SELECT  OWNER, OBJECT_NAME,
        'TABLE '||owner||'.'|| OBJECT_NAME||';' Extracts, 
        'MAP '||owner||'.'||OBJECT_NAME||', TARGET '||owner||'.'||OBJECT_NAME||';' Replicators
  FROM DBA_OBJECTS 
 WHERE OBJECT_NAME  IN (SELECT DISTINCT TABLE_NAME 
                          FROM dba_tab_columns dtc 
                         WHERE DATA_TYPE IN ('CLOB', 'BLOB', 'LONG', 'RAW') 
                           AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX')) 
   AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX') 
   AND OBJECT_TYPE = 'TABLE'
   AND (owner,object_name)  IN (
                                 SELECT owner, table_name
                                 FROM ( SELECT dc.OWNER, dc.TABLE_NAME
                                          FROM dba_constraints dc
                                         WHERE dc.owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
                                           AND dc.constraint_type = 'P'
                                         GROUP BY dc.owner, dc.table_name, CONSTRAINT_TYPE
                                         UNION ALL
                                        SELECT dc_otr.owner, dc_otr.table_name
                                          FROM dba_constraints dc_otr
                                         WHERE dc_otr.owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
                                           AND dc_otr.constraint_type = 'U'
                                           AND NOT EXISTS (SELECT 1 
                                                             FROM dba_constraints dc_inr
                                                            WHERE dc_inr.owner = dc_otr.owner 
                                                              AND dc_inr.table_name = dc_otr.table_name
                                                              AND constraint_type='P')
                                         GROUP BY dc_otr.owner, dc_otr.table_name, CONSTRAINT_TYPE
                                      ) 
                               )
  ORDER BY owner DESC, object_name ASC;

-- Tables list without PK/UK key constraint, which includes clob/blob tables also
SELECT OWNER, TABLE_NAME,
        'TABLE '||owner||'.'|| TABLE_NAME||';'Extracts, 
        'MAP '||owner||'.'||TABLE_NAME||', TARGET '||owner||'.'||TABLE_NAME||';'Replicators
FROM 
 (
    SELECT dt.OWNER, dt.TABLE_NAME
      FROM DBA_TABLES dt, dba_objects doj
     WHERE  dt.owner = doj.owner AND dt.table_name = doj.object_name AND
       NOT EXISTS (SELECT  'TRUE'
                     FROM DBA_CONSTRAINTS dc
                     WHERE dc.TABLE_NAME = dt.TABLE_NAME
                       AND dc.owner = dt.owner
                       AND dc.CONSTRAINT_TYPE IN ('P','U'))
       AND dt.OWNER  IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
       AND NOT (REGEXP_LIKE (dt.TABLE_NAME,'\$|s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
       AND doj.object_type='TABLE'
     ORDER BY OWNER DESC, TABLE_NAME ASC
 )


SELECT 'TABLE '||owner||'.'|| TABLE_NAME||';'Extracts, 'MAP '||owner||'.'||table_name||', TARGET '||owner||'.'||table_name||';'Replicators
FROM dba_tables
WHERE owner LIKE '%3113' 
ORDER BY owner DESC, table_name ASC


SELECT 'TABLE '||owner||'.'|| TABLE_NAME||';'Extracts, 'MAP '||owner||'.'||table_name||', TARGET '||owner||'.'||table_name||';'Replicators
FROM dba_tables
WHERE owner IN  ('SNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20195','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526')
ORDER BY owner DESC, table_name ASC


-------------------------------------------------------------------------------------------------------------------

-- Below Query gives the detail about the tables 
  SELECT DCL.OWNER "Owner",
         dcl.table_name " Table Name ",
         dcmt.COMMENTS "Table Description",
         DCL.COLUMN_ID "Sr. No.",
         INITCAP (REPLACE (dcl.column_name, '_', ' ')) "Entity Name",
         DECODE (DCL.DATA_TYPE,
                 'NUMBER', INITCAP ('NUMERIC'),
                 'VARCHAR2', INITCAP ('Character'),
                 'DATE', INITCAP ('Date'),
                 'TIMESTAMP(6)', 'TIMESTAMP',
                 'CLOB', 'CLOB',
                 'BLOB', 'BLOB')
            "Domain",
         INITCAP (DCMNT.COMMENTS) "Description",
         DCL.COLUMN_NAME "Column Name",
         DCL.DATA_TYPE "Data Type",
         --  DECODE(DCL.DATA_TYPE,'DATE',NULL, 'TIMESTAMP(6)',NULL,DECODE ( DCL.DATA_LENGTH, 22, NULL, DCL.DATA_LENGTH) )"Size",
         CASE
            WHEN DCL.DATA_TYPE IN ('DATE', 'TIMESTAMP(6)')
            THEN
               NULL
            WHEN     DCL.DATA_TYPE = 'NUMBER'
                 AND (DCL.DATA_PRECISION IS NOT NULL AND DCL.DATA_SCALE = 0)
            THEN
               TO_CHAR (DCL.DATA_PRECISION)
            WHEN     DCL.DATA_TYPE = 'NUMBER'
                 AND (    DCL.DATA_PRECISION IS NOT NULL
                      AND DCL.DATA_SCALE IS NOT NULL)
            THEN
               TO_CHAR (DCL.DATA_PRECISION || ',' || DCL.DATA_SCALE)
            WHEN DCL.DATA_TYPE = 'VARCHAR2'
            THEN
               TO_CHAR (DCL.DATA_LENGTH)
         END
            "Size",
         DCL.NULLABLE "Nullable",
         DECODE (
            (SELECT DECODE (DTL.CONSTRAINT_TYPE, 'P', 'Y', 'N')
               FROM DBA_cons_columns cns, dba_constraints dtl
              WHERE     cns.owner = dtl.owner
                    AND CNS.TABLE_NAME = DTL.TABLE_NAME
                    AND CNS.COLUMN_NAME = DCL.COLUMN_NAME
                    AND CNS.CONSTRAINT_NAME = DTL.CONSTRAINT_NAME
                    AND DTL.CONSTRAINT_TYPE = 'P'
                    AND cns.owner = DCL.OWNER
                    AND cns.table_name = DCL.TABLE_NAME),
            'Y', 'Y',
            NULL, 'N')
            "Primary Key",
         DECODE (
            (SELECT DECODE (DTL.CONSTRAINT_TYPE, 'U', 'Y', 'N')
               FROM DBA_cons_columns cns, dba_constraints dtl
              WHERE     cns.owner = dtl.owner
                    AND CNS.TABLE_NAME = DTL.TABLE_NAME
                    AND CNS.COLUMN_NAME = DCL.COLUMN_NAME
                    AND CNS.CONSTRAINT_NAME = DTL.CONSTRAINT_NAME
                    AND DTL.CONSTRAINT_TYPE = 'U'
                    AND cns.owner = DCL.OWNER
                    AND cns.table_name = DCL.TABLE_NAME),
            'Y', 'Y',
            NULL, 'N')
            "Unique Key",
         DECODE (
            (SELECT DISTINCT DECODE (cns.column_name, NULL, 'N', 'Y')
               FROM DBA_cons_columns cns,
                    dba_constraints dtl,
                    dba_tab_columns dcll
              WHERE     (    cns.owner = dcll.owner
                         AND cns.owner = dtl.owner
                         AND dcll.owner = dtl.owner)
                    AND (    cns.table_name = dcll.table_name
                         AND cns.table_name = dtl.table_name
                         AND dcll.table_name = dtl.table_name)
                    AND cns.column_name = dcll.column_name
                    AND cns.column_name = dcl.column_name
                    AND cns.constraint_name = dtl.constraint_name
                    AND dtl.constraint_type = 'R'
                    AND dtl.table_name = dcl.table_name
                    AND dtl.OWNER = dcl.owner),
            'Y', 'Y',
            NULL, 'N')
            "Foreign Key",
         (  SELECT DISTINCT
                   LISTAGG (cfk.table_name, ' , ')
                      WITHIN GROUP (ORDER BY cfk.table_name)
              FROM dba_constraints dc, dba_cons_columns cpk, dba_cons_columns cfk
             WHERE     dc.owner = cpk.owner
                   AND dc.r_owner = cfk.owner
                   AND dc.constraint_name = cpk.constraint_name
                   AND dc.r_constraint_name = cfk.constraint_name
                   AND cpk.position = cfk.position
                   AND dc.owner = dcl.owner
                   --AND     cfk.owner = dcl.owner
                   AND dc.table_name = dcl.table_name
                   AND cpk.column_name = dcl.column_name
          GROUP BY dc.owner)
            AS "Ref Table",
         (  SELECT DISTINCT
                   LISTAGG (cfk.column_name, ' , ')
                      WITHIN GROUP (ORDER BY cfk.table_name)
              FROM dba_constraints dc, dba_cons_columns cpk, dba_cons_columns cfk
             WHERE     dc.owner = cpk.owner
                   AND dc.r_owner = cfk.owner
                   AND dc.constraint_name = cpk.constraint_name
                   AND dc.r_constraint_name = cfk.constraint_name
                   AND cpk.position = cfk.position
                   AND dc.owner = dcl.owner
                   AND dc.table_name = dcl.table_name
                   AND cpk.column_name = dcl.column_name
          GROUP BY dc.owner, cfk.table_name, cpk.column_name)
            AS "Ref Column"
    FROM dba_tab_columns dcl, dba_col_comments dcmnt, dba_tab_comments dcmt
   WHERE     dcl.owner = dcmnt.owner
         AND dcl.table_name = dcmnt.table_name
         AND dcl.column_name = dcmnt.column_name
         AND dcl.owner = dcmt.owner
         AND dcl.table_name = dcmt.table_name
        -- AND (dcmnt.comments IS NOT NULL OR dcmt.comments IS NOT NULL)
         AND DCL.OWNER = 'TRANSNOX_CPASS'
    AND dcl.table_name = 'TRANS_RESPONSE_INFO'
ORDER BY dcl.table_name, dcl.column_id;
-------------------------------------------------------------------------------------------------------------------

-- ASH related quries to check what was happend in given time frame
SELECT
  h.event "Wait Event",
  SUM(h.wait_time + h.time_waited) "Total Wait Time"
FROM
  v$active_session_history h,
  v$event_name E
WHERE
      h.sample_time BETWEEN TO_DATE('01/03/2016 18:00:00','mm/dd/yyyy hh24:mi:ss')
                      AND TO_DATE('01/03/2016 21:00:00','mm/dd/yyyy hh24:mi:ss')
  AND h.event_id = E.event_id
  AND E.wait_class <> 'Idle'
GROUP BY h.event
ORDER BY 2 DESC

SELECT username, COUNT(*)
FROM (
SELECT sample_time, session_id, session_type,sql_id, sql_opname, wait_time, time_waited,session_state,blocking_session_status,machine,du.username username
FROM v$active_session_history ash, dba_users du
WHERE ash.user_id = du.user_id
  AND sample_time BETWEEN TO_DATE('01/03/2016 18:00:00','mm/dd/yyyy hh24:mi:ss')
                      AND TO_DATE('01/03/2016 21:00:00','mm/dd/yyyy hh24:mi:ss')
)
GROUP BY username
ORDER BY 2 DESC

SELECT COUNT(DISTINCT session_id)
FROM v$active_session_history
WHERE SAMPLE_TIME BETWEEN TO_DATE('01/03/2016 18:00:00','mm/dd/yyyy hh24:mi:ss')
                      AND TO_DATE('01/03/2016 21:00:00','mm/dd/yyyy hh24:mi:ss')
-------------------------------------------------------------------------------------------------------------------



-- even and odd scripts
  SELECT sequence_owner,
         sequence_name,
         increment_by,
         cache_size,
         last_number,
         DECODE(MOD (last_number, 2),0,'Even',1,'Odd') Even_Or_Odd,
         CASE
            WHEN MOD (last_number, 2) = 1 THEN last_number + 10001
            WHEN MOD (last_number, 2) = 0 THEN last_number + 10000
            ELSE last_number
         END
            final_even_or_odd_no,
         CASE
            WHEN MOD (last_number, 2) = 1 THEN 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 5001 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' || chr(10) 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;'
            WHEN MOD (last_number, 2) = 0 THEN 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 5000 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' || chr(10) 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;'
            ELSE TO_CHAR (last_number)
         END first_even_time_increment,
         CASE
            WHEN MOD (last_number, 2) = 1 THEN 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 5000 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' || chr(10) 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;'
            WHEN MOD (last_number, 2) = 0 THEN 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 5001 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' || chr(10) 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;'
            ELSE TO_CHAR (last_number)
         END first_odd_time_increment,
            'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' final_even_run
    FROM dba_sequences
   WHERE sequence_owner IN  ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS', 'WEBFORT','KEYNOX_FX')
   AND MOD (last_number, 2) =0
ORDER BY sequence_owner ASC
-------------------------------------------------------------------------------------------------------------------


SELECT dt.OWNER, dt.TABLE_NAME
FROM DBA_TABLES dt, dba_objects doj
WHERE  dt.owner = doj.owner AND dt.table_name = doj.object_name AND
  NOT EXISTS (SELECT  'TRUE'
                  FROM DBA_CONSTRAINTS dc
                  WHERE dc.TABLE_NAME = dt.TABLE_NAME
                    AND dc.CONSTRAINT_TYPE='P')
  AND dt.OWNER  IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
  AND NOT (REGEXP_LIKE (dt.TABLE_NAME,'\$|s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
  AND doj.object_type='TABLE'
ORDER BY OWNER, TABLE_NAME ASC  


-- Table Name without CLOB and BLOB Data Typies
SELECT 'TABLE '||OWNER||'.'||TABLE_NAME ||', GETBEFORECOLS(ON UPDATE ALL, ON DELETE ALL);' TABLE_NAME
FROM
(
    SELECT UNIQUE dtc.owner, dtc.table_name
      FROM dba_tab_columns dtc, dba_objects doj
     WHERE dtc.owner = doj.owner AND dtc.table_name = doj.object_name AND doj.object_type='TABLE'
       AND dtc.owner = 'SNOX4TRANSNOX_CPASS'
       AND  dtc.DATA_TYPE NOT IN ('CLOB','BLOB','LONG','RAW')
)
WHERE NOT (REGEXP_LIKE (table_name,'s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
--  AND TABLE_NAME IN (SELECT OBJECT_NAME FROM dba_objects doj WHERE OWNER='SNOX4TRANSNOX_CPASS' AND OBJECT_TYPE='TABLE')
    AND table_name IN ('BACKEND_CONNECTIONS_LT','CLIENT','COMPARE_DATA_LOOKUP','DEVICE_PROCESSOR_INFO_HIST','ENCRYPTED_HOST_DATA','EVENT','EVENT_MACHINE_AVAILABLITY','INFONOX_SERVICE_USAGE','LOOKUP_MERCHANT_ACCESS_PROFILE','LOOKUP_MER_BUSINESS_TYPE_MONI','LOOKUP_SIC_CODES','LOOKUP_TAX_CATEGORY','MERCHANT_DATA_TSPG','MERCHANT_PROCESSOR_INFO','MERCHANT_PROCESSOR_INFO_HIST','MERCHANT_PRODUCT_HIST','MERCHANT_PRODUCT_TAX_MAP','MERCHANT_SEARCH_XML_RESPONSE','MER_CUSTOM_PRODUCT_DETAILS_HIS','MNOX_GLUON_ALERT_EVENTS','PROCESSOR_SYNC_STATUS','PROCESSOR_SYNC_STATUS_LT','RELEASE_HISTORY','REPLICATION_DATA','REQUESTVALIDATION','SNOX_POSTOFFICE_IDM_STATUS','SNOX_REPORT_USAGE','SNOX_SCHEDULER_HISTORY','SN_FEEDBACK','SS_RULE_CATEGORY_LOOKUP','SS_RULE_OBJECT_FUNCTION_LOOKUP','SS_RULE_OBJECT_TYPE_LOOKUP','USER_AUDIT_DETAIL')
-- AND TABLE_NAME IN ('ATNT_RESPONSE_DTL','ATNT_RESPONSE_DTL_AUDIT','BATCH_JOB_EXECUTION_PARAMS','CAPTURE_DEVICE_PROGRESS_STAG','CAPTURE_LINE_DETAILS_STAG','CARD_BIN_LOOKUP','CHAINED_ROWS','CLOB_DATA','COMPARE_DATA_LOOKUP','CONFIRMATION_DATA','CONFIRMATION_FILE_DATA','COUNTRY_CURRENCY_INFO','CPASS_BILLING_FILE_CONFIG_T','CPASS_BILLING_FILE_DATA','CUSTOMER_COMPANY','CUST_ADDRESS_HISTORY','CUST_BANK_ACCOUNT_HIST','CUST_CARD_ACCOUNT_HIST','CUST_COMPLIANCE_INFO_HISTORY','DASH_DATA','DATA_LOAD_ERROR_TRACE','DR_BATCH_MERCHANTS','DR_BATCH_MERCHANT_HISTORY','DR_CAT_CARD_ENCRYPTION','DR_ICOM_SETTELMENT_FILEDATA','DR_TAS_SETTLEMENT_HISTORY','FEE_TABLE','FILE_PROCESS_HISTORY','GENERIC_REPORT_QUERY_TEST','HARMONY_SETLMNT_TRANS_DET_HIST','HARMONY_SETTLEMENT_LINE_DET','HARMONY_SETTLEMENT_TAD_DET','INSTITUTION_ROUTING_NUM_HIST ','INSTITUTION_ROUTING_NUM_MASTER','INSTITUTION_ROUTING_NUM_TEMP','LOG_EXECUTION_TIME','LOOKUP_COMPLIANCE','LOOKUP_COMPLIANCE_CATEGORY','LOOKUP_COMPLIANCE_LEVEL','LOOKUP_EMAIL_DOMAIN','LOOKUP_ISSUER','LOOKUP_LANGUGE','LOOKUP_MC_BIN_RANGE','LOOKUP_PAYMENT_TYPE','LOOKUP_PHONE_COUNTRY','LOOKUP_POST_TYPE','LOOKUP_PROCESSOR','LOOKUP_RULES','LOOKUP_SIC','LOOKUP_TRANS_REQMNT_CATEGORY','LOOKUP_TRANS_STATUS','LOOKUP_TRAN_STATE','LOOKUP_VISA_BIN_RANGE','MERCHANT_BATCHCLOSE_METADATA','MERCHANT_CURRENT_BALANCE','MERCHANT_CURRENT_BALANCE_LOG','MERCHANT_QUERY_FILTER','MER_ACCT_ROUTING_LOOKUP_HIST','MER_BATCHCLOSE_METADATA_HIST','MILIND_KPASS_SSN','MQ_COMPANY_INFO','MQ_CONSUMER_SCRATCHPAD','PROCESSOR_SYNC_STATUS','QUERY','RECURRING_SCRAPPED_ROWS','RECURRING_SCRATCHPAD_TMP','RECURRING_UPLOAD_SUMMARY','RELEASE_HISTORY','SETTLEMENT_ELIGIBLE_DEVICES','SETTLEMENT_MERCHANT_LIST_STAG','SETTLE_DEBUG','SETTLE_LOCK_LOG','TASK_TIME_LOG','TRANS_ADDITIONAL_AMOUNT_TYPE','TRANS_BILL_PAY_HISTORY','TRANS_PRODUCT_INFO_HIST','TRANS_SCORE')
ORDER BY table_name ASC

-- Table Name with CLOB and BLOB Data Typies
SELECT UNIQUE 'TABLE '||dtc.OWNER||'.'||dtc.TABLE_NAME ||';' TABLE_NAME
  FROM dba_tab_columns dtc, dba_objects doj
 WHERE dtc.owner = doj.owner AND dtc.table_name = doj.object_name AND doj.object_type='TABLE'
   AND dtc.owner = 'SNOX4TRANSNOX_CPASS'
   AND  dtc.DATA_TYPE  IN ('CLOB','BLOB','LONG','RAW')
   AND NOT (REGEXP_LIKE (dtc.table_name,'s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
--   AND TABLE_NAME IN (SELECT OBJECT_NAME FROM dba_objects doj WHERE OWNER='SNOX4TRANSNOX_CPASS' AND OBJECT_TYPE='TABLE')
  AND dtc.table_name IN ('BACKEND_CONNECTIONS_LT','CLIENT','COMPARE_DATA_LOOKUP','DEVICE_PROCESSOR_INFO_HIST','ENCRYPTED_HOST_DATA','EVENT','EVENT_MACHINE_AVAILABLITY','INFONOX_SERVICE_USAGE','LOOKUP_MERCHANT_ACCESS_PROFILE','LOOKUP_MER_BUSINESS_TYPE_MONI','LOOKUP_SIC_CODES','LOOKUP_TAX_CATEGORY','MERCHANT_DATA_TSPG','MERCHANT_PROCESSOR_INFO','MERCHANT_PROCESSOR_INFO_HIST','MERCHANT_PRODUCT_HIST','MERCHANT_PRODUCT_TAX_MAP','MERCHANT_SEARCH_XML_RESPONSE','MER_CUSTOM_PRODUCT_DETAILS_HIS','MNOX_GLUON_ALERT_EVENTS','PROCESSOR_SYNC_STATUS','PROCESSOR_SYNC_STATUS_LT','RELEASE_HISTORY','REPLICATION_DATA','REQUESTVALIDATION','SNOX_POSTOFFICE_IDM_STATUS','SNOX_REPORT_USAGE','SNOX_SCHEDULER_HISTORY','SN_FEEDBACK','SS_RULE_CATEGORY_LOOKUP','SS_RULE_OBJECT_FUNCTION_LOOKUP','SS_RULE_OBJECT_TYPE_LOOKUP','USER_AUDIT_DETAIL')
ORDER BY TABLE_NAME ASC;

-- Replicat Process

-- Queries for Replicat process
-- Table Name without CLOB and BLOB Data Typies
SELECT 'MAP '||OWNER||'.'||TABLE_NAME ||', TARGET '||OWNER||'.'||TABLE_NAME ||','||CHR(13)||
       ' COMPARECOLS (ON UPDATE ALL, ON DELETE ALL), '||CHR(13)||
       '  RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, IGNORE)), '||CHR(13)||
       '  RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, IGNORE)), '||CHR(13)||
       '  RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, OVERWRITE)), '||CHR(13)||
       '  RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, IGNORE)), '||CHR(13)||
       '  RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, DISCARD));' TABLE_NAME
FROM
(
    SELECT UNIQUE dtc.owner, dtc.table_name
      FROM dba_tab_columns dtc, dba_objects doj
     WHERE dtc.owner = doj.owner AND dtc.table_name = doj.object_name AND doj.object_type='TABLE'
       AND dtc.owner = 'TRANSNOX_CPASS'
       AND  dtc.DATA_TYPE NOT IN ('CLOB','BLOB','LONG','RAW')
)
WHERE --NOT (REGEXP_LIKE (table_name,'s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i')) AND
----    table_name NOT IN ('BACKEND_CONNECTIONS_LT','CLIENT','COMPARE_DATA_LOOKUP','DEVICE_PROCESSOR_INFO_HIST','DR_HISTORY_VITAL_SETTLEMENT','DR_SETTLEMENT_DATA','ENCRYPTED_HOST_DATA','EVENT','EVENT_MACHINE_AVAILABLITY','INFONOX_SERVICE_USAGE','LOOKUP_MERCHANT_ACCESS_PROFILE','LOOKUP_MER_BUSINESS_TYPE_MONI','LOOKUP_SIC_CODES','LOOKUP_TAX_CATEGORY','MERCHANT_DATA_TSPG','MERCHANT_PROCESSOR_INFO','MERCHANT_PROCESSOR_INFO_HIST','MERCHANT_PRODUCT_HIST','MERCHANT_PRODUCT_TAX_MAP','MERCHANT_SEARCH_XML_RESPONSE','MER_CUSTOM_PRODUCT_DETAILS_HIS','MNOX_GLUON_ALERT_EVENTS','PROCESSOR_SYNC_STATUS','PROCESSOR_SYN_CSTATUS_LT','RELEASE_HISTORY','REPLICATION_DATA','REQUESTVALIDATION','SNOX_POSTOFFICE_IDM_STATUS','SNOX_REPORT_USAGE','SNOX_SCHEDULER_HISTORY','SN_FEEDBACK','SS_RULE_CATEGORY_LOOKUP','SS_RULE_OBJECT_FUNCTION_LOOKUP','SS_RULE_OBJECT_TYPE_LOOKUP','USER_AUDIT_DETAIL')
    table_name NOT IN ('ATNT_RESPONSE_DTL','ATNT_RESPONSE_DTL_AUDIT','BATCH_JOB_EXECUTION_PARAMS','CARD_BIN_LOOKUP','CHAINED_ROWS','CLOB_DATA','COMPARE_DATA_LOOKUP','CONFIRMATION_DATA','CONFIRMATION_FILE_DATA','COUNTRY_CURRENCY_INFO','CPASS_BILLING_FILE_DATA','CUSTOMER_COMPANY','CUST_ADDRESS_HISTORY','CUST_BANK_ACCOUNT_HIST','CUST_CARD_ACCOUNT_HIST','CUST_COMPLIANCE_INFO_HISTORY','DASH_DATA','DATA_LOAD_ERROR_TRACE','FEE_TABLE','FILE_PROCESS_HISTORY','GENERIC_REPORT_QUERY_TEST','HARMONY_SETLMNT_TRANS_DET_HIST','HARMONY_SETTLEMENT_LINE_DET','HARMONY_SETTLEMENT_TAD_DET','INSTITUTION_ROUTING_NUM_HIST ','INSTITUTION_ROUTING_NUM_MASTER','INSTITUTION_ROUTING_NUM_TEMP','LOG_EXECUTION_TIME','LOOKUP_COMPLIANCE','LOOKUP_COMPLIANCE_CATEGORY','LOOKUP_COMPLIANCE_LEVEL','LOOKUP_EMAIL_DOMAIN','LOOKUP_ISSUER','LOOKUP_LANGUGE','LOOKUP_MC_BIN_RANGE','LOOKUP_PAYMENT_TYPE','LOOKUP_PHONE_COUNTRY','LOOKUP_POST_TYPE','LOOKUP_PROCESSOR','LOOKUP_RULES','LOOKUP_SIC','LOOKUP_TRANS_REQMNT_CATEGORY','LOOKUP_TRANS_STATUS','LOOKUP_TRAN_STATE','LOOKUP_VISA_BIN_RANGE','MERCHANT_BATCHCLOSE_METADATA','MERCHANT_CURRENT_BALANCE','MERCHANT_CURRENT_BALANCE_LOG','MERCHANT_QUERY_FILTER','MER_ACCT_ROUTING_LOOKUP_HIST','MER_BATCHCLOSE_METADATA_HIST','MQ_COMPANY_INFO','MQ_CONSUMER_SCRATCHPAD','PROCESSOR_SYNC_STATUS','QUERY','RECURRING_SCRAPPED_ROWS','RECURRING_UPLOAD_SUMMARY','RELEASE_HISTORY','SETTLEMENT_ELIGIBLE_DEVICES','SETTLE_DEBUG','SETTLE_LOCK_LOG','TASK_TIME_LOG','TRANS_ADDITIONAL_AMOUNT_TYPE','TRANS_BILL_PAY_HISTORY','TRANS_PRODUCT_INFO_HIST','TRANS_SCORE')
ORDER BY table_name ASC;

-- Table Name with CLOB and BLOB Data Typies
SELECT UNIQUE 'MAP '||dtc.OWNER||'.'||dtc.TABLE_NAME ||', TARGET '||dtc.OWNER||'.'||dtc.TABLE_NAME ||';' TABLE_NAME
  FROM dba_tab_columns dtc, dba_objects doj
 WHERE dtc.owner = doj.owner AND dtc.table_name = doj.object_name AND doj.object_type='TABLE'
   AND dtc.owner = 'TRANSNOX_CPASS'
   AND dtc.DATA_TYPE IN ('CLOB','BLOB')
   AND NOT (REGEXP_LIKE (dtc.TABLE_NAME,'s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
--   AND TABLE_NAME NOT IN ('BACKEND_CONNECTIONS_LT','CLIENT','COMPARE_DATA_LOOKUP','DEVICE_PROCESSOR_INFO_HIST','DR_HISTORY_VITAL_SETTLEMENT','DR_SETTLEMENT_DATA','ENCRYPTED_HOST_DATA','EVENT','EVENT_MACHINE_AVAILABLITY','INFONOX_SERVICE_USAGE','LOOKUP_MERCHANT_ACCESS_PROFILE','LOOKUP_MER_BUSINESS_TYPE_MONI','LOOKUP_SIC_CODES','LOOKUP_TAX_CATEGORY','MERCHANT_DATA_TSPG','MERCHANT_PROCESSOR_INFO','MERCHANT_PROCESSOR_INFO_HIST','MERCHANT_PRODUCT_HIST','MERCHANT_PRODUCT_TAX_MAP','MERCHANT_SEARCH_XML_RESPONSE','MER_CUSTOM_PRODUCT_DETAILS_HIS','MNOX_GLUON_ALERT_EVENTS','PROCESSOR_SYNC_STATUS','PROCESSOR_SYN_CSTATUS_LT','RELEASE_HISTORY','REPLICATION_DATA','REQUESTVALIDATION','SNOX_POSTOFFICE_IDM_STATUS','SNOX_REPORT_USAGE','SNOX_SCHEDULER_HISTORY','SN_FEEDBACK','SS_RULE_CATEGORY_LOOKUP','SS_RULE_OBJECT_FUNCTION_LOOKUP','SS_RULE_OBJECT_TYPE_LOOKUP','USER_AUDIT_DETAIL')
   AND TABLE_NAME NOT IN ('ATNT_RESPONSE_DTL','ATNT_RESPONSE_DTL_AUDIT','BATCH_JOB_EXECUTION_PARAMS','CARD_BIN_LOOKUP','CHAINED_ROWS','CLOB_DATA','COMPARE_DATA_LOOKUP','CONFIRMATION_DATA','CONFIRMATION_FILE_DATA','COUNTRY_CURRENCY_INFO','CPASS_BILLING_FILE_DATA','CUSTOMER_COMPANY','CUST_ADDRESS_HISTORY','CUST_BANK_ACCOUNT_HIST','CUST_CARD_ACCOUNT_HIST','CUST_COMPLIANCE_INFO_HISTORY','DASH_DATA','DATA_LOAD_ERROR_TRACE','FEE_TABLE','FILE_PROCESS_HISTORY','GENERIC_REPORT_QUERY_TEST','HARMONY_SETLMNT_TRANS_DET_HIST','HARMONY_SETTLEMENT_LINE_DET','HARMONY_SETTLEMENT_TAD_DET','INSTITUTION_ROUTING_NUM_HIST ','INSTITUTION_ROUTING_NUM_MASTER','INSTITUTION_ROUTING_NUM_TEMP','LOG_EXECUTION_TIME','LOOKUP_COMPLIANCE','LOOKUP_COMPLIANCE_CATEGORY','LOOKUP_COMPLIANCE_LEVEL','LOOKUP_EMAIL_DOMAIN','LOOKUP_ISSUER','LOOKUP_LANGUGE','LOOKUP_MC_BIN_RANGE','LOOKUP_PAYMENT_TYPE','LOOKUP_PHONE_COUNTRY','LOOKUP_POST_TYPE','LOOKUP_PROCESSOR','LOOKUP_RULES','LOOKUP_SIC','LOOKUP_TRANS_REQMNT_CATEGORY','LOOKUP_TRANS_STATUS','LOOKUP_TRAN_STATE','LOOKUP_VISA_BIN_RANGE','MERCHANT_BATCHCLOSE_METADATA','MERCHANT_CURRENT_BALANCE','MERCHANT_CURRENT_BALANCE_LOG','MERCHANT_QUERY_FILTER','MER_ACCT_ROUTING_LOOKUP_HIST','MER_BATCHCLOSE_METADATA_HIST','MQ_COMPANY_INFO','MQ_CONSUMER_SCRATCHPAD','PROCESSOR_SYNC_STATUS','QUERY','RECURRING_SCRAPPED_ROWS','RECURRING_UPLOAD_SUMMARY','RELEASE_HISTORY','SETTLEMENT_ELIGIBLE_DEVICES','SETTLE_DEBUG','SETTLE_LOCK_LOG','TASK_TIME_LOG','TRANS_ADDITIONAL_AMOUNT_TYPE','TRANS_BILL_PAY_HISTORY','TRANS_PRODUCT_INFO_HIST','TRANS_SCORE')
ORDER BY TABLE_NAME ASC;


-- cursors are running 
  SELECT A.VALUE, S.USERNAME, S.SID, S.SERIAL#
  FROM V$SESSTAT A, V$STATNAME B, V$SESSION S
  WHERE A.STATISTIC# = B.STATISTIC#  
    AND S.SID=A.SID
    AND B.NAME = 'opened cursors current' 
    AND USERNAME = 'VELU';

--------------------------------------------------------------------------------------------------------------------------------

-- PK/UK Table List (FInal Query)
-- List of tables, which are having PK/UK key constraints and 
-- exclude those are having LOBs columns
SELECT UNIQUE dtc.owner, dtc.OBJECT_NAME 
FROM 
   (
      SELECT OWNER, OBJECT_NAME 
        FROM DBA_OBJECTS 
       WHERE OBJECT_NAME NOT IN (SELECT DISTINCT TABLE_NAME 
                                      FROM dba_tab_columns dtc 
                                     WHERE DATA_TYPE IN ('CLOB', 'BLOB', 'LONG', 'RAW') 
                                       AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX')) 
         AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX') 
         AND OBJECT_TYPE = 'TABLE'
   ) DTC, 
   (                                 
       -- Query to get PK constraint table 
      SELECT dc.OWNER, dc.TABLE_NAME
          FROM dba_constraints dc
         WHERE dc.owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
           AND dc.constraint_type = 'P'
         GROUP BY dc.owner, dc.table_name, CONSTRAINT_TYPE
         UNION ALL
        SELECT dc_otr.owner, dc_otr.table_name
          FROM dba_constraints dc_otr
         WHERE dc_otr.owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
           AND dc_otr.constraint_type = 'U'
           AND NOT EXISTS (SELECT 1 
                             FROM dba_constraints dc_inr
                            WHERE dc_inr.owner = dc_otr.owner 
                              AND dc_inr.table_name = dc_otr.table_name
                              AND constraint_type='P')
         GROUP BY dc_otr.owner, dc_otr.table_name, CONSTRAINT_TYPE
   ) inri 
WHERE dtc.owner = inri.owner 
 AND dtc.OBJECT_NAME = inri.TABLE_name 
 AND NOT (REGEXP_LIKE ( dtc.OBJECT_NAME, '\$|s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE|^TODROP_', 'i')) 
ORDER BY owner DESC, OBJECT_NAME ASC;


-- None PK/UK table list
SELECT dt.OWNER, dt.TABLE_NAME
  FROM DBA_TABLES dt, dba_objects doj
 WHERE  dt.owner = doj.owner AND dt.table_name = doj.object_name AND
   NOT EXISTS (SELECT  'TRUE'
                 FROM DBA_CONSTRAINTS dc
                 WHERE dc.TABLE_NAME = dt.TABLE_NAME
                   AND dc.CONSTRAINT_TYPE IN ('P','U'))
   AND dt.OWNER  IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
   AND NOT (REGEXP_LIKE (dt.TABLE_NAME,'\$|s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
   AND doj.object_type='TABLE'
 ORDER BY OWNER, TABLE_NAME ASC


-- Un-Support Data Type Table list
SELECT OWNER, OBJECT_NAME 
FROM DBA_OBJECTS 
WHERE OBJECT_NAME  IN (SELECT DISTINCT TABLE_NAME 
                              FROM dba_tab_columns dtc 
                             WHERE DATA_TYPE IN ('CLOB', 'BLOB', 'LONG', 'RAW') 
                               AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX')) 
 AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX') 
 AND OBJECT_TYPE = 'TABLE'  
 
 
 
-- Table list with clob/blob columns, but do not have PK/UK constraints 
SELECT dtc.owner, dtc.table_name
FROM dba_tab_columns dtc, dba_objects doj
WHERE dtc.data_type IN ('CLOB', 'BLOB', 'LONG', 'RAW')
  AND (dtc.owner, dtc.table_name) IN (SELECT OWNER,TABLE_NAME
                                        FROM DBA_TABLES dt
                                       WHERE NOT EXISTS (SELECT  'TRUE'
                                                           FROM DBA_CONSTRAINTS dc
                                                          WHERE dc.TABLE_NAME = dt.TABLE_NAME
                                                            AND dc.CONSTRAINT_TYPE IN ('P','U'))
                                         AND OWNER  IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX'))
  AND dtc.owner = doj.owner
  AND DTC.TABLE_NAME = doj.object_name
  AND doj.object_type = 'TABLE'
  AND NOT REGEXP_LIKE(doj.object_name,'\$|^z_','i')
ORDER BY dtc.owner DESC, dtc.table_name ASC 


-------------------------------------------------------------------------------------------------------------------

-- Module wise query report for just an exampl
SELECT KEY_NOKEY.OWNER, KEY_NOKEY.TABLE_NAME, DECODE(KEY_NOKEY.CONSTRAINT_TYPE,NULL,'NOPK',KEY_NOKEY.CONSTRAINT_TYPE) constraint_type, 
    KEY_NOKEY.KEY_COLUMN_NAME, date_cols.DATE_COLUMN_NAME, LOB_COLUMNS
FROM 
  (  -- list of the pk/uk tables
       SELECT dc.OWNER, dc.TABLE_NAME, DECODE(dc.CONSTRAINT_TYPE,'P','PK') CONSTRAINT_TYPE,  WM_CONCAT(dcc.COLUMN_NAME) key_column_name
          FROM dba_constraints dc, dba_cons_columns dcc
         WHERE  dc.owner = dcc.owner
           AND dc.constraint_name = dcc.constraint_name
           AND dc.table_name = dcc.table_name
           AND dc.owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
           AND dc.constraint_type = 'P'
         GROUP BY dc.owner, dc.table_name, CONSTRAINT_TYPE
         UNION ALL
        SELECT dc_otr.owner, dc_otr.table_name, DECODE(dc_otr.CONSTRAINT_TYPE,'U','UK') CONSTRAINT_TYPE,  WM_CONCAT(COLUMN_NAME) key_column_name
          FROM dba_constraints dc_otr, dba_cons_columns dcc
         WHERE dc_otr.owner = dcc.owner
           AND dc_otr.constraint_name = dcc.constraint_name
           AND dc_otr.table_name = dcc.table_name
           AND dc_otr.owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
           AND dc_otr.constraint_type = 'U'
           AND NOT EXISTS (SELECT 1 
                             FROM dba_constraints dc_inr
                            WHERE dc_inr.owner = dc_otr.owner 
                              AND dc_inr.table_name = dc_otr.table_name
                              AND constraint_type='P')
         GROUP BY dc_otr.owner, dc_otr.table_name, CONSTRAINT_TYPE
         UNION ALL
         SELECT owner, table_name, NULL, NULL
           FROM dba_TABLES dt
          WHERE NOT EXISTS (SELECT 1
                              FROM dba_CONSTRAINTS dc
                             WHERE dc.owner = dt.owner
                               AND dt.table_name = dc.table_name
                               AND constraint_type IN ('P','U'))
            AND owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
   ) key_nokey 
   FULL OUTER JOIN
   ( -- tables list of date and timestamp columns
        SELECT dtc.OWNER, dtc.TABLE_NAME, wm_concat(dtc.column_name) date_column_name
          FROM dba_tab_columns dtc
         WHERE owner IN ('SNOX4TRANSNOX','TRANSNOX_IOX')
           AND (data_type IN ('DATE') OR REGEXP_LIKE(DATA_TYPE,'TIMESTAMP','i'))
         GROUP BY  dtc.OWNER, dtc.TABLE_NAME       
   )date_cols 
    ON (key_nokey.OWNER = date_cols.OWNER AND key_nokey.TABLE_NAME = date_cols.TABLE_NAME)    
    FULL OUTER JOIN
   (   -- list of table which are having lobc and long, raw data typies
        SELECT DISTINCT owner, TABLE_NAME ,'Y' LOB_COLUMNS
          FROM dba_tab_columns dtc 
         WHERE DATA_TYPE IN ('CLOB', 'BLOB', 'LONG', 'RAW') 
           AND OWNER IN ('SNOX4TRANSNOX', 'TRANSNOX_IOX')
     )lobs
    ON (key_nokey.OWNER = lobs.OWNER AND key_nokey.TABLE_NAME = lobs.TABLE_NAME)
 WHERE KEY_NOKEY.table_name IN ('ACCOUNT_NUMBER_MASTER','CATEGORY_MODIFIER_MAP','CUSTOMER_GROUP_MAP','DEVICE','DEVICE_CONFIGURATION','DEVICE_PROCESSOR_INFO','GLOBAL_PRODUCT_IMAGES','GLOBAL_PRODUCTS','LOOKUP_ADDITIONAL_AMOUNT_TYPE','LOOKUP_AUDIT_USER_EVENT','LOOKUP_OPERATOR_TYPE','LOOKUP_SIC_CODES','LOOKUP_TRANS_TYPE','MER_CUSTOM_PRODUCT_DETAILS','MER_PRODUCT_CATEGORY_TAX_MAP','MER_PRODUCT_MODIFIER_OPTION','MER_PRODUCT_VARIANT_OPTION','MERCHANT','MERCHANT_PROCESSOR_INFO','MERCHANT_PRODUCT','MERCHANT_PRODUCT_CATEGORY','MERCHANT_PRODUCT_MODIFIER','MERCHANT_PRODUCT_TAX_MAP','MERCHANT_PRODUCT_VARIANT','MERCHANT_TAX_CATEGORY','OPERATOR','PRODUCT_CATEGORY_MAP','PRODUCT_MODIFIER_MAP','USER_AUDIT','USER_AUDIT_DETAIL')
-- ('PROCESSOR_CONFIGURATION','PROCESSOR_MASTER','PROCESSOR_OPERATOR','PROCESSOR_SWITCH','PROCESSOR_SWITCH_MERCHANT','PROCESSOR_SYNC_STATUS')
-- ('REPORT_CHART_META_DATA','REPORT_COLUMNS','REPORT_COLUMNS_MAP','REPORT_DEFUALT_CONDITION','REPORT_INFORMATION','REPORT_PAGINATION_INFO','REPORT_SEARCH_PARAMETER','REPORT_SEARCH_PARAMETER_MAP')
-- ('DYNAMIC_DAEMON_RULESETS','RECON_CONFIG','RECON_FILE_CONFIG','RECON_FILE_STATUS','RECON_STATUS','SOURCE_MER_FILE_CONFIG')
--  ('GLOBAL_PRODUCT_IMAGES','GLOBAL_PRODUCTS','KEY_VALIDATION_INFO','KEY_VALIDATION_INFO_HIST','MER_CUSTOM_PRODUCT_DETAILS','MER_CUSTOM_PRODUCT_DETAILS_HIS','MER_PRODUCT_CATEGORY_TAX_MAP','MER_PRODUCT_MODIFIER_OPTION','MER_PRODUCT_VARIANT_OPTION','MER_SEARCH_XML_RESPONSE_IMGAES','MERCHANT_DISCOUNT','MERCHANT_DISCOUNT_REASON','MERCHANT_MODIFIER_CATEGORY','MERCHANT_MODIFIER_CATEGORY_MAP','MERCHANT_PRODUCT','MERCHANT_PRODUCT_CATEGORY','MERCHANT_PRODUCT_HIST','MERCHANT_PRODUCT_MAP','MERCHANT_PRODUCT_MODIFIER','MERCHANT_PRODUCT_TAX_MAP','MERCHANT_PRODUCT_VARIANT','MERCHANT_SEARCH_XML_RESPONSE','MERCHANT_TAX_CATEGORY','MERCHANT_XML_RESPONSE','MERCHANT_XML_STORAGE','PRODUCT_CATEGORY_MAP','PRODUCT_CONFIGURATION','PRODUCT_IMAGE','PRODUCT_MASTER','PRODUCT_MODIFIER_MAP')
-- ('DATABASE_EXEC_LOG_HSP','LOG_EXECUTION_TIME')
-- ('EXTERNAL_REQUEST_AUDIT','INFONOX_SERVICE_USAGE','REPORT_USAGE_AUDITTRAIL','REQUEST_AUDIT_TRAIL','SYSTEM_CONFIGURATION','USER_AUDIT','USER_AUDIT_DETAIL')
-- ('CPASS_BILLING_FILE_CONFIG','LICENCE_TYPE_DETAILS','LICENCE_TYPE_DETAILS_HIST','MERCHANT_LICENSE_SUMMARY')
-- ('ATNT_RESPONSE_DTL','ATNT_RESPONSE_DTL_AUDIT','ATNT_SCRATCHPAD','CONFIRMATION_DATA','CONFIRMATION_FILE_DATA','FIELD_VALIDATION_INFO','FILE_PROCESS_COLUMN_MAPS','FILE_PROCESS_CUSTOMER','FILE_PROCESS_DETAILS','FILE_PROCESS_HISTORY','FILE_PROCESS_SAMPLES','FILE_PROCESS_SCRATCHPAD','FILE_PROCESS_STATISTICS','INSTITUTION_ROUTING_NUM_HIST','INSTITUTION_ROUTING_NUM_MASTER','INSTITUTION_ROUTING_NUM_TEMP','LOOKUP_MER_DESTINATION_TYPE','LOOKUP_MER_DESTINATION_TYPE','LOOKUP_MER_FILE_COLUMNS','LOOKUP_MER_FILE_TYPES','MERCHANT_FILE_PROCESS','RECURRING_BILLING_STAG','RECURRING_CONSUMER_STAG','RECURRING_PAYMENT_STAG','RECURRING_SCRAPPED_ROWS','RECURRING_SCRATCHPAD_TMP','RECURRING_UPLOAD_SUMMARY','TMS_RESPONSE_DTL','TMS_RESPONSE_DTL_AUDIT') 
-- ('BUSINESS_ENTITY_OPERATION_MAP','BUSINESS_ENTITY_ROLE_MAP','OPERATION_APPLICATION_MAP','OPERATOR','OPERATOR_OPERATIONS','PROFILE_DETAIL','PROFILE_OPERATIONS','PROFILES')
-- ('RECURRING_PAYMENT','RECURRING_SCHEDULE','SCHEDULE_FIN_ACCOUNTS')
-- ('ADMIN_TRANSACTION','HARMONY_BATCH_INFO','HARMONY_BATCH_SELECTION_INFO','HARMONY_SETLMNT_TRANS_DET_HIST','HARMONY_SETTLEMENT_LINE_DET','HARMONY_SETTLEMENT_TAD_DET','HARMONY_SETTLEMENT_TRANS_DET','HARMONY_TRANS_EMV_DATA','MER_BATCHCLOSE_METADATA_HIST','MERCHANT_BATCHCLOSE_METADATA','TERMINAL_THREAD_MAP') 
-- ('ACQUIRER','ACQUIRER_OPERATIONS','APPLICATION_DEVICE','APPLICATION_MASTER','APPLICATION_MERCHANT','BIN','BIN_ACQUIRER_MAP','BIN_CONFIGURATION','BIN_SALES_AGENT_MAP','BOARDING_ACQUIRER_CONFIG','CORPORATION','DEVICE','DEVICE_CONFIGURATION','DEVICE_PERIPHERAL','DEVICE_PROCESSOR_INFO','DEVICE_PROCESSOR_INFO_HIST','DEVICE_PROFILE_PARAMS','DEVICE_SUB_MENU','LOOKUP_OPERATIONS','LOOKUP_OPERATOR_TYPE_OPERATION','LOOKUP_PROPERTY_NAME','LOOKUP_PROPERTY_NAME_DEFAULTS','MERCHANT','MERCHANT_ACTIVATION_URL','MERCHANT_CONFIGURATION','MERCHANT_CONFIGURATION_HIST','MERCHANT_OPERATIONS','MERCHANT_OPERATOR_DETAILS','MERCHANT_PROCESSOR_INFO','MERCHANT_PROCESSOR_INFO_HIST')
--  ('CARD_NUMBER_MASTER','CUST_ADDRESS','CUST_ADDRESS_HISTORY','CUST_BANK_ACCOUNT','CUST_BANK_ACCOUNT_HIST','CUST_CARD_ACCOUNT','CUST_CARD_ACCOUNT_HIST','CUST_COMPLIANCE_INFO','CUST_COMPLIANCE_INFO_HISTORY','CUST_CONFIGURATION','CUST_ENROLLMNENT','CUST_FINANCIAL_ACCOUNT','CUST_SIGNATURE','CUST_SIGNATURE_HISTORY','CUSTOMER','ENROLLED_CUSTOMER_DATA','SSN_MASTER')
-- ('TASK','TRANS_ADDITIONAL_AMOUNT_TYPE','TRANS_BANK_DETAIL','TRANS_BANK_DETAIL_HISTORY','TRANS_CARD','TRANS_CARD_HISTORY','TRANS_COMPLIANCE_INFO','TRANS_COUPONS','TRANS_DETAIL','TRANS_DISCOUNT_INFO','TRANS_EMV_DATA','TRANS_ENHANCED_DATA','TRANS_FEE_DETAIL','TRANS_INVOICE_DATA','TRANS_LODGING_INFO','TRANS_MODIFIER_INFO','TRANS_ORDER_DATA','TRANS_PRODUCT_INFO','TRANS_PRODUCT_INFO_HIST','TRANS_REPRINT','TRANS_RESPONSE_INFO','TRANS_RETURN','TRANS_SCORE','TRANS_SETTLEMENT','TRANS_SHIPPING_INFO','TRANS_SIGNATURE','TRANS_SIGNATURE_HISTORY','TRANS_TAX_DETAIL','TRANS_VOID','TRANSACTION')
ORDER BY KEY_NOKEY.owner ASC, KEY_NOKEY.table_name ASC
-------------------------------------------------------------------------------------------------------------------

/*

Finding what's consuming the most UNDO
posted Apr 24, 2012, 8:54 AM by Sachchida Ojha   [ updated Apr 24, 2012, 8:55 AM ]
Very often DBA's see that one or more session seem to be hogging the UNDO tablespace.  You need to find out what user and which SQL statement is eating up all the UNDO space.
*/
SELECT S.SQL_TEXT 
FROM V$SQL S, V$UNDOSTAT U
WHERE U.MAXQUERYID=S.SQL_ID;

-- You can also use following SQL to find out most undo used by a session for a currently executing transaction.
SELECT s.sid,s.username,t.used_urec,t.used_ublk
  FROM v$SESSION s, v$transaction t
 WHERE s.saddr = t.ses_addr
 ORDER by t.used_ublk desc;

-- To find out which session is currently using the most UNDO,
SELECT s.sid, t.name, s.value
  FROM v$sesstat s, v$statname t
  WHERE s.statistic#=t.statistic#
    AND t.name='undo change vector size'
  ORDER by s.value desc;


SELECT sql.sql_text, t.used_urec records, t.used_ublk blocks,
		(t.used_ublk*8192/1024) kb 
  FROM v$transaction t, v$session s, v$sql sql
 WHERE t.addr=s.taddr
   AND s.sql_id = sql.sql_id
   AND s.username ='&USERNAME';
-------------------------------------------------------------------------------------------------------------------

-- Query 
SELECT
  MAX(DECODE(dow,1,d,NULL)) Sun,
  MAX(DECODE(dow,2,d,NULL)) Mon,
  MAX(DECODE(dow,3,d,NULL)) Tue,
  MAX(DECODE(dow,4,d,NULL)) Wed,
  MAX(DECODE(dow,5,d,NULL)) Thu,
  MAX(DECODE(dow,6,d,NULL)) Fri,
  MAX(DECODE(dow,7,d,NULL)) Sat
 FROM
  ( SELECT ROWNUM d
           ,ROWNUM-2+TO_NUMBER(TO_CHAR(DATE '2016-05-01','D')) P
           ,TO_CHAR(DATE '2016-05-01' -1 + ROWNUM,'D') dow
    FROM dual
    CONNECT BY LEVEL <= 31
   )
 GROUP BY TRUNC(P/7)
 ORDER BY TRUNC(P/7); 
-------------------------------------------------------------------------------------------------------------------

-- Reclaim datafile size

/* Formatted on 05/19/2016 2:45:14 AM (QP5 v5.185.11230.41888) */
SELECT File_ID, Tablespace_name, file_name, High_Water_Mark, current_size_in_GB,
    'ALTER DATABASE DATAFILE '''||file_name||''' resize '|| High_Water_Mark|| 'M;' script_reclaim
FROM 
(
    WITH v_file_info
         AS (SELECT FILE_NAME, FILE_ID, BLOCK_SIZE
               FROM dba_tablespaces tbs, dba_data_files df
              WHERE tbs.tablespace_name = df.tablespace_name)
    SELECT A.FILE_ID,
           A.FILE_NAME,
           A.TABLESPACE_NAME,
           CEIL ( (NVL (hwm, 1) * v_file_info.block_size) / 1024 / 1024) High_Water_Mark,
           CEIL (BLOCKS * v_file_info.block_size / 1024 / 1024 /2014) current_size_in_GB
      FROM dba_data_files A,
           v_file_info,
           (  SELECT file_id, MAX (block_id + BLOCKS - 1) hwm
                FROM dba_extents
            GROUP BY file_id) b
     WHERE A.file_id = b.file_id(+) 
       AND A.file_id = v_file_info.file_id
       AND tablespace_name='IFX_SER_USAGE_DATA2'
)     
WHERE  High_Water_Mark <> current_size_in_GB

ALTER DATABASE DATAFILE '+ASMTXNDATA/txndcw/datafile/all_temp_tables.284.882569903' RESIZE 6M     
   
   
   