East OS patch GG


GGSCI (wpl1trandbrpt1.tsysacquiring.org) 2> !
info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRW        00:00:01      00:00:07
EXTRACT     STOPPED     PPRWRE      00:00:00      00:11:49
REPLICAT    STOPPED     RPRWRE      00:00:00      00:11:54
REPLICAT    STOPPED     RPRWTE01    00:00:00      00:11:41
REPLICAT    STOPPED     RPRWTELG    00:00:00      00:11:40
REPLICAT    RUNNING     RPRWTW01    00:00:00      00:00:03
REPLICAT    RUNNING     RPRWTWLG    00:00:00      00:00:00


GGSCI (wpl1trandbtxn1.tsysacquiring.org) 2> !
info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTW        00:00:02      00:00:00
EXTRACT     STOPPED     PPTWRE      00:00:00      00:12:09
EXTRACT     RUNNING     PPTWRW      00:00:00      00:00:02
EXTRACT     STOPPED     PPTWTE      00:00:00      00:12:05
REPLICAT    STOPPED     RPTWTE01    00:00:00      00:12:16
REPLICAT    STOPPED     RPTWTELG    00:00:00      00:12:15


GGSCI (wpl1trandbtxn1.tsysacquiring.org) 3>



sh date 
info all
sh date 





--precheck

ps -eaf | grep pmon | tee /acfs/patch_stat/os_pmon_`date +"%m-%d-%Y"`_`hostname`.log
ps -eaf | grep pmon | tee /acfs/patch_stat/os_tns_`date +"%m-%d-%Y"`_`hostname`.log
df -Ph  | /acfs/patch_stat/tee os_df_`date`_`hostname`.log
/opt/app/11.2.0/grid_1/bin/./crsctl stat res -t | tee /acfs/patch_stat/os_crs_`date +"%m-%d-%Y"`_`hostname`.log
/opt/app/11.2.0/grid_1/bin/./crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
 awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}' | tee /acfs/patch_stat/os_crsstat_`date +"%m-%d-%Y"`_`hostname`.log



/opt/app/11.2.0/grid_1/bin/./crsctl stop cluster -n epl1trandbtxn3


/opt/app/oracle/xag/bin/agctl stop goldengate gg_etxn

/opt/app/oracle/xag/bin/agctl start goldengate gg_etxn


 /opt/app/oracle/xag/bin/agctl stop goldengate gg_erpt

