https://community#oracle#com/people/3189350/blog?customTheme=otn
IMP --http://www#oracle-scn#com/oracle-goldengate-veridata-122-step-by-step-installation/

vishalvilas#b@gmail#com
devdbnode2#tsysacquiring#org

scp oracle@regdbnode2#tsysacquiring#org:/recovery/oracle/bkups/dumpfiles/expdp_regracdb2_bkups_21Feb2019#dmp#gz  #/ 

rman target / rcvcat rman/rman@rcat  @${HOME}/scripts/backup/RMANdelobsolete.rcv

BACKUP ARCHIVELOG ALL  until time 'sysdate-1' DELETE INPUT;
backup archivelog all archivelog until time 'sysdate-1/24' delete input;
  
restore archivelog from logseq=295139 until logseq=295143; thread=2;




allocate channel for maintenance type disk;
allocate channel for maintenance device type 'sbt_tape' PARMS 'SBT_LIBRARY=/opt/omni/lib/libob2oracle8_64bit.so';
crosscheck archivelog all;
delete force obsolete;
delete exxpired archivelog all;
crosscheck archivelog all;
