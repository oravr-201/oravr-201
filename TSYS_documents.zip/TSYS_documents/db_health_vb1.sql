
CRS_STAT( )
{
        TMP=/tmp/status$$.tmp                                             # A tempfile
       TMP2=/tmp/status2$$.tmp                                            # Another tempfile
  DBMACHINE=/opt/oracle.SupportTools/onecommand/databasemachine.xml       # File where we should find the Exadata model as oracle user
       GREP="."                                                           # What we grep                  -- default is everything
     UNGREP="nothing_to_ungrep_unless_v_option_is_used$$"                 # What we don't grep (grep -v)  -- default is nothing
 USE_ORAENV="YES"                                                         # Use oraenv to set the ASM env (-e changes this to NO)
    REVERSE="NO"                                                          # Revert the colors to make them visible, useful for clear terminal backgrounds
WITH_COLORS="YES"                                                         # Output with colors, (-b changes this to NO); set to NO for permanent no colored output
      WHITE="37m"                                                         # White color code
 DIFF_HOURS="24"                                                          # Nb of hours the instance has been restarted
    SORT_BY=""                                                            # Column to sort by (see the help for possible values)
 LONG_NAMES="NO"                                                          # If we try to shorten the host names in the tables or not

# Choose the information what you want to see -- the last uncommented value wins
# ./rac-status.sh -h for more information
  SHOW_DB="YES"                 # Databases
 #SHOW_DB="NO"
SHOW_LSNR="YES"                 # Listeners
#SHOW_LSNR="NO"
 SHOW_SVC="YES"                 # Services
 SHOW_SVC="NO"

# Number of spaces between the status and the "|" of the column - this applies before and after the status
# A value of 2 would print 2 spaces before and after the status and like |  Open  |
# A value of 8 would print |        Open         |
# A value of 99 means that this parameter is dynamically calculated depending on the number of nodes
# A non 99 value is applied regardless of the number of nodes
COL_NODE_OFFSET=99

#
# Different OS support
#
OS=`uname`
case ${OS} in
        SunOS)
                           AWK=`which gawk`                         ;
                           SED=`which gsed`                         ;;
        Linux)
                           AWK=`which awk`                          ;
                           SED=`which sed`                          ;;
        HP-UX)
                           AWK=`which awk`                          ;
                           SED=`which sed`                          ;;
        AIX)
                           AWK=`which gawk`                         ;
                           SED=`which sed`                          ;;
        *)                 printf "\n\t\033[1;31m%s\033[m\n\n" "Unsupported OS, cannot continue."           ;
                           exit 666                            ;;
esac
# Check if we have an AWK and a SED to continue
if [[ ! -f ${AWK} ]]
then
        printf "\n\t\033[1;31m%s" "No awk found on your system, cannot continue, if you run Solaris, please ensure that gawk is in your path"
        printf "\t%s\033[m\n\n" ${AWK}
        exit 678
fi
if [[ ! -f ${SED} ]]
then
        printf "\n\t\033[1;31m%s" "No sed found on your system, cannot continue, if you run Solaris, please ensure that gsed is in your path"
        printf "\t%s\033[m\n\n" ${SED}
        exit 679
fi
#
# Show the version of the script (-V)
#
show_version()
{
        VERSION=`${AWK} '{if ($0 ~ /^# 20[0-9][0-9][0-1][0-9]/) {print $2; exit}}' $0`
        printf "\n\t\033[1;36m%s\033[m\n" "The current version of "`basename $0`" is "$VERSION"."          ;
}
#
# An usage function
#
usage()
{
printf "\n\033[1;37m%-8s\033[m\n" "NAME"                ;
cat << END
        `basename $0` - A nice overview of databases, listeners and services running across a GI 12c
END

printf "\n\033[1;37m%-8s\033[m\n" "SYNOPSIS"            ;
cat << END
        $0 [-a] [-n] [-d] [-l] [-s] [-o] [-f] [-r] [-u] [-h]
END

printf "\n\033[1;37m%-8s\033[m\n" "DESCRIPTION"         ;
cat << END
        `basename $0` needs to be executed with a user allowed to query GI using crsctl; oraenv also has to be working
        `basename $0` will show what is running or not running accross all the nodes of a GI 12c :
                - The databases instances (and the ORACLE_HOME they are running against)
                - The type of database : Primary, Standby, RAC One node, Single
                - The listeners (SCAN Listener and regular listeners)
                - The services
        With no option, `basename $0` will show what is defined by the variables :
                - SHOW_DB       # To show the databases instances
                - SHOW_LSNR     # To show the listeners
                - SHOW_SVC      # To show the services
                These variables can be modified in the script itself or you can use command line option to revert their value (see below)

END

printf "\n\033[1;37m%-8s\033[m\n" "OPTIONS"             ;
cat << END
        -a        Show everything regardless of the default behavior defined with SHOW_DB, SHOW_LSNR and SHOW_SVC
        -n        Show nothing  regardless of the default behavior defined with SHOW_DB, SHOW_LSNR and SHOW_SVC
        -a and -n are handy to erase the defaults values:
                        $ ./rac-status.sh -n -d                         # Show the databases output only
                        $ ./rac-status.sh -a -s                         # Show everything but the services (then the listeners and the databases)

        -d        Revert the behavior defined by SHOW_DB  ; if SHOW_DB   is set to YES to show the databases by default, then the -d option will hide the databases
        -l        Revert the behavior defined by SHOW_LSNR; if SHOW_LSNR is set to YES to show the listeners by default, then the -l option will hide the listeners
        -s        Revert the behavior defined by SHOW_SVC ; if SHOW_SVC  is set to YES to show the services  by default, then the -s option will hide the services

        -g        Act as a grep command to grep a pattern from the output (key sensitive)
        -v        Act as "grep -v" to ungrep from the output
        -g and -v examples :
                        $ ./rac-status.sh -g Open                       # Show only the lines with "Open" on it
                        $ ./rac-status.sh -g Open                       # Show only the lines with "Open" on it
                        $ ./rac-status.sh -g "Open|Online"              # Show only the lines with "Open" or "Online" on it
                        $ ./rac-status.sh -g "Open|Online" -v 12        # Show only the lines with "Open" or "Online" on it but no those containing 12

        -c        Column to sort by, please have a look at "Sort the database output" in http://bit.ly/2MFkzDw for more details on this -c option

        -o        Specify a file to save the crsctl commands output
                       $ ./rac-status.sh -o /tmp/rac-status_output.log
        -f        A file to use as input file (one generated by the -o option for example)
                       $ ./rac-status.sh -f /tmp/rac-status_output.log

        -e        Do not use oraenv to set the ASM environment but relies on the current environment
                  Set USE_ORAENV="NO" on top of the script to have a permanent -e option

        -L        Do not try to shorten the host names, show the entire host names

        -r        Reverse the colors (useful for clear terminal backgrounds)

        -u        Shows the Uncolored output (no colors); set WITH_COLORS="NO" on top of the script to have it permanently

        -w        Shows a yellow background when a resource has been restarted less than the number of hours in parameter (default is $DIFF_HOURS)
                    h for hours (default) d for day, w for week, m for month and y for year can be used to specify the delay:
                        $ ./rac-status.sh -w 24         # 24 hours
                        $ ./rac-status.sh -w 24h        # 24 hours
                        $ ./rac-status.sh -w 2d         # 2 days
                        $ ./rac-status.sh -w 3m         # 3 months
        -V        Shows the version of the script
        -h        Shows this help

        Note : the options are cumulative and can be combined with a "the last one wins" behavior :
                $ $0 -a -l              # Show everything but the listeners (-a will force show everything then -l will hide the listeners)
                $ $0 -n -d              # Show only the databases           (-n will force hide everything then -d with show the databases)

                Experiment and enjoy  !

END
exit 123
}

# Options
while getopts "andslLhg:v:o:f:eruw:c:V" OPT; do
        case ${OPT} in
        a)         SHOW_DB="YES"        ; SHOW_LSNR="YES"       ; SHOW_SVC="YES"                ;;
        n)         SHOW_DB="NO"         ; SHOW_LSNR="NO"        ; SHOW_SVC="NO"                 ;;
        d)         if [ "$SHOW_DB"   = "YES" ]; then   SHOW_DB="NO"; else   SHOW_DB="YES"; fi   ;;
        s)         if [ "$SHOW_SVC"  = "YES" ]; then  SHOW_SVC="NO"; else  SHOW_SVC="YES"; fi   ;;
        l)         if [ "$SHOW_LSNR" = "YES" ]; then SHOW_LSNR="NO"; else SHOW_LSNR="YES"; fi   ;;
        L)     LONG_NAMES="YES"                                                                 ;;
        g)           GREP=${OPTARG}                                                             ;;
        c)        SORT_BY=${OPTARG}                                                             ;;
        v)         UNGREP=${OPTARG}                                                             ;;
        f)           FILE=${OPTARG}                                                             ;;
        o)            OUT=${OPTARG}                                                             ;;
        e)     USE_ORAENV="NO"                                                                  ;;
        r)        REVERSE="YES"                                                                 ;;
        w)     DIFF_HOURS=${OPTARG}                                                             ;;
        u)    WITH_COLORS="NO"                                                                  ;;
        V)      show_version; exit 567                                                          ;;
        h)         usage                                                                        ;;
        \?)        echo "Invalid option: -$OPTARG" >&2; usage                                   ;;
        esac
done


#
# Manage the diff hours depending on the unit in the -w option
#
DIFF_HOURS_UNIT=${DIFF_HOURS: -1}

if [[ ! "${DIFF_HOURS_UNIT}" =~ [0-9] ]]
then
        HOURS=`echo ${DIFF_HOURS} | sed s'/.$//'`

        case ${DIFF_HOURS_UNIT} in
        h)      NB_HOURS=1                                                                      ;;
        d)      NB_HOURS=24                                                                     ;;
        w)      NB_HOURS=$((24*7))                                                              ;;
        m)      NB_HOURS=$((24*7*31))                                                           ;;
        y)      NB_HOURS=$((24*7*31*365))                                                       ;;
        esac

        DIFF_HOURS=$(($HOURS * $NB_HOURS))
else
        DIFF_HOURS_UNIT="h"
                  HOURS=${DIFF_HOURS}
fi

#
# If we dont show the DB we dont need to sort
#
if [ "$SHOW_DB" = "NO" ]
then
        SORT_BY=""
fi


#
# Check that the input file is here if specified
#
if [[ "${REVERSE}" == "YES" ]]
then
        WHITE="30m"     ;        # Black
fi
if [ -n "$FILE" ]       # Input file specified, we wont run any crsctl command and rely on the file as input
then
    if  [ ! -f ${FILE} ]
    then
        printf "\n\t\033[1;31m%s\033[m\n\n" "Cannot find the ${FILE} input file; cannot continue"
        exit 222
    else    # we use $FILE as input
        printf "\n\t\033[1;34m%s\033[m\n\n" "Proceeding with the ${FILE} file as input file"
    fi
fi

if [ -z "$FILE" ]               # This is not needed when using an input file
then
        if [[ "${USE_ORAENV}" == "YES" ]]
        then
                #
                # Set the ASM env to be able to use crsctl commands
                #
                ORACLE_SID=`ps -ef | grep pmon | grep asm | ${AWK} '{print $NF}' | sed s'/asm_pmon_//' | egrep "^[+]"`

                export ORAENV_ASK=NO
                . oraenv > /dev/null 2>&1
        fi
        if ! type crsctl > /dev/null 2>&1
        then
                printf "\n\t\033[1;31m%s\033[m\n\n" "Cannot find crsctl, cannot continue, please check if oraenv works or set your environment manually and use the -e option."          ;
                exit 777
        fi

        #
        # List of the nodes of the cluster
        #
        # Try to find if there is "db" in the hostname, if yes we can delete the common "<clustername>" pattern from the hosts for visibility
        SHORT_NAMES="NO"
        if [[ `olsnodes | head -1 | sed s'/,.*$//g' | tr '[:upper:]' '[:lower:]'` == *"db"* && "${LONG_NAMES}" == "NO" ]]
        then
                       NODES=`olsnodes | sed s'/^.*db/db/g' | ${AWK} '{if (NR<2){txt=$0} else{txt=txt","$0}} END {print txt}'`
                CLUSTER_NAME=`olsnodes | head -1 | sed s'/db.*$//g'`
                 SHORT_NAMES="YES"
        else
                       NODES=`olsnodes | ${AWK} '{if (NR<2){txt=$0} else{txt=txt","$0}} END {print txt}'`
                CLUSTER_NAME=`olsnodes -c`
        fi
        NAME_OF_THE_CLUSTER=`olsnodes -c`
        # if oracle restart, olsnodes is here but returns nothing, we then set the NODES with the current hostname
        if [ -z "${NODES}" ]
        then
                NODES=`hostname -s`
        fi

        if [[ "$WITH_COLORS" == "YES" ]]
        then
                COLOR_FOR_CLUSTER="\e[1;"${WHITE}
        else
                COLOR_FOR_CLUSTER=""
        fi
        printf "\n\t\t%s"${COLOR_FOR_CLUSTER}"%s\e[m" "Cluster " "$NAME_OF_THE_CLUSTER"

        #
        # Show the Exadata model if possible (if this cluster is an Exadata)
        #
        if [ -f ${DBMACHINE} ] && [ -r ${DBMACHINE} ]
        then
                        MODEL=`grep -i MACHINETYPES ${DBMACHINE} | sed -e s':</*MACHINETYPES>::g' -e s'/^ *//' -e s'/ *$//'`
                        printf "%s"${COLOR_FOR_CLUSTER}"%s\e[m\n" " is a " "$MODEL"
        else
                        printf "\n"
        fi
        printf "\n"

        # Get the info we want
        cat /dev/null                                                           >  $TMP
        if [ "$SHOW_DB" = "YES" ]
        then
                        crsctl stat res -p -w "TYPE = ora.database.type"        >> $TMP
                        crsctl stat res -v -w "TYPE = ora.database.type"        >> $TMP
        fi
        if [ "$SHOW_LSNR" = "YES" ]
        then
                        crsctl stat res -v -w "TYPE = ora.listener.type"        >> $TMP
                        crsctl stat res -p -w "TYPE = ora.listener.type"        >> $TMP
                        crsctl stat res -v -w "TYPE = ora.scan_listener.type"   >> $TMP
                        crsctl stat res -p -w "TYPE = ora.scan_listener.type"   >> $TMP
        fi
        if [ "$SHOW_SVC" = "YES" ]
        then
                        crsctl stat res -v -w "TYPE = ora.service.type"          >> $TMP
                        crsctl stat res -p -w "TYPE = ora.service.type"          >> $TMP         # not used, in case we need it one day
        fi

        # Easiest way to manage the different versions of crsctl outputs
        awk '{if ($1 ~ /^NAME=/) {print "BREAK_HERE"; print  $0} else {print $0}}' $TMP > $TMP2
        cp ${TMP2} ${TMP}

        if [ "$SHORT_NAMES" = "YES" ]
        then
                        ${SED} -i "s/$CLUSTER_NAME//g" $TMP
        fi
        NB_NODES=`olsnodes | wc -l`
else            # If we use an input file
        cp ${FILE} ${TMP}
           NODES=`grep LAST_SERVER $TMP | awk -F"=" '{print $2}' | sort | uniq | grep -v "^$" | awk '{if (NR<2){txt=$0} else{txt=txt","$0}} END {print txt}'`
        NB_NODES=`grep LAST_SERVER $TMP | awk -F"=" '{print $2}' | sort | uniq | wc -l`
fi      # End if [ -z "$FILE" ]


#
# Define the offset to apply to the status column depending on the number of nodes to make the tables visible for big implementations
#
if [ "$COL_NODE_OFFSET" = "99" ]
then
                COL_NODE_OFFSET=3       ;
                if [ "$NB_NODES" -eq "2" ]; then COL_NODE_OFFSET=6      ;       fi      ;
                if [ "$NB_NODES" -eq "4" ]; then COL_NODE_OFFSET=5      ;       fi      ;
                if [ "$NB_NODES" -gt "4" ]; then COL_NODE_OFFSET=3      ;       fi      ;
fi

        ${AWK} -v NODES="$NODES" -v col_node_offset="$COL_NODE_OFFSET"  \
                                 -v         REVERSE="$REVERSE"          \
                                 -v      DIFF_HOURS="$DIFF_HOURS"       \
                                 -v           HOURS="$HOURS"            \
                                 -v DIFF_HOURS_UNIT="$DIFF_HOURS_UNIT"  \
        'BEGIN\
        {             FS = "="                          ;
                       n = split(NODES, nodes, ",")     ;       # Make a table with the nodes of the cluster
                # some colors
             COLOR_BEGIN =       "\033[1;"              ;
             #COLOR_BEGIN =       "\033["               ;
               COLOR_END =       "\033[m"               ;
                     RED =       "31m"                  ;
                   GREEN =       "32m"                  ;
                  YELLOW =       "33m"                  ;
                    BLUE =       "34m"                  ;
                    TEAL =       "36m"                  ;
                   WHITE =       "37m"                  ;
               WITH_BACK =       "43m"                  ;       # Yellow background
               WITH_BACK2=       "44m"                  ;       # Blue background
               WITH_BACK2=       "41m"                  ;       # Red background
                if (REVERSE == "YES")
                {
                   WHITE =       "30m"                  ;       # Black
                    TEAL =       "34m"                  ;       # Blue
             COLOR_BEGIN =       "\033[2;"              ;       # Bold
                }

                 UNKNOWN = "-"                          ;       # Something to print when the status is unknown
                DISABLED = "x"                          ;       # Something disabled

                # Default columns size
                COL_NODE = 0                            ;
         COL_NODE_OFFSET = col_node_offset * 2          ;       # Defined on top the script, have a look for explanations on this
                  COL_DB = 12                           ;
                 COL_VER = 15                           ;
                COL_TYPE = 14                           ;
                  COL_OH = 24                           ;       # to print the ORACLE_HOMEs
               COL_OWNER = 6                            ;       # to print owner:group
               COL_GROUP = 3                            ;       # to print owner:group
             COL_DEFAULT = BLUE                         ;       # for the "-"
        RECENT_RESTARTED = 0                            ;       # To show a legend if we found a recent restarted
            STATUS_ISSUE = 0                            ;       # To show a legend if we found an issue with the status
        SERVICE_DISABLED = 0                            ;       # To show a legend of a service is disabled
                 COL_SEP = "|"                          ;       # Column separator
        }

        #
        # A function to center the outputs with colors
        #
        function center(str, n, color, sep)
        {       right = int((n - length(str)) / 2)                                                              ;
                left  = n - length(str) - right                                                                 ;
                return sprintf(COLOR_BEGIN color "%" left "s%s%" right "s" COLOR_END sep, "", str, "" )         ;
        }
        #
        # Colorize a string
        #
        function in_color(str, color)
        {
                return sprintf(COLOR_BEGIN color "%s" COLOR_END, str)                                           ;
        }
        #
        # Get a date in format MM/DD/YYYY HH24:MI:SS and return the rounded number hours difference between this date and the current date
        #
        function diff_hours(a_date)
        {       split(a_date, temp, /[\/ :]/)                                                                   ;
                return (systime()-mktime (temp[3]" "temp[1]" "temp[2]" "temp[4]" "temp[5]" "temp[6]))/(60*60)   ;
        }
        #
        # Get a string and return it with a nice case: first character in upper case ad the others in lower case (ABCD => Abcd)
        #
        function nice_case(str)
        {
                return sprintf("%s", toupper(substr(str,1,1)) tolower(substr(str,2,length(str))))               ;
        }
        #
        # Print a legend for the recent restarted instances, listeners and services
        #
        function print_legend_recent_restarted()
        {
                if (RECENT_RESTARTED == 1)
                {
                        printf("%s", " ")                                                                       ;
                        printf(COLOR_BEGIN WITH_BACK "%-3s" COLOR_END, " ")                                     ;
                        if (DIFF_HOURS_UNIT == "h")     { UNIT="hour"           }
                        if (DIFF_HOURS_UNIT == "d")     { UNIT="day"            }
                        if (DIFF_HOURS_UNIT == "w")     { UNIT="week"           }
                        if (DIFF_HOURS_UNIT == "m")     { UNIT="month"          }
                        if (DIFF_HOURS_UNIT == "y")     { UNIT="year"           }
                        if (HOURS > 1)                  { UNIT=UNIT"s"          }
                        printf(COLOR_BEGIN WHITE " %-s\n " COLOR_END, ": Has been restarted less than "HOURS" "UNIT" ago")             ;
                }
        }
        #
        # Print a legend if we found an issue in the status (STATUS != TARGET)
        #
        function print_legend_status_issue()
        {
                if (STATUS_ISSUE == 1)
                {
                        printf(COLOR_BEGIN WITH_BACK2 "%-3s" COLOR_END, " ")                                    ;
                        printf(COLOR_BEGIN WHITE " %-s\n " COLOR_END, ": STATUS and TARGET are different")      ;
                }
        }
        #
        # Print a legend when something is disabled
        #
        function print_legend_disabled(a_variable, a_text)
        {       if (a_variable == 1)
                {       printf("%s", " ")                                                                       ;
                        printf("%s", center(DISABLED, 3, RED))                                                  ;
                        printf("%-s\n", in_color(" : "a_text" is disabled", WHITE))                             ;
                }
        }
        #
        # A function that just print a "---" white line
        #
        function print_a_line(size)
        {
                if ( ! size)
                {       size = COL_DB+COL_VER+(COL_NODE*n)+COL_TYPE+n+3                                         ;
                }
                printf("%s", COLOR_BEGIN WHITE)                                                                 ;
                for (k=1; k<=size; k++) {printf("%s", "-");}                                                    ;       # n = number of nodes
                printf("%s", COLOR_END"\n")                                                                     ;
        }
        {
               # Fill 2 tables with the OH and the version from "crsctl stat res -p -w "TYPE = ora.database.type""
               if ($1 == "NAME")
               {        type = "DB"                                                                             ;
                        sub("^ora.", "", $2)                                                                    ;
                        sub(".db$",  "", $2)                                                                    ;
                        if ($2 ~ ".lsnr")                                                                               # Listeners
                        {       sub(".lsnr$", "", $2)                                                           ;
                                tab_lsnr[$2]    = $2                                                            ;
                                type            =       "LISTENER"                                              ;
                        }
                        if ($2 ~ ".svc")                                                                                # Services
                        {       sub(".svc$", "", $2)                                                            ;
                                tab_svc[$2]=$2                                                                  ;
                                    service=$2                                                                  ;
                                sub(/^[^.]*\./, "", service)                                                    ;       # Remove the DB name
                                if (length(service) > COL_VER-1)                                                        # To adapt the column size
                                {     COL_VER = length(service) +1                                              ;
                                }
                                type            =       "SERVICE"                                               ;
                        }
                        DB=$2                                                                                   ;
                        split($2, temp, ".")                                                                    ;
                        if (length(temp[1]) > COL_DB-1)                                                                  # To adapt the 1st column size
                        {     COL_DB = length(temp[1]) +1                                                       ;
                        }

                        getline; getline                                                                        ;
                        if ($1 == "ACL")                        # crsctl stat res -p output
                        {
                                if (type == "DB")
                                {
                                        # Get the owner and the group
                                        match($2, /owner:([[:alnum:]]*):.*/, OWNER)                             ;
                                        match($2, /^.*pgrp:([[:alnum:]]*):.*/, GROUP)                           ;

                                        while (getline)
                                        {
                                                if ($1 == "ORACLE_HOME")
                                                {                    OH = $2                                    ;
                                                        match($2, /1[0-9]\.[0-9]\.?[0-9]?\.?[0-9]?/)            ;       # Grab the version from the OH path)
                                                                VERSION = substr($2,RSTART,RLENGTH)             ;
                                                }
                                                if ($1 == "DATABASE_TYPE")                                              # RAC / RACOneNode / Single Instance are expected here
                                                {
                                                             dbtype[DB] = $2                                    ;
                                                }
                                                if ($1 == "ROLE")                                                       # Primary / Standby expected here
                                                {              role[DB] = $2                                    ;
                                                }
                                                if ($1 == "ENABLED")                                                    # Instance is enabled (1) or disabled (0)
                                                {       for (i=1; i<=n; i++)                                            # n = number of nodes
                                                        {       is_enabled[DB,nodes[i]]= $2                     ;
                                                        }
                                                        while(getline)
                                                        {       if ($1 ~ /ENABLED@SERVERNAME/ )
                                                                {       sub("ENABLED@SERVERNAME[(]", "", $1)    ;
                                                                        sub(")", "", $1)                        ;
                                                                        is_enabled[DB,$1] = $2                  ;
                                                                } else {
                                                                        break                                   ;
                                                                }
                                                        }
                                                }
                                                if ($0 ~ /^$/)
                                                {           version[DB] = VERSION                               ;
                                                                 oh[DB] = OH                                    ;

                                                        if (!(OH in oh_list))
                                                        {
                                                                oh_ref++                                        ;
                                                            oh_list[OH] = oh_ref                                ;
                                                            o_list[OH] = OWNER[1]                               ;
                                                            g_list[OH] = GROUP[1]                               ;
                                                                if (length(OH)       > COL_OH)    {        COL_OH = length(OH)                  ; }
                                                                if (length(OWNER[1]) > COL_OWNER) {     COL_OWNER = length(OWNER[1])            ; }
                                                                if (length(GROUP[1]) > COL_GROUP) {     COL_GROUP = length(GROUP[1])            ; }
                                                        }
                                                        break                                                   ;
                                                }
                                        }
                                }       # End if (type == "DB")
                                if (type == "SERVICE")
                                {       while(getline)
                                        {
                                                if ($1 == "ENABLED")                                                    # Service is enabled (1) or disabled (0)
                                                {       for (i=1; i<=n; i++)                                            # n = number of nodes
                                                        {       is_enabled[DB,nodes[i]]= $2                     ;
                                                        }
                                                        while(getline)
                                                        {       if ($1 ~ /ENABLED@SERVERNAME/ )
                                                                {       sub("ENABLED@SERVERNAME[(]", "", $1)    ;
                                                                        sub(")", "", $1)                        ;
                                                                        is_enabled[DB,$1] = $2                  ;
                                                                } else {
                                                                        break                                   ;
                                                                }
                                                        }
                                                }
                                                if ($0 ~ /^$/)
                                                {       break                                                   ;
                                                }
                                        }

                                }       # End if (type == "SERVICE")
                                #if (DB in tab_lsnr == 1)
                                if (type == "LISTENER")
                                {
                                        while(getline)
                                        {       if ($1 == "ENABLED")                                                    # Listener is enabled (1) or disabled (0)
                                                {       for (i=1; i<=n; i++)                                            # n = number of nodes
                                                        {       is_enabled[DB,nodes[i]]= $2                     ;
                                                        }
                                                        while(getline)
                                                        {       if ($1 ~ /ENABLED@SERVERNAME/ )
                                                                {       sub("ENABLED@SERVERNAME[(]", "", $1)    ;
                                                                        sub(")", "", $1)                        ;
                                                                        is_enabled[DB,$1] = $2                  ;
                                                                } else {
                                                                        break                                   ;
                                                                }
                                                        }
                                                }
                                                if ($1 == "ENDPOINTS")
                                                {
                                                        port[DB] = $2                                           ;
                                                        break                                                   ;
                                                }
                                        }
                                }
                        }       # End if ($1 == "ACL")
                        if ($1 == "LAST_SERVER")        # crsctl stat res -v output
                        {           NB = 0      ;       # Number of instance as CARDINALITY_ID is sometimes irrelevant
                                SERVER = $2     ;
                                if (length(SERVER) > COL_NODE)
                                {       COL_NODE = length(SERVER) + COL_NODE_OFFSET                             ;
                                }
                                while (getline)
                                {
                                        if ($1 == "LAST_SERVER")        {       SERVER = $2                             ; }
                                        if ($1 == "STATE")              {       gsub(" on .*$", "", $2)                 ;
                                                                                status[DB,SERVER] = $2                  ;
                                                                                if (length(status[DB,SERVER]) > COL_NODE) { COL_NODE = length(status[DB,SERVER]) + COL_NODE_OFFSET;}
                                                                        }
                                        if ($1 == "TARGET")             {       target[DB,SERVER]=$2                    ;}
                                        if ($1 == "LAST_RESTART")       {       started[DB,SERVER]=diff_hours($2" "$3)  ;}
                                        if ($1 == "STATE_DETAILS")      {       NB++                                    ;       # Number of instances we came through
                                                                                sub("STATE_DETAILS=", "", $0)           ;
                                                                                sub(",HOME=.*$", "", $0)                ;       # Manage the 12cR2 new feature, check 20170606 for more details
                                                                                sub("),.*$", ")", $0)                   ;       # To make clear multi status like "Mounted (Closed),Readonly,Open Initiated"
                                                                                if ($0 == "Instance Shutdown")  {  status_details[DB,SERVER] = "Shutdown"       ;       } else
                                                                                if ($0 ~  "Readonly")           {  status_details[DB,SERVER] = "Readonly"       ;       } else
                                                                                if ($0 ~  /Mount/)              {  status_details[DB,SERVER] = "Mounted"        ;       } else
                                                                                if ($0 ~  /running from old/)   {  status_details[DB,SERVER] = "Open from old OH";      } else
                                                                                                                {  status_details[DB,SERVER] = $0               ;       }
                                                                                if (length(status_details[DB,SERVER]) > COL_NODE)
                                                                                {       COL_NODE = length(status_details[DB,SERVER]) + COL_NODE_OFFSET  ;
                                                                                }
                                                                        }
                                                                        if ($1 == "BREAK_HERE") { break;}
                                }
                        }
                }       # End of if ($1 ~ /^NAME/)
            }
            END {       #
                        # Listeners
                        #
                        if (length(tab_lsnr) > 0)                # We print only if we have something to show
                        {
                                # A header for the listeners
                                printf("%s", center("Listener" ,  COL_DB, WHITE, COL_SEP))                      ;
                                printf("%s", center("Port"     , COL_VER+1, WHITE, COL_SEP))                    ;
                                n=asort(nodes)                                                                  ;       # sort array nodes
                                for (i = 1; i <= n; i++) {
                                        printf("%s", center(nodes[i], COL_NODE, WHITE, COL_SEP))                ;
                                }
                                printf("%s", center("Type"    , COL_TYPE, WHITE, COL_SEP))                      ;
                                printf("\n")                                                                    ;

                                # a "---" line under the header
                                print_a_line()                                                                  ;

                                # print the listeners
                                x=asorti(tab_lsnr, lsnr_sorted)                                                 ;
                                for (j = 1; j <= x; j++)
                                {
                                        printf(COLOR_BEGIN WHITE " %-"COL_DB-1"s" COLOR_END"|", lsnr_sorted[j], WHITE);     # Listener name
                                        # It may happen that listeners listen on many ports then it wont fit this column
                                        # We then print it outside of the table after the last column
                                        if (length(port[lsnr_sorted[j]]) > COL_VER)
                                        {
                                                printf(COLOR_BEGIN WHITE " %-"COL_VER"s" COLOR_END"|", "See -->", WHITE);       # "See -->"
                                                print_port_later = 1                                            ;
                                        } else {
                                                printf(COLOR_BEGIN WHITE " %-"COL_VER"s" COLOR_END"|", port[lsnr_sorted[j]], WHITE);      # Port
                                        }
                                        for (i = 1; i <= n; i++)
                                        {
                                                dbstatus =         status[lsnr_sorted[j],nodes[i]]              ;
                                                dbtarget =         target[lsnr_sorted[j],nodes[i]]              ;
                                                dbdetail = status_details[lsnr_sorted[j],nodes[i]]              ;
                                                if ((started[lsnr_sorted[j],nodes[i]] < DIFF_HOURS) && (started[lsnr_sorted[j],nodes[i]]))
                                                {         COL_ONLINE=WITH_BACK                                  ;
                                                           COL_OTHER=WITH_BACK                                  ;
                                                    RECENT_RESTARTED=1                                          ;
                                                } else {
                                                          COL_ONLINE=GREEN                                      ;
                                                           COL_OTHER=RED                                        ;
                                                }
                                                if (dbstatus != dbtarget)
                                                {         COL_ONLINE=WITH_BACK2                                 ;
                                                           COL_OTHER=WITH_BACK2                                 ;
                                                        STATUS_ISSUE=1                                          ;
                                                }
                                                if (is_enabled[lsnr_sorted[j],nodes[i]] == 0)                            # Listener disabled
                                                {
                                                        LISTENER_DISABLED = 1                                   ;
                                                        right = int((COL_NODE - length(dbstatus)) / 2)          ;
                                                        left  = COL_NODE - length(dbstatus) - right             ;

                                                        if (dbstatus == "")             {printf("%s", center(DISABLED,           COL_NODE, RED, COL_SEP ))      ;} else
                                                        if (dbstatus == "ONLINE")       {printf("%"left"s%s %s%"right-1"s", "", in_color(nice_case(dbstatus), COL_ONLINE), in_color(DISABLED, RED), COL_SEP);}
                                                        else                            {printf("%"left"s%s %s%"right-1"s", "", in_color(nice_case(dbstatus), COL_OTHER ), in_color(DISABLED, RED), COL_SEP);}
                                                } else {
                                                        if (dbstatus == "")             {printf("%s", center(UNKNOWN,             COL_NODE, COL_DEFAULT, COL_SEP    ))      ;}      else
                                                        if (dbstatus == "ONLINE")       {printf("%s", center(nice_case(dbstatus), COL_NODE, COL_ONLINE,  COL_SEP    ))      ;}
                                                        else                            {printf("%s", center(nice_case(dbstatus), COL_NODE, COL_OTHER,   COL_SEP    ))      ;}
                                                }
                                        }
                                        if (toupper(lsnr_sorted[j]) ~ /SCAN/)
                                        {       LSNR_TYPE = "SCAN"                                              ;
                                        } else {
                                                LSNR_TYPE = "Listener"                                          ;
                                        }
                                        printf("%s", center(LSNR_TYPE, COL_TYPE, WHITE, COL_SEP))               ;
                                        if (print_port_later)
                                        {       print_port_later = 0                                            ;
                                                printf(COLOR_BEGIN WHITE " %-"COL_VER-1"s" COLOR_END, port[lsnr_sorted[j]], WHITE);      # Port
                                        }
                                        printf("\n")                                                            ;
                                }
                                # a "---" line under the header
                                print_a_line()                                                                  ;
                                print_legend_disabled(LISTENER_DISABLED, "Listener")                            ;
                                printf("\n")                                                                    ;
                        }

                        #
                        # Services
                        #
                        if (length(tab_svc) > 0)                # We print only if we have something to show
                        {
                                # A header for the services
                                printf("%s", center("DB"      ,  COL_DB, WHITE, COL_SEP))                       ;
                                printf("%s", center("Service" ,  COL_VER+1, WHITE, COL_SEP))                    ;
                                n=asort(nodes)                                                                  ;       # sort array nodes
                                for (i = 1; i <= n; i++) {
                                        printf("%s", center(nodes[i], COL_NODE, WHITE, COL_SEP))                ;
                                }
                                printf("\n")

                                # a "---" line under the header
                                print_a_line(COL_DB+COL_NODE*n+COL_VER+n+2)                                     ;

                                # Print the Services
                                x=asorti(tab_svc, svc_sorted)                                                   ;
                                for (j = 1; j <= x; j++)
                                {       split(svc_sorted[j], to_print, ".")                                     ;       # The service we have is <db_name>.<service_name>
                                        service = svc_sorted[j]                                                 ;
                                        sub(/^[^.]*\./, "", service)                                            ;       # Remove the DB name only
                                        if (previous_db != to_print[1])                                                 # Do not duplicate the DB names on the output
                                        {
                                                printf(COLOR_BEGIN WHITE " %-"COL_DB-1"s" COLOR_END COL_SEP, to_print[1], WHITE);     # Database
                                                previous_db = to_print[1]                                       ;
                                        }else {
                                                printf("%s", center("",  COL_DB, WHITE, COL_SEP))               ;
                                        }
                                        printf(COLOR_BEGIN WHITE " %-"COL_VER"s" COLOR_END"|", service, WHITE);     # Service

                                        for (i = 1; i <= n; i++)
                                        {
                                                dbstatus =           status[svc_sorted[j],nodes[i]]             ;
                                                dbtarget =           target[svc_sorted[j],nodes[i]]             ;
                                                dbdetail =   status_details[svc_sorted[j],nodes[i]]             ;
                                                if ((started[svc_sorted[j],nodes[i]] < DIFF_HOURS) && (started[svc_sorted[j],nodes[i]]))
                                                {         COL_ONLINE=WITH_BACK                                  ;
                                                           COL_OTHER=WITH_BACK                                  ;
                                                    RECENT_RESTARTED=1                                          ;
                                                } else {
                                                          COL_ONLINE=GREEN                                      ;
                                                           COL_OTHER=RED                                        ;
                                                }
                                                if (dbstatus != dbtarget)
                                                {
                                                          COL_ONLINE=WITH_BACK2                                 ;
                                                           COL_OTHER=WITH_BACK2                                 ;
                                                        STATUS_ISSUE=1                                          ;
                                                }
                                                if (is_enabled[svc_sorted[j],nodes[i]] == 0)                            # Service disabled
                                                {
                                                        SERVICE_DISABLED = 1                                    ;
                                                        right = int((COL_NODE - length(dbstatus)) / 2)          ;
                                                        left  = COL_NODE - length(dbstatus) - right             ;

                                                        if (dbstatus == "")             {printf("%s", center(DISABLED, COL_NODE, RED, COL_SEP ))      ;} else
                                                        if (dbstatus == "ONLINE")       {printf("%"left"s%s %s%"right-1"s", "", in_color(nice_case(dbstatus), COL_ONLINE), in_color(DISABLED, RED), COL_SEP);}
                                                        else                            {printf("%"left"s%s %s%"right-1"s", "", in_color(nice_case(dbstatus), COL_OTHER ), in_color(DISABLED, RED), COL_SEP);}
                                                } else {
                                                        if (dbstatus == "")             {printf("%s", center(UNKNOWN,             COL_NODE, COL_DEFAULT, COL_SEP   ))      ;} else
                                                        if (dbstatus == "ONLINE")       {printf("%s", center(nice_case(dbstatus), COL_NODE, COL_ONLINE,  COL_SEP   ))      ;}
                                                        else                            {printf("%s", center(nice_case(dbstatus), COL_NODE, COL_OTHER,   COL_SEP   ))      ;}
                                                }
                                        }
                                        printf("\n")                                                             ;
                                }
                                # a "---" line under the header
                                print_a_line(COL_DB+COL_NODE*n+COL_VER+n+2)                                      ;
                                print_legend_disabled(SERVICE_DISABLED, "Service")                               ;
                                printf("\n")                                                                     ;
                        }

                        #
                        # Databases
                        #
                        if (length(version) > 0)                # We print only if we have something to show
                        {
                                # A header for the databases
                                printf("%s", center("DB"        , COL_DB, WHITE, COL_SEP))                       ;
                                printf("%s", center("Version"   , COL_VER+1, WHITE, COL_SEP))                    ;
                                n=asort(nodes)                                                                   ;       # sort array nodes
                                for (i = 1; i <= n; i++) {
                                        printf("%s", center(nodes[i], COL_NODE, WHITE, COL_SEP))                 ;
                                }
                                printf("%s", center("DB Type"    , COL_TYPE, WHITE, COL_SEP))                    ;
                                printf("\n")                                                                     ;

                                # a "---" line under the header
                                print_a_line()                                                                   ;

                                # Print the databases
                                m=asorti(version, version_sorted)                                                ;
                                for (j = 1; j <= m; j++)
                                {
                                        printf(COLOR_BEGIN WHITE " %-"COL_DB-1"s" COLOR_END"|", version_sorted[j], WHITE)                ;     # Database
                                        printf(COLOR_BEGIN WHITE " %-"COL_VER-6"s" COLOR_END, version[version_sorted[j]], COL_VER, WHITE);     # Version
                                        printf(COLOR_BEGIN WHITE "%6s" COLOR_END"|"," ("oh_list[oh[version_sorted[j]]] ") ")             ;     # OH id

                                        for (i = 1; i <= n; i++)
                                        {
                                                dbstatus =           status[version_sorted[j],nodes[i]]         ;
                                                dbtarget =           target[version_sorted[j],nodes[i]]         ;
                                                dbdetail =   status_details[version_sorted[j],nodes[i]]         ;
                                                #
                                                # Print the status here, all that are not listed in that if ladder will appear in RED
                                                #
                                                if ((started[version_sorted[j],nodes[i]] < DIFF_HOURS) && (started[version_sorted[j],nodes[i]]))
                                                {           COL_OPEN=WITH_BACK                                  ;
                                                        COL_READONLY=WITH_BACK                                  ;
                                                            COL_SHUT=WITH_BACK                                  ;
                                                           COL_OTHER=WITH_BACK                                  ;
                                                    RECENT_RESTARTED=1                                          ;
                                                } else  {
                                                            COL_OPEN=GREEN                                      ;
                                                        COL_READONLY=WHITE                                      ;
                                                            COL_SHUT=YELLOW                                     ;
                                                           COL_OTHER=RED                                        ;
                                                }
                                                if (dbstatus != dbtarget)
                                                {
                                                            COL_OPEN=WITH_BACK2                                 ;
                                                        COL_READONLY=WITH_BACK2                                 ;
                                                            COL_SHUT=WITH_BACK2                                 ;
                                                           COL_OTHER=WITH_BACK2                                 ;
                                                        STATUS_ISSUE=1                                          ;
                                                }
                                                if (is_enabled[version_sorted[j],nodes[i]] == 0)                            # Instance disabled
                                                {
                                                        INSTANCE_DISABLED = 1                                   ;
                                                        right = int((COL_NODE - length(dbdetail)) / 2)          ;
                                                        left  = COL_NODE - length(dbdetail) - right             ;

                                                        if (dbdetail == "")             {printf("%s",                           center(DISABLED, COL_NODE, RED, COL_SEP ))                                    ;} else
                                                        if (dbdetail == "Open")         {printf("%"left"s%s %s%"right-1"s", "", in_color(nice_case(dbdetail), COL_ONLINE),   in_color(DISABLED, RED), COL_SEP);} else
                                                        if (dbdetail ~  /Readonly/)     {printf("%"left"s%s %s%"right-1"s", "", in_color(nice_case(dbdetail), COL_READONLY), in_color(DISABLED, RED), COL_SEP);} else
                                                        if (dbdetail ~  /Shut/)         {printf("%"left"s%s %s%"right-1"s", "", in_color(nice_case(dbdetail), COL_SHUT),     in_color(DISABLED, RED), COL_SEP);} else
                                                                                        {printf("%"left"s%s %s%"right-1"s", "", in_color(nice_case(dbdetail), COL_OTHER),    in_color(DISABLED, RED), COL_SEP);}

                                                } else {
                                                        if (dbdetail == "")             {printf("%s", center(UNKNOWN,             COL_NODE, COL_DEFAULT, COL_SEP ))  ;}      else
                                                        if (dbdetail == "Open")         {printf("%s", center(nice_case(dbdetail), COL_NODE, COL_OPEN,    COL_SEP ))  ;}      else
                                                        if (dbdetail ~  /Readonly/)     {printf("%s", center(nice_case(dbdetail), COL_NODE, COL_READONLY,COL_SEP ))  ;}      else
                                                        if (dbdetail ~  /Shut/)         {printf("%s", center(nice_case(dbdetail), COL_NODE, COL_SHUT,    COL_SEP ))  ;}      else
                                                                                        {printf("%s", center(nice_case(dbdetail), COL_NODE, COL_OTHER,   COL_SEP ))  ;}
                                                }
                                        }
                                        #
                                        # Color the DB Type column depending on the ROLE of the database (20170619)
                                        #
                                        if (role[version_sorted[j]] == "PRIMARY") { ROLE_COLOR=WHITE ; ROLE_SHORT=" (P)"; } else { ROLE_COLOR=RED ; ROLE_SHORT=" (S)" }
                                        printf("%s", center(dbtype[version_sorted[j]] ROLE_SHORT, COL_TYPE, ROLE_COLOR, COL_SEP))           ;

                                        printf("\n")                                                            ;
                                }

                                # a "---" line as a footer
                                print_a_line()                                                                  ;

                                # Print the OH list and a legend for the DB Type colors underneath the table
                                printf ("%s", "ORACLE_HOME references listed in the Version column ")           ;
                                if (oh_ref > 1)
                                {
                                        printf ("(%s)", "\"" sprintf(COLOR_BEGIN TEAL "%s" COLOR_END, "\47\47") "\" means \"same as above\"")           ;
                                }
                                printf ("\n\n")                                                                 ;

                                previous_group = ""                                                             ;
                                previous_owner = ""                                                             ;
                                if (COL_OWNER%2) { COL_OWNER++  }
                                if (COL_GROUP%2) { COL_GROUP++  }
                                g_same_as_above=sprintf(COLOR_BEGIN TEAL "%"(COL_GROUP/2)-1"s%s" COLOR_END, "", "\47\47")                               ;
                                o_same_as_above=sprintf(COLOR_BEGIN TEAL "%"(COL_OWNER/2)-1"s%s%"(COL_OWNER/2)-1"s" COLOR_END, "", "\47\47", "")        ;

                                # to ease the ORACLE_HOME sorting
                                for (x in oh_list)
                                {
                                        to_print[oh_list[x]] = x                                                ;
                                }
                                for (i=1; i<=oh_ref; i++)
                                {
                                        # to ease the naming
                                        the_oh=to_print[i]                                                      ;
                                         owner=o_list[to_print[i]]                                              ;
                                         group=g_list[to_print[i]]                                              ;
                                        if (group == previous_group) {  group_to_print = g_same_as_above        ;       } else {        group_to_print = group  ;       }
                                        if (owner == previous_owner) {  owner_to_print = o_same_as_above        ;       } else {        owner_to_print = owner  ;       }

                                        printf("\t%2d : %-"COL_OH"s\t%-"COL_OWNER"s %s\n", i, the_oh, owner_to_print, group_to_print) ;
                                        previous_group = group                                                  ;
                                        previous_owner = owner                                                  ;
                                }
                        }
                        printf ("\n")                                                                           ;
                        print_legend_disabled(INSTANCE_DISABLED, "Instance")                                    ;
                        print_legend_recent_restarted()                                                         ;
                        print_legend_status_issue()                                                             ;
        } ' $TMP | ${AWK} -v GREP="$GREP" -v UNGREP="$UNGREP" ' BEGIN {FS="|"}                                              # AWK used to grep and ungrep
                      {         if ((NF >= 3) && ($(NF-1) !~ /Type/) && ($2 !~ /Service/))
                                {       if (($0 ~ GREP) && ($0 !~ UNGREP))
                                        {
                                                print $0                                                        ;
                                        }
                                } else {
                                        print  $0                                                               ;
                                }
                        }' | sed s'/^/  /'              > ${TMP2}                       # We can reuse TMP2 here

        #
        # Special sort order (option -c)
        #
        if [[ -n ${SORT_BY} ]]                                                          # Special sort order
        then
                  SORT_COL="${SORT_BY:0:1}"                                             # First character
                 SORT_NODE="${SORT_BY:1:1}"                                             # Second character
                SORT_ORDER="${SORT_BY: -1}"                                             # Last character

                if [[ "${SORT_COL}" =~ [1-9] ]]
                then    SORT_NODE=${SORT_COL}
                         SORT_COL="c"
                fi

                # Sort order can only be "r" for reverse or "" for normal
                if [[ "${SORT_ORDER}" != "r" ]]
                then    SORT_ORDER=""
                else    SORT_ORDER="r"
                fi

                # Column or node number
                if [[ ! "${SORT_NODE}" =~ [1-9] ]]
                then    SORT_NODE=1
                fi


                # Assign the column  number depending of what we want to sort by
                 SORT_NUM=1
                SORT_NUM2=2                                                                                                    # Second column to sort by
                SORT_NUM3=2                                                                                                    # Third column to sort by
                case ${SORT_COL} in
                c )     if [[ "${SORT_NODE}" -gt "2" ]]
                        then
                                SORT_NUM=$(((${SORT_NODE}*2)+2))
                                SORT_NUM2=$((${SORT_NUM}-1))
                        else    SORT_NUM=$(( ${SORT_NODE}*2   ))
                        fi                                                                                      ;;              # Sort by column number
                d )     SORT_NUM=2                                                                              ;;              # Sort by DB name
                v )     SORT_NUM=4                                                                              ;;              # Sort by version
                s )     SORT_NUM=$(((${SORT_NODE}*2)+6))                                                        ;               # Sort by status (Shutdown, Open)
                        SORT_NUM2=$((${SORT_NUM}-1))                                                            ;;
                t )     TYPE_COL=`cat ${TMP2} | awk 'BEGIN {FS="|"}{if ($2 ~ "Version"){print (NF-1); exit}}'`  ;
                        SORT_NUM=$(((${TYPE_COL}*2)+1))                                                         ;;              # Sort by Type
                esac

                SORT_K_1=" -k"${SORT_NUM}${SORT_ORDER}" "
                SORT_K_2=" -k"${SORT_NUM2}" "
                SORT_K_3=" -k"${SORT_NUM3}" "

                cat ${TMP2} | awk 'BEGIN {FS="|"} {print $0; if ($2 ~ "Version"){getline; print $0; exit;}}' > ${TMP}
                cat ${TMP2} | awk 'BEGIN {FS="|"}{if ($2 ~ "Version"){getline; while(getline){if ($0 ~ /---------------/){break}; print $0; }}}' | sort -i ${SORT_K_1} ${SORT_K_2} ${SORT_K_3} >> ${TMP}
                tac ${TMP2} | awk '{print $0; if ($0 ~ /---------------/){exit;}}' | tac >> ${TMP}

                cp ${TMP} ${TMP2}
        fi

        if [[ "$WITH_COLORS" == "YES" ]]
        then
                cat ${TMP2}
        else
                cat ${TMP2} | sed -r "s/\x1B\[([0-9]{1,2}(;[0-9]{1,2})?)?[m|K]//g"      # Remove the colors
        fi

        printf "\n"

if [ -f ${TMP} ]
then
        if [ -n "$OUT" ]
        then
            cp $TMP $OUT
            printf "\n\t\033[1;34m%s\033[m\n\n" "Output file $OUT has been generated"
        fi
        rm -f ${TMP}
fi
if [ -f ${TMP2} ]
then
        rm -f ${TMP2}
fi

}





















EMAIL="vishalbhandwalkar@tsys.com"
export SRV_NAME="`uname -n`"


        case ${EMAIL} in "vishalbhandwalkar@tsys.com")
         echo
         echo "##############################################################################################"
         echo "You Missed Something :-)"
         echo "In order to receive the HEALTH CHECK report via Email, you have to ADD your E-mail at line# 90"
         echo "by replacing this template [vishalbhandwalkar@tsys.com] with YOUR E-mail address."
         echo "DB HEALTH CHECK report will be saved on disk..."
         echo "##############################################################################################"
         export SQLLINESIZE=165
         echo;;
         *)
         export SQLLINESIZE=200
         export OSLINESIZE=300
         ;;
        esac

SCRIPT_NAME="dbdailychk${VER}"
# In case your company Emails go through specific SMTP server. Specify it in the below line and UN-HASH it:
#export smtp="mailrelay.mycompany.com:25"       #This is an example, you have to check with your Network Admin for the SMTP NAME/PORT to use.

export MAIL_LIST="${EMAIL}"
#export MAIL_LIST="-r ${SRV_NAME} ${EMAIL}"

echo
echo "[dbdailychk Script Started ...]"

# #########################
# THRESHOLDS:
# #########################
# Send an E-mail for each THRESHOLD if been reached:
# ADJUST the following THRESHOLD VALUES as per your requirements:

HTMLENABLE=Y            # Enable HTML Email Format                                      [DB]
FSTHRESHOLD=80          # THRESHOLD FOR FILESYSTEM %USED                                [OS]
CPUTHRESHOLD=80         # THRESHOLD FOR CPU %UTILIZATION                                [OS]
TBSTHRESHOLD=80         # THRESHOLD FOR TABLESPACE %USED                                [DB]
FRATHRESHOLD=80         # THRESHOLD FOR FLASH RECOVERY AREA %USED                       [DB]
ASMTHRESHOLD=80         # THRESHOLD FOR ASM DISK GROUPS                                 [DB]
UNUSEINDXTHRESHOLD=1    # THRESHOLD FOR NUMBER OF UNUSABLE INDEXES                      [DB]
INVOBJECTTHRESHOLD=1    # THRESHOLD FOR NUMBER OF INVALID OBJECTS                       [DB]
FAILLOGINTHRESHOLD=1    # THRESHOLD FOR NUMBER OF FAILED LOGINS                         [DB]
AUDITRECOTHRESHOLD=1    # THRESHOLD FOR NUMBER OF AUDIT RECORDS                         [DB]
CORUPTBLKTHRESHOLD=1    # THRESHOLD FOR NUMBER OF CORRUPTED BLOCKS                      [DB]
FAILDJOBSTHRESHOLD=1    # THRESHOLD FOR NUMBER OF FAILED JOBS                           [DB]
JOBSRUNSINCENDAY=1      # THRESHOLD FOR JOBS RUNNING LONGER THAN N DAY                  [DB]
NEWOBJCONTTHRESHOLD=1   # THRESHOLD FOR NUMBER OF NEWLY CREATED OBJECTS                 [DB]
MODOBJCONTTHRESHOLD=1   # THRESHOLD FOR NUMBER OF MODIFIED OBJECTS                      [DB]
LONG_RUN_QUR_HOURS=1    # THRESHOLD FOR QUERIES RUNNING LONGER THAN N HOURS             [DB]
CLUSTER_CHECK=Y         # CHECK CLUSTERWARE HEALTH                                      [OS]
CHKAUDITRECORDS=Y       # CHECK DATABASE AUDIT RECORDS [increases CPU Load]             [DB]
SHOWSQLTUNINGADVISOR=N  # SHOW SQL TUNING ADVISOR RESULTS IN THE REPORT                 [DB]
SHOWMEMORYADVISORS=N    # SHOW MEMORY ADVISORS RESULTS IN THE REPORT                    [DB]
SHOWSEGMENTADVVISOR=N   # SHOW SEGMENT ADVISOR RESULTS IN THE REPORT                    [DB]
SHOWJOBS=Y              # SHOW DB JOBS DETAILS IN THE REPORT                            [DB]
SHOWHASHEDCRED=N        # SHOW DB USERS HASHED VERSION CREDENTIALS IN THE REPORT        [DB]
REPORTUNRECOVERABLE=Y   # REPORT UNRECOVERABLE DATAFILES.                               [DB]


# #######################################
# Excluded INSTANCES:
# #######################################
# Here you can mention the instances the script will IGNORE and will NOT run against:
# Use pipe "|" as a separator between each instance name.
# e.g. Excluding: -MGMTDB, ASM instances:

CRS_STAT > /tmp/crs_stat.log


EXL_DB="\-MGMTDB|ASM"           #Excluding INSTANCES [Will get excluded from the report].

# #########################
# Excluded ERRORS:
# #########################
# Here you can exclude the errors that you don't want to be alerted when they appear in the logs:
# Use pipe "|" between each error.

EXL_ALERT_ERR="ORA-2396|TNS-00507|TNS-12502|TNS-12560|TNS-12537|TNS-00505"              #Excluded ALERTLOG ERRORS [Will not get reported].
EXL_LSNR_ERR="TNS-00507|TNS-12502|TNS-12560|TNS-12537|TNS-00505"                        #Excluded LISTENER ERRORS [Will not get reported].


# ################################
# Excluded FILESYSTEM/MOUNT POINTS:
# ################################
# Here you can exclude specific filesystems/mount points from being reported by the script:
# e.g. Excluding: /dev/mapper, /dev/asm mount points:

EXL_FS="\/dev\/mapper\/|\/dev\/asm\/"                                                   #Excluded mount points [Will be skipped during the check].

# Workaround df command output bug "`/root/.gvfs': Permission denied"
if [ -f /etc/redhat-release ]
 then
  export DF='df -hPx fuse.gvfs-fuse-daemon'
 else
  export DF='df -h'
fi

# #########################
# Checking The FILESYSTEM:
# #########################

# Report Partitions that reach the threshold of Used Space:

FSLOG=/tmp/filesystem_DBA_BUNDLE.log
echo "[Reported By ${SCRIPT_NAME} Script]"      >  ${FSLOG}
echo ""                                         >> ${FSLOG}
${DF}                                           >> ${FSLOG}
${DF} | grep -v "^Filesystem" |awk '{print substr($0, index($0, $2))}'| egrep -v "${EXL_FS}"|awk '{print $(NF-1)" "$NF}'| while read OUTPUT
   do
        PRCUSED=`echo ${OUTPUT}|awk '{print $1}'|cut -d'%' -f1`
        FILESYS=`echo ${OUTPUT}|awk '{print $2}'`
                if [ ${PRCUSED} -ge ${FSTHRESHOLD} ]
                 then
mail -s "ALARM: Filesystem [${FILESYS}] on Server [${SRV_NAME}] has reached ${PRCUSED}% of USED space" ${MAIL_LIST} < ${FSLOG}
                fi
   done

rm -f ${FSLOG}


# #########################
# Getting ORACLE_SID:
# #########################
# Exit with sending Alert mail if No DBs are running:
INS_COUNT=$( ps -ef|grep pmon|grep -v grep|egrep -v ${EXL_DB}|wc -l )
        if [ $INS_COUNT -eq 0 ]
         then
         echo "[Reported By ${SCRIPT_NAME} Script]"                                             >  /tmp/oracle_processes_DBA_BUNDLE.log
         echo " "                                                                               >> /tmp/oracle_processes_DBA_BUNDLE.log
         echo "Current running INSTANCES on server [${SRV_NAME}]:"                              >> /tmp/oracle_processes_DBA_BUNDLE.log
         echo "***************************************************"                             >> /tmp/oracle_processes_DBA_BUNDLE.log
         ps -ef|grep -v grep|grep pmon                                                          >> /tmp/oracle_processes_DBA_BUNDLE.log
         echo " "                                                                               >> /tmp/oracle_processes_DBA_BUNDLE.log
         echo "Current running LISTENERS on server [${SRV_NAME}]:"                              >> /tmp/oracle_processes_DBA_BUNDLE.log
         echo "***************************************************"                             >> /tmp/oracle_processes_DBA_BUNDLE.log
         ps -ef|grep -v grep|grep tnslsnr                                                       >> /tmp/oracle_processes_DBA_BUNDLE.log
mail -s "ALARM: No Databases Are Running on Server ${SRV_NAME} !!!" ${MAIL_LIST}                <  /tmp/oracle_processes_DBA_BUNDLE.log
         rm -f /tmp/oracle_processes_DBA_BUNDLE.log
         exit
        fi

# #########################
# Setting ORACLE_SID:
# #########################
for ORACLE_SID in $( ps -ef|grep pmon|grep -v grep|egrep -v ${EXL_DB}|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )
   do
    export ORACLE_SID

# #########################
# Getting ORACLE_HOME
# #########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|egrep -v ${EXL_DB}|grep -v "\-MGMTDB"|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep -i "^${ORA_USER}:" /etc/passwd| cut -f6 -d ':'|tail -1`

# SETTING ORATAB:
if [ -f /etc/oratab ]
  then
ORATAB=/etc/oratab
export ORATAB
## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
ORATAB=/var/opt/oracle/oratab
export ORATAB
fi

# ATTEMPT1: Get ORACLE_HOME using pwdx command:
PMON_PID=`pgrep  -lf _pmon_${ORACLE_SID}|awk '{print $1}'`
export PMON_PID
ORACLE_HOME=`pwdx ${PMON_PID}|awk '{print $NF}'|sed -e 's/\/dbs//g'`
export ORACLE_HOME

# ATTEMPT2: If ORACLE_HOME not found get it from oratab file:
if [ ! -f ${ORACLE_HOME}/bin/sqlplus ]
 then
## If OS is Linux:
if [ -f /etc/oratab ]
  then
ORATAB=/etc/oratab
ORACLE_HOME=`grep -v '^\#' ${ORATAB} | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
ORATAB=/var/opt/oracle/oratab
ORACLE_HOME=`grep -v '^\#' ${ORATAB} | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
export ORACLE_HOME
fi
fi

# ATTEMPT3: If ORACLE_HOME is in /etc/oratab, use dbhome command:
if [ ! -f ${ORACLE_HOME}/bin/sqlplus ]
 then
ORACLE_HOME=`dbhome "${ORACLE_SID}"`
export ORACLE_HOME
fi

# ATTEMPT4: If ORACLE_HOME is still not found, search for the environment variable: [Less accurate]
if [ ! -f ${ORACLE_HOME}/bin/sqlplus ]
 then
ORACLE_HOME=`env|grep -i ORACLE_HOME|sed -e 's/ORACLE_HOME=//g'`
export ORACLE_HOME
fi

# ATTEMPT5: If ORACLE_HOME is not found in the environment search user's profile: [Less accurate]
if [ ! -f ${ORACLE_HOME}/bin/sqlplus ]
 then
ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' ${USR_ORA_HOME}/.bash_profile ${USR_ORA_HOME}/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
export ORACLE_HOME
fi

# ATTEMPT6: If ORACLE_HOME is still not found, search for orapipe: [Least accurate]
if [ ! -f ${ORACLE_HOME}/bin/sqlplus ]
 then
        if [ -x /usr/bin/locate ]
         then
ORACLE_HOME=`locate -i orapipe|head -1|sed -e 's/\/bin\/orapipe//g'`
export ORACLE_HOME
        fi
fi

# TERMINATE: If all above attempts failed to get ORACLE_HOME location, EXIT the script:
if [ ! -f ${ORACLE_HOME}/bin/sqlplus ]
 then
  echo "Please export ORACLE_HOME variable in your .bash_profile file under oracle user home directory in order to get this script to run properly"
  echo "e.g."
  echo "export ORACLE_HOME=/u01/app/oracle/product/11.2.0/db_1"
mail -s "dbdailychk script on Server [${SRV_NAME}] failed to locate ORACLE_HOME for SID [${ORACLE_SID}], Please export ORACLE_HOME variable in your .bash_profile file under oracle user home directory" ${MAIL_LIST} < /dev/null
exit
fi

# #############################
# Getting hostname in lowercase:
# #############################
HOSTNAMELOWER=$( echo "`hostname --short`"| tr '[A-Z]' '[a-z]' )
export HOSTNAMELOWER

# ########################
# Getting GRID_HOME:
# ########################

CHECK_OCSSD=`ps -ef|grep 'ocssd.bin'|grep -v grep|wc -l`
CHECK_CRSD=`ps -ef|grep 'crsd.bin'|grep -v grep|wc -l`

 if [ ${CHECK_OCSSD} -gt 0 ]
  then
GRID_HOME=`ps -ef|grep 'ocssd.bin'|grep -v grep|awk '{print $NF}'|sed -e 's/\/bin\/ocssd.bin//g'|grep -v sed|grep -v "//g"|tail -1`
export GRID_HOME

        if [ ! -d ${GRID_HOME} ]
         then
ASM_INSTANCE_NAME=`ps -ef|grep pmon|grep -v grep|grep asm_pmon_|awk '{print $NF}'|sed -e 's/asm_pmon_//g'|grep -v sed|grep -v "s///g"|tail -1`
GRID_HOME=`dbhome ${ASM_INSTANCE_NAME}`
export GRID_HOME
        fi

# ########################
# Getting GRID_BASE:
# ########################

# Locating GRID_BASE:

GRID_BASE=`cat ${GRID_HOME}/crs/install/crsconfig_params|grep ^ORACLE_BASE|tail -1|awk '{print $NF}'|sed -e 's/ORACLE_BASE=//g'`
export GRID_BASE

        if [ ! -d ${GRID_BASE} ]
         then
GRID_BASE=`cat ${GRID_HOME}/crs/utl/appvipcfg|grep ^ORACLE_BASE|tail -1|awk '{print $NF}'|sed -e 's/ORACLE_BASE=//g'`
export GRID_BASE
        fi

        if [ ! -d ${GRID_BASE} ]
         then
GRID_BASE=`cat ${GRID_HOME}/install/envVars.properties|grep ^ORACLE_BASE|tail -1|awk '{print $NF}'|sed -e 's/ORACLE_BASE=//g'`
export GRID_BASE
        fi
 fi

# #########################
# Variables:
# #########################
export PATH=${PATH}:${ORACLE_HOME}/bin
export LOG_DIR=${USR_ORA_HOME}/BUNDLE_Logs
mkdir -p ${LOG_DIR}
chown -R ${ORA_USER} ${LOG_DIR}
chmod -R go-rwx ${LOG_DIR}

        if [ ! -d ${LOG_DIR} ]
         then
          mkdir -p /tmp/BUNDLE_Logs
          export LOG_DIR=/tmp/BUNDLE_Logs
          chown -R ${ORA_USER} ${LOG_DIR}
          chmod -R go-rwx ${LOG_DIR}
        fi

cat /dev/null > ${LOG_DIR}/dbdailychk.part.log
export LOGFILE=${LOG_DIR}/dbdailychk.part.log

# #########################
# HTML Preparation:
# #########################
   case ${HTMLENABLE} in
   y|Y|yes|YES|Yes|ON|On|on)
        if [ -x /usr/sbin/sendmail ]
        then
export SENDMAIL="/usr/sbin/sendmail -t"
export MAILEXEC="echo #"
export HASHHTML=""
export HASHNONHTML="--"
export HASHHTMLOS=""
export HASHNOHTMLOS="echo #"
SENDMAILARGS=$(
echo "To:           ${EMAIL};"
echo "Subject:      ${MSGSUBJECT} ;"
echo "Content-Type: text/html;"
echo "MIME-Version: 1.0;"
cat ${LOGFILE}
)
export SENDMAILARGS
        else
export SENDMAIL="echo #"
export MAILEXEC="mail -s"
export HASHHTML="--"
export HASHNONHTML=""
export HASHHTMLOS="echo #"
export HASHNOHTMLOS=""
        fi
   ;;
   *)
export SENDMAIL="echo #"
export HASHHTML="--"
export HASHNONHTML=""
export HASHHTMLOS="echo #"
export HASHNOHTMLOS=""
export MAILEXEC="mail -s"
   ;;
   esac

export LOGFILE=${LOG_DIR}/dbdailychk.part.log
export SRV_NAME="`uname -n`"


# ########################
# Getting ORACLE_BASE:
# ########################
# Get ORACLE_BASE from user's profile if it EMPTY:

if [ ! -d "${ORACLE_BASE}" ]
 then
ORACLE_BASE=`cat ${ORACLE_HOME}/install/envVars.properties|grep ^ORACLE_BASE|tail -1|awk '{print $NF}'|sed -e 's/ORACLE_BASE=//g'`
export ORACLE_BASE
fi

if [ ! -d "${ORACLE_BASE}" ]
 then
ORACLE_BASE=`grep -h 'ORACLE_BASE=\/' ${USR_ORA_HOME}/.bash* ${USR_ORA_HOME}/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
export ORACLE_BASE
fi


# #########################
# Getting DB_NAME:
# #########################
DB_NAME_RAW=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" <<EOF
set pages 0 feedback off lines 1000;
prompt
SELECT name from v\$database;
exit;
EOF
)
# Getting DB_NAME in Uppercase & Lowercase:
DB_NAME_UPPER=`echo ${DB_NAME_RAW}| perl -lpe'$_ = reverse' |awk '{print $1}'|perl -lpe'$_ = reverse'`
DB_NAME_LOWER=$( echo "${DB_NAME_UPPER}" | tr -s  '[:upper:]' '[:lower:]' )
export DB_NAME_UPPER
export DB_NAME_LOWER

export DB_NAME=${DB_NAME_UPPER}


# #########################
# Getting DB_UNQ_NAME:
# #########################
VAL121=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" <<EOF
set pages 0 feedback off;
prompt
select value from v\$parameter where name='db_unique_name';
exit;
EOF
)
# Getting DB_NAME in Uppercase & Lowercase:
DB_UNQ_NAME=`echo ${VAL121}| perl -lpe'$_ = reverse' |awk '{print $1}'|perl -lpe'$_ = reverse'`
export DB_UNQ_NAME

# In case DB_UNQ_NAME variable is empty then use DB_NAME instead:
case ${DB_UNQ_NAME} in
'') DB_UNQ_NAME=${DB_NAME}; export DB_UNQ_NAME;;
esac


        if [ -d ${ORACLE_BASE}/diag/rdbms/${DB_NAME_UPPER} ]
        then
                DB_NAME=${DB_NAME_UPPER}
        fi

        if [ -d ${ORACLE_BASE}/diag/rdbms/${DB_NAME_LOWER} ]
        then
                DB_NAME=${DB_NAME_LOWER}
        fi

        if [ -d ${ORACLE_BASE}/diag/rdbms/${DB_UNQ_NAME} ]
        then
                DB_NAME=${DB_UNQ_NAME}
        fi

export DB_NAME


# ###################
# Checking DB Version:
# ###################

VAL311=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" <<EOF
set pages 0 feedback off;
prompt
select version from v\$instance;
exit;
EOF
)
DB_VER=`echo ${VAL311}|perl -lpe'$_ = reverse' |awk '{print $1}'|perl -lpe'$_ = reverse'|cut -f1 -d '.'`


# #####################
# Getting DB Block Size:
# #####################
VAL302=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" <<EOF
set pages 0 feedback off;
prompt
select value from v\$parameter where name='db_block_size';
exit;
EOF
)
blksize=`echo ${VAL302}|perl -lpe'$_ = reverse' |awk '{print $1}'|perl -lpe'$_ = reverse'|cut -f1 -d '.'`


# #####################
# Getting DB ROLE:
# #####################
VAL312=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" <<EOF
set pages 0 feedback off lines 1000;
prompt
select DATABASE_ROLE from v\$database;
exit;
EOF
)
DB_ROLE=`echo ${VAL312}|perl -lpe'$_ = reverse' |awk '{print $1}'|perl -lpe'$_ = reverse'|cut -f1 -d '.'`

        case ${DB_ROLE} in
         PRIMARY)
export DB_ROLE_ID=0
        ;;
               *)
export DB_ROLE_ID=1
# Disable the reporting of BLOCKED Sessions if the DB Role is not a PRIMARY:
export BLOCKTHRESHOLD=100000
        ;;
        esac

export SRV_NAME="`uname -n`"


# ############################################
# Checking LONG RUNNING DB JOBS:
# ############################################
VAL410=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" << EOF
set pages 0 feedback off echo off;
--SELECT count(*) from dba_scheduler_running_jobs where extract(day FROM elapsed_time) > ${JOBSRUNSINCENDAY} and SESSION_ID is not null;
SELECT count(*) from dba_scheduler_running_jobs where extract(day FROM elapsed_time) > ${JOBSRUNSINCENDAY};
exit;
EOF
)
VAL510=`echo ${VAL410} | awk '{print $NF}'`
                if [ ${VAL510} -ge 1 ]
                 then
VAL610=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" << EOF
set linesize ${SQLLINESIZE} pages 1000
-- Enable HTML color format:
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
spool ${LOGFILE}
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT Long Running Jobs [${ORACLE_SID}]
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT Long Running Jobs: [${ORACLE_SID}]
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^
col INS for 999
col "JOB_NAME|OWNER|SPID|SID" for a55
col ELAPSED_TIME for a17
col CPU_USED for a17
col "WAIT_SEC"  for 9999999999
col WAIT_CLASS for a15
col "BLKD_BY" for 9999999
col "WAITED|WCLASS|EVENT"       for a45
select j.RUNNING_INSTANCE INS,j.JOB_NAME ||' | '|| j.OWNER||' |'||SLAVE_OS_PROCESS_ID||'|'||j.SESSION_ID"JOB_NAME|OWNER|SPID|SID"
,s.FINAL_BLOCKING_SESSION "BLKD_BY",ELAPSED_TIME,CPU_USED
,substr(s.SECONDS_IN_WAIT||'|'||s.WAIT_CLASS||'|'||s.EVENT,1,45) "WAITED|WCLASS|EVENT",S.SQL_ID
from dba_scheduler_running_jobs j, gv\$session s
where   j.RUNNING_INSTANCE=S.INST_ID(+)
and     j.SESSION_ID=S.SID(+)
and     extract(day FROM elapsed_time) > ${JOBSRUNSINCENDAY}
order by "JOB_NAME|OWNER|SPID|SID",ELAPSED_TIME;
spool off
exit;
EOF
)

#mail -s "WARNING: JOBS running for more than ${JOBSRUNSINCENDAY} day detected on database [${DB_NAME_UPPER}] on Server [${SRV_NAME}]" ${MAIL_LIST} < ${LOG_DIR}/long_running_jobs.log
export MSGSUBJECT="WARNING: JOBS running for more than ${JOBSRUNSINCENDAY} day detected on database [${DB_NAME_UPPER}] on Server [${SRV_NAME}]"

#SENDMAILARGS=$(
#echo "To:           ${EMAIL};"
#echo "Subject:      ${MSGSUBJECT} ;"
#echo "Content-Type: text/html;"
#echo "MIME-Version: 1.0;"
#cat ${LOGFILE}
#)

${MAILEXEC} "${MSGSUBJECT}" ${MAIL_LIST} < ${LOGFILE}
#echo ${SENDMAILARGS} | tr \; '\n' |awk 'length == 1 || NR == 1 {print $0} length && NR > 1 { print substr($0,2) }'| ${SENDMAIL}

(
echo "To: ${EMAIL};"
echo "MIME-Version: 1.0"
echo "Content-Type: text/html;"
echo "Subject: ${MSGSUBJECT}"
cat ${LOGFILE}
) | ${SENDMAIL}

cat /dev/null > ${LOGFILE}
                fi



# ############################################
# LOGFILE SETTINGS:
# ############################################

# Logfile path variable:
DB_HEALTHCHK_RPT=${LOG_DIR}/${DB_NAME_UPPER}_HEALTH_CHECK_REPORT.log
OS_HEALTHCHK_RPT=${LOG_DIR}/OS_HEALTH_CHECK_REPORT.log
export DB_HEALTHCHK_RPT

# Flush the logfile:
cat /dev/null > ${OS_HEALTHCHK_RPT}



# ############################################
# Checking RAC/ORACLE_RESTART Services:
# ############################################

                case ${CLUSTER_CHECK} in
                y|Y|yes|YES|Yes|ON|On|on)

# Check for ocssd clusterware process:
CHECK_OCSSD=`ps -ef|grep 'ocssd.bin'|grep -v grep|wc -l`
CHECK_CRSD=`ps -ef|grep 'crsd.bin'|grep -v grep|wc -l`

if [ ${CHECK_CRSD} -gt 0 ]
then
 CLS_STR=crs
 export CLS_STR
 CLUSTER_TYPE=CLUSTERWARE
 export CLUSTER_TYPE
else
 CLS_STR=has
 export CLS_STR
 CLUSTER_TYPE=ORACLE_RESTART
 export CLUSTER_TYPE
fi

        if [ ${CHECK_CRSD} -gt 0 ]
         then

GRID_HOME=`ps -ef|grep 'ocssd.bin'|grep -v grep|awk '{print $NF}'|sed -e 's/\/bin\/ocssd.bin//g'|grep -v sed|grep -v "//g"`
export GRID_HOME



fi

        if [ ${CHECK_OCSSD} -gt 0 ]
         then

GRID_HOME=`ps -ef|grep 'ocssd.bin'|grep -v grep|awk '{print $NF}'|sed -e 's/\/bin\/ocssd.bin//g'|grep -v sed|grep -v "//g"`
export GRID_HOME

        fi
                ;;
                esac


                                echo ""                                                                 >> ${OS_HEALTHCHK_RPT}


echo "^^^^^^^^^^^^^^^^^"                                                >> ${OS_HEALTHCHK_RPT}
echo "CLUSTER STATUS:"                                                >> ${OS_HEALTHCHK_RPT}
echo "^^^^^^^^^^^^^^^^^"                                                >> ${OS_HEALTHCHK_RPT}

cat  /tmp/crs_stat.log  >> ${OS_HEALTHCHK_RPT}

echo ""                                                                 >> ${OS_HEALTHCHK_RPT}
echo "^^^^^^^^^^^^^^^^^"                                                >> ${OS_HEALTHCHK_RPT}
echo "Local_Filesystem:"                                                >> ${OS_HEALTHCHK_RPT}
echo "^^^^^^^^^^^^^^^^^"                                                >> ${OS_HEALTHCHK_RPT}


OLSNODES=`${GRID_HOME}/bin/./olsnodes`
for I in $OLSNODES
do
export OLDNODE=$I
echo ""                                                                                                                                                 >> ${OS_HEALTHCHK_RPT}
echo "$I :"                                                                                                     >> ${OS_HEALTHCHK_RPT}
echo ""
echo "Filesystem                      Size  Used Avail Use% Mounted on "    >> ${OS_HEALTHCHK_RPT}                                                     >> ${OS_HEALTHCHK_RPT}
ssh $OLDNODE ${DF} |awk '+$5 >= 80 {print}'                                                                                                      >> ${OS_HEALTHCHK_RPT}
done
echo ""                                                                 >> ${OS_HEALTHCHK_RPT}

# Convert OS Checks into HTML format:
${HASHHTMLOS} awk 'BEGIN { print "<table borader=1>"} {print "<tr>"; for(i=1;i<=NF;i++)print "<td><FONT COLOR=BROWN FACE="Times New Roman" SIZE=${FONTSIZE}>" $i"</FONT></td>"; print "</tr>"} END{print "</table>" }' ${OS_HEALTHCHK_RPT} > ${DB_HEALTHCHK_RPT}

        case ${HASHHTMLOS} in
        'echo #')
cat ${OS_HEALTHCHK_RPT} > ${DB_HEALTHCHK_RPT}
        esac


# If the database version is 10g onward collect the advisors recommendations:
        if [ ${DB_VER} -gt 9 ]
         then

VAL611=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" << EOF
set linesize ${SQLLINESIZE} pages 100
-- Enable HTML color format:
--${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { background: #E67E22; font-size: 80%; } th { font:bold 9pt Arial,Helvetica,sans-serif; align: left; color: #FFFFFF; background: #AF601A; } td { font:9pt; background: #FFFFFF; padding: 0px; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
spool ${DB_HEALTHCHK_RPT} app
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT Tablespaces Size
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT Tablespaces Size:  [Based on Datafiles MAXSIZE]
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^
set pages 1000 linesize ${SQLLINESIZE} tab off
col tablespace_name for A25
col Total_MB for 999999999999
col Used_MB for 999999999999
col '%Used' for 999.99
comp sum of Total_MB on report
comp sum of Used_MB   on report
bre on report
select tablespace_name,
       (tablespace_size*$blksize)/(1024*1024) Total_MB,
       (used_space*$blksize)/(1024*1024) Used_MB,
      -- used_percent "%Used"
case when used_percent > 90 then '<span style="background-color:#E67E22;display:block;overflow:auto">' || to_char(used_percent,999.99) || '</span>' else to_char(used_percent,999.99) end as "%Used"
from dba_tablespace_usage_metrics where used_percent > 90 ;

${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT ASM STATISTICS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT ASM STATISTICS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^
select name,state,OFFLINE_DISKS,total_mb,free_mb
,case when ROUND((1-(free_mb / total_mb))*100, 2) > 90 then '<span style="background-color:#E67E22;display:block;overflow:auto">' || to_char(ROUND((1-(free_mb / total_mb))*100, 2),999.99) || '</span>' else to_char(ROUND((1-(free_mb / total_mb))*100, 2),999.99) end as "%FULL"
from v\$asm_diskgroup order by "%FULL" desc ;
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT Active Incidents
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT Active Incidents:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^
set linesize ${SQLLINESIZE}
col RECENT_PROBLEMS_1_WEEK_BACK for a45
select PROBLEM_KEY RECENT_PROBLEMS_1_WEEK_BACK,to_char(FIRSTINC_TIME,'DD-MON-YY HH24:mi:ss') FIRST_OCCURENCE,to_char(LASTINC_TIME,'DD-MON-YY HH24:mi:ss')
LAST_OCCURENCE FROM V\$DIAG_PROBLEM WHERE LASTINC_TIME > SYSDATE -10;
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT OUTSTANDING ALERTS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT OUTSTANDING ALERTS:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^
col CREATION_TIME for a40
col REASON for a80
select REASON,CREATION_TIME,METRIC_VALUE from DBA_OUTSTANDING_ALERTS;
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT CORRUPTED BLOCKS
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} ${HASHJ}PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} ${HASHJ}PROMPT SCHEDULED JOBS STATUS
${HASHHTML} ${HASHJ}PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} ${HASHJ}PROMPT <p> <table border='1' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} ${HASHJ}PROMPT DBMS_JOBS
${HASHHTML} ${HASHJ}PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} ${HASHJ}PROMPT
${HASHNONHTML} ${HASHJ}PROMPT ^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} ${HASHJ}PROMPT SCHEDULED JOBS STATUS:
${HASHNONHTML} ${HASHJ}PROMPT ^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} ${HASHJ}PROMPT
${HASHNONHTML} ${HASHJ}PROMPT DBMS_JOBS:
${HASHNONHTML} ${HASHJ}PROMPT ^^^^^^^^^^
${HASHJ}set linesize ${SQLLINESIZE}
${HASHJ}col LAST_RUN for a25
${HASHJ}col NEXT_RUN for a25
${HASHJ}select job,schema_user,failures,to_char(LAST_DATE,'DD-Mon-YYYY hh24:mi:ss')LAST_RUN,to_char(NEXT_DATE,'DD-Mon-YYYY hh24:mi:ss')NEXT_RUN from dba_jobs WHERE schema_user NOT IN  ('SYS','SYSTEM','OUTLN','DIP','ORACLE_OCM','DBSNMP','APPQOSSYS','WMSYS','EXFSYS','CTXSYS','XDB','ANONYMOUS','ORDSYS','ORDDATA','MDSYS','SI_INFORMTN_SCHEMA','ORDPLUGINS','OLAPSYS','MDDATA','SPATIAL_WFS_ADMIN_USR','SPATIAL_CSW_ADMIN_USR','SYSMAN','MGMT_VIEW','FLOWS_FILES','APEX_PUBLIC_USER','APEX_030200','OWBSYS','OWBSYS_AUDIT','SCOTT','RCHAUDHARI','GGATE') ;
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} ${HASHJ}PROMPT <br> <p> <table border='1' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} ${HASHJ}PROMPT FAILED DBMS_SCHEDULER JOBS IN THE LAST 24H
${HASHHTML} ${HASHJ}PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} ${HASHJ}PROMPT
${HASHNONHTML} ${HASHJ}PROMPT FAILED DBMS_SCHEDULER JOBS IN THE LAST 24H:
${HASHNONHTML} ${HASHJ}PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHJ}col LOG_DATE for a36
${HASHJ}col OWNER for a15
${HASHJ}col JOB_NAME for a35
${HASHJ}col STATUS for a11
${HASHJ}col RUN_DURATION for a20
${HASHJ}col ID for 99
${HASHJ}select INSTANCE_ID ID,JOB_NAME,OWNER,LOG_DATE,STATUS,ERROR#,RUN_DURATION from DBA_SCHEDULER_JOB_RUN_DETAILS where LOG_DATE > sysdate-1 and STATUS='FAILED' AND OWNER NOT IN ('SYS','SYSTEM','OUTLN','DIP','ORACLE_OCM','DBSNMP','APPQOSSYS','WMSYS','EXFSYS','CTXSYS','XDB','ANONYMOUS','ORDSYS','ORDDATA','MDSYS','SI_INFORMTN_SCHEMA','ORDPLUGINS','OLAPSYS','MDDATA','SPATIAL_WFS_ADMIN_USR','SPATIAL_CSW_ADMIN_USR','SYSMAN','MGMT_VIEW','FLOWS_FILES','APEX_PUBLIC_USER','APEX_030200','OWBSYS','OWBSYS_AUDIT','SCOTT','RCHAUDHARI','GGATE') order by JOB_NAME,LOG_DATE;
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT Queries Running For More Than [${LONG_RUN_QUR_HOURS}] Hours
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT Queries Running For More Than [${LONG_RUN_QUR_HOURS}] 3 Minute:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col module for a30
col DURATION_HOURS for 99999.9
col STARTED_AT for a13
col "USERNAME| SID,SERIAL#" for a30
${HASHNONHTML} col "SQL_ID | SQL_TEXT" for a120
select username||'| '||sid ||','|| serial# "USERNAME| SID,SERIAL#",substr(MODULE,1,30) "MODULE", to_char(sysdate-last_call_et/24/60/60,'DD-MON HH24:MI') STARTED_AT,
last_call_et/60/60 "DURATION_HOURS"
--||' | '|| (select SQL_FULLTEXT from v\$sql where address=sql_address) "SQL_ID | SQL_TEXT"
,SQL_ID
from v\$session where
username is not null
and module is not null
and last_call_et > 60*3*${LONG_RUN_QUR_HOURS}
and status = 'ACTIVE';
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT TOP FRAGMENTED TABLES:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT TOP FRAGMENTED TABLES
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
col "%RECLAIMABLE_SPACE" for 99
col owner                for a30
col "%FRAGMENTED_SPACE"  for a17
col LAST_ANALYZED for a13
select * from (select owner,table_name,to_char(LAST_ANALYZED, 'DD-MON-YYYY') LAST_ANALYZED,
round(blocks * ${blksize}/1024/1024)     "FULL_SIZE_MB",
round(num_rows * avg_row_len/1024/1024)  "ACTUAL_SIZE_MB",
round(blocks * ${blksize}/1024/1024) - round(num_rows * avg_row_len/1024/1024) "FRAGMENTED_SPACE_MB",
round(((round((blocks * ${blksize}/1024/1024), 2) - round((num_rows * avg_row_len/1024/1024), 2)) / round((blocks * ${blksize}/1024/1024), 2)) * 100)||'%' "%FRAGMENTED_SPACE"
from dba_tables
where blocks>10
and round(blocks * ${blksize}/1024/1024) > 10
-- Fragmented Space must be > 30%:
and ((round((blocks * ${blksize}/1024/1024), 2) - round((num_rows * avg_row_len/1024/1024), 2)) / round((blocks * ${blksize}/1024/1024), 2)) * 100 > 30
order by "FRAGMENTED_SPACE_MB" desc) where rownum<11;
PROMPT Hint: The accuracy of FRAGMENTED TABLES list depends on having a recent STATISTICS.
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT RESOURCE LIMIT
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT RESOURCE LIMIT:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^
col INITIAL_ALLOCATION for a20
col LIMIT_VALUE for a20
select * from gv\$resource_limit where resource_name in ('sessions','processes','transactions') order by RESOURCE_NAME;
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT Monitored INDEXES
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT Monitored INDEXES:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^
set linesize ${SQLLINESIZE} pages 1000
col Index_NAME for a40
col TABLE_NAME for a40
        select io.name Index_NAME, t.name TABLE_NAME,decode(bitand(i.flags, 65536),0,'NO','YES') Monitoring,
        decode(bitand(ou.flags, 1),0,'NO','YES') USED,ou.start_monitoring,ou.end_monitoring
        from sys.obj$ io,sys.obj$ t,sys.ind$ i,sys.object_usage ou where i.obj# = ou.obj# and io.obj# = ou.obj# and t.obj# = i.bo#;
--PROMPT
--PROMPT To stop monitoring USED indexes use this command:
--prompt select 'ALTER INDEX RA.'||io.name||' NOMONITORING USAGE;' from sys.obj$ io,sys.obj$ t,sys.ind$ i,sys.object_usage ou where i.obj# = ou.obj# and io.obj# = ou.obj# and t.obj# = i.bo#
--prompt and decode(bitand(i.flags, 65536),0,'NO','YES')='YES' and decode(bitand(ou.flags, 1),0,'NO','YES')='YES' order by 1
--prompt /
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='20%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT REDO LOG SWITCHES
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT REDO LOG SWITCHES:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^
set linesize ${SQLLINESIZE}
col day for a11
SELECT to_char(first_time,'YYYY-MON-DD') day,
to_char(sum(decode(to_char(first_time,'HH24'),'00',1,0)),'9999') "00",
to_char(sum(decode(to_char(first_time,'HH24'),'01',1,0)),'9999') "01",
to_char(sum(decode(to_char(first_time,'HH24'),'02',1,0)),'9999') "02",
to_char(sum(decode(to_char(first_time,'HH24'),'03',1,0)),'9999') "03",
to_char(sum(decode(to_char(first_time,'HH24'),'04',1,0)),'9999') "04",
to_char(sum(decode(to_char(first_time,'HH24'),'05',1,0)),'9999') "05",
to_char(sum(decode(to_char(first_time,'HH24'),'06',1,0)),'9999') "06",
to_char(sum(decode(to_char(first_time,'HH24'),'07',1,0)),'9999') "07",
to_char(sum(decode(to_char(first_time,'HH24'),'08',1,0)),'9999') "08",
to_char(sum(decode(to_char(first_time,'HH24'),'09',1,0)),'9999') "09",
to_char(sum(decode(to_char(first_time,'HH24'),'10',1,0)),'9999') "10",
to_char(sum(decode(to_char(first_time,'HH24'),'11',1,0)),'9999') "11",
to_char(sum(decode(to_char(first_time,'HH24'),'12',1,0)),'9999') "12",
to_char(sum(decode(to_char(first_time,'HH24'),'13',1,0)),'9999') "13",
to_char(sum(decode(to_char(first_time,'HH24'),'14',1,0)),'9999') "14",
to_char(sum(decode(to_char(first_time,'HH24'),'15',1,0)),'9999') "15",
to_char(sum(decode(to_char(first_time,'HH24'),'16',1,0)),'9999') "16",
to_char(sum(decode(to_char(first_time,'HH24'),'17',1,0)),'9999') "17",
to_char(sum(decode(to_char(first_time,'HH24'),'18',1,0)),'9999') "18",
to_char(sum(decode(to_char(first_time,'HH24'),'19',1,0)),'9999') "19",
to_char(sum(decode(to_char(first_time,'HH24'),'20',1,0)),'9999') "20",
to_char(sum(decode(to_char(first_time,'HH24'),'21',1,0)),'9999') "21",
to_char(sum(decode(to_char(first_time,'HH24'),'22',1,0)),'9999') "22",
to_char(sum(decode(to_char(first_time,'HH24'),'23',1,0)),'9999') "23"
from v\$log_history where first_time > sysdate-1
GROUP by to_char(first_time,'YYYY-MON-DD') order by 1 asc;
${HASHHTML} PROMPT <br>
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='35%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT Modified Parameters Since The Instance Startup
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} PROMPT
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} PROMPT Modified Parameters Since The Instance Startup:
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
col name for a45
col VALUE for a80
col DEPRECATED for a10
select NAME,VALUE,ISDEFAULT "DEFAULT",ISDEPRECATED "DEPRECATED" from v\$parameter where ISMODIFIED = 'SYSTEM_MOD' and name not in ('local_listener','remote_listener','service_names')order by 1;
${HASHHTML} PROMPT <br>
spool off
exit;
EOF
)

        fi

# #################################################
# Reporting New Created Objects in the last 24Hours:
# #################################################
NEWOBJCONTRAW=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" << EOF
set pages 0 feedback off echo off;
select count(*) from dba_objects
where created > sysdate-1
and owner <> 'SYS';
exit;
EOF
)
NEWOBJCONT=`echo ${NEWOBJCONTRAW} | awk '{print $NF}'`
                if [ ${NEWOBJCONT} -ge ${NEWOBJCONTTHRESHOLD} ]
                 then
VALNEWOBJCONT=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" << EOF
set linesize ${SQLLINESIZE} pages 1000
-- Enable HTML color format:
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
spool ${DB_HEALTHCHK_RPT} app
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT New Created objects [Last 24H]
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} prompt
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} prompt New Created objects [Last 24H] ...
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} prompt
col owner for a30
col object_name for a30
col object_type for a19
col created for a20
select object_type,owner,object_name,to_char(created, 'DD-Mon-YYYY HH24:MI:SS') CREATED from dba_objects
where created > sysdate-1
and owner not in ('SYS','SYSTEM','OUTLN','DIP','ORACLE_OCM','DBSNMP','APPQOSSYS','WMSYS','EXFSYS','CTXSYS','XDB','ANONYMOUS','ORDDATA','MDSYS','SI_INFORMTN_SCHEMA','ORDPLUGINS','OLAPSYS','MDDATA','SPATIAL_WFS_ADMIN_USR','SPATIAL_CSW_ADMIN_USR','SYSMAN','MGMT_VIEW','FLOWS_FILES','APEX_PUBLIC_USER','APEX_030200','OWBSYS','OWBSYS_AUDIT','SCOTT','RCHAUDHARI','GGATE')
order by owner,object_type;
spool off
exit;
EOF
)
                fi

# ###############################################
# Reporting Modified Objects in the last 24Hours:
# ###############################################
MODOBJCONTRAW=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" << EOF
set pages 0 feedback off echo off;
select count(*) from dba_objects
where LAST_DDL_TIME > sysdate-1
and owner <> 'SYS';
exit;
EOF
)
MODOBJCONT=`echo ${MODOBJCONTRAW} | awk '{print $NF}'`
                if [ ${MODOBJCONT} -ge ${MODOBJCONTTHRESHOLD} ]
                 then
VALMODOBJCONT=$(${ORACLE_HOME}/bin/sqlplus -S "/ as sysdba" << EOF
set linesize ${SQLLINESIZE} pages 1000
-- Enable HTML color format:
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
spool ${DB_HEALTHCHK_RPT} app
${HASHHTML} SET PAGES 0
${HASHHTML} SET MARKUP HTML OFF SPOOL OFF
${HASHHTML} PROMPT <br> <p> <table border='3' bordercolor='#E67E22' width='30%' align='left' summary='Script output'> <tr> <th scope="col">
${HASHHTML} PROMPT Modified objects in the Last 24H
${HASHHTML} PROMPT </td> </tr> </table> <p> <br>
${HASHHTML} SET WRAP OFF ECHO OFF FEEDBACK OFF MARKUP HTML ON SPOOL ON HEAD '<title></title> <style type="text/css"> table { font-size: 80%; } th { background: #AF601A; } </style>' TABLE "border='2' bordercolor='#E67E22'" ENTMAP OFF
${HASHHTML} set pages 1000
${HASHNONHTML} prompt
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} prompt Modified objects in the Last 24H ...
${HASHNONHTML} PROMPT ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
${HASHNONHTML} prompt
col owner for a30
col object_name for a30
col object_type for a19
col LAST_DDL_TIME for a20
select object_type,owner,object_name,to_char(LAST_DDL_TIME, 'DD-Mon-YYYY HH24:MI:SS') LAST_DDL_TIME from dba_objects
where LAST_DDL_TIME > sysdate-1
and owner NOT IN ('SYS','SYSTEM','OUTLN','DIP','ORACLE_OCM','DBSNMP','APPQOSSYS','WMSYS','EXFSYS','CTXSYS','XDB','ANONYMOUS','ORDSYS','ORDDATA','MDSYS','SI_INFORMTN_SCHEMA','ORDPLUGINS','OLAPSYS','MDDATA','SPATIAL_WFS_ADMIN_USR','SPATIAL_CSW_ADMIN_USR','SYSMAN','MGMT_VIEW','FLOWS_FILES','APEX_PUBLIC_USER','APEX_030200','OWBSYS','OWBSYS_AUDIT','SCOTT','RCHAUDHARI','GGATE')
order by owner,object_type;
spool off
exit;
EOF
)
                fi


export LOGFILE=${DB_HEALTHCHK_RPT}
export MSGSUBJECT="HEALTH CHECK REPORT: For Database [${DB_NAME_UPPER}] on Server [${SRV_NAME}]"
echo ${MSGSUBJECT}

${MAILEXEC} "${MSGSUBJECT}" ${MAIL_LIST} < ${LOGFILE}

(
echo "To: ${EMAIL};"
echo "MIME-Version: 1.0"
echo "Content-Type: text/html;"
echo "Subject: ${MSGSUBJECT}"
cat ${LOGFILE}
) | ${SENDMAIL}



echo "HEALTH CHECK REPORT FOR DATABASE [${DB_NAME_UPPER}] WAS SAVED TO: ${DB_HEALTHCHK_RPT}"
        done

echo ""



# #############
# END OF SCRIPT
# #############


