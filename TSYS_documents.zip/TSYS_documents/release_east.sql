STEP 1: 
"

http://10.132.13.131:6280/jenkins/ 

- from backup  data center (DCE) to primary data center (DCW)
- from primary  data center (DCW)to  backup data center (DCE)"



GGSCI (epl1trandbrpt1.tsysacquiring.org) 2> INFO ALL

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRE        00:00:01      00:00:05
EXTRACT     STOPPED     PPRERW      00:00:00      00:02:18
REPLICAT    STOPPED     RPRERW      00:00:00      00:02:17
REPLICAT    RUNNING     RPRETE01    00:00:00      00:00:00
REPLICAT    RUNNING     RPRETELG    00:00:00      00:00:00
REPLICAT    STOPPED     RPRETW01    00:00:00      00:02:16
REPLICAT    STOPPED     RPRETWLG    00:00:00      00:02:15


GGSCI (epl1trandbtxn1.tsysacquiring.org) 2> INFO ALL

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTE        00:00:04      00:00:01
EXTRACT     RUNNING     PPTERE      00:00:00      00:00:06
EXTRACT     STOPPED     PPTERW      00:00:00      00:02:18
EXTRACT     STOPPED     PPTETW      00:00:00      00:02:18
REPLICAT    STOPPED     RPTETW01    00:00:00      00:02:18
REPLICAT    STOPPED     RPTETWLG    00:00:00      00:02:17


GGSCI (wpl1trandbrpt1.tsysacquiring.org) 2> INFO ALL

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRW        00:00:00      00:00:07
EXTRACT     STOPPED     PPRWRE      00:00:00      00:02:18
REPLICAT    STOPPED     RPRWRE      00:00:00      00:02:18
REPLICAT    STOPPED     RPRWTE01    00:00:00      00:02:18
REPLICAT    STOPPED     RPRWTELG    00:00:00      00:02:18
REPLICAT    RUNNING     RPRWTW01    00:00:00      00:00:00
REPLICAT    RUNNING     RPRWTWLG    00:00:00      00:00:00


GGSCI (wpl1trandbtxn1.tsysacquiring.org) 2> INFO ALL

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTW        00:00:03      00:00:05
EXTRACT     STOPPED     PPTWRE      00:00:03      00:02:17
EXTRACT     RUNNING     PPTWRW      00:00:03      00:00:04
EXTRACT     STOPPED     PPTWTE      00:00:00      00:02:15
REPLICAT    STOPPED     RPTWTE01    00:00:00      00:02:14
REPLICAT    STOPPED     RPTWTELG    00:00:00      00:02:14







step 2 : START FROM DCW TO DCE THEN DCE TO DCW


'Start replicate
- (DCW to DCE) to sync up the transactions 
'Verify there is no lag between DCW to DCE

GGSCI (epl1trandbrpt1.tsysacquiring.org) 6> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRE        00:00:01      00:00:05
EXTRACT     STOPPED     PPRERW      00:00:00      01:46:54
REPLICAT    RUNNING     RPRERW      00:00:00      00:00:05
REPLICAT    RUNNING     RPRETE01    00:00:00      00:00:00
REPLICAT    RUNNING     RPRETELG    00:00:00      00:00:01
REPLICAT    RUNNING     RPRETW01    01:46:04      00:00:02
REPLICAT    RUNNING     RPRETWLG    00:00:00      00:00:00


GGSCI (epl1trandbtxn1.tsysacquiring.org) 6> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTE        00:00:01      00:00:09
EXTRACT     RUNNING     PPTERE      00:00:00      00:00:05
EXTRACT     STOPPED     PPTERW      00:00:00      01:46:54
EXTRACT     STOPPED     PPTETW      00:00:00      01:46:54
REPLICAT    RUNNING     RPTETW01    01:41:55      00:00:00
REPLICAT    RUNNING     RPTETWLG    00:00:00      00:00:01


GGSCI (wpl1trandbrpt1.tsysacquiring.org) 6> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRW        00:00:02      00:00:07
EXTRACT     RUNNING     PPRWRE      00:00:00      00:00:00
REPLICAT    STOPPED     RPRWRE      00:00:00      01:46:54
REPLICAT    STOPPED     RPRWTE01    00:00:00      01:46:54
REPLICAT    STOPPED     RPRWTELG    00:00:00      01:46:54
REPLICAT    RUNNING     RPRWTW01    00:00:00      00:00:02
REPLICAT    RUNNING     RPRWTWLG    00:00:00      00:00:00

GGSCI (wpl1trandbtxn1.tsysacquiring.org) 6> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING

EXTRACT     RUNNING     EPTW        00:00:01      00:00:02
EXTRACT     RUNNING     PPTWRE      00:25:22      00:00:09
EXTRACT     RUNNING     PPTWRW      00:00:03      00:00:02
EXTRACT     RUNNING     PPTWTE      00:25:24      00:00:09
REPLICAT    STOPPED     RPTWTE01    00:00:00      01:46:50
REPLICAT    STOPPED     RPTWTELG    00:00:00      01:46:50




step 3 :


GGSCI (epl1trandbrpt1.tsysacquiring.org) 35> info all


Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRE        00:00:01      00:00:01
EXTRACT     RUNNING     PPRERW      00:00:00      00:00:06
REPLICAT    RUNNING     RPRERW      00:00:00      00:00:06
REPLICAT    RUNNING     RPRETE01    00:00:00      00:00:02
REPLICAT    RUNNING     RPRETELG    00:00:00      00:00:02
REPLICAT    RUNNING     RPRETW01    00:00:00      00:00:03
REPLICAT    RUNNING     RPRETWLG    00:00:00      00:00:02


GGSCI (epl1trandbrpt1.tsysacquiring.org) 36>
GGSCI (epl1trandbrpt1.tsysacquiring.org) 36>

GGSCI (epl1trandbtxn1.tsysacquiring.org) 12> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTE        00:00:03      00:00:08
EXTRACT     RUNNING     PPTERE      00:00:03      00:00:09
EXTRACT     RUNNING     PPTERW      00:00:03      00:00:04
EXTRACT     RUNNING     PPTETW      00:00:03      00:00:08
REPLICAT    RUNNING     RPTETW01    00:00:00      00:00:02
REPLICAT    RUNNING     RPTETWLG    00:00:00      00:00:03


GGSCI (epl1trandbtxn1.tsysacquiring.org) 13>

GGSCI (epl1trandbtxn1.tsysacquiring.org) 13>


GGSCI (wpl1trandbrpt1.tsysacquiring.org) 13> !
info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRW        00:00:00      00:00:00
EXTRACT     RUNNING     PPRWRE      00:00:00      00:00:05
REPLICAT    RUNNING     RPRWRE      00:00:00      00:00:01
REPLICAT    RUNNING     RPRWTE01    02:03:57      00:00:03
REPLICAT    RUNNING     RPRWTELG    01:56:40      00:00:00
REPLICAT    RUNNING     RPRWTW01    00:00:00      00:00:09
REPLICAT    RUNNING     RPRWTWLG    00:00:00      00:00:09



GGSCI (wpl1trandbtxn1.tsysacquiring.org) 14> !
info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTW        00:00:01      00:00:01
EXTRACT     RUNNING     PPTWRE      00:00:00      00:00:00
EXTRACT     RUNNING     PPTWRW      00:00:00      00:00:01
EXTRACT     RUNNING     PPTWTE      00:00:00      00:00:07
REPLICAT    RUNNING     RPTWTE01    01:58:11      00:00:00
REPLICAT    RUNNING     RPTWTELG    00:00:00      00:00:00

