GGSCI (epl1trandbtxn1.tsysacquiring.org) 43> INFO EXTRACT EPTE ,showch

EXTRACT    EPTE      Last Started 2019-06-17 02:00   Status RUNNING
Checkpoint Lag       00:00:00 (updated 00:00:07 ago)
Log Read Checkpoint  Oracle Redo Logs
                     2019-06-17 02:13:17  Thread 1, Seqno 156561, RBA 62283264
                     SCN 16.3003463115 (71722939851)
Log Read Checkpoint  Oracle Redo Logs
                     2019-06-17 02:13:17  Thread 2, Seqno 104386, RBA 111245312
                     SCN 16.3003463119 (71722939855)
Log Read Checkpoint  Oracle Redo Logs
                     2019-06-17 02:13:19  Thread 3, Seqno 142784, RBA 13372832
                     SCN 16.3003463137 (71722939873)


Current Checkpoint Detail:

Read Checkpoint #1

  Oracle Threaded Redo Log

  Startup Checkpoint (starting position in the data source):
    Thread #: 1
    Sequence #: 156560
    RBA: 34320
    Timestamp: 2019-06-17 01:54:52.000000
    SCN: 16.3003137638 (71722614374)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_9.12313.852387741

  Recovery Checkpoint (position of oldest unprocessed transaction in the data source):
    Thread #: 1
    Sequence #: 156561
    RBA: 62282768
    Timestamp: 2019-06-17 02:13:17.000000
    SCN: 16.3003463115 (71722939851)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_10.20850.852387725

  Current Checkpoint (position of last record read in the data source):
    Thread #: 1
    Sequence #: 156561
    RBA: 62283264
    Timestamp: 2019-06-17 02:13:17.000000
    SCN: 16.3003463115 (71722939851)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_10.20850.852387725

  BR Previous Recovery Checkpoint:
    Thread #: 1
    Sequence #: 0
    RBA: 0
    Timestamp: 2019-06-16 11:52:08.139452
    SCN: Not available
    Redo File:

  BR Begin Recovery Checkpoint:
    Thread #: 1
    Sequence #: 156523
    RBA: 5877264
    Timestamp: 2019-06-16 19:52:14.000000
    SCN: 16.3000716171 (71720192907)
    Redo File:

  BR End Recovery Checkpoint:
    Thread #: 1
    Sequence #: 156523
    RBA: 5909260
    Timestamp: 2019-06-16 19:52:16.000000
    SCN: 16.3000716235 (71720192971)
    Redo File:

Read Checkpoint #2

  Oracle Threaded Redo Log

  Startup Checkpoint (starting position in the data source):
    Thread #: 2
    Sequence #: 104381
    RBA: 43939856
    Timestamp: 2019-06-17 01:54:55.000000
    SCN: 16.3003138085 (71722614821)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_12.33998.852387777

  Recovery Checkpoint (position of oldest unprocessed transaction in the data source):
    Thread #: 2
    Sequence #: 104386
    RBA: 111207440
    Timestamp: 2019-06-17 02:13:17.000000
    SCN: 16.3003463119 (71722939855)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_14.32177.852446465

  Current Checkpoint (position of last record read in the data source):
    Thread #: 2
    Sequence #: 104386
    RBA: 111245312
    Timestamp: 2019-06-17 02:13:17.000000
    SCN: 16.3003463119 (71722939855)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_14.32177.852446465

  BR Previous Recovery Checkpoint:
    Thread #: 2
    Sequence #: 0
    RBA: 0
    Timestamp: 2019-06-16 11:52:08.139452
    SCN: Not available
    Redo File:

  BR Begin Recovery Checkpoint:
    Thread #: 2
    Sequence #: 104350
    RBA: 392201744
    Timestamp: 2019-06-16 19:52:15.000000
    SCN: 16.3000716191 (71720192927)
    Redo File:

  BR End Recovery Checkpoint:
    Thread #: 2
    Sequence #: 104350
    RBA: 393349120
    Timestamp: 2019-06-16 19:52:17.000000
    SCN: 16.3000716307 (71720193043)
    Redo File:

Read Checkpoint #3

  Oracle Threaded Redo Log

  Startup Checkpoint (starting position in the data source):
    Thread #: 3
    Sequence #: 142782
    RBA: 362337808
    Timestamp: 2019-06-17 01:54:56.000000
    SCN: 16.3003138225 (71722614961)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_7.9466.852387641

  Recovery Checkpoint (position of oldest unprocessed transaction in the data source):
    Thread #: 3
    Sequence #: 142784
    RBA: 13371920
    Timestamp: 2019-06-17 02:13:19.000000
    SCN: 16.3003463137 (71722939873)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_8.18882.852387661

  Current Checkpoint (position of last record read in the data source):
    Thread #: 3
    Sequence #: 142784
    RBA: 13372832
    Timestamp: 2019-06-17 02:13:19.000000
    SCN: 16.3003463137 (71722939873)
    Redo File: +ASMTXNARCHIVE/transittxnga/onlinelog/group_8.18882.852387661

  BR Previous Recovery Checkpoint:
    Thread #: 3
    Sequence #: 0
    RBA: 0
    Timestamp: 2019-06-16 11:52:08.139452
    SCN: Not available
    Redo File:

  BR Begin Recovery Checkpoint:
    Thread #: 3
    Sequence #: 142760
    RBA: 3642880
    Timestamp: 2019-06-16 19:52:14.000000
    SCN: 16.3000716169 (71720192905)
    Redo File:

  BR End Recovery Checkpoint:
    Thread #: 3
    Sequence #: 142760
    RBA: 3642880
    Timestamp: 2019-06-16 19:52:14.000000
    SCN: 16.3000716169 (71720192905)
    Redo File:

Write Checkpoint #1

  GGS Log Trail

  Current Checkpoint (current write position):
    Sequence #: 96099
    RBA: 113921
    Timestamp: 2019-06-17 02:13:19.466298
    Extract Trail: /acfs/goldengate/dirdat/LA
    Trail Type: EXTTRAIL

Header:
  Version = 2
  Record Source = A
  Type = 11
  # Input Checkpoints = 3
  # Output Checkpoints = 1

File Information:
  Block Size = 2048
  Max Blocks = 100
  Record Length = 4096
  Current Offset = 0

Configuration:
  Data Source = 3
  Transaction Integrity = 1
  Task Type = 0

Status:
  Start Time = 2019-06-17 02:00:41
  Last Update Time = 2019-06-17 02:13:19
  Stop Status = A
  Last Result = 0



GGSCI (epl1trandbtxn1.tsysacquiring.org) 44> info extract PPTETW

EXTRACT    PPTETW    Last Started 2019-06-17 02:05   Status RUNNING
Checkpoint Lag       01:39:20 (updated 00:07:41 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/LA096006
                     2019-06-17 00:26:42.000000  RBA 29182576


GGSCI (epl1trandbtxn1.tsysacquiring.org) 45> info extract PPTETW , showch

EXTRACT    PPTETW    Last Started 2019-06-17 02:05   Status RUNNING
Checkpoint Lag       01:39:20 (updated 00:07:52 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/LA096006
                     2019-06-17 00:26:42.000000  RBA 29182576


Current Checkpoint Detail:

Read Checkpoint #1

  GGS Log Trail

  Startup Checkpoint (starting position in the data source):
    Sequence #: 96006
    RBA: 29182576
    Timestamp: 2019-06-17 00:26:42.000000
    Extract Trail: /acfs/goldengate/dirdat/LA

  Current Checkpoint (position of last record read in the data source):
    Sequence #: 96006
    RBA: 29182576
    Timestamp: 2019-06-17 00:26:42.000000
    Extract Trail: /acfs/goldengate/dirdat/LA

Write Checkpoint #1

  GGS Log Trail

  Current Checkpoint (current write position):
    Sequence #: 94048
    RBA: 29189642
    Timestamp: 2019-06-17 00:45:44.864908
    Extract Trail: /acfs/goldengate/dirdat/EB
    Trail Type: RMTTRAIL

Header:
  Version = 2
  Record Source = A
  Type = 1
  # Input Checkpoints = 1
  # Output Checkpoints = 1

File Information:
  Block Size = 2048
  Max Blocks = 100
  Record Length = 2048
  Current Offset = 0

Configuration:
  Data Source = 0
  Transaction Integrity = 1
  Task Type = 0

Status:
  Start Time = 2019-06-17 02:05:56
  Last Update Time = 2019-06-17 02:06:02
  Stop Status = A
  Last Result = 0



GGSCI (epl1trandbtxn1.tsysacquiring.org) 46> info REPLICAT RPTETW01,showch

REPLICAT   RPTETW01  Last Started 2019-06-17 01:39   Status RUNNING
Checkpoint Lag       00:00:00 (updated 00:00:00 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/WB261351
                     2019-06-17 02:14:13.019403  RBA 41139015


Current Checkpoint Detail:

Read Checkpoint #1

  GGS Log Trail

  Startup Checkpoint (starting position in the data source):
    Sequence #: 261348
    RBA: 9559503
    Timestamp: 2019-06-17 01:15:32.131145
    Extract Trail: /acfs/goldengate/dirdat/WB

  Current Checkpoint (position of last record read in the data source):
    Sequence #: 261351
    RBA: 41139015
    Timestamp: 2019-06-17 02:14:13.019403
    Extract Trail: /acfs/goldengate/dirdat/WB

Header:
  Version = 2
  Record Source = A
  Type = 1
  # Input Checkpoints = 1
  # Output Checkpoints = 0

File Information:
  Block Size = 2048
  Max Blocks = 100
  Record Length = 2048
  Current Offset = 0

Configuration:
  Data Source = 0
  Transaction Integrity = -1
  Task Type = 0

Database Checkpoint:
  Checkpoint table = GGATE.CHECKPOINT
  Key = 3734245889 (0xde941201)
  Create Time = 2014-07-03 18:59:53

Status:
  Start Time = 2019-06-17 01:39:51
  Last Update Time = 2019-06-17 02:14:17
  Stop Status = A
  Last Result = 400



GGSCI (epl1trandbtxn1.tsysacquiring.org) 47>
