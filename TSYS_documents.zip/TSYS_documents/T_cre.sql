Total system : id : VishalBhandwalkar@tsys.com


servers :							IDS 

Columbus Production :

Tempe UAT servers 	:

WinCvs 				:		

Linux :
Chgme.12							
OCTOV1								vishalbh
octdev41n                           vishalbh
octmsdapp01                         vishalbh
octdb30                             vishalbh
octdb31                             vishalbh
wuh1mltidbs01                       vishalbh
wul2mapxapp02                       vishalbh
dcetk1                              vishalbh
dcetk2                              vishalbh
dcesg1                              vishalbh
dcedb01                             vishalbh
dcetp1                              vishalbh
dcetp2                              vishalbh
dcedb7                              vishalbh
dcedb8                              vishalbh
dcedb9                              vishalbh
dcedb10                             vishalbh
dcedbkp2                            vishalbh
eph1mapxdbs01                       vishalbh
epl1mapxapp01                       vishalbh
dcwtk1                              vishalbh
dcwtk2                              vishalbh
dcwsg1                              vishalbh
dcwdb01                             vishalbh
dcwdb03                             vishalbh
dcwtp1                              vishalbh
dcwtp2                              vishalbh
dcwdb7                              vishalbh
dcwdb8                              vishalbh
dcwdb9                              vishalbh
octdb7                              vishalbh
wph1mapxdbs01                       vishalbh
wph1mapxdbs02                       vishalbh
wpl1mapxapp01                       vishalbh
wdl2tsyssvs04 - CVS                 vishalbh












Support Team:								mail ids :

TransIT-Appl-Production :					TransIT-Appl-ProductionSupport@tsys.com  


