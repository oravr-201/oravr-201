Purpose: 
How to start and stop an DB2 instance.



Responsibilities:
Starting and stopping the DB2 database/s



Assumptions:
DBA level access



Work Instruction:

Stop the DB2 instance
01. Login as db2prod user using one of the following statements from octov1:
pbrun -h wpa1mapxdbs01 su - db2prod  
pbrun -h epa1mapxdbs01 su - db2prod


pbrun -h wpa1mapxdbs01 su - db2prod 
pbrun -h wpa1mapxdbs01 su - db2fic

02. Run alter command and choose the instance to stop
alter


03. Check DB2 instance for any connected session
db2 list applications

*NOTE: If connected session exist, inform the application support to disconnect/stop their sessions or terminal all connection via DB2. 
	
To terminal all the connects issue below command.
db2 force application all


04. Check all active database in the instance. We will need to deactivate all active database before stopping the instance.

a. To check active database/s.
db2 list active databases

b. To deactivate database/s
db2 deactivate db <db_name>


05. Stop the DB2 database manager by entering below command.
db2stop


06. Check again for the sessions for verification
db2 list applications




Start the DB2 instance
01. Login as db2 user.


02. Run alter command to choose the instance to start
alter


03. Start the DB2 database manager by entering below command.
db2start


04. List database in the instance so we can activate them.
db2 list database directory 


05. Active database/s
db2 activate db <db_name>


06. Inform Application support that DB2 is up and running. Verify if there are connections in the instance by running below check.
db2 list applications