==================================================================================================================================
LOG IN DETAILS: 
==================================================================================================================================
set sqlprompt "_user'@'_connect_identifier> "

set sqlprompt "_date':'_user'@'_connect_identifier> "
set linesize 190
set pages 1000
set long 32000
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
col HOSTNAME for a35
col BLOCKED for a7
col STARTUP_TIME for a19
select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,d.protection_mode,D.database_role,I.LOGINS,
to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from gv$instance I,v$database D ;



col DB_HOSTNAME for a20
col INSTANCE for a20
col CLIENTHOST for a40
set pages 200
set lines 3200
SELECT to_char(SYSDATE,'dd-mm-yyyy hh24:mi:ss') "DATE",SYS_CONTEXT('USERENV','SERVER_HOST') AS DB_HOSTNAME ,SYS_CONTEXT('USERENV','DB_NAME') AS INSTANCE,SYS_CONTEXT('USERENV','HOST') AS CLIENTHOST FROM DUAL;


SELECT SID, SERIAL#
    FROM GV$SESSION
    WHERE AUDSID = Sys_Context('USERENV', 'SESSIONID')
      AND INST_ID = USERENV('Instance');
==================================================================================================================================
Tablespace details :
===================================================================================================================================

select tablespace_name,used_percent from dba_tablespace_usage_metrics where used_percent > 70;
 
 col file_name for a100
select FILE_NAME,bytes/1024/1024,AUTOEXTENSIBLE from dba_DATA_files where tablespace_name='&DCS_D_03' order by file_id;

Jan@12345&12345
h122761
DOM01\h117437 Sweethome$1234&1234

---------------------------------------
set lines 500	
col file_name format a85	
col TABLESPACE_NAME for a30	
select tablespace_name,file_name,bytes/1024/1024,maxbytes/1024/1024,autoextensible	
from dba_temp_files	
where tablespace_name='&ADBI01' ORDER BY file_name;	


rprete


set lines 500
col tablespace_name for a25
SELECT a.tablespace_name, ROUND (a.bytes_alloc / 1024 / 1024, 2) ALLOCATED_MB,
ROUND (NVL (b.bytes_free, 0) / 1024 / 1024, 2) FREE_MB,
ROUND ((a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024,2) USED_MB,
ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) "% FREE",
100 - ROUND ((NVL (b.bytes_free, 0) / a.bytes_alloc) * 100, 2) "% USED",
ROUND (maxbytes / 1048576, 2) MAXBYTES,
round(100-(ROUND ((a.bytes_alloc - NVL (b.bytes_free, 0)) / 1024 / 1024,2)*100/ROUND (maxbytes / 1048576, 2)),2) "% MAX_Free"
FROM
(SELECT f.tablespace_name, SUM (f.BYTES) bytes_alloc,SUM (DECODE (f.autoextensible,'YES', f.maxbytes,'NO', f.BYTES)) maxbytes FROM dba_data_files f GROUP BY tablespace_name) a,
(SELECT f.tablespace_name, SUM (f.BYTES) bytes_free FROM dba_free_space f GROUP BY tablespace_name) b 
WHERE a.tablespace_name = b.tablespace_name(+)
and a.tablespace_name ='&VDV_TEMP2';


set pages 50000 lines 32767
col tablespace_name format a30
col TABLESPACE_NAME heading "Tablespace|Name"
col Allocated_size heading "Allocated|Size(GB)" form 99999999.99
col Current_size heading "Current|Size(GB)" form 99999999.99
col Used_size heading "Used|Size(GB)" form 99999999.99
col Available_size heading "Available|Size(GB)" form 99999999.99
col Pct_used heading "%Used (vs)|(Allocated)" form 99999999.99 

select a.tablespace_name
       ,a.alloc_size/1024/1024/1024 Allocated_size
       ,a.cur_size/1024/1024/1024 Current_Size
       ,(u.used+a.file_count*65536)/1024/1024/1024 Used_size
       ,(a.alloc_size-(u.used+a.file_count*65536))/1024/1024/1024 Available_size
       ,((u.used+a.file_count*65536)*100)/a.alloc_size Pct_used
from     dba_tablespaces t
       ,(select t1.tablespace_name
       ,nvl(sum(s.bytes),0) used
        from  dba_segments s
       ,dba_tablespaces t1
         where t1.tablespace_name=s.tablespace_name(+)
         group by t1.tablespace_name) u
       ,(select d.tablespace_name
       ,sum(greatest(d.bytes,nvl(d.maxbytes,0))) alloc_size
       ,sum(d.bytes) cur_size
       ,count(*) file_count
        from dba_data_files d
        group by d.tablespace_name) a
where t.tablespace_name=u.tablespace_name
--and ((u.used+a.file_count*65536)*100)/a.alloc_size>80
  and t.tablespace_name=a.tablespace_name
  and t.tablespace_name='UNDOTBS1'
order by t.tablespace_name; 



REM TABLESPACE DETAILS	
col TABLESPACE_NAME for a30	
REM Tablespace freespace	
set linesize 150	
set linesize 150	
set pages 10000	
set head on	
SELECT tablespace_name,ROUND(SUM(total_mb)-SUM(free_mb)) CUR_USE_MB,	
ROUND(SUM(max_mb) - (SUM(total_mb)-SUM(free_mb))) FREE_SPACE_MB,	
ROUND(SUM(max_mb)) MAX_SZ_MB,	
ROUND((SUM(total_mb)-SUM(free_mb))/SUM(max_mb)*100) PCT_FULL FROM 	
( SELECT tablespace_name, SUM(bytes)/1024/1024 FREE_MB, 0 TOTAL_MB, 0 MAX_MB FROM dba_free_space GROUP BY tablespace_name UNION 	
SELECT tablespace_name, 0 CURRENT_MB,	
SUM(bytes)/1024/1024 TOTAL_MB,	
SUM(case when maxbytes<bytes then bytes else maxbytes end)/1024/1024 MAX_MB FROM dba_data_files GROUP BY tablespace_name) 	
where tablespace_name like '&AWSD01'	
GROUP BY tablespace_name order by 5	;

----free space
add following for temp files -

select sum(bytes)/1024 kbytes_alloc, tablespace_name
from sys.dba_temp_files
group by tablespace_name 

the new query will be 

select b.tablespace_name, tbs_size SizeMb, a.free_space FreeMb
from 
(select tablespace_name, round(sum(bytes)/1024/1024,2) as free_space 
from dba_free_space group by tablespace_name) a, 
(select tablespace_name, sum(bytes)/1024/1024 as tbs_size 
from dba_data_files group by tablespace_name
UNION
select tablespace_name, sum(bytes)/1024/1024 tbs_size
from dba_temp_files
group by tablespace_name ) b
where a.tablespace_name(+)=b.tablespace_name;



---tablespace MB 

SET ECHO        OFF
SET FEEDBACK    6
SET HEADING     ON
SET LINESIZE    180
SET PAGESIZE    50000
SET TERMOUT     ON
SET TIMING      OFF
SET TRIMOUT     ON
SET TRIMSPOOL   ON
SET VERIFY      OFF

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

COLUMN status      FORMAT a9                 HEADING 'Status'
COLUMN name        FORMAT a30                HEADING 'Tablespace Name'
COLUMN type        FORMAT a15                HEADING 'TS Type'
COLUMN extent_mgt  FORMAT a10                HEADING 'Ext. Mgt.'
COLUMN segment_mgt FORMAT a10                HEADING 'Seg. Mgt.'
COLUMN ts_size     FORMAT 9,999,999,999,999.99  HEADING 'Tablespace Size'
COLUMN used        FORMAT 9,999,999,999,999.99  HEADING 'Used (in bytes)'
COLUMN free        FORMAT 9,999,999,999,999.99  HEADING 'Free (in bytes)'
COLUMN pct_used    FORMAT 999.99                HEADING 'Pct. Used'


BREAK ON report

COMPUTE sum OF ts_size  ON report
COMPUTE sum OF used     ON report
COMPUTE sum OF free     ON report
COMPUTE avg OF pct_used ON report
SELECT
    d.status                                            status
 , d.tablespace_name                                   name
 , d.contents                                          type
 , d.extent_management                                 extent_mgt
 , d.segment_space_management                          segment_mgt
 , NVL(a.bytes/1024/1024, 0)                                     ts_size
 , NVL(a.bytes/1024/1024 - NVL(f.bytes/1024/1024, 0), 0)                   used
  --, NVL(f.bytes, 0)                                     free
 , NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0) pct_used
FROM
    sys.dba_tablespaces d
 , ( select tablespace_name, sum(bytes) bytes
      from dba_data_files
      group by tablespace_name
    ) a
 , ( select tablespace_name, sum(bytes) bytes
      from dba_free_space
      group by tablespace_name
    ) f
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = f.tablespace_name(+)
  AND NOT (
    d.extent_management like 'LOCAL'
    AND
    d.contents like 'TEMPORARY'
  )
UNION ALL
SELECT
    d.status                         status
 , d.tablespace_name                name
 , d.contents                       type
 , d.extent_management              extent_mgt
 , d.segment_space_management       segment_mgt
 , NVL(a.bytes/1024/1024, 0)                  ts_size
 , NVL(t.bytes/1024/1024, 0)                  used
  --, NVL(a.bytes/1024/1024 - NVL(t.bytes,0), 0) free
 , NVL(t.bytes / a.bytes * 100, 0)  pct_used
FROM
    sys.dba_tablespaces d
 , ( select tablespace_name, sum(bytes) bytes
      from dba_temp_files
      group by tablespace_name
    ) a
 , ( select tablespace_name, sum(bytes_cached) bytes
      from v$temp_extent_pool
      group by tablespace_name
    ) t
WHERE
      d.tablespace_name = a.tablespace_name(+)
  AND d.tablespace_name = t.tablespace_name(+)
  AND d.extent_management like 'LOCAL'
  AND d.contents like 'TEMPORARY'
ORDER BY
  2
/



---shrink tablespace (type) 

SET LINES 32000
SET PAGES 200
COL SCRIPT_RECLAIM FOR A100
COL FILE_NAME FOR A60
COL TABLESPACE_NAME FOR A15
SELECT File_ID, Tablespace_name, file_name, High_Water_Mark, current_size_in_GB,
   'ALTER DATABASE DATAFILE '''||file_name||''' resize '|| High_Water_Mark|| 'M;' script_reclaim
FROM 
(
   WITH v_file_info
         AS (SELECT FILE_NAME, FILE_ID, BLOCK_SIZE
               FROM dba_tablespaces tbs, dba_data_files df
              WHERE tbs.tablespace_name = df.tablespace_name)
    SELECT A.FILE_ID,
           A.FILE_NAME,
           A.TABLESPACE_NAME,
           CEIL ( (NVL (hwm, 1) * v_file_info.block_size) / 1024 / 1024) High_Water_Mark,
           CEIL (BLOCKS * v_file_info.block_size / 1024 / 1024 /2014) current_size_in_GB
      FROM dba_data_files A,
           v_file_info,
           (  SELECT file_id, MAX (block_id + BLOCKS - 1) hwm
                FROM dba_extents
            GROUP BY file_id) b
     WHERE A.file_id = b.file_id(+) 
       AND A.file_id = v_file_info.file_id
       AND tablespace_name='&IFX_SER_USAGE_DATA2'
)     
WHERE  High_Water_Mark <> current_size_in_GB 





--Shrink Tablespaces 
set pages 1000
set serveroutput on
set lines 500
 
DECLARE 
        
    v_hwm number :=0;
    v_current_size number :=0;
    v_percent_gain number :=0;
    v_total_space_rec number :=0;
    v_total_data_size number :=0;
        
BEGIN
    
    for v_file_info in (select FILE_NAME, FILE_ID, BLOCK_SIZE 
                        from dba_tablespaces tbs, dba_data_files df 
                        where tbs.tablespace_name = df.tablespace_name)
    loop
        select ceil( (nvl(hwm,1) * v_file_info.block_size)/1024/1024 ),
               ceil( blocks * v_file_info.block_size/1024/1024) into v_hwm,v_current_size
        from dba_data_files a,
        ( select file_id, max(block_id+blocks-1) hwm
          from dba_extents
          group by file_id ) b
       where a.file_id = b.file_id(+)
       and a.file_id = v_file_info.file_id;
       
       v_total_space_rec := v_total_space_rec +(v_current_size-v_hwm);
       v_total_data_size := v_total_data_size +v_current_size;
          
        dbms_output.put_line(v_file_info.file_name || ':');
        dbms_output.put_line('Current size: ' || v_current_size || 'M' );
        dbms_output.put_line('HWM: ' || v_hwm || 'M' );
        dbms_output.put_line('Percentage reclaimable: ' || round((v_current_size-v_hwm)*100/v_current_size,2) || '%');
        dbms_output.put_line('Use following command to resize: ALTER DATABASE DATAFILE ''' || v_file_info.file_name || ''' RESIZE ' || v_hwm|| 'M;');
        
        dbms_output.put_line('    ');
        dbms_output.put_line('    ');
    end loop;
    
    dbms_output.put_line('Total datafiles size reclaimable: ' || v_total_space_rec || 'M');
    dbms_output.put_line('Percentage of space reclaimable in the datafiles: ' || round(v_total_space_rec*100/v_total_data_size,2) || '%');
END;
/

******************************************************************************************************************************************
================================================================================================================================================
Rman backup job details :
=================================================================================================================================================
set lines 300 pages 300 
col TIME_TAKEN_DISPLAY for a10
col start_time for a20
col status for a20
col input_type for a20
select SESSION_KEY, INPUT_TYPE, STATUS,
to_char(START_TIME,'dd-mm-yyyy:hh24:mi:ss') start_time,
to_char(END_TIME,'dd-mm-yyyy:hh24:mi:ss') end_time,
time_taken_display,OUTPUT_BYTES/1024/1024 "size in MB" from V$RMAN_BACKUP_JOB_DETAILS
order by session_key;

*************************************************************************************************************************************************
================================================================================================================================================
ASM DISK PERCENTAGE :
=================================================================================================================================================

SELECT name, free_mb/1024, total_mb/1024, free_mb/total_mb*100 as percentage FROM v$asm_diskgroup;

wmic logicaldisk get size,freespace,caption
wmic logicaldisk get size,freespace,caption
fsutil volume diskfree


select NAME,type, total_mb/1024, free_mb/1024, free_mb*100/total_mb from v$asm_diskgroup where name='&1';
select NAME,type, total_mb/1024, free_mb/1024, free_mb*100/total_mb from v$asm_diskgroup;
 
[‎06-‎04-‎2017 18:56] Shah, Preksha: 
w9a94f80
Kaabil12345&12345


************************************************************************************************************************************************
================================================================================================================================================
PROCESS STUATU :
=================================================================================================================================================

==>GET INFO ACTIVE PROCESS :

SELECT pr.username "O/S Id",
       ss.username "Oracle User Id",
       ss.status "status",
       ss.sid "Session Id",
       ss.serial# "Serial No",
       lpad(pr.spid,7) "Process Id",
       substr(sqa.sql_text,1,540) "Sql Text"
  FROM v$process pr, v$session ss, v$sqlarea sqa
 WHERE pr.addr=ss.paddr
   AND ss.username is not null
   AND ss.sql_address=sqa.address(+)
   AND ss.sql_hash_value=sqa.hash_value(+)
   AND ss.status='ACTIVE'
ORDER BY 1,2,7

===>>
	select resource_name, current_utilization, max_utilization from v$resource_limit where resource_name in ('processes','sessions');

===>
	select sid,  process, program from v$session s join v$bgprocess using (paddr) where rownum < 5;

*************************************************************************************************************************************************
================================================================================================================================================
FRA :
=================================================================================================================================================

show parameter reco
								
select * from v$flash_recovery_area_usage;
								
								
sho parameter reco;

SELECT NAME,TO_CHAR(SPACE_LIMIT, '999,999,999,999') AS SPACE_LIMIT,TO_CHAR(SPACE_LIMIT - SPACE_USED + SPACE_RECLAIMABLE,
'999,999,999,999') AS SPACE_AVAILABLE,
ROUND((SPACE_USED - SPACE_RECLAIMABLE)/SPACE_LIMIT * 100, 1)
AS PERCENT_FULL FROM V$RECOVERY_FILE_DEST;
-------
select * from v$flash_recovery_area_usage;
------
select sum(PERCENT_SPACE_USED) from v$FLASH_RECOVERY_AREA_USAGE;
-------
set pages 9999
set lines 200
SELECT * FROM V$FLASH_RECOVERY_AREA_USAGE;
ATF:I4346464
								
*************************************************************************************************************************************************
================================================================================================================================================
TOOLS TABLESPACE :
=================================================================================================================================================
								
Step 1: check the snapshot:

select min(snap_id), max(snap_id) from Stats$SNAPSHOT; 

Step 2: run the below command :

@?/rdbms/admin/sppurge.sql

Step 3: Run the below query:

select 'ALTER index ' || OWNER || '.' || INDEX_NAME || ' rebuild ;' from dba_indexes where owner = 'PERFSTAT';
select 'ALTER table ' || OWNER || '.' || TABLE_NAME || ' enable row movement;' from dba_tables where owner = 'PERFSTAT';
select 'ALTER table ' || OWNER || '.' || TABLE_NAME || ' shrink space;' from dba_tables where owner = 'PERFSTAT';							

*************************************************************************************************************************************************
================================================================================================================================================
TOOLS TABLESPACE :
=================================================================================================================================================
---
set line 100
set pagesize 200
col TABLESPACE format a30;
col TOTAL_MB format 999,999,999
col USED_MB format 999,999,999
col FREE_MB format 999,999,999
col %_USED format 999.99
break on report 
compute sum of TOTAL_MB on report
compute sum of USED_MB on report
compute sum of FREE_MB on report
compute avg of %_USED on report

select a.tablespace_name "TABLESPACE",
(b.bytes/1048576) "TOTAL_MB",
nvl((c.bytes/1048576),0) "USED_MB",
nvl((d.bytes/1048576),0) "FREE_MB",
nvl((c.bytes/b.bytes)*100,0) "%_USED"
from (select tablespace_name from dba_tablespaces) a,
(select tablespace_name,bytes from sys.sm$ts_avail) b,
(select tablespace_name,bytes from sys.sm$ts_USED) c,
(select tablespace_name,bytes from sys.sm$ts_FREE) d
where a.tablespace_name= b.tablespace_name(+)
and a.tablespace_name= c.tablespace_name(+)
and a.tablespace_name= d.tablespace_name(+)
order by 5 desc;

---------
SELECT MIN(SNAP_ID), MAX(SNAP_ID) FROM STATS$SNAPSHOT; 

----------

@?/rdbms/admin/sppurge.sql



select 'ALTER index ' || OWNER || '.' || INDEX_NAME || ' rebuild ;' from dba_indexes where owner = 'PERFSTAT';
select 'ALTER table ' || OWNER || '.' || TABLE_NAME || ' enable row movement;' from dba_tables where owner = 'PERFSTAT';
select 'ALTER table ' || OWNER || '.' || TABLE_NAME || ' shrink space;' from dba_tables where owner = 'PERFSTAT';

*************************************************************************************************************************************************

users details 
select * from dba_role_privs where GRANTEE='DSCILIAN';

=====================================================================================================================
Raman Session status : 
=====================================================================================================================

SELECT s.SID,s.serial#, USERNAME AS "User", PROGRAM, MODULE, ACTION, LOGON_TIME "Logon", l.* FROM V$SESSION s, V$ENQUEUE_LOCK l
WHERE l.SID = s.SID AND l.TYPE = 'CF' AND l.ID1 = 0 AND l.ID2 = 2;

select sid, serial#, status, logon_time from v$session where program like '%rman%';
ps -ewf |grep rman|awk '{print $2}' | xargs kill -9
=====================================================================================================================







=====================================================================================================================
sync report 
=====================================================================================================================
select max(sequence#) from v$log_history;
select max(sequence#) from v$archived_log where applied='YES' and dest_id=2;



satandby:

SELECT ARCH.THREAD# "Thread", ARCH.SEQUENCE# "Last Sequence Received", APPL.SEQUENCE# "Last Sequence Applied", (ARCH.SEQUENCE# - APPL.SEQUENCE#) "Difference"
FROM (SELECT THREAD#,SEQUENCE# FROM V$ARCHIVED_LOG WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$ARCHIVED_LOG GROUP BY THREAD#)) ARCH,
(SELECT THREAD#,SEQUENCE# FROM V$LOG_HISTORY WHERE (THREAD#,FIRST_TIME ) IN (SELECT THREAD#,MAX(FIRST_TIME) FROM V$LOG_HISTORY GROUP BY THREAD#)) APPL
WHERE ARCH.THREAD# = APPL.THREAD# ORDER BY 1;

primary:

select pr.thread# "Node", pr.primary "Primary",dr.Standby "DR",pr.primary-dr.Standby "Difference"
from 
(select thread#,max(sequence#) as primary from v$archived_log where 
resetlogs_change#=(select resetlogs_change# from v$database) group by thread#) Pr,
(select thread#,max(sequence#) as Standby from v$archived_log where 
resetlogs_change#=(select resetlogs_change# from v$database) and applied='YES' group by thread#) dr 
where 
pr.thread#=dr.thread#;

=====================================================================================================================
REDO 
=====================================================================================================================
set linesize 300
column REDOLOG_FILE_NAME format a50
SELECT
    a.GROUP#,
    a.THREAD#,
    a.SEQUENCE#,
    a.ARCHIVED,
    a.STATUS,
    b.MEMBER    AS REDOLOG_FILE_NAME,
    (a.BYTES/1024/1024) AS SIZE_MB
FROM v$log a
JOIN v$logfile b ON a.Group#=b.Group# 
ORDER BY a.GROUP# ASC;





--Object tablespaces 

SELECT DISTINCT  ','||TABLESPACE_NAME||':CPASS_DATA_TBLS'
    FROM DBA_SEGMENTS
    WHERE
--     SEGMENT_TYPE = 'INDEX'
--    AND 
    OWNER in ('SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS')
--    ORDER BY SEGMENT_NAME;
group by TABLESPACE_NAME





select sum(bytes/1024/1024/1024) from dba_segments ;
Select name, value from v$parameter where name='sga_max_size';


select &a/1024/1024/1024 from dual;


----alert log in windows | tail 
get-Content D:\APP\ORACLE\PRODUCT\11.2.0\DBHOME_1\DATABASE\refresh_full_1.log -Wait -Tail 30


--optimizer 
https://blog.tanelpoder.com/posts/scripts-for-drilling-down-into-unknown-optimizer-changes/
https://docs.oracle.com/cd/B10500_01/server.920/a96533/optimops.htm



--certificate  :

https://docs.oracle.com/database/121/ARPLS/u_tcp.htm#ARPLS71570
deadlocks :
https://oracle-base.com/articles/misc/deadlocks <https://oracle-base.com/articles/misc/deadlocks>  

datafile :https://fritshoogland.wordpress.com/2012/07/23/rename-oracle-managed-file-omf-datafiles-in-asm/


http://allappsdba.blogspot.com/2012/04/to-check-library-cache-lock-contention.html

https://docs.oracle.com/cd/A97630_01/server.920/a96653/sbydbmanappx.htms

https://france.emc.com/collateral/TechnicalDocument/docu59580.pdf
https://japan.emc.com/collateral/TechnicalDocument/docu53954.pdf
https://japan.emc.com <https://japan.emc.com/collateral/TechnicalDocument/docu53954.pdf> 
monsanto password change :
http://orapwchanger.monsanto.com/

http://oraclewindow.blogspot.com/
http://www.dbas-oracle.com/2013/05/10-steps-to-analyze-awr-report-in-oracle.html
https://community.toadworld.com/platforms/oracle/w/wiki/11730.table-level-recovery-using-rman-oracle-12c

--oracle veridata 


https://gjilevski.com/2012/11/18/deploy-oracle-goldengate-veridata-version-3-0-for-comparison-between-oracle-rdbms-databases-replicated-using-ogg-11gr2/

----ORACLE Goldengate 

https://jinyuwang.weebly.com/oracle-goldengate.html
http://db.geeksinsight.com/12c-database/
https://github.com/blackyboy/RedHat-Centos-Common-Stuffs/blob/master/Step-by-Step-how-to-setup-a-DNS-Server-in-RHEL-6.2-6.4-6.5-Using-Bind.md


http://orcldesk.blogspot.com/p/oracle-12-invisible-column.html