https://databaseinternalmechanism.com/oracle-12c-miscellaneous/managing-a-cdb-pdb-basic-dba-commands/
https://oracle-base.com/articles/12c/multitenant-create-and-configure-pluggable-database-12cr1
https://osamaoracle.com/2013/07/05/pluggable-database-tutorial-12c-part-2/
http://www.oracle-wiki.net/premium:startdocsminimultistartpdb
https://www.dell.com/community/VNX/Linux-vnx5400-multipathing-failure/td-p/7115879
https://www.oracle-dba-online.com/Managing_Pluggable_Databases.htm
https://blog.toadworld.com/2017/05/19/issues-with-oracle-multi-tenant-application-containers
http://www.ludovicocaldara.net/dba/category/oracledb/oracle-database-18c/
https://blog.toadworld.com/2017/05/19/issues-with-oracle-multi-tenant-application-containers
--imp 
	http://www.zhongweicheng.com/?p=1135
	https://hemantoracledba.blogspot.com/2016/06/services-4-using-servicenames-parameter.html
	https://hemantoracledba.blogspot.com/2017/04/12cr1-rac-posts-9-adding-service-to-pdb.html


	
-- JDBC VERSION 

	https://www.oracle.com/technetwork/database/enterprise-edition/jdbc-faq-090281.html#01_01	


Please provide below deatails 

database name : east/west
time freame  :
date :
hostname :

SQL script for getting AWR Report on 
RAC database: 
@$ORACLE_HOME/rdbms/admin/awrgrpti.sql 		-- SQLscript for getting AWR Report for  single instance: 
@$ORACLE_HOME/rdbms/admin/awrrpt.sql		-- SQL script for getting ASH Report on RAC database: 
@$ORACLE_HOME/rdbms/admin/ashrpti.sql 		-- SQL script for getting ASH Report for single Instance: 
@$ORACLE_HOME/rdbms/admin/ashrpt.sql 		-- SQL script for getting ADDM Report on RAC database: 
@$ORACLE_HOME/rdbms/admin/addmrpti.sql 		-- SQL script for getting ADDM Report for single instance: 
@$ORACLE_HOME/rdbms/admin/addmrpt.sql





${GOLDENGATE_HOME}/ggsci << EOF > /tmp/ggsci_status.log
info all
EOF



CREATE DATABASE LINK RE
 CONNECT TO DBRELEASE
 IDENTIFIED BY <PASSWORD>
 USING '(DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=e-transitdb-rpt.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=transitrpt)
    )
  )';
  
  
  


CREATE DATABASE LINK TWGG
 CONNECT TO GGATE
 IDENTIFIED BY <PASSWORD>
 USING '(DESCRIPTION= (ADDRESS= (PROTOCOL=TCP) (HOST=w-transitdb-txn.tsysacquiring.org) (PORT=1521) ) (CONNECT_DATA= (SERVICE_NAME=transittxn) ) )';

 


ICD Person Group	:PG1698 - MS GTS Database Administration