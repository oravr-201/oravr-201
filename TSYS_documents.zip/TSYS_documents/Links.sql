KT TOTAL SYSTEM INC  .......


unlocak lan account : 8811


usefull weblinks :

1. pluralsight													https://app.pluralsight.com/sso/tsys
2. pluralsight(utside LAN)										https://app.pluralsight.com/plans/email-validation/total-system-services-inc-9d844
3. sharepoint (dba on call)										https://sharepoint.tsys.com/sites/tas/DS/_layouts/15/WopiFrame.aspx?sourcedoc=/sites/tas/DS/Shared%20Documents/DBA-OnCall-Schedule.xlsx&action=default
																https://sharepoint.tsys.com/sites/tas/CC/Lists/On%20Call%20List/AllItems.aspx.InplviewHasha197b3ca-dd37-4b54-b4f3-00a510b782f5=
4. sharepoint(ducuments )										https://sharepoint.tsys.com/sites/tas/DS/Shared%20Documents/Forms/AllItems.aspx
5. sharepoint (merchant)										https://sharepoint.tsys.com/sites/tas/DS/Merchant%20DBA%20Wiki/Home.aspx
6. sharepoint(ducuments)										https://sharepoint.tsys.com/sites/tas/DS/Shared%20Documents/Forms/AllItems.aspx?RootFolder=%2Fsites%2Ftas%2FDS%2FShared%20Documents%2FDBA%20general%20documents&FolderCTID=0x012000D06A615EC487D343A8E7C168AED71EE7&View=%7B12AC87B6-7A5E-4E0C-AEDC-BC9165A89EF0%7D

7. yammer 														https://www.yammer.com/tsys.com/ 



8.HR BERRY 														-- https://www.hrberry.com/powerhr/index.php?q=cms&m=index&client=tsys				113514



7387


9. org chart 													-- https://sharepoint.tsys.com/sites/TSYSIndiaPortal/TSYS%20India%20%20Org%20Chart/Forms/AllItems.aspx


10. reference : 												-- https://sharepoint.tsys.com/sites/TIRP/_layouts/15/start.aspx#/SitePages/ReferralProcess.aspx 




https://merchantcenter-e.transit-pass.com/jsp/vt/jsp/index.jsp  
 




PG1953 (IS Account Management)-- Kathleen Water and Donna Dunlup's



bit loccker :Contact Helpdesk at 706-644-1234. 

on call - details :

[‎3/‎7/‎2019 12:40 PM] Sandip Tujare: 
https://sharepoint.tsys.com/sites/TSYSPune/GTS/SitePages/Home.aspx 
https://sharepoint.tsys.com/sites/TSYSPune/GTS/SitePages/Home.aspx?RootFolder=%2Fsites%2FTSYSPune%2FGTS%2FShared%20Documents%2FGTS_Shift_Allowance_Details&FolderCTID=0x012000955734235F0D4E42A4AAD52814347550&View=%7BAEFE48D0-1AF1-4053-BFA1-2366F17281D8%7D 



Informix with AD:
DB Authentication Encryption
https://www-01.ibm.com/support/docview.wss?uid=swg21405613&aid=1



jul$Action2019



may$Ispl_2019





Username: vishalbh
Password: 1Bd=iep92w04Bq
Home Directory : /home/vishalbh






ispl_201




GTS SOFTWARE request : http://gtsrequests.tsys.com/swr/GTSWRequest_1.aspx

toad price: https://shop.quest.com/682/catalog/category.84868/language.en/currency.GBP/?id=b4x2JwQAJr





Site Message: TOTAL SYSTEM SERVICES INC  
Admin key: CDPYLXT4VX6EKATXW17CDSHKTYCM1DSSZLFW1-136-167-749-3F




10.100.226.121 





Printer : \\ndifp1



fixit : https://sharepoint.tsys.com/sites/tas/itcomm/fix-it-days/_layouts/15/start.aspx#/SitePages/Home_Page_2019-Q2.aspx#InplviewHashf1591cdc-40bc-46b4-a571-c7ef881a1c74=Paged%3DTRUE-p_ID%3D204-PageFirstRow%3D61 




Hi Team, 
Please Active/Unlock account on "octov1.vitalps.com" server. I am Production support database administrator Please unlock account ASAP. 

username :    vishalbh
name :           vishal bhandwalkar(113514)

 Regards, Vishal bhandwalkar +91.957.912.3863
 
 
 
 SR968041
 
 SR968041
 
 
 Need to Active/Unlock "vishalbh" Account on 'octov1.vitalps.com'

