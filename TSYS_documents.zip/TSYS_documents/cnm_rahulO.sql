/* Formatted on 11/17/2019 10:52:02 PM (QP5 v5.185.11230.41888) */
SELECT * FROM stujare.cnm_181119_vb_dcmv_post;

 

SELECT *
  FROM TRANSNOX_IOX.transaction
 WHERE transaction_id = 607691302;

 


create table romanwar.cnm_181119_vb_dcmv_post as
  SELECT tc.transaction_id,
         TC.CARD_NUMBER,
         TC.CARD_ENCRYPT_DATA,
         CNM.CARD_SEQNO,
         CNM.CARD_ENCRYPT,
            'update TRANSNOX_IOX.card_number_master set card_seqno = '''
         || cnm.card_seqno
         || ''' where card_encrypt = '''
         || cnm.card_encrypt
         || ''' and card_mask =  '''
         || cnm.card_mask
         || ''';'
            cnm_syncup,
            ' update transnox_iox.trans_card set card_number = '''
         || cnm.card_seqno
         || ''' where transaction_id = '
         || tc.transaction_id
         || ' and card_number = '''
         || tc.card_number
         || ''';'trans_card_synup
    FROM    TRANSNOX_IOX.TRANS_CARD tc
         LEFT JOIN
            TRANSNOX_IOX.CARD_NUMBER_MASTER cnm
         ON (TC.CARD_ENCRYPT_data = CNM.CARD_ENCRYPT)
   WHERE transaction_id IN (607691302)
ORDER BY transaction_id;

 


SELECT * from TRANSNOX_IOX.trans_card where card_number = '551061455'




----check out-of-sync status on batch sattelment 

SELECT * FROM stujare.cnm_191119_vb;

SELECT * FROM TRANSNOX_IOX.TRANSACTION WHERE TRANSACTION_ID=606893574

SELECT * FROM TRANSNOX_IOX.TRANS_SETTLEMENT WHERE TRANSACTION_ID=606893574