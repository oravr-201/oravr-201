-- Purging time -- on all four databases.

SELECT TRUNC (created_date),
         ROUND (
              (  TO_DATE (TO_CHAR (Batch_End_Time, 'DD/MM/YYYY HH24:MI:SS'),
                          'DD/MM/YYYY HH24:MI:SS')
               - TO_DATE (TO_CHAR (Batch_start_Time, 'DD/MM/YYYY HH24:MI:SS'),
                          'DD/MM/YYYY HH24:MI:SS'))
            * (24 * 60),
            2)
            Puring_Time_in_Min
    FROM Purgedata.Trns_Purge_Batch_Info
    WHERE created_date >=
                TO_DATE ('15-01-2020  00:00:00', 'DD-MM-YYYY  HH24:MI:SS')
ORDER BY 1 DESC;
 
 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 -- Average transaction processing Report -- TE or TW

SELECT TRUNC (SERVER_TIMESTAMP) server_date,
         ROUND (AVG (processing_time_in_sec), 2) average_processing_time
    FROM transnox_iox.REQUEST_AUDIT_TRAIL
   WHERE     SERVER_TIMESTAMP >=
                TO_DATE ('15-01-2019  00:00:00', 'dd-mm-yyyy  hh24:mi:ss') -- AND TO_DATE ('22-Sep-2019 23:59:59', 'dd-mon-yyyy hh24:mi:ss')
         AND SUBSERVICE_CODE = 'AUTH'
         AND ADAPTOR_PROCESSING_TIME_IN_SEC > 0.5
         AND PROCESSING_TIME_IN_SEC - ADAPTOR_PROCESSING_TIME_IN_SEC > 0.5
         AND processing_time_in_sec < 5
GROUP BY TRUNC (SERVER_TIMESTAMP)
ORDER BY 1 DESC;
 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 
-- Total time outs in a day for reporting RPT

SELECT report_date, SUM (timeout_counts) total_time_outs
    FROM (  SELECT report_date,
                   REPLACE (report_id_1, ',', '') report_id,
                   COUNT (1) timeout_counts
              FROM (SELECT report_date,
                           Report_id,
                           (CASE
                               WHEN SUBSTR (report_id,
                                            1,
                                            INSTR (report_id, ' ', 1))
                                       IS NULL
                               THEN
                                  report_id
                               WHEN SUBSTR (report_id,
                                            1,
                                            INSTR (report_id, ' ', 1))
                                       IS NOT NULL
                               THEN
                                  SUBSTR (report_id,
                                          1,
                                          INSTR (report_id, ' ', 1))
                            END)
                              report_id_1,
                           TO_NUMBER (
                              TRIM (REPLACE (processing_time, 'Sec', '')))
                              processing_time
                      FROM (SELECT TRUNC (start_date) report_date,
                                   SUBSTR (parameter_list,
                                           INSTR (parameter_list, '=>', 1) + 3,
                                           35)
                                      Report_id,
                                   processing_time
                              FROM TRANSNOX_IOX.REPORT_USAGE_AUDITTRAIL rua
                             WHERE     rua.start_date >=
                                          TO_DATE ('15-01-2020  00:00:00',
                                                   'DD-MM-YYYY  HH24:MI:SS')
                                   --rua.start_date BETWEEN TO_DATE ('01-01-2020  00:00:00', 'DD-MM-YYYY  HH24:MI:SS') AND TO_DATE ('22-SEP-2019 23:59:59', 'DD-MON-YYYY HH24:MI:SS')
                                   AND processing_time IS NOT NULL))
             WHERE report_id IS NOT NULL AND processing_time > 180
          GROUP BY report_id_1, report_date)
GROUP BY report_date;
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 -- Deadlock count --TXN

SELECT TRUNC (EXECUTEDON), COUNT (1)
    FROM TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP
   WHERE     OBJECT_NAME = 'CAPTURE_HARMONY_SETTLE_PRE'
         AND output_msg <> 'SUCCESS'
         AND EXECUTEDON >=
                TO_DATE ('15-01-2020  00:00:00', 'DD-MM-YYYY  HH24:MI:SS')
GROUP BY TRUNC (EXECUTEDON)
ORDER BY 1 DESC
 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 
 
-----  Transaction taking more than 10 seconds to process Report rw

SELECT TRUNC (transacting_date),
         SUM (gateway_processing_tran_count) gateway_processing_tran_count,
         SUM (adaptor_processing_tran_count) adaptor_processing_tran_count,
         SUM (total_processing_time) total_processing_time_count
    FROM (SELECT transacting_date,
                 (CASE WHEN gateway_processing_time > 10 THEN 1 ELSE 0 END)
                    gateway_processing_tran_count,
                 (CASE
                     WHEN ADAPTOR_PROCESSING_TIME_IN_SEC > 10 THEN 1
                     ELSE 0
                  END)
                    adaptor_processing_tran_count,
                 (CASE WHEN PROCESSING_TIME_IN_SEC > 10 THEN 1 ELSE 0 END)
                    total_processing_time
            FROM (SELECT TO_DATE (
                            TO_CHAR (SERVER_TIMESTAMP, 'MM/DD/YYYY HH24:MI'),
                            'MM/DD/YYYY HH24:MI')
                            transacting_date,
                         transaction_id,
                         (  PROCESSING_TIME_IN_SEC
                          - ADAPTOR_PROCESSING_TIME_IN_SEC)
                            gateway_processing_time,
                         ADAPTOR_PROCESSING_TIME_IN_SEC,
                         PROCESSING_TIME_IN_SEC
                    FROM TRANSNOX_IOX.REQUEST_AUDIT_TRAIL RAT
                   WHERE     RAT.SERVER_TIMESTAMP >=
                                TO_DATE ('15-01-2019  00:00:00',
                                         'DD-MM-YYYY  HH24:MI:SS') --between trunc(sysdate-1) and trunc(sysdate)
                         AND REQUEST_MESSAGE IN
                                ('TRANSACTIONADJUSTMENT',
                                 'AUTH',
                                 'VOID',
                                 'CARDAUTHENTICATION',
                                 'CAPTURE',
                                 'CARDRQ',
                                 'CHECKRQ',
                                 'SALE',
                                 'ACH',
                                 'TIPADJUSTMENT',
                                 'CARDVERIFICATION',
                                 'CASHSALE',
                                 'DEBITSALE',
                                 'RETURN',
                                 'FORCEDAUTH')
                         AND PROCESSING_TIME_IN_SEC > 10
                         AND (    PROCESSING_TIME_IN_SEC IS NOT NULL
                              AND ADAPTOR_PROCESSING_TIME_IN_SEC IS NOT NULL)))
GROUP BY TRUNC (transacting_date)
ORDER BY 1 DESC;
 
 
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 --sattelment TXN
 
  SELECT recon_time || ':45:00' recon_time,
         groups_created,
         total_transaction_count,
         batches_posted,
         db_execution_time,
         JOB_START_TIME,
         JOB_END_TIME,
         total_job_exec_time_in_sec,
         settled_transaction_count
    FROM (  SELECT TO_CHAR (
                      TO_DATE (SUBSTR (input_string, 52, 19),
                               'DD-MM-YYYY HH24:MI:SS'),
                      'MM/DD/YYYY HH24')
                      recon_time,
                   SUM (rec_count)  total_transaction_count,
                   MAX (execution_time) db_execution_time,
                   COUNT (1)        groups_created
              FROM TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP
             WHERE     object_name = 'CAPTURE_HARMONY_SETTLE_PRE'
                   AND executedon >
                          TO_DATE ('01/15/2020 00:00:00',
                                   'MM/DD/YYYY HH24:MI:SS')
                   AND OUTPUT_MSG = 'Success'
          GROUP BY TO_CHAR (
                      TO_DATE (SUBSTR (input_string, 52, 19),
                               'DD-MM-YYYY HH24:MI:SS'),
                      'MM/DD/YYYY HH24')) a,
         (SELECT job_execution_id,
                 job_date,
                 JOB_START_TIME,
                 JOB_END_TIME,
                     EXTRACT (
                        DAY FROM (JOB_END_TIME - JOB_START_TIME) DAY TO SECOND)
                   * 86400
                 +   EXTRACT (
                        HOUR FROM (JOB_END_TIME - JOB_START_TIME) DAY TO SECOND)
                   * 3600
                 +   EXTRACT (
                        MINUTE FROM (JOB_END_TIME - JOB_START_TIME) DAY TO
                                                                    SECOND)
                   * 60
                 + EXTRACT (
                      SECOND FROM (JOB_END_TIME - JOB_START_TIME) DAY TO SECOND)
                    AS total_job_exec_time_in_sec
            FROM (  SELECT job_execution_id,
                           TO_CHAR (START_TIME, 'MM/DD/YYYY HH24') job_date,
                           MIN (START_TIME)                    JOB_START_TIME,
                           MAX (end_time)                      JOB_END_TIME
                      FROM TRANSNOX_IOX.BATCH_STEP_EXECUTION
                     WHERE     step_name LIKE 'slave%'
                           AND status = 'COMPLETED'
                           AND START_TIME >
                                  TO_DATE ('01/15/2020 00:00:00',
                                           'MM/DD/YYYY HH24:MI:SS')
                  GROUP BY job_execution_id,
                           TO_CHAR (START_TIME, 'MM/DD/YYYY HH24'))) b,
         (  SELECT TO_CHAR (settle_date, 'MM/DD/YYYY HH24') settle_date,
                   batch_status,
                   COUNT (DISTINCT ssb.batch_seq_id)    batches_posted,
                   COUNT (ts.transaction_id)
                      settled_transaction_count
              FROM TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH ssb,
                   transnox_iox.trans_settlement  ts
             WHERE     SSB.BATCH_SEQ_ID = TS.BATCH_SEQ_ID
                   AND batch_status = 'SUCCESS'
                   AND settle_date >
                          TO_DATE ('01/15/2020 00:00:00',
                                   'MM/DD/YYYY HH24:MI:SS')
                   AND time_stamp >
                          TO_DATE ('01/15/2020 00:00:00',
                                   'MM/DD/YYYY HH24:MI:SS')
          GROUP BY TO_CHAR (settle_date, 'MM/DD/YYYY HH24'), batch_status) c
   WHERE a.recon_time = b.job_date AND a.recon_time = c.settle_date
ORDER BY job_start_time DESC
 ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------