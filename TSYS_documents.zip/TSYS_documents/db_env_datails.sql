prod :			TRANSIT 				REPORTING 

EAST :			3							3
																		EACH NODE HAVE ONE DB (TOTAL NODE 12 INSTANCE 12 )
WEST :			3							3

4 rac Systm each have 3 node on E&W 



UAT :			TRANSIT 				REPORTING 

EAST :			2							2
																		EACH NODE HAVE TWO DB (TOTAL NODE 4 INSTANCE 8 )
WEST :			2							2



PERF :			TRANSIT 				REPORTING 

EAST :			3							3
																		EACH NODE HAVE TWO DB (TOTAL NODE 6 INSTANCE 12 )
WEST :			3							3



qa dev & reg we have and 2 node rac and dont have GG 
