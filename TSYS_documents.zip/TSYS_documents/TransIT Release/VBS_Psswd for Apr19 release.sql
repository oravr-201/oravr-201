
--Location :
	/home/oracle/database/install/VBS_CREATION 
--hostname :
	wdl2tsyssvs04.tsysacquiring.org 





java -jar EncryptPassword.jar $a

java -jar EncryptPassword.jar TransitGWTApr19Nox
java -jar EncryptPassword.jar TransitGWSApr19Nox

java -jar EncryptPassword.jar TransitSTApr19Nox
java -jar EncryptPassword.jar TransitSSApr19Nox

java -jar EncryptPassword.jar TransitFETApr19Nox
java -jar EncryptPassword.jar TransitFESApr19Nox


TRANSIT_GATEWAY_TNOX_3126		TransitGWTApr19Nox
TRANSIT_GATEWAY_SNOX_3126		TransitGWSApr19Nox

TRANSIT_SMSNOX_TNOX_3126		TransitSTApr19Nox
TRANSIT_SMSNOX_SNOX_3126		TransitSSApr19Nox

TRANSIT_FE_TNOX_3126			TransitFETApr19Nox
TRANSIT_FE_SNOX_3126			TransitFESApr19Nox


ALTER USER TRANSIT_GATEWAY_TNOX_3126 IDENTIFIED BY "TransitGWTApr19Nox";
ALTER USER TRANSIT_GATEWAY_SNOX_3126 IDENTIFIED BY "TransitGWSApr19Nox";
ALTER USER TRANSIT_SMSNOX_TNOX_3126 IDENTIFIED BY "TransitSTApr19Nox";
ALTER USER TRANSIT_SMSNOX_SNOX_3126 IDENTIFIED BY "TransitSSApr19Nox";
ALTER USER TRANSIT_FE_TNOX_3126 IDENTIFIED BY "TransitFETApr19Nox";
ALTER USER TRANSIT_FE_SNOX_3126 IDENTIFIED BY "TransitFESApr19Nox";


EXEC DBMS_UTILITY.COMPILE_SCHEMA( 'TRANSIT_GATEWAY_TNOX_3126', FALSE );
EXEC DBMS_UTILITY.COMPILE_SCHEMA( 'TRANSIT_GATEWAY_SNOX_3126', FALSE );

EXEC DBMS_UTILITY.COMPILE_SCHEMA( 'TRANSIT_SMSNOX_TNOX_3126', FALSE );
EXEC DBMS_UTILITY.COMPILE_SCHEMA( 'TRANSIT_SMSNOX_SNOX_3126', FALSE );

EXEC DBMS_UTILITY.COMPILE_SCHEMA( 'TRANSIT_FE_TNOX_3126', FALSE );
EXEC DBMS_UTILITY.COMPILE_SCHEMA( 'TRANSIT_FE_SNOX_3126', FALSE );

PFB credentials for New VBS Schemas in Production DB.

------------------------------------------------------------------------------------------------------
User Name: TRANSIT_GATEWAY_TNOX_3126
Encrypt Password = C40F53F5455A95046A5060ED0C2C6F114B0EC4001303FD8F

--- Hibernate Key and Password
Key = FB3776CD646E3BE9
Password = 8A23310832A40DA0C98C5306B2A82F5107748C71EF8FC2F3
------------------------------------------------------------------------------------------------------
User Name: TRANSIT_GATEWAY_SNOX_3126
Encrypt Password = C40F53F5455A9504169A390EAEB8A0754B0EC4001303FD8F

--- Hibernate Key and Password
Key = BF01E3A480F44029
Password = 6D20DC63C2506FCB54ED8D0DC725E1ADFD35A58CDF1DC8D9
-----------------------------------------------------------------------------------------------------
User Name: TRANSIT_SMSNOX_TNOX_3126
Encrypt Password = F56666D1A72C69FD6861C0A317BB6D5B28856E782D0DC55B

--- Hibernate Key and Password
Key = 4F43EC8F515E2686
Password = D015EA9801E2C00E7FFB82D318DD1189A3CEB501EDB6B305
------------------------------------------------------------------------------------------------------
User Name: TRANSIT_SMSNOX_SNOX_3126
Encrypt Password = F56666D1A72C69FDE448B23BA17EDED328856E782D0DC55B

--- Hibernate Key and Password
Key = 836E923B97544C92
Password = 505E4105556CC534E485DAE6E1890D729FB67F310EDAD82B
------------------------------------------------------------------------------------------------------ 
User Name: TRANSIT_FE_TNOX_3126
Encrypt Password = 14B21EA4C2DABFB16A8B95464EDAE8B44B0EC4001303FD8F

--- Hibernate Key and Password
Key = 8016E9C276A8FE16
Password = 73D3280C36588A6BE578C6BBA2183686905F18E28E9F57E9
------------------------------------------------------------------------------------------------------
User Name: TRANSIT_FE_SNOX_3126
Encrypt Password = 14B21EA4C2DABFB1396A35F594E20E624B0EC4001303FD8F

--- Hibernate Key and Password
Key = B080C8CBB9329449
Password = 848F7888CB887C191D82E4BA41535FED262B1D9D255E43E6
------------------------------------------------------------------------------------------------------

