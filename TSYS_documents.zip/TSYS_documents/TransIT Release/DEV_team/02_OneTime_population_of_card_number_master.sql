
DECLARE
   CURSOR CUR_CARD_NUMBER_MASTER
   IS
        SELECT TO_NUMBER (CARD_SEQNO) CARD_SEQNO,
               CARD_ENCRYPT,
               CARD_MASK,
               MAX_DATE
          FROM TRANSNOX_CPASS.CARD_NUMBER_MASTER CNM,
               (  SELECT CARD_NUMBER, MAX (TIMESTAMP) MAX_DATE
                    FROM TRANSNOX_CPASS.TRANS_CARD
                   WHERE TIMESTAMP >= ADD_MONTHS (SYSDATE, -24)
                GROUP BY CARD_NUMBER)
         WHERE TO_CHAR (CARD_NUMBER) = CARD_SEQNO
      ORDER BY CARD_SEQNO;


   TYPE TYPE_CUR_CARD_NUMBER_MASTER
      IS TABLE OF CUR_CARD_NUMBER_MASTER%ROWTYPE;

   V_CARD_NUMBER_MASTER_NEW   TYPE_CUR_CARD_NUMBER_MASTER;
BEGIN
   OPEN CUR_CARD_NUMBER_MASTER;

   LOOP
      EXIT WHEN CUR_CARD_NUMBER_MASTER%NOTFOUND;

      FETCH CUR_CARD_NUMBER_MASTER
         BULK COLLECT INTO V_CARD_NUMBER_MASTER_NEW
         LIMIT 1000;


      BEGIN
         FORALL I IN 1 .. V_CARD_NUMBER_MASTER_NEW.COUNT SAVE EXCEPTIONS
            INSERT /*+ APPEND*/
                  INTO  TRANSNOX_CPASS.CARD_NUMBER_MASTER_NEW (CARD_SEQNO,
                                                               CARD_ENCRYPT,
                                                               CARD_MASK,
                                                               DATE_CREATED)
                 VALUES (V_CARD_NUMBER_MASTER_NEW (I).CARD_SEQNO,
                         V_CARD_NUMBER_MASTER_NEW (I).CARD_ENCRYPT,
                         V_CARD_NUMBER_MASTER_NEW (I).CARD_MASK,
                         V_CARD_NUMBER_MASTER_NEW (I).MAX_DATE);



         COMMIT;
      EXCEPTION
         WHEN OTHERS
         THEN
            FOR I IN 1 .. SQL%BULK_EXCEPTIONS.COUNT
            LOOP
               DBMS_OUTPUT.PUT_LINE (
                     'ERROR AT CARD CARD SEQUENCE NUMBER '
                  || V_CARD_NUMBER_MASTER_NEW (
                        SQL%BULK_EXCEPTIONS (I).ERROR_INDEX).CARD_SEQNO
                  || ' ERROR MESSAGE: '
                  || SQLERRM (-SQL%BULK_EXCEPTIONS (I).ERROR_CODE));
            END LOOP;
      END;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
END;