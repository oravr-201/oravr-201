DECLARE
   V_MAX_CARD_SEQNO   NUMBER;
BEGIN
   --Getting max card number from new table
   SELECT MAX (CARD_SEQNO)
     INTO V_MAX_CARD_SEQNO
     FROM TRANSNOX_CPASS.CARD_NUMBER_MASTER_NEW;

   INSERT /*+ APPEND*/
         INTO  TRANSNOX_CPASS.CARD_NUMBER_MASTER_NEW (CARD_SEQNO,
                                                      CARD_ENCRYPT,
                                                      CARD_MASK,
                                                      DATE_CREATED)
      SELECT TO_NUMBER (CARD_SEQNO) CARD_SEQNO,
             CARD_ENCRYPT,
             CARD_MASK,
             SYSDATE - 1            MAX_DATE
        FROM TRANSNOX_CPASS.CARD_NUMBER_MASTER
       WHERE TO_NUMBER (CARD_SEQNO) > V_MAX_CARD_SEQNO;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      NULL;
   WHEN OTHERS
   THEN
      NULL;
END;