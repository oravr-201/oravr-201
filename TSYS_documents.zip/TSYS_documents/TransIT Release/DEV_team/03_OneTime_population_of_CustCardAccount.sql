DECLARE
   CURSOR CUR_CARD_NUMBER_MASTER
   IS
        SELECT TO_NUMBER (CNM.CARD_SEQNO) CARD_SEQNO,
               CARD_ENCRYPT,
               CARD_MASK,
               DATE_CREATED
          FROM (SELECT CCA.CARD_NUMBER, CCA.DATE_CREATED DATE_CREATED
                  FROM TRANSNOX_CPASS.CUST_CARD_ACCOUNT    CCA,
                       TRANSNOX_CPASS.CARD_NUMBER_MASTER_NEW CNMN
                 WHERE     CNMN.CARD_SEQNO(+) = TO_NUMBER (CCA.CARD_NUMBER)
                       AND CNMN.CARD_SEQNO IS NULL) CCA,
               TRANSNOX_CPASS.CARD_NUMBER_MASTER CNM
         WHERE CCA.CARD_NUMBER = CNM.CARD_SEQNO
      ORDER BY CARD_SEQNO;

   TYPE TYPE_CUR_CARD_NUMBER_MASTER
      IS TABLE OF CUR_CARD_NUMBER_MASTER%ROWTYPE;

   V_CARD_NUMBER_MASTER_NEW   TYPE_CUR_CARD_NUMBER_MASTER;
BEGIN
   OPEN CUR_CARD_NUMBER_MASTER;

   LOOP
      EXIT WHEN CUR_CARD_NUMBER_MASTER%NOTFOUND;

      FETCH CUR_CARD_NUMBER_MASTER
         BULK COLLECT INTO V_CARD_NUMBER_MASTER_NEW
         LIMIT 1000;


      BEGIN
         FORALL I IN 1 .. V_CARD_NUMBER_MASTER_NEW.COUNT SAVE EXCEPTIONS
            INSERT /*+ APPEND*/
                  INTO  TRANSNOX_CPASS.CARD_NUMBER_MASTER_NEW (CARD_SEQNO,
                                                               CARD_ENCRYPT,
                                                               CARD_MASK,
                                                               DATE_CREATED)
                 VALUES (V_CARD_NUMBER_MASTER_NEW (I).CARD_SEQNO,
                         V_CARD_NUMBER_MASTER_NEW (I).CARD_ENCRYPT,
                         V_CARD_NUMBER_MASTER_NEW (I).CARD_MASK,
                         V_CARD_NUMBER_MASTER_NEW (I).DATE_CREATED);

         COMMIT;
      EXCEPTION
         WHEN OTHERS
         THEN
            FOR I IN 1 .. SQL%BULK_EXCEPTIONS.COUNT
            LOOP
               DBMS_OUTPUT.PUT_LINE (
                     'Error at card card sequence number '
                  || V_CARD_NUMBER_MASTER_NEW (
                        SQL%BULK_EXCEPTIONS (I).ERROR_INDEX).CARD_SEQNO
                  || ' Error Message: '
                  || SQLERRM (-SQL%BULK_EXCEPTIONS (I).ERROR_CODE));
            END LOOP;
      END;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (SQLERRM || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;