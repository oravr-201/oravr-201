[oracle@devdbnode1 ~]$ ps -eaf | grep pmon
oracle    5894     1  0 Jan07 ?        00:11:09 asm_pmon_+ASM1
oracle   14334     1  0 Jan07 ?        00:22:27 ora_pmon_devracdb1
oracle   31948 31897  0 20:07 pts/0    00:00:00 grep pmon
[oracle@devdbnode1 ~]$ ps -eaf | grep tns
root        37     2  0 Jan07 ?        00:00:00 [netns]
oracle    7298     1  0 Jan07 ?        00:11:23 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER -inherit
oracle    7340     1  0 Jan07 ?        00:04:06 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER_SCAN1 -inherit
oracle   32056 31897  0 20:07 pts/0    00:00:00 grep tns
[oracle@devdbnode1 ~]$ uname -a
Linux devdbnode1.tsysacquiring.org 2.6.32-754.3.5.el6.x86_64 #1 SMP Thu Aug 9 11:56:22 EDT 2018 x86_64 x86_64 x86_64 GNU/Linux
[oracle@devdbnode1 ~]$
[oracle@devdbnode1 ~]$ crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.CRS.dg
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.CSR.dg
               OFFLINE OFFLINE      devdbnode1
               OFFLINE OFFLINE      devdbnode2
ora.DATA.dg
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.LISTENER.lsnr
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.asm
               ONLINE  ONLINE       devdbnode1               Started
               ONLINE  ONLINE       devdbnode2               Started
ora.gsd
               ONLINE  OFFLINE      devdbnode1
               ONLINE  OFFLINE      devdbnode2
ora.net1.network
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.ons
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.registry.acfs
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       devdbnode1
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       devdbnode2
ora.LISTENER_SCAN3.lsnr
      1        ONLINE  ONLINE       devdbnode2
ora.cvu
      1        ONLINE  ONLINE       devdbnode2
ora.devdbnode1.vip
      1        ONLINE  ONLINE       devdbnode1
ora.devdbnode2.vip
      1        ONLINE  ONLINE       devdbnode2
ora.devracdb.db
      1        ONLINE  ONLINE       devdbnode1               Open
      2        ONLINE  ONLINE       devdbnode2               Open
ora.devracdb.devracdbtaf.svc
      1        ONLINE  ONLINE       devdbnode1
      2        ONLINE  ONLINE       devdbnode2
ora.oc4j
      1        ONLINE  ONLINE       devdbnode2
ora.scan1.vip
      1        ONLINE  ONLINE       devdbnode1
ora.scan2.vip
      1        ONLINE  ONLINE       devdbnode2
ora.scan3.vip
      1        ONLINE  ONLINE       devdbnode2
[oracle@devdbnode1 ~]$














[oracle@devdbnode2 ~]$ ps -eaf | grep pmon
oracle    5109     1  0  2018 ?        00:49:11 asm_pmon_+ASM2
oracle    7900     1  0  2018 ?        01:22:38 ora_pmon_devracdb2
oracle   15543 15316  0 20:10 pts/0    00:00:00 grep pmon
[oracle@devdbnode2 ~]$ ps -eaf | grep tns
root        37     2  0  2018 ?        00:00:00 [netns]
oracle    6201     1  0  2018 ?        00:20:15 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER_SCAN3 -inherit
oracle    6214     1  0  2018 ?        00:13:38 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER_SCAN2 -inherit
oracle    6261     1  0  2018 ?        00:38:35 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER -inherit
oracle   15563 15316  0 20:10 pts/0    00:00:00 grep tns
[oracle@devdbnode2 ~]$ uname -a
Linux devdbnode2.tsysacquiring.org 2.6.32-754.3.5.el6.x86_64 #1 SMP Thu Aug 9 11:56:22 EDT 2018 x86_64 x86_64 x86_64 GNU/Linux
[oracle@devdbnode2 ~]$ crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.CRS.dg
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.CSR.dg
               OFFLINE OFFLINE      devdbnode1
               OFFLINE OFFLINE      devdbnode2
ora.DATA.dg
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.LISTENER.lsnr
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.asm
               ONLINE  ONLINE       devdbnode1               Started
               ONLINE  ONLINE       devdbnode2               Started
ora.gsd
               ONLINE  OFFLINE      devdbnode1
               ONLINE  OFFLINE      devdbnode2
ora.net1.network
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.ons
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
ora.registry.acfs
               ONLINE  ONLINE       devdbnode1
               ONLINE  ONLINE       devdbnode2
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       devdbnode1
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       devdbnode2
ora.LISTENER_SCAN3.lsnr
      1        ONLINE  ONLINE       devdbnode2
ora.cvu
      1        ONLINE  ONLINE       devdbnode2
ora.devdbnode1.vip
      1        ONLINE  ONLINE       devdbnode1
ora.devdbnode2.vip
      1        ONLINE  ONLINE       devdbnode2
ora.devracdb.db
      1        ONLINE  ONLINE       devdbnode1               Open
      2        ONLINE  ONLINE       devdbnode2               Open
ora.devracdb.devracdbtaf.svc
      1        ONLINE  ONLINE       devdbnode1
      2        ONLINE  ONLINE       devdbnode2
ora.oc4j
      1        ONLINE  ONLINE       devdbnode2
ora.scan1.vip
      1        ONLINE  ONLINE       devdbnode1
ora.scan2.vip
      1        ONLINE  ONLINE       devdbnode2
ora.scan3.vip
      1        ONLINE  ONLINE       devdbnode2
[oracle@devdbnode2 ~]$








wdl2tsysdbs02.tsysacquiring.org:/home/oracle> crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.DATA.dg
               ONLINE  ONLINE       wdl2tsysdbs02
ora.LISTENER.lsnr
               ONLINE  ONLINE       wdl2tsysdbs02
ora.asm
               ONLINE  ONLINE       wdl2tsysdbs02            Started
ora.ons
               OFFLINE OFFLINE      wdl2tsysdbs02
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.cssd
      1        ONLINE  ONLINE       wdl2tsysdbs02
ora.devdb.db
      1        OFFLINE OFFLINE                               Instance Shutdown
ora.devreportdb.db
      1        ONLINE  ONLINE       wdl2tsysdbs02            Open
ora.diskmon
      1        OFFLINE OFFLINE
ora.evmd
      1        ONLINE  ONLINE       wdl2tsysdbs02
wdl2tsysdbs02.tsysacquiring.org:/home/oracle>

wdl2tsysdbs02.tsysacquiring.org:/home/oracle> crsctl stop crs
CRS-4013: This command is not supported in a single-node configuration.
CRS-4000: Command Stop failed, or completed with errors.
wdl2tsysdbs02.tsysacquiring.org:/home/oracle> crsctl stop has
CRS-2791: Starting shutdown of Oracle High Availability Services-managed resources on 'wdl2tsysdbs02'
CRS-2673: Attempting to stop 'ora.DATA.dg' on 'wdl2tsysdbs02'
CRS-2677: Stop of 'ora.DATA.dg' on 'wdl2tsysdbs02' succeeded
CRS-2673: Attempting to stop 'ora.asm' on 'wdl2tsysdbs02'
CRS-2677: Stop of 'ora.asm' on 'wdl2tsysdbs02' succeeded
CRS-2673: Attempting to stop 'ora.cssd' on 'wdl2tsysdbs02'
CRS-2677: Stop of 'ora.cssd' on 'wdl2tsysdbs02' succeeded
CRS-2673: Attempting to stop 'ora.evmd' on 'wdl2tsysdbs02'
CRS-2677: Stop of 'ora.evmd' on 'wdl2tsysdbs02' succeeded
CRS-2793: Shutdown of Oracle High Availability Services-managed resources on 'wdl2tsysdbs02' has completed
CRS-4133: Oracle High Availability Services has been stopped.
wdl2tsysdbs02.tsysacquiring.org:/home/oracle>




wdl2tsysdbs03.tsysacquiring.org:/home/oracle> ps -eaf | grep pmon
oracle    7734     1  0 Jan08 ?        00:07:53 ora_pmon_oemrep
oracle   24973 24020  0 21:29 pts/0    00:00:00 grep pmon
wdl2tsysdbs03.tsysacquiring.org:/home/oracle> ps -eaf | grep tns
root        37     2  0 Jan08 ?        00:00:00 [netns]
oracle    7854     1  0 Jan08 ?        00:02:53 /opt/app/oracle/product/11.2.0/dbhome_2/bin/tnslsnr LISTENER -inherit
oracle   24977 24020  0 21:29 pts/0    00:00:00 grep tns
wdl2tsysdbs03.tsysacquiring.org:/home/oracle> uname -a
Linux wdl2tsysdbs03.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
wdl2tsysdbs03.tsysacquiring.org:/home/oracle>
wdl2tsysdbs03.tsysacquiring.org:/home/oracle> ps -eaf| grep oms
oracle    4691     1  0 Jan08 ?        00:57:21 /opt/app/oracle/Middleware12105/jdk16/jdk/jre/bin/java -Xms126m -Xmx382m -Dweblogic.security.SSL.enableJSSE=true -Djava.security.egd=file:///dev/./urandom -classpath /opt/app/oracle/Middleware12105/jdk16/jdk/jre/lib/rt.jar:/opt/app/oracle/Middleware12105/jdk16/jdk/jre/lib/i18n.jar:/opt/app/oracle/Middleware12105/patch_wls1036/profiles/default/sys_manifest_classpath/weblogic_patch.jar:/opt/app/oracle/Middleware12105/jdk16/jdk/lib/tools.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic_sp.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic.jar:/opt/app/oracle/Middleware12105/modules/features/weblogic.server.modules_10.3.6.0.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/webservices.jar:/opt/app/oracle/Middleware12105/modules/org.apache.ant_1.7.1/lib/ant-all.jar:/opt/app/oracle/Middleware12105/modules/net.sf.antcontrib_1.1.0.0_1-0b2/lib/ant-contrib.jar:/opt/app/oracle/Middleware12105/patch_wls1036/profiles/default/sys_manifest_classpath/weblogic_patch.jar:/opt/app/oracle/Middleware12105/jdk16/jdk/lib/tools.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic_sp.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic.jar:/opt/app/oracle/Middleware12105/modules/features/weblogic.server.modules_10.3.6.0.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/webservices.jar:/opt/app/oracle/Middleware12105/modules/org.apache.ant_1.7.1/lib/ant-all.jar:/opt/app/oracle/Middleware12105/modules/net.sf.antcontrib_1.1.0.0_1-0b2/lib/ant-contrib.jar:/opt/app/oracle/Middleware12105/oms/sysman/jlib/emagentSDK.jar:/opt/app/oracle/Middleware12105/oms/sysman/jlib/emCORE.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.http_client_11.1.1.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.pki_11.1.1/oraclepki.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.osdt_11.1.1/osdt_cert.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.osdt_11.1.1/osdt_core.jar:/opt/app/oracle/Middleware12105/modules/com.bea.core.apache.log4j_1.2.13.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.jrf_11.1.1/jrf-wlstman.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/lib/adfscripting.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/lib/adf-share-mbeans-wlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/lib/mdswlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/auditwlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/igfwlsthelp.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/jps-wlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/jps-wls-trustprovider.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/jrf-wlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/oamap_help.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/oamAuthnProvider.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/ossoiap_help.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/ossoiap.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/ovdwlsthelp.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/sslconfigwlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/wsm-wlst.jar:/opt/app/oracle/Middleware12105/utils/config/10.3/config-launch.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/common/derby/lib/derbynet.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/common/derby/lib/derbyclient.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/common/derby/lib/derbytools.jar -DListenAddress=wdl2tsysdbs03.tsysacquiring.org -DNodeManagerHome=/opt/app/oracle/Middleware12105/gc_inst/NodeManager/emnodemanager -DQuitEnabled=true -DListenPort=7403 weblogic.NodeManager
oracle    4793  4744  0 Jan08 ?        01:38:36 /opt/app/oracle/Middleware12105/jdk16/jdk/bin/java -server -Xms256m -Xmx512m -XX:MaxPermSize=512m -Dweblogic.Name=EMGC_ADMINSERVER -Djava.security.policy=/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic.policy -Dweblogic.ProductionModeEnabled=true -Dweblogic.system.BootIdentityFile=/opt/app/oracle/Middleware12105/gc_inst/user_projects/domains/EMTASDev/servers/EMGC_ADMINSERVER/security/boot.properties -Dweblogic.nodemanager.ServiceEnabled=true -Djava.security.egd=file:///dev/./urandom -Dweblogic.debug.DebugWebAppSecurity=true -Dweblogic.SSL.LoginTimeoutMillis=300000 -Djps.auth.debug=true -Djps.authz=ACC -Djps.combiner.optimize.lazyeval=true -Djps.combiner.optimize=true -Djps.policystore.hybrid.mode=false -Djps.subject.cache.key=5 -Djps.subject.cache.ttl=600000 -Doracle.apm.home=/opt/app/oracle/Middleware12105/oms/apm/ -DAPM_HELP_FILENAME=oesohwconfig.xml -da -Dplatform.home=/opt/app/oracle/Middleware12105/wlserver_10.3 -Dwls.home=/opt/app/oracle/Middleware12105/wlserver_10.3/server -Dweblogic.home=/opt/app/oracle/Middleware12105/wlserver_10.3/server -Dcommon.components.home=/opt/app/oracle/Middleware12105/oracle_common -Djrf.version=11.1.1 -Dorg.apache.commons.logging.Log=org.apache.commons.logging.impl.Jdk14Logger -Ddomain.home=/opt/app/oracle/Middleware12105/gc_inst/user_projects/domains/EMTASDev -Djrockit.optfile=/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.jrf_11.1.1/jrocket_optfile.txt -Doracle.server.config.dir=/opt/app/oracle/Middleware12105/gc_inst/user_projects/domains/EMTASDev/config/fmwconfig/servers/EMGC_ADMINSERVER -Doracle.domain.config.dir=/opt/app/oracle/Middleware12105/gc_inst/user_projects/domains/EMTASDev/config/fmwconfig -Digf.arisidbeans.carmlloc=/opt/app/oracle/Middleware12105/gc_inst/user_projects/domains/EMTASDev/config/fmwconfig/carml -Digf.arisidstack.home=/opt/app/oracle/Middleware12105/gc_inst/user_projects/domains/EMTASDev/config/fmwconfig/arisidprovider -Doracle.security.jps.config=/opt/app/oracle/Middleware12105/gc_inst/user_projects/domains/EMTASDev/config/fmwconfig/jps-config.xml -Doracle.deployed.app.dir=/opt/app/oracle/Middleware12105/gc_inst/user_projects/domains/EMTASDev/servers/EMGC_ADMINSERVER/tmp/_WL_user -Doracle.deployed.app.ext=/- -Dweblogic.alternateTypesDirectory=/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.ossoiap_11.1.1,/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.oamprovider_11.1.1,/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.jps_11.1.1,/opt/app/oracle/Middleware12105/oms/sysman/jlib -Djava.protocol.handler.pkgs=oracle.mds.net.protocol -Dweblogic.jdbc.remoteEnabled=false -Doracle.apm.home=/opt/app/oracle/Middleware12105/oms/apm/ -DAPM_HELP_FILENAME=oesohwconfig.xml -Dweblogic.management.discover=true -Dwlw.iterativeDev=false -Dwlw.testConsole=false -Dwlw.logErrorsToConsole=false -Dweblogic.ext.dirs=/opt/app/oracle/Middleware12105/patch_wls1036/profiles/default/sysext_manifest_classpath weblogic.Server
oracle   25898 24020  0 21:32 pts/0    00:00:00 grep oms

wdl2tsysdbs03.tsysacquiring.org:/home/oracle>  ps -eaf| grep agent
oracle    4691     1  0 Jan08 ?        00:57:21 /opt/app/oracle/Middleware12105/jdk16/jdk/jre/bin/java -Xms126m -Xmx382m -Dweblogic.security.SSL.enableJSSE=true -Djava.security.egd=file:///dev/./urandom -classpath /opt/app/oracle/Middleware12105/jdk16/jdk/jre/lib/rt.jar:/opt/app/oracle/Middleware12105/jdk16/jdk/jre/lib/i18n.jar:/opt/app/oracle/Middleware12105/patch_wls1036/profiles/default/sys_manifest_classpath/weblogic_patch.jar:/opt/app/oracle/Middleware12105/jdk16/jdk/lib/tools.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic_sp.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic.jar:/opt/app/oracle/Middleware12105/modules/features/weblogic.server.modules_10.3.6.0.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/webservices.jar:/opt/app/oracle/Middleware12105/modules/org.apache.ant_1.7.1/lib/ant-all.jar:/opt/app/oracle/Middleware12105/modules/net.sf.antcontrib_1.1.0.0_1-0b2/lib/ant-contrib.jar:/opt/app/oracle/Middleware12105/patch_wls1036/profiles/default/sys_manifest_classpath/weblogic_patch.jar:/opt/app/oracle/Middleware12105/jdk16/jdk/lib/tools.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic_sp.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/weblogic.jar:/opt/app/oracle/Middleware12105/modules/features/weblogic.server.modules_10.3.6.0.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/server/lib/webservices.jar:/opt/app/oracle/Middleware12105/modules/org.apache.ant_1.7.1/lib/ant-all.jar:/opt/app/oracle/Middleware12105/modules/net.sf.antcontrib_1.1.0.0_1-0b2/lib/ant-contrib.jar:/opt/app/oracle/Middleware12105/oms/sysman/jlib/emagentSDK.jar:/opt/app/oracle/Middleware12105/oms/sysman/jlib/emCORE.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.http_client_11.1.1.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.pki_11.1.1/oraclepki.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.osdt_11.1.1/osdt_cert.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.osdt_11.1.1/osdt_core.jar:/opt/app/oracle/Middleware12105/modules/com.bea.core.apache.log4j_1.2.13.jar:/opt/app/oracle/Middleware12105/oracle_common/modules/oracle.jrf_11.1.1/jrf-wlstman.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/lib/adfscripting.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/lib/adf-share-mbeans-wlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/lib/mdswlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/auditwlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/igfwlsthelp.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/jps-wlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/jps-wls-trustprovider.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/jrf-wlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/oamap_help.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/oamAuthnProvider.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/ossoiap_help.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/ossoiap.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/ovdwlsthelp.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/sslconfigwlst.jar:/opt/app/oracle/Middleware12105/oracle_common/common/wlst/resources/wsm-wlst.jar:/opt/app/oracle/Middleware12105/utils/config/10.3/config-launch.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/common/derby/lib/derbynet.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/common/derby/lib/derbyclient.jar:/opt/app/oracle/Middleware12105/wlserver_10.3/common/derby/lib/derbytools.jar -DListenAddress=wdl2tsysdbs03.tsysacquiring.org -DNodeManagerHome=/opt/app/oracle/Middleware12105/gc_inst/NodeManager/emnodemanager -DQuitEnabled=true -DListenPort=7403 weblogic.NodeManager
oracle    5141 24020  0 21:34 pts/0    00:00:00 grep agent
oracle    9016     1  0 Jan08 ?        00:04:00 /opt/app/oracle/Agent/core/12.1.0.2.0/perl/bin/perl /opt/app/oracle/Agent/core/12.1.0.2.0/bin/emwd.pl agent /opt/app/oracle/Agent/agent_inst/sysman/log/emagent.nohup
oracle    9070  9016  0 Jan08 ?        03:56:54 /opt/app/oracle/Agent/core/12.1.0.2.0/jdk/bin/java -Xmx140M -XX:MaxPermSize=96M -server -Djava.security.egd=file:///dev/./urandom -Dsun.lang.ClassLoader.allowArraySyntax=true -XX:+UseLinuxPosixThreadCPUClocks -XX:+UseConcMarkSweepGC -XX:+CMSClassUnloadingEnabled -XX:+UseCompressedOops -Dwatchdog.pid=9016 -cp /opt/app/oracle/Agent/core/12.1.0.2.0/jdbc/lib/ojdbc5.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/ucp/lib/ucp.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/modules/oracle.http_client_11.1.1.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/lib/xmlparserv2.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/lib/jsch.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/lib/optic.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/modules/oracle.dms_11.1.1/dms.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/modules/oracle.odl_11.1.1/ojdl.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/modules/oracle.odl_11.1.1/ojdl2.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/sysman/jlib/log4j-core.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/jlib/gcagent_core.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/sysman/jlib/emagentSDK-intg.jar:/opt/app/oracle/Agent/core/12.1.0.2.0/sysman/jlib/emagentSDK.jar oracle.sysman.gcagent.tmmain.TMMain
root     15839  1686  0 Jan29 ?        00:00:29 lw-container gpagent
wdl2tsysdbs03.tsysacquiring.org:/home/oracle>



---------------15 feb-----

[oracle@regdbnode1 ~]$ df -Ph
Filesystem                                 Size  Used Avail Use% Mounted on
/dev/mapper/lvg1-lvm2                       25G   11G   13G  47% /
tmpfs                                      7.8G   12K  7.8G   1% /dev/shm
/dev/sda1                                  477M  120M  332M  27% /boot
/dev/sdd                                    99G   41G   53G  44% /recovery
/dev/sde                                    99G  5.6G   88G   6% /backup
/dev/mapper/lvg2-lvm3                      149G   46G   96G  33% /opt
10.100.226.130:/oradata4/oracle/exp_bkups  493G  256G  212G  55% /backups
[oracle@regdbnode1 ~]$ ps -eaf | grep tns
root        37     2  0 Jan13 ?        00:00:00 [netns]
oracle   29885 28876  0 20:23 pts/0    00:00:00 grep tns
[oracle@regdbnode1 ~]$ ps -eaf | grep pmon
oracle   30018 28876  0 20:23 pts/0    00:00:00 grep pmon
[oracle@regdbnode1 ~]$ date
Thu Feb 14 20:23:19 PST 2019
[oracle@regdbnode1 ~]$ uname -a
Linux regdbnode1.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
[oracle@regdbnode1 ~]$



[oracle@qadbnode1 ~]$ crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.CRSVTGRP.dg
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.LISTENER.lsnr
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.ORADATA.dg
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.asm
               ONLINE  ONLINE       qadbnode1                Started
               ONLINE  ONLINE       qadbnode2                Started
ora.gsd
               OFFLINE OFFLINE      qadbnode1
               OFFLINE OFFLINE      qadbnode2
ora.net1.network
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.ons
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.registry.acfs
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       qadbnode2
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       qadbnode1
ora.LISTENER_SCAN3.lsnr
      1        ONLINE  ONLINE       qadbnode1
ora.cvu
      1        ONLINE  ONLINE       qadbnode1
ora.oc4j
      1        ONLINE  ONLINE       qadbnode1
ora.qadbnode1.vip
      1        ONLINE  ONLINE       qadbnode1
ora.qadbnode2.vip
      1        ONLINE  ONLINE       qadbnode2
ora.qaracdb.db
      1        ONLINE  ONLINE       qadbnode1                Open
      2        ONLINE  ONLINE       qadbnode2                Open
ora.qaracdb.qaracdbtaf.svc
      1        ONLINE  ONLINE       qadbnode1
      2        ONLINE  ONLINE       qadbnode2
ora.scan1.vip
      1        ONLINE  ONLINE       qadbnode2
ora.scan2.vip
      1        ONLINE  ONLINE       qadbnode1
ora.scan3.vip
      1        ONLINE  ONLINE       qadbnode1
[oracle@qadbnode1 ~]$ ps -eaf | grep pmon
oracle    6833     1  0 Jan13 ?        00:11:32 asm_pmon_+ASM1
oracle    7696     1  0 Jan13 ?        00:25:48 ora_pmon_qaracdb1
oracle   25368 24847  0 20:30 pts/0    00:00:00 grep pmon
[oracle@qadbnode1 ~]$ ps -eaf | grep tns
root        37     2  0 Jan13 ?        00:00:00 [netns]
oracle    7448     1  0 Jan13 ?        00:22:49 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER -inherit
oracle   11452     1  0 Jan13 ?        00:13:19 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER_SCAN3 -inherit
oracle   11454     1  0 Jan13 ?        00:11:39 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER_SCAN2 -inherit
oracle   25386 24847  0 20:30 pts/0    00:00:00 grep tns
[oracle@qadbnode1 ~]$ ps -eaf | grep mgr
root        38     2  0 Jan13 ?        00:00:00 [async/mgr]
oracle   25414 24847  0 20:30 pts/0    00:00:00 grep mgr
[oracle@qadbnode1 ~]$ df -Ph
Filesystem                                Size  Used Avail Use% Mounted on
/dev/mapper/lvg1-lvm2                      25G  7.4G   17G  31% /
tmpfs                                     9.8G  5.2G  4.7G  53% /dev/shm
/dev/sda1                                 477M  147M  305M  33% /boot
/dev/sdb                                   50G   41G  6.3G  87% /opt
/dev/sdd                                   99G   32G   62G  34% /recovery
/dev/sde                                   99G   13G   81G  14% /backup
10.100.224.80:/oradata4/oracle/exp_bkups  493G  256G  212G  55% /backups
[oracle@qadbnode1 ~]$ uname -a
Linux qadbnode1.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
[oracle@qadbnode1 ~]$


[oracle@qadbnode2 ~]$ ps -eaf | grep pmon
oracle    5376     1  0 Jan13 ?        00:11:28 asm_pmon_+ASM2
oracle    6860     1  0 Jan13 ?        00:25:27 ora_pmon_qaracdb2
oracle   11981  8503  0 20:36 pts/0    00:00:00 grep pmon
[oracle@qadbnode2 ~]$ ps -eaf | grep tns
root        37     2  0 Jan13 ?        00:00:00 [netns]
oracle    6348     1  0 Jan13 ?        00:18:00 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER -inherit
oracle    6432     1  0 Jan13 ?        00:12:30 /opt/app/11.2.0/grid4/bin/tnslsnr LISTENER_SCAN1 -inherit
oracle   11984  8503  0 20:36 pts/0    00:00:00 grep tns
[oracle@qadbnode2 ~]$ ps -eaf | grep oms
oracle   11987  8503  0 20:36 pts/0    00:00:00 grep oms
[oracle@qadbnode2 ~]$ ps -eaf | grep agent
oracle    3584     1  0 Jan13 ?        00:04:13 /opt/app/oracle/product/agent/core/12.1.0.2.0/perl/bin/perl /opt/app/oracle/product/agent/core/12.1.0.2.0/bin/emwd.pl agent /opt/app/oracle/product/agent/agent_inst/sysman/log/emagent.nohup
oracle    3812     1  0 Jan13 ?        02:53:30 /opt/app/11.2.0/grid4/bin/oraagent.bin
oracle    3829  3584  0 Jan13 ?        02:41:27 /opt/app/oracle/product/agent/core/12.1.0.2.0/jdk/bin/java -Xmx128M -XX:MaxPermSize=96M -server -Djava.security.egd=file:///dev/./urandom -Dsun.lang.ClassLoader.allowArraySyntax=true -XX:+UseLinuxPosixThreadCPUClocks -XX:+UseConcMarkSweepGC -XX:+CMSClassUnloadingEnabled -XX:+UseCompressedOops -Dwatchdog.pid=3584 -cp /opt/app/oracle/product/agent/core/12.1.0.2.0/jdbc/lib/ojdbc5.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/ucp/lib/ucp.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/modules/oracle.http_client_11.1.1.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/lib/xmlparserv2.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/lib/jsch.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/lib/optic.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/modules/oracle.dms_11.1.1/dms.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/modules/oracle.odl_11.1.1/ojdl.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/modules/oracle.odl_11.1.1/ojdl2.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/sysman/jlib/log4j-core.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/jlib/gcagent_core.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/sysman/jlib/emagentSDK-intg.jar:/opt/app/oracle/product/agent/core/12.1.0.2.0/sysman/jlib/emagentSDK.jar oracle.sysman.gcagent.tmmain.TMMain
root      3894     1  0 Jan13 ?        04:17:07 /opt/app/11.2.0/grid4/bin/orarootagent.bin
root      3986     1  0 Jan13 ?        00:52:00 /opt/app/11.2.0/grid4/bin/cssdagent
oracle    5987     1  0 Jan13 ?        06:46:19 /opt/app/11.2.0/grid4/bin/oraagent.bin
root      5991     1  0 Jan13 ?        06:13:42 /opt/app/11.2.0/grid4/bin/orarootagent.bin
oracle   11990  8503  0 20:36 pts/0    00:00:00 grep agent
root     29488  2138  0 Feb04 ?        00:00:34 lw-container gpagent
[oracle@qadbnode2 ~]$
[oracle@qadbnode2 ~]$ uname -a
Linux qadbnode2.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
[oracle@qadbnode2 ~]$ date
Thu Feb 14 20:36:24 PST 2019
[oracle@qadbnode2 ~]$ crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.CRSVTGRP.dg
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.LISTENER.lsnr
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.ORADATA.dg
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.asm
               ONLINE  ONLINE       qadbnode1                Started
               ONLINE  ONLINE       qadbnode2                Started
ora.gsd
               OFFLINE OFFLINE      qadbnode1
               OFFLINE OFFLINE      qadbnode2
ora.net1.network
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.ons
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
ora.registry.acfs
               ONLINE  ONLINE       qadbnode1
               ONLINE  ONLINE       qadbnode2
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       qadbnode2
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       qadbnode1
ora.LISTENER_SCAN3.lsnr
      1        ONLINE  ONLINE       qadbnode1
ora.cvu
      1        ONLINE  ONLINE       qadbnode1
ora.oc4j
      1        ONLINE  ONLINE       qadbnode1
ora.qadbnode1.vip
      1        ONLINE  ONLINE       qadbnode1
ora.qadbnode2.vip
      1        ONLINE  ONLINE       qadbnode2
ora.qaracdb.db
      1        ONLINE  ONLINE       qadbnode1                Open
      2        ONLINE  ONLINE       qadbnode2                Open
ora.qaracdb.qaracdbtaf.svc
      1        ONLINE  ONLINE       qadbnode1
      2        ONLINE  ONLINE       qadbnode2
ora.scan1.vip
      1        ONLINE  ONLINE       qadbnode2
ora.scan2.vip
      1        ONLINE  ONLINE       qadbnode1
ora.scan3.vip
      1        ONLINE  ONLINE       qadbnode1
[oracle@qadbnode2 ~]$ df -Ph
Filesystem             Size  Used Avail Use% Mounted on
/dev/mapper/lvg1-lvm2   25G  6.7G   18G  29% /
tmpfs                  9.8G  5.2G  4.7G  53% /dev/shm
/dev/sda1              477M  147M  305M  33% /boot
/dev/sdd                99G   12G   83G  12% /recovery
/dev/sde                99G  8.0G   86G   9% /backup
/dev/mapper/lvg2-lvm3  100G   41G   54G  43% /opt
[oracle@qadbnode2 ~]$
[oracle@qadbnode2 ~]$




wql1trandbs03.tsysacquiring.org:/home/oracle> ps -eaf | grep pmon
oracle    7399     1  0 Feb13 ?        00:00:39 asm_pmon_+ASM3
oracle    8934     1  0 Feb13 ?        00:00:45 ora_pmon_rptDCE3
oracle   25250 25086  0 21:04 pts/0    00:00:00 grep pmon
wql1trandbs03.tsysacquiring.org:/home/oracle> ps -eaf | grep tns
root        37     2  0 Feb13 ?        00:00:00 [netns]
oracle    8591     1  0 Feb13 ?        00:00:14 /opt/app/11.2.0/grid_1/bin/tnslsnr LISTENER -inherit
oracle    8622     1  0 Feb13 ?        00:00:11 /opt/app/11.2.0/grid_1/bin/tnslsnr LISTENER_SCAN2 -inherit
oracle   25257 25086  0 21:04 pts/0    00:00:00 grep tns
wql1trandbs03.tsysacquiring.org:/home/oracle> ps -eaf | grep oms
oracle   25260 25086  0 21:04 pts/0    00:00:00 grep oms
wql1trandbs03.tsysacquiring.org:/home/oracle> ps -eaf | grep agent
root      3444  3271  0 Feb13 ?        00:00:04 lw-container gpagent
oracle    6209     1  0 Feb13 ?        00:00:13 /opt/app/oracle/agent/core/12.1.0.2.0/perl/bin/perl /opt/app/oracle/agent/core/12.1.0.2.0/bin/emwd.pl agent /opt/app/oracle/agent/agent_inst/sysman/log/emagent.nohup
oracle    6263     1  0 Feb13 ?        00:08:39 /opt/app/11.2.0/grid_1/bin/oraagent.bin
oracle    6311  6209  0 Feb13 ?        00:08:39 /opt/app/oracle/agent/core/12.1.0.2.0/jdk/bin/java -Xmx128M -XX:MaxPermSize=96M -server -Djava.security.egd=file:///dev/./urandom -Dsun.lang.ClassLoader.allowArraySyntax=true -XX:+UseLinuxPosixThreadCPUClocks -XX:+UseConcMarkSweepGC -XX:+CMSClassUnloadingEnabled -XX:+UseCompressedOops -Dwatchdog.pid=6209 -cp /opt/app/oracle/agent/core/12.1.0.2.0/jdbc/lib/ojdbc5.jar:/opt/app/oracle/agent/core/12.1.0.2.0/ucp/lib/ucp.jar:/opt/app/oracle/agent/core/12.1.0.2.0/modules/oracle.http_client_11.1.1.jar:/opt/app/oracle/agent/core/12.1.0.2.0/lib/xmlparserv2.jar:/opt/app/oracle/agent/core/12.1.0.2.0/lib/jsch.jar:/opt/app/oracle/agent/core/12.1.0.2.0/lib/optic.jar:/opt/app/oracle/agent/core/12.1.0.2.0/modules/oracle.dms_11.1.1/dms.jar:/opt/app/oracle/agent/core/12.1.0.2.0/modules/oracle.odl_11.1.1/ojdl.jar:/opt/app/oracle/agent/core/12.1.0.2.0/modules/oracle.odl_11.1.1/ojdl2.jar:/opt/app/oracle/agent/core/12.1.0.2.0/sysman/jlib/log4j-core.jar:/opt/app/oracle/agent/core/12.1.0.2.0/jlib/gcagent_core.jar:/opt/app/oracle/agent/core/12.1.0.2.0/sysman/jlib/emagentSDK-intg.jar:/opt/app/oracle/agent/core/12.1.0.2.0/sysman/jlib/emagentSDK.jar oracle.sysman.gcagent.tmmain.TMMain
root      6338     1  0 Feb13 ?        00:12:28 /opt/app/11.2.0/grid_1/bin/orarootagent.bin
root      6426     1  0 Feb13 ?        00:02:24 /opt/app/11.2.0/grid_1/bin/cssdagent
oracle    8060     1  1 Feb13 ?        00:29:38 /opt/app/11.2.0/grid_1/bin/oraagent.bin
root      8064     1  0 Feb13 ?        00:17:51 /opt/app/11.2.0/grid_1/bin/orarootagent.bin
oracle   25263 25086  0 21:04 pts/0    00:00:00 grep agent
wql1trandbs03.tsysacquiring.org:/home/oracle>
wql1trandbs03.tsysacquiring.org:/home/oracle> uname -a
Linux wql1trandbs03.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
wql1trandbs03.tsysacquiring.org:/home/oracle> date
Thu Feb 14 21:04:32 PST 2019
wql1trandbs03.tsysacquiring.org:/home/oracle> crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.ACFS.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ASMRPTDATA.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ASMTEARCHIVE.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ASMTEBASEDB.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ASMTXNDATA.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.LISTENER.lsnr
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.OCR_VOTE.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.asm
               ONLINE  ONLINE       wql1trandbs01            Started
               ONLINE  ONLINE       wql1trandbs02            Started
               ONLINE  ONLINE       wql1trandbs03            Started
ora.gsd
               OFFLINE OFFLINE      wql1trandbs01
               OFFLINE OFFLINE      wql1trandbs02
               OFFLINE OFFLINE      wql1trandbs03
ora.net1.network
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ons
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.registry.acfs
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       wql1trandbs02
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       wql1trandbs03
ora.LISTENER_SCAN3.lsnr
      1        ONLINE  ONLINE       wql1trandbs01
ora.cvu
      1        ONLINE  ONLINE       wql1trandbs01
ora.oc4j
      1        ONLINE  ONLINE       wql1trandbs01
ora.rptdce.db
      1        ONLINE  ONLINE       wql1trandbs01            Open
      2        ONLINE  ONLINE       wql1trandbs02            Open
      3        ONLINE  ONLINE       wql1trandbs03            Open
ora.rptdce.transitrpt.svc
      1        ONLINE  UNKNOWN      wql1trandbs03
      2        ONLINE  ONLINE       wql1trandbs02
      3        ONLINE  ONLINE       wql1trandbs01
ora.scan1.vip
      1        ONLINE  ONLINE       wql1trandbs02
ora.scan2.vip
      1        ONLINE  ONLINE       wql1trandbs03
ora.scan3.vip
      1        ONLINE  ONLINE       wql1trandbs01
ora.txndce.db
      1        ONLINE  ONLINE       wql1trandbs01            Open
      2        ONLINE  ONLINE       wql1trandbs02            Open
      3        ONLINE  OFFLINE
ora.txndce.transittxn.svc
      1        ONLINE  OFFLINE
      2        ONLINE  ONLINE       wql1trandbs01
      3        ONLINE  ONLINE       wql1trandbs02
ora.wql1trandbs01.vip
      1        ONLINE  ONLINE       wql1trandbs01
ora.wql1trandbs02.vip
      1        ONLINE  ONLINE       wql1trandbs02
ora.wql1trandbs03.vip
      1        ONLINE  ONLINE       wql1trandbs03
wql1trandbs03.tsysacquiring.org:/home/oracle> df -Ph
Filesystem                      Size  Used Avail Use% Mounted on
/dev/mapper/VolGroup-lv_root     49G   19G   27G  42% /
tmpfs                            32G  3.7G   28G  12% /dev/shm
/dev/sda1                       477M  100M  352M  23% /boot
/dev/mapper/VolGroup-lv_home     49G  273M   46G   1% /home
/dev/mapper/vg_orabin3-lv_opt3   98G   48G   46G  51% /opt
/dev/asm/goldengate-390         299G   37G  263G  13% /acfs
wql1trandbs03.tsysacquiring.org:/home/oracle>
wql1trandbs03.tsysacquiring.org:/home/oracle>
wql1trandbs01.tsysacquiring.org:/home/oracle> ps -eaf | grep pmon
oracle    9050     1  0 Feb13 ?        00:00:40 asm_pmon_+ASM1
oracle   10141     1  0 Feb13 ?        00:00:48 ora_pmon_rptDCE1
oracle   10146     1  0 Feb13 ?        00:00:49 ora_pmon_txnDCE1
oracle   59488 48904  0 21:07 pts/0    00:00:00 grep pmon
wql1trandbs01.tsysacquiring.org:/home/oracle> ps -eaf | grep tns
root        37     2  0 Feb13 ?        00:00:00 [netns]
oracle    9803     1  0 Feb13 ?        00:00:15 /opt/app/11.2.0/grid_1/bin/tnslsnr LISTENER -inherit
oracle   14459     1  0 Feb13 ?        00:00:11 /opt/app/11.2.0/grid_1/bin/tnslsnr LISTENER_SCAN3 -inherit
oracle   59491 48904  0 21:07 pts/0    00:00:00 grep tns
wql1trandbs01.tsysacquiring.org:/home/oracle> ps -eaf | grep oms
oracle   59494 48904  0 21:07 pts/0    00:00:00 grep oms
wql1trandbs01.tsysacquiring.org:/home/oracle> ps -eaf | grep agent
root      3420  3243  0 Feb13 ?        00:00:04 lw-container gpagent
oracle    6044     1  0 Feb13 ?        00:00:14 /opt/app/oracle/agent/core/12.1.0.2.0/perl/bin/perl /opt/app/oracle/agent/core/12.1.0.2.0/bin/emwd.pl agent /opt/app/oracle/agent/agent_inst/sysman/log/emagent.nohup
oracle    6214  6044  0 Feb13 ?        00:16:35 /opt/app/oracle/agent/core/12.1.0.2.0/jdk/bin/java -Xmx128M -XX:MaxPermSize=96M -server -Djava.security.egd=file:///dev/./urandom -Dsun.lang.ClassLoader.allowArraySyntax=true -XX:+UseLinuxPosixThreadCPUClocks -XX:+UseConcMarkSweepGC -XX:+CMSClassUnloadingEnabled -XX:+UseCompressedOops -Dwatchdog.pid=6044 -cp /opt/app/oracle/agent/core/12.1.0.2.0/jdbc/lib/ojdbc5.jar:/opt/app/oracle/agent/core/12.1.0.2.0/ucp/lib/ucp.jar:/opt/app/oracle/agent/core/12.1.0.2.0/modules/oracle.http_client_11.1.1.jar:/opt/app/oracle/agent/core/12.1.0.2.0/lib/xmlparserv2.jar:/opt/app/oracle/agent/core/12.1.0.2.0/lib/jsch.jar:/opt/app/oracle/agent/core/12.1.0.2.0/lib/optic.jar:/opt/app/oracle/agent/core/12.1.0.2.0/modules/oracle.dms_11.1.1/dms.jar:/opt/app/oracle/agent/core/12.1.0.2.0/modules/oracle.odl_11.1.1/ojdl.jar:/opt/app/oracle/agent/core/12.1.0.2.0/modules/oracle.odl_11.1.1/ojdl2.jar:/opt/app/oracle/agent/core/12.1.0.2.0/sysman/jlib/log4j-core.jar:/opt/app/oracle/agent/core/12.1.0.2.0/jlib/gcagent_core.jar:/opt/app/oracle/agent/core/12.1.0.2.0/sysman/jlib/emagentSDK-intg.jar:/opt/app/oracle/agent/core/12.1.0.2.0/sysman/jlib/emagentSDK.jar oracle.sysman.gcagent.tmmain.TMMain
oracle    6460     1  0 Feb13 ?        00:08:44 /opt/app/11.2.0/grid_1/bin/oraagent.bin
root      6667     1  0 Feb13 ?        00:12:57 /opt/app/11.2.0/grid_1/bin/orarootagent.bin
root      7048     1  0 Feb13 ?        00:02:26 /opt/app/11.2.0/grid_1/bin/cssdagent
oracle    9425     1  1 Feb13 ?        00:36:31 /opt/app/11.2.0/grid_1/bin/oraagent.bin
root      9429     1  0 Feb13 ?        00:18:32 /opt/app/11.2.0/grid_1/bin/orarootagent.bin
503       9872  9849  0 Feb13 ?        00:02:40 /acfs/goldengate/ggcmd PARAMFILE /acfs/goldengate/dirprm/jagent.prm REPORTFILE /acfs/goldengate/dirrpt/JAGENT.rpt PROCESSID JAGENT USESUBDIRS
503       9877  9872  0 Feb13 ?        00:02:18 java -jar -Xms64m -Xmx512m dirjar/jagent.jar
oracle   14641     1  0 Feb13 ?        00:00:39 /opt/app/11.2.0/grid_1/bin/scriptagent.bin
oracle   59497 48904  0 21:07 pts/0    00:00:00 grep agent
wql1trandbs01.tsysacquiring.org:/home/oracle>
wql1trandbs01.tsysacquiring.org:/home/oracle> uname -a
Linux wql1trandbs01.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
wql1trandbs01.tsysacquiring.org:/home/oracle> date
Thu Feb 14 21:07:40 PST 2019
wql1trandbs01.tsysacquiring.org:/home/oracle> crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.ACFS.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ASMRPTDATA.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ASMTEARCHIVE.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ASMTEBASEDB.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ASMTXNDATA.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.LISTENER.lsnr
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.OCR_VOTE.dg
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.asm
               ONLINE  ONLINE       wql1trandbs01            Started
               ONLINE  ONLINE       wql1trandbs02            Started
               ONLINE  ONLINE       wql1trandbs03            Started
ora.gsd
               OFFLINE OFFLINE      wql1trandbs01
               OFFLINE OFFLINE      wql1trandbs02
               OFFLINE OFFLINE      wql1trandbs03
ora.net1.network
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.ons
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
ora.registry.acfs
               ONLINE  ONLINE       wql1trandbs01
               ONLINE  ONLINE       wql1trandbs02
               ONLINE  ONLINE       wql1trandbs03
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       wql1trandbs02
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       wql1trandbs03
ora.LISTENER_SCAN3.lsnr
      1        ONLINE  ONLINE       wql1trandbs01
ora.cvu
      1        ONLINE  ONLINE       wql1trandbs01
ora.oc4j
      1        ONLINE  ONLINE       wql1trandbs01
ora.rptdce.db
      1        ONLINE  ONLINE       wql1trandbs01            Open
      2        ONLINE  ONLINE       wql1trandbs02            Open
      3        ONLINE  ONLINE       wql1trandbs03            Open
ora.rptdce.transitrpt.svc
      1        ONLINE  UNKNOWN      wql1trandbs03
      2        ONLINE  ONLINE       wql1trandbs02
      3        ONLINE  ONLINE       wql1trandbs01
ora.scan1.vip
      1        ONLINE  ONLINE       wql1trandbs02
ora.scan2.vip
      1        ONLINE  ONLINE       wql1trandbs03
ora.scan3.vip
      1        ONLINE  ONLINE       wql1trandbs01
ora.txndce.db
      1        ONLINE  ONLINE       wql1trandbs01            Open
      2        ONLINE  ONLINE       wql1trandbs02            Open
      3        ONLINE  OFFLINE
ora.txndce.transittxn.svc
      1        ONLINE  OFFLINE
      2        ONLINE  ONLINE       wql1trandbs01
      3        ONLINE  ONLINE       wql1trandbs02
ora.wql1trandbs01.vip
      1        ONLINE  ONLINE       wql1trandbs01
ora.wql1trandbs02.vip
      1        ONLINE  ONLINE       wql1trandbs02
ora.wql1trandbs03.vip
      1        ONLINE  ONLINE       wql1trandbs03
wql1trandbs01.tsysacquiring.org:/home/oracle> df -Ph
Filesystem                      Size  Used Avail Use% Mounted on
/dev/mapper/VolGroup-lv_root     84G   52G   28G  65% /
tmpfs                            32G   16G   16G  50% /dev/shm
/dev/sda1                       477M  100M  352M  22% /boot
/dev/mapper/VolGroup-lv_home     49G  268M   46G   1% /home
/dev/mapper/vg_orabin1-lv_opt1   98G   53G   41G  57% /opt
/dev/mapper/vg_bkp-lv_bkp       196G  133G   54G  72% /backup
/dev/asm/goldengate-390         299G   37G  263G  13% /acfs
wql1trandbs01.tsysacquiring.org:/home/oracle>
wql1trandbs01.tsysacquiring.org:/home/oracle>



vishalbh@octov1:/home/vishalbh$ pbrun -h wql2mltidbs01.tsysacquiring.org        su -
[root@wql2mltidbs01 ~]#
[root@wql2mltidbs01 ~]# ps -eaf | grep pmon
root      2521  2493  0 21:09 pts/0    00:00:00 grep pmon
[root@wql2mltidbs01 ~]# ps -eaf | grep tns
root        21     2  0 Jan14 ?        00:00:00 [netns]
root      2524  2493  0 21:09 pts/0    00:00:00 grep tns
[root@wql2mltidbs01 ~]# ps -eaf | grep agent
oracle    2047     1  0 Jan14 ?        00:00:00 /usr/bin/ck-xinit-session /usr/bin/ssh-agent /etc/X11/xinit/Xclients
oracle    2208  2207  0 Jan14 ?        00:00:14 /usr/bin/ssh-agent /etc/X11/xinit/Xclients
oracle    2323  2207  0 Jan14 ?        00:00:00 /usr/libexec/polkit-gnome-authentication-agent-1
root      2527  2493  0 21:09 pts/0    00:00:00 grep agent
root     22231  1541  0 Feb04 ?        00:00:30 lw-container gpagent
[root@wql2mltidbs01 ~]# ps -eaf | grep oms
root      2534  2493  0 21:09 pts/0    00:00:00 grep oms
[root@wql2mltidbs01 ~]# uname -a
Linux wql2mltidbs01.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
[root@wql2mltidbs01 ~]# date
Thu Feb 14 21:09:30 PST 2019
[root@wql2mltidbs01 ~]#

-----21 feb 2018

wul2trandbs06.tsysacquiring.org:/home/oracle> crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.ASMRPTARCHIVE.dg
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
ora.ASMRPTBASEDB.dg
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
ora.ASMRPTDATA.dg
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
ora.ASMRPTGOLDENGATE.dg
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
ora.LISTENER.lsnr
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
ora.OCR_VOTE.dg
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
ora.asm
               ONLINE  ONLINE       wul2trandbs06            Started
               ONLINE  ONLINE       wul2trandbs07            Started
ora.gsd
               OFFLINE OFFLINE      wul2trandbs06
               OFFLINE OFFLINE      wul2trandbs07
ora.net1.network
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
ora.ons
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
ora.registry.acfs
               ONLINE  ONLINE       wul2trandbs06
               ONLINE  ONLINE       wul2trandbs07
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       wul2trandbs07
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       wul2trandbs06
ora.cvu
      1        ONLINE  ONLINE       wul2trandbs06
ora.oc4j
      1        ONLINE  ONLINE       wul2trandbs06
ora.scan1.vip
      1        ONLINE  ONLINE       wul2trandbs07
ora.scan2.vip
      1        ONLINE  ONLINE       wul2trandbs06
ora.urptdb.db
      1        ONLINE  ONLINE       wul2trandbs06            Open
      2        ONLINE  ONLINE       wul2trandbs07            Open
ora.urptdb.uattransitrpt.svc
      1        ONLINE  ONLINE       wul2trandbs06
      2        ONLINE  ONLINE       wul2trandbs07
ora.utxndb.db
      1        ONLINE  ONLINE       wul2trandbs06            Open
      2        ONLINE  ONLINE       wul2trandbs07            Open
ora.utxndb.uattransittxn.svc
      1        ONLINE  ONLINE       wul2trandbs06
      2        ONLINE  ONLINE       wul2trandbs07
ora.utxndb.uattxndb.svc
      1        ONLINE  ONLINE       wul2trandbs06
      2        ONLINE  ONLINE       wul2trandbs07
ora.wul2trandbs06.vip
      1        ONLINE  ONLINE       wul2trandbs06
ora.wul2trandbs07.vip
      1        ONLINE  ONLINE       wul2trandbs07
wul2trandbs06.tsysacquiring.org:/home/oracle> uname -a
Linux wul2trandbs06.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
wul2trandbs06.tsysacquiring.org:/home/oracle> date
Wed Feb 20 21:30:12 PST 2019
wul2trandbs06.tsysacquiring.org:/home/oracle>






wul2trandbs04.tsysacquiring.org:/home/oracle> ps -eaf | grep pmon
oracle    6697     1  0 Jan20 ?        00:09:02 asm_pmon_+ASM1
oracle    7459     1  0 Jan20 ?        00:13:40 ora_pmon_uattxndb1
oracle    7461     1  0 Jan20 ?        00:09:43 ora_pmon_uatrptdb1
oracle   58942 58844  0 21:32 pts/2    00:00:00 grep pmon
wul2trandbs04.tsysacquiring.org:/home/oracle> ps -eaf | grep tns
root        21     2  0 Jan20 ?        00:00:00 [netns]
oracle    7379     1  0 Jan20 ?        00:23:55 /opt/app/product/11.2.0/grid_1/bin/tnslsnr LISTENER -inherit
oracle    8423     1  0 Jan20 ?        00:21:35 /opt/app/product/11.2.0/grid_1/bin/tnslsnr LISTENER_SCAN2 -inherit
oracle   58944 58844  0 21:32 pts/2    00:00:00 grep tns
wul2trandbs04.tsysacquiring.org:/home/oracle> ps -eaf | grep oms
oracle   58946 58844  0 21:32 pts/2    00:00:00 grep oms
wul2trandbs04.tsysacquiring.org:/home/oracle> ps -eaf | grep agent
root      2790     1  0 Jan24 ?        00:14:40 ./wrapper ./agent.conf wrapper.pidfile=../tmp/teagent.pid wrapper.daemonize=TRUE
oracle    4459     1  0 Jan20 ?        01:38:21 /opt/app/product/11.2.0/grid_1/bin/oraagent.bin
root      4580     1  0 Jan20 ?        03:01:33 /opt/app/product/11.2.0/grid_1/bin/orarootagent.bin
oracle    4600     1  0 Jan20 ?        00:02:54 /opt/app/oracle/agent/core/12.1.0.3.0/perl/bin/perl /opt/app/oracle/agent/core/12.1.0.3.0/bin/emwd.pl agent /opt/app/oracle/agent/agent_inst/sysman/log/emagent.nohup
root      4663     1  0 Jan20 ?        00:33:22 /opt/app/product/11.2.0/grid_1/bin/cssdagent
oracle    4805  4600  2 Jan20 ?        18:31:15 /opt/app/oracle/agent/core/12.1.0.3.0/jdk/bin/java -Xmx128M -XX:MaxPermSize=96M -server -Djava.security.egd=file:///dev/./urandom -Dsun.lang.ClassLoader.allowArraySyntax=true -XX:+UseLinuxPosixThreadCPUClocks -XX:+UseConcMarkSweepGC -XX:+CMSClassUnloadingEnabled -XX:+UseCompressedOops -Dwatchdog.pid=4600 -cp /opt/app/oracle/agent/core/12.1.0.3.0/jdbc/lib/ojdbc5.jar:/opt/app/oracle/agent/core/12.1.0.3.0/ucp/lib/ucp.jar:/opt/app/oracle/agent/core/12.1.0.3.0/modules/oracle.http_client_11.1.1.jar:/opt/app/oracle/agent/core/12.1.0.3.0/lib/xmlparserv2.jar:/opt/app/oracle/agent/core/12.1.0.3.0/lib/jsch.jar:/opt/app/oracle/agent/core/12.1.0.3.0/lib/optic.jar:/opt/app/oracle/agent/core/12.1.0.3.0/modules/oracle.dms_11.1.1/dms.jar:/opt/app/oracle/agent/core/12.1.0.3.0/modules/oracle.odl_11.1.1/ojdl.jar:/opt/app/oracle/agent/core/12.1.0.3.0/modules/oracle.odl_11.1.1/ojdl2.jar:/opt/app/oracle/agent/core/12.1.0.3.0/sysman/jlib/log4j-core.jar:/opt/app/oracle/agent/core/12.1.0.3.0/jlib/gcagent_core.jar:/opt/app/oracle/agent/core/12.1.0.3.0/sysman/jlib/emagentSDK-intg.jar:/opt/app/oracle/agent/core/12.1.0.3.0/sysman/jlib/emagentSDK.jar oracle.sysman.gcagent.tmmain.TMMain
oracle    6958     1  0 Jan20 ?        07:24:50 /opt/app/product/11.2.0/grid_1/bin/oraagent.bin
root      6970     1  0 Jan20 ?        03:32:06 /opt/app/product/11.2.0/grid_1/bin/orarootagent.bin
oracle    8360     1  0 Jan20 ?        00:08:39 /opt/app/product/11.2.0/grid_1/bin/scriptagent.bin
oracle   58951 58844  0 21:32 pts/2    00:00:00 grep agent
root     59584  2790  0 Jan30 ?        00:34:38 /usr/local/tripwire/te/agent/jre/bin/java -da -server -Dtw.server=false -Djava.security.manager=com.tripwire.kernel.ext.security.TripwireSecurityManager -Djava.security.properties=/usr/local/tripwire/te/agent/data/security/security.properties -Djava.security.policy==/usr/local/tripwire/te/agent/data/security/jaas.policy -XX:MetaspaceSize=20m -Djava.io.tmpdir=/usr/local/tripwire/te/agent/tmp -Dsun.rmi.dgc.server.gcInterval=3600000 -Dsun.rmi.dgc.client.gcInterval=3600000 -Dsun.rmi.dgc.checkInterval=1800000 -Djava.awt.headless=true -Dtw.home=/usr/local/tripwire/te/agent -Djava.rmi.server.useCodebaseOnly=true -XX:MaxMetaspaceSize=128m -Dorg.bouncycastle.rsa.allow_multi_use=true -Djavax.net.ssl.trustStore=/usr/local/tripwire/te/agent/data/security/merged_trust_store.ks -Djavax.net.ssl.trustStoreType=BCFKS -Djavax.net.ssl.trustStorePassword=changeit -Djavax.net.ssl.keyStoreType=BCFKS -Djava.security.egd=file:/dev/urandom -Djdk.tls.namedGroups="secp224r1, secp384r1, secp521r1, sect283k1, sect283r1, sect409k1, sect409r1, sect571k1, sect571r1" -Xms5m -Xmx256m -Djava.library.path=../lib -classpath ../lib/getopt.jar:../lib/tetool.jar:../lib/tw-kernel.jar:../lib/tw-launcher.jar:../lib/wrapper.jar:../lib/ext/bc-fips.jar:../lib/ext/bcpkix-jdk15on.jar:../lib/ext/cypher.jar:../lib/ext/tw-crypto-fips.jar:../lib/ext/tw-crypto-misc.jar:../lib/ext/tw-ext.jar:../data/config -Dwrapper.key=rRPGeqCGH9NMJUFDQQOPpo1CVxWTgjA8 -Dwrapper.port=32000 -Dwrapper.jvm.port.min=31000 -Dwrapper.jvm.port.max=31999 -Dwrapper.disable_console_input=TRUE -Dwrapper.pid=2790 -Dwrapper.use_system_time=TRUE -Dwrapper.version=3.5.25-st -Dwrapper.native_library=wrapper -Dwrapper.arch=x86 -Dwrapper.service=TRUE -Dwrapper.disable_shutdown_hook=TRUE -Dwrapper.cpu.timeout=10 -Dwrapper.jvmid=3 -Dwrapper.lang.domain=wrapper -Dwrapper.lang.folder=../lang com.tripwire.space.bootstrap.BootstrapLauncher
wul2trandbs04.tsysacquiring.org:/home/oracle>
wul2trandbs04.tsysacquiring.org:/home/oracle> uname -a
Linux wul2trandbs04.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
wul2trandbs04.tsysacquiring.org:/home/oracle> date
Wed Feb 20 21:32:06 PST 2019
wul2trandbs04.tsysacquiring.org:/home/oracle> crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.ACFS.dg
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
ora.ASMARCHIVE.dg
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
ora.ASMBASEDB.dg
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
ora.ASMTXNDATA.dg
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
ora.LISTENER.lsnr
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
ora.OCR_VOTE.dg
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
ora.asm
               ONLINE  ONLINE       wul2trandbs04            Started
               ONLINE  ONLINE       wul2trandbs05            Started
ora.gsd
               OFFLINE OFFLINE      wul2trandbs04
               OFFLINE OFFLINE      wul2trandbs05
ora.net1.network
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
ora.ons
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
ora.registry.acfs
               ONLINE  ONLINE       wul2trandbs04
               ONLINE  ONLINE       wul2trandbs05
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       wul2trandbs05
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       wul2trandbs04
ora.cvu
      1        ONLINE  ONLINE       wul2trandbs04
ora.oc4j
      1        ONLINE  ONLINE       wul2trandbs04
ora.scan1.vip
      1        ONLINE  ONLINE       wul2trandbs05
ora.scan2.vip
      1        ONLINE  ONLINE       wul2trandbs04
ora.uatrptdb.db
      1        ONLINE  ONLINE       wul2trandbs04            Open
      2        ONLINE  ONLINE       wul2trandbs05            Open
ora.uatrptdb.uattransitrpt.svc
      1        ONLINE  ONLINE       wul2trandbs04
      2        ONLINE  ONLINE       wul2trandbs05
ora.uattxndb.db
      1        ONLINE  ONLINE       wul2trandbs04            Open
      2        ONLINE  ONLINE       wul2trandbs05            Open
ora.uattxndb.uattransittxn.svc
      1        ONLINE  ONLINE       wul2trandbs04
      2        ONLINE  ONLINE       wul2trandbs05
ora.uattxndb.utxndb.svc
      1        ONLINE  ONLINE       wul2trandbs04
      2        ONLINE  ONLINE       wul2trandbs05
ora.wul2trandbs04.vip
      1        ONLINE  ONLINE       wul2trandbs04
ora.wul2trandbs05.vip
      1        ONLINE  ONLINE       wul2trandbs05
wul2trandbs04.tsysacquiring.org:/home/oracle> df -Ph
Filesystem                    Size  Used Avail Use% Mounted on
/dev/mapper/VolGroup-lv_root   29G   20G  7.9G  72% /
tmpfs                          12G  6.1G  5.7G  52% /dev/shm
/dev/sda1                     477M  100M  352M  23% /boot
/dev/mapper/vg_opt-lv_opt      49G   44G  2.3G  96% /opt
/dev/asm/goldengate-12         99G  4.5G   95G   5% /acfs/goldengate
wul2trandbs04.tsysacquiring.org:/home/oracle>
wul2trandbs04.tsysacquiring.org:/home/oracle>

--27-FEB


wul2mapxdbs01.tsysacquiring.org:/home/oracle> ps -eaf | grep pmon
oracle    5167     1  0 Jan23 ?        00:09:09 ora_pmon_mapuatdb
oracle   25135 25095  0 21:13 pts/0    00:00:00 grep pmon
wul2mapxdbs01.tsysacquiring.org:/home/oracle> ps -eaf | grep tns
root        37     2  0 Jan23 ?        00:00:00 [netns]
oracle    5420     1  0 Jan23 ?        00:03:46 /opt/oracle/product/11.2.0.4/bin/tnslsnr LISTENER -inherit
oracle   25141 25095  0 21:14 pts/0    00:00:00 grep tns
wul2mapxdbs01.tsysacquiring.org:/home/oracle> date
Tue Feb 26 21:14:41 EST 2019
wul2mapxdbs01.tsysacquiring.org:/home/oracle> uname -a
Linux wul2mapxdbs01.tsysacquiring.org 2.6.32-754.9.1.el6.x86_64 #1 SMP Wed Nov 21 15:08:21 EST 2018 x86_64 x86_64 x86_64 GNU/Linux
wul2mapxdbs01.tsysacquiring.org:/home/oracle>






prod 4-feb-2019

epl1trandbrpt1.tsysacquiring.org:/home/oracle> crsctl stat res -t
--------------------------------------------------------------------------------
NAME           TARGET  STATE        SERVER                   STATE_DETAILS
--------------------------------------------------------------------------------
Local Resources
--------------------------------------------------------------------------------
ora.ASMGOLDENGATE.dg
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
ora.ASMRPTARCHIVE.dg
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
ora.ASMRPTBASEDB.dg
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
ora.ASMRPTCRSVT.dg
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
ora.ASMRPTDATA.dg
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
ora.LISTENER.lsnr
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
ora.asm
               ONLINE  ONLINE       epl1trandbrpt1           Started
               ONLINE  ONLINE       epl1trandbrpt2           Started
               ONLINE  ONLINE       epl1trandbrpt3           Started
ora.asmgoldengate.goldengate.acfs
               ONLINE  ONLINE       epl1trandbrpt1           mounted on /acfs
               ONLINE  ONLINE       epl1trandbrpt2           mounted on /acfs
               ONLINE  ONLINE       epl1trandbrpt3           mounted on /acfs
ora.gsd
               ONLINE  OFFLINE      epl1trandbrpt1
               ONLINE  OFFLINE      epl1trandbrpt2
               ONLINE  OFFLINE      epl1trandbrpt3
ora.net1.network
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
ora.ons
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
ora.registry.acfs
               ONLINE  ONLINE       epl1trandbrpt1
               ONLINE  ONLINE       epl1trandbrpt2
               ONLINE  ONLINE       epl1trandbrpt3
--------------------------------------------------------------------------------
Cluster Resources
--------------------------------------------------------------------------------
e-rpt-ggatevip.tsysacquiring.org
      1        ONLINE  ONLINE       epl1trandbrpt3
ora.LISTENER_SCAN1.lsnr
      1        ONLINE  ONLINE       epl1trandbrpt2
ora.LISTENER_SCAN2.lsnr
      1        ONLINE  ONLINE       epl1trandbrpt3
ora.LISTENER_SCAN3.lsnr
      1        ONLINE  ONLINE       epl1trandbrpt1
ora.cvu
      1        ONLINE  ONLINE       epl1trandbrpt1
ora.epl1trandbrpt1.vip
      1        ONLINE  ONLINE       epl1trandbrpt1
ora.epl1trandbrpt2.vip
      1        ONLINE  ONLINE       epl1trandbrpt2
ora.epl1trandbrpt3.vip
      1        ONLINE  ONLINE       epl1trandbrpt3
ora.oc4j
      1        ONLINE  ONLINE       epl1trandbrpt1
ora.scan1.vip
      1        ONLINE  ONLINE       epl1trandbrpt2
ora.scan2.vip
      1        ONLINE  ONLINE       epl1trandbrpt3
ora.scan3.vip
      1        ONLINE  ONLINE       epl1trandbrpt1
ora.transitrptga.db
      1        ONLINE  ONLINE       epl1trandbrpt1           Open
      2        ONLINE  ONLINE       epl1trandbrpt2           Open
      3        ONLINE  ONLINE       epl1trandbrpt3           Open
ora.transitrptga.transitrpt.svc
      1        ONLINE  ONLINE       epl1trandbrpt1
      2        ONLINE  ONLINE       epl1trandbrpt2
      3        ONLINE  ONLINE       epl1trandbrpt3
xag.gg_erpt.goldengate
      1        ONLINE  ONLINE       epl1trandbrpt3
epl1trandbrpt1.tsysacquiring.org:/home/oracle>

epl1trandbrpt1.tsysacquiring.org:/home/oracle> nslookup epl1trandbrpt1.tsysacquiring.org
Server:         10.104.0.30
Address:        10.104.0.30#53

Name:   epl1trandbrpt1.tsysacquiring.org
Address: 10.50.50.171

epl1trandbrpt1.tsysacquiring.org:/home/oracle>

GGSCI (epl1trandbtxn1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTE        00:00:01      00:00:09
EXTRACT     RUNNING     PPTERE      00:00:00      00:00:09
EXTRACT     RUNNING     PPTERW      00:00:00      00:00:07
EXTRACT     RUNNING     PPTETW      00:00:00      00:00:05
REPLICAT    RUNNING     RPTETW01    00:00:00      00:00:03
REPLICAT    RUNNING     RPTETWLG    00:00:00      00:00:03


GGSCI (epl1trandbtxn1.tsysacquiring.org) 2>

GGSCI (epl1trandbrpt1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRE        00:00:01      00:00:05
EXTRACT     RUNNING     PPRERW      00:00:00      00:00:07
REPLICAT    RUNNING     RPRERW      00:00:00      00:00:05
REPLICAT    RUNNING     RPRETE01    00:00:00      00:00:00
REPLICAT    RUNNING     RPRETELG    00:00:00      00:00:01
REPLICAT    RUNNING     RPRETW01    00:00:00      00:00:00
REPLICAT    RUNNING     RPRETWLG    00:00:00      00:00:00


GGSCI (wpl1trandbtxn1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTW        00:00:03      00:00:07
EXTRACT     RUNNING     PPTWRE      00:00:04      00:00:03
EXTRACT     RUNNING     PPTWRW      00:00:04      00:00:02
EXTRACT     RUNNING     PPTWTE      00:00:04      00:00:03
REPLICAT    RUNNING     RPTWTE01    00:00:00      00:00:00
REPLICAT    RUNNING     RPTWTELG    00:00:00      00:00:00


GGSCI (wpl1trandbtxn1.tsysacquiring.org) 2>


GGSCI (wpl1trandbrpt1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRW        00:00:02      00:00:02
EXTRACT     RUNNING     PPRWRE      00:00:00      00:00:09
REPLICAT    RUNNING     RPRWRE      00:00:00      00:00:03
REPLICAT    RUNNING     RPRWTE01    00:00:00      00:00:01
REPLICAT    RUNNING     RPRWTELG    00:00:00      00:00:00
REPLICAT    RUNNING     RPRWTW01    00:00:00      00:00:00
REPLICAT    RUNNING     RPRWTWLG    00:00:00      00:00:00




GGSCI (epl1trandbtxn1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     info EPTE     ,showch   00:00:01      00:00:09
EXTRACT     RUNNING     info PPTERE   ,showch   00:00:00      00:00:09
EXTRACT     RUNNING     info PPTERW   ,showch   00:00:00      00:00:07
EXTRACT     RUNNING     info PPTETW   ,showch   00:00:00      00:00:05
REPLICAT    RUNNING     info RPTETW01 ,showch   00:00:00      00:00:03
REPLICAT    RUNNING     info RPTETWLG ,showch   00:00:00      00:00:03


GGSCI (epl1trandbtxn1.tsysacquiring.org) 2>

GGSCI (epl1trandbrpt1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     info EPRE    ,showch   00:00:01      00:00:05
EXTRACT     RUNNING     info PPRERW  ,showch   00:00:00      00:00:07
REPLICAT    RUNNING     info RPRERW  ,showch   00:00:00      00:00:05
REPLICAT    RUNNING     info RPRETE01,showch   00:00:00      00:00:00
REPLICAT    RUNNING     info RPRETELG,showch   00:00:00      00:00:01
REPLICAT    RUNNING     info RPRETW01,showch   00:00:00      00:00:00
REPLICAT    RUNNING     info RPRETWLG,showch   00:00:00      00:00:00


GGSCI (wpl1trandbtxn1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING      info EPTW    ,showch    00:00:03      00:00:07
EXTRACT     RUNNING      info PPTWRE  ,showch    00:00:04      00:00:03
EXTRACT     RUNNING      info PPTWRW  ,showch    00:00:04      00:00:02
EXTRACT     RUNNING      info PPTWTE  ,showch    00:00:04      00:00:03
REPLICAT    RUNNING      info RPTWTE01,showch    00:00:00      00:00:00
REPLICAT    RUNNING      info RPTWTELG,showch    00:00:00      00:00:00


GGSCI (wpl1trandbtxn1.tsysacquiring.org) 2>


GGSCI (wpl1trandbrpt1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     info EPRW     ,showch   00:00:02      00:00:02
EXTRACT     RUNNING     info PPRWRE   ,showch   00:00:00      00:00:09
REPLICAT    RUNNING     info RPRWRE   ,showch   00:00:00      00:00:03
REPLICAT    RUNNING     info RPRWTE01 ,showch   00:00:00      00:00:01
REPLICAT    RUNNING     info RPRWTELG ,showch   00:00:00      00:00:00
REPLICAT    RUNNING     info RPRWTW01 ,showch   00:00:00      00:00:00
REPLICAT    RUNNING     info RPRWTWLG ,showch   00:00:00      00:00:00














