--precheck

ps -eaf | grep pmon | tee /acfs/patch_stat/os_pmon_`date +"%m-%d-%Y"`_`hostname`.log
ps -eaf | grep pmon | tee /acfs/patch_stat/os_tns_`date +"%m-%d-%Y"`_`hostname`.log
df -Ph  | /acfs/patch_stat/tee os_df_`date`_`hostname`.log
/opt/app/11.2.0/grid_1/bin/./crsctl stat res -t | tee /acfs/patch_stat/os_crs_`date +"%m-%d-%Y"`_`hostname`.log
/opt/app/11.2.0/grid_1/bin/./crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
 awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}' | tee /acfs/patch_stat/os_crsstat_`date +"%m-%d-%Y"`_`hostname`.log





/opt/app/11.2.0/grid_1/bin/./crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
 awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}' | tee /acfs/patch_stat/pre_os_crsstat_`date +"%m-%d-%Y"`_`hostname`.log


/opt/app/11.2.0/grid_1/bin/./crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
 awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}' | tee /acfs/patch_stat/post_os_crsstat_`date +"%m-%d-%Y"`_`hostname`.log








----IMP :
	start replication before complile schema script .

	
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch_apr19/29698727/29141201 
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch_apr19/29698727/29497421
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch_apr19/29698727/29509309 





pbrun -h epl1trandbtxn1.tsysacquiring.org	su - root
pbrun -h epl1trandbtxn2.tsysacquiring.org   su - root
pbrun -h epl1trandbtxn3.tsysacquiring.org   su - root


pbrun -h epl1trandbrpt1.tsysacquiring.org	su - root
pbrun -h epl1trandbrpt2.tsysacquiring.org   su - root
pbrun -h epl1trandbrpt3.tsysacquiring.org   su - root





echo $ORACLE_HOME
echo $ORACLE_BASE



$ORACLE_HOME/OPatch/./opatch auto  /opt/app/software/patch_apr19/29698727 -oh /opt/app/11.2.0/grid_1 -ocmrf $ORACLE_HOME/dbs/ocm.rsp
$ORACLE_HOME/OPatch/./opatch auto  /opt/app/software/patch_apr19/29698727 -oh /opt/app/oracle/product/11.2.0/dbhome_2 -ocmrf $ORACLE_HOME/dbs/ocm.rsp


/opt/app/oracle/xag/bin/agctl stop goldengate gg_etxn
/opt/app/oracle/xag/bin/agctl start goldengate gg_etxn



/opt/app/oracle/xag/bin/agctl stop goldengate gg_erpt
/opt/app/oracle/xag/bin/agctl start  goldengate gg_erpt


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

copy \\W10-D-TAS-023.dev.tas.corp\c$\Users\113514\Desktop\users.xls C:\Users\113514\Desktop\Prod_vdi_docs


W10-P-TAS-063.prod.tas.corp



mkdir -p /opt/app/software/patch_apr19
chmod -R 775 /opt/app/software/patch_apr19

$ORACLE_HOME/OPatch/ocm/bin/emocmrsp  -no_banner -output <specify_the_location>/file.rsp
chown -R oracle:dba OPatch 
chmod -R 775 OPatch

 mv OPatch OPatch_old 
 unzip p6880880_112000_Linux-x86-64.zip >> aa
OPatch/./opatch version

--copy 
scp /opt/oracle/gi_software/system.dmp vishalbh@10.100.101.20:/software/oracle/joselle

--download 
scp vishalbh@octov1.vitalps.com:/software/oracle/SOFTWARE/OPatch/Apr19_patch/p29252208_112040_Linux-x86-64.zip /opt/app/software/patch_apr19
scp vishalbh@octov1.vitalps.com:/software/oracle/SOFTWARE/OPatch/Apr19_patch/p6880880_112000_Linux-x86-64.zip /opt/app/software/patch_apr19



scp oracle@wdl1trandbs02.tsysacquiring.org:/opt/app/software/patch_apr19/p29252208_112040_Linux-x86-64.zip /opt/app/software/patch_apr19
scp oracle@wdl1trandbs02.tsysacquiring.org:/opt/app/software/patch_apr19/p6880880_112000_Linux-x86-64.zip /opt/app/software/patch_apr19


--12c

scp vishalbh@octov1.vitalps.com:/software/oracle/SOFTWARE/OPatch/Apr19_patch/p29252164_121020_Linux-x86-64.zip .
scp vishalbh@octov1.vitalps.com:/software/oracle/SOFTWARE/OPatch/Apr19_patch/p6880880_122010_Linux-x86-64.zip .

p29252208_112040_HPUX-IA64.zip
scp vishalbh@wpl2tsysdbs01.vitalps.com:/oracle/recovery/SOFTWARE/patch_apr19/p29252208_112040_HPUX-IA64.tar .



crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
 awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}'


 
 
 
 
  scp vishalbh@octov1.vitalps.com:/software/oracle/SOFTWARE/OPatch/Apr19_patch/p6880880_112000_HPUX-IA64.zip .
 
 
 
find . -name java -print 2>/dev/null
find / -name java -print 2>/dev/null
/opt/java6/bin/jar -xvf p6880880_112000_HPUX-IA64.zip 
ll

/opt/app/software

vishalbh@octov1:/home/vishalbh$  ll /software/oracle/SOFTWARE/OPatch/Apr19_patch
total 11665686
-rwxrwxr-x   1 vishalbh   users      1854685313 Apr 17 22:58 p29252072_122010_Linux-x86-64.zip
-rw-------   1 vishalbh   users      2711221864 Apr 17 23:33 p29252164_121020_Linux-x86-64.zip
-rwxrwxr-x   1 vishalbh   users      1182084929 Apr 17 22:24 p29252208_112040_Linux-x86-64.zip
-rwxrwxr-x   1 vishalbh   users      113112960 Apr 17 21:43 p6880880_112000_Linux-x86-64.zip
-rwxrwxr-x   1 vishalbh   users      111682884 Apr 17 21:44 p6880880_122010_Linux-x86-64.zip











–createAlias pass


vericom.sh -wluser username -wlport –addCredentialStore
We need to apply oracle Q2 security patches on east production data center.
spool /acfs/patch_stat/registry_history.log
SET linesize 32000 pagesize 200 
col action_time FOR a28 
col version FOR a10 
col comments FOR a35 
col action FOR a25 
col namespace FOR a12 
SELECT * FROM registry$history order by action_time DESC;
spool off 


sh date 
info all
sh date



/*
pbrun -h epl1trandbtxn1.tsysacquiring.org	su - 
pbrun -h epl1trandbtxn2.tsysacquiring.org   su - 
pbrun -h epl1trandbtxn3.tsysacquiring.org   su - 
pbrun -h epl1trandbrpt1.tsysacquiring.org   su - 
pbrun -h epl1trandbrpt2.tsysacquiring.org   su - 
pbrun -h epl1trandbrpt3.tsysacquiring.org   su - 

*/


ps -eaf | grep pmon | tee /tmp/`hostname`_pmon_`date +"%m%d%Y-%T"`.log
ps -eaf | grep tns | tee /tmp/`hostname`_tns_`date +"%m%d%Y-%T"`.log
crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
 awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}' | tee /tmp/`hostname`_crs_output_`date +"%m%d%Y-%T"`.log

 
 
 $ORACLE_HOME/OPatch/./opatch lsinventory | tee /tmp/`hostname`_prepatchinventory_db_`date +"%m%d%Y-%T"`.log
 $ORACLE_HOME/OPatch/./opatch lsinventory | tee /tmp/`hostname`_prepatchinventory_grid_`date +"%m%d%Y-%T"`.log

 
 
 /opt/app/11.2.0/grid_1/OPatch/./opatch lsinventory | tee /acfs/patch_stat/`hostname`_postpatchinventory_db_`date +"%m%d%Y-%T"`.log
 /opt/app/oracle/product/11.2.0/dbhome_2/OPatch/./opatch lsinventory | tee /acfs/patch_stat/`hostname`_postpatchinventory_grid_`date +"%m%d%Y-%T"`.log

 /opt/app/11.2.0/grid_1/OPatch/./opatch lsinventory  | grep applied | tee /acfs/patch_stat/`hostname`_postpatchinventory_db_`date +"%m%d%Y-%T"`.log
 /opt/app/oracle/product/11.2.0/dbhome_2/OPatch/./opatch lsinventory  | grep applied | tee /acfs/patch_stat/`hostname`_postpatchinventory_grid_`date +"%m%d%Y-%T"`.log

ps -eaf | grep pmon | tee /acfs/patch_stat/`hostname`_pmon_`date +"%m%d%Y-%T"`.log
ps -eaf | grep tns | tee /acfs/patch_stat/`hostname`_tns_`date +"%m%d%Y-%T"`.log
crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}' | tee /acfs/patch_stat/`hostname`_crs_output_`date +"%m%d%Y-%T"`.log

 
 
 
 
 
 
 
 
 
 echo $ORACLE_HOME 
 $ORACLE_HOME/OPatch/./opatch version
 
 /opt/app/11.2.0/grid_1
 
$ORACLE_HOME/OPatch/./opatch auto  /opt/app/software/patch_apr19/29252208/29255947 -oh /opt/app/11.2.0/grid_1 -ocmrf $ORACLE_HOME/dbs/ocm.rsp 
$ORACLE_HOME/OPatch/./opatch auto  /opt/app/software/patch_apr19/29252208/29255947 -oh /opt/app/oracle/product/11.2.0/dbhome_2 -ocmrf $ORACLE_HOME/dbs/ocm.rsp 


 


 
 
 
 $ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch_apr19/29252208/29255947/29141056
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch_apr19/29252208/29255947/29141201




$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch_apr19/29252208/29255947/29141056
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch_apr19/29252208/29255947/29141201
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch_apr19/29252208/29255947/28729245


$ORACLE_HOME/OPatch/ocm/bin/emocmrsp  -no_banner -output $ORACLE_HOME/dbs/ocm.rsp

chmod -R 775 $ORACLE_HOME/dbs/ocm.rsp


unzip p6880880_112000_Linux-x86-64.zip > a; unzip p29252208_112040_Linux-x86-64.zip > b ; rm a b; ls -altr 



cp /opt/app/software/patch_apr19/p6880880_112000_Linux-x86-64.zip /opt/app/11.2.0/grid_1/ ; cd /opt/app/11.2.0/grid_1/; ls -altr 


/opt/app/11.2.0/grid_1
	mv OPatch OPatch_vb_bkp ; unzip p6880880_112000_Linux-x86-64.zip > a; chmod -R 777 OPatch/ ; chown -R oracle:dba OPatch/ ; ls -altr 


echo $ORACLE_HOME
 
