 ALTER SESSION SET CURRENT_SCHEMA=TRANSNOX_CPASS;

DECLARE
   V_MIN_TRAN_ID       NUMBER;
   V_MAX_TRAN_ID       NUMBER;
   V_SQL               VARCHAR2 (4000);
   V_TABLE_NAME        VARCHAR2 (40) := NULL;
   V_CNT               NUMBER := NULL;
   V_UPDATE_SQL        VARCHAR2 (4000);
   V_START_TIME        NUMBER;
   V_END_TIME          NUMBER;
   V_QUERY_EXEC_TIME   NUMBER;
   V_ERROR_MESSAGE     VARCHAR2 (1000);
BEGIN
   -- To get min and max transaction id from  last 24 hours of transactional data

   SELECT MIN (TRANSACTION_ID)
     INTO V_MIN_TRAN_ID
     FROM TRANSACTION
    WHERE TIME_STAMP BETWEEN TRUNC (SYSDATE - 1)
                         AND TRUNC (SYSDATE) - 1 / 18600;

   SELECT MAX (TRANSACTION_ID)
     INTO V_MAX_TRAN_ID
     FROM TRANSACTION
    WHERE TIME_STAMP BETWEEN TRUNC (SYSDATE - 1)
                         AND TRUNC (SYSDATE) - 1 / 18600;


   -- Table wise rowcount finding

   FOR I IN (SELECT OWNER, TABLE_NAME, SQL_QUERY
               FROM TRANSNOX_CPASS.DATABASE_TABLES_COMPARE)
   LOOP
      V_SQL := REPLACE (I.SQL_QUERY, 'v_min_tran_id', V_MIN_TRAN_ID);
      V_SQL := REPLACE (V_SQL, 'v_max_tran_id', V_MAX_TRAN_ID);

      V_START_TIME := DBMS_UTILITY.GET_TIME;

      BEGIN
         EXECUTE IMMEDIATE V_SQL INTO V_TABLE_NAME, V_CNT;
      EXCEPTION
         WHEN OTHERS
         THEN
            V_TABLE_NAME := I.TABLE_NAME;
            V_CNT := 0;
      END;

      V_END_TIME := DBMS_UTILITY.GET_TIME;
      V_QUERY_EXEC_TIME := V_END_TIME - V_START_TIME;

      V_UPDATE_SQL :=
            'UPDATE TRANSNOX_CPASS.DATA_COMPARE SET TW ='
         || V_CNT
         || ' WHERE TABLE_NAME ='''
         || V_TABLE_NAME
         || '''';

      INSERT INTO TRANSNOX_CPASS.DATACOMP_QUERY_LOGS (DATA_CENTER,
                                                      TABLE_NAME,
                                                      SQL_QUERY,
                                                      EXCECTION_TIME_SEC,
                                                      CREATED_DATE,
                                                      UPDATE_QUERY)
           VALUES ('TW',
                   I.TABLE_NAME,
                   I.SQL_QUERY,
                   V_QUERY_EXEC_TIME,
                   SYSDATE,
                   V_UPDATE_SQL);

      EXECUTE IMMEDIATE V_UPDATE_SQL;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      V_ERROR_MESSAGE := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || SQLERRM;

      INSERT INTO TRANSNOX_CPASS.DATACOMP_QUERY_LOGS (DATA_CENTER,
                                                      TABLE_NAME,
                                                      SQL_QUERY,
                                                      EXCECTION_TIME_SEC,
                                                      CREATED_DATE,
                                                      UPDATE_QUERY)
           VALUES ('TW',
                   'JOB_EXECUTION_FAILURE',
                   V_ERROR_MESSAGE,
                   '',
                   SYSDATE,
                   '');
END;