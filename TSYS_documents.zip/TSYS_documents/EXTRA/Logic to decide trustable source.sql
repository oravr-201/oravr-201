DECLARE
   V_MAX             NUMBER;
   V_TE              NUMBER;
   V_TW              NUMBER;
   V_RE              NUMBER;
   V_RW              NUMBER;
   V_LIABLE_SOURCE   VARCHAR2 (100);
   V_UPDATE_SQL      VARCHAR2 (1000);
BEGIN
   FOR I IN (SELECT TABLE_NAME, TE, TW, RE, RW, LIABLE_SOURCE
               FROM TRANSNOX_CPASS.DATA_COMPARE
             )
   LOOP
      V_TE := I.TE;
      V_TW := I.TW;
      V_RE := I.RE;
      V_RW := I.RW;

--To pick the high great value for a table from group of data center row count.

      SELECT GREATEST (NVL (I.TE, 0),
                       NVL (I.TW, 0),
                       NVL (I.RE, 0),
                       NVL (I.RW, 0))
        INTO V_MAX
        FROM DUAL;
--  logic to decide Liabale/trustable data source to replicate 
      SELECT CASE
                WHEN     V_MAX = I.TE
                     AND V_MAX = I.TW
                     AND V_MAX = I.RE
                     AND V_MAX = I.RW
                THEN
                  ''
                WHEN V_MAX = I.TE AND V_MAX = I.TW
                THEN
                   ''
                WHEN V_MAX = I.TE
                THEN
                   'TE'
                WHEN V_MAX = I.TW
                THEN
                   'TW'
                ELSE
                   ''
             END
        INTO V_LIABLE_SOURCE
        FROM DUAL;

--Updating Liable datacenter in DATA_COMPARE table

      IF V_LIABLE_SOURCE IS NULL
      THEN
         NULL;
      ELSE
         V_UPDATE_SQL :=
               'update TRANSNOX_CPASS.DATA_COMPARE set liable_Source = '''
            || V_LIABLE_SOURCE
            || ''' where TABLE_NAME='''
            || I.TABLE_NAME
            || '''';
      END IF;

      EXECUTE IMMEDIATE V_UPDATE_SQL;
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      NULL;
END;
