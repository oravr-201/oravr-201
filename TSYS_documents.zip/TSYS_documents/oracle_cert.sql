




Oracle Database 12c Maximum Availability Certified Expert Certification Overview

Step1 - Complete these Certifications

	Oracle Database 12c Administrator Certified Professional
		1. Oracle Database 12c Administrator Certified Associate
		2. Coplete Cource 
		3. Oracle Database 12c: Advanced Administration 1Z0-063
	
	Oracle Certified Expert, Oracle Database 12c: RAC and Grid Infrastructure Administration
		1. Oracle Database 11g Administrator Certified Professional or
		2. Cource Traning 
		3. Oracle Database 12c: RAC and Grid Infrastructure Administration | 1Z0-068

	Oracle Certified Expert, Oracle Database 12c: Data Guard Administration
		1. Oracle Database 11g Administrator Certified Professional
		2. Coplete Cource
		3. Oracle Database 12c: Data Guard Administration 1Z0-066
 
 
 
 
Oracle Database 12c Maximum Availability Certified Master Certification Overview
	 
	Oracle Database 12c Administrator Certified Professional Certification Overview
		1. Oracle Database 12c Administrator Certified Associate
		2. Coplete Cource 
		3. Oracle Database 12c: Advanced Administration 1Z0-063
	
	Oracle Certified Expert, Oracle Database 12c: RAC and Grid Infrastructure Administration
		1. Oracle Database 11g Administrator Certified Professional or
		2. Cource Traning 
		3. Oracle Database 12c: RAC and Grid Infrastructure Administration | 1Z0-068
	
	Oracle Certified Expert, Oracle Database 12c: Data Guard Administration
		1. Oracle Database 11g Administrator Certified Professional
		2. Coplete Cource
		3. Oracle Database 12c: Data Guard Administration 1Z0-066
 
 
 
 
 
 
 $4,850.00	Exadata Database Machine: 12c Administration Workshop Ed 2 TOD
 $1,630.00	Oracle Database 12c: ASM Administration Ed 1.1 TOD
 $1,360.00	Oracle Database 12c: Managing Multitenant Architecture Ed 1 (JP) TOD