--New server 


--DEV :
	wdl2trandbs03.tsysacquiring.org
	wdl2trandbs04.tsysacquiring.org
	
--QA 	:
	
	wql2trandbs01.tsysacquiring.org
	wql2trandbs02.tsysacquiring.org
	
--NR 	:
	wql2trandbs03.tsysacquiring.org
	wql2trandbs04.tsysacquiring.org
--PERF :

	wql2trandbs05.tsysacquiring.org
	wql2trandbs06.tsysacquiring.org
	wql2trandbs07.tsysacquiring.org

	wdl2trandbs05.tsysacquiring.org
	wdl2trandbs06.tsysacquiring.org
	wdl2trandbs07.tsysacquiring.org

--UAT Servers 	

	wul2trandbs09.tsysacquiring.org
	wul2trandbs10.tsysacquiring.org
	
	
	wul2trandbs11.tsysacquiring.org
	wul2trandbs12.tsysacquiring.org

--PF Archive server :

	wql2trandbs08.tsysacquiring.org
	
--Jira severs

	wdl2oraclesvs01.tsysacquiring.org
	wdl2oraclesvs02.tsysacquiring.org 
	
--Archive Server Prod 


	wpl2trandbs02-priv.tsysacquiring.org
	epl2trandbs01-priv.tsysacquiring.org

--OEM 
10.150.4.155    wml2oracledbs01.vitalps.com     wml2oracledbs01
10.150.50.155   db.wml2oracledbs01.vitalps.com  db.wml2oracledbs01


maven server: 
	10.132.13.131
	

	
	
	
devtransitdb-scan.tsysacquiring.org
-10.132.14.1
-10.132.14.2
-10.132.14.3
qatransitdb-scan.tsysacquiring.org
-10.132.14.4
-10.132.14.5
-10.132.14.6
regtransitdb-scan.tsysacquiring.org
-10.132.14.7
-10.132.14.8
-10.132.14.9
pfetransitdb-scan.tsysacquiring.org
-10.132.14.10
-10.132.14.11
-10.132.14.12
pfwtransitdb-scan.tsysacquiring.org
-10.132.14.13
-10.132.14.14
-10.132.14.15 
	 
	 
	 
	 
https://10.150.4.155:7803/em/faces/logon/core-uifwk-console-login 	 
	 
13c old 
wml1tsysdbs01.vitalps.com	 
	 
	 
	
--varidata: prod 
http://10.150.4.108:8830/veridata/welcome.jsf 
http://10.50.4.108:8830/veridata/login.jsf 
veridata
Jayhawk1


--OEM prod 
https://10.150.50.100:7802/em/faces/logon/core-uifwk-console-login?_afrLoop=80871673880772632&_afrWindowMode=0&_afrWindowId=null#%40%3F_afrLoop%3D80871673880772632%26_afrWindowId%3Dnull%26_afrWindowMode%3D0%26_adf.ctrl-state%3D7ydohw0om_4 
https://wml1tsysdbs01.vitalps.com:7803/em/faces/logon/core-uifwk-console-login 


-- OEM dev

https://wdl2tsysdbs03.tsysacquiring.org:4903/em/faces/logon/core-uifwk-console-login?_afrLoop=32208811271429972&_afrWindowMode=0&_afrWindowId=null#%40%3F_afrWindowMode%3D0%26_afrWindowId%3Dnull%26_afrLoop%3D32208811271429972%26_adf.ctrl-state%3D5t6vxerb8_4 

mpty%kow

mptykow2020


mptykow%2020

10.132.13.130 







LDAP Password chnage :
10.100.226.121 - dev/qa 
UAT 71/72 = Prod
SR1202765


-- omi
ALTER USER SYSDG IDENTIFIED BY VALUES '6C6198D0644CF9B4';






https://merchantcenter-e.transit-pass.com/jsp/vt/jsp/index.jsp 