PARAMETER                                     '11.2.0.1'     '11.2.0.2'    DESCRIPTION
--------------------------------------------- -------------- ------------- ----------------------------------------------------------------------
_px_partition_scan_enabled                    FALSE          TRUE          enables or disables parallel partition-based scan
optimizer_features_enable                     11.2.0.1       11.2.0.2      optimizer plan compatibility parameter
_optimizer_undo_cost_change                   11.2.0.1       11.2.0.2      optimizer undo cost change
_optimizer_false_filter_pred_pullup           FALSE          TRUE          optimizer false predicate pull up transformation
_optimizer_full_outer_join_to_outer           FALSE          TRUE          enable/disable full outer to left outer join conversion
_optimizer_extended_stats_usage_control       224            192           controls the optimizer usage of extended stats
_optimizer_enable_table_lookup_by_nl          FALSE          TRUE          consider table lookup by nl transformation



step 1:

clean restart ;

create table vishalbh.prameter_bkp_13_sep as (select * from v$parameter);
create pfile='/home/oralce/init.ora' from spfile ;

step 2:

alter system reset hidden_parameter_name scope=spfile sid='*';

step 3:

restart the database ;

step 4:

validate patameters 
/*
col name for a60
col value for a60
set lines 3000
set pages 100
select par.ksppinm name,
val.ksppstvl value,
val.ksppstdf def_val
from x$ksppi par,
x$ksppcv val
where par.indx=val.indx
and 
par.ksppinm like '%&1%'
order by 1;
*/