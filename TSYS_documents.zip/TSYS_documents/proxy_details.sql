--Europ

http://tsysproxy1.tsyseurope.com:4438/accelerated_pac_base.pac

http://tsysproxy1.tsyseurope.com
port : 4438

--india 

http://indiaproxy.tsys.com:4438/accelerated_pac_base.pac


http://indiaproxy.tsys.com
http://indiaproxy.tsys.com

port : 4438

http://indiaproxy.tsys.com:4438/accelerated_pac_base.pac