
--user audit prodation :
/*
col username format a30
col PROFILE format a35
col ACCOUNT_STATUS format a16
col GRANTED_ROLE format a18
set lines 400
set pages 999
select USERNAME,ACCOUNT_STATUS, PROFILE, DrP.GRANTED_ROLE,DRP.ADMIN_OPTION, AUTHENTICATION_TYPE, CREATED, EXPIRY_DATE, LOCK_DATE from dba_users du, DBA_ROLE_PRIVS drp
where DU.USERNAME=DrP.GRANTEE
and DRP.GRANTED_ROLE in ('DB_RELEASE_GROUP','OPERATOR','DBA','ORDADMIN','VIEWER','WKUSER','MGMT_USER','OWB_USER','OEM_MONITOR','RESOURCE')
order by 1 ;
select sysdate from dual;
select INSTANCE_NAME, HOST_NAME from v$instance; 

*/


---catalog server username/password

rman target / rcvcat rman/rman@rcat



--Scan details :

srvctl status scan_listener -i 1
srvctl status scan_listener -i 2
srvctl status scan_listener -i 3

srvctl stop scan_listener -i 1
srvctl stop scan_listener -i 2
srvctl stop scan_listener -i 3

srvctl start scan_listener -i 1
srvctl start  scan_listener -i 2
srvctl start scan_listener -i 3













































Ticket number :

SR835641			OS dev patch 12-feb-19

