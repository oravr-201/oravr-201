##################################################
#            Created by                          #
#       vishal Bhandwalkar                       #
#        Mob : 9960902388 						 # 
#------------------------------------------------#
#												 #
#Please insert only database patch dir and number#
#		GRID_DB_PATCH=$1 						 #
#		OJVM_PATCH=$2							 #
#		OPATCH_DIR=$3							 #
#												 #
#  NOTE : we need to Run this script from oralce #
#  user but we need sudo root Access             #
#  Please find the command  log on /tmp folder   #	
#                                              ###
###################################################


echo
echo "==================================================="
echo "This script database nonasm + OJVM PATCHING           on 11G  ."
echo "==================================================="
echo
sleep 1
#############*****###############
# Description: Listener down   # 
#                               #
#############*****###############
TNS_STOP( )
{
echo
echo "==================================================="
echo "This script  shutdown listener .  "
echo "==================================================="
echo
sleep 1

#############################
# Listing Available Databases:
#############################

# Count Instance Numbers:
INS_COUNT=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|wc -l )

# Exit if No DBs are running:
if [ $INS_COUNT -eq 0 ]
 then
   echo No Database Running !
   exit
fi

# If there is ONLY one DB set it as default without prompt for selection:
if [ $INS_COUNT -eq 1 ]
 then
   export ORACLE_SID=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )

# If there is more than one DB ASK the user to select:
elif [ $INS_COUNT -gt 1 ]
 then
    echo
    echo "Select the ORACLE_SID:[Enter the number]"
    echo ---------------------
    select DB_ID in $( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )
     do
        if [ -z "${REPLY##[0-9]*}" ]
         then
          export ORACLE_SID=$DB_ID
          echo Selected Instance:
          echo
          echo "********"
          echo $DB_ID
          echo "********"
          echo
          break
         else
          export ORACLE_SID=${REPLY}
          break
        fi
     done

fi
# Exit if the user selected a Non Listed Number:
        if [ -z "${ORACLE_SID}" ]
         then
          echo "You've Entered An INVALID ORACLE_SID"
          exit
        fi

###########################
# Getting ORACLE_HOME
###########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|grep -v ASM|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep ${ORA_USER} /etc/passwd| cut -f6 -d ':'|tail -1`

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

##########################################
# Exit if the user is not the Oracle Owner:
##########################################
CURR_USER=`whoami`
        if [ ${ORA_USER} != ${CURR_USER} ]; then
          echo ""
          echo "You're Running This Sctipt with User: \"${CURR_USER}\" !!!"
          echo "Please Run This Script With The Right OS User: \"${ORA_USER}\""
          echo "Script Terminated!"
          exit
        fi

echo " Welcome to oravb "

#TNS_LIST=`ps -ef | grep tns | grep -inherit | awk '{print $9}'`

for TNS in $TNS_LIST
do
export TNS_NAME=$TNS
$ORACLE_HOME/bin/lsnrctl stop $TNS_NAME
done

}



#############*****###############
# Description: Listener start  # 
#                               #
#############*****###############
TNS_START( )
{
echo
echo "==================================================="
echo "This script start listener                      .  "
echo "==================================================="
echo
sleep 1
#############################
# Listing Available Databases:
#############################

# Count Instance Numbers:
INS_COUNT=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|wc -l )

# Exit if No DBs are running:
if [ $INS_COUNT -eq 0 ]
 then
   echo No Database Running !
   exit
fi

# If there is ONLY one DB set it as default without prompt for selection:
if [ $INS_COUNT -eq 1 ]
 then
   export ORACLE_SID=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )

# If there is more than one DB ASK the user to select:
elif [ $INS_COUNT -gt 1 ]
 then
    echo
    echo "Select the ORACLE_SID:[Enter the number]"
    echo ---------------------
    select DB_ID in $( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" )
     do
        if [ -z "${REPLY##[0-9]*}" ]
         then
          export ORACLE_SID=$DB_ID
          echo Selected Instance:
          echo
          echo "********"
          echo $DB_ID
          echo "********"
          echo
          break
         else
          export ORACLE_SID=${REPLY}
          break
        fi
     done

fi
# Exit if the user selected a Non Listed Number:
        if [ -z "${ORACLE_SID}" ]
         then
          echo "You've Entered An INVALID ORACLE_SID"
          exit
        fi

###########################
# Getting ORACLE_HOME
###########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|grep -v ASM|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep ${ORA_USER} /etc/passwd| cut -f6 -d ':'|tail -1`

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

##########################################
# Exit if the user is not the Oracle Owner:
##########################################
CURR_USER=`whoami`
        if [ ${ORA_USER} != ${CURR_USER} ]; then
          echo ""
          echo "You're Running This Sctipt with User: \"${CURR_USER}\" !!!"
          echo "Please Run This Script With The Right OS User: \"${ORA_USER}\""
          echo "Script Terminated!"
          exit
        fi

echo " Welcome to oravb "


#TNS_LIST=`ps -ef | grep tns | grep -inherit | awk '{print $9}'`

for TNS in $TNS_LIST
do
export TNS_NAME=$TNS
$ORACLE_HOME/bin/lsnrctl start $TNS_NAME
done

}

#############************###############
# Description: start database patching # 
#                                      #
#############************###############
database( )
{
echo
echo "==================================================="
echo "This script database patch                      .  "
echo "==================================================="
echo
sleep 1

#############################
# Listing Available Databases:
#############################


export ORACLE_SID=$ORACLE_SIDD
echo " Welcome to oravb wait 2 min "

echo $ORACLE_SID

if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

echo " 3"


echo " Welcome to oravb sleep 2 min "
sleep 30


echo " Database ls inventory  "

$OPATCH_DIR/OPatch/./opatch lsinventory | tee /tmp/pre_lsinventory_1.log


echo " start patch database "


cd $GRID_DB_PATCH
$OPATCH_DIR/OPatch/opatch apply -silent -ocmrf $ORACLE_HOME/dbs/ocm.rsp

echo " Database OJVM_PATCH  "
cd $OJVM_PATCH

$OPATCH_DIR/OPatch/opatch apply -silent -ocmrf $ORACLE_HOME/dbs/ocm.rsp


echo " Database ls post inventory  "

$OPATCH_DIR/OPatch/./opatch lsinventory | tee /tmp/post_lsinventory_1.log

sleep 30

}



SHUTDOWN( )
{
###########################
# Getting ORACLE_HOME
###########################
  ORA_USER=`ps -ef|grep ${ORACLE_SID}|grep pmon|grep -v grep|grep -v ASM|awk '{print $1}'|tail -1`
  USR_ORA_HOME=`grep ${ORA_USER} /etc/passwd| cut -f6 -d ':'|tail -1`

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

##########################################
# Exit if the user is not the Oracle Owner:
##########################################
CURR_USER=`whoami`
        if [ ${ORA_USER} != ${CURR_USER} ]; then
          echo ""
          echo "You're Running This Sctipt with User: \"${CURR_USER}\" !!!"
          echo "Please Run This Script With The Right OS User: \"${ORA_USER}\""
          echo "Script Terminated!"
          exit
        fi

#######################
# Checking Datafiles:
#######################
$ORACLE_HOME/bin/sqlplus '/ as sysdba' <<EOF
set linesize 190
set pages 1000
set long 32000
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
col HOSTNAME for a15
col BLOCKED for a7
col STARTUP_TIME for a19
select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,
to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from v\$instance I ,v\$database D ;

alter system switch logfile ;
alter system switch logfile ;

alter system checkpoint ;
alter system checkpoint ;

shut immediate;

EOF
}

####---------------------------------------------------------------------------------------------------#

STARTUP_UPGRADE( )
{
###########################
# Getting ORACLE_HOME
###########################
###########################
###########################

## If OS is Linux:
if [ -f /etc/oratab ]
  then
  ORATAB=/etc/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME

## If OS is Solaris:
elif [ -f /var/opt/oracle/oratab ]
  then
  ORATAB=/var/opt/oracle/oratab
  ORACLE_HOME=`grep -v '^\#' $ORATAB | grep -v '^$'| grep -i "^${ORACLE_SID}:" | perl -lpe'$_ = reverse' | cut -f3 | perl -lpe'$_ = reverse' |cut -f2 -d':'`
  export ORACLE_HOME
fi

## If oratab is not exist, or ORACLE_SID not added to oratab, find ORACLE_HOME in user's profile:
if [ -z "${ORACLE_HOME}" ]
 then
  ORACLE_HOME=`grep -h 'ORACLE_HOME=\/' $USR_ORA_HOME/.bash* $USR_ORA_HOME/.*profile | perl -lpe'$_ = reverse' |cut -f1 -d'=' | perl -lpe'$_ = reverse'|tail -1`
  export ORACLE_HOME
fi

#######################
# Checking Datafiles:
#######################
$ORACLE_HOME/bin/sqlplus '/ as sysdba' <<EOF

startup

set linesize 190
set pages 1000
set long 32000
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
col HOSTNAME for a15
col BLOCKED for a7
col STARTUP_TIME for a19
select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,
to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from v\$instance I ,v\$database D ;


@?/rdbms/admin/catbundle.sql psu apply
@?/rdbms/admin/utlrp.sql

shut immediate;

startup upgrade ;

@$OJVM_PATCH/postinstall.sql

shut immediate;


startup

set linesize 190
set pages 1000
set long 32000
COLUMN id_plus_exp FORMAT 990 HEADING i
COLUMN parent_id_plus_exp FORMAT 990 HEADING p
COLUMN plan_plus_exp FORMAT a60
COLUMN object_node_plus_exp FORMAT a8
COLUMN other_tag_plus_exp FORMAT a29
COLUMN other_plus_exp FORMAT a44
col HOSTNAME for a15
col BLOCKED for a7
col STARTUP_TIME for a19
select I.instance_name INS_NAME,I.host_name HOSTNAME,I.STATUS,I.DATABASE_STATUS DB_STATUS,D.open_mode,D.database_role,I.LOGINS,
to_char(I.STARTUP_TIME,'DD-MON-YY HH24:MI:SS') STARTUP_TIME from v\$instance I ,v\$database D ;
EOF



}

####-------------------------------------------------------------------------------------------------#######

echo
echo "==================================================="
echo "This script Shows the DATAFILES Size on a database."
echo "==================================================="
echo
sleep 1

#############################
# Listing Available Databases:
#############################

ORACLE_SIDD=$( ps -ef|grep pmon|grep -v grep|grep -v ASM|awk '{print $NF}'|sed -e 's/ora_pmon_//g'|grep -v sed|grep -v "s///g" | head -1 )

ps -eaf | grep pmon | tee /tmp/pre_pmon.log
ps -eaf | grep tns | tee /tmp/pre_tns.log

TNS_LIST=`ps -ef | grep tns | grep -inherit | awk '{print $9}'`

echo " stop listener 1 ......................................   "
TNS_STOP
DBLIST=`ps -ef | grep pmon | grep -v "grep pmon" | grep -v "+ASM" | cut -f3 -d_`


for dbname in $DBLIST
do
export ORACLE_SID=$dbname
echo $ORACLE_SID
SHUTDOWN
done

GRID_DB_PATCH=$1
DIR=/u01/patch_bkp_aug_2018/28317183
OJVM_PATCH=$2
OPATCH_DIR=$3

echo " start database patch ......................................   "

database

echo " End  database patch ......................................   "

echo " start database and apply psu and postinstall ......................................   "

for dbname in $DBLIST
do
export ORACLE_SID=$dbname
echo $ORACLE_SID
STARTUP_UPGRADE
done


echo " start listener 1 ......................................   "

TNS_START
echo " post stutus......................................   "
ps -eaf | grep pmon | tee /tmp/post_pmon.log
ps -eaf | grep tns | tee /tmp/post_tns.log
