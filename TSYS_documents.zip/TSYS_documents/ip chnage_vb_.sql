  ping wql2trandbs03-vip.tsysacquiring.org
  ping wql2trandbs03.tsysacquiring.org
  /opt/oracle/app/product/19.3.0.1/gi/bin/oifcfg getif -global
  /opt/oracle/app/product/19.3.0.1/gi/bin/oifcfg setif -global ens161/10.0.0.0:cluster_interconnect,asm
  /opt/oracle/app/product/19.3.0.1/gi/bin/oifcfg getif -global
  vi /etc/hosts
  reboot
  more /etc/redhat-release
  nmcli con show
  nmcli dev show
  ip addr list
  rpm -qa --last |grep -i kernel
  uname -r
  last |more
  /opt/oracle/app/product/19.3.0.1/gi/bin/oifcfg getif -global
  ./srvctl add asmnetwork -netnum 2 -subnet 10.0.0.0
  cd /opt/oracle/app/product/19.3.0.1/gi/bin/
  ./srvctl add asmnetwork -netnum 2 -subnet 10.0.0.0
  ./srvctl config asmnetwork
  ./srvctl config listener -asmlistener
  ./srvctl add listener -asmlistener -subnet 10.0.0.0
  ./srvctl start listener -listener LISTENER_ASM
  ./crsctl stat res -t
  ./srvctl stop asmnetwork -netnum 1 -force
  ./crsctl stat res -t
  ./srvctl remove listener -listener ASMNET1LSNR_ASM
  srvctl remove asmnetwork -netnum 1
  ./srvctl remove asmnetwork -netnum 1
  ./crsctl stat res -t
  /opt/oracle/app/product/19.3.0.1/gi/bin/oifcfg getif -global
  /opt/oracle/app/product/19.3.0.1/gi/bin/oifcfg delif -global ens256/10.100.226.0
  /opt/oracle/app/product/19.3.0.1/gi/bin/oifcfg getif -global
  reboot
  /opt/oracle/app/product/19.3.0.1/gi/bin/oifcfg getif -global
  cd /opt/oracle/app/product/19.3.0.1/gi/bin/
  ./crsctl stat res -t
  hiustory
  history