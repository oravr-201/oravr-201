epl1trandbrpt1.tsysacquiring.org:/acfs/goldengate> cat /acfs/goldengate/scripts/log_rotation.sh
#!/bin/bash

CurrentDate=`date +%Y%m%d%H`

cd /acfs/goldengate

LOG_FILE_PATH=/acfs/goldengate/ggserr.log
MV_LOGS_DIR=/acfs/goldengate/ggserr_logs
OLD_LOG_FILE_PATH=$MV_LOGS_DIR/ggserr_$CurrentDate.log


DISK_SPACE_VAL=`du -sh "$LOG_FILE_PATH" | awk '{print $1}' | sed -e 's/M//g' -e 's/G//g' -e 's/K//g' -e 's/\./ /g' | awk '{print $1}'`
echo $DISK_SPACE_VAL

if [ "$DISK_SPACE_VAL" -ge "500" ];then
echo "File size is $DISK_SPACE_VAL and moving to other  folder"
cp $LOG_FILE_PATH $OLD_LOG_FILE_PATH
echo "" > $LOG_FILE_PATH
else
echo "File size is less then 500 ..."
fi

epl1trandbrpt1.tsysacquiring.org:/acfs/goldengate> cat /acfs/goldengate/scripts/gglogerror.sh
#!/bin/bash
_logfile=/acfs/goldengate/ggserr.log
_emailFile=/tmp/ggora.$$
_date=`date +%Y-%m-%d`
_search="ORA-"
#_date="2015-10-18"
echo -e "\nSearching for $_search in $_logfile for $_date \n"
cat $_logfile | grep "^$_date" | grep "ORA-" > $_emailFile

if [[ -s $_emailFile ]];then
        perlemail.pl -f OGG_Replication_Err_Alters -t "baidhardas@tsys.com" -c "ifx-dbalerts@tsys.com" -s "$HOSTNAME : Goldengate replication error" -l $_emailFile
else
        echo -e "\nThere are no errors in Golden gate logs..\n"
fi
rm -f $_emailFile
epl1trandbrpt1.tsysacquiring.org:/acfs/goldengate> cat /home/goldengate/scripts/scan_ggate_cdr.sh
#!/bin/ksh
#--------------------------------------------------------------
#
# Purpose : This script pulls a report from goldengate and
#           scans the GoldenGate log for information on CDR
#           statistics on an hourly basis.  If it detects
#           any unresolved CDR errors, it will report them.
#           This should be run hourly
#
#
#--------------------------------------------------------------
#
# Author : Dwight D. Haas
# Date   : April 12, 2016
#
#--------------------------------------------------------------
#
# Declaring certain initial variables.  Not all of them will be used
# but since most have been a habit to work with in the past I have
# been including them whether I ever use them or not.
# Some of them have been changed (like TMP_MONTH) to use a different
# format specific for this particular job

export TMP_MONTH=`date +%b`
export TMP_HOUR=`date +%H`:00:00
export TMP_ALL_HOUR=`date +%H`
export TMP_TEN_MIN=`date +%M | awk '{print substr($1,1,1)}'`
export TMP_HOUR_MIN=`date +%H`:${TMP_TEN_MIN}
export TMP_FULLDATE=`date +%Y-%m-%d`
export TMP_TIMESTRING=`date +%Y_%m_%d_%H%M`
export TMP_YEAR=`date +%Y`
export TMP_DAY=`date | awk '{print $3}'`
export TMP_WEEKDAY=`date +%a`
export TMP_DATE=`date +%Y%m%d`
export TMP_DATE_NORM=`date`
export TMP_MON=`date +%m`
export TMP_MAIL=none
export TMP_ADDR=none
export HOST=`uname -a | awk '{print $2}'`
export BASE_DIR=/home/goldengate/
export CMDDIR=$BASE_DIR/scripts
export SQLDIR=$BASE_DIR/sql
unset ORACLE_SID
export PATH=$PATH:/usr/local/bin

umask 007

# Now we will look at setting up some OS specific items

export OS=`uname`
if [ "$OS" = "HP-UX" ]
     then AWK=/usr/bin/awk
          ORATAB=/etc/oratab
elif [ "$OS" = "Linux" ]
     then AWK=/bin/gawk
          MAILX=/bin/mail
          ORATAB=/etc/oratab
else
          AWK=/usr/bin/nawk
          ORATAB=/var/opt/oracle/oratab
          MAILX=/usr/bin/mailx
fi


# I was hoping to make this so nothing would have to be
# passed in as a parameter, but because Goldengate
# does require some of the libraries set up by an Oracle
# environment, I had to put this in.

# Setting up the options that can be passed in
# -i = instance name - actually it is the env file

while getopts ":i:" opt ; do
     case $opt in
          i ) export ORACLE_SID=$OPTARG ;;
          * ) echo "\n\n"
              echo "\t This is your handy help file at work \n"
              echo "\t Usage : $0 -i <envfile> "
              echo "\t       -i = Vaild ORACLE_SID."
              exit 1 ;;
      esac
done
shift $(($OPTIND - 1))

echo "ORACLE_SID is ${ORACLE_SID}"
export CDRCHK=cdr_scan.${ORACLE_SID}.${TMP_TIMESTRING}
export SCANERR=/home/goldengate/cdr_logs/log_rpt.${TMP_FULLDATE}

if [[ -z "$ORACLE_SID" ]]
     then echo "No SID specified using -i option."
          echo "\t Usage : $0 -i <envfile>"
          echo "\t     -i = Vaild ORACLE_SID."
          echo "exiting"
          exit 1
     else if [[ `fgrep ${ORACLE_SID} ${ORATAB} | wc -l ` -gt 0 ]]
               then export ORAENV_ASK=NO
                    . oraenv
               else echo "No valid SId called ${ORACLE_SID} found in ${ORATAB}"
                    echo "Please try again or review $ORATAB} for valid SIDs"
                    echo "exiting"
                    exit 1
          fi
fi



# Now we use the ggsci command to generate a report and send the
# output to a tmp file.  The tmp file will be scanned for CDR
# info and the results of that scan will be saved in the logs
# directory.

mkdir -p /home/goldengate/cdr_logs

/acfs/goldengate/ggsci > /tmp/$CDRCHK << EOF
stats replicat *, REPORTCDR
EOF

# The file is generated, and now we will scan it.  There are
# many different ways this could have been done.  This method
# is easiest to follow for most though, and so it takes on
# a rather procedural approach in its evaluation
# This actually ended up as a 2 step process - again to keep
# the overall code simple.  The first plucks the info and then
# send it to a pipe delimited file, and the second step pulls
# out only the info and reformats it as regarding CDR

sleep 120

if [[ "${TMP_HOUR}" = "23:00:00" ]]
     then $AWK -v TMP_HOUR=$TMP_HOUR                -v TMP_FULLDATE=$TMP_FULLDATE            \
               -v CDRCHK=$CDRCHK                                                             \
               'BEGIN {print "Report on "CDRCHK"\n"}
                      { if ( NF>4 && $1=="Replicating" ) printf ("\n%s|",$3) }
                      { if ( NF==7 && $2=="Daily" && $5==TMP_FULLDATE ) printf ("%s|",$0) }
                      { if ( NF==7 && $2=="Daily" && $5==TMP_FULLDATE ) flag=1 }
                      { if ( NF < 1 ) flag=0 }
                      { if ( NF < 1 ) nflag=0 }
                      { if ( $1=="CDR" || $2=="CDR" ) nflag=1 }
                      { if ( nflag==1 && flag==1 ) printf ("%s|",$0 ) }
                      { if ( NF < 1 ) flag=0 }
                      { if ( NF < 1 ) nflag=0 }
                  END { if ( x>0 ) print "Sessions crossed threshold \n\n"
                         else print "CDR check complete" }' /tmp/${CDRCHK} >> /tmp/phase1_${CDRCHK}

          $AWK -F\| '{ if ( NF > 3 ) printf ("%s\n%s\n\t%s\n\t%s\n\t%s\n\n",$1,$2,$3,$4,$5) }' \
                    /tmp/phase1_${CDRCHK} >> /home/goldengate/cdr_logs/${CDRCHK}

fi

rm /tmp/${CDRCHK} /tmp/phase1_${CDRCHK}

# Now the previous just generates a report that is all nice and neat.
# This section is a little different in that it will scan for CDR
# errors reported to the log file every 10 minutes.  Of course this
# also means more fun in pattern matching, but it should be simple enough overall

$AWK -v TMP_HOUR=$TMP_HOUR                -v TMP_HOUR_MIN=$TMP_HOUR_MIN            \
     -v SCANERR=$SCANERR                  -v TMP_FULLDATE=$TMP_FULLDATE            \
     'BEGIN {print "Report for "SCANERR"\n"}
            { if ( $1==TMP_FULLDATE && substr($2,1,4)==TMP_HOUR_MIN && $0~"Conflict" ) print $0 }
            { if ( $1==TMP_FULLDATE && substr($2,1,4)==TMP_HOUR_MIN && $0~"Conflict" ) x++ }
      END { if ( x>0 ) print "Found "x" CDR errors"
            else print "No errors found in *.log" }' /acfs/goldengate/*.log > /tmp/${CDRCHK}

RESULT=`fgrep "No errors" /tmp/${CDRCHK} | wc -l`
if [[ $RESULT -ne 1 ]]
     then
          perlemail.pl -f oracle@${HOST} -t "ifx-dbalerts@tsys.com" -s "${HOST} : CDR ERROR ALERT on ${ORACLE_SID}" -l /tmp/${CDRCHK}
fi

rm /tmp/${CDRCHK} /tmp/phase1_${CDRCHK}


--*/
epl1trandbrpt1.tsysacquiring.org:/acfs/goldengate> cat /home/goldengate/scripts/ggsci_status.sh
#!/usr/bin/ksh

#Author : Sandip Tujare
#Script Name: ggsci_status.sh
#Usage:sh <ScriptName> Lag_Threshold
#Purpose: This script has been written to check GoldenGate process's status. This script is part of crontab and will run on every 15 mins to check the lag. If any process ABENEDED or STOPPED due to any reason, this script will send an email to DBA team'.


# constants
# -------------------------------------------------------------------------
GOLDENGATE_HOME=/acfs/goldengate/
ORACLE_HOME=/opt/app/oracle/product/11.2.0/dbhome_2


# no more editting pas this point
# -------------------------------------------------------------------------
LD_LIBRARY_PATH=${ORACLE_HOME}/lib
export LD_LIBRARY_PATH

export LAG_THRESHOLD=$1

cd ${GOLDENGATE_HOME}

# start golden gate with eof and execute 'info all' and
#golden_gate_infoall=`${GOLDENGATE_HOME}/ggsci << EOF > /tmp/ggsci_status.log
#info all
#EOF`

${GOLDENGATE_HOME}/ggsci << EOF > /tmp/ggsci_status.log
info all
EOF

########################################################################################################################

# ********************************************
# Monitoring Godlengate processes and lag time
# ********************************************
cat /tmp/ggsci_status.log | egrep 'MANAGER|EXTRACT|REPLICAT'| tr ":" " " | while read LINE
do
  case $LINE in
    *)
    PROCESS_TYPE=`echo $LINE | awk -F" " '{print $1}'`
    PROCESS_STATUS=`echo $LINE | awk -F" " '{print $2}'`
    if [ "$PROCESS_TYPE" == "MANAGER" ]
    then
       if [ "$PROCESS_STATUS" != "RUNNING" ]
       then
           SUBJECT="ALERT ... Goldengate process \"$PROCESS_TYPE\" is $PROCESS_STATUS on `uname -n`($ORACLE_SID)"
           mailx -s "$SUBJECT" $MAIL_LIST < $GOLDENGATE_HOME/dirrpt/MGR.rpt
           exit 1
       else
           continue
       fi
    elif [ "$PROCESS_TYPE" == "JAGENT" ]
    then
       if [ "$PROCESS_STATUS" != "RUNNING" ]
       then
           SUBJECT="WARNING ... Goldengate process \"$PROCESS_TYPE\" is $PROCESS_STATUS on `uname -n`"
           mailx -s "$SUBJECT" $MAIL_LIST < $GOLDENGATE_HOME/dirrpt/JAGENT.rpt
       fi
    else
       PROCESS_NAME=`echo $LINE | awk -F" " '{print $3}'`
       LAG_HH=`echo $LINE | awk -F" " '{print $4}'`
       LAG_MM=`echo $LINE | awk -F" " '{print $5}'`
       LAG_SS=`echo $LINE | awk -F" " '{print $6}'`
       CKPT_HH=`echo $LINE | awk -F" " '{print $7}'`
       CKPT_MM=`echo $LINE | awk -F" " '{print $8}'`
       CKPT_SS=`echo $LINE | awk -F" " '{print $9}'`

           if [ "$PROCESS_STATUS" != "RUNNING" ]
       then
           perl  /home/goldengate/scripts/perlmail.pl ${PROCESS_TYPE} ${PROCESS_NAME} ${PROCESS_STATUS} 0 "${LAG_HH}:${LAG_MM}:${LAG_SS}" "${CKPT_HH}:${CKPT_MM}:${CKPT_SS}" "a" "b"
       else
           if [ $LAG_HH -gt 00 -o $LAG_MM -ge $LAG_THRESHOLD ];
           then
                 perl  /home/goldengate/scripts/perlmail.pl ${PROCESS_TYPE} ${PROCESS_NAME} ${PROCESS_STATUS} 1 "${LAG_HH}:${LAG_MM}:${LAG_SS}" "${CKPT_HH}:${CKPT_MM}:${CKPT_SS}"  "${LAG_HH}" "${LAG_MM}"
           fi
      fi
    fi
  esac
done

########################################################################################################################


epl1trandbrpt1.tsysacquiring.org:/acfs/goldengate>











epl1trandbrpt1.tsysacquiring.org:/acfs/goldengate> cat /bin/perlemail.pl
#!/usr/bin/perl -w
#
#Author : Angad Patil
#Version 1.0 =
#18 July 2011
use lib ".";
use Env;
use MIME::Lite;
#use Getopt::Std;
use Getopt::Long;
use Sys::Hostname;
#
my $host = hostname;
#my $SMTP_SERVER = 'smtp.tsysacquiring.org';
my $SMTP_SERVER = 'smtpeast.tas.corp';
my $SENDER = 'apatil@tsys.com';
my $RECIPIENT = 'apatil@tsys.com';
my $CCMAIL = '';
my $SUBJECT = "Test Email From $host";
my $FILENAME = "";

usage() if ( @ARGV < 1 or
! GetOptions ('help|?' => \$help,
        "f=s" => \$SENDER,
        "t=s" => \$RECIPIENT,
        "c=s" => \$CCMAIL,
        "s=s" => \$SUBJECT,
        "l=s" => \$FILENAME)
or defined $help );

sub usage
{
  print "\nUnknown option: @_\n" if ( @_ );
  print "\nusage: perlemail.pl [-f Sender Email ID] [-t Recepient Email ID] [-c CC] [-s Subject] [-l filename] [--help|-?]\n\n";
  exit;
}


if (-f ($FILENAME)){
        $yourmessage = `cat $FILENAME`;
        print "\n";
} else {
        print "\nThis is not a valid file. Please attach the appropriate mail content file.........\n\n";
        exit;
}

$msg = new MIME::Lite(
From => $SENDER,
To => $RECIPIENT,
CC => $CCMAIL,
Subject => $SUBJECT,
Type => "TEXT",
Data=> $yourmessage);


print "Sender :- $SENDER\n";
print "Recipient :-  $RECIPIENT\n";
print "CC :- $CCMAIL \n";
print "Subject :- $SUBJECT\n";
print "Email Server :- $SMTP_SERVER\n";

$msg->send('smtp', $SMTP_SERVER, Timeout=>60);
exit 0;

-----------------------------------------------------------------------------------------------------














# GoldenGate ggserr.log rotation cron job
00 02 * * * sh /acfs/goldengate/scripts/log_rotation.sh > /acfs/goldengate/scripts/log_rotation.log
55 23 * * * sh /acfs/goldengate/scripts/gglogerror.sh

##################################################
# Pull CDR info
##################################################
09  *  *  *  *           /home/goldengate/scripts/scan_ggate_cdr.sh -i transitr1                          >> /dev/null 2>&1
19  *  *  *  *           /home/goldengate/scripts/scan_ggate_cdr.sh -i transitr1                          >> /dev/null 2>&1
29  *  *  *  *           /home/goldengate/scripts/scan_ggate_cdr.sh -i transitr1                          >> /dev/null 2>&1
39  *  *  *  *           /home/goldengate/scripts/scan_ggate_cdr.sh -i transitr1                          >> /dev/null 2>&1
49  *  *  *  *           /home/goldengate/scripts/scan_ggate_cdr.sh -i transitr1                          >> /dev/null 2>&1
59  *  *  *  *           /home/goldengate/scripts/scan_ggate_cdr.sh -i transitr1                          >> /dev/null 2>&1



########################################################
# GoldenGate Monitoring Script
#######################################################
*/15 * * * *  sh /home/goldengate/scripts/ggsci_status.sh 1 > /home/goldengate/scripts/ggsci_status.log

epl1trandbrpt1.tsysacquiring.org:/acfs/goldengate>
