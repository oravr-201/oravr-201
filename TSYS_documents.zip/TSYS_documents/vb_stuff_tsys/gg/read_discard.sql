Step 1 : GGATE.read_discard



CREATE OR REPLACE FUNCTION GGATE.read_discard
   RETURN DiscardTable
   PIPELINED
IS
   /*******************************************************************************************
   -- Created By : Sandip Tujare
   -- Creation Date : 05 May, 2016
   -- Purpose : This function is created as apart of HOT-HOT phase 2, to read conflict related information from the discard file.
   ********************************************************************************************/

   FileHandle      UTL_FILE.FILE_TYPE;

   DiscardRec      DISCARDRECORD;
   DiscardExtra    DISCARDRECORD;

   FileBuffer      VARCHAR2 (32767);
   PartLine        VARCHAR2 (32767);

   OutputRow       BOOLEAN;
   ErrorRow        BOOLEAN;
   FindingColumn   BOOLEAN;

   LineNumber      NUMBER := 0;

   V_FileName      VARCHAR2 (50);

   /* Cursors */

   CURSOR get_cons_cols_curs (
      ConstraintOwner    VARCHAR2,
      ConstraintName     VARCHAR2)
   IS
      SELECT column_name
        FROM dba_cons_columns
       WHERE     OWNER = ConstraintOwner
             AND constraint_name = ConstraintName
             AND position = 1;

   CURSOR get_pk_table_curs (
      ConstraintOwner    VARCHAR2,
      ConstraintName     VARCHAR2)
   IS
      SELECT pk.table_name
        FROM dba_constraints fk, dba_constraints pk
       WHERE     pk.owner = fk.r_owner
             AND pk.constraint_name = fk.r_constraint_name
             AND fk.owner = ConstraintOwner
             AND fk.constraint_name = ConstraintName;

   CURSOR get_pk_col_curs (
      TableOwner    VARCHAR2,
      TableName     VARCHAR2)
   IS
      SELECT col.column_name
        FROM dba_cons_columns COL, dba_constraints pk
       WHERE     pk.owner = TableOwner
             AND pk.table_name = TableName
             AND pk.owner = col.owner
             AND pk.constraint_name = col.constraint_name
             AND pk.constraint_type = 'P'
             AND col.position = 1;

   /* Procedures */

   PROCEDURE OpenDiscard (FileName IN VARCHAR2)
   IS
   BEGIN
      FileHandle := UTL_FILE.FOPEN ('GGDISCARD', FileName, 'R');
   END OpenDiscard;

   PROCEDURE ReadDiscard
   IS
   BEGIN
      UTL_FILE.GET_LINE (FileHandle, FileBuffer);

      LineNumber := LineNumber + 1;
   END ReadDiscard;

   PROCEDURE CloseDiscard
   IS
   BEGIN
      UTL_FILE.FCLOSE (FileHandle);
   END CloseDiscard;

   PROCEDURE InitialiseRecord (Discard_INOUT IN OUT DISCARDRECORD)
   IS
   BEGIN
      Discard_INOUT :=
         DISCARDRECORD (NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL,
                        NULL);
   END InitialiseRecord;
BEGIN
   InitialiseRecord (DiscardRec);


    /* If number of replicator discard files are increased then please make the modification below, to include that new file name */
   FOR I IN 1 .. 2
   LOOP
      IF I = 1
      THEN
         V_FileName := 'RPTETW01.dsc';
      ELSIF I = 2
      THEN
         V_FileName := 'RPTETWLG.dsc';
      END IF;

      OpenDiscard (V_FileName);

      ErrorRow := FALSE;
      FindingColumn := FALSE;

      --      InitialiseRecord (DiscardRec);

      BEGIN
         LOOP
            ReadDiscard;

            WHILE FileBuffer IS NULL
            LOOP
               ReadDiscard;
            END LOOP;

            /* Read first 2 words */

            IF FileBuffer = '*'
            THEN
               PartLine := '*';
            ELSE
               PartLine :=SUBSTR (FileBuffer,1,INSTR (FileBuffer,' ',2,2)- 1);
            END IF;

            OutputRow := FALSE;

            CASE PartLine
               WHEN 'Current time:'
               THEN
                  IF ErrorRow
                  THEN
                     PIPE ROW (DiscardRec);
                     InitialiseRecord (DiscardRec);
                  END IF;

                  DiscardRec.FILE_NAME := V_FileName;
                  DiscardRec.MESSAGE_TYPE := 'ERROR';
                  DiscardRec.message_date :=TO_DATE (SUBSTR (FileBuffer, INSTR (FileBuffer, ':') + 2),'YYYY-MM-DD HH24:MI:SS');
                  DiscardRec.line_number := LineNumber;

                  ErrorRow := TRUE;
                  OutputRow := FALSE;
               WHEN 'OCI Error'
               THEN
                  DiscardRec.oracle_error :=SUBSTR (FileBuffer,INSTR (FileBuffer,' ',1,2)+ 1,INSTR (FileBuffer, ':')- (  INSTR (FileBuffer,' ',1,2)+ 1));
                  DiscardRec.error_number :=TO_NUMBER (SUBSTR (DiscardRec.oracle_error,INSTR (DiscardRec.oracle_error, '-') + 1));
                  DiscardRec.MESSAGE :=SUBSTR (FileBuffer,INSTR (FileBuffer, ':') + 2,INSTR (FileBuffer, ',')- (INSTR (FileBuffer, ':') + 2));


                  CASE DiscardRec.error_number
                     WHEN 1
                     THEN
                        PartLine := SUBSTR (DiscardRec.MESSAGE,INSTR (DiscardRec.MESSAGE, '(') + 1,INSTR (DiscardRec.MESSAGE, ')')- (INSTR (DiscardRec.MESSAGE, '(') + 1));
                        DiscardRec.error_object_owner := SUBSTR (PartLine, 1, INSTR (PartLine, '.') - 1);
                        DiscardRec.error_object_name :=SUBSTR (PartLine, INSTR (PartLine, '.') + 1);
                        DiscardRec.description :=SUBSTR (FileBuffer,INSTR (FileBuffer,'.',1,2)+ 1);
                        
                     WHEN 2291
                     THEN
                        PartLine :=SUBSTR (DiscardRec.MESSAGE,INSTR (DiscardRec.MESSAGE, '(') + 1,INSTR (DiscardRec.MESSAGE, ')')- (INSTR (DiscardRec.MESSAGE, '(') + 1));
                        DiscardRec.error_object_owner :=SUBSTR (PartLine, 1, INSTR (PartLine, '.') - 1);
                        DiscardRec.error_object_name :=SUBSTR (PartLine, INSTR (PartLine, '.') + 1);
                        DiscardRec.description :=SUBSTR (FileBuffer,INSTR (FileBuffer,'.',1,2)+ 1);
                        
                     WHEN 1403
                     THEN
                        DiscardRec.description := SUBSTR (FileBuffer, INSTR (FileBuffer, 'SQL '));
                        
                     ELSE
                        NULL;
                  END CASE;

                  OutputRow := FALSE;
               WHEN 'Problem replicating'
               THEN
                  PartLine :=SUBSTR (FileBuffer,INSTR (FileBuffer,' ',1,2)+ 1,INSTR (FileBuffer, ' to ')- (  INSTR (FileBuffer,' ',1,2)+ 1));
                  DiscardRec.source_object_owner :=SUBSTR (PartLine, 1, INSTR (PartLine, '.') - 1);
                  DiscardRec.source_object_name :=SUBSTR (PartLine, INSTR (PartLine, '.') + 1);

                  PartLine :=SUBSTR (FileBuffer, INSTR (FileBuffer, ' to ') + 4);

                  DiscardRec.target_object_owner :=SUBSTR (PartLine, 1, INSTR (PartLine, '.') - 1);
                  DiscardRec.target_object_name :=SUBSTR (PartLine, INSTR (PartLine, '.') + 1);

                  OutputRow := FALSE;
               WHEN 'Operation failed'
               THEN
                  DiscardRec.operation_seqno :=SUBSTR (FileBuffer,INSTR (FileBuffer, 'seqno ') + 6,INSTR (FileBuffer, ' rba ')- (INSTR (FileBuffer, 'seqno ') + 6));
                  DiscardRec.operation_rba :=SUBSTR (FileBuffer, INSTR (FileBuffer, ' rba ') + 5);

                  OutputRow := FALSE;
               WHEN 'Oracle GoldenGate'
               THEN
                  IF ErrorRow
                  THEN
                     PIPE ROW (DiscardRec);
                     InitialiseRecord (DiscardRec);
                     ErrorRow := FALSE;
                  END IF;



                  DiscardRec.MESSAGE_TYPE := 'INFO';
                  DiscardRec.MESSAGE := SUBSTR (FileBuffer, 19, INSTR (FileBuffer, ' ', 19, 1) - 19) || ' Process ' || SUBSTR (FileBuffer,INSTR (FileBuffer, 'for Oracle process') + 19,INSTR (FileBuffer, ',')- (INSTR (FileBuffer, 'for Oracle process') + 19));
                  DiscardRec.description :=SUBSTR (FileBuffer,INSTR (FileBuffer, ',') + 2,INSTR (FileBuffer, ':')- (INSTR (FileBuffer, ',') + 2));
                  DiscardRec.message_date :=TO_DATE (SUBSTR (FileBuffer, INSTR (FileBuffer, ':') + 2),'YYYY-MM-DD HH24:MI:SS');
                  DiscardRec.line_number := LineNumber;
                  OutputRow := TRUE;
               WHEN 'Process Abending'
               THEN
                  IF ErrorRow
                  THEN
                     PIPE ROW (DiscardRec);
                     InitialiseRecord (DiscardRec);
                     ErrorRow := FALSE;
                  END IF;

                  DiscardRec.MESSAGE_TYPE := 'WARNING';
                  DiscardRec.MESSAGE := PartLine;
                  DiscardRec.message_date :=TO_DATE (SUBSTR (FileBuffer, INSTR (FileBuffer, ':') + 2),'YYYY-MM-DD HH24:MI:SS');
                  DiscardRec.line_number := LineNumber;

                  OutputRow := TRUE;
               WHEN 'Aborted compressed'
               THEN
                  DiscardRec.error_operation :=UPPER (SUBSTR (FileBuffer,INSTR (FileBuffer,' ',1,2)+ 1,INSTR (FileBuffer,' ',1,3)- (  INSTR (FileBuffer,' ',1,2)+ 1)));

                  DiscardRec.source_object_owner :=SUBSTR (FileBuffer,INSTR (FileBuffer,' ',1,4)+ 1,(INSTR (FileBuffer, '.')- INSTR (FileBuffer,' ',1,4)- 1));
                  DiscardRec.source_object_name :=SUBSTR (FileBuffer,INSTR (FileBuffer,'.',1,1)+ 1,(INSTR (FileBuffer,' ',1,5)- (INSTR (FileBuffer,'.',1,1)+ 1)));

                  DiscardRec.target_object_owner := SUBSTR (FileBuffer,INSTR (FileBuffer,' ',1,4)+ 1,(INSTR (FileBuffer, '.')- INSTR (FileBuffer,' ',1,4)- 1));
                  DiscardRec.target_object_name :=SUBSTR (FileBuffer,INSTR (FileBuffer,'.',1,1)+ 1,(INSTR (FileBuffer,' ',1,5)- (INSTR (FileBuffer,'.',1,1)+ 1)));

                  OutputRow := FALSE;
               
               WHEN 'Aborted insert'
               THEN
                  DiscardRec.error_operation :=UPPER (SUBSTR (FileBuffer,INSTR (FileBuffer,' ',1)+ 1,INSTR (FileBuffer,' ',1,2)- (INSTR (FileBuffer,' ',1)+ 1)));

                  DiscardRec.source_object_owner :=SUBSTR (FileBuffer,INSTR (FileBuffer,' ',1,3)+ 1,(INSTR (FileBuffer, '.')- INSTR (FileBuffer,' ',1,3)- 1));
                  DiscardRec.source_object_name :=SUBSTR (FileBuffer,INSTR (FileBuffer,'.',1,1)+ 1,(INSTR (FileBuffer,' ',1,4)- (INSTR (FileBuffer,'.',1,1)+ 1)));

                  DiscardRec.target_object_owner := SUBSTR (FileBuffer,INSTR (FileBuffer,' ',1,3)+ 1,(INSTR (FileBuffer, '.')- INSTR (FileBuffer,' ',1,3)- 1));
                  DiscardRec.target_object_name :=SUBSTR (FileBuffer,INSTR (FileBuffer,'.',1,1)+ 1,(INSTR (FileBuffer,' ',1,4)- (INSTR (FileBuffer,'.',1,1)+ 1)));
                  
                  DiscardRec.description := FileBuffer;
                  DiscardRec.error_object_owner := DiscardRec.source_object_owner;
                  DiscardRec.error_object_name := DiscardRec.source_object_name;

                  OutputRow := FALSE;
                  
               WHEN 'Error text'
               THEN
                  DiscardRec.oracle_error := SUBSTR (FileBuffer,INSTR (FileBuffer, ', ') + 2,INSTR (FileBuffer, ':')- (INSTR (FileBuffer, ', ') + 2));
                  DiscardRec.error_number :=TO_NUMBER (SUBSTR (DiscardRec.oracle_error,INSTR (DiscardRec.oracle_error, '-') + 1));
                  DiscardRec.MESSAGE :=SUBSTR (FileBuffer,INSTR (FileBuffer, ':') + 2,INSTR (FileBuffer,',',1,2)- (INSTR (FileBuffer, ':') + 2));
                  DiscardRec.description :=SUBSTR (FileBuffer, INSTR (FileBuffer, 'SQL '));

                  OutputRow := FALSE;
               WHEN 'Discarding record'
               THEN
                  DiscardRec.MESSAGE := FileBuffer;

                  OutputRow := FALSE;
               WHEN 'Operation: 15'
               THEN
                  DiscardRec.oracle_error :='ORA-'|| TO_CHAR (TO_NUMBER (SUBSTR (FileBuffer,INSTR (FileBuffer, ' ', -1))),'FM09999');
                  DiscardRec.error_number :=TO_NUMBER (SUBSTR (DiscardRec.oracle_error,INSTR (DiscardRec.oracle_error, '-') + 1));

                  DiscardRec.description := FileBuffer;

                  OutputRow := FALSE;
                  
               WHEN 'Operation: 5'
               THEN
                  DiscardRec.oracle_error :='ORA-'|| TO_CHAR (TO_NUMBER (SUBSTR (FileBuffer,INSTR (FileBuffer, ' ', -1))),'FM09999');
                  DiscardRec.error_number :=TO_NUMBER (SUBSTR (DiscardRec.oracle_error,INSTR (DiscardRec.oracle_error, '-') + 1));

                  OutputRow := FALSE;
               WHEN 'Mapping problem'
               THEN
                  DiscardRec.error_operation :=UPPER (SUBSTR (FileBuffer,INSTR (FileBuffer,' ',-1,4)+ 1,INSTR (FileBuffer,' ',-1,3)- (INSTR (FileBuffer,' ',-1,4)+ 1)));

                  OutputRow := FALSE;
               WHEN 'Record not'
               THEN
                  DiscardRec.MESSAGE := FileBuffer;

                  OutputRow := FALSE;
               WHEN '*'
               THEN
                  IF FindingColumn
                  THEN
                     FindingColumn := FALSE;
                     OutputRow := TRUE;
                  ELSE
                     /* Gather some information for specific messages */

                     CASE DiscardRec.error_number
                        WHEN 1               /* Unique constraint violation */
                        THEN
                           /* Find the first column for the key and then be able to find it's value in the text */

                           OPEN get_cons_cols_curs (DiscardRec.error_object_owner,DiscardRec.error_object_name);

                           FETCH get_cons_cols_curs
                           INTO DiscardRec.error_column;

                           CLOSE get_cons_cols_curs;
                        WHEN 1403                          /* Row not found */
                        THEN
                           /* Find the PK of the table and then find it's value - if possible */

                           DiscardRec.error_object_owner :=DiscardRec.source_object_owner;
                           DiscardRec.error_object_name :=DiscardRec.source_object_name;

                           OPEN get_pk_col_curs (DiscardRec.error_object_owner,DiscardRec.error_object_name);

                           FETCH get_pk_col_curs INTO DiscardRec.error_column;

                           CLOSE get_pk_col_curs;
                        WHEN 2291         /* Integrity constraint voilation */
                        THEN
                           /* Find the fk table name , column name and then be able to find the value of the offending row */
                           /* Get the column name */

                           OPEN get_cons_cols_curs (DiscardRec.error_object_owner,DiscardRec.error_object_name);

                           FETCH get_cons_cols_curs
                           INTO DiscardRec.error_column;

                           CLOSE get_cons_cols_curs;

                           /* Get primary key table name */

                           OPEN get_pk_table_curs (DiscardRec.error_object_owner,DiscardRec.error_object_name);

                           FETCH get_pk_table_curs
                           INTO DiscardRec.parent_table_name;

                           CLOSE get_pk_table_curs;
                        ELSE
                           NULL;
                     END CASE;

                     FindingColumn := TRUE;
                  END IF;
               ELSE
                  IF FindingColumn
                  THEN
                     IF DiscardRec.error_column IS NOT NULL
                     THEN
                        IF DiscardRec.error_column =SUBSTR (FileBuffer,1,INSTR (FileBuffer, ' = ') - 1)
                        THEN
                           DiscardRec.error_value :=SUBSTR (FileBuffer,INSTR (FileBuffer, ' = ') + 3);
                        END IF;

                        DiscardRec.actual_values :=DiscardRec.actual_values|| ' | '|| SUBSTR (FileBuffer,1,INSTR (FileBuffer, ' = ') - 1)|| ' = '|| SUBSTR (FileBuffer,INSTR (FileBuffer, ' = ') + 3);
                     END IF;
                  ELSE
                  
                    
                     /* Found something unusual so let's output an extra record */

                     InitialiseRecord (DiscardExtra);
                     DiscardExtra.MESSAGE_TYPE := 'UNKNOWN';
                     DiscardExtra.MESSAGE := SUBSTR (FileBuffer, 1, 120);
                     DiscardExtra.description := SUBSTR (FileBuffer, 120);
                     DiscardExtra.line_number := LineNumber;

                     PIPE ROW (DiscardExtra);
                  END IF;
            END CASE;

            IF OutputRow
            THEN
               PIPE ROW (DiscardRec);
               InitialiseRecord (DiscardRec);
               ErrorRow := FALSE;
            END IF;
         END LOOP;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            /* Output last row if not output */

            IF DiscardRec.MESSAGE_TYPE IS NOT NULL
            THEN
               PIPE ROW (DiscardRec);
            END IF;

            CloseDiscard;
         WHEN OTHERS
         THEN
            NULL;
      END;
   END LOOP;
END read_discard;     /* GOLDENGATE_DDL_REPLICATION */
/











---------------------------------------------------------------------------------



STEP 2 : JOB 

BEGIN
   INSERT INTO DISCARD_DATA (DATABASE_NAME
                           , MESSAGE_TYPE
                           , MESSAGE
                           , MESSAGE_DATE
                           , LINE_NUMBER
                           , ORACLE_ERROR
                           , ERROR_NUMBER
                           , SOURCE_OBJECT_OWNER
                           , SOURCE_OBJECT_NAME
                           , TARGET_OBJECT_OWNER
                           , TARGET_OBJECT_NAME
                           , ERROR_OPERATION
                           , ERROR_OBJECT_OWNER
                           , ERROR_OBJECT_NAME
                           , ERROR_COLUMN
                           , ERROR_VALUE
                           , PARENT_TABLE_NAME
                           , OPERATION_SEQNO
                           , OPERATION_RBA
                           , DESCRIPTION
                           , ACTUAL_VALUES)
      SELECT FILE_NAME
           , MESSAGE_TYPE
           , MESSAGE
           , MESSAGE_DATE
           , LINE_NUMBER
           , ORACLE_ERROR
           , ERROR_NUMBER
           , SOURCE_OBJECT_OWNER
           , SOURCE_OBJECT_NAME
           , TARGET_OBJECT_OWNER
           , TARGET_OBJECT_NAME
           , ERROR_OPERATION
           , ERROR_OBJECT_OWNER
           , ERROR_OBJECT_NAME
           , ERROR_COLUMN
           , ERROR_VALUE
           , PARENT_TABLE_NAME
           , OPERATION_SEQNO
           , OPERATION_RBA
           , DESCRIPTION
           , ACTUAL_VALUES
        FROM TABLE (READ_DISCARD)
       WHERE MESSAGE_TYPE = 'ERROR'
       AND MESSAGE_DATE BETWEEN SYSDATE -1/24 AND SYSDATE;


   COMMIT;
   EXCEPTION
   WHEN OTHERS THEN NULL; 
END;




STEP 3 : CREATE TABLE 


CREATE TABLE CDR_DATA.DISCARD_DATA
(
  DATABASE_NAME        VARCHAR2(100 BYTE),
  MESSAGE_TYPE         VARCHAR2(7 BYTE),
  MESSAGE              VARCHAR2(4000 BYTE),
  MESSAGE_DATE         DATE,
  LINE_NUMBER          NUMBER,
  ORACLE_ERROR         VARCHAR2(10 BYTE),
  ERROR_NUMBER         NUMBER,
  SOURCE_OBJECT_OWNER  VARCHAR2(30 BYTE),
  SOURCE_OBJECT_NAME   VARCHAR2(30 BYTE),
  TARGET_OBJECT_OWNER  VARCHAR2(30 BYTE),
  TARGET_OBJECT_NAME   VARCHAR2(30 BYTE),
  ERROR_OPERATION      VARCHAR2(20 BYTE),
  ERROR_OBJECT_OWNER   VARCHAR2(30 BYTE),
  ERROR_OBJECT_NAME    VARCHAR2(30 BYTE),
  ERROR_COLUMN         VARCHAR2(120 BYTE),
  ERROR_VALUE          VARCHAR2(4000 BYTE),
  PARENT_TABLE_NAME    VARCHAR2(30 BYTE),
  OPERATION_SEQNO      NUMBER,
  OPERATION_RBA        NUMBER,
  DESCRIPTION          VARCHAR2(4000 BYTE),
  ACTUAL_VALUES        VARCHAR2(4000 BYTE)
)
TABLESPACE USERS
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
MONITORING;


CREATE INDEX CDR_DATA.IDX_MESSAGE_DATE ON CDR_DATA.DISCARD_DATA
(MESSAGE_DATE)
LOGGING
TABLESPACE INDX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE OR REPLACE SYNONYM GGATE.DISCARD_DATA FOR CDR_DATA.DISCARD_DATA;


CREATE OR REPLACE SYNONYM TRANSNOX_IOX.DISCARD_DATA FOR CDR_DATA.DISCARD_DATA;


CREATE OR REPLACE SYNONYM TRANSNOX_IOX_APP.DISCARD_DATA FOR CDR_DATA.DISCARD_DATA;


GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON CDR_DATA.DISCARD_DATA TO GGATE;

GRANT DELETE, INSERT, SELECT, UPDATE ON CDR_DATA.DISCARD_DATA TO TRANSNOX_IOX;

GRANT DELETE, INSERT, SELECT, UPDATE ON CDR_DATA.DISCARD_DATA TO TRANSNOX_IOX_APP;




step 4:


CREATE TABLE CDR_DATA.DISCARD_DATA
(
  DATABASE_NAME        VARCHAR2(100 BYTE),
  MESSAGE_TYPE         VARCHAR2(7 BYTE),
  MESSAGE              VARCHAR2(4000 BYTE),
  MESSAGE_DATE         DATE,
  LINE_NUMBER          NUMBER,
  ORACLE_ERROR         VARCHAR2(10 BYTE),
  ERROR_NUMBER         NUMBER,
  SOURCE_OBJECT_OWNER  VARCHAR2(30 BYTE),
  SOURCE_OBJECT_NAME   VARCHAR2(30 BYTE),
  TARGET_OBJECT_OWNER  VARCHAR2(30 BYTE),
  TARGET_OBJECT_NAME   VARCHAR2(30 BYTE),
  ERROR_OPERATION      VARCHAR2(20 BYTE),
  ERROR_OBJECT_OWNER   VARCHAR2(30 BYTE),
  ERROR_OBJECT_NAME    VARCHAR2(30 BYTE),
  ERROR_COLUMN         VARCHAR2(120 BYTE),
  ERROR_VALUE          VARCHAR2(4000 BYTE),
  PARENT_TABLE_NAME    VARCHAR2(30 BYTE),
  OPERATION_SEQNO      NUMBER,
  OPERATION_RBA        NUMBER,
  DESCRIPTION          VARCHAR2(4000 BYTE),
  ACTUAL_VALUES        VARCHAR2(4000 BYTE)
)
TABLESPACE USERS
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
MONITORING;


CREATE INDEX CDR_DATA.IDX_MESSAGE_DATE ON CDR_DATA.DISCARD_DATA
(MESSAGE_DATE)
LOGGING
TABLESPACE INDX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           );

CREATE OR REPLACE SYNONYM GGATE.DISCARD_DATA FOR CDR_DATA.DISCARD_DATA;


CREATE OR REPLACE SYNONYM TRANSNOX_IOX.DISCARD_DATA FOR CDR_DATA.DISCARD_DATA;


CREATE OR REPLACE SYNONYM TRANSNOX_IOX_APP.DISCARD_DATA FOR CDR_DATA.DISCARD_DATA;


GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON CDR_DATA.DISCARD_DATA TO GGATE;

GRANT DELETE, INSERT, SELECT, UPDATE ON CDR_DATA.DISCARD_DATA TO TRANSNOX_IOX;

GRANT DELETE, INSERT, SELECT, UPDATE ON CDR_DATA.DISCARD_DATA TO TRANSNOX_IOX_APP;

