[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat pass.sh
>pass_list_QA_3118.txt
for i in transit_fe_tnox_3118 transit_fe_snox_3118 transit_gateway_tnox_3118 transit_gateway_snox_3118 transit_smsnox_tnox_3118 transit_smsnox_snox_3118
do

sleep 2
export a=`date +%s | sha256sum | base64 | head -c 29`


java -jar EncryptPassword.jar $a
echo "=======================================================" >> pass_list_QA_3118.txt
echo -e "$i" >>pass_list_QA_3118.txt
echo "$a" >>pass_list_QA_3118.txt
cat KeyPassword.txt >> pass_list_QA_3118.txt
echo "=======================================================">>pass_list_QA_3118.txt

done
[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat generatepass.sh
a=`date +%s | sha256sum | base64 | head -c 29`

pass=$ver/.${INFONOX_NEW_VBS_SCHEMA_NAME}_${INFONOX_DB_SERVICENAME}.txt
>$pass
sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME   @sqlscripts/set_password.sql $INFONOX_NEW_VBS_SCHEMA_NAME $a  $TODAY $SERVICE_LOG_FOLDER_NAME

sed -i '/new   1: alter user/d' $logfile

java -jar EncryptPassword.jar $a
echo "=======================================================" >> $pass
echo "Plain password $a" >>$pass
echo -e "$INFONOX_NEW_VBS_SCHEMA_NAME\n" >>$pass
cat KeyPassword.txt >> $pass
echo "=======================================================">>$pass
[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat create_vbs.sh
for i in `grep -iv no env_config.csv`
do
   service=`echo $i|awk -F, '{print $1}'|tr -d ""`
   sh run_dbrelease.sh  $service &
done
[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat run_dbrelease_vbs.sh





export release_person=ggate
echo "Enter Password:"
read -s release_person_passwd

export INFONOX_DB_SERVICENAME=RW_N1

export backup_directory_name=dbrelease_export
export defaulttablespace=users
export defaul_temp_tablespace=temp
export indextablespace=indx
export SERVICE_LOG_FOLDER_NAME=${INFONOX_DB_SERVICENAME:0:3}
export TODAY=`date +%d_%m_%Y`
mkdir -p logs/$TODAY/$SERVICE_LOG_FOLDER_NAME
ver1=`grep -v '#' config.csv|tail -1|awk -F"," '{print $2}'|awk -F"_" '{print $4}'`
export ver=.pass/$ver1/$SERVICE_LOG_FOLDER_NAME
mkdir -p $ver

vbs_logs=/home/dblogs/Vbs_Logs/${ver1}

mkdir -p $vbs_logs

#exec >${SERVICE_LOG_FOLDER_NAME}_${ver1}_${TODAY}`date +%H%M%S`
export logfile=${SERVICE_LOG_FOLDER_NAME}_${ver1}_complete_logs_`date +%d%m%Y%H%M%S`.log


exec > $logfile 2>&1


for i in `cat config.csv|grep -v '#'`
do

export INFONOX_OLD_VBS_SCHEMA_NAME=`echo $i |awk -F"," '{print $1}'`

export INFONOX_NEW_VBS_SCHEMA_NAME=`echo $i|awk -F"," '{print $2}'`


export export_dump_file_name=exp_${INFONOX_OLD_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`

export import_log_file_name=${INFONOX_NEW_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`.log

echo -e "==============================================================START OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

echo "Starting schema export for user ${INFONOX_OLD_VBS_SCHEMA_NAME}....."

echo ${export_dump_file_name}.dmp

expdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME directory=$backup_directory_name dumpfile=${export_dump_file_name}.dmp logfile=${export_dump_file_name}.log schemas=$INFONOX_OLD_VBS_SCHEMA_NAME GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\"

if [ $? -eq 0 ]
then

        echo "Export Completed for schema $INFONOX_OLD_VBS_SCHEMA_NAME....."
else
        echo ">>>>>>Error while exporting exiting ..."
        mv $logfile $vbs_logs
        exit 1
fi

echo "Starting schema import for  ${INFONOX_NEW_VBS_SCHEMA_NAME}..."

impdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME GRANTS=y  directory=$backup_directory_name  dumpfile=${export_dump_file_name}.dmp logfile=$import_log_file_name  remap_schema=$INFONOX_OLD_VBS_SCHEMA_NAME:$INFONOX_NEW_VBS_SCHEMA_NAME transform=OID:n

echo "Import completed for schema $INFONOX_NEW_VBS_SCHEMA_NAME"

sh  generatepass.sh

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME   @sqlscripts/GRANT_SCRIPT.sql $INFONOX_OLD_VBS_SCHEMA_NAME $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

echo "Start - Compiling Invalid Schema Objects: compile_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/compile_schema.sql $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

!echo "Done - Compiled Invalid Schema Objects: compile_schema"

!echo "Start - Comparing Schema Objects: compare_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/COMPARE_VBS.sql $INFONOX_NEW_VBS_SCHEMA_NAME $INFONOX_OLD_VBS_SCHEMA_NAME $defaulttablespace $defaul_temp_tablespace $release_person $release_person_passwd $INFONOX_DB_SERVICENAME $TODAY $SERVICE_LOG_FOLDER_NAME


echo "End - Comparing Schema Objects: compare_schema"

echo -e "==============================================================END OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

done

cd $ver

pass_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_PASSWORDS_`date +%d%m%Y%H%M%S`.txt

cat `ls -atr .*.txt`|grep -v 'Plain'  >$pass_file


mv $pass_file $vbs_logs

cd ../../..

sed -i '/new   1: alter user/d' $logfile

mv $logfile $vbs_logs

cd logs/$TODAY/$SERVICE_LOG_FOLDER_NAME

cmp_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_compare_all_vbs_logs_`date +%d%m%Y%H%M%S`.log

cat `ls -tr COMPARE_VBS_transit*_${ver1}.SQL`|sed -n '/^OBJECT_TYPE/,/SQL>/p'  > $cmp_file

sed -i 's/SQL>/\n/' $cmp_file

mv  $cmp_file  $vbs_logs

echo "Completed VBS Creation....."






















[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat run_dbrelease_vbs_RE.sh





export release_person=ggate
#echo "Enter Password:"
#read -s release_person_passwd

export release_person_passwd=

export INFONOX_DB_SERVICENAME=RE_N1

export backup_directory_name=dbrelease_export
export defaulttablespace=users
export defaul_temp_tablespace=temp
export indextablespace=indx
export SERVICE_LOG_FOLDER_NAME=${INFONOX_DB_SERVICENAME:0:3}
export TODAY=`date +%d_%m_%Y`
mkdir -p logs/$TODAY/$SERVICE_LOG_FOLDER_NAME
ver1=`grep -v '#' config.csv|tail -1|awk -F"," '{print $2}'|awk -F"_" '{print $4}'`
export ver=.pass/$ver1/$SERVICE_LOG_FOLDER_NAME
mkdir -p $ver

vbs_logs=/home/dblogs/Vbs_Logs/${ver1}

mkdir -p $vbs_logs

#exec >${SERVICE_LOG_FOLDER_NAME}_${ver1}_${TODAY}`date +%H%M%S`
export logfile=${SERVICE_LOG_FOLDER_NAME}_${ver1}_complete_logs_`date +%d%m%Y%H%M%S`.log


exec > $logfile 2>&1


for i in `cat config.csv|grep -v '#'`
do

export INFONOX_OLD_VBS_SCHEMA_NAME=`echo $i |awk -F"," '{print $1}'`

export INFONOX_NEW_VBS_SCHEMA_NAME=`echo $i|awk -F"," '{print $2}'`


export export_dump_file_name=exp_${INFONOX_OLD_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`

export import_log_file_name=${INFONOX_NEW_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`.log

echo -e "==============================================================START OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

echo "Starting schema export for user ${INFONOX_OLD_VBS_SCHEMA_NAME}....."

echo ${export_dump_file_name}.dmp

expdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME directory=$backup_directory_name dumpfile=${export_dump_file_name}.dmp logfile=${export_dump_file_name}.log schemas=$INFONOX_OLD_VBS_SCHEMA_NAME GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\"

if [ $? -eq 0 ]
then

        echo "Export Completed for schema $INFONOX_OLD_VBS_SCHEMA_NAME....."
else
        echo ">>>>>>Error while exporting exiting ..."
        mv $logfile $vbs_logs
        exit 1
fi

echo "Starting schema import for  ${INFONOX_NEW_VBS_SCHEMA_NAME}..."

impdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME GRANTS=y  directory=$backup_directory_name  dumpfile=${export_dump_file_name}.dmp logfile=$import_log_file_name  remap_schema=$INFONOX_OLD_VBS_SCHEMA_NAME:$INFONOX_NEW_VBS_SCHEMA_NAME transform=OID:n

echo "Import completed for schema $INFONOX_NEW_VBS_SCHEMA_NAME"

sh  generatepass.sh

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME   @sqlscripts/GRANT_SCRIPT.sql $INFONOX_OLD_VBS_SCHEMA_NAME $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

echo "Start - Compiling Invalid Schema Objects: compile_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/compile_schema.sql $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

!echo "Done - Compiled Invalid Schema Objects: compile_schema"

!echo "Start - Comparing Schema Objects: compare_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/COMPARE_VBS.sql $INFONOX_NEW_VBS_SCHEMA_NAME $INFONOX_OLD_VBS_SCHEMA_NAME $defaulttablespace $defaul_temp_tablespace $release_person $release_person_passwd $INFONOX_DB_SERVICENAME $TODAY $SERVICE_LOG_FOLDER_NAME


echo "End - Comparing Schema Objects: compare_schema"

echo -e "==============================================================END OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

done

cd $ver

pass_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_PASSWORDS_`date +%d%m%Y%H%M%S`.txt

cat `ls -atr .*.txt`|grep -v 'Plain'  >$pass_file


mv $pass_file $vbs_logs

cd ../../..

sed -i '/new   1: alter user/d' $logfile

mv $logfile $vbs_logs

cd logs/$TODAY/$SERVICE_LOG_FOLDER_NAME

cmp_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_compare_all_vbs_logs_`date +%d%m%Y%H%M%S`.log

cat `ls -tr COMPARE_VBS_transit*_${ver1}.SQL`|sed -n '/^OBJECT_TYPE/,/SQL>/p'  > $cmp_file

sed -i 's/SQL>/\n/' $cmp_file

mv  $cmp_file  $vbs_logs

echo "Completed VBS Creation....."






















[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat run_dbrelease_vbs_RW.sh





export release_person=ggate
#echo "Enter Password:"
#read -s release_person_passwd

export release_person_passwd=

export INFONOX_DB_SERVICENAME=RW_N1

export backup_directory_name=dbrelease_export
export defaulttablespace=users
export defaul_temp_tablespace=temp
export indextablespace=indx
export SERVICE_LOG_FOLDER_NAME=${INFONOX_DB_SERVICENAME:0:3}
export TODAY=`date +%d_%m_%Y`
mkdir -p logs/$TODAY/$SERVICE_LOG_FOLDER_NAME
ver1=`grep -v '#' config.csv|tail -1|awk -F"," '{print $2}'|awk -F"_" '{print $4}'`
export ver=.pass/$ver1/$SERVICE_LOG_FOLDER_NAME
mkdir -p $ver

vbs_logs=/home/dblogs/Vbs_Logs/${ver1}

mkdir -p $vbs_logs

#exec >${SERVICE_LOG_FOLDER_NAME}_${ver1}_${TODAY}`date +%H%M%S`
export logfile=${SERVICE_LOG_FOLDER_NAME}_${ver1}_complete_logs_`date +%d%m%Y%H%M%S`.log


exec > $logfile 2>&1


for i in `cat config.csv|grep -v '#'`
do

export INFONOX_OLD_VBS_SCHEMA_NAME=`echo $i |awk -F"," '{print $1}'`

export INFONOX_NEW_VBS_SCHEMA_NAME=`echo $i|awk -F"," '{print $2}'`


export export_dump_file_name=exp_${INFONOX_OLD_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`

export import_log_file_name=${INFONOX_NEW_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`.log

echo -e "==============================================================START OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

echo "Starting schema export for user ${INFONOX_OLD_VBS_SCHEMA_NAME}....."

echo ${export_dump_file_name}.dmp

expdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME directory=$backup_directory_name dumpfile=${export_dump_file_name}.dmp logfile=${export_dump_file_name}.log schemas=$INFONOX_OLD_VBS_SCHEMA_NAME GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\"

if [ $? -eq 0 ]
then

        echo "Export Completed for schema $INFONOX_OLD_VBS_SCHEMA_NAME....."
else
        echo ">>>>>>Error while exporting exiting ..."
        mv $logfile $vbs_logs
        exit 1
fi

echo "Starting schema import for  ${INFONOX_NEW_VBS_SCHEMA_NAME}..."

impdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME GRANTS=y  directory=$backup_directory_name  dumpfile=${export_dump_file_name}.dmp logfile=$import_log_file_name  remap_schema=$INFONOX_OLD_VBS_SCHEMA_NAME:$INFONOX_NEW_VBS_SCHEMA_NAME transform=OID:n

echo "Import completed for schema $INFONOX_NEW_VBS_SCHEMA_NAME"

sh  generatepass.sh

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME   @sqlscripts/GRANT_SCRIPT.sql $INFONOX_OLD_VBS_SCHEMA_NAME $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

echo "Start - Compiling Invalid Schema Objects: compile_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/compile_schema.sql $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

!echo "Done - Compiled Invalid Schema Objects: compile_schema"

!echo "Start - Comparing Schema Objects: compare_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/COMPARE_VBS.sql $INFONOX_NEW_VBS_SCHEMA_NAME $INFONOX_OLD_VBS_SCHEMA_NAME $defaulttablespace $defaul_temp_tablespace $release_person $release_person_passwd $INFONOX_DB_SERVICENAME $TODAY $SERVICE_LOG_FOLDER_NAME


echo "End - Comparing Schema Objects: compare_schema"

echo -e "==============================================================END OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

done

cd $ver

pass_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_PASSWORDS_`date +%d%m%Y%H%M%S`.txt

cat `ls -atr .*.txt`|grep -v 'Plain'  >$pass_file


mv $pass_file $vbs_logs

cd ../../..

sed -i '/new   1: alter user/d' $logfile

mv $logfile $vbs_logs

cd logs/$TODAY/$SERVICE_LOG_FOLDER_NAME

cmp_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_compare_all_vbs_logs_`date +%d%m%Y%H%M%S`.log

cat `ls -tr COMPARE_VBS_transit*_${ver1}.SQL`|sed -n '/^OBJECT_TYPE/,/SQL>/p'  > $cmp_file

sed -i 's/SQL>/\n/' $cmp_file

mv  $cmp_file  $vbs_logs

echo "Completed VBS Creation....."






















[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat run_dbrelease_vbs_TE.sh





export release_person=ggate
#echo "Enter Password:"
#read -s release_person_passwd

export release_person_passwd=

export INFONOX_DB_SERVICENAME=TE_N1

export backup_directory_name=dbrelease_export
export defaulttablespace=users
export defaul_temp_tablespace=temp
export indextablespace=indx
export SERVICE_LOG_FOLDER_NAME=${INFONOX_DB_SERVICENAME:0:3}
export TODAY=`date +%d_%m_%Y`
mkdir -p logs/$TODAY/$SERVICE_LOG_FOLDER_NAME
ver1=`grep -v '#' config.csv|tail -1|awk -F"," '{print $2}'|awk -F"_" '{print $4}'`
export ver=.pass/$ver1/$SERVICE_LOG_FOLDER_NAME
mkdir -p $ver

vbs_logs=/home/dblogs/Vbs_Logs/${ver1}

mkdir -p $vbs_logs

#exec >${SERVICE_LOG_FOLDER_NAME}_${ver1}_${TODAY}`date +%H%M%S`
export logfile=${SERVICE_LOG_FOLDER_NAME}_${ver1}_complete_logs_`date +%d%m%Y%H%M%S`.log


exec > $logfile 2>&1


for i in `cat config.csv|grep -v '#'`
do

export INFONOX_OLD_VBS_SCHEMA_NAME=`echo $i |awk -F"," '{print $1}'`

export INFONOX_NEW_VBS_SCHEMA_NAME=`echo $i|awk -F"," '{print $2}'`


export export_dump_file_name=exp_${INFONOX_OLD_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`

export import_log_file_name=${INFONOX_NEW_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`.log

echo -e "==============================================================START OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

echo "Starting schema export for user ${INFONOX_OLD_VBS_SCHEMA_NAME}....."

echo ${export_dump_file_name}.dmp

expdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME directory=$backup_directory_name dumpfile=${export_dump_file_name}.dmp logfile=${export_dump_file_name}.log schemas=$INFONOX_OLD_VBS_SCHEMA_NAME GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\"

if [ $? -eq 0 ]
then

        echo "Export Completed for schema $INFONOX_OLD_VBS_SCHEMA_NAME....."
else
        echo ">>>>>>Error while exporting exiting ..."
        mv $logfile $vbs_logs
        exit 1
fi

echo "Starting schema import for  ${INFONOX_NEW_VBS_SCHEMA_NAME}..."

impdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME GRANTS=y  directory=$backup_directory_name  dumpfile=${export_dump_file_name}.dmp logfile=$import_log_file_name  remap_schema=$INFONOX_OLD_VBS_SCHEMA_NAME:$INFONOX_NEW_VBS_SCHEMA_NAME transform=OID:n

echo "Import completed for schema $INFONOX_NEW_VBS_SCHEMA_NAME"

sh  generatepass.sh

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME   @sqlscripts/GRANT_SCRIPT.sql $INFONOX_OLD_VBS_SCHEMA_NAME $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

echo "Start - Compiling Invalid Schema Objects: compile_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/compile_schema.sql $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

!echo "Done - Compiled Invalid Schema Objects: compile_schema"

!echo "Start - Comparing Schema Objects: compare_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/COMPARE_VBS.sql $INFONOX_NEW_VBS_SCHEMA_NAME $INFONOX_OLD_VBS_SCHEMA_NAME $defaulttablespace $defaul_temp_tablespace $release_person $release_person_passwd $INFONOX_DB_SERVICENAME $TODAY $SERVICE_LOG_FOLDER_NAME


echo "End - Comparing Schema Objects: compare_schema"

echo -e "==============================================================END OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

done

cd $ver

pass_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_PASSWORDS_`date +%d%m%Y%H%M%S`.txt

cat `ls -atr .*.txt`|grep -v 'Plain'  >$pass_file


mv $pass_file $vbs_logs

cd ../../..

sed -i '/new   1: alter user/d' $logfile

mv $logfile $vbs_logs

cd logs/$TODAY/$SERVICE_LOG_FOLDER_NAME

cmp_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_compare_all_vbs_logs_`date +%d%m%Y%H%M%S`.log

cat `ls -tr COMPARE_VBS_transit*_${ver1}.SQL`|sed -n '/^OBJECT_TYPE/,/SQL>/p'  > $cmp_file

sed -i 's/SQL>/\n/' $cmp_file

mv  $cmp_file  $vbs_logs

echo "Completed VBS Creation....."






















[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat run_dbrelease_vbs_TW.sh





export release_person=ggate
#echo "Enter Password:"
#read -s release_person_passwd

export release_person_passwd=

export INFONOX_DB_SERVICENAME=TW_N1

export backup_directory_name=dbrelease_export
export defaulttablespace=users
export defaul_temp_tablespace=temp
export indextablespace=indx
export SERVICE_LOG_FOLDER_NAME=${INFONOX_DB_SERVICENAME:0:3}
export TODAY=`date +%d_%m_%Y`
mkdir -p logs/$TODAY/$SERVICE_LOG_FOLDER_NAME
ver1=`grep -v '#' config.csv|tail -1|awk -F"," '{print $2}'|awk -F"_" '{print $4}'`
export ver=.pass/$ver1/$SERVICE_LOG_FOLDER_NAME
mkdir -p $ver

vbs_logs=/home/dblogs/Vbs_Logs/${ver1}

mkdir -p $vbs_logs

#exec >${SERVICE_LOG_FOLDER_NAME}_${ver1}_${TODAY}`date +%H%M%S`
export logfile=${SERVICE_LOG_FOLDER_NAME}_${ver1}_complete_logs_`date +%d%m%Y%H%M%S`.log


exec > $logfile 2>&1


for i in `cat config.csv|grep -v '#'`
do

export INFONOX_OLD_VBS_SCHEMA_NAME=`echo $i |awk -F"," '{print $1}'`

export INFONOX_NEW_VBS_SCHEMA_NAME=`echo $i|awk -F"," '{print $2}'`


export export_dump_file_name=exp_${INFONOX_OLD_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`

export import_log_file_name=${INFONOX_NEW_VBS_SCHEMA_NAME}`date +%d%m%Y%H%M%S`.log

echo -e "==============================================================START OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

echo "Starting schema export for user ${INFONOX_OLD_VBS_SCHEMA_NAME}....."

echo ${export_dump_file_name}.dmp

expdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME directory=$backup_directory_name dumpfile=${export_dump_file_name}.dmp logfile=${export_dump_file_name}.log schemas=$INFONOX_OLD_VBS_SCHEMA_NAME GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\"

if [ $? -eq 0 ]
then

        echo "Export Completed for schema $INFONOX_OLD_VBS_SCHEMA_NAME....."
else
        echo ">>>>>>Error while exporting exiting ..."
        mv $logfile $vbs_logs
        exit 1
fi

echo "Starting schema import for  ${INFONOX_NEW_VBS_SCHEMA_NAME}..."

impdp $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME GRANTS=y  directory=$backup_directory_name  dumpfile=${export_dump_file_name}.dmp logfile=$import_log_file_name  remap_schema=$INFONOX_OLD_VBS_SCHEMA_NAME:$INFONOX_NEW_VBS_SCHEMA_NAME transform=OID:n

echo "Import completed for schema $INFONOX_NEW_VBS_SCHEMA_NAME"

sh  generatepass.sh

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME   @sqlscripts/GRANT_SCRIPT.sql $INFONOX_OLD_VBS_SCHEMA_NAME $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

echo "Start - Compiling Invalid Schema Objects: compile_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/compile_schema.sql $INFONOX_NEW_VBS_SCHEMA_NAME $TODAY $SERVICE_LOG_FOLDER_NAME

!echo "Done - Compiled Invalid Schema Objects: compile_schema"

!echo "Start - Comparing Schema Objects: compare_schema"

sqlplus  $release_person/$release_person_passwd@$INFONOX_DB_SERVICENAME @sqlscripts/COMPARE_VBS.sql $INFONOX_NEW_VBS_SCHEMA_NAME $INFONOX_OLD_VBS_SCHEMA_NAME $defaulttablespace $defaul_temp_tablespace $release_person $release_person_passwd $INFONOX_DB_SERVICENAME $TODAY $SERVICE_LOG_FOLDER_NAME


echo "End - Comparing Schema Objects: compare_schema"

echo -e "==============================================================END OF VBS CREATION:${INFONOX_NEW_VBS_SCHEMA_NAME}======================================================================================\n"

done

cd $ver

pass_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_PASSWORDS_`date +%d%m%Y%H%M%S`.txt

cat `ls -atr .*.txt`|grep -v 'Plain'  >$pass_file


mv $pass_file $vbs_logs

cd ../../..

sed -i '/new   1: alter user/d' $logfile

mv $logfile $vbs_logs

cd logs/$TODAY/$SERVICE_LOG_FOLDER_NAME

cmp_file=${SERVICE_LOG_FOLDER_NAME}_${ver1}_compare_all_vbs_logs_`date +%d%m%Y%H%M%S`.log

cat `ls -tr COMPARE_VBS_transit*_${ver1}.SQL`|sed -n '/^OBJECT_TYPE/,/SQL>/p'  > $cmp_file

sed -i 's/SQL>/\n/' $cmp_file

mv  $cmp_file  $vbs_logs

echo "Completed VBS Creation....."






















[oracle@wdl2tsyssvs04 VBS_CREATION]$




[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat config.csv
#############################################################################################
#Please follow sequence of Components while creating vbs                                    #
#1.Gateway                                                                                  #
#2.FE                                                                                       #
#3.SMSNOX                                                                                   #
#Configuration values are separated by comma[,]                                             #
#The first fild is old vbs name from which New vbs is to be created                         #
#Second Field is New vbs Name                                                               #
#vbs_from_which_to_create_new,New_vbs_name                                                  #
#############################################################################################
transit_gateway_tnox_3124,transit_gateway_tnox_3125
transit_gateway_snox_3124,transit_gateway_snox_3125
transit_fe_tnox_3124,transit_fe_tnox_3125
transit_fe_snox_3124,transit_fe_snox_3125
transit_smsnox_tnox_3124,transit_smsnox_tnox_3125
transit_smsnox_snox_3124,transit_smsnox_snox_3125
[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat env_config.csv
DEVRACDB,yes
REGRACDB,yes
QARACDB,no
UAT_NODE_PUB,no
LOADTXNDCE,NO
[oracle@wdl2tsyssvs04 VBS_CREATION]$ cat KeyPassword.txt
Encrypt Password = 747C8E48CB5A294EDD415BECEDF3A5B4CA1C243A800732D2807200C421E8DB43

--- Hibernate Key and Password
Key = 79CDD023C48C58E9
Password = 2B42CE6C40578B8A60ACE5C324B8F8A9492573DA0E6B20EFF772346A5DBE934D
[oracle@wdl2tsyssvs04 VBS_CREATION]$
