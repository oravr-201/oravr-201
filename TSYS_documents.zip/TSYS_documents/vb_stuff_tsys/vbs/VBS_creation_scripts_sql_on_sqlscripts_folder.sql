[oracle@wdl2tsyssvs04 sqlscripts]$ cat set_password.sql
SET SERVEROUTPUT OFF

prompt Setting Password START

                prompt -----------------------------------------------------------------------------------

                SET HEADING OFF

                SET FEEDBACK OFF

                SET LINESIZE 1000

                SET PAGESIZE 20

                SPOOL logs/&3/&4/set_password_&1..SQL


alter user &1 IDENTIFIED BY &2;

prompt Setting Password END

SPOOL OFF
exit
[oracle@wdl2tsyssvs04 sqlscripts]$ cat .GRANT_SCRIPT.sql.swp
b0VIM 7.0
33210#"! Utp▒wadB2w▒▒▒▒]\=<▒▒▒▒▒▒▒cb@:1▒racle/VBS_CREATION/sqlscripts/GRANT_SCRIPT.sqlutf-8
▒
▒
▒
▒
v
k
4
#
▒
 ▒
  ▒
   p
    W
     F
      >
       =
        <

         ▒
▒
▒
▒
▒
▒
▒
n
`
=

▒       ▒       ▒       ▒       ▒       ▒       ▒       r       m       k       j       `       [       '       &              ▒▒▒▒`S:/▒▒▒▒▒eM4
▒▒▒▒▒XH32         WHEN OTHERS      EXCEPTION     DBMS_OUTPUT.PUT_LINE (typ_grts_str (rc));         EXECUTE IMMEDIATE typ_grts_str (rc);      BEGIN   LOOP   FOR rc IN typ_grts_str.FIRST .. typ_grts_str.LAST   END;         RETURN;            || SQLERRM);            || '       '            || CHR (13)               'Following error Occured while creating grant script'         DBMS_OUTPUT.PUT_LINE (      THEN      WHEN OTHERS         RETURN;         DBMS_OUTPUT.PUT_LINE ('NO Grants are Found');      THEN      WHEN NO_DATA_FOUND   EXCEPTION      GROUP BY OWNER, TABLE_NAME, GRANTEE;         WHERE GRANTEE = UPPER ('&1')          FROM DBA_TAB_PRIVS          BULK COLLECT INTO typ_grts_str               || '&2 '               || ' TO '               || TABLE_NAME               || '.'               || OWNER               || ' ON '               || LISTAGG (privilege, ',') WITHIN GROUP (ORDER BY TABLE_NAME)        SELECT    'GRANT '   BEGINBEGIN   typ_grts_str   TYP_GRANTS_STR;   TYPE TYP_GRANTS_STR IS TABLE OF VARCHAR2 (2000);LARESPOOL OFF/END;      DBMS_OUTPUT.PUT_LINE (SQLERRM);   THEN   WHEN OTHERSEXCEPTION   DBMS_OUTPUT.PUT_LINE ('Grants are given');   END LOOP;      END;               'Error while executing grants  ' || SQLERRM);            DBMS_OUTPUT.PUT_LINE (         THEN         WHEN OTHERS      EXCEPTION     DBMS_OUTPUT.PUT_LINE (typ_grts_str (rc));          EXECUTE IMMEDIATE typ_grts_str (rc);      BEGIN   LOOP   FOR rc IN typ_grts_str.FIRST .. typ_grts_str.LAST   END;         RETURN;            || SQLERRM);            || '       '            || CHR (13)               'Following error Occured while creating grant script'         DBMS_OUTPUT.PUT_LINE (      THEN      WHEN OTHERS         RETURN;         DBMS_OUTPUT.PUT_LINE ('NO Grants are Found');      THEN      WHEN NO_DATA_FOUND   EXCEPTION      GROUP BY OWNER, TABLE_NAME, GRANTEE;         WHERE GRANTEE = UPPER ('&1')          FROM DBA_TAB_PRIVS          BULK COLLECT INTO typ_grts_str               || '&2 '               || ' TO '               || TABLE_NAME               || '.'               || OWNER               || ' ON '               || LISTAGG (privilege, ',') WITHIN GROUP (ORDER BY TABLE_NAME)        SELECT    'GRANT '   BEGINBEGIN   typ_grts_str   TYP_GRANTS_STR;   TYPE TYP_GRANTS_STR IS TABLE OF VARCHAR2 (2000);DECLARE                SPOOL logs/&3/&4/GRANT_VBS_&1..SQL             SET PAGESIZE 20                                SET LINESIZE 1000                SET FEEDBACK OFF                SET HEADING ON                prompt -----------------------------------------------------------------------------------prompt GRANT TO VBS OBJECTS STARTSET SERVEROUTPUT ON[oracle@wdl2tsyssvs04 sqlscripts]$ cat GRANT_SCRIPT.sql

SET SERVEROUTPUT ON
prompt GRANT TO VBS OBJECTS START

                prompt -----------------------------------------------------------------------------------

                SET HEADING ON

                SET FEEDBACK OFF

                SET LINESIZE 1000

                SET PAGESIZE 20

                SPOOL logs/&3/&4/GRANT_VBS_&1..SQL


DECLARE
   TYPE TYP_GRANTS_STR IS TABLE OF VARCHAR2 (2000);

   typ_grts_str   TYP_GRANTS_STR;
BEGIN
   BEGIN
        SELECT    'GRANT '
               || LISTAGG (privilege, ',') WITHIN GROUP (ORDER BY TABLE_NAME)
               || ' ON '
               || OWNER
               || '.'
               || TABLE_NAME
               || ' TO '
               || '&2 '
          BULK COLLECT INTO typ_grts_str
          FROM DBA_TAB_PRIVS
         WHERE GRANTEE = UPPER ('&1')
      GROUP BY OWNER, TABLE_NAME, GRANTEE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         DBMS_OUTPUT.PUT_LINE ('NO Grants are Found');
         RETURN;
      WHEN OTHERS
      THEN
         DBMS_OUTPUT.PUT_LINE (
               'Following error Occured while creating grant script'
            || CHR (13)
            || '       '
            || SQLERRM);
         RETURN;
   END;


   FOR rc IN typ_grts_str.FIRST .. typ_grts_str.LAST
   LOOP
      BEGIN

         EXECUTE IMMEDIATE typ_grts_str (rc);

     DBMS_OUTPUT.PUT_LINE (typ_grts_str (rc));
      EXCEPTION
         WHEN OTHERS
         THEN
            DBMS_OUTPUT.PUT_LINE (
               'Error while executing grants  ' || SQLERRM);
      END;
   END LOOP;

   DBMS_OUTPUT.PUT_LINE ('Grants are given');
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
END;
/

SPOOL OFF
exit
[oracle@wdl2tsyssvs04 sqlscripts]$ cat CREATE_NEW_VBS_SCHEMA.SQL
SPOOL logs/&9/&10/VBS_CREATION_&1._1.log

--1 %INFONOX_NEW_VBS_SCHEMA_NAME%
--2 %INFONOX_NEW_VBS_SCHEMA_PWD%
--3 %INFONOX_OLD_VBS_SCHEMA_NAME%
--4 %DEFAULTTABLESPACE%
--5 %DEFAUL_TEMP_TABLESPACE%
--6 %RELEASE_PERSON%
--7 %RELEASE_PERSON_PASSWD%
--8 %INFONOX_DB_SERVICENAME%

SHOW USER
--set echo on
  SELECT SUBSTR(GLOBAL_NAME,1,30) SERVER FROM GLOBAL_NAME;

    CREATE USER &1 IDENTIFIED BY &2 DEFAULT TABLESPACE &4 TEMPORARY TABLESPACE &5 PROFILE APPUSERS;
    GRANT CREATE SESSION, RESOURCE, CREATE ANY TABLE TO &1 ;


    -- host exp &6/&7@&8 file=dumps/exp_vbs_dump_&1..dmp log=dumps/exp_vbs_log_&1..log statistics=none OWNER=&3


  --  host expdp &6/&7@&8 schemas=&3 directory=dbrelease_export dumpfile=exp_vbs_dump_&1..dmp logfile=exp_vbs_log_&1..logi

    host expdp &6/&7@&8  directory=dbrelease_export dumpfile=exp_vbs_dump_&1..dmp logfile=exp_vbs_log_&1..log schemas=&3 exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\" reuse_dumpfiles=y compression=all

exit
    prompt -----------------------------------------------------------------------------------

    PROMPT export done.

    prompt -----------------------------------------------------------------------------------

    prompt -----------------------------------------------------------------------------------

    prompt GRANTS SCRIPT PREPARATION

    prompt -----------------------------------------------------------------------------------

    SET HEADING OFF

    SET FEEDBACK OFF

    SET LINESIZE 1000

    SPOOL logs/&9/&10/GRANT_SCRIPT_&1..SQL

    SELECT 'GRANT ' || privilege || ' on ' || OWNER || '.' || table_name || ' to ' || '&1' || ' ;' from DBA_TAB_PRIVS WHERE  GRANTEE = UPPER( '&3' ) ;

    SET HEADING ON

    SET FEEDBACK ON

    SPOOL logs/&9/&10/VBS_CREATION_&1._2.log

    prompt --------------------------------------------------------------------------------------------------------------------------------

    prompt MOHTER SCHEMA OBJECT PRIVILAGES TO NEW VBS SCHEMA - START

    prompt ---------------------------------------------------------------------------------------------------------------------------------

   @logs/&9/&10/GRANT_SCRIPT_&1..SQL

    prompt --------------------------------------------------------------------------------------------------------------------------------

    prompt MOHTER SCHEMA OBJECT PRIVILAGES TO NEW VBS SCHEMA - DONE

    prompt ---------------------------------------------------------------------------------------------------------------------------------

    prompt --------------------------------------------------------------------------------------------------------------------------------

    PROMPT IMPORT STARTED

    --host imp &6/&7@&8 file=dumps/exp_vbs_dump_&1..dmp log=dumps/imp_vbs_log_&1..log fromuser=&3 touser=&1 ignore=y grants=n
    host impdp &6/&7@&8  directory=dbrelease_export  dumpfile=exp_vbs_dump_&1..dmp logfile=imp_vbs_log_&1..log schemas=&3 remap_schema=&3:&1

   prompt -----------------------------------------------------------------------------------

    PROMPT IMPORT DONE

    prompt -----------------------------------------------------------------------------------
 SPOOL OFF

[oracle@wdl2tsyssvs04 sqlscripts]$ cat CREATE_MISSING_OBJECTS.sql
--SPOOL logs/CREATE_MISSING_OBJECTS_&1._1.log

--1 %INFONOX_NEW_VBS_SCHEMA_NAME%
--2 %INFONOX_NEW_VBS_SCHEMA_PWD%
--3 %INFONOX_OLD_VBS_SCHEMA_NAME%
--4 %DEFAULTTABLESPACE%
--5 %DEFAUL_TEMP_TABLESPACE%
--6 %RELEASE_PERSON%
--7 %RELEASE_PERSON_PASSWD%
--8 %INFONOX_DB_SERVICENAME%

SPOOL logs/&3/&4/CREATE_MISSING_OBJECTS_&1..log

SHOW USER
  SELECT SUBSTR(GLOBAL_NAME,1,30) SERVER FROM GLOBAL_NAME;

    prompt -----------------------------------------------------------------------------------

    prompt CREATE MISSING OBJECTS START

    prompt -----------------------------------------------------------------------------------

    SET HEADING ON

    SET FEEDBACK OFF

    SET LINESIZE 1000

    SET SERVEROUTPUT ON FORMAT WRAPPED

    SET VERIFY OFF

    SET SQLPROMPT ""



    SPOOL logs/&3/&4/CREATE_MISSING_OBJECTS_&1..SQL

DECLARE

      TYPE compare_objects IS RECORD
      (
         obj_type           VARCHAR2(30),
         new_schema      NUMBER,
         old_schema        NUMBER
      ) ;

    TYPE cmp_obj IS TABLE OF compare_objects ;

    TYPE typ_char IS TABLE OF VARCHAR2(30) ;

    typ_compare_objects  cmp_obj  ;
    typ_chr                     typ_char                    ;
    lc_ddl_query              VARCHAR2(32000) ;

BEGIN


                       SELECT REPLACE(OBJECT_TYPE,' ','_') OBJECT_TYPE ,
                               MAX(DECODE(VBS_NAME,'&1',CNT)) &1,
                               MAX(DECODE(VBS_NAME,'&2',CNT)) &2
                               BULK COLLECT INTO typ_compare_objects
                       FROM (
                           SELECT '&2' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
                           FROM DBA_OBJECTS
                           WHERE OWNER=UPPER('&2')
                           GROUP BY OBJECT_TYPE,STATUS
                              UNION ALL
                           SELECT '&1' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
                           FROM DBA_OBJECTS
                           WHERE OWNER=UPPER('&1')
                           GROUP BY OBJECT_TYPE,STATUS
                            )
                       GROUP BY OBJECT_TYPE,STATUS
                       ORDER BY 1;

                       BEGIN
                         DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'SQLTERMINATOR', true);
                         DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'PRETTY', false);
                         DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'SEGMENT_ATTRIBUTES', false);
                         DBMS_METADATA.set_transform_param (DBMS_METADATA.session_transform, 'STORAGE', false);
                       END ;

         FOR rc_cmp IN typ_compare_objects.first ..typ_compare_objects.last LOOP

                IF typ_compare_objects(rc_cmp).new_schema IS NULL AND typ_compare_objects(rc_cmp).old_schema IS NOT NULL  THEN

                  BEGIN

                    SELECT object_name BULK COLLECT INTO typ_chr FROM dba_objects WHERE owner = '&2' AND object_type =  REPLACE(typ_compare_objects(rc_cmp).obj_type,'_',' ') ;

                   FOR typ IN typ_chr.FIRST..typ_chr.LAST LOOP

                         lc_ddl_query := DBMS_METADATA.get_ddl(typ_compare_objects(rc_cmp).obj_type,typ_chr(typ),'&2');

                         lc_ddl_query := REPLACE(REPLACE(lc_ddl_query,'"&2"','"&1"'),'"',null) ;

                  DBMS_OUTPUT.put_line('SET FEEDBACK ON'||CHR(13)||CHR(13)||lc_ddl_query||CHR(13)||CHR(13)||'SET FEEDBACK OFF') ;
                 END LOOP ;
                EXCEPTION
                  WHEN OTHERS THEN
                    DBMS_OUTPUT.put_line('-- This Database Object / Type  Not Created =====  '||typ_compare_objects(rc_cmp).obj_type) ;
                  END ;

              END IF ;
        END LOOP  ;
EXCEPTION
      WHEN OTHERS THEN
         DBMS_OUTPUT.put_line(sqlerrm) ;
END ;

/
    SPOOL logs/&3/&4/CREATE_MISSING_OBJECTS_&1..log APPEND

  --  prompt ---------------------------------------------------------------------------------------------------------------------------------

    @logs/&3/&4/CREATE_MISSING_OBJECTS_&1..SQL

   -- prompt --------------------------------------------------------------------------------------------------------------------------------

    prompt CREATING MISSING OBJECT - DONE


SPOOL OFF

 SET HEADING ON

 SET FEEDBACK ON

 SET ECHO ON

-- SET SQLPROMPT "SQL>"


[oracle@wdl2tsyssvs04 sqlscripts]$ cat compile_schema.sql
SPOOL logs/&2/&3/compile_schema_&1..log

SHOW USER
PROMPT
SELECT TO_CHAR(SYSDATE, 'MM/DD/YYYY HH24:MI:SS') Release_Date FROM DUAL;
PROMPT

EXEC DBMS_UTILITY.COMPILE_SCHEMA( UPPER('&1'),FALSE);

--SELECT 'ALTER '||OBJECT_TYPE||' '||OBJECT_NAME||' COMPILE;' FROM DBA_OBJECTS WHERE STATUS = 'INVALID' AND OWNER= UPPER('&1')
/

SPOOL OFF
exit
[oracle@wdl2tsyssvs04 sqlscripts]$ cat COMPARE_VBS.sql
--SPOOL logs/COMPARE_VBS_&1._1.log

--1 %INFONOX_NEW_VBS_SCHEMA_NAME%
--2 %INFONOX_NEW_VBS_SCHEMA_PWD%
--3 %INFONOX_OLD_VBS_SCHEMA_NAME%
--4 %DEFAULTTABLESPACE%
--5 %DEFAUL_TEMP_TABLESPACE%
--6 %RELEASE_PERSON%
--7 %RELEASE_PERSON_PASSWD%
--8 %INFONOX_DB_SERVICENAME%

SHOW USER
  SELECT SUBSTR(GLOBAL_NAME,1,30) SERVER FROM GLOBAL_NAME;

                prompt -----------------------------------------------------------------------------------

                prompt COMPARE VBS START

                prompt -----------------------------------------------------------------------------------

                SET HEADING ON

                SET FEEDBACK OFF

                SET LINESIZE 1000
                SET PAGESIZE 20

                SPOOL logs/&8/&9/COMPARE_VBS_&1..SQL

                SELECT OBJECT_TYPE,STATUS,
                        MAX(DECODE(VBS_NAME,'&1',CNT)) &1,
                        MAX(DECODE(VBS_NAME,'&2',CNT)) &2
                FROM (
                        SELECT '&2' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
                        FROM DBA_OBJECTS
                        WHERE OWNER=UPPER('&2')
                        GROUP BY OBJECT_TYPE,STATUS
                       UNION ALL
                        SELECT '&1' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
                        FROM DBA_OBJECTS
                        WHERE OWNER=UPPER('&1')
                        GROUP BY OBJECT_TYPE,STATUS
                     )
                GROUP BY OBJECT_TYPE,STATUS
                ORDER BY 1;
                prompt -----------------------------------------------------------------------------------


                SET HEADING ON

                SET FEEDBACK ON

                SET ECHO ON

                prompt ---------------------------------------------------------------------------------------------------------------------------------

                --@logs/&8/&9/COMPARE_VBS_&1..SQL

                prompt --------------------------------------------------------------------------------------------------------------------------------

                prompt COMPARE VBS - DONE


 SPOOL OFF

exit
[oracle@wdl2tsyssvs04 sqlscripts]$ PuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTY
bash: PuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTYPuTTY: command not found...
[oracle@wdl2tsyssvs04 sqlscripts]$
