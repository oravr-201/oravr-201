Hi Vishal,

As discussed, please follow below steps for this activity.

GGSCI (wpl1trandbtxn1.tsysacquiring.org) 7> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTW        00:00:03      00:00:00
EXTRACT     STOPPED     PPTWRE      00:00:04      00:00:21
EXTRACT     RUNNING     PPTWRW      00:00:04      00:00:04
EXTRACT     STOPPED     PPTWTE      00:00:04      00:00:12
REPLICAT    STOPPED     RPTWTE01    00:00:00      00:00:04
REPLICAT    STOPPED     RPTWTELG    00:00:00      00:00:03


GGSCI (wpl1trandbtxn1.tsysacquiring.org) 8>
-----------------------------------------------------------------------------------------------
GGSCI (wpl1trandbrpt1.tsysacquiring.org) 7> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRW        00:00:01      00:00:08
EXTRACT     STOPPED     PPRWRE      00:00:00      00:00:21
REPLICAT    STOPPED     RPRWRE      00:00:00      00:00:13
REPLICAT    STOPPED     RPRWTE01    00:00:00      00:00:04
REPLICAT    STOPPED     RPRWTELG    00:00:00      00:00:04
REPLICAT    RUNNING     RPRWTW01    00:00:00      00:00:00
REPLICAT    RUNNING     RPRWTWLG    00:00:00      00:00:00


GGSCI (wpl1trandbrpt1.tsysacquiring.org) 8>

-----------------------------------------------------------------------------------------------
GGSCI (epl1trandbtxn1.tsysacquiring.org) 5> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTE        00:00:00      00:00:05
EXTRACT     STOPPED     PPTERE      00:00:00      00:00:04
EXTRACT     STOPPED     PPTERW      00:00:00      00:00:03
EXTRACT     STOPPED     PPTETW      00:00:00      00:00:03
REPLICAT    STOPPED     RPTETW01    00:00:00      00:00:09
REPLICAT    STOPPED     RPTETWLG    00:00:00      00:00:09


GGSCI (epl1trandbtxn1.tsysacquiring.org) 6>

-----------------------------------------------------------------------------------------------
GGSCI (epl1trandbrpt1.tsysacquiring.org) 12> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     STOPPED
JAGENT      STOPPED
EXTRACT     STOPPED     EPRE        00:00:02      00:00:39
EXTRACT     STOPPED     PPRERW      00:00:00      00:00:44
REPLICAT    STOPPED     RPRERW      00:00:00      00:00:52
REPLICAT    STOPPED     RPRETE01    00:00:00      00:00:52
REPLICAT    STOPPED     RPRETELG    00:00:00      00:00:50
REPLICAT    STOPPED     RPRETW01    00:00:00      00:00:49
REPLICAT    STOPPED     RPRETWLG    00:00:00      00:00:49


GGSCI (epl1trandbrpt1.tsysacquiring.org) 13> Killed
[stujare@epl1trandbrpt1 ~]$

-----------------------------------------------------------------------------------------------
[ORACLE]

            xag.gg_erpt.goldengate
                  1        ONLINE  ONLINE       epl1trandbrpt3
            epl1trandbrpt1.tsysacquiring.org:/home/oracle>

            xag.gg_erpt.goldengate
                  1        OFFLINE OFFLINE
            epl1trandbrpt1.tsysacquiring.org:/home/oracle>


/opt/app/oracle/xag/bin/agctl stop goldengate gg_erpt
-----------------------------------------------------------------------------------------------


[ROOT]
cd /opt/app/11.2.0/grid_1/bin/
./crsctl stop cluster -n epl1trandbrpt1

 ./crsctl stop cluster -n epl1trandbrpt2

 ./crsctl stop cluster -n epl1trandbrpt3
-----------------------------------------------------------------------------------------------

[ORACLE]
/opt/app/oracle/xag/bin/agctl start goldengate gg_erpt 
-----------------------------------------------------------------------------------------------

GGSCI (epl1trandbrpt1.tsysacquiring.org) 13> start mgr

GGSCI (epl1trandbrpt1.tsysacquiring.org) 13> start jagent

GGSCI (epl1trandbrpt1.tsysacquiring.org) 13> start ep*

GGSCI (epl1trandbrpt1.tsysacquiring.org) 13> start pp*
--===================================================================================
GGSCI (epl1trandbrpt1.tsysacquiring.org) 13> start rp*


-----------------------------------------------------------------------------------------------

GGSCI (epl1trandbtxn1.tsysacquiring.org) 5> stop ep*
GGSCI (epl1trandbtxn1.tsysacquiring.org) 5> stop jagent
GGSCI (epl1trandbtxn1.tsysacquiring.org) 5> stop mgr

opt/app/oracle/xag/bin/agctl stop goldengate gg_etxn


root-
cd /opt/app/11.2.0/grid_1/bin/
 /opt/app/11.2.0/grid_1/bin/./crsctl stop cluster -n epl1trandbtxn1
epl1trandbtxn1.tsysacquiring.org
 ./crsctl stop cluster -n epl1trandbtxn2

 ./crsctl stop cluster -n epl1trandbtxn3

/opt/app/oracle/xag/bin/agctl start goldengate gg_etxn

TE-
            START MGR
            START JAGENT
            START EP*
            START PP*
            START RP*

RE- 
            

TW- 
            START PP*
            START RP*

RW-
            START PP*
            START RP*
            


Thank You !

Regards,
Sandip Tujare 
Oracle Database Administrator Specialist,
Global Technology Services, Merchant,

+91.20.4103.6764 Office,
+91.841.197.3965 Work,
stujare@tsys.com

