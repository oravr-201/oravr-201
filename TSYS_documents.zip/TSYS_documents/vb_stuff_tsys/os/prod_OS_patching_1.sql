DCE


--TXN: TE 

GGSCI (epl1trandbtxn1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTE        00:00:01      00:00:01
EXTRACT     RUNNING     PPTERE      00:00:00      00:00:02	--RE
EXTRACT     RUNNING     PPTERW      00:00:00      00:00:04	--RW
EXTRACT     RUNNING     PPTETW      00:00:00      00:00:10	--TW
REPLICAT    RUNNING     RPTETW01    00:00:00      00:00:00	--TW
REPLICAT    RUNNING     RPTETWLG    00:00:00      00:00:00	--TW


--RPT: RE
GGSCI (epl1trandbrpt1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRE        00:00:02      00:00:05
EXTRACT     RUNNING     PPRERW      00:00:00      00:00:06		--RW
REPLICAT    RUNNING     RPRERW      00:00:00      00:00:06		--RW
REPLICAT    RUNNING     RPRETE01    00:00:00      00:00:01		--TE
REPLICAT    RUNNING     RPRETELG    00:00:00      00:00:01		--TE
REPLICAT    RUNNING     RPRETW01    00:00:00      00:00:00		--TW
REPLICAT    RUNNING     RPRETWLG    00:00:00      00:00:00		--TW






--------------------------------------------------


DCW 

--TXN:

GGSCI (wpl1trandbtxn1.tsysacquiring.org) 1> nfo all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPTW        00:00:02      00:00:10
EXTRACT     RUNNING     PPTWRE      00:00:03      00:00:03		--RE
EXTRACT     RUNNING     PPTWRW      00:00:03      00:00:09		--RW
EXTRACT     RUNNING     PPTWTE      00:00:03      00:00:00		--TE
REPLICAT    RUNNING     RPTWTE01    00:00:00      00:00:01		--TE
REPLICAT    RUNNING     RPTWTELG    00:00:00      00:00:01		--TE


--RPT:

GGSCI (wpl1trandbrpt1.tsysacquiring.org) 1> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     RUNNING     EPRW        00:00:01      00:00:06
EXTRACT     RUNNING     PPRWRE      00:00:00      00:00:05		--RE
REPLICAT    RUNNING     RPRWRE      00:00:00      00:00:09		--RE
REPLICAT    RUNNING     RPRWTE01    00:00:00      00:00:01		--TE
REPLICAT    RUNNING     RPRWTELG    00:00:00      00:00:01		--TE
REPLICAT    RUNNING     RPRWTW01    00:00:00      00:00:01		--TW
REPLICAT    RUNNING     RPRWTWLG    00:00:00      00:00:00		--TW



