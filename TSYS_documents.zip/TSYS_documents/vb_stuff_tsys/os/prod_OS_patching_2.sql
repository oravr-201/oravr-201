========================================================================================================

Patch on east DC txn database :

	1. All Goldengate process are down  TE
		Stop rp*
		stop pp*
		stop ep*
		stop jagent
		stop mgr!
		
		Other DC GG process need to stop :
		1. RE :  RPRETE01,RPRETELG
		2. RW :  RPRWTE01,RPRWTELG
		3. TW :  PPTWTE,RPTWTE01,RPTWTELG
	
	2. start all GG process on east DC txn 
		start mgr
		start jagent
		start ep*
		start pp*
		start rp*
		
		Other DC GG process need to start :
		1. RE :  RPRETE01,RPRETELG
		2. RW :  RPRWTE01,RPRWTELG
		3. TW :  PPTWTE,RPTWTE01,RPTWTELG
	
	
	--wait for lag resolution :
========================================================================================================

Patch on east DC rpt database :

	1. All Goldengate process are down RE
		Stop rp*
		stop pp*
		stop ep*
		stop jagent
		stop mgr!
		
		Other DC GG process need to stop :
		1. TE :  PPTERE
		2. RW :  PPRWRE,RPRWRE
		3. TW :  PPTWRE
	
	2. start all GG process on east DC RPT 
		start mgr
		start jagent
		start ep*
		start pp*
		start rp*
		
		Other DC GG process need to START :
		1. TE :  PPTERE
		2. RW :  PPRWRE,RPRWRE
		3. TW :  PPTWRE
		
--wait for lag resolution :
========================================================================================================






























========================================================================================================

Patch on WEST DC txn database :

	1. All Goldengate process are down  TE
		Stop rp*
		stop pp*
		stop ep*
		stop jagent
		stop mgr!
		
		Other DC GG process need to stop :
		1. RE :  RPRETW01,RPRETWLG
		2. RW :  RPRWTW01,RPRWTWLG
		3. TE :  PPTETW,RPTETW01,RPTETWLG
	
	2. start all GG process on east DC txn 
		start mgr
		start jagent
		start ep*
		start pp*
		start rp*
		
		Other DC GG process need to start :
		1. RE :  RPRETW01,RPRETWLG
		2. RW :  RPRWTW01,RPRWTWLG
		3. TE :  PPTETW,RPTETW01,RPTETWLG
	
	--wait for lag resolution :
========================================================================================================

Patch on WEST DC rpt database :

	1. All Goldengate process are down RE
		Stop rp*
		stop pp*
		stop ep*
		stop jagent
		stop mgr!
		
		Other DC GG process need to stop :
		1. TE :  PPTERW
		2. RE :  PPRERW,RPRERW
		3. TW :  PPTWRW
	
	2. start all GG process on east DC RPT 
		start mgr
		start jagent
		start ep*
		start pp*
		start rp*
		
		Other DC GG process need to stop :
		1. TE :  PPTERW
		2. RE :  PPRERW,RPRERW
		3. TW :  PPTWRW
		
--wait for lag resolution :
========================================================================================================
