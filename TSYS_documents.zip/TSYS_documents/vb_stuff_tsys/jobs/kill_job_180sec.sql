--kill job 
BEGIN
TRANSITHA.KILL_REPORT_SESSION;
END; 





CREATE OR REPLACE PROCEDURE TRANSITHA.KILL_REPORT_SESSION
IS
   tmpVar         NUMBER;
   v_start_time   VARCHAR2 (20);

   CURSOR c_killsession
   IS
      SELECT    'Alter System kill session '''
             || SID
             || ','
             || SERIAL#
             || ',@'
             || inst_id
             || ''' immediate'
                stmt
        FROM (SELECT username,
                     SID,
                     SERIAL#,
                     s.INST_ID,
                     ROUND (sofar / totalwork * 100, 2) "% Complete",
                     a.sql_text
                FROM gv$session_longops s, gv$sqltext A
               WHERE     s.sql_hash_value = a.hash_value
                     AND elapsed_seconds > 210
                     AND s.username IN ( SELECT USERNAME FROM DBA_USERS WHERE (USERNAME LIKE 'TRANSIT_GATEWAY_TNOX%' OR USERNAME LIKE 'TRANSIT_FE_TNOX%'))
                     AND UPPER (a.sql_text) LIKE '%CREATE TABLE SN_TEM%')
       WHERE "% Complete" != 100;
BEGIN
   tmpVar := 0;

   SELECT TO_CHAR (SYSDATE, 'MMDDYYYY HH24miss') INTO v_start_time FROM DUAL;

   INSERT INTO transitha.kill_report_session_hist (USERNAME,
                                                   SID,
                                                   SERIAL#,
                                                   INST_ID,
                                                   START_TIME,
                                                   LAST_UPDATE_TIME,
                                                   TIMESTAMP,
                                                   TIME_REMAINING,
                                                   "% Complete",
                                                   SQL_TEXT)
      SELECT USERNAME,
             SID,
             SERIAL#,
             INST_ID,
             START_TIME,
             LAST_UPDATE_TIME,
             TIMESTAMP,
             TIME_REMAINING,
             "% Complete",
             SQL_TEXT
        FROM (SELECT username,
                     SID,
                     SERIAL#,
                     s.INST_ID,
                     START_TIME,
                     LAST_UPDATE_TIME,
                     TIMESTAMP,
                     TIME_REMAINING,
                     ROUND (sofar / totalwork * 100, 2) "% Complete",
                     a.sql_text
                FROM gv$session_longops s, gv$sqltext A
               WHERE     s.sql_hash_value = a.hash_value
                     AND elapsed_seconds > 210
                     AND UPPER (a.sql_text) LIKE '%CREATE TABLE SN_TEM%')
       WHERE "% Complete" != 100;

   COMMIT;


   BEGIN
      FOR j IN c_killsession
      LOOP
         BEGIN
            EXECUTE IMMEDIATE j.stmt;

            tmpVar := tmpVar + 1;
         EXCEPTION
            WHEN OTHERS
            THEN
               NULL;
         END;
      END LOOP;
   END;

   INSERT INTO KILL_SESSION_LOG (START_TIME, END_TIME, COUNT1)
        VALUES (V_START_TIME, TO_CHAR (SYSDATE, 'MMDDYYYY HH24miss'), TMPVAR);

   COMMIT;
EXCEPTION
   WHEN OTHERS
   THEN
      NULL;
END KILL_REPORT_SESSION;
/













-- old one 


CREATE OR REPLACE PROCEDURE TRANSITHA.kill_all_session 
IS
   tmpVar   NUMBER;
 v_start_time VARCHAR2(20);

   CURSOR c_killsession
   IS
        SELECT    'Alter System kill session '''
               || SID
               || ','
               || SERIAL#
               || ',@'
               || inst_id
               || ''' immediate'
                  stmt
          FROM gv$SESSION s
         WHERE     s.username IN ( 'TRANSIT_FE_TNOX_3122','TRANSIT_GATEWAY_TNOX_3122')
-- '%GATEWAY%'
         AND s.status = 'ACTIVE'
         AND s.last_call_et > (5*60);

BEGIN
   tmpVar := 0;
   SELECT TO_CHAR(SYSDATE,'MMDDYYYY HH24miss') INTO v_start_time FROM dual;
   
   INSERT INTO transitha.sessiondtl (TIMESTAMP  , user_name  , machine_name  )
SELECT TO_CHAR(SYSDATE,'MMDDYYYY HH24miss'),  s.schemaname, s.machine
            FROM gv$SESSION s
         WHERE     s.username IN   ( SELECT USERNAME FROM DBA_USERS WHERE (USERNAME LIKE 'TRANSIT_GATEWAY_TNOX%' OR USERNAME LIKE 'TRANSIT_FE_TNOX%'))
         AND s.status = 'ACTIVE'
         AND s.last_call_et > (5*60);
         COMMIT;
         

         BEGIN
         FOR j IN c_killsession
         LOOP
            BEGIN
                 
               EXECUTE IMMEDIATE j.stmt;
               tmpVar := tmpVar+1;
            EXCEPTION
               WHEN OTHERS
               THEN
                  NULL;
            END;
         END LOOP;
      END;
      INSERT INTO kill_session_log 
      (start_time, end_time, count1)
      VALUES(v_start_time,  TO_CHAR(SYSDATE,'MMDDYYYY HH24miss'), tmpVar);
      COMMIT;
  
EXCEPTION
   WHEN OTHERS
   THEN NULL;
END kill_all_session;
/





---- drop tmp tables 



CREATE OR REPLACE PROCEDURE TRANSITHA.drop_temp_table
AS
vCnt NUMBER := 0;   
BEGIN
    FOR I IN (SELECT OWNER, object_name FROM dba_objects
              WHERE REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
                AND object_type='TABLE' AND created < SYSDATE-1/24)
    LOOP
        DBMS_UTILITY.EXEC_DDL_STATEMENT('drop table '||i.owner||'.'||i.object_name||' purge');
        vCnt := vCnt +1;
    END LOOP;
    INSERT INTO drop_temp_table_log (DateExecuted, CountofTableDropped)
    VALUES
    (SYSDATE,vCnt); 
END;  /* GOLDENGATE_DDL_REPLICATION */
/
