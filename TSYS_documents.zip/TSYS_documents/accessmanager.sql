rice
pune
tandav
sushal
nimbhore

sep$Action2019

SELECT sql_text,cpu_time,elapsed_time, executions, buffer_gets
      FROM dba_sqlset_statements
      WHERE sqlset_name='STS_CaptureCursorCache';