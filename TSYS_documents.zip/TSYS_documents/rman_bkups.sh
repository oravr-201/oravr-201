[oracle@devdbnode1 ~]$ cat /home/oracle/cronjobs/rman_bkups.sh
#!/bin/bash
<<Script_Developer

                Rahul Chaudhari
                Database Administrator GTS
                TSYS

Script_Developer


#load the bash_profile
. ~/.bash_profile

# Below is the main area to put some comments
<<Comment1
--> Below lines are commnetd, So you can include any Importent Notes here

# Day of the week
        0=Sunday,
        1=Monday
        2=Tuesday
        3=Wednesday
        4=Thursday
        5=Friday
        6=Saturday

# RMAN Backup Levels
Level = 0            -- A level 0 incremental backup, similar to a full backup, contains all data file blocks.
Level = 1            -- A differential level 1 incremental backup contains only blocks modified since the last incremental backup.
Level = 1 CUMULATIVE -- A cumulative level 1 incremental backup contains only blocks modified since the last level 0 incremental backup.

# Below Functio are created for the different level RMAN backups
fun_level_0  = Level 0 (Full Backup)
fun_level_1  = Level 1 (Incremental Backup)
fun_level_1C = Level 1C (Cumulative Backup)

# Weekly Backup
S  M  T  W  T  F  S
0  1  1  1C 1  1 1C

S  M  T  W  T  F  S
0  1  1  1C 1  1 1C

S  M  T  W  T  F  S
0  1  1  1C 1  1 1C

S  M  T  W  T  F  S
0  1  1  1C 1  1 1C


##############################################################################################################################################
How Backup will be stored?
ANS:--> Backup will be stored on weekly basis, So on every Sunday there will be a Full backup. At the time of Full backup the Directories
will be created on NFS Mounted Disk "/backups" (dev/NR/qa). In which weekly incremental and Cumulative backups we done. On Saturday after
cumulative backup is completed, that week's (Sunday - Saturday) backup will be compress using tar.gz and moved to /backups/devdb_bkups/old_rman_bkups/
path.
##############################################################################################################################################

# Incremental (Level 1) and Cumulative (Level 1C) backups will work only if you have taken full RMAN before taking level 1 or level 1C
Comment1

# Get the current Date
DATE_FORMAT=`date +%d%b%Y`

#What day is today, will decide the RMAN Backup
DAY_TODAY=`date +"%A"`

# variable to log the date of backup starting
Current_Date_YYYYMMDD=`date +"%m/%d/%G %H:%M:%S"`

# variable to store Last Date of Sunday, which will be start of week for Full Backup
# So full backup will be started on every Sunday
#WEEKSTART_DATE=`date -dlast-Sunday +"%A%d%b%Y"`

# variable to store the coming Saturday (That week's Saturday), which will be End of Week.
#WEEKEND_DATE=`date -dSaturday +"%A%d%b%Y"`

if [ $DAY_TODAY = 'Sunday' -o $DAY_TODAY = 'Saturday' ] ; then
        # If Today is Monday or Sunday then get the date format in <<WeekName>><<DD>><<Mon>><<YYYY>> -- for e.g. - Monday05Oct2015
        WEEKSTART_DATE=`date  +"%A%d%b%Y"`

                WEEKEND_DATE=`date -dSaturday +"%A%d%b%Y"`
else
        # variable to store Last Date of Sunday, which will be start of week for Full Backup
        # So full backup will be started on every Sunday
        WEEKSTART_DATE=`date -dlast-Sunday +"%A%d%b%Y"`

        # variable to store the coming Saturday (That week's Saturday), which will be End of Week.
        WEEKEND_DATE=`date -dSaturday +"%A%d%b%Y"`
fi

# Backup drive path is the main path and should be changed/modified environmental wish.
# So this will be the main path where Weekly folder will be created and under which all the rest backups will be stored
BACKUP_DRIVE_PATH=/backups/devdb_bkups
BACKUP_START_DATE=`date +"%m%d%G"`

# Store the compressed tar.gz file
CREATE_BKUP_TARFILE=${BACKUP_DRIVE_PATH}/old_rman_bkups/tar_${ORACLE_SID}_${WEEKSTART_DATE}_${WEEKEND_DATE}.tar.gz

# check if the weekly backup directory exists, else create it
WEEKLY_DIR=${BACKUP_DRIVE_PATH}/RMAN_${ORACLE_SID}_Bkup_${WEEKSTART_DATE}_${WEEKEND_DATE}
if [ ! -d ${WEEKLY_DIR} ]; then
        mkdir -p ${WEEKLY_DIR}
        export FLAG='CHECK_IF_FULL_BACKUP_WAS_TAKEN_BEFORE'
fi

# All weekly rman backups (level 0, level 1, level 1C) will be done under this directory
#BACKUP_PATH=${WEEKLY_DIR}/${FULL_BKUP_DIR}
BACKUP_PATH=${WEEKLY_DIR}

# Store the rman backup logs
RMAN_BAKUP_LOG=${BACKUP_PATH}/rmanbkup_${ORACLE_SID}_${DATE_FORMAT}.log

# Store rman connect target string
RMAN_TRGT_CONN_STR=/
RMAN_SPBKP_FLS="rmanbackup_${ORACLE_SID}_SPFiles_%u_%s_%T"
RMAN_CTRLBKP_FLS="rmanbackup_${ORACLE_SID}_CTRLFiles_%u_%s_%T"
RMAN_CTRLSNAPSHOTBKP_FLS="rmanbackup_${ORACLE_SID}_CTRLSShotFiles.ctl"
RMAN_DBBKP_FLS="rmanbackup_${ORACLE_SID}_DBFiles_%u_%s_%T"
#RMAN_DBBKP_FULL_FLS="rmanbackup_${ORACLE_SID}_DBFiles_FULL_%u_%s_%T"
#RMAN_DBBKP_INCRE_FLS="rmanbackup_${ORACLE_SID}_DBFiles_INCRE_%u_%s_%T"
#RMAN_DBBKP_CUMUL_FLS="rmanbackup_${ORACLE_SID}_DBFiles_CUMUL_%u_%s_%T"
RMAN_ARCHBKP_FLS="rmanbackup_${ORACLE_SID}_ArchFiles_%u_%s_%T"

RMAN_DELETE_LOGS="rman_delete_obsolete_logs.log"

# create the rman log file in append mode to append all other logs
if [ ! -d ${RMAN_BAKUP_LOG} ] ; then
   touch ${RMAN_BAKUP_LOG}
   touch ${BACKUP_PATH}/${RMAN_DELETE_LOGS}

fi

#Display and store the logs output
echo "====================== ${ORACLE_SID} RMAN BACKUP ===================================="  > ${RMAN_BAKUP_LOG}
echo "RMAN Backup Started Date and Time   - "${Current_Date_YYYYMMDD}                   >> ${RMAN_BAKUP_LOG}
echo "Backup Running on Database Instance - "${ORACLE_SID}                              >> ${RMAN_BAKUP_LOG}
echo "Backup Running on Database Node     - "${HOST}                                    >> ${RMAN_BAKUP_LOG}
echo "RMAN Backup is taken on Path        - "${WEEKLY_DIR}                              >> ${RMAN_BAKUP_LOG}
echo "                                      "                                           >> ${RMAN_BAKUP_LOG}
echo "------------------------------------------------------------------------"         >> ${RMAN_BAKUP_LOG}
if [ $DAY_TODAY = 'Sunday' ] ; then
        BACKUP_TYPE_DAY="Full RMAN Backup"
elif [ $DAY_TODAY = 'Monday' -o $DAY_TODAY = 'Tuesday' -o $DAY_TODAY = 'Thursday' -o $DAY_TODAY = 'Friday' ] ; then
        BACKUP_TYPE_DAY="Incremental RMAN Backup"
elif [ $DAY_TODAY = 'Wednesday' -o $DAY_TODAY = 'Saturday' ] ; then
        BACKUP_TYPE_DAY="Cumulative RMAN Backup"
fi
echo "Start with ${BACKUP_TYPE_DAY}       - "${DAY_TODAY} "-" ${Current_Date_YYYYMMDD}  >> ${RMAN_BAKUP_LOG}
echo "------------------------------------------------------------------------"         >> ${RMAN_BAKUP_LOG}
echo "====================================================================================="  >> ${RMAN_BAKUP_LOG}

#Send EMail once rman script is completed
MAIL_FROM=RMAN-DEV-NR-QA-BKUPS
MAIL_TO=ifx-dbalerts@tsys.com
MAIL_CC=""
SUBJECT_LINE="${BACKUP_TYPE_DAY} - ${ORACLE_SID} - ${DATE_FORMAT}"
EMAIL_BODY=${RMAN_BAKUP_LOG}
SEND_MAIL_SCRIPT=/home/oracle/cronjobs/perlemail.pl

#send_mail(){
#perl ${SEND_MAIL_SCRIPT} -f ${MAIL_FROM} -t ${MAIL_TO} -s "${SUBJECT_LINE}" -l "${EMAIL_BODY}"
#}

# There is a bug "ORA-27054: NFS file system where the file is created or resides is not mounted with correct options"
# in RMAN backup done over NFS mounted disks, to by-passing the bug, you can execute the below event check.
sqlplus -s / as sysdba <<EOF
alter system set events '10298 trace name context forever, level 32';
EOF


# Delete the expired and obsolete
RMAN_DEL_EXPIRED_BKUPS="
rman target / <<EOF
run
{
        ALLOCATE CHANNEL c1 TYPE DISK;
        CROSSCHECK BACKUP;
        CROSSCHECK ARCHIVELOG ALL;
        DELETE NOPROMPT OBSOLETE;
        DELETE NOPROMPT EXPIRED BACKUP;
        DELETE EXPIRED ARCHIVELOG ALL;
        RELEASE CHANNEL c1;
}
exit 0
EOF
"

# string which has rman backup scripts
RMAN_CONN_STRG="
rman target ${RMAN_TRGT_CONN_STR} msglog ${RMAN_BAKUP_LOG} append << EOF"

RMAN_CONFIG_STRG="
CONFIGURE RETENTION POLICY TO REDUNDANCY 3;
CROSSCHECK BACKUP;
CROSSCHECK ARCHIVELOG ALL;
CONFIGURE SNAPSHOT CONTROLFILE NAME CLEAR;
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '${BACKUP_PATH}/${RMAN_CTRLSNAPSHOTBKP_FLS}';
"

RMAN_BKUP_STRG1="
run {
ALLOCATE CHANNEL R1 TYPE DISK;
ALLOCATE CHANNEL R2 TYPE DISK;
ALLOCATE CHANNEL R3 TYPE DISK;
ALLOCATE CHANNEL R4 TYPE DISK;
SQL 'ALTER SYSTEM SWITCH LOGFILE';"

RMAN_BKUP_STRG11="
BACKUP
        SPFILE
        FORMAT '${BACKUP_PATH}/${RMAN_SPBKP_FLS}';
BACKUP
        CURRENT CONTROLFILE
        FORMAT '${BACKUP_PATH}/${RMAN_CTRLBKP_FLS}';"

# String for full (level 0) backup
BKUP_TYPE_FULL="
BACKUP AS
        COMPRESSED BACKUPSET
        DATABASE FORMAT '${BACKUP_PATH}/${RMAN_DBBKP_FLS}';"

BKUP_TYPE_FULL="
BACKUP AS
        COMPRESSED BACKUPSET INCREMENTAL LEVEL = 0 DATABASE
        FORMAT '${BACKUP_PATH}/${RMAN_DBBKP_FLS}';"

# String for incremental (level 1) backup
BKUP_TYPE_INCRE="
BACKUP AS
        COMPRESSED BACKUPSET INCREMENTAL LEVEL = 1 DATABASE
        FORMAT '${BACKUP_PATH}/${RMAN_DBBKP_FLS}';"

# String for cumulative (level 1 cumulative) backup
BKUP_TYPE_CUMUL="
BACKUP AS
        COMPRESSED BACKUPSET INCREMENTAL LEVEL = 1 CUMULATIVE DATABASE
        FORMAT '${BACKUP_PATH}/${RMAN_DBBKP_FLS}';"

# String to store the rest of the script
RMAN_BKUP_STRG2="
BACKUP
    ARCHIVELOG ALL NOT BACKED UP 1 TIMES
    FILESPERSET 20
    FORMAT '${BACKUP_PATH}/${RMAN_ARCHBKP_FLS}';
    DELETE FORCE NOPROMPT ARCHIVELOG UNTIL TIME 'SYSDATE-3' BACKED UP 1 TIMES TO DEVICE TYPE DISK;
SQL 'ALTER SYSTEM SWITCH LOGFILE';
DELETE FORCE NOPROMPT EXPIRED ARCHIVELOG ALL;
RELEASE CHANNEL R1;
RELEASE CHANNEL R2;
RELEASE CHANNEL R3;
RELEASE CHANNEL R4;
}
exit 0
EOF
"

# based on day wise backup will be scheduled
if [ $DAY_TODAY = 'Sunday' ] ; then

        # It's a Full Backup done on Sunday, So make the free Disk Space by removing old backup Files and Folders
        /bin/sh -c `find ${BACKUP_DRIVE_PATH}/* -type d -ctime +2 -print |xrags rm -rf`                                                 >  ${RMAN_DELETE_LOGS}
        /bin/sh -c "${RMAN_DEL_EXPIRED_BKUPS}"                                                                                          >> ${RMAN_DELETE_LOGS}

        echo "${RMAN_CONN_STRG} ${RMAN_CONFIG_STRG} ${RMAN_BKUP_STRG1} ${RMAN_BKUP_STRG11} ${BKUP_TYPE_FULL} ${RMAN_BKUP_STRG2}"        >> ${RMAN_BAKUP_LOG}
        /bin/sh -c "${RMAN_CONN_STRG} ${RMAN_CONFIG_STRG} ${RMAN_BKUP_STRG1} ${RMAN_BKUP_STRG11} ${BKUP_TYPE_FULL} ${RMAN_BKUP_STRG2}"  >> ${RMAN_BAKUP_LOG}
        echo "        "                                                                                                                 >> ${RMAN_BAKUP_LOG}
        echo "RMAN Full Backup for Today - $Current_Date_YYYYMMDD End Here"                                                             >> ${RMAN_BAKUP_LOG}
elif [ $DAY_TODAY = 'Monday' -o $DAY_TODAY = 'Tuesday' -o $DAY_TODAY = 'Thursday' -o $DAY_TODAY = 'Friday' ] ; then
        echo "${RMAN_CONN_STRG} ${RMAN_BKUP_STRG1} ${BKUP_TYPE_INCRE} ${RMAN_BKUP_STRG2}"                                               >> ${RMAN_BAKUP_LOG}
        /bin/sh -c "${RMAN_CONN_STRG} ${RMAN_BKUP_STRG1} ${BKUP_TYPE_INCRE} ${RMAN_BKUP_STRG2}"                                         >> ${RMAN_BAKUP_LOG}

        echo "        "                                                                                                                 >> ${RMAN_BAKUP_LOG}
        echo "RMAN Incremental Backup for Today - ${Current_Date_YYYYMMDD} End Here"                                                    >> ${RMAN_BAKUP_LOG}
elif [ $DAY_TODAY = 'Wednesday' -o $DAY_TODAY = 'Saturday' ] ; then
        echo "${RMAN_CONN_STRG} ${RMAN_BKUP_STRG1} ${BKUP_TYPE_CUMUL} ${RMAN_BKUP_STRG2}"                                               >> ${RMAN_BAKUP_LOG}
        /bin/sh -c "${RMAN_CONN_STRG} ${RMAN_BKUP_STRG1} ${BKUP_TYPE_CUMUL} ${RMAN_BKUP_STRG2}"                                         >> ${RMAN_BAKUP_LOG}
        echo "        "                                                                                                                 >> ${RMAN_BAKUP_LOG}
        echo "RMAN Cumulative Backup for Today - ${Current_Date_YYYYMMDD} End Here"                                                     >> ${RMAN_BAKUP_LOG}
fi

# send the mail to group
#send_mail
#### Check for RMAN/ORA Errors and notify accordingly
RMAN_ERRORS=`egrep "ORA-|RMAN-" ${RMAN_BAKUP_LOG}`
RMAN_WARNING=`egrep "ORA-|RMAN-" ${RMAN_BAKUP_LOG}`

if [ -z "${RMAN_ERRORS}" ] ; then
   echo "No Errors"
elif [ -z "${RMAN_WARNING}" ] ; then
   echo "No Errors, but Warnings"
   SUBJECT_LINE="Warning Errors found in ${BACKUP_TYPE_DAY} RMAN Backups - ${ORACLE_SID}"
   perl ${SEND_MAIL_SCRIPT} -f ${MAIL_FROM} -t ${MAIL_TO} -s "${SUBJECT_LINE}" -l "${EMAIL_BODY}"
else
   echo "Errors Found !!!!"
   SUBJECT_LINE="Errors found in ${BACKUP_TYPE_DAY} RMAN Backups - ${ORACLE_SID}"
   perl ${SEND_MAIL_SCRIPT} -f ${MAIL_FROM} -t ${MAIL_TO} -s "${SUBJECT_LINE}" -l "${EMAIL_BODY}"
fi

#if [ $DAY_TODAY = 'Saturday' ] ; then
#    tar -cvzf ${CREATE_BKUP_TARFILE} ${WEEKLY_DIR}
#   rm -rf ${WEEKLY_DIR}
#fi
