
--------------------------------------------Jan 20 start ----------------------------------------------------------

--01/Jan/2020
--02/Jan/2020
RE: Service Request SR1159300 Assigned to Your Group
FW: Service Request SR1159300 Assigned to Your Group
RE: Approval Request for "CM85941 Change CM85941 meets criteria to be an Exception change. Please enter exception reason."
RE: SR1156928:-Redhat OS patching of TransIT Dev servers
RE: !!!Alert - Disk utilisation of wdl1trandbs03.tsysacquiring.org is crossed threshold limit of 85%

--03/Jan/2020
RE: dcwhan03-siprod Archived logs not applied.
RE: EXCEPTION REQUEST - CM85941: MERCH / US - Arizona - Tempe / Production / TRANSIT / SR1159300 -Below script needs to be updated on Prod DB to resolve the merchant issue.
--04/Jan/2020
--05/Jan/2020
--06/Jan/2020
RE: !!!Alert - Disk utilisation of qadbnode2.tsysacquiring.org is crossed threshold limit of 75%
RE: EM Event: Fatal:+ASM1_10.100.224.69 - Failed to connect to ASM instance. Failed to connect: java.sql.SQLException: The Network Adapter could not establish the connection
RE: EM Event: Fatal:+ASM1_10.100.224.69 - Failed to connect to ASM instance. Failed to connect: java.sql.SQLException: The Network Adapter could not establish the connection
RE: Critical alert for E-Connection POS_Auth_Sum (pos_sum) Runtime Error. DBLOAD Failed on dcedb9
RE: dcwposr@dcwdb9
RE: dcwhan03-siprod Archived logs not applied.
RE: !!!Alert - Disk utilisation of wpl1trandbtxn1.tsysacquiring.org is crossed threshold limit of 75%

--07/Jan/2020
RE: Critical alert for OEM13C || IM3259731
RE: EM Event: Critical:sipsbe1 - The standby database is approximately 2303 seconds behind the primary database.
RE: Oracle ULA information
RE: dcwhan03-siprod Archived logs not applied.

--08/Jan/2020
Accepted: Quick Discussion on How to make Cert Environment
RE: Service Request SR1166790 Assigned to Your Group
RE: Do Peer Review for CM86328
--09/Jan/2020
--10/Jan/2020
RE: List of Tables from Extract file in TE, TW, RE, RW in PROD DBs
RE: TNS listener issue on NR DB for API 
--11/Jan/2020
--12/Jan/2020
--13/Jan/2020
RE: PROD_RE Alert: GoldenGate REPLICAT process RPRETWJan has a lag of 00 hour 04 min
RE: PF WEST Alert: GoldenGate REPLICAT process RPRWTE has a lag of 00 hour 03 min
RE: !!!Alert - Disk utilisation of wpl1trandbtxn1.tsysacquiring.org is crossed threshold limit of 75%

--14/Jan/2020 --Oncall
RE: 2Jan00260 -ArDBM::Query string not available corresponding to the query
RE: Service Request SR1170887 Assigned to You
RE: UAT Alert : Lag on TW Database TW - DCW.
RE: SR1168339:-TransIT UAT Linux servers OS patching and reboot
RE: EM Event: Critical:uatrptdb_uatrptdb1 - The database status is UNKNOWN.
RE: EM Event: Critical:uatrptdb_uatrptdb1 - The database status is UNKNOWN.
RE: dcwhan03-siprod Archived logs not applied.

--15/Jan/2020 --Oncall
SR1172745			:  please execute below insert query on UAT DB to resolve below 
					   Exception we are seeing in UAT ARCOT logs
IM3262137			:   eph1tsysdbsJan.vitalps.com: Disk Device /dev/disk/disk9 is 100% busy.

RE: dcwhan03-siprod Archived logs not applied.
RE: [WARN] Export for dcwhan03+siprod - RptStatus=FAILED
RE: Table does not exist error on Dev DB
RE: PF WEST Alert: GoldenGate REPLICAT process RPRWTE has a lag of 00 hour 04 min

--16/Jan/2020 --Oncall
RE: EM Event: Clear:uatrptdb - Tablespace [ARCOT_DATA] is [86 percent ] full
FW: (DRAFT) Automation Catalog - Invitation to edit
RE: PROD_TE Alert: GoldenGate REPLICAT process RPTETWLG has a lag of 00 hour 09 min
RE: DC Move Discussion

--17/Jan/2020 --Oncall
SR 3-22089798251 : Insert/Update/Commit not working ORA-00942: table or view does not exist
RE: Service Request SR1176742 Assigned to Your Group
Index Rebuield o West DC 
RE: Amber - TransIT Feb release
RE: EM Event: Critical:transitrptaz - Tablespace [TNOX_CPASS_LOB] is [97 percent ] full

--18/Jan/2020 --Oncall
RE: epl1trandbrpt1.tsysacquiring.org : Space running out
RE: dcwhan03-siprod Archived logs not applied.

--19/Jan/2020 --Oncall
RE: *** Check Archived Applied Failed to Start ***
RE: Critical alerts for OEM13C || IM3263745
epl1tsysdbsJan :filesystem issue 
RE: epl1tsysdbsJan.vitalps.com-ccprode Archived logs not applied.
RE: !!!Alert - Disk utilisation of wpl1trandbtxn1.tsysacquiring.org is crossed threshold limit of 75%
SR 3-22089798251 : Insert/Update/Commit not working ORA-00942: table or view does not exist
RE: Amber - TransIT Feb release

--20/Jan/2020 --Oncall
RE: !!!Alert - Disk utilisation of epl1trandbrpt1.tsysacquiring.org is crossed threshold limit of 75%
RE: !!!Alert - Disk utilisation of wpl1trandbtxn1.tsysacquiring.org is crossed threshold limit of 75%
RE: DC Move Discussion
RE: List of Tables from Extract file in TE, TW, RE, RW in PROD DBs
RE: TNS listener issue on NR DB for API 
SR1177936 : Space request for TransIT NR and UAT 
RE: Bad TAS Batch for Batch 021 Merchant C6YW5EU1 || SR1171333

SR1178448
SR1178459
--21/Jan/2020 --Oncall
RE: TNS listener issue on NR DB for API 
RE: transitt1-epl1trandbtxn1.tsysacquiring.org SM INCREMENTAL File Archived Redo Backup Failed
Oracle 2020_Q1 security Patching  | patch review
RE: Service Request SR1177821 SLA Breached

--22/Jan/2020 
RE: jira error
RE: DC Move Discussion
RE: Service Request SR1177821 Assigned to Your Group
RE: SR1179498 - Capured Transactions Showing as Pending Settlement

--23/Jan/2020 
RE: UAT - Settlement Process Failed - Analysis


--24/Jan/2020 
RE: Upcoming Merchant Federal Examination
RE: UAT MAP Linux servers OS patching and reboot (SR1177944)
--25/Jan/2020 
Re: Control M Meeting Minutes
--26/Jan/2020
Replication Error 

--27/Jan/2020 
Re: !!!Alert - Disk utilisation of epl1trandbrpt1.tsysacquiring.org is crossed threshold limit of 75%
RE: EM Event: Warning:ctlmptch - Tablespace [SYSAUX] is [85.06 percent] full

--28/Jan/2020
RE: Service Request SR1177821 SLA Breached

--29/Jan/2020 
Patches Dwonloaded 
--30/Jan/2020 
RE: Need tasks done in Archive DB in WEST (wpl2trandbs02-priv.tsysacquiring.org).

--31/Jan/2020 
RE: Critical alerts for OEM13C
Patch Schedule preparation 

--------------------------------------------Jan 20 End ----------------------------------------------------------



--------------------------------------------FEB 20 Start ----------------------------------------------------------


--01/Feb/2020
Re: Critical alert for OEM13C.|| IM3267320

--02/Feb/2020
--03/Feb/2020
RE: dcwhan03-siprod Archived logs not applied.
RE: !!!Alert - Disk utilisation of wdl2mapxdbs01 is crossed threshold limit of 75%
RE: !!!Alert - Disk utilisation of wql2mapxdbs01.tsysacquiring.org is crossed threshold limit of 75%

--04/Feb/2020 --WFH : 04-Feb-2020
RE: dcwhan03-siprod Archived logs not applied.
RE: EM Event: Fatal:mapdevdb - Failed to connect to database instance: Failed to connect: java.sql.SQLException: The Network Adapter could not establish the connection.
RE: Q1_2020  : Oracle Security  Patching on MAP DEV
RE: Warning: File system /opt/oracle on dcwhan03 is at 20% and is over threshold of 20% free

--05/Feb/2020 : Leave

RE: Q1_2020  : Oracle Security  Patching on MAP QA

--06/Feb/2020
RE: StrongAuth DB patching in QA
RE: Import MAP DEV data
RE: [WARN] Export for dcwhan03+siprod - RptStatus=FAILED
RE: EM Event: Warning:sipsbe1 - 81% of archive area /var/opt/oracle/recovery/arch_logs/sipsbe1/ is used.
RE: Warning: File system /var/opt/oracle/recovery/backups on eph1tsysdbs01 is at 15% and is over threshold of 15% free
RE: File system utilization alert for wulmapxdbs01 server
RE: IM3264867 - Merchant attempting too many <GenerateKey> messages
RE: Q1_2020  : Oracle Security  Patching on  ControlM/SI
RE: 19c QA server connectivity is not happeing from Jenkins server (10.132.13.16)

--07/Feb/2020
RE: Multiple critical alerts for OEM13C||  IM3269935
RE: Service Request SR1177821 SLA Breached
RE: wpl1tsysdbs01.vitalps.com-controlm DataGuard Status has Errors.
RE: Critical alert for File system space utilization on WQL1TSYSDBS01 server.
--08/Feb/2020
RE: IM3264867 - Merchant attempting too many <GenerateKey> messages
RE: Critical alert for File system space utilization for WUL2MAPXDBS01 server.

--09/Feb/2020

--10/Feb/2020
RE: !!!Alert - Disk utilisation of epl1trandbrpt1.tsysacquiring.org is crossed threshold limit of 75%
RE: dcwhan03-siprod Archived logs not applied.
RE: Warning: File system /oracle/sauthuat/rman_bkups on wul2tsysdbs01.vitalps.com is at 20% and is over threshold of 20% free
POSH Online Training 
RE: High number of Bad Batch received on transit.

--11/Feb/2020
RE: dcwhan03-siprod Archived logs not applied.
RE: EM Event: Warning:sipsbe1 - 81% of archive area /var/opt/oracle/recovery/arch_logs/sipsbe1/ is used.
RE: Warning: File system /oracle/sauthuat/rman_bkups on wul2tsysdbs01.vitalps.com is at 19% and is over threshold of 20% free
RE: Multiple auth timeouts for pin transactions on DCWTP1 || IM3270898 
RE: Critical alert for File system space utilization for WUL2MAPXDBS01 server.

Support Prod issue in TRANSIT
--12/Feb/2020
RE: EM Event: Critical:wpl1mapxdbs01.tsysacquiring.org:3872 - Agent Unreachable (REASON = Unable to connect to the agent at https://wpl1mapxdbs01.tsysacquiring.org:3872/emd/main/ [connect timed out]). Host is reachable.
RE: dcwhan03-siprod Archived logs not applied.
Support MAP Prod OS Patch 
RE: EM Event: Critical:wpl1mapxdbs01.tsysacquiring.org:3872 - Agent Unreachable (REASON = Unable to connect to the agent at https://wpl1mapxdbs01.tsysacquiring.org:3872/emd/main/ [connect timed out]). Host is reachable.
RE: Warning: File system /var/opt/oracle/recovery/backups on eph1tsysdbs01 is at 13% and is over threshold of 15% free

--13/Feb/2020
--14/Feb/2020
RE: Q1_2020  : Oracle Security  Patching TransIT  Preprod

--15/Feb/2020
RE: CM88284 | MERCH / US - Arizona - Tempe / Production / SIERRA / Sierra FEB20 PROD release 02/15/2020.
IM3272953

--16/Feb/2020
--17/Feb/2020
RE: dcwhan03-siprod Archived logs not applied.
--18/Feb/2020
RE: PF WEST Alert: GoldenGate REPLICAT process RPTWTELG has a lag of 00 hour 01 min
RE: TransIT Processing Time Monitoring Report - SR1201786
RE: Q1_2020  : Oracle Security  Patching : MAP UAT
RE: !!!Alert - Disk utilisation of wdl2mapxdbs01 is crossed threshold limit of 75%

--19/Feb/2020
RE: HP OMI Alert! FileSystem space utilization for Logical Disk /opt/oracle12c of type vxfs

--20/Feb/2020
RE:  StrongAuth DB patching UAT
Q1_2020  : Oracle Security  Patching TransIT  Preprod 
RE: PF WEST Alert: GoldenGate REPLICAT process RPTWTE has been ABENDED
--21/Feb/2020
PF Database refresh 11g to 19c 

--22/Feb/2020
RE: FileSystem space utilization for Logical Disk /opt of type xfs
RE: dcwhan03-siprod Archived logs not applied.
RE: PROD_RW Alert: GoldenGate EXTRACT process PPTERC has been ABENDED
--23/Feb/2020

--24/Feb/2020
	RE: CM88923 | MERCH / US - Arizona - Tempe / Production / TRANSIT / GTS Merchant Prod Release Joker (23 Feb 2020) update # 
--25/Feb/2020
RE: File system space utilization on wql2tsysdbs03
RE: update db spreadsheet
JIRA Migration 

--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------

--------------------------------------------FEB 20 Start ----------------------------------------------------------


--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020

--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--------------------------------------------FEB 20 Start ----------------------------------------------------------
--01/Feb/2020
--02/Feb/2020
--03/Feb/2020
--04/Feb/2020
--05/Feb/2020
--06/Feb/2020
--07/Feb/2020
--08/Feb/2020
--09/Feb/2020
--10/Feb/2020
--11/Feb/2020
--12/Feb/2020
--13/Feb/2020
--14/Feb/2020
--15/Feb/2020
--16/Feb/2020
--17/Feb/2020
--18/Feb/2020
--19/Feb/2020
--20/Feb/2020
--21/Feb/2020
--22/Feb/2020
--23/Feb/2020
--24/Feb/2020
--25/Feb/2020
--26/Feb/2020
--27/Feb/2020
--28/Feb/2020
--29/Feb/2020
--30/Feb/2020
--31/Feb/2020





















































































