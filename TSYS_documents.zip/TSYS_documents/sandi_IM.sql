[‎3/‎8/‎2019 11:43 AM] Sandip Tujare: 
Select * from tab@dblink
Minus<\\tef00028\devdept\Software\Win7 VDI Softwares\DBA>
Select * from tab; 
[‎3/‎8/‎2019 11:45 AM] Sandip Tujare: 
<\\tef00028\devdept\Software\Win7 VDI Softwares\DBA> Software 
toad, oracle client 64 bit
install karun ghe hya location warun
[‎3/‎8/‎2019 12:15 PM] Sandip Tujare: 
5-09640-15125-27442-05305
INFONOX-106-468-537 
key 			5-09640-15125-27442-05305
site messgae 		INFONOX-106-468-537  
[‎3/‎8/‎2019 12:36 PM] Sandip Tujare: 

[‎3/‎8/‎2019 1:08 PM] Vishal Bhandwalkar: 
$ORACLE_HOME/OPatch/ocm/bin/emocmrsp  -no_banner -output $ORACLE_HOME/dbs/ocm.rsp 
[‎3/‎8/‎2019 1:09 PM] Sandip Tujare: 
$ORACLE_HOME/OPatch/ocm/bin/emocmrsp  
We saved this conversation. You'll see it soon in the Conversations tab in Skype for Business and in the Conversation History folder in Outlook.
[‎3/‎8/‎2019 1:38 PM] Sandip Tujare: 
27301652 
[‎3/‎8/‎2019 1:40 PM] Sandip Tujare: 
https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=521727000505904&id=2495017.1&displayIndex=4&_afrWindowMode=0&_adf.ctrl-state=oda3pg6b6_545#FIX 
[‎3/‎8/‎2019 1:44 PM] Vishal Bhandwalkar: 
https://support.oracle.com/epmos/faces/PatchResultsNDetails?_adf.ctrl-state=mna5anv3t_38&releaseId=600000000009300&requestId=21852945&patchId=27301652&languageId=0&platformId=226&searchdata=%3Ccontext+type%3D%22BASIC%22+search%3D%22%26lt%3BSearch%26gt%3B%26lt%3BFilter+name%3D%26quot%3Bpatch_number%26quot%3B+op%3D%26quot%3Bis%26quot%3B+value%3D%26quot%3B27301652+%26quot%3B%2F%26gt%3B%26lt%3BFilter+name%3D%26quot%3Bplatform%26quot%3B+op%3D%26quot%3Bis%26quot%3B+value%3D%26quot%3B226%26quot%3B%2F%26gt%3B%26lt%3BFilter+name%3D%26quot%3Bexclude_superseded%26quot%3B+op%3D%26quot%3Bis%26quot%3B+value%3D%26quot%3Bfalse%26quot%3B%2F%26gt%3B%26lt%3B%2FSearch%26gt%3B%22%2F%3E&_afrLoop=523713129563030 
[‎3/‎8/‎2019 2:02 PM] Sandip Tujare: 
select * from TRANSNOX_IOX.CUSTOMER
where date_created > add_months(sysdate, -6)
minus
select * from TRANSNOX_IOX.CUSTOMER@tegg
where date_created > add_months(sysdate, -6);
 
We saved this conversation. You'll see it soon in the Conversations tab in Skype for Business and in the Conversation History folder in Outlook.
We saved this conversation. You'll see it soon in the Conversations tab in Skype for Business and in the Conversation History folder in Outlook.
[‎3/‎11/‎2019 9:13 AM] Sandip Tujare: 
Pune  > 020-4103-6885 
US GA >706-383-7543
US CA >408-498-7039
passcode >81313440# 
[‎3/‎11/‎2019 9:35 AM] Vishal Bhandwalkar: 
You do not have permission to download patches. Request permission from your company's My Oracle Support administrator. 
[‎3/‎11/‎2019 9:40 AM] Sandip Tujare: 
http://10.132.13.131:6280/jenkins/blue/organizations/jenkins/Production-PreRelease/detail/Production-PreRelease/91/pipeline 
[‎3/‎11/‎2019 9:52 AM] Vishal Bhandwalkar: 
Hi Baidhar,
	Can you please guide me on perform this Activity , so i can perform this activity  .
[‎3/‎11/‎2019 9:53 AM] Sandip Tujare: 
TRANSNOX_IOX.CUSTOMER
TRANSNOX_IOX.CUST_BANK_ACCOUNT
TRANSNOX_IOX.CUST_CARD_ACCOUNT
TRANSNOX_IOX.CUST_ENROLLMNENT
TRANSNOX_IOX.CUST_FINANCIAL_ACCOUNT
 
[‎3/‎11/‎2019 9:57 AM] Vishal Bhandwalkar: 
 Hi Baidhar,
	I was check listed tables their are no diffence between below table (customer) . But thair large diffrence between transation tables 
	can you Please guide me How to compare and reapir tables.


No Difference :

TRANSNOX_IOX.CUSTOMER
TRANSNOX_IOX.CUST_BANK_ACCOUNT
TRANSNOX_IOX.CUST_CARD_ACCOUNT
TRANSNOX_IOX.CUST_ENROLLMNENT
TRANSNOX_IOX.CUST_FINANCIAL_ACCOUNT 
[‎3/‎11/‎2019 10:12 AM] Sandip Tujare: 
Hi Baidhar,
	I was check listed tables their are no diffence between below table (customer) . But few tables have huge data (transation tables )
	can you Please guide me How to compare and reapir tables.


No Difference :

TRANSNOX_IOX.CUSTOMER
TRANSNOX_IOX.CUST_BANK_ACCOUNT
TRANSNOX_IOX.CUST_CARD_ACCOUNT
TRANSNOX_IOX.CUST_ENROLLMNENT
TRANSNOX_IOX.CUST_FINANCIAL_ACCOUNT  





















