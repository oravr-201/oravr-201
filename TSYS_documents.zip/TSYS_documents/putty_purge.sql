

set datetimef=%date:~10,4%%date:~4,2%%date:~7,2%
echo %datetimef%
cd C:\Vishal\
md bkp_putty_%datetimef%
cd "C:\Vishal\putty_bkp_"%datetimef%""
copy C:\Vishal\v1.log C:\Vishal\bkp_putty_20200219\v1_"%datetimef%".log
copy C:\Vishal\v2.log C:\Vishal\bkp_putty_20200219\v2_"%datetimef%".log
copy C:\Vishal\v3.log C:\Vishal\bkp_putty_20200219\v3_"%datetimef%".log
copy C:\Vishal\v4.log C:\Vishal\bkp_putty_20200219\v4_"%datetimef%".log



cd C:\Vishal\ putty_bkp_
%datetimef%




"C:\Program Files (x86)\7-Zip\7z.exe"  a -- C:\Vishal\putty_bkp_"%datetimef%".zip C:\Vishal\putty_bkp_"%datetimef%"




copy /Y NUL empty.txt



copy  /Y NUL  C:\Vishal\v1.log
copy  /Y NUL  C:\Vishal\v2.log
copy  /Y NUL  C:\Vishal\v3.log
copy  /Y NUL  C:\Vishal\v4.log