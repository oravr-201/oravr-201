 
select 'ALTER INDEX ' ||owner||'.'||index_name||' REBUILD ONLINE;' from ( 
SELECT A.*,
         ROUND (INDEX_LEAF_ESTIMATE_IF_REBUILT / CURRENT_LEAF_BLOCKS * 100)
            PERCENT,
         CASE
            WHEN INDEX_LEAF_ESTIMATE_IF_REBUILT / CURRENT_LEAF_BLOCKS < 0.5
            THEN
               'candidate for rebuild'
         END
            STATUS,
         (SELECT SUM (BYTES) / (1024 * 1024 * 1024)
            FROM DBA_SEGMENTS DS
           WHERE     DS.OWNER IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX')
                 AND SEGMENT_NAME = INDEX_NAME)
            INDEX_SIZE,
         (SELECT SUM (BYTES) / (1024 * 1024 * 1024)
            FROM DBA_SEGMENTS DS
           WHERE     DS.OWNER IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX')
                 AND SEGMENT_NAME = TABLE_NAME)
            TABLE_SIZE
    FROM (  SELECT OWNER,TABLE_NAME,
                   INDEX_NAME,
                   CURRENT_LEAF_BLOCKS,
                   ROUND (
                        100
                      / 90
                      * (  IND_NUM_ROWS * (ROWID_LENGTH + UNIQ_IND + 4)
                         + SUM ( (AVG_COL_LEN) * (TAB_NUM_ROWS)))
                      / (8192 - 192))
                      AS INDEX_LEAF_ESTIMATE_IF_REBUILT
              FROM (SELECT TAB.OWNER,TAB.TABLE_NAME,
                           TAB.NUM_ROWS TAB_NUM_ROWS,
                           DECODE (TAB.PARTITIONED, 'YES', 10, 6) ROWID_LENGTH,
                           IND.INDEX_NAME,
                           IND.INDEX_TYPE,
                           IND.NUM_ROWS IND_NUM_ROWS,
                           IND.LEAF_BLOCKS AS CURRENT_LEAF_BLOCKS,
                           DECODE (UNIQUENESS, 'UNIQUE', 0, 1) UNIQ_IND,
                           IC.COLUMN_NAME AS IND_COLUMN_NAME,
                           TC.COLUMN_NAME,
                           TC.AVG_COL_LEN
                      FROM DBA_TABLES TAB
                           JOIN DBA_INDEXES IND
                              ON     IND.OWNER = TAB.OWNER
                                 AND IND.TABLE_NAME = TAB.TABLE_NAME
                           JOIN DBA_IND_COLUMNS IC
                              ON     IC.TABLE_OWNER = TAB.OWNER
                                 AND IC.TABLE_NAME = TAB.TABLE_NAME
                                 AND IC.INDEX_OWNER = TAB.OWNER
                                 AND IC.INDEX_NAME = IND.INDEX_NAME
                           JOIN DBA_TAB_COLUMNS TC
                              ON     TC.OWNER = TAB.OWNER
                                 AND TC.TABLE_NAME = TAB.TABLE_NAME
                                 AND TC.COLUMN_NAME = IC.COLUMN_NAME
                     WHERE     TAB.OWNER IN ('TRANSNOX_IOX','SNOX4TRANSNOX')
--                     and tab.table_name in ('RECURRING_PAYMENT','CUSTOMER','TASK','TRANS_RETURN','TRANS_SIGNATURE','CUST_ADDRESS','TRANSACTION','CUST_CARD_ACCOUNT','CUST_FINANCIAL_ACCOUNT','TRANS_DETAIL','TRANS_TAX_DETAIL','TRANS_VOID','CUST_ENROLLMNENT','TRANS_RESPONSE_INFO','USER_AUDIT_DETAIL','TRANS_FEE_DETAIL','TRANS_DENOMINATION_DETAILS','TRANS_CARD','OPERATOR','TRANS_PRODUCT_INFO','USER_AUDIT','TRANS_ENHANCED_DATA','MERCHANT_XML_STORAGE','FILE_PROCESS_SCRATCHPAD')
                           AND IND.LEAF_BLOCKS IS NOT NULL
                           AND IND.LEAF_BLOCKS > 1000)
          GROUP BY OWNER,TABLE_NAME,
                   INDEX_NAME,
                   CURRENT_LEAF_BLOCKS,
                   IND_NUM_ROWS,
                   UNIQ_IND,
                   ROWID_LENGTH) A
   WHERE INDEX_LEAF_ESTIMATE_IF_REBUILT / CURRENT_LEAF_BLOCKS < 0.5
ORDER BY 1, INDEX_LEAF_ESTIMATE_IF_REBUILT / CURRENT_LEAF_BLOCKS) 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 --No Title 
SELECT A.*,
         ROUND (INDEX_LEAF_ESTIMATE_IF_REBUILT / CURRENT_LEAF_BLOCKS * 100)
            PERCENT,
         CASE
            WHEN INDEX_LEAF_ESTIMATE_IF_REBUILT / CURRENT_LEAF_BLOCKS < 0.5
            THEN
               'candidate for rebuild'
         END
            STATUS,
         (SELECT SUM (BYTES) / (1024 * 1024 * 1024)
            FROM DBA_SEGMENTS DS
           WHERE     DS.OWNER IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX')
                 AND SEGMENT_NAME = INDEX_NAME)
            INDEX_SIZE,
         (SELECT SUM (BYTES) / (1024 * 1024 * 1024)
            FROM DBA_SEGMENTS DS
           WHERE     DS.OWNER IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX')
                 AND SEGMENT_NAME = TABLE_NAME)
            TABLE_SIZE
    FROM (  SELECT OWNER,TABLE_NAME,
                   INDEX_NAME,
                   CURRENT_LEAF_BLOCKS,
                   ROUND (
                        100
                      / 90
                      * (  IND_NUM_ROWS * (ROWID_LENGTH + UNIQ_IND + 4)
                         + SUM ( (AVG_COL_LEN) * (TAB_NUM_ROWS)))
                      / (8192 - 192))
                      AS INDEX_LEAF_ESTIMATE_IF_REBUILT
              FROM (SELECT TAB.OWNER,TAB.TABLE_NAME,
                           TAB.NUM_ROWS TAB_NUM_ROWS,
                           DECODE (TAB.PARTITIONED, 'YES', 10, 6) ROWID_LENGTH,
                           IND.INDEX_NAME,
                           IND.INDEX_TYPE,
                           IND.NUM_ROWS IND_NUM_ROWS,
                           IND.LEAF_BLOCKS AS CURRENT_LEAF_BLOCKS,
                           DECODE (UNIQUENESS, 'UNIQUE', 0, 1) UNIQ_IND,
                           IC.COLUMN_NAME AS IND_COLUMN_NAME,
                           TC.COLUMN_NAME,
                           TC.AVG_COL_LEN
                      FROM DBA_TABLES TAB
                           JOIN DBA_INDEXES IND
                              ON     IND.OWNER = TAB.OWNER
                                 AND IND.TABLE_NAME = TAB.TABLE_NAME
                           JOIN DBA_IND_COLUMNS IC
                              ON     IC.TABLE_OWNER = TAB.OWNER
                                 AND IC.TABLE_NAME = TAB.TABLE_NAME
                                 AND IC.INDEX_OWNER = TAB.OWNER
                                 AND IC.INDEX_NAME = IND.INDEX_NAME
                           JOIN DBA_TAB_COLUMNS TC
                              ON     TC.OWNER = TAB.OWNER
                                 AND TC.TABLE_NAME = TAB.TABLE_NAME
                                 AND TC.COLUMN_NAME = IC.COLUMN_NAME
                     WHERE     TAB.OWNER IN ('TRANSNOX_IOX','SNOX4TRANSNOX')
                     and tab.table_name in ('RECURRING_PAYMENT','CUSTOMER','TASK','TRANS_RETURN','TRANS_SIGNATURE','CUST_ADDRESS','TRANSACTION','CUST_CARD_ACCOUNT','CUST_FINANCIAL_ACCOUNT','TRANS_DETAIL','TRANS_TAX_DETAIL','TRANS_VOID','CUST_ENROLLMNENT','TRANS_RESPONSE_INFO','USER_AUDIT_DETAIL','TRANS_FEE_DETAIL','TRANS_DENOMINATION_DETAILS','TRANS_CARD','OPERATOR','TRANS_PRODUCT_INFO','USER_AUDIT','TRANS_ENHANCED_DATA','MERCHANT_XML_STORAGE','FILE_PROCESS_SCRATCHPAD')
                           AND IND.LEAF_BLOCKS IS NOT NULL
                           AND IND.LEAF_BLOCKS > 1000)
          GROUP BY OWNER,TABLE_NAME,
                   INDEX_NAME,
                   CURRENT_LEAF_BLOCKS,
                   IND_NUM_ROWS,
                   UNIQ_IND,
                   ROWID_LENGTH) A
   WHERE INDEX_LEAF_ESTIMATE_IF_REBUILT / CURRENT_LEAF_BLOCKS < 0.5
ORDER BY 1, INDEX_LEAF_ESTIMATE_IF_REBUILT / CURRENT_LEAF_BLOCKS; 
 

