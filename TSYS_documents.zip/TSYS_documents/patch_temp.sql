CM81006
CM81006




-- sga chnages 
ALTER SYSTEM SET pga_aggregate_target='7G' SCOPE=SPFILE SID='*';
ALTER SYSTEM SET sga_target='22G' SCOPE=SPFILE SID='*';
ALTER SYSTEM SET sga_max_size='22G' SCOPE=SPFILE SID='*';



 $ORACLE_HOME/OPatch/./opatch auto  /opt/app/software/patch/Patch_Q3/29698727 -oh /opt/app/11.2.0/grid_1 -ocmrf $ORACLE_HOME/dbs/ocm.rsp
 $ORACLE_HOME/OPatch/./opatch auto  /opt/app/software/patch/Patch_Q3/29698727 -oh /opt/app/oracle/product/11.2.0/dbhome_2 -ocmrf $ORACLE_HOME/dbs/ocm.rsp

 
 
$ORACLE_HOME/OPatch/./opatch auto  /opt/app/software/patch/Patch_Q3/29698727 -oh /opt/app/11.2.0/grid_1  -rollback -ocmrf $ORACLE_HOME/dbs/ocm.rsp
$ORACLE_HOME/OPatch/./opatch auto  /opt/app/software/patch/Patch_Q3/29698727 -oh /opt/app/oracle/product/11.2.0/dbhome_2  -rollback -ocmrf $ORACLE_HOME/dbs/ocm.rsp

 
 
 @?/rdbms/admin/catbundle_PSU_TRANSITR_ROLLBACK.sql
 
 
pbrun -h wpl1trandbrpt1.tsysacquiring.org  su - 
pbrun -h wpl1trandbrpt2.tsysacquiring.org  su - 
pbrun -h wpl1trandbrpt3.tsysacquiring.org  su - 

pbrun -h wpl1trandbtxn1.tsysacquiring.org  su - 
pbrun -h wpl1trandbtxn2.tsysacquiring.org  su - 
pbrun -h wpl1trandbtxn3.tsysacquiring.org  su - 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 opatch auto <UNZIPPED_PATCH_LOCATION>/29698727 -oh <GI_HOME> -rollback -ocmrf <ocm response file>
 
 
 
/opt/app/11.2.0/grid_1/OPatch/./opatch lsinventory | grep applied
/opt/app/oracle/product/11.2.0/dbhome_2/OPatch/./opatch lsinventory | grep applied 


@?/rdbms/admin/catbundle.sql psu apply
@?/rdbms/admin/utlrp.sql

 
chmod -R 777 /opt/app/11.2.0/grid_1/dbs/ocm.rsp
chmod -R 777 /opt/app/oracle/product/11.2.0/dbhome_2/dbs/ocm.rsp
$ORACLE_HOME/OPatch/ocm/bin/emocmrsp  -no_banner -output $ORACLE_HOME/dbs/ocm.rsp



ALTER SYSTEM SET pga_aggregate_target=7G SCOPE=SPFILE SID='*';
ALTER SYSTEM SET sga_target=22G SCOPE=SPFILE SID='*';
ALTER SYSTEM SET sga_max_size=22G SCOPE=SPFILE SID='*';


wpl1trandbrpt3.tsysacquiring.org:/home/oracle> /opt/app/11.2.0/grid_1/OPatch/./opatch lsinventory | grep applied
Patch  29497421     : applied on Sun Oct 06 23:39:00 PDT 2019
Patch  29141201     : applied on Sun Oct 06 23:38:09 PDT 2019
Patch  25803774     : applied on Mon Sep 17 01:18:53 PDT 2018
wpl1trandbrpt3.tsysacquiring.org:/home/oracle> /opt/app/oracle/product/11.2.0/dbhome_2/OPatch/./opatch lsinventory | grep applied
Patch  29497421     : applied on Sun Oct 06 23:39:00 PDT 2019
Patch  29141201     : applied on Sun Oct 06 23:38:09 PDT 2019
Patch  25803774     : applied on Mon Sep 17 01:18:53 PDT 2018
wpl1trandbrpt3.tsysacquiring.org:/home/oracle>
wpl1trandbrpt3.tsysacquiring.org:/home/oracle>

wpl1trandbtxn1.tsysacquiring.org:/home/oracle> /opt/app/11.2.0/grid_1/OPatch/./opatch lsinventory | grep applied
Patch  29497421     : applied on Sun Oct 06 23:35:55 PDT 2019
Patch  29141201     : applied on Sun Oct 06 23:35:05 PDT 2019
Patch  25803774     : applied on Mon Sep 17 01:02:11 PDT 2018
wpl1trandbtxn1.tsysacquiring.org:/home/oracle> /opt/app/oracle/product/11.2.0/dbhome_2/OPatch/./opatch lsinventory | grep applied
Patch  29497421     : applied on Sun Oct 06 23:35:55 PDT 2019
Patch  29141201     : applied on Sun Oct 06 23:35:05 PDT 2019
Patch  25803774     : applied on Mon Sep 17 01:02:11 PDT 2018






























1.DC MOVE FROM west  to east  Then east to West 
2.application start/stop PG2298
3.apps down west indsys

10/13/19 21:00:00 
10/14/19 05:00:00




scp p6880880_112000_Linux-x86-64.zip oracle@wpl1trandbrpt1.tsysacquiring.org:/opt/app/software/patch/Patch_Q3
scp p6880880_112000_Linux-x86-64.zip oracle@wpl1trandbrpt2.tsysacquiring.org:/opt/app/software/patch/Patch_Q3
scp p6880880_112000_Linux-x86-64.zip oracle@wpl1trandbrpt3.tsysacquiring.org:/opt/app/software/patch/Patch_Q3
scp p6880880_112000_Linux-x86-64.zip oracle@wpl1trandbtxn1.tsysacquiring.org:/opt/app/software/patch/Patch_Q3
scp p6880880_112000_Linux-x86-64.zip oracle@wpl1trandbtxn2.tsysacquiring.org:/opt/app/software/patch/Patch_Q3
scp p6880880_112000_Linux-x86-64.zip oracle@wpl1trandbtxn3.tsysacquiring.org:/opt/app/software/patch/Patch_Q3

scp vishalbh@10.100.101.20:/software/oracle/SOFTWARE/OPatch/Q3_patch/p29698727_112040_Linux-x86-64.zip .





$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch/Patch_Q3/29698727/29141201  > /tmp/db_29141201.log
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch/Patch_Q3/29698727/29497421  > /tmp/db_29497421.log
$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /opt/app/software/patch/Patch_Q3/29698727/29509309  > /tmp/db_29509309.log

  
  /opt/app/oracle/product/11.2.0/dbhome_2/OPatch/./opatch version
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
step 1 :

ALTER TABLE TRANSNOX_CPASS.TRANS_SETTLEMENT PCTFREE 20 INITRANS 30;
ALTER TABLE TRANSNOX_CPASS.TRANS_SETTLEMENT MOVE  TABLESPACE  CPASS_DATA_TBLS ;


ALTER INDEX TRANSNOX_CPASS.PK_TRANS_SETTLEMENT REBUILD ONLINE PCTFREE 20 INITRANS 32;
EXEC DBMS_STATS.gather_table_stats('TRANSNOX_CPASS', 'TRANS_SETTLEMENT');





ALTER TABLE t1 MOVE ONLINE TABLESPACE users;

-- Change table compression.
ALTER TABLE t1 MOVE ONLINE TABLESPACE users COMPRESS UPDATE INDEXES;
ALTER TABLE t1 MOVE ONLINE TABLESPACE users NOCOMPRESS UPDATE INDEXES;

-- Change storage parameters.
ALTER TABLE t1 MOVE ONLINE STORAGE (PCTINCREASE 0);


