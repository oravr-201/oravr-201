2019-06-17 03:23:45  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094421.
2019-06-17 03:23:46  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:23:54  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:23:56  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:23:58  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:24:00  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:24:00  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094422.
2019-06-17 03:24:15  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094423.
2019-06-17 03:24:18  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:24:30  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094424.
2019-06-17 03:24:46  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094425.
2019-06-17 03:24:51  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): ALTER extract PPTETW  BEGIN 2019-06-17 01:00:00.
2019-06-17 03:24:58  ERROR   OGG-01117  Oracle GoldenGate Command Interpreter for Oracle:  Received signal: Program interrupt (2).
2019-06-17 03:24:58  ERROR   OGG-01668  Oracle GoldenGate Command Interpreter for Oracle:  PROCESS ABENDING.
2019-06-17 03:25:00  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094426.
2019-06-17 03:25:07  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:25:10  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:25:12  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:25:14  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:25:16  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094427.
2019-06-17 03:25:20  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): stop PPTETW.
2019-06-17 03:25:21  INFO    OGG-01021  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Command received from GGSCI: STOP.
2019-06-17 03:25:26  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:25:31  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094428.
2019-06-17 03:25:33  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): stop PPTETW.
2019-06-17 03:25:33  INFO    OGG-01021  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Command received from GGSCI: FORCESTOP.
2019-06-17 03:25:33  WARNING OGG-00990  Oracle GoldenGate Capture for Oracle, pptetw.prm:  EXTRACT PPTETW stop forced by user.
2019-06-17 03:25:36  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:25:41  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:25:54  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): ALTER extract PPTETW  BEGIN 2019-06-17 01:00:00.
2019-06-17 03:25:59  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): start PPTETW.
2019-06-17 03:25:59  INFO    OGG-00963  Oracle GoldenGate Manager for Oracle, mgr.prm:  Command received from GGSCI on host [10.50.50.161]:16591 (START EXTRACT PPTETW ).
2019-06-17 03:25:59  INFO    OGG-00975  Oracle GoldenGate Manager for Oracle, mgr.prm:  EXTRACT PPTETW starting.
2019-06-17 03:25:59  INFO    OGG-00992  Oracle GoldenGate Capture for Oracle, pptetw.prm:  EXTRACT PPTETW starting.
2019-06-17 03:25:59  INFO    OGG-03035  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Operating system character set identified as UTF-8. Locale: en_US, LC_ALL:.
2019-06-17 03:25:59  INFO    OGG-02696  Oracle GoldenGate Capture for Oracle, pptetw.prm:  NON-ANSI SQL parameter syntax is used for parameter parsing.
2019-06-17 03:25:59  INFO    OGG-01815  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Virtual Memory Facilities for: COM
    anon alloc: mmap(MAP_ANON)  anon free: munmap
    file alloc: mmap(MAP_SHARED)  file free: munmap
    target directories:
    /acfs/goldengate/dirtmp.
2019-06-17 03:25:59  INFO    OGG-01014  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Positioning with begin time: Jun 17, 2019 1:00:00 AM, starting record time: Jun 17, 2019 1:01:29 AM at extseqno 96097, extrba 10905688.
2019-06-17 03:25:59  INFO    OGG-00993  Oracle GoldenGate Capture for Oracle, pptetw.prm:  EXTRACT PPTETW started.
2019-06-17 03:26:00  WARNING OGG-01931  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Datastore 'dirbdb' cannot be opened. Error 2 (No such file or directory).
2019-06-17 03:26:03  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:04  INFO    OGG-01226  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Socket buffer size set to 27985 (flush size 27985).
2019-06-17 03:26:05  INFO    OGG-01056  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Recovery initialization completed for target file /acfs/goldengate/dirdat/EB094428, at RBA 13556342, CSN 71721766834.
2019-06-17 03:26:05  INFO    OGG-01478  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Output file /acfs/goldengate/dirdat/EB is using format RELEASE 11.2.
2019-06-17 03:26:05  WARNING OGG-01438  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Checkpoint marked as from graceful shutdown, but records found after checkpoint in trail /acfs/goldengate/dirdat/EB.  Expected EOF Seqno 94052, RBA 0.  Found Seqno 94428, RBA 13556342.
2019-06-17 03:26:05  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Rolling over remote file /acfs/goldengate/dirdat/EB094429.
2019-06-17 03:26:05  INFO    OGG-01054  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Recovery completed for target file /acfs/goldengate/dirdat/EB094429, at RBA 1566, CSN 71721766834.
2019-06-17 03:26:05  INFO    OGG-01057  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Recovery completed for all targets.
2019-06-17 03:26:06  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:08  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:09  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:10  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:11  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:26:11  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:12  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:13  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:14  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:26:15  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:15  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:26:16  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:17  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info all.
2019-06-17 03:26:17  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:18  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
2019-06-17 03:26:19  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): info PPTETW.
