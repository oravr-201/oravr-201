
set define off
set pause on

prompt
prompt
prompt **************************************************************************
prompt **************************************************************************
prompt
prompt    =====================================
prompt
prompt
prompt
prompt    To continue press Enter. To quit press Ctrl-C.
prompt
prompt
prompt
prompt **************************************************************************
prompt **************************************************************************
prompt
prompt


prompt

prompt    vb Installer: Privileges
prompt    ===========================

grant create view to VISHALBH;
grant create type to VISHALBH;
grant create table to VISHALBH;
grant create procedure to VISHALBH;
grant execute on sys.dbms_lock to VISHALBH;
grant select on  sys.v_$database to VISHALBH;
grant select on  sys.gv_$session to VISHALBH;
grant select on  sys.v_$session to VISHALBH;
grant select on  sys.gv_$statname to VISHALBH;
grant select on  sys.v_$statname to VISHALBH;
grant select on  sys.gv_$sysstat to VISHALBH;
grant select on  sys.v_$sysstat to VISHALBH;
grant select on  sys.gv_$osstat to VISHALBH;
grant select on  sys.v_$osstat to VISHALBH;
grant select on  sys.gv_$timer to VISHALBH;
grant select on  sys.v_$timer to VISHALBH;
grant select on  sys.gv_$sql to VISHALBH;
grant select on  sys.v_$sql to VISHALBH;


prompt Creating types...
prompt    ===========================

create type vb_v2_ntt as table of varchar2(4000);
/


create type vb_output_ot as object
( output varchar2(4000)
);
/


create type vb_output_ntt as table of vb_output_ot;
/


create type vb_ash_ot as object
( inst_id                       number
, snaptime                      timestamp
, saddr                         raw(8)
, sid                           number
, serial#                       number
, audsid                        number
, paddr                         raw(8)
, user#                         number
, username                      varchar2(64)
, command                       number
, ownerid                       number
, taddr                         varchar2(64)
, lockwait                      varchar2(64)
, status                        varchar2(64)
, server                        varchar2(64)
, schema#                       number
, schemaname                    varchar2(64)
, osuser                        varchar2(64)
, process                       varchar2(64)
, machine                       varchar2(64)
, terminal                      varchar2(64)
, program                       varchar2(64)
, type                          varchar2(64)
, sql_address                   raw(8)
, sql_hash_value                number
, sql_id                        varchar2(64)
, sql_child_number              number
, prev_sql_addr                 raw(8)
, prev_hash_value               number
, prev_sql_id                   varchar2(64)
, prev_child_number             number
, module                        varchar2(64)
, module_hash                   number
, action                        varchar2(64)
, action_hash                   number
, client_info                   varchar2(64)
, fixed_table_sequence          number
, row_wait_obj#                 number
, row_wait_file#                number
, row_wait_block#               number
, row_wait_row#                 number
, logon_time                    date
, last_call_et                  number
, pdml_enabled                  varchar2(64)
, failover_type                 varchar2(64)
, failover_method               varchar2(64)
, failed_over                   varchar2(64)
, resource_consumer_group       varchar2(64)
, pdml_status                   varchar2(64)
, pddl_status                   varchar2(64)
, pq_status                     varchar2(64)
, current_queue_duration        number
, client_identifier             varchar2(64)
, blocking_session_status       varchar2(64)
, blocking_instance             number
, blocking_session              number
, seq#                          number
, event#                        number
, event                         varchar2(64)
, p1text                        varchar2(64)
, p1                            number
, p1raw                         raw(8)
, p2text                        varchar2(64)
, p2                            number
, p2raw                         raw(8)
, p3text                        varchar2(64)
, p3                            number
, p3raw                         raw(8)
, wait_class_id                 number
, wait_class#                   number
, wait_class                    varchar2(64)
, wait_time                     number
, seconds_in_wait               number
, state                         varchar2(64)
, service_name                  varchar2(64)
, sql_trace                     varchar2(64)
, sql_trace_waits               varchar2(64)
, sql_trace_binds               varchar2(64)
);
/


create type vb_ash_ntt as table of vb_ash_ot;
/


create type vb_stat_ot as object
( inst_id number
, type  varchar2(100)
, name  varchar2(100)
, value number 
);
/

create type vb_stat_ntt as table of vb_stat_ot;
/

create type ash_aas_ot as object
( aas       number
, cpu_aas   number 
, io_aas    number
);
/

create type ash_aas_ntt is table of ash_aas_ot;
/

create type ash_graph_ot as object
( graph   varchar2(100))
;
/

create type ash_graph_ntt is table of ash_graph_ot;
/


prompt Creating package...
prompt    ===========================

create or replace package vb as

   -- --------------------------------------------------------------------------

   -- Pipelined function to show TOP instance summary activity. The refresh rate
   -- defines how many ASH/SYSSTAT samples to take and is roughly equivalent to
   -- the number of seconds between screen refreshes...
   -- --------------------------------------------------------------------------
   function top (
            p_refresh_rate    in integer default null,
            p_screen_size     in integer default null,
            p_ash_height      in integer default null,
            p_sql_height      in integer default null,
            p_ash_window_size in integer default null
            ) return vb_output_ntt pipelined;

   -- Helper procedure to size window to TOP output...
   -- --------------------------------------------------------------------------
   procedure format_window;

   -- Internal Use Only
   -- -----------------
   -- All functions and procedures from this point onwards are for internal use
   -- only in v1.01. Some of these will be exposed in future versions of vb.

   -- Pipelined function to return dynamic samples, queries, aggregations etc
   -- of active session data. The refresh rate defines (in seconds) how many
   -- ASH samples to take before running the query components...
   -- --------------------------------------------------------------------------
   function ash (
            p_refresh_rate in integer  default null,
            p_select       in varchar2 default null,
            p_where        in varchar2 default null,
            p_group_by     in varchar2 default null,
            p_order_by     in varchar2 default null
            ) return vb_output_ntt pipelined;

   -- Until 11g you can't bind UDTs into DBMS_SQL cursors, so this is an
   -- internal workaround. Can also be used to query all of the collected ASH
   -- samples. Note that gc_all_rows returns all ASH records between the two
   -- snapshots and gc_deltas returns only the lower and upper snapshots...
   -- --------------------------------------------------------------------------
   gc_all_rows constant pls_integer := 0;
   gc_deltas   constant pls_integer := 1;

   function get_ash (
            p_lower_snap in pls_integer default null,
            p_upper_snap in pls_integer default null,
            p_return_set in pls_integer default vb.gc_all_rows
            ) return vb_ash_ntt pipelined;

   -- Constants, get/set for vb parameters such as polling rate, ASH size...
   -- --------------------------------------------------------------------------
   gc_ash_polling_rate constant pls_integer := 0;
   gc_ash_threshold    constant pls_integer := 1;
   gc_top_refresh_rate constant pls_integer := 2;
   gc_ash_window_size  constant pls_integer := 3;

   procedure set_parameter(
             p_parameter_code  in pls_integer,
             p_parameter_value in integer
             );

   function get_parameter(
            p_parameter_code in pls_integer
            ) return integer;

   procedure restore_default_parameters;

   -- Debugging...
   -- --------------------------------------------------------------------------
   procedure show_snaps;

end vb;
/

-- ----------------------------------------------------------------------------------
















prompt    creaating package body 

prompt    ===========================



CREATE OR REPLACE PACKAGE BODY VISHALBH.VB AS

   -- Internal types and global arrays for caching collections of
   -- SYSSTAT/ASH data for querying within vb...
   -- ------------------------------------------------------------------
   TYPE vb_stat_ntt_aat IS TABLE OF vb_stat_ntt
      INDEX BY PLS_INTEGER;
   g_stats vb_stat_ntt_aat;

   TYPE vb_ash_ntt_aat IS TABLE OF vb_ash_ntt
      INDEX BY PLS_INTEGER;
   g_ash vb_ash_ntt_aat;

   -- Internal type and variable for storing simple vb parameters...
   -- -----------------------------------------------------------------
   TYPE parameter_aat IS TABLE OF integer
      INDEX BY PLS_INTEGER;
   g_params parameter_aat;

   -- Variables for maintaining ASH/SYSSTAT collections...
   -- ----------------------------------------------------
   g_ash_size  PLS_INTEGER := 0;
   g_stat_size PLS_INTEGER := 0;

   -- global variable for screen size
   -- ----------------------------------------------------
   g_screen_size       PLS_INTEGER;

   -- General constants...
   -- --------------------
   gc_space       CONSTANT vb_output_ot := vb_output_ot(NULL);
   gc_mb          CONSTANT PLS_INTEGER     := 1048576;
   gc_gb          CONSTANT PLS_INTEGER     := 1048576*1024;
   gc_newline     CONSTANT varchar2(1)     := CHR(10);

   gc_cpu         CONSTANT varchar2(1)     := '+';
   gc_io          CONSTANT varchar2(1)     := '*';
   gc_others      CONSTANT varchar2(1)     := '@';

   gc_cpu_color_prefix        CONSTANT varchar2(50)    := CHR(27) || '[38;5;46m';
   gc_io_color_prefix         CONSTANT varchar2(50)    := CHR(27) || '[38;5;21m';
   gc_others_color_prefix     CONSTANT varchar2(50)    := CHR(27) || '[38;5;124m';
   gc_color_postfix           CONSTANT varchar2(50)    := CHR(27) || '[0m';

   gc_max_screen_size      CONSTANT PLS_INTEGER     := 100;
   gc_default_screen_size  CONSTANT PLS_INTEGER     := 40;
   gc_default_ash_height   CONSTANT PLS_INTEGER     := 13;
   gc_default_sql_height   CONSTANT PLS_INTEGER     := 8;
   gc_ash_graph_length     CONSTANT PLS_INTEGER     := 86;
   gc_screen_width         CONSTANT PLS_INTEGER     := 175;

   -- variables for dealing with Active Session Graph
   -- ----------------------------------------------------
   g_ash_aas      ash_aas_ntt    := ash_aas_ntt();
   g_ash_graph    ash_graph_ntt  := ash_graph_ntt();
   g_ash_idx      PLS_INTEGER;
   g_ash_height   PLS_INTEGER;
   g_sql_height   PLS_INTEGER;

   g_ash_spaces        varchar2(100);
   g_ash_scales_height PLS_INTEGER;

   TYPE ash_lines_aat IS TABLE OF varchar2(4000);
   g_ash_lines ash_lines_aat := ash_lines_aat();
   g_ash_lines_color ash_lines_aat := ash_lines_aat();

   TYPE ash_scales_aat IS TABLE OF integer;
   g_ash_scales ash_scales_aat := ash_scales_aat();

   g_max_aas_current   PLS_INTEGER;

   ----------------------------------------------------------------------------
   PROCEDURE P( p_str IN varchar2 ) IS
   BEGIN
      DBMS_OUTPUT.PUT_LINE(p_str);
   END P;

   ----------------------------------------------------------------------------
   PROCEDURE po( p_str IN vb_output_ot ) IS
   BEGIN
      p(p_str.output);
   END po;

--   ----------------------------------------------------------------------------
--   procedure dump_ash is
--      pragma autonomous_transaction;
--   begin
--      insert into vb_ash_dump select * from table(vb.get_ash);
--      commit;
--   end dump_ash;

   ----------------------------------------------------------------------------
   FUNCTION to_color( p_str IN varchar2 ) RETURN varchar2 IS
   v_str varchar2(4000);
   BEGIN
      v_str := REGEXP_REPLACE(p_str, '(\' || gc_cpu    || '[\' || gc_cpu    || ' ]*)', gc_cpu_color_prefix    || '\1' || gc_color_postfix);
      v_str := REGEXP_REPLACE(v_str, '(\' || gc_io     || '[\' || gc_io     || ' ]*)', gc_io_color_prefix     || '\1' || gc_color_postfix);
      v_str := REGEXP_REPLACE(v_str, '(\' || gc_others || '[\' || gc_others || ' ]*)', gc_others_color_prefix || '\1' || gc_color_postfix);
      RETURN v_str;
   END to_color;

   ----------------------------------------------------------------------------
   FUNCTION to_color_ash( p_str IN varchar2 ) RETURN varchar2 IS
   v_str varchar2(4000);
   BEGIN
      v_str := REGEXP_REPLACE(p_str, '(\' || gc_cpu    || '[\' || gc_cpu    || ' ]*)', gc_cpu_color_prefix    || '\1');
      v_str := REGEXP_REPLACE(v_str, '(\' || gc_io     || '[\' || gc_io     || ' ]*)', gc_io_color_prefix     || '\1');
      v_str := REGEXP_REPLACE(v_str, '(\' || gc_others || '[\' || gc_others || ' ]*)', gc_others_color_prefix || '\1');
      RETURN v_str || gc_color_postfix;
   END to_color_ash;

   ----------------------------------------------------------------------------
   PROCEDURE show_snaps IS
      v_indx PLS_INTEGER;
   BEGIN
      p('ASH snaps...');
      p('------------------------------------');
      v_indx := g_ash.first;
      WHILE v_indx IS NOT NULL LOOP
         p(UTL_LMS.FORMAT_MESSAGE('Index=[%d] Count=[%d]', v_indx, g_ash(v_indx).COUNT));
         v_indx := g_ash.next(v_indx);
      END LOOP;
      p('STAT snaps...');
      p('------------------------------------');
      v_indx := g_stats.first;
      WHILE v_indx IS NOT NULL LOOP
         p(UTL_LMS.FORMAT_MESSAGE('Index=[%d] Count=[%d]', v_indx, g_stats(v_indx).COUNT));
         v_indx := g_stats.next(v_indx);
      END LOOP;
   END show_snaps;

   ----------------------------------------------------------------------------
   FUNCTION banner RETURN vb_output_ntt IS
   BEGIN
      RETURN vb_output_ntt(
                vb_output_ot('-----------------------------------'),
                vb_output_ot('---------   Welcome VB   ----------')
                );
   END banner;

   ----------------------------------------------------------------------------
   FUNCTION to_string ( p_collection IN vb_v2_ntt,
                        p_delimiter  IN varchar2 DEFAULT ',',
                        p_elements   IN PLS_INTEGER DEFAULT NULL ) RETURN varchar2 IS
      v_str varchar2(4000);
   BEGIN
      FOR I IN 1 .. LEAST(NVL(p_elements, p_collection.count), p_collection.count) LOOP
         v_str := v_str || p_delimiter || p_collection(I);
      END LOOP;
      RETURN LTRIM(v_str, p_delimiter);
   END to_string;

   ----------------------------------------------------------------------------
   PROCEDURE format_window IS
      v_banner   vb_output_ntt := banner();
      c_boundary varchar2(110)    := RPAD('-',110,'-');
      PROCEDURE spaces( p_spaces IN PLS_INTEGER ) IS
      BEGIN
         FOR I IN 1 .. p_spaces LOOP
            po(gc_space);
         END LOOP;
      END spaces;
   BEGIN
      p(c_boundary);
      spaces(2);
      FOR I IN 1 .. v_banner.count LOOP
         p(v_banner(I).output);
      END LOOP;
      spaces(3);
      p('       vb.FORMAT_WINDOW');
      p('       -------------------');
      p('       Align sqlplus window size to dotted lines for optimal output');
      spaces(g_screen_size-10);
      p(c_boundary);
   END format_window;

   ----------------------------------------------------------------------------
   PROCEDURE set_parameter( p_parameter_code  IN PLS_INTEGER,
                            p_parameter_value IN integer ) IS
   BEGIN
      g_params(p_parameter_code) := p_parameter_value;
   END set_parameter;

   ----------------------------------------------------------------------------
   FUNCTION get_parameter ( p_parameter_code IN PLS_INTEGER ) RETURN integer IS
   BEGIN
      RETURN g_params(p_parameter_code);
   END get_parameter;

   ----------------------------------------------------------------------------
   PROCEDURE restore_default_parameters IS
   BEGIN
      set_parameter(VB.GC_ASH_POLLING_RATE, 1);
      set_parameter(VB.GC_ASH_THRESHOLD, 20000);
      set_parameter(VB.GC_TOP_REFRESH_RATE, 10);
      -- By default don't use a trailing ASH window
      set_parameter(VB.GC_ASH_WINDOW_SIZE, NULL);
   END restore_default_parameters;

   ----------------------------------------------------------------------------
   PROCEDURE init_screen_variables( p_screen_size  IN PLS_INTEGER,
                                    p_ash_height   IN PLS_INTEGER,
                                    p_sql_height   IN PLS_INTEGER) IS
      v_max_height PLS_INTEGER;
   BEGIN

      -- Initial the screen size variable and some sanity check ...
      -- -----------------------------------------------------------
      IF ( p_screen_size IS NULL OR p_screen_size <= gc_default_screen_size OR p_screen_size > gc_max_screen_size) THEN
         g_screen_size := gc_default_screen_size;
      ELSE
         g_screen_size := p_screen_size;
      END IF;

      v_max_height := (2/3) * g_screen_size;

      IF ( p_ash_height IS NULL OR p_ash_height <= gc_default_ash_height OR p_ash_height > v_max_height ) THEN
         g_ash_height := gc_default_ash_height;
      ELSE
         g_ash_height := p_ash_height;
      END IF;

      IF ( p_sql_height IS NULL OR p_sql_height <= gc_default_sql_height OR p_sql_height > v_max_height ) THEN
         g_sql_height := gc_default_sql_height;
      ELSE
         g_sql_height := p_sql_height;
      END IF;
   END init_screen_variables;

   ----------------------------------------------------------------------------
   PROCEDURE init_ash_graph_variables IS
   BEGIN

      g_ash_spaces         := LPAD(' ', g_ash_height, ' ');
      g_ash_scales_height  := g_ash_height + 1;
      g_ash_idx            := 1;
      g_max_aas_current    := g_ash_height;
      g_ash_aas.extend(gc_ash_graph_length);
      g_ash_graph.extend(gc_ash_graph_length);
      g_ash_lines.extend(g_ash_height);
      g_ash_lines_color.extend(g_ash_height);
      g_ash_scales.extend(g_ash_scales_height);

      FOR I IN 1 .. g_ash_aas.count LOOP
         g_ash_aas(I) := ash_aas_ot(0, 0, 0);
      END LOOP;

      FOR I IN 1 .. g_ash_graph.count LOOP
         g_ash_graph(I) := ash_graph_ot(g_ash_spaces);
      END LOOP;

      FOR I IN 1 .. g_ash_lines.count LOOP
         g_ash_lines(I) := LPAD(' ', gc_ash_graph_length);
      END LOOP;
      FOR I IN 1 .. g_ash_scales.count LOOP
         g_ash_scales(I) := g_ash_scales_height - I + 1;
      END LOOP;
   END init_ash_graph_variables;

   ----------------------------------------------------------------------------
   FUNCTION get_sql( p_select   IN varchar2,
                     p_from     IN varchar2,
                     p_where    IN varchar2,
                     p_group_by IN varchar2,
                     p_order_by IN varchar2 ) RETURN varchar2 IS
      v_sql varchar2(32767);
   BEGIN
      v_sql := 'select ' || NVL(p_select, '*') || ' from ' || p_from;
      IF p_where IS NOT NULL THEN
         v_sql := v_sql || ' where ' || p_where;
      END IF;
      IF p_group_by IS NOT NULL THEN
         v_sql := v_sql || ' group by ' || p_group_by;
      END IF;
      IF p_order_by IS NOT NULL THEN
         v_sql := v_sql || ' order by ' || p_order_by;
      END IF;
      RETURN v_sql;
   END get_sql;

   ----------------------------------------------------------------------------
   FUNCTION ash_history RETURN interval DAY TO SECOND IS
   BEGIN
      RETURN g_ash(g_ash.last)(1).snaptime - g_ash(g_ash.first)(1).snaptime;
   END ash_history;

   ----------------------------------------------------------------------------
   FUNCTION ash_snap_count( p_lower_snap IN PLS_INTEGER,
                              p_upper_snap IN PLS_INTEGER ) RETURN PLS_INTEGER IS
      v_snap_cnt  PLS_INTEGER := 0;
      v_snap      PLS_INTEGER;
      v_exit      BOOLEAN := FALSE;
   BEGIN
      v_snap := p_lower_snap;
      WHILE v_snap IS NOT NULL AND NOT v_exit LOOP
         v_snap_cnt := v_snap_cnt + 1;
         v_exit := (v_snap = p_upper_snap);
         v_snap := g_ash.next(v_snap);
      END LOOP;
      RETURN GREATEST(v_snap_cnt,1);
   END ash_snap_count;

   ----------------------------------------------------------------------------
   FUNCTION ash_sample_count( p_lower_snap IN PLS_INTEGER,
                              p_upper_snap IN PLS_INTEGER ) RETURN PLS_INTEGER IS
      v_samples PLS_INTEGER := 0;
      v_snap    PLS_INTEGER;
      v_exit    BOOLEAN := FALSE;
   BEGIN
      v_snap := p_lower_snap;
      WHILE v_snap IS NOT NULL AND NOT v_exit LOOP
         -- Ignore dummy record and the record which is deleted by maintain_ash_collection
         IF NOT ( (NOT g_ash.exists(v_snap)) OR (g_ash(v_snap).COUNT = 1 AND g_ash(v_snap)(1).SID IS NULL)) THEN
            v_samples := v_samples + g_ash(v_snap).COUNT;
         END IF;
         v_exit := (v_snap = p_upper_snap);
         v_snap := g_ash.next(v_snap);
      END LOOP;
      RETURN GREATEST(v_samples,1);
   END ash_sample_count;

   ----------------------------------------------------------------------------
   PROCEDURE maintain_ash_collection( p_index IN PLS_INTEGER ) IS
   BEGIN
      IF g_ash(p_index).COUNT = 0 THEN
         g_ash.delete(p_index);
      ELSE
         g_ash_size := g_ash_size + g_ash(p_index).COUNT;
         WHILE g_ash_size > g_params(VB.GC_ASH_THRESHOLD) LOOP
            g_ash_size := g_ash_size - g_ash(g_ash.first).COUNT;
            g_ash.delete(g_ash.first);
         END LOOP;
      END IF;
   END maintain_ash_collection;

   ----------------------------------------------------------------------------
   PROCEDURE snap_ash( p_index IN PLS_INTEGER ) IS
      v_sql_template varchar2(32767);
      v_sql          varchar2(32767);
   BEGIN

      -- TODO: conditional compilation to get correct column list for version or
      -- select a small bunch of useful columns

      -- Use dynamic SQL to avoid explicit grants on V$SESSION. Prepare the start
      -- of the SQL as it will be used twice...
      -- ------------------------------------------------------------------------
      v_sql_template := q'[select vb_ash_ot(
                                     inst_id, systimestamp, saddr, %sid%, serial#, audsid, paddr,
                                     user#, username, command, ownerid, taddr, lockwait,
                                     status, server, schema#, schemaname, osuser,
                                     process, machine, terminal, program, type,
                                     sql_address, sql_hash_value, sql_id, sql_child_number,
                                     prev_sql_addr, prev_hash_value, prev_sql_id,
                                     prev_child_number, module, module_hash, action,
                                     action_hash, client_info, fixed_table_sequence,
                                     row_wait_obj#, row_wait_file#, row_wait_block#,
                                     row_wait_row#, logon_time, last_call_et, pdml_enabled,
                                     failover_type, failover_method, failed_over,
                                     resource_consumer_group, pdml_status, pddl_status,
                                     pq_status, current_queue_duration, client_identifier,
                                     blocking_session_status, blocking_instance,
                                     blocking_session, seq#, event#, case when state = 'WAITING' then event else 'ON CPU' end, p1text, p1,
                                     p1raw, p2text, p2, p2raw, p3text, p3, p3raw,
                                     wait_class_id, wait_class#, case when state = 'WAITING' then wait_class else 'ON CPU' end, wait_time,
                                     seconds_in_wait, state, service_name, sql_trace,
                                     sql_trace_waits, sql_trace_binds
                                     )
                           from   gv$session
                           where  %preds%]';

      v_sql := REPLACE( v_sql_template, '%sid%', 'sid');
      v_sql := REPLACE( v_sql, '%preds%',  q'[    status = 'ACTIVE'
                                              and (wait_class != 'Idle' or state != 'WAITING')
                                              and (sql_id is null or (sql_id not in (select sql_id from v$session where sid=sys_context('userenv', 'sid')))) ]' );

      EXECUTE IMMEDIATE v_sql BULK COLLECT INTO g_ash(p_index);

      -- If we have nothing to snap, add a dummy record that will be ignored
      -- in GET_ASH and GET_ASH_SAMPLE_COUNT...
      -- -------------------------------------------------------------------
      IF g_ash(p_index).COUNT = 0 THEN
         v_sql := REPLACE( v_sql_template, '%sid%', 'null');
         v_sql := REPLACE( v_sql, '%preds%', q'[(inst_id, sid) in (select sys_context('userenv', 'instance'), sys_context('userenv', 'sid') from dual)]' );
         EXECUTE IMMEDIATE v_sql BULK COLLECT INTO g_ash(p_index);
      END IF;

      maintain_ash_collection(p_index);

   END snap_ash;

   ----------------------------------------------------------------------------
   PROCEDURE reset_stats_collection IS
   BEGIN
      g_stats.delete;
   END reset_stats_collection;

   ----------------------------------------------------------------------------
   PROCEDURE snap_stats( p_index IN PLS_INTEGER,
                         p_reset IN BOOLEAN DEFAULT FALSE ) IS
   BEGIN

      IF p_reset THEN
         reset_stats_collection();
      END IF;

      -- Use dynamic SQL to avoid explicit grants on V$ views...
      -- -------------------------------------------------------
      EXECUTE IMMEDIATE
         q'[select vb_stat_ot(inst_id, type, name, value)
             from (
                   select ss.inst_id, 'STAT' as type
                   ,      sn.name
                   ,      ss.value
                   from   v$statname sn
                   ,      gv$sysstat  ss
                   where  sn.statistic# = ss.statistic#
                   and    sn.name in ( 'cell flash cache read hits',
                                       'cell physical IO bytes eligible for predicate offload',
                                       'cell physical IO bytes saved by storage index',
                                       'cell physical IO interconnect bytes returned by smart scan',
                                       'execute count', 'logons cumulative', 'vb timer',
                                       'parse count (hard)', 'parse count (total)',
                                       'physical read total IO requests', 'physical read total bytes',
                                       'physical write total IO requests', 'physical write total bytes',
                                       'redo size', 'session cursor cache hits',
                                       'session logical reads', 'user calls', 'user commits')
                  union all
                  select inst_id, 'osstat' as type
                  ,      STAT_NAME
                  ,      VALUE
                  from gv$osstat
                  union all
                  select inst_id, 'TIMER'
                   ,      'vb timer'
                   ,      hsecs
                   from   gv$timer
                  )]'
      BULK COLLECT INTO g_stats(p_index);

   END snap_stats;

   ----------------------------------------------------------------------------
   FUNCTION instance_summary ( p_lower_snap IN PLS_INTEGER,
                               p_upper_snap IN PLS_INTEGER,
                               p_refresh_rate IN PLS_INTEGER ) RETURN vb_output_ntt IS

      TYPE metric IS record
      ( inst_id          number
      , VALUE            number);
      TYPE metric_total IS record
      ( VALUE            number);

      TYPE metric_aat IS TABLE OF metric
         INDEX BY PLS_INTEGER;
      TYPE metric_total_aat IS TABLE OF metric_total
         INDEX BY PLS_INTEGER;
      v_rows    vb_output_ntt := vb_output_ntt();
      v_metrics metric_aat;
      v_metrics_total metric_total_aat;
      v_secs    number;                 --<-- seconds between 2 stats snaps
      v_hivl    interval DAY TO SECOND; --<-- interval of ASH history saved
      v_hstr    varchar2(30);           --<-- formatted hh:mi:ss string of history

      TYPE heading IS TABLE OF varchar2(50);
      v_head heading := heading('Inst','CPU: idle%--usr%--sys%','Logons','Execs','Calls','Commits','sParse','hParse','ccHits','LIOs(K)','PhyRD','PhyWR','READ MB','Write MB','Redo MB','Offload%','ExSI MB','ExFCHits');
      v_headstr  varchar2(250);
      v_metric_str  varchar2(250);
      v_idx_base  number;
      v_dbname    varchar2(32);
      v_header    varchar2(200);

      v_total_cpu  number;
      v_idle_cpu   varchar2(10);
      v_usr_cpu    varchar2(10);
      v_sys_cpu    varchar2(10);

      v_offload  number;

      c_metrics  CONSTANT number := 23;
   BEGIN

      -- Get long and short v_metrics for range of stats. Order for fixed array offset...
      -- ------------------------------------------------------------------------------
      SELECT (DECODE (lwr.inst_id,0,1,lwr.inst_id)), SUM(DECODE ((upr.value - lwr.value),0,1,(upr.value - lwr.value)))
      BULK COLLECT INTO v_metrics
      FROM   TABLE(g_stats(p_lower_snap)) lwr
      ,      TABLE(g_stats(p_upper_snap)) upr
      WHERE  lwr.name = upr.name
      AND    lwr.inst_id = upr.inst_id
      AND    lwr.name IN (
                        'BUSY_TIME', 'IDLE_TIME', 'IOWAIT_TIME', 'SYS_TIME',
                        'USER_TIME', 'cell flash cache read hits',
                        'cell physical IO bytes eligible for predicate offload',
                        'cell physical IO bytes saved by storage index',
                        'cell physical IO interconnect bytes returned by smart scan',
                        'execute count', 'logons cumulative', 'vb timer',
                        'parse count (hard)', 'parse count (total)',
                        'physical read total IO requests', 'physical read total bytes',
                        'physical write total IO requests', 'physical write total bytes',
                        'redo size', 'session cursor cache hits',
                        'session logical reads', 'user calls', 'user commits')
      GROUP BY lwr.name,lwr.inst_id
--      GROUP BY lwr.name
      ORDER  BY
             lwr.inst_id,
             lwr.name;

      SELECT SUM(DECODE ((upr.value - lwr.value),0,1,(upr.value - lwr.value)))
      BULK COLLECT INTO v_metrics_total
      FROM   TABLE(g_stats(p_lower_snap)) lwr
      ,      TABLE(g_stats(p_upper_snap)) upr
      WHERE  lwr.name = upr.name
      AND    lwr.inst_id = upr.inst_id
      AND    lwr.name IN (
                        'BUSY_TIME', 'IDLE_TIME', 'IOWAIT_TIME', 'SYS_TIME',
                        'USER_TIME', 'cell flash cache read hits',
                        'cell physical IO bytes eligible for predicate offload',
                        'cell physical IO bytes saved by storage index',
                        'cell physical IO interconnect bytes returned by smart scan',
                        'execute count', 'logons cumulative', 'vb timer',
                        'parse count (hard)', 'parse count (total)',
                        'physical read total IO requests', 'physical read total bytes',
                        'physical write total IO requests', 'physical write total bytes',
                        'redo size', 'session cursor cache hits',
                        'session logical reads', 'user calls', 'user commits')
      GROUP BY lwr.name
      ORDER  BY
             lwr.name;

      -- 1   BUSY_TIME
      -- 2   IDLE_TIME
      -- 3   IOWAIT_TIME
      -- 4   SYS_TIME
      -- 5   USER_TIME
      -- 6   cell flash cache read hits
      -- 7   cell physical IO bytes eligible for predicate offload
      -- 8   cell physical IO bytes saved by storage index
      -- 9   cell physical IO interconnect bytes returned by smart scan
      -- 10  execute count
      -- 11  logons cumulative
      -- 12  vb timer
      -- 13  parse count (hard)
      -- 14  parse count (total)
      -- 15  physical read total IO requests
      -- 16  physical read total bytes
      -- 17  physical write total IO requests
      -- 18  physical write total bytes
      -- 19  redo size
      -- 20  session cursor cache hits
      -- 21  session logical reads
      -- 22  user calls
      -- 23  user commits

      -- Logons/s:    logon count
      -- Execs/s:     execute count
      -- sParse/s:    parse count (total)
      -- LIOs/s:      session logical reads
      -- Read MB/s:   physical read total bytes / 1048576
      -- Calls/s:     user calls
      -- hParse/s:    parse count (hard)
      -- PhyRD/s:     physical read total IO requests
      -- PhyWR/s:     physical write total IO requests
      -- Write MB/s:  physical write total bytes / 1048576
      -- History:
      -- Commits/s:   user commits
      -- ccHits/s:    session cursor cache hits
      -- Redo MB/s:   redo size
      -- Offload%:    1 - (cell physical IO interconnect bytes returned by smart scan)/(cell physical IO bytes eligible for predicate offload)
      -- ExSIMB/s:    (cell physical IO bytes saved by storage index) / 1048576
      -- ExFCHits/s:  cell flash cache read hits

      -- Calculate number of seconds...
      -- ------------------------------
      v_secs := v_metrics(12).VALUE/100;
--      v_secs := (DECODE (v_secs1,0,0.00001v_secs1));

      -- Calculate ASH history...
      -- ------------------------
      v_hivl := ash_history();
      v_hstr := TO_CHAR(EXTRACT(HOUR FROM v_hivl))   || 'h ' ||
                TO_CHAR(EXTRACT(MINUTE FROM v_hivl)) || 'm ' ||
                TO_CHAR(TRUNC(EXTRACT(SECOND FROM v_hivl))) || 's';
      SELECT NAME INTO v_dbname FROM v$DATABASE;
      v_header := '+ Database: ' || RPAD(v_dbname, 8) || RPAD('| Current Time: ' ||
                  TO_CHAR(SYSDATE, 'DD-Mon hh24:mi:ss'), 36) ||
                  RPAD('| ASH History:  ' || v_hstr, 27) || '|';
      -- Set the instance summary output...
      -- ----------------------------------

      v_rows.extend(2);
      --v_rows(1) := vb_output_ot(v_header);
      v_rows(1) := vb_output_ot(RPAD('+ Database: ' || RPAD(v_dbname, 8) || ' |' || RPAD(' Activity Statistics Per Second',33) || '|' ||
                                       RPAD(' Interval: ' || NVL(p_refresh_rate, g_params(VB.GC_TOP_REFRESH_RATE)) || 's ',17) ||  '|' ||
                                       RPAD(' Screen Window = ' || g_screen_size || ' * ' || gc_screen_width, 26) || '|' ||
                                       RPAD(' Ash Height = ' || g_ash_height, 17) || '|' ||
                                       RPAD(' SQL Height = ' || g_sql_height, 17) || '|' ||
                                       RPAD(' Arraysize should be ' || 2 * g_screen_size, 26) || '+', 172,'-') || '+');
--      v_headstr := '|Inst|CPU: idle%--usr%--sys%|';
 v_headstr := '|Inst|CPU: idle%--usr%--sys%|    Logons  |     Execs  |   Calls| Commits|      sParse|      hParse|      ccHits| LIOs(K)|         PhyRD|         PhyWR| READ MB|Write MB| Redo MB|Offload%| ExSI MB|ExFCHits|';

--      FOR I IN 3 .. v_head.count
--      LOOP
--         v_headstr := v_headstr || LPAD(v_head(I),12) || '|';
--      END LOOP;
      
      v_rows(2) := vb_output_ot(v_headstr);

      FOR I IN 1 .. v_metrics.count/c_metrics LOOP
         BEGIN 
         v_idx_base := (i-1)*c_metrics;
         v_metric_str := '|';
         v_metric_str := v_metric_str || LPAD(v_metrics(v_idx_base+1).inst_id, '4') || '|'; -- instance number
         v_total_cpu  := v_metrics(v_idx_base+1).VALUE + v_metrics(v_idx_base+2).VALUE;
         v_idle_cpu   := TO_CHAR(100*v_metrics(v_idx_base+2).VALUE/v_total_cpu,'fm999.0');
         v_usr_cpu    := TO_CHAR(100*v_metrics(v_idx_base+5).VALUE/v_total_cpu,'fm999.0');
         v_sys_cpu    := TO_CHAR(100*v_metrics(v_idx_base+4).VALUE/v_total_cpu,'fm999.0');
         v_metric_str := v_metric_str || '    ' || LPAD(v_idle_cpu,6) || LPAD(v_usr_cpu,6) || LPAD(v_sys_cpu,6) || '|'; -- CPU
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+11).VALUE/v_secs,'fm999999999999'), '12') || '|'; -- Logons
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+10).VALUE/v_secs,'fm999999999999'), '12') || '|'; -- Execs
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+22).VALUE/v_secs,'fm99999999'), '8') || '|'; -- Calls
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+23).VALUE/v_secs,'fm99999999'), '8') || '|'; -- Commit
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+14).VALUE/v_secs,'fm999999999999'), '12') || '|'; -- sParse
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+13).VALUE/v_secs,'fm999999999999'), '12') || '|'; -- hParse
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+20).VALUE/v_secs,'fm999999999999'), '12') || '|'; -- ccHits
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+21).VALUE/v_secs/1000,'fm99999999'), '8') || '|'; -- LIOs(K)
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+15).VALUE/v_secs,'fm99999999999999'), '14') || '|'; -- PhyRD
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+17).VALUE/v_secs,'fm99999999999999'), '14') || '|'; -- PhyWR
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+16).VALUE/v_secs/gc_mb,'fm99999999'), '8') || '|'; -- READ MB
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+18).VALUE/v_secs/gc_mb,'fm99999999'), '8') || '|'; -- Write MB
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+19).VALUE/v_secs/gc_mb,'fm99999999'), '8') || '|'; -- Redo MB
         v_offload    := CASE WHEN v_metrics(v_idx_base+9).VALUE=0 OR v_metrics(v_idx_base+7).VALUE=0 THEN
                           0
                         ELSE
                           100*(1-v_metrics(v_idx_base+9).VALUE/v_metrics(v_idx_base+7).VALUE)
                         END;
                         
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_offload,'fm999.0'), '8') || '|'; -- offload percent
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+8).VALUE/v_secs/gc_mb,'fm99999999'), '8') || '|'; -- IO Save by Storage index MB
         v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics(v_idx_base+6).VALUE/v_secs,'fm99999999'), '8') || '|'; -- Smart Flash Cache hit
         v_rows.extend(1);
         v_rows(v_rows.last) := vb_output_ot(v_metric_str);
          
 EXCEPTION
            WHEN ZERO_DIVIDE THEN
                             CONTINUE;
         END;
         
               END LOOP;
    
     
    v_rows.extend(1);
      v_rows(v_rows.last) := vb_output_ot(RPAD('+', 172, '-') || '+');

      v_metric_str := '                      Total :';
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(11).VALUE/v_secs,'fm999999999999'), '12') || ';'; -- Logons
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(10).VALUE/v_secs,'fm999999999999'), '12') || ';'; -- Execs
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(22).VALUE/v_secs,'fm99999999'), '8') || ';'; -- Calls
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(23).VALUE/v_secs,'fm99999999'), '8') || ';'; -- Commit
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(14).VALUE/v_secs,'fm999999999999'), '12') || ';'; -- sParse
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(13).VALUE/v_secs,'fm999999999999'), '12') || ';'; -- hParse
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(20).VALUE/v_secs,'fm999999999999'), '12') || ';'; -- ccHits
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(21).VALUE/v_secs/1000,'fm99999999'), '8') || ';'; -- LIOs(K)
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(15).VALUE/v_secs,'fm99999999999999'), '14') || ';'; -- PhyRD
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(17).VALUE/v_secs,'fm99999999999999'), '14') || ';'; -- PhyWR
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(16).VALUE/v_secs/gc_mb,'fm99999999'), '8') || ';'; -- READ MB
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(18).VALUE/v_secs/gc_mb,'fm99999999'), '8') || ';'; -- Write MB
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(19).VALUE/v_secs/gc_mb,'fm99999999'), '8') || ';'; -- Redo MB
      v_metric_str := v_metric_str || LPAD(' ', '8') || ';'; -- Offload
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(8).VALUE/v_secs/gc_mb,'fm99999999'), '8') || ';'; -- IO Save by Storage index MB
      v_metric_str := v_metric_str || LPAD(TO_CHAR(v_metrics_total(6).VALUE/v_secs,'fm99999999'), '8') || ';'; -- Smart Flash Cache hit

      v_rows.extend(1);
      v_rows(v_rows.last) := vb_output_ot(v_metric_str);
             RETURN v_rows;

   END instance_summary;

   ----------------------------------------------------------------------------
   PROCEDURE draw_active_session_graph ( p_lower_snap IN PLS_INTEGER,
                          p_upper_snap IN PLS_INTEGER) IS

      v_snaps     PLS_INTEGER;

      -- Variables to draw active session graph...
      -- --------------------------------------------------
      v_max_aas PLS_INTEGER;
      v_line varchar2(200);
      v_idx  integer;
   BEGIN

      -- Calculate number of ASH snapshot for this output...
      -- --------------------------------------------------
      v_snaps := ash_snap_count( p_lower_snap => p_lower_snap,
                                     p_upper_snap => p_upper_snap );

      -- Fetch aas, cpu_aas , io_aas...
      -- -------------------------------
      SELECT COUNT(*)/v_snaps aas,
             SUM(CASE WHEN wait_class='ON CPU' THEN 1 ELSE 0 END)/v_snaps cpu_aas,
             SUM(CASE WHEN wait_class='User I/O' THEN 1 ELSE 0 END)/v_snaps io_aas
      INTO g_ash_aas(g_ash_idx).aas, g_ash_aas(g_ash_idx).cpu_aas, g_ash_aas(g_ash_idx).io_aas
      FROM   TABLE(
                VB.GET_ASH(
                   p_lower_snap, p_upper_snap, VB.GC_ALL_ROWS));

      SELECT CASE WHEN MAX(aas) <= g_ash_height THEN g_ash_height ELSE CEIL(MAX(aas)) END
      INTO v_max_aas
      FROM  TABLE(g_ash_aas);

      IF v_max_aas = g_max_aas_current THEN

      -- Only draw the lastest sample
      -- -------------------------------
         g_ash_graph(g_ash_idx) :=  ash_graph_ot(RPAD(NVL(
                                    RPAD(gc_cpu, ROUND((g_ash_aas(g_ash_idx).cpu_aas/g_max_aas_current) * g_ash_height), gc_cpu) ||
                                    RPAD(gc_io, ROUND((g_ash_aas(g_ash_idx).io_aas/g_max_aas_current) * g_ash_height), gc_io) ||
                                    RPAD(gc_others, ROUND(((g_ash_aas(g_ash_idx).aas - g_ash_aas(g_ash_idx).cpu_aas - g_ash_aas(g_ash_idx).io_aas)/g_max_aas_current) * g_ash_height), gc_others), ' '),
                                    g_ash_height, ' '));
         FOR I IN 1 .. g_ash_height LOOP
            g_ash_lines(I) := SUBSTR(g_ash_lines(I), 2, gc_ash_graph_length-1) || SUBSTR(g_ash_graph(g_ash_idx).graph, g_ash_height-I+1, 1);
         END LOOP;
      ELSE

      -- Re-draw al the samples
      -- -------------------------------
         g_max_aas_current := v_max_aas;
         FOR I IN 1 .. gc_ash_graph_length LOOP
            IF ROUND((g_ash_aas(I).aas/g_max_aas_current) * g_ash_height) < 1 THEN
               g_ash_graph(I) := ash_graph_ot(g_ash_spaces);
            ELSE
               g_ash_graph(I) :=  ash_graph_ot(RPAD(NVL(
                                          RPAD(gc_cpu, ROUND((g_ash_aas(I).cpu_aas/g_max_aas_current) * g_ash_height), gc_cpu) ||
                                          RPAD(gc_io, ROUND((g_ash_aas(I).io_aas/g_max_aas_current) * g_ash_height), gc_io) ||
                                          RPAD(gc_others, ROUND(((g_ash_aas(I).aas - g_ash_aas(I).cpu_aas - g_ash_aas(I).io_aas)/g_max_aas_current) * g_ash_height), gc_others), ' '),
                                          g_ash_height, ' '));
            END IF;
         END LOOP;
         FOR I IN 1 .. g_ash_height LOOP
            v_line := '';
            FOR j IN 1 .. gc_ash_graph_length LOOP
              v_line := v_line || SUBSTR(g_ash_graph(MOD(g_ash_idx+j-1, gc_ash_graph_length)+1).graph, g_ash_height-I+1, 1);
            END LOOP;
            g_ash_lines(I) := v_line;
         END LOOP;

      -- Re-draw the scales
      -- -------------------------------
      FOR I IN 1 .. g_ash_scales.count LOOP
         g_ash_scales(I) := ROUND(g_max_aas_current * (g_ash_scales_height-I+1)/g_ash_height);
      END LOOP;
      END IF;

      -- trun the g_ash_lines into colourfull
      -- ------------------------------------
      FOR I IN 1 .. g_ash_height LOOP
         g_ash_lines_color(I) := to_color_ash(g_ash_lines(I));
      END LOOP;

      g_ash_idx := g_ash_idx + 1;
      IF g_ash_idx > gc_ash_graph_length THEN
         g_ash_idx := 1;
      END IF;

   END draw_active_session_graph;

   ----------------------------------------------------------------------------
   FUNCTION top_summary ( p_lower_snap IN PLS_INTEGER,
                          p_upper_snap IN PLS_INTEGER,
                          p_refresh_rate IN PLS_INTEGER) RETURN vb_output_ntt IS

      TYPE top_sql_rt IS record
      ( sql_id           varchar2(64)
      , occurrences      number
      , inst_cnt         number
      , top_sids         vb_v2_ntt
      , first_top_event  varchar2(40)
      , second_top_event varchar2(40));

      TYPE top_waits_rt IS record
      ( inst_id     number
      , wait_name   varchar2(64)
      , wait_class  varchar2(64)
      , occurrences number );

      TYPE top_sql_aat IS TABLE OF top_sql_rt
         INDEX BY PLS_INTEGER;

      TYPE top_waits_aat IS TABLE OF top_waits_rt
         INDEX BY PLS_INTEGER;

      v_row       varchar2(4000);
      v_rows      vb_output_ntt := vb_output_ntt();
      v_top_sqls  top_sql_aat;
      v_top_waits top_waits_aat;
      v_samples   PLS_INTEGER;
      v_snaps     PLS_INTEGER;

   BEGIN

      -- Calculate number of ASH snapshot for this output...
      -- --------------------------------------------------
      v_snaps := ash_snap_count( p_lower_snap => p_lower_snap,
                                     p_upper_snap => p_upper_snap );

      -- Calculate number of ASH samples for this output...
      -- --------------------------------------------------
      v_samples := ash_sample_count( p_lower_snap => p_lower_snap,
                                     p_upper_snap => p_upper_snap );

      -- Top SQL_IDs...
      -- --------------
      WITH ash_data AS (
              SELECT inst_id, SID, sql_id, event
              FROM   TABLE(
                        VB.GET_ASH(
                           p_lower_snap, p_upper_snap, VB.GC_ALL_ROWS))
            ),
            ash_sql_event AS (
              SELECT sql_id, top_event, ROW_NUMBER
              FROM
              (
                 SELECT sql_id,
                        SUBSTR(event, 1, 28) ||  ' (' || ROUND(100*RATIO_TO_REPORT(COUNT(*)) OVER ( PARTITION BY sql_id)) || '%)' top_event,
                        ROW_NUMBER() OVER (PARTITION BY sql_id ORDER BY COUNT(*) DESC) AS ROW_NUMBER
                 FROM   TABLE(
                           VB.GET_ASH(
                              p_lower_snap, p_upper_snap, VB.GC_ALL_ROWS))
                 GROUP BY sql_id, event
                 ORDER BY COUNT(*) DESC
              )
              WHERE ROW_NUMBER <=2
            )
      SELECT o_ash.sql_id
      ,      o_ash.occurrences
      ,      o_ash.inst_cnt
      ,      CAST(
                MULTISET(
                   SELECT i_ash.sid || '@' || i_ash.inst_id
                   FROM   ash_data i_ash
                   WHERE   NVL(i_ash.sql_id,'X') = NVL(o_ash.sql_id,'X')
                   GROUP  BY
                          i_ash.sid, i_ash.inst_id
                   ORDER  BY
                          COUNT(*) DESC
                   ) AS vb_v2_ntt) AS top_sids
      ,      (
                   SELECT  top_event
                   FROM    ash_sql_event i_ash
                   WHERE   NVL(i_ash.sql_id,'X') = NVL(o_ash.sql_id,'X')
                   AND     i_ash.row_number = 1
                   ) AS first_top_event
      ,      (
                   SELECT  top_event
                   FROM    ash_sql_event i_ash
                   WHERE   NVL(i_ash.sql_id,'X') = NVL(o_ash.sql_id,'X')
                   AND     i_ash.row_number = 2
                   ) AS second_top_event
      BULK COLLECT INTO v_top_sqls
      FROM  (
             SELECT sql_id
             ,      COUNT(*) AS occurrences
             ,      COUNT(DISTINCT inst_id) AS inst_cnt
             FROM   ash_data
             GROUP  BY
                    sql_id
             ORDER  BY
                    COUNT(*) DESC
            ) o_ash
      WHERE  ROWNUM <= g_sql_height;

      -- Top waits...
      -- ------------
      SELECT inst_id
      ,      SUBSTR(event,1,28)
      ,      wait_class
      ,      occurrences
      BULK COLLECT INTO v_top_waits
      FROM  (
             SELECT inst_id
             ,      event
             ,      wait_class
             ,      COUNT(*) AS occurrences
             FROM   TABLE(
                       VB.GET_ASH(
                          p_lower_snap, p_upper_snap, VB.GC_ALL_ROWS))
             GROUP  BY
                    inst_id
             ,      event
             ,      wait_class
             ORDER  BY
                    COUNT(*) DESC
            )
      WHERE  ROWNUM <= g_ash_height;

      -- Begin TOP Event summary...
      -- --------------------
      v_rows.extend(2);
      v_rows(1) := vb_output_ot(LPAD('_______                                Active Session Graph                                    _______', 173,' '));
      v_rows(2) := vb_output_ot(
                      RPAD('+   AAS| TOP|Instance| Top Events',51,'-') || '+ WAIT CLASS -+'  || LPAD(g_ash_scales(1),10) ||
                      to_color(RPAD(' | CPU:' || gc_cpu || ' IO:' || gc_io || ' Others:' || gc_others, 90, ' ')) ||
                           '| ' || g_ash_scales(1)
                      );

      -- Top Event Summary and Active Session Graph output...
      -- -----------------
      FOR I IN 1 .. g_ash_height LOOP
         v_rows.extend;
         v_row := CASE
                     WHEN v_top_waits.exists(I)
                     THEN '|' || LPAD(TO_CHAR((v_top_waits(I).occurrences/v_snaps), 'fm99990.0'),6)  ||
                          '|' || LPAD(TO_CHAR((v_top_waits(I).occurrences/v_samples)*100, 'fm9999'),3) || '%' ||
                          '|' || LPAD('inst(' || v_top_waits(I).inst_id || ')',8) ||
                          RPAD('| ' || SUBSTR(v_top_waits(I).wait_name,1,35), 29) ||
                          RPAD(' | ' || v_top_waits(I).wait_class, 15) || '|'
                     WHEN I = v_top_waits.count + 1
                     THEN RPAD('+',65,'-') || '+'
                     ELSE RPAD(' ', 66)
                  END;
         v_row := v_row ||  LPAD(g_ash_scales(I+1), 10) || ' | ' || g_ash_lines_color(I) || ' | ' || RPAD(g_ash_scales(I+1), 6);

         v_rows(v_rows.last) := vb_output_ot(v_row);
      END LOOP;

      IF v_top_waits.count >= g_ash_height THEN
         v_row := RPAD('+',65,'-') || '+         0 +'  || LPAD('-', 88, '-') || '+ 0';
      ELSE
         v_row := LPAD('0 +',78,' ') || LPAD('-', 88, '-') || '+ 0';
      END IF;
      v_rows.extend(1);
      v_rows(v_rows.last) := vb_output_ot(v_row);

      v_row := LPAD('^ '||TO_CHAR(SYSDATE-(NVL(p_refresh_rate, g_params(VB.GC_TOP_REFRESH_RATE)) * gc_ash_graph_length)/86400, 'hh24:mi:ss'), 89, ' ') ||
               LPAD(TO_CHAR(SYSDATE-(NVL(p_refresh_rate, g_params(VB.GC_TOP_REFRESH_RATE)) * gc_ash_graph_length)/86400/2, 'hh24:mi:ss') || ' ^', 33) ||
               LPAD(TO_CHAR(SYSDATE, 'hh24:mi:ss') || ' ^', 43);

      v_rows.extend(1);
      v_rows(v_rows.last) := vb_output_ot(v_row);
      --v_rows.extend(1);
      --v_rows(v_rows.last) := gc_space;


      -- Top SQL Summary output
      -- --------------------------------------------------------------------------
      v_rows.extend;
      v_rows(v_rows.last) := vb_output_ot(
                      RPAD('+   AAS| TOP| SQL_ID ',28,'-') ||
                      RPAD('+ 1st TOP Event(%) ',37,'-') ||
                      RPAD('+ 2nd TOP Event(%) ',37,'-') ||
                      RPAD('+ Inst_Cnt ', 11,'-') ||
                      RPAD('+ TOP SESSIONS (sid@inst_id) ',59,'-') || '+'
                      );
      FOR I IN 1 .. v_top_sqls.count LOOP
         v_rows.extend;
         v_row := '|' || LPAD(TO_CHAR((v_top_sqls(I).occurrences/v_snaps), 'fm99990.0'),6)  ||
                  '|' || LPAD(TO_CHAR((v_top_sqls(I).occurrences/v_samples)*100, 'fm9999'),3) || '%' ||
                  RPAD('| ' || v_top_sqls(I).sql_id , 16) ||
                  RPAD('| ' || v_top_sqls(I).first_top_event, 37) ||
                  RPAD('| ' || v_top_sqls(I).second_top_event, 37) ||
                  '| ' || LPAD(v_top_sqls(I).inst_cnt || ' ', 9) ||
                  RPAD('| ' || to_string(v_top_sqls(I).top_sids, p_elements => 8), 59) || '|';

         v_rows(v_rows.last) := vb_output_ot(v_row);
      END LOOP;

      v_rows.extend;
      v_rows(v_rows.last) := vb_output_ot(
                                RPAD('+',172,'-') || '+'
                                );


      -- Top SQL output - we're going to deliberately loop r-b-r for the sql_ids...
      -- --------------------------------------------------------------------------
      v_rows.extend;
      v_rows(v_rows.last) := vb_output_ot(
                                RPAD('+ TOP SQL_ID ----+ PLAN_HASH_VALUE + SQL TEXT ', 172, '-') || '+'
                                );
      FOR I IN 1 .. v_top_sqls.count LOOP
         FOR r_sql IN (SELECT DISTINCT sql_id, REGEXP_REPLACE(sql_text, '( ){2,}','\1' ) sql_text, plan_hash_value
                       FROM   gv$SQL
                       WHERE  sql_id = v_top_sqls(I).sql_id
                       AND    ROWNUM = 1)
         LOOP
            v_rows.extend;
            v_rows(v_rows.last) := vb_output_ot(
                                      RPAD('| ' || r_sql.sql_id, 17) ||
                                      RPAD('| ' || r_sql.plan_hash_value, 18) ||
                                      RPAD('| ' || SUBSTR(r_sql.sql_text, 1, 135), 136) || ' |'
                                      );
            v_rows.extend;
            v_rows(v_rows.last) := vb_output_ot(
                                      RPAD('+', 17, '-') ||
                                      RPAD('-', 18, '-') ||
                                      RPAD('-', 137, '-') || '+'
                                      );
         END LOOP;
      END LOOP;

      RETURN v_rows;

   END top_summary;

   ----------------------------------------------------------------------------
   PROCEDURE poll( p_refresh_rate IN  integer,
                   p_include_ash  IN  BOOLEAN,
                   p_include_stat IN  BOOLEAN,
                   p_lower_snap   OUT PLS_INTEGER,
                   p_upper_snap   OUT PLS_INTEGER ) IS

      v_index        PLS_INTEGER;
      v_refresh_rate integer := NVL(p_refresh_rate, g_params(VB.GC_TOP_REFRESH_RATE));

      FUNCTION snap_index RETURN PLS_INTEGER IS
      BEGIN
         RETURN DBMS_UTILITY.GET_TIME();
      END snap_index;

   BEGIN

      -- Set starting snap index...
      -- --------------------------
      v_index := snap_index();
      p_lower_snap := v_index;

      -- Snap SYSSTAT if required...
      -- ---------------------------
      IF p_include_stat THEN
         snap_stats(v_index, TRUE);
      END IF;

      -- Snap ASH if required...
      -- -----------------------
      IF p_include_ash THEN
         FOR I IN 1 .. CEIL(v_refresh_rate/g_params(VB.GC_ASH_POLLING_RATE)) LOOP
            IF I > 1 THEN
              v_index := snap_index;
            END IF;
            snap_ash(v_index);
            DBMS_LOCK.SLEEP(g_params(VB.GC_ASH_POLLING_RATE));
         END LOOP;
      END IF;

      -- If no ASH samples taken, sleep for refresh rate instead...
      -- ----------------------------------------------------------
      IF p_include_stat AND NOT p_include_ash THEN
         DBMS_LOCK.SLEEP(v_refresh_rate);
         v_index := snap_index;
      END IF;

      -- Snap SYSSTAT again if required...
      -- ---------------------------------
      IF p_include_stat THEN
         snap_stats(v_index);
      END IF;

      -- Set end snap index...
      -- ---------------------
      p_upper_snap := v_index;

   END poll;

   ----------------------------------------------------------------------------
   -- Determine ASH trailing window size
   ----------------------------------------------------------------------------
   FUNCTION get_ash_window_lower_snap (
        p_lower_snap      IN PLS_INTEGER,
        p_upper_snap      IN PLS_INTEGER,
        p_refresh_rate    IN PLS_INTEGER,
        p_ash_window_size IN PLS_INTEGER
        ) RETURN PLS_INTEGER IS

      v_snap_count      PLS_INTEGER;
      v_snap            PLS_INTEGER;
      v_ash_window_size PLS_INTEGER;
   BEGIN
      v_ash_window_size := NVL(p_ash_window_size, get_parameter(VB.GC_ASH_WINDOW_SIZE));
      -- By default no ASH trailing window or if refresh rate greater than window size
      -- -----------------------------------------------------------------------------
      IF v_ash_window_size IS NULL OR p_refresh_rate >= v_ash_window_size THEN
         v_snap := p_lower_snap;
      ELSE
         v_snap_count := 1;
         v_snap := p_upper_snap;
         WHILE v_snap_count < v_ash_window_size AND g_ash.prior(v_snap) IS NOT NULL LOOP
           v_snap_count := v_snap_count + 1;
           v_snap := g_ash.prior(v_snap);
         END LOOP;
      END IF;

      RETURN v_snap;
   END get_ash_window_lower_snap;

   ----------------------------------------------------------------------------
   FUNCTION top (
            p_refresh_rate    IN integer DEFAULT NULL,
            p_screen_size     IN integer DEFAULT NULL,
            p_ash_height      IN integer DEFAULT NULL,
            p_sql_height      IN integer DEFAULT NULL,
            p_ash_window_size IN integer DEFAULT NULL
            ) RETURN vb_output_ntt pipelined IS

      v_lower_snap PLS_INTEGER;
      v_upper_snap PLS_INTEGER;
      v_row        varchar2(4000);
      v_rows       vb_output_ntt := vb_output_ntt();
      v_cnt        PLS_INTEGER := 0;

   BEGIN

      -- Init the screen size variable and some sanity check ...
      -- -----------------------------------------------------------
      init_screen_variables( p_screen_size, p_ash_height, p_sql_height);

      -- Initial clear screen and stabiliser...
      -- --------------------------------------
      v_rows := banner();
      -- fill the initial "blank screen" (this is needed for arraysize = 2*g_screen_size to work)
      FOR I IN 1 .. g_screen_size LOOP
         pipe ROW (gc_space);
      END LOOP;
      -- print banner onto the top of the screen
      FOR I IN 1 .. v_rows.count LOOP
         pipe ROW (v_rows(I));
      END LOOP;
      -- fill the rest of the visible screen
      FOR I IN 1 .. g_screen_size-(v_rows.count+1) LOOP
         pipe ROW (gc_space);
      END LOOP;
      pipe ROW (vb_output_ot('Please wait : fetching data for first refresh...'));
      -- singce the first sqlplus fetech size is 1, output an additional space row)
      pipe ROW (gc_space);

      -- Init Active Session Graph variables
      -- ---------------------------------------
      init_ash_graph_variables();

      -- Begin TOP refreshes...
      -- ----------------------
      LOOP

         -- Take some ASH/STAT samples...
         -- -----------------------------
         poll( p_refresh_rate => p_refresh_rate,
               p_include_ash  => TRUE,
               p_include_stat => TRUE,
               p_lower_snap   => v_lower_snap,
               p_upper_snap   => v_upper_snap );

         -- Banner...
         -- ---------
         -- v_rows := banner();
         -- for i in 1 .. v_rows.count loop
         --    pipe row (v_rows(i));
         -- end loop;
         -- pipe row (gc_space);
         -- v_cnt := v_rows.count + 1;
         v_cnt := 0;

         v_lower_snap := get_ash_window_lower_snap( p_lower_snap => v_lower_snap,
                                                    p_upper_snap => v_upper_snap,
                                                    p_refresh_rate => p_refresh_rate,
                                                    p_ash_window_size => p_ash_window_size );

         -- Draw the colorfull Active Session Graph...
         -- ------------------------------------------
         draw_active_session_graph( p_lower_snap => v_lower_snap,
                                    p_upper_snap => v_upper_snap);

         -- Clear screen...
         -- ---------------
         FOR I IN 1 .. g_screen_size LOOP
            pipe ROW (gc_space);
         END LOOP;

         -- Instance summary...
         -- -------------------
         v_rows := instance_summary( p_lower_snap => v_lower_snap,
                                     p_upper_snap => v_upper_snap,
                                     p_refresh_rate => p_refresh_rate );
         FOR I IN 1 .. v_rows.count LOOP
            pipe ROW (v_rows(I));
         END LOOP;
         --pipe row (gc_space);
         v_cnt := v_cnt + v_rows.count;

         -- Top SQL and waits section...
         -- ----------------------------
         v_rows := top_summary( p_lower_snap => v_lower_snap,
                                p_upper_snap => v_upper_snap,
                                p_refresh_rate => p_refresh_rate);

         -- In case the arraysize is overflow
         -- ---------------------------------
         FOR I IN 1 .. LEAST(v_rows.count, (g_screen_size-v_cnt)) LOOP
            pipe ROW (v_rows(I));
         END LOOP;
         v_cnt := v_cnt + v_rows.count;

         -- Some blank output...
         -- --------------------
         IF v_cnt < (g_screen_size) THEN
            FOR I IN 1 .. (g_screen_size)-v_cnt LOOP
               pipe ROW (gc_space);
            END LOOP;
         END IF;

      END LOOP;
      RETURN;

   EXCEPTION
      WHEN no_data_found THEN
         raise_application_error(-20000, 'Error: '||sqlerrm||' at:'||CHR(10)||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
   END top;

   ----------------------------------------------------------------------------
   FUNCTION ash (
            p_refresh_rate IN integer  DEFAULT NULL,
            p_select       IN varchar2 DEFAULT NULL,
            p_where        IN varchar2 DEFAULT NULL,
            p_group_by     IN varchar2 DEFAULT NULL,
            p_order_by     IN varchar2 DEFAULT NULL
            ) RETURN vb_output_ntt pipelined IS

      v_lower_snap PLS_INTEGER;
      v_upper_snap PLS_INTEGER;
      v_row        varchar2(4000);
      v_cnt        PLS_INTEGER := 0;

      -- DBMS_SQL variables...
      -- ---------------------
      v_sql        varchar2(32767);
      v_cursor     binary_integer;
      v_execute    integer;
      v_desc       DBMS_SQL.DESC_TAB2;
      v_cols       integer;
      v_value      varchar2(4000);

   BEGIN

      -- Build up the dynamic SQL...
      -- ---------------------------
      v_sql := get_sql( p_select   => p_select,
                        p_from     => 'TABLE(vb.get_ash(:b1, :b2))',
                        p_where    => p_where,
                        p_group_by => p_group_by,
                        p_order_by => p_order_by );

      -- Open a cursor for the ASH queries, parse and describe it...
      -- -----------------------------------------------------------
      v_cursor := DBMS_SQL.OPEN_CURSOR;
      DBMS_SQL.PARSE(v_cursor, v_sql, DBMS_SQL.NATIVE);
      DBMS_SQL.DESCRIBE_COLUMNS2(v_cursor, v_cols, v_desc);

      -- Take some ASH samples...
      -- ------------------------
      poll( p_refresh_rate => p_refresh_rate,
            p_include_ash  => TRUE,
            p_include_stat => FALSE,
            p_lower_snap   => v_lower_snap,
            p_upper_snap   => v_upper_snap );

      -- Bind the ASH snapshots...
      -- -------------------------
      DBMS_SQL.BIND_VARIABLE(v_cursor, 'b1', v_lower_snap);
      DBMS_SQL.BIND_VARIABLE(v_cursor, 'b2', v_upper_snap);

      -- Define the columns and variable we are fetching into...
      -- -------------------------------------------------------
      FOR I IN 1 .. v_cols LOOP
         DBMS_SQL.DEFINE_COLUMN(v_cursor, i, v_value, 4000);
      END LOOP;

      -- Output the heading...
      -- ---------------------
      FOR I IN 1 .. v_cols LOOP
         v_row := v_row || '|' || v_desc(I).col_name;
      END LOOP;
      pipe ROW (vb_output_ot(v_row));
      v_row := NULL;

      -- Start fetching...
      -- -----------------
      v_execute := DBMS_SQL.EXECUTE(v_cursor);

      WHILE DBMS_SQL.FETCH_ROWS(v_cursor) > 0 LOOP
         FOR I IN 1 .. v_cols LOOP
            DBMS_SQL.COLUMN_VALUE(v_cursor, i, v_value);
            v_row := v_row || '|' || v_value;
         END LOOP;
         pipe ROW (vb_output_ot(v_row));
         v_row := NULL;
      END LOOP;
      DBMS_SQL.CLOSE_CURSOR(v_cursor); --<-- will never be reached on an infinite loop with ctrl-c

      RETURN;

   EXCEPTION
      WHEN others THEN
         DBMS_SQL.CLOSE_CURSOR(v_cursor);
         raise_application_error (-20000, 'Error: ' || sqlerrm || ' at:' || CHR(10) || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, TRUE);
   END ash;

   ----------------------------------------------------------------------------
   FUNCTION get_ash (
            p_lower_snap IN PLS_INTEGER DEFAULT NULL,
            p_upper_snap IN PLS_INTEGER DEFAULT NULL,
            p_return_set IN PLS_INTEGER DEFAULT VB.GC_ALL_ROWS
            ) RETURN vb_ash_ntt pipelined IS
      v_lower_snap PLS_INTEGER := NVL(p_lower_snap, g_ash.first);
      v_upper_snap PLS_INTEGER := NVL(p_upper_snap, g_ash.last);
      v_snap       PLS_INTEGER;
      v_exit       BOOLEAN := FALSE;
   BEGIN
      v_snap := v_lower_snap;
      WHILE v_snap IS NOT NULL AND NOT v_exit LOOP
         FOR I IN 1 .. g_ash(v_snap).COUNT LOOP
            -- Ignore dummy records
            IF g_ash(v_snap)(i).SID IS NOT NULL THEN
               pipe ROW (g_ash(v_snap)(i));
            END IF;
         END LOOP;
         v_exit := (v_snap = v_upper_snap);
         v_snap := CASE p_return_set
                      WHEN VB.GC_ALL_ROWS
                      THEN g_ash.next(v_snap)
                      ELSE v_upper_snap
                   END;
      END LOOP;
      RETURN;
   END get_ash;

BEGIN
   restore_default_parameters();
END VB;
/




prompt Creating view...
create or replace view top
as
   select *
   from   table(vb.top);

   
 -- prompt **************************************************************************
-- prompt **************************************************************************
-- prompt
-- prompt

-- pause

-- prompt Removing vb...

-- drop view 		VISHALBH.top;
-- drop package 	VISHALBH.vb;
-- drop type       VISHALBH.vb_output_ntt;
-- drop type       VISHALBH.vb_output_ot;
-- drop type       VISHALBH.vb_v2_ntt;
-- drop type       VISHALBH.vb_ash_ntt;
-- drop type       VISHALBH.vb_ash_ot;
-- drop type       VISHALBH.vb_stat_ntt;
-- drop type       VISHALBH.vb_stat_ot;
-- drop type       VISHALBH.ash_aas_ntt;
-- drop type       VISHALBH.ash_aas_ot;
-- drop type       VISHALBH.ash_graph_ntt;
-- drop type       VISHALBH.ash_graph_ot;

-- prompt
-- prompt
-- prompt **************************************************************************
-- prompt    Uninstall complete.
-- prompt **************************************************************************

  
   
set define on
set pause off

