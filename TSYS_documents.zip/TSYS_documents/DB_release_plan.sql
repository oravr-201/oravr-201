Database relaease plan :


--DB release server meven :

wdl2tsyssvs04.tsysacquiring.org 
-- Need to change TNS entry ( where release happen)

/home/oracle/app/oracle/product/11.2.0/client_1/network/admin 

edit tnsnames.ora


--live release status :

http://10.132.13.131:6280/jenkins/view/Production/job/Production-PreRelease/ 
http://10.132.13.131:6280/jenkins/blue/organizations/jenkins/Production-PreRelease/detail/Production-PreRelease/89/pipeline 
http://10.132.13.131:6280/jenkins/view/Production/job/Production-PreRelease/89/console 
