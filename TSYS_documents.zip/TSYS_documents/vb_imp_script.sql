

--active session history gv$active_session_history
@ash\ashtop.sql 
--dba_hist_active_sess_history
@ash\dashtop.sql

