--oracle active and hist session history 

--active_session_history 
@C:\Users\vishalbhandwalkar\Desktop\vb\ash\ashtop inst_id||':<'||SESSION_ID||'@'||SESSION_SERIAL#||':'||sample_time||'>:<'||username||':'||PROGRAM||':'||MODULE||':'||MACHINE||':'||PORT||'>:<'||SQL_OPNAME||':'||sql_id||'>:'||event2||':'||event "USERNAME<>'SYS'" sysdate-10/1440 sysdate
--active_session_history  with blokking session 
@C:\Users\vishalbhandwalkar\Desktop\vb\ash\ashtop inst_id||':<'||SESSION_ID||'@'||SESSION_SERIAL#||':'||sample_time||'>:<'||username||':'||PROGRAM||':'||MODULE||':'||MACHINE||':'||PORT||'>:<'||SQL_OPNAME||':'||sql_id||'>:'||event2||':'||event "USERNAME<>'SYS'and blocking_session IS NOT NULL  " sysdate-10/1440 sysdate
--hist_active_session_history  with blokking session 
@C:\Users\vishalbhandwalkar\Desktop\vb\ash\dashtop INSTANCE_NUMBER||':<'||SESSION_ID||'@'||SESSION_SERIAL#||':'||sample_time||'>:<'||username||':'||PROGRAM||':'||MODULE||':'||MACHINE||':'||PORT||'>:<'||SQL_OPNAME||':'||sql_id||'>:'||event2||':'||event "USERNAME<>'SYS' and blocking_session IS NOT NULL "  "TIMESTAMP'2019-11-04 07:30:00'" "TIMESTAMP'2019-11-04 10:53:00'"
--check wait of past time without blocking session 
@C:\Users\vishalbhandwalkar\Desktop\vb\ash\dashtop INSTANCE_NUMBER||':<'||SESSION_ID||'@'||SESSION_SERIAL#||':'||sample_time||'>:<'||username||':'||PROGRAM||':'||MODULE||':'||MACHINE||':'||PORT||'>:<'||SQL_OPNAME||':'||sql_id||'>:'||event||':'||event2||':'||event "USERNAME<>'SYS'"  "TIMESTAMP'2019-11-04 07:30:00'" "TIMESTAMP'2019-11-04 10:53:00'"



----(oracle wait )


--check wait of current time 
@C:\Users\vishalbhandwalkar\Desktop\vb\ash\ash_wait_chains inst_id||':<'||SESSION_ID||'@'||SESSION_SERIAL#||':'||sample_time||'>:<'||username||':'||PROGRAM||':'||MODULE||':'||MACHINE||':'||PORT||'>:<'||SQL_OPNAME||':'||sql_id||'>:'||event2||':'||event "USERNAME<>'SYS'" sysdate-10/1440 sysdate
--check wait of current time  aginst sql_id
@C:\Users\vishalbhandwalkar\Desktop\vb\ash\ash_wait_chains inst_id||':<'||SESSION_ID||'@'||SESSION_SERIAL#||':'||sample_time||'>:<'||username||':'||PROGRAM||':'||MODULE||':'||MACHINE||':'||PORT||'>:<'||SQL_OPNAME||':'||sql_id||'>:'||event2||':'||event "USERNAME<>'SYS' and sql_id='auk20df2t6v3u'" sysdate-10/1440 sysdate
--check wait of past time with blocking session 
@C:\Users\vishalbhandwalkar\Desktop\vb\ash\dash_wait_chains INSTANCE_NUMBER||':<'||SESSION_ID||'@'||SESSION_SERIAL#||':'||sample_time||'>:<'||username||':'||PROGRAM||':'||MODULE||':'||MACHINE||':'||PORT||'>:<'||SQL_OPNAME||':'||sql_id||'>:'||event2||':'||event "USERNAME<>'SYS' and blocking_session IS NOT NULL "  "TIMESTAMP'2019-11-04 07:30:00'" "TIMESTAMP'2019-11-04 10:53:00'"
--check wait of past time without blocking session 
@C:\Users\vishalbhandwalkar\Desktop\vb\ash\dash_wait_chains INSTANCE_NUMBER||':<'||SESSION_ID||'@'||SESSION_SERIAL#||':'||sample_time||'>:<'||username||':'||PROGRAM||':'||MODULE||':'||MACHINE||':'||PORT||'>:<'||SQL_OPNAME||':'||sql_id||'>:'||event||':'||event2||':'||event "USERNAME<>'SYS'"  "TIMESTAMP'2019-11-04 07:30:00'" "TIMESTAMP'2019-11-04 10:53:00'"