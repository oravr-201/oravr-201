SELECT  object_type ,count(1) FROM ALL_OBJECTS WHERE object_name IN (SELECT object_name
  FROM all_objects
 WHERE status = 'INVALID' AND object_type = 'SYNONYM' AND owner LIKE '%3129%') and owner LIKE '%3129%'  group by object_type  ;



TRANSIT_GATEWAY_TNOX_3129.CREATE_API_CUSTOMER_ID

SELECT 'alter  synonym ' || owner || '.' || object_name || ' compile;'
  FROM all_objects
 WHERE status = 'INVALID' AND object_type = 'SYNONYM' AND owner LIKE '%3129%' ;





BEGIN
   FOR MANIA IN (SELECT ao.object_name, ao.owner owner
                   FROM all_objects ao
                  WHERE status = 'INVALID' AND object_type = 'SYNONYM' AND owner LIKE '%3129%')
   LOOP
      -- execute alter public synonym seq.object_name compile;
      DBMS_OUTPUT.put_line (
            'alter public synonym '
         || MANIA.owner
         || '.'
         || MANIA.object_name
         || ' compile;');
   END LOOP;
END;
/