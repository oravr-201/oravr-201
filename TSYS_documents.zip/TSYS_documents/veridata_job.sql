
[oracle@wpl1trandbs01 scripts]$ cat TW_Vs_TE_Compare.sh
#!/bin/sh

#######################################################################################
# Purposes - A quick and dirty script to trigger veridata jobs for comparision.
#            Script will send automatic email to DBA team along with statys and report.
#######################################################################################
#
#-------------------------------------------------------------------------------------
#
# Author : Sandip Tujare
# Date   : Jul 05, 2019
#
#------------------------------------------------------------------------------------
#
####################################################################################

/opt/oracle/product/12.2.1_middleware/user_projects/domains/base_domain/veridata/bin/vericom.sh -j FixDay_01_Lookup_tables -wluser veridata </opt/oracle/product/12.2.1_middleware/user_projects/domains/base_domain/veridata/bin/veridata1 >/home/oracle/logs/FixDay_01_Lookup_tables.log

export LogFile=`awk ' / Report / {print $5}' /home/oracle/logs/FixDay_01_Lookup_tables.log`
export JobStatus=`awk ' / Completion / {print $5}' /home/oracle/logs/FixDay_01_Lookup_tables.log`

cp $LogFile /tmp/FixDay_01_Lookup_tables.txt

export FileName=`awk '{idx = split(FILENAME, parts, "/"); print parts[idx]; nextfile}' /tmp/FixDay_01_Lookup_tables.txt`

if [ "$JobStatus" == "In-Sync" ]; then
        Status_COL="green"
else
        Status_COL="red"
fi

perl sendmail.pl "FixDay_01_Lookup_tables" "TW_Vs_TE" "$JobStatus" "$Status_COL" "FixDay_01_Lookup_tables.txt" "/tmp/FixDay_01_Lookup_tables.txt"
##########################################################################################################################################################################
/opt/oracle/product/12.2.1_middleware/user_projects/domains/base_domain/veridata/bin/vericom.sh -j FixDay_05_TW_Vs_TE_Snox_Tables -wluser veridata </opt/oracle/product/12.2.1_middleware/user_projects/domains/base_domain/veridata/bin/veridata1 >/home/oracle/logs/FixDay_05_TW_Vs_TE_Snox_Tables.log

export LogFile=`awk ' / Report / {print $5}' /home/oracle/logs/FixDay_05_TW_Vs_TE_Snox_Tables.log`
export JobStatus=`awk ' / Completion / {print $5}' /home/oracle/logs/FixDay_05_TW_Vs_TE_Snox_Tables.log`

cp $LogFile /tmp/FixDay_05_TW_Vs_TE_Snox_Tables.txt

export FileName=`awk '{idx = split(FILENAME, parts, "/"); print parts[idx]; nextfile}' /tmp/FixDay_05_TW_Vs_TE_Snox_Tables.txt`

if [ "$JobStatus" == "In-Sync" ]; then
        Status_COL="green"
else
        Status_COL="red"
fi

perl sendmail.pl "FixDay_05_TW_Vs_TE_Snox_Tables" "TW_Vs_TE" "$JobStatus" "$Status_COL" "FixDay_05_TW_Vs_TE_Snox_Tables.txt" "/tmp/FixDay_05_TW_Vs_TE_Snox_Tables.txt"
##########################################################################################################################################################################
/opt/oracle/product/12.2.1_middleware/user_projects/domains/base_domain/veridata/bin/vericom.sh -j FixDay_04_TW_Vs_TE_XTN_Tables -wluser veridata </opt/oracle/product/12.2.1_middleware/user_projects/domains/base_domain/veridata/bin/veridata1 >/home/oracle/logs/FixDay_04_TW_Vs_TE_XTN_Tables.log

export LogFile=`awk ' / Report / {print $5}' /home/oracle/logs/FixDay_04_TW_Vs_TE_XTN_Tables.log`
export JobStatus=`awk ' / Completion / {print $5}' /home/oracle/logs/FixDay_04_TW_Vs_TE_XTN_Tables.log`

cp $LogFile /tmp/FixDay_04_TW_Vs_TE_XTN_Tables.txt

export FileName=`awk '{idx = split(FILENAME, parts, "/"); print parts[idx]; nextfile}' /tmp/FixDay_04_TW_Vs_TE_XTN_Tables.txt`

if [ "$JobStatus" == "In-Sync" ]; then
        Status_COL="green"
else
        Status_COL="red"
fi

perl sendmail.pl "FixDay_04_TW_Vs_TE_XTN_Tables" "TW_Vs_TE" "$JobStatus" "$Status_COL" "FixDay_04_TW_Vs_TE_XTN_Tables.txt" "/tmp/FixDay_04_TW_Vs_TE_XTN_Tables.txt"
##########################################################################################################################################################################







[oracle@wpl1trandbs01 scripts]$ cat sendmail.pl
#!/usr/bin/perl--


use MIME::Lite;
use Net::SMTP;


my $JobName=$ARGV[0];
my $SERVICENAME=$ARGV[1];
my $Status=$ARGV[2];
my $Status_COL=$ARGV[3];
my $my_attach_file=$ARGV[4];
my $my_attach_file_path=$ARGV[5];

#Adjust sender, recipient and your SMTP mailhost--
my $from_address = 'ifx-dbalerts@tsys.com';
#my $to_address = 'ACQ-TransITDB@tsys.com,ACQ-TransITQA@tsys.com';--
my $to_address = 'stujare@tsys.com,vishalbhandwalkar@tsys.com';
my $mail_host = 'smtpwest.tas.corp';

#Adjust subject and body message--
my $subject = "Data Compare status- $Status : for job $JobName on $SERVICENAME";

my $message_header = "<p><font face='verdana' size='2' color='gray'>Hello All,</font></p>

<p><font face='verdana' size='2' color='gray'>Data compare activity has completed for job <strong><font face='verdana'  size='2' color='blue'>$JobName</font></strong> on <strong><font face='verdana'      size='2' color='blue'>$SERVICENAME .</font></strong></font></p>
<p><font face='verdana' size='2' color='gray'>Database compare status is:</font> <strong><font face='verdana'  size='2' color=$Status_COL>$Status</font></strong>
</p>

<p><font face='verdana' size='1' color='black'>**Please find attached report for detailed report.</font></p>
<p><font face='verdana' size='2' color='black'>Thank you !</font><br>
<font face='verdana' size='2' color='black'>DBA Team.</font></p>
";

#Create the multipart container--
$msg = MIME::Lite->new (
  From => $from_address,
  To => $to_address,
  Subject => $subject,
  Type =>'multipart/mixed'
) or die "Error creating multipart container: $!\n";

#Add the message part---
$msg->attach (
  Type => 'TEXT/HTML',
  Data => $message_header
) or die "Error adding the message part: $!\n";

#Add the ZIP file---
$msg->attach (
   Type => 'application/txt',
   Type => 'application',
   Path => $my_attach_file_path,
   Filename => $my_attach_file,
   Disposition => 'attachment'
) or die "Error adding $file_zip: $!\n";

#Send the Message---
MIME::Lite->send('smtp', $mail_host, Timeout=>60);
$msg->send;



[oracle@wpl1trandbs01 scripts]$ cat perlmail.pl
#!/usr/bin/perl
use MIME::Lite;

$to = 'stujare@tsys.com';
$cc = 'stujare@tsys.com';
$from = 'ifx-dbalerts@tsys.com';
$subject = 'Test Email';
$mail_host = 'smtpwest.tas.corp';
$message = 'This is test email sent by Perl Script';

$msg = MIME::Lite->new(
                 From     => $from,
                 To       => $to,
                 Cc       => $cc,

                 Subject  => $subject,
                 Type     => 'multipart/mixed'
                 );

# Add your text message.
$msg->attach(Type         => 'text',
             Data         => $message
             );

# Specify your file as attachement.
$msg->attach(Type         => 'application/txt',
             Path         => '/opt/oracle/product/12.2.1_middleware/user_projects/domains/base_domain/veridata/reports/rpt/FixDay_01_Lookup_tables/00001896/FixDay_01_Lookup_tables.rpt.txt',
             Filename     => 'FixDay_01_Lookup_tables.rpt.txt',
             Disposition  => 'attachment'
            );
MIME::Lite->send('smtp', $mail_host, Timeout=>60);
$msg->send;
print "Email Sent Successfully\n";
[oracle@wpl1trandbs01 scripts]$
