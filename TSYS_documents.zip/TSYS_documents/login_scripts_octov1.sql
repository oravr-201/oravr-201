
vishalbh@octov1:/home/vishalbh$ cat .login
cat .cshrc
cat .exrc
cat .profile
cat gg-perf.host.lst
cat gg-prod.host.lst
cat gg-uat.host.lst
cat inf-non.host.lst
cat inf-prod.host.lst
cat ora-non
cat ora-non.OLD

# @(#)B.11.31_LR


# Default user .login file ( /usr/bin/csh initialization )

# Set up the default search paths:
set path=( $path )

#set up the terminal
eval `tset -s -Q -m ':?hp' `
stty erase "^H" kill "^U" intr "^C" eof "^D" susp "^Z" hupcl ixon ixoff tostop
tabs

# Set up shell environment:
set noclobber
set history=20
cat ora-non.20150525

vishalbh@octov1:/home/vishalbh$ cat .cshrc
cat ora-non.host.lst
cat ora-prod
cat ora-prod.host.lst
cat gg-perf
#
# Default user .cshrc file (/usr/bin/csh initialization).
#
# @(#)B.11.31_LR
# Usage:  Copy this file to a user's home directory and edit it to
# customize it to taste.  It is run by csh each time it starts up.

# Set up default command search path:
#
# (For security, this default is a minimal set.)

        set path=( $path )

# Set up C shell environment:

        if ( $?prompt ) then            # shell is interactive.
            set history=20              # previous commands to remember.
            set savehist=20             # number to save across sessions.
            set system=`hostname`       # name of this system.
            set prompt = "$system \!: " # command prompt.

            # Sample alias:

            alias       h       history

            # More sample aliases, commented out by default:

            # alias     d       dirs
            # alias     pd      pushd
            # alias     pd2     pushd +2
            # alias     po      popd
            # alias     m       more
        endif
cat inf-non
cat gg-prod

vishalbh@octov1:/home/vishalbh$ cat .exrc
cat gg-uat
cat inf-prod
set autoindent autowrite showmatch wrapmargin=0 report=1
map     :set wrapmargin=8
map     {!}sort -b
map    1G
map    1G
map    G
map
map
map    k
map    j
map     i
map     x
map     dd
map     D
map     DjdG$
map!   a
map!
       a
map!   a
map!   a
map!
map!
ap!

vishalbh@octov1:/home/vishalbh$ cat .profile

# @(#)B.11.31_LR

# Default user .profile file (/usr/bin/sh initialization).

# Set up the terminal:
        if [ "$TERM" = "" ]
        then
                eval ` tset -s -Q -m ':?hp' `
        else
                eval ` tset -s -Q `
        fi
        stty erase "^H" kill "^U" intr "^C" eof "^D"
        stty hupcl ixon ixoff
        tabs

# NOTE: '.' is added to $PATH for compatibility reasons only. This
#       default will be changed in a future release. If "." is not
#       needed for compatibility it is better to omit this line.
#       Please edit .profile according to your site requirements.

# Set up the search paths:
        PATH=$PATH:.

# Set up the shell environment:
        set -u
        trap "echo 'logout'" 0

# Set up the shell variables:
        EDITOR=vi
        export EDITOR

vishalbh@octov1:/home/vishalbh$ cat gg-perf.host.lst
TransIT Rpt-Txn PF-DCW:DEV:wdl1trandbs01.tsysacquiring.org
TransIT Rpt-Txn PF-DCW:DEV:wdl1trandbs02.tsysacquiring.org
TransIT Rpt-Txn PF-DCW:DEV:wdl1trandbs03.tsysacquiring.org
TransIT Rpt-Txn PF-DCE:QA:wql1trandbs01.tsysacquiring.org
TransIT Rpt-Txn PF-DCE:QA:wql1trandbs02.tsysacquiring.org
TransIT Rpt-Txn PF-DCE:QA:wql1trandbs03.tsysacquiring.org

vishalbh@octov1:/home/vishalbh$ cat gg-prod.host.lst
TransIT Reporting East Node1:Prod - East:epl1trandbrpt1.tsysacquiring.org
TransIT Reporting East Node2:Prod - East:epl1trandbrpt2.tsysacquiring.org
TransIT Reporting East Node3:Prod - East:epl1trandbrpt3.tsysacquiring.org
TransIT Reporting West Node1:Prod - West:wpl1trandbrpt1.tsysacquiring.org
TransIT Reporting West Node2:Prod - West:wpl1trandbrpt2.tsysacquiring.org
TransIT Reporting West Node3:Prod - West:wpl1trandbrpt3.tsysacquiring.org
TransIT Transaction East Node1:Prod - East:epl1trandbtxn1.tsysacquiring.org
TransIT Transaction East Node2:Prod - East:epl1trandbtxn2.tsysacquiring.org
TransIT Transaction East Node3:Prod - East:epl1trandbtxn3.tsysacquiring.org
TransIT Transaction West Node1:Prod - West:wpl1trandbtxn1.tsysacquiring.org
TransIT Transaction West Node2:Prod - West:wpl1trandbtxn2.tsysacquiring.org
TransIT Transaction West Node3:Prod - West:wpl1trandbtxn3.tsysacquiring.org

vishalbh@octov1:/home/vishalbh$ cat gg-uat.host.lst
TransIT Rpt-Txn:UAT:wul2trandbs04.tsysacquiring.org
TransIT Rpt-Txn:UAT:wul2trandbs06.tsysacquiring.org

vishalbh@octov1:/home/vishalbh$ cat inf-non.host.lst
CBOS:Cat:octdb10.vitalps.com
CBOS:Dev:octdb30.vitalps.com
CBOS:QA:octdb31.vitalps.com
CBOS:UAT:wuh1mltidbs01.vitalps.com
eConn Admin:Cat:octdb10.vitalps.com
eConn Admin:Dev:octdb30.vitalps.com
eConn Admin:QA:octdb31.vitalps.com
Econn Cloud:AWS:10.35.79.11
Econn Cloud DW:AWS:10.35.79.10
eConn DW:Dev:octdb30.vitalps.com
eConn DW:DEV:octdb31n.vitalps.com
eConn DW:DEV:octdb30n.vitalps.com
eConn DW:QA:octdb31.vitalps.com
eConn DW:UAT:wuh1mltidbs01.vitalps.com
ET:Cat:octdb10.vitalps.com
ET:Dev:octdb30.vitalps.com
ET:QA:octdb31.vitalps.com
ET:UAT:wuh1mltidbs01.vitalps.com
Express:Cat:octdb10.vitalps.com
Express:Dev:octdb30.vitalps.com
Express:QA:octdb31.vitalps.com
Express:Stage:octdb9.vitalps.com
Express:UAT:wuh1mltidbs01.vitalps.com
IVR:DEV:octdb30.vitalps.com
IVR:QA:octdb31.vitalps.com
MMS:Audit:octdb31.vitalps.com
MMS:Cat:octdb10.vitalps.com
MMS:Cert:octdb31.vitalps.com
MMS:QA:octdb31.vitalps.com
MMS:Stage:octdb9.vitalps.com
MMS:Training:octdb31.vitalps.com
MMS:UAT:wuh1mltidbs01.vitalps.com
MMS - OTP:DEV:octdb30.vitalps.com
MMS (old?):UAT:octdb31.vitalps.com
Parse Tool (Public Facing):UAT:wuh1mltidbs01.vitalps.com
POSR:QA:octdb31.vitalps.com
Sierra:Cert:certdb.vitalps.com
Sierra:Cert:certlivesg1.vitalps.com
Sierra:Cert:certlivetp1.vitalps.com
Sierra:Cert:octcert3.vitalps.com
Sierra:Cert:octcrt31.vitalps.com
Sierra:Cert:octcrt40.vitalps.com
Sierra:Dev:octdb30.vitalps.com
Sierra:QA:octdb31.vitalps.com
Sierra:QAE (Integ):qaedb1.vitalps.com
TMS DW:Archive:wph1mapxdbs01.vitalps.com
TMS DW:Archive:wph1mapxdbs02.vitalps.com
TMS DW:DEV:octdb30.vitalps.com
TMS DW:UAT:wuh1mapxdbs02.vitalps.com
TMS DW IWA:UAT:wul2mapxapp02.vitalps.com
Veridata:QA:octdb31.vitalps.com

vishalbh@octov1:/home/vishalbh$ cat inf-prod.host.lst
CBOS:Prod - East:dcedb8.vitalps.com
CBOS:Prod - West:dcwdb8.vitalps.com
eConn Admin:Prod - East:dcedb10.vitalps.com
eConn Admin:Prod - West:octdb7.vitalps.com
eConn DW OLD:Backup:dcebksvr.vitalps.com
eConn DW:Backup:dcedbkp2.vitalps.com
eConn DW XPS:Prod - East:dcedb2.vitalps.com
eConn DW IDS:Prod - East:dcedb02.vitalps.com
eConn DW XPS:Prod - West:dcwdb2.vitalps.com
eConn DW IDS:Prod - West:dcwdb02.vitalps.com
EMR:Prod - East:dcedb7.vitalps.com
EMR:Prod - West:dcwdb7.vitalps.com
Express:Prod - East:dcedb10.vitalps.com
Express:Prod - West:octdb7.vitalps.com
IVR:Prod - West:dcwdb01.vitalps.com
MMS:Prod - East:dcedb01.vitalps.com
MMS:Prod - West:dcwdb03.vitalps.com
MMS:Prod Copy:wuh1mltidbs01.vitalps.com
POSR:Prod - East:dcedb9.vitalps.com
POSR:Prod - West:dcwdb9.vitalps.com
Sierra - IS:Prod - East:dcedb01.vitalps.com
Sierra - IS:Prod - West:dcwdb01.vitalps.com
Sierra - SG:Prod - East:dcesg1.vitalps.com
Sierra - SG:Prod - West:dcwsg1.vitalps.com
Sierra - TP:Prod - East:dcetp1.vitalps.com
Sierra - TP:Prod - East:dcetp2.vitalps.com
Sierra - TP:Prod - West:dcwtp1.vitalps.com
Sierra - TP:Prod - West:dcwtp2.vitalps.com
SSO:Prod - East:dcedb10.vitalps.com
SSO:Prod - West:octdb7.vitalps.com
TMS DW:Prod - East:eph1mapxdbs01.vitalps.com
TMS DW:Prod - West:wph1mapxdbs01.vitalps.com
TMS DW IWA:Prod - East:epl1mapxapp01.vitalps.com
TMS DW IWA:Prod - West:wpl1mapxapp01.vitalps.com

vishalbh@octov1:/home/vishalbh$ cat ora-non
#!/usr/local/bin/bash
#
clear
#
echo "Oracle QA-DEV-UAT Environment ..."
echo "---------------------------------"
#
cat /home/jlontok/ora-non.host.lst|sort -t: -k1|grep -E -v '(^#)'|awk -F: '{printf "%-45s %-14s %s\n", $3, $2, $1}'
#
PS3="Use number to select an Oracle server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/jlontok/ora-non.host.lst|awk -F: '{print $3}'|sort|uniq)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/jlontok/ora-non.host.lst|grep $var1|awk -F: '{printf "%-45s %-14s", $1, $2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - oracle
    break
done

vishalbh@octov1:/home/vishalbh$ cat ora-non.OLD
#!/usr/local/bin/bash
#
clear
#
PS3="Use number to select an Oracle server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/jlontok/ora-non-prod-host.lst|awk '{print $3}'|sort)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/jlontok/ora-non-prod-host.lst|grep $var1|awk '{print $1,$2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - oracle
    break
done

vishalbh@octov1:/home/vishalbh$ cat ora-non.20150525
#!/usr/local/bin/bash
#
clear
#
echo "Oracle QA-DEV-UAT Environment ..."
echo "---------------------------------"
#
cat /home/jlontok/ora-non.host.lst|sort -t: -k1|grep -E -v '(^#)'|awk -F: '{printf "%-45s %-14s %s\n", $3, $2, $1}'
#
PS3="Use number to select an Oracle server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/jlontok/ora-non.host.lst|awk -F: '{print $3}'|sort|uniq)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/jlontok/ora-non.host.lst|grep $var1|awk -F: '{printf "%-45s %-14s", $1, $2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - oracle
    break
done

vishalbh@octov1:/home/vishalbh$ cat ora-non.host.lst
Control-M:QA:wql1tsysdbs01.vitalps.com
Fortify:DEV:wdl2fsscdbs01.tsysacquiring.org
MAP:DEV:wdl2mapxdbs01.tsysacquiring.org
MAP:QA:wql2mapxdbs01.tsysacquiring.org
MAP:UAT:wul2mapxdbs01.tsysacquiring.org
Sterling Integrator:QA:octdb31.vitalps.com
Sterling Integrator:UAT:wul2tsysfss01.tsysacquiring.org
StrongAuth:QA:wql2tsysdbs03.vitalps.com
StrongAuth:UAT:wul2tsysdbs01.vitalps.com
TransIT DB Release Automation Test Server:DEV:dbtest.infonox.com
TransIT Non-Prod/UAT backup:UAT:wdl1mltidbs01.tsysacquiring.org
TransIT OEM-Dev:DEV:wdl2tsysdbs03.tsysacquiring.org
Veridata:UAT:wul1trandbs01.tsysacquiring.org
TransIT:DEV:devdbnode1.tsysacquiring.org
TransIT:DEV:devdbnode2.tsysacquiring.org
TransIT:QA:qadbnode1.tsysacquiring.org
TransIT:QA:qadbnode2.tsysacquiring.org
TransIT:REGRESS:regdbnode1.tsysacquiring.org
TransIT:REGRESS:regdbnode2.tsysacquiring.org
TransIT Rpt-Txn PF-DCW:DEV:wdl1trandbs01.tsysacquiring.org
TransIT Rpt-Txn PF-DCW:DEV:wdl1trandbs02.tsysacquiring.org
TransIT Rpt-Txn PF-DCW:DEV:wdl1trandbs03.tsysacquiring.org
TransIT:DEV:wdl2mltidbs01.tsysacquiring.org
TransIT:DEV:wdl2mltidbs02.tsysacquiring.org
TransIT Rpt-Txn PF-DCE:QA:wql1trandbs01.tsysacquiring.org
TransIT Rpt-Txn PF-DCE:QA:wql1trandbs02.tsysacquiring.org
TransIT Rpt-Txn PF-DCE:QA:wql1trandbs03.tsysacquiring.org
TransIT Rpt-Txn:UAT:wul2trandbs04.tsysacquiring.org
TransIT Rpt-Txn:UAT:wul2trandbs05.tsysacquiring.org
TransIT Rpt-Txn:UAT:wul2trandbs06.tsysacquiring.org
TransIT Rpt-Txn:UAT:wul2trandbs07.tsysacquiring.org

vishalbh@octov1:/home/vishalbh$ cat ora-prod
#!/usr/local/bin/bash
#
clear
#
echo "Oracle PRODUCTION Environment ..."
echo "---------------------------------"
#
cat /home/jlontok/ora-prod.host.lst|sort -t: -k1|grep -E -v '(^#)'|awk -F: '{printf "%-45s %-14s %s\n", $3, $2, $1}'
#
PS3="Use number to select an Oracle server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/jlontok/ora-prod.host.lst|awk -F: '{print $3}'|sort|uniq)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/jlontok/ora-prod.host.lst|grep $var1|awk -F: '{printf "%-45s %-14s", $1, $2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - oracle
    break
done

vishalbh@octov1:/home/vishalbh$ cat ora-prod.host.lst
Control Center Sec:Prod - East:epl1tsysdbs01.vitalps.com
Control Center Pri:Prod - West:wpl1tsysdbs01.vitalps.com
Control-M Sec:Prod - East:epl1tsysdbs01.vitalps.com
Control-M Pri:Prod - West:wpl1tsysdbs01.vitalps.com
MAP Pri:Prod - East:epl1mapxdbs01.tsysacquiring.org
MAP Sec:Prod - East:epl1mapxdbs02.tsysacquiring.org
MAP Sec:Prod - West:wpl1mapxdbs01.tsysacquiring.org
OEM Tempe:Prod - West:octgcpapp01.vitalps.com
OEM TransIT:Prod - West:wpl2mltidbs01.tsysacquiring.org
OMi Sec:Prod - East:eml2tsysdbs01.tas.corp
OMi Pri:Prod - West:wml2tsysdbs01.tas.corp
Sterling Integrator Act:Prod - West:dcwhan02.vitalps.com
Sterling Integrator Pas:Prod - West:dcwhan03.vitalps.com
Sterling Integrator Sec:Prod - East:eph1tsysdbs01.vitalps.com
StrongAuth Pri:Prod - East:epl2tsysdbs01.vitalps.com
StrongAuth Sec:Prod - East:epl2tsysdbs02.vitalps.com
StrongAuth Sec:Prod - West:wpl2tsysdbs01.vitalps.com
TransIT Prod/UAT backup:Prod - East:epl1mltidbs01.tsysacquiring.org
TransIT Reporting East Node1:Prod - East:epl1trandbrpt1.tsysacquiring.org
TransIT Reporting East Node2:Prod - East:epl1trandbrpt2.tsysacquiring.org
TransIT Reporting East Node3:Prod - East:epl1trandbrpt3.tsysacquiring.org
TransIT Reporting West Node1:Prod - West:wpl1trandbrpt1.tsysacquiring.org
TransIT Reporting West Node2:Prod - West:wpl1trandbrpt2.tsysacquiring.org
TransIT Reporting West Node3:Prod - West:wpl1trandbrpt3.tsysacquiring.org
TransIT Transaction East Node1:Prod - East:epl1trandbtxn1.tsysacquiring.org
TransIT Transaction East Node2:Prod - East:epl1trandbtxn2.tsysacquiring.org
TransIT Transaction East Node3:Prod - East:epl1trandbtxn3.tsysacquiring.org
TransIT Transaction West Node1:Prod - West:wpl1trandbtxn1.tsysacquiring.org
TransIT Transaction West Node2:Prod - West:wpl1trandbtxn2.tsysacquiring.org
TransIT Transaction West Node3:Prod - West:wpl1trandbtxn3.tsysacquiring.org
Veridata:Prod - East:epl1trandbs03.tsysacquiring.org
Veridata:Prod - West:wpl1trandbs01.tsysacquiring.org

vishalbh@octov1:/home/vishalbh$ cat gg-perf
#!/usr/local/bin/bash
#
clear
#
echo "GoldenGate - PERF -  Environment ..."
echo "---------------------------------"
#
cat /home/vishalbh/gg-perf.host.lst|sort -t: -k1|grep -E -v '(^#)'|awk -F: '{printf "%-45s %-14s %s\n", $3, $2, $1}'
#
PS3="Use number to select an GoldenGate server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/vishalbh/gg-perf.host.lst|awk -F: '{print $3}'|sort|uniq)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/vishalbh/gg-perf.host.lst|grep $var1|awk -F: '{printf "%-45s %-14s", $1, $2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - goldengate
    break
done

vishalbh@octov1:/home/vishalbh$ cat inf-non
#!/usr/local/bin/bash
#
clear
#
echo "Informix QA-DEV-UAT Environment ..."
echo "---------------------------------"
#
cat /home/vishalbh/inf-non.host.lst|sort -t: -k1|grep -E -v '(^#)'|awk -F: '{printf "%-45s %-14s %s\n", $3, $2, $1}'
#
PS3="Use number to select an Informix server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/vishalbh/inf-non.host.lst|awk -F: '{print $3}'|sort|uniq)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/vishalbh/inf-non.host.lst|grep $var1|awk -F: '{printf "%-45s %-14s", $1, $2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - informix
    break
done

vishalbh@octov1:/home/vishalbh$ cat gg-prod
#!/usr/local/bin/bash
#
clear
#
echo "GoldenGate - UAT -  Environment ..."
echo "---------------------------------"
#
cat /home/vishalbh/gg-prod.host.lst|sort -t: -k1|grep -E -v '(^#)'|awk -F: '{printf "%-45s %-14s %s\n", $3, $2, $1}'
#
PS3="Use number to select an GoldenGate server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/vishalbh/gg-prod.host.lst|awk -F: '{print $3}'|sort|uniq)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/vishalbh/gg-prod.host.lst|grep $var1|awk -F: '{printf "%-45s %-14s", $1, $2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - goldengate
    break
done

vishalbh@octov1:/home/vishalbh$ cat gg-uat
#!/usr/local/bin/bash
#
clear
#
echo "GoldenGate - UAT -  Environment ..."
echo "---------------------------------"
#
cat /home/vishalbh/gg-uat.host.lst|sort -t: -k1|grep -E -v '(^#)'|awk -F: '{printf "%-45s %-14s %s\n", $3, $2, $1}'
#
PS3="Use number to select an GoldenGate server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/vishalbh/gg-uat.host.lst|awk -F: '{print $3}'|sort|uniq)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/vishalbh/gg-uat.host.lst|grep $var1|awk -F: '{printf "%-45s %-14s", $1, $2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - goldengate
    break
done

vishalbh@octov1:/home/vishalbh$ cat inf-prod
#!/usr/local/bin/bash
#
clear
#
echo "Informix PRODUCTION Environment ..."
echo "---------------------------------"
#
cat /home/jlontok/inf-prod.host.lst|sort -t: -k1|grep -E -v '(^#)'|awk -F: '{printf "%-45s %-14s %s\n", $3, $2, $1}'
#
PS3="Use number to select an Informix server or 'exit' to cancel: "
#
echo ""
#
select var1 in $(cat /home/jlontok/inf-prod.host.lst|awk -F: '{print $3}'|sort|uniq)
do
    echo ""
    if [[ "$REPLY" == exit ]]; then break; fi

    if [[ "$var1" == "" ]]
    then
        echo "'$REPLY' is not a valid number"
        continue
    fi
    var2=`cat /home/jlontok/inf-prod.host.lst|grep $var1|awk -F: '{printf "%-45s %-14s", $1, $2}'`
    echo "Logging in to server:  "$var2"        --> "$var1
    echo ""
    sleep 1
    pbrun -h $var1 su - informix
    break
done

vishalbh@octov1:/home/vishalbh$ PuTTY
