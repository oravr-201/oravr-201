-- Create directory 
create or replace directory BKUP  as '/opt/oracle/gi_software/BKUP';
GRANT read, write ON DIRECTORY BKUP TO BKUP; 
grant all on directory BKUP to BKUP

grant DATAPUMP_EXP_FULL_DATABASE to exp1 WITH ADMIN OPTION;
grant DATAPUMP_IMP_FULL_DATABASE to exp1 WITH ADMIN OPTION;
grant dba,pdb_dba,cdb_dba to exp1 WITH ADMIN OPTION;


==========================================================================================================================================================================================
--11g to 19c :


--Exp Normal users :

	expdp "'/ as sysdba'" directory=BKUPS dumpfile=data_vbs_%U.dmp logfile=data_vbs.log cluster=N  parallel=4 compression=all  schemas= GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\",table:\"like \'INFONOX_SERVICE_USAGE%\'\" 
"
--Exp Snox and Transnos_iox

	expdp "'/ as sysdba'" directory=BKUPS dumpfile=SNOX4TRANSNOX_CPASS_%U.dmp logfile=SNOX4TRANSNOX_CPASS.log cluster=N  parallel=4 compression=all  schemas=SNOX4TRANSNOX_CPASS GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\",table:\"like \'INFONOX_SERVICE_USAGE%\'\" 
"
	expdp "'/ as sysdba'" directory=BKUPS dumpfile=TRANSNOX_CPASS_%U.dmp logfile=TRANSNOX_CPASS.log cluster=N  parallel=4 compression=all  schemas=TRANSNOX_CPASS GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\",table:\"like \'INFONOX_SERVICE_USAGE%\'\" 
"

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


--Exp Normal users :
		impdp  "'/ as sysdba'" directory=BKUP dumpfile=data_vbs_%U.dmp logfile=imp_data_vbs.log cluster=N  parallel=4 schemas=

--Exp Snox and Transnos_iox
	
		impdp "'/ as sysdba'" directory=BKUP dumpfile=SNOX4TRANSNOX_CPASS_%U.dmp logfile=txn_imp_SNOX4TRANSNOX_CPASS.log cluster=N  parallel=4   REMAP_SCHEMA=SNOX4TRANSNOX_CPASS:SNOX4TRANSNOX

sleep 300

		impdp "'/ as sysdba'" directory=BKUP dumpfile=TRANSNOX_CPASS_%U.dmp logfile=txn_imp_TRANSNOX_CPASS.log cluster=N  parallel=4  REMAP_SCHEMA=TRANSNOX_CPASS:TRANSNOX_IOX

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--check SYNONYM


select 'CREATE OR REPLACE SYNONYM '|| (case when owner = 'TRANSNOX_CPASS' then 'TRANSNOX_IOX' when owner = 'SNOX4TRANSNOX_CPASS' THEN 'SNOX4TRANSNOX' ELSE owner END)||'.'||
synonym_name||' FOR '||(case when owner = 'TRANSNOX_CPASS' then 'TRANSNOX_IOX' when owner = 'SNOX4TRANSNOX_CPASS' THEN 'SNOX4TRANSNOX' ELSE owner END)||'.'||table_name||';' updated_sysnonym_script
from dba_synonyms
where table_owner IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS') and
owner in (
'TRANSNOX_CPASS',
'SNOX4TRANSNOX_CPASS',
'TRANSIT_GATEWAY_TNOX_3132','TRANSIT_GATEWAY_SNOX_3132',
'TRANSIT_FE_TNOX_3132',
'TRANSIT_FE_SNOX_3132',
'TRANSIT_SMSNOX_TNOX_3132',
'TRANSIT_SMSNOX_SNOX_3132');



==========================================================================================================================================================================================






































































--common user without c##
alter session set "_ORACLE_SCRIPT"=true;


--copy 
scp /acfs/oracle/dpump/uat51_to_new12c.dmp vishalbh@10.100.101.20:/software/oracle/joselle/

--download 
scp vishalbh@10.100.101.20:/software/oracle/joselle/exp_perf2archive_20_may_2019.dmp /opt/oracle/gi_software

scp vishalbh@wul2trandbs04.tsysacquiring.org:/acfs/oracle/dpump/uat51_to_new12c.dmp . 




--12c export import for pluggable examples .

nohup impdp vishalbh/ispl_201@DEV_PDB dumpfile=TRANSNOX.dmp  directory=BKUPS schemas=TRANSNOX_CPASS  logfile=TRANSNOX_imp.log &

nohup expdp vishalbh dumpfile=TRANSNOX.dmp  directory=BKUPS schemas=TRANSIT_SMSNOX_TNOX_3125  logfile=TRANSNOX.log &


-- exclude archive log 
transform=disable_archive_logging:Y 
 


arcot refresh request  QA :QA 

/*  
impdp exp@QA_PDB1  DIRECTORY=BKUPS dumpfile=webfort.dmp schemas=WEBFORT1,WEBFORT_NEW,WEBFORT logfile=webfort_1_imp.log grants=y

expdp "'/ as sysdba'"  DIRECTORY=BKUPS dumpfile=webfort.dmp schemas=WEBFORT1,WEBFORT_NEW,WEBFORT logfile=webfort_1_imp.log grants=y



*/



rollback schema request 


/*

nohup impdp "'/ as sysdba'"  directory=BACKUP  dumpfile=SR955922_manoj.dmp logfile=SR955922_manoj_imp.log grants=y REMAP_SCHEMA=TRANSNOX_CPASS:TNOX_CPASS,SNOX4TRANSNOX_CPASS:SNOX_CPASS,TRANSIT_GATEWAY_TNOX_3127:RB_GATEWAY_TNOX_3127,TRANSIT_GATEWAY_SNOX_3127:RB_GATEWAY_SNOX_3127,TRANSIT_FE_TNOX_3127:RB_FE_TNOX_3127 ,TRANSIT_FE_SNOX_3127:RB_FE_SNOX_3127,TRANSIT_SMSNOX_TNOX_3127:RB_SMSNOX_TNOX_3127,TRANSIT_SMSNOX_SNOX_3127:RB_SMSNOX_SNOX_3127 &


nohup expdp "'/ as sysdba'" directory=BKUPS_1 dumpfile=SR955922_manoj.dmp logfile=SR955922_manoj.log schemas=TRANSNOX_CPASS,SNOX4TRANSNOX_CPASS,TRANSIT_GATEWAY_TNOX_3127,TRANSIT_GATEWAY_SNOX_3127,TRANSIT_FE_TNOX_3127,TRANSIT_FE_SNOX_3127,TRANSIT_SMSNOX_TNOX_3127 TRANSIT_SMSNOX_SNOX_3127 GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\",table:\"like \'INFONOX_SERVICE_USAGE%\'\" &

"
TRANSIT_FE_TNOX_3127		 > 			RB_FE_TNOX_3127
TRANSIT_FE_SNOX_3127		 > 			RB_FE_SNOX_3127
TRANSIT_GATEWAY_TNOX_3127	 > 			RB_GATEWAY_TNOX_3127
TRANSIT_GATEWAY_SNOX_3127 	 > 			RB_GATEWAY_SNOX_3127
TRANSIT_SMSNOX_TNOX_3127 	 > 			RB_SMSNOX_TNOX_3127
TRANSIT_SMSNOX_SNOX_3127	 > 			RB_SMSNOX_SNOX_3127
SNOX4TRANSNOX_CPASS    		 > 			SNOX_CPASS
TRANSNOX_CPASS         		 > 			TNOX_CPASS

drop user RB_FE_TNOX_3127 cascade;
drop user RB_FE_SNOX_3127 cascade;
drop user RB_GATEWAY_TNOX_3127 cascade;
drop user RB_GATEWAY_SNOX_3127 cascade;
drop user RB_SMSNOX_TNOX_3127 cascade;
drop user RB_SMSNOX_SNOX_3127 cascade;
drop user SNOX_CPASS cascade;
drop user TNOX_CPASS cascade;

 */

compression=all


Jira refresh request : QA : DEV12C

/*  
nohup expdp "'/ as sysdba'" directory=DPUMP dumpfile=subodh_07_may2019.dmp logfile=subodh_07_may2019.log schemas=TSYSJIRA2,TSYSJIRA4,TSYSJIRA,TSYSJIRA3,TSYSJIRA1  GRANTS=y  compression=all &

nohup impdp "'/ as sysdba'" directory=DPUMP dumpfile=subodh_07_may2019.dmp logfile=subodh_07_may2019.log schemas=TSYSJIRA2,TSYSJIRA4,TSYSJIRA,TSYSJIRA3,TSYSJIRA1  GRANTS=y  &


scp vishalbh@10.100.101.20:/software/oracle/joselle/subodh_07_may2019.dmp  .
scp -rv /recovery/oracle/dumpfiles/subodh_07_may2019.dmp vishalbh@10.100.101.20:/software/oracle/joselle/

nohup impdp EXP/exp@DEV_PDB dumpfile=subodh_07_may2019.dmp  directory=BKUPS schemas=TSYSJIRA1,TSYSJIRA4,TSYSJIRA2,TSYSJIRA3,TSYSJIRA  logfile=imp_subodh_07_may2019.dmp.log transform=disable_archive_logging:Y &

drop user TSYSJIRA2	cascade ;
drop user TSYSJIRA4 cascade ;
drop user TSYSJIRA  cascade ;
drop user TSYSJIRA3 cascade ;
drop user TSYSJIRA1 cascade ;



*/
















nohup expdp "'/ as sysdba'" directory=BKUPS dumpfile=16APR2019NRREFRESH.dmp logfile=16APR2019NRREFRESH.log schemas=TRANSIT_SMSNOX_TNOX_3126,TRANSIT_SMSNOX_SNOX_3126,TRANSIT_GATEWAY_TNOX_3126,TRANSIT_GATEWAY_SNOX_3126,TRANSIT_FE_TNOX_3126,TRANSIT_FE_SNOX_3126,TRANSNOX_CPASS,SNOX4TRANSNOX_CPASS GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\",table:\"like \'INFONOX_SERVICE_USAGE%\'\" &

"
"

 impdp vishalbh@SRVPDB1  directory=BKUPS_1  dumpfile=16APR2019NRREFRESH.dmp logfile=16APR2019NRREFRESH_imp.log    
 nohup impdp vishalbh/********@QA_PDB1 directory=BKUPS dumpfile=expdp_qa_bkups.dmp logfile=expdp_qa_bkups_imp.log full=y
 
 
 

 
 
 

--

nohup expdp "'/ as sysdba'" directory=BKUPS_1 dumpfile="expdp_qa_bkups.dmp" logfile="logs_expdp_qa_bkups.log" exclude=statistics exclude=table:\"like \'INFONOX_SERVICE_USAGE%\'\",table:\"like \'SN_TEMP%\'\" exclude=schema:\" IN \(\'XS$NULL\',\'XDB\',\'WMSYS\',\'TOAD\',\'SYSTEM\',\'SYSMAN\',\'SYS\',\'SPATIAL_WFS_ADMIN_USR\',\'SPATIAL_CSW_ADMIN_USR\',\'SI_INFORMTN_SCHEMA\',\'RMAN\',\'OWBSYS_AUDIT\',\'OWBSYS\',\'OUTLN\',\'ORDSYS\',\'ORDPLUGINS\',\'ORDDATA\',\'ORACLE_OCM\',\'OPS$ORACLE\',\'OLAPSYS\',\'MGMT_VIEW\',\'MDSYS\',\'FLOWS_FILES\',\'EXFSYS\',\'DIP\',\'DBSNMP\',\'CTXSYS\',\'APPQOSSYS\',\'APEX_PUBLIC_USER\',\'APEX_030200\',\'ANONYMOUS\',\'TNOX_CPASS\'\)\" FULL=Y &


"
nohup impdp vishalbh/vb12345@QA_PDB1 directory=BKUPS dumpfile=expdp_qa_bkups.dmp logfile=expdp_qa_bkups_imp.log full=y &


/opt/oracle/gi_software/expdp_qa_bkups_imp.log

nohup impdp vb/vb12345@QA_PDB1 dumpfile=TRANSNOX.dmp  directory=BKUPS schemas=TRANSNOX_CPASS  logfile=TRANSNOX_imp.log &


nohup expdp "'/ as sysdba'" directory=BKUPS_1 dumpfile="expdp_qa_bkups.dmp" logfile="logs_expdp_qa_bkups.log"  full=y exclude=statistics,table:\"like \'INFONOX_SERVICE_USAGE%\'\",table:\"like \'SC_TEMP%\'\", schema:\" in \(\'XS$NULL\',\'XDB\',\'WMSYS\',\'TOAD\',\'SYSTEM\',\'SYSMAN\',\'SYS\',\'SPATIAL_WFS_ADMIN_USR\',\'SPATIAL_CSW_ADMIN_USR\',\'SI_INFORMTN_SCHEMA\',\'RMAN\',\'OWBSYS_AUDIT\',\'OWBSYS\',\'OUTLN\',\'ORDSYS\',\'ORDPLUGINS\',\'ORDDATA\',\'ORACLE_OCM\',\'OPS$ORACLE\',\'OLAPSYS\',\'MGMT_VIEW\',\'MDSYS\',\'FLOWS_FILES\',\'EXFSYS\',\'DIP\',\'DBSNMP\',\'CTXSYS\',\'APPQOSSYS\',\'APEX_PUBLIC_USER\',\'APEX_030200\',\'ANONYMOUS\',\'TNOX_CPASS\'\)\" &

nohup expdp "'/ as sysdba'"  directory=BKUPS dumpfile=16APR2019NRREFRESH.dmp logfile=16APR2019NRREFRESH.log schemas=TRANSIT_SMSNOX_TNOX_3126,TRANSIT_SMSNOX_SNOX_3126,TRANSIT_GATEWAY_TNOX_3126,TRANSIT_GATEWAY_SNOX_3126,TRANSIT_FE_TNOX_3126,TRANSIT_FE_SNOX_3126,TRANSNOX_CPASS,SNOX4TRANSNOX_CPASS GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\",table:\"like \'INFONOX_SERVICE_USAGE%\'\" &  
""'




--orace 12c expdp/impdp with disable archivelog

 nohup expdp "'/ as sysdba'"  directory=BKUPS dumpfile=19APR2019NRREFRESH.dmp logfile=19APR2019NRREFRESH.log schemas=ABHADORIA, AKIBEY, ASATYAMURTI, ASHRIVASTAV ,CODETESTER,DBAUDIT,DBHATT,DBHOSALE,DBJOBS,DBRELEASE,DJOSHI,DMULEY,DUPADHYE,GASHISH,GPATEL,HBANDI,HTTPUNIT,KBARAL,KEYNOX,KEYNOX_FX,KKHANORKAR,MANOJPAL,MDANISH,MGMT_VIEW,MNAYAK,PAMBURE,PBHANGE,PJAIN,PPADMANABHAN,PSATHE,PTIBILE,PURGEDATA,PVARMA,RMANADMIN,ROHITDESHMUKH,ROMANWAR,RPANDEY,RRANJAN,RSHIWALKAR,RURANE,SBHAMARE,SGUPTA,SGURAV,SKAMBLE,SMATHEW,SNOX_API_AUTOMATION,SNOX4TRANSNOX_CPASS,SYSTEM,TLAKKIMSETTY,TRANSIT_FE_SNOX_3124,TRANSIT_FE_SNOX_3125,TRANSIT_FE_SNOX_3126,TRANSIT_FE_TNOX_3124,TRANSIT_FE_TNOX_3125,TRANSIT_FE_TNOX_3126,TRANSIT_GATEWAY_SNOX_3124,TRANSIT_GATEWAY_SNOX_3125,TRANSIT_GATEWAY_SNOX_3126,TRANSIT_GATEWAY_TNOX_3124,TRANSIT_GATEWAY_TNOX_3125,TRANSIT_GATEWAY_TNOX_3126,TRANSIT_SMSNOX_SNOX_3124,TRANSIT_SMSNOX_SNOX_3125,TRANSIT_SMSNOX_SNOX_3126,TRANSIT_SMSNOX_TNOX_3124,TRANSIT_SMSNOX_TNOX_3125,TRANSIT_SMSNOX_TNOX_3126,TRANSNOX_CPASS,TSYSJIRA,TSYSJIRA_2,TSYSJIRA_NEW,TSYSJIRA_REPL,VNGO,VWAYKOLE GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\",table:\"like \'INFONOX_SERVICE_USAGE%\'\" &  
 
 
 
 
 "

 --transform=disable_archive_logging:Y

 
  nohup impdp   vishalbh/vb12345@SRVPDB1 directory=BKUP dumpfile=19APR2019NRREFRESH.dmp logfile=19APR2019NRREFRESH_imp.log transform=disable_archive_logging:Y schemas=ABHADORIA, AKIBEY, ASATYAMURTI, ASHRIVASTAV ,CODETESTER,DBAUDIT,DBHATT,DBHOSALE,DBJOBS,DBRELEASE,DJOSHI,DMULEY,DUPADHYE,GASHISH,GPATEL,HBANDI,HTTPUNIT,KBARAL,KEYNOX,KEYNOX_FX,KKHANORKAR,MANOJPAL,MDANISH,MGMT_VIEW,MNAYAK,PAMBURE,PBHANGE,PJAIN,PPADMANABHAN,PSATHE,PTIBILE,PURGEDATA,PVARMA,RMANADMIN,ROHITDESHMUKH,ROMANWAR,RPANDEY,RRANJAN,RSHIWALKAR,RURANE,SBHAMARE,SGUPTA,SGURAV,SKAMBLE,SMATHEW,SNOX_API_AUTOMATION,SNOX4TRANSNOX_CPASS,SYSTEM,TLAKKIMSETTY,TRANSIT_FE_SNOX_3124,TRANSIT_FE_SNOX_3125,TRANSIT_FE_SNOX_3126,TRANSIT_FE_TNOX_3124,TRANSIT_FE_TNOX_3125,TRANSIT_FE_TNOX_3126,TRANSIT_GATEWAY_SNOX_3124,TRANSIT_GATEWAY_SNOX_3125,TRANSIT_GATEWAY_SNOX_3126,TRANSIT_GATEWAY_TNOX_3124,TRANSIT_GATEWAY_TNOX_3125,TRANSIT_GATEWAY_TNOX_3126,TRANSIT_SMSNOX_SNOX_3124,TRANSIT_SMSNOX_SNOX_3125,TRANSIT_SMSNOX_SNOX_3126,TRANSIT_SMSNOX_TNOX_3124,TRANSIT_SMSNOX_TNOX_3125,TRANSIT_SMSNOX_TNOX_3126,TRANSNOX_CPASS,TSYSJIRA,TSYSJIRA_2,TSYSJIRA_NEW,TSYSJIRA_REPL,VNGO,VWAYKOLE GRANTS=y &
 










alter user VISHALBH set container_data=all for REGTXNDBPDB1,REGTXNDBPDB2 container=current;
 
GRANT CREATE SESSION, SYSOPER,PDB_DBA,DBA, CREATE PLUGGABLE DATABASE TO vishalbh CONTAINER=ALL ;












--UAT EXPORT/IMPORT request (11g to 12c)



 nohup expdp "'/ as sysdba'"  directory=IMP_DPUMP dumpfile=uat51_to_new12c.dmp logfile=uat51_to_new12c.log schemas=DBHOSALE,DBRELEASE,GASHISH,HBANDI,KEYNOX,KEYNOX_FX,MANOJPAL,ROMANWAR,SGURAV,SNOX4TRANSNOX_CPASS,TRANSNOX_CPASS,transit_fe_tnox_3126,transit_fe_snox_3126,transit_gateway_tnox_3126,transit_gateway_snox_3126,transit_smsnox_tnox_3126,transit_smsnox_snox_3126,transit_fe_tnox_3127,transit_fe_snox_3127,transit_gateway_tnox_3127,transit_gateway_snox_3127,transit_smsnox_tnox_3127,transit_smsnox_snox_3127,transit_fe_tnox_3128,transit_fe_snox_3128,transit_gateway_tnox_3128,transit_gateway_snox_3128,transit_smsnox_tnox_3128,transit_smsnox_snox_3128 GRANTS=y exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\",table:\"like \'INFONOX_SERVICE_USAGE%\'\" &  
 
 
 "
 KEYNOX

 --transform=disable_archive_logging:Y

 
 nohup impdp "'/ as sysdba'"  directory=VB_DUMPS dumpfile=uat51_to_new12c.dmp logfile=imp_rpt_uat51_to_new12c.log schemas=DBHOSALE,DBRELEASE,GASHISH,HBANDI,KEYNOX_FX,MANOJPAL,ROMANWAR,SGURAV,SNOX4TRANSNOX_CPASS,TRANSNOX_CPASS,TRANSIT_FE_TNOX_3126,TRANSIT_FE_SNOX_3126,TRANSIT_GATEWAY_TNOX_3126,TRANSIT_GATEWAY_SNOX_3126,TRANSIT_SMSNOX_TNOX_3126,TRANSIT_SMSNOX_SNOX_3126,TRANSIT_FE_TNOX_3127,TRANSIT_FE_SNOX_3127,TRANSIT_GATEWAY_TNOX_3127,TRANSIT_GATEWAY_SNOX_3127,TRANSIT_SMSNOX_TNOX_3127,TRANSIT_SMSNOX_SNOX_3127,TRANSIT_FE_TNOX_3128,TRANSIT_FE_SNOX_3128,TRANSIT_GATEWAY_TNOX_3128,TRANSIT_GATEWAY_SNOX_3128,TRANSIT_SMSNOX_TNOX_3128,TRANSIT_SMSNOX_SNOX_3128 GRANTS=y  transform=disable_archive_logging:Y &
















