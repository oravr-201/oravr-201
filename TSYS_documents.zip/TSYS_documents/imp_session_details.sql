/* Formatted on 5/27/2019 3:17:03 AM (QP5 v5.294) */
  SELECT A.SID,
         A.SERIAL#,
         B.SPID,
         A.USERNAME,
         A.OSUSER,
         A.MACHINE,
         A.PROGRAM,
         A.STATUS,
         A.SQL_ID,
         I.INSTANCE_NAME,
         SUBSTR(SA.SQL_TEXT, 1, 1024)  CURRENT_SQL,
         L.SQL_FULLTEXT
    FROM GV$SESSION A,
         GV$PROCESS B,
         GV$INSTANCE I,
         V$SQLAREA SA,
          V$SQL L
   WHERE     A.PADDR = B.ADDR
         AND A.INST_ID = I.INST_ID
         AND L.SQL_ID = A.SQL_ID
         AND A.SQL_ADDRESS = SA.ADDRESS(+)
         AND A.SQL_HASH_VALUE = SA.HASH_VALUE(+)
         AND A.MACHINE = 'wql1tranapp02.tsysacquiring.org'
--         AND I.INSTANCE_NAME  IN ('txnDCE1','txnDCE2')
         AND I.INSTANCE_NAME  IN ('txnDCE3')
ORDER BY A.STATUS;


