--Batch 
select batch_status,settle_date,count(distinct ssb.batch_seq_id) batches_posted
from TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH ssb, transnox_iox.trans_settlement ts
where ssb.batch_seq_id  = ts.batch_seq_id and ssb.time_stamp > sysdate-2/24 and ts.timestamp > sysdate-1/24
group by batch_status,settle_date;






--Batch 
select *
from TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH ssb, transnox_iox.trans_settlement ts
where ssb.batch_seq_id  = ts.batch_seq_id and ssb.time_stamp > sysdate-2/24 and ts.timestamp > sysdate-1/24
--group by batch_status,settle_date;


select sysdate from dual;

TRANSIT_SMSNOX_TNOX_3128.CAPTURE_HARMONY_SETTLE_PRE

select settlement_status,batch_status,settle_date,count(distinct ssb.batch_seq_id)
from TRANSNOX_IOX.TRANS_SETTLEMENT ts, transnox_iox.snox_settlement_batch ssb
where ts.batch_seq_id = ssb.batch_seq_id and timestamp > sysdate-1/24 
group by settlement_status,batch_status,settle_date;

select * from TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP where executedon > sysdate-1/24 and object_name = 'CAPTURE_HARMONY_SETTLE_PRE'order by executedon desc






select sysdate,a.* from snox4transnox.recon_status a order by start_ts desc;

select * from snox4transnox.recon_config where recon_type  = 'TAS_CAPTURE_JOB'

select * from TRANSNOX_IOX.BATCH_STEP_EXECUTION where step_name like '%slave%' and start_time > sysdate-1/24;

select * from TRANSNOX_IOX.BATCH_STEP_EXECUTION    where job_execution_id  = 1412677;

select * from TRANSNOX_IOX.CAPTURE_MERCHANT_GROUP_STAG where settle_group_id  = '4ae127f9b1a145d589a15af93a83d2de' and 

select * from TRANSNOX_IOX.CAPTURE_TRANS_DETAILS_STAG where settle_group_id  ='4ae127f9b1a145d589a15af93a83d2de'; 




SELECT *
  FROM TRANSNOX_IOX.capture_batch_info
 WHERE     SETTLE_GROUP_ID IN ('14789387c02f4ac7a0555b2f0a1df8ee')
       AND time_stamp BETWEEN TO_DATE ('12/13/2019 01:45:00',
                                       'MM/DD/YYYY HH24:MI:SS')
                          AND TO_DATE ('12/13/2019 02:00:00',
                                       'MM/DD/YYYY HH24:MI:SS')
       AND BATCH_READY_TO_PICK = 'Y'






















  SELECT TO_DATE (recon_time || ':45:00', 'MM/DD/YYYY HH24:MI:SS') recon_time,
         groups_created,
         total_transaction_count,
         batches_posted,
         db_execution_time_in_sec,
         JOB_START_TIME,
         JOB_END_TIME,
         total_job_exec_time_in_sec,
         settled_transaction_count
    FROM (  SELECT TO_CHAR (
                      TO_DATE (SUBSTR (input_string, 52, 19),
                               'DD-MM-YYYY HH24:MI:SS'),
                      'MM/DD/YYYY HH24')
                      recon_time,
                   SUM (rec_count)  total_transaction_count,
                   MAX (execution_time) db_execution_time_in_sec,
                   COUNT (1)        groups_created
              FROM TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP
             WHERE     object_name = 'CAPTURE_HARMONY_SETTLE_PRE'
                   AND executedon BETWEEN TO_DATE ('02/15/2020 03:45:00',
                                                   'MM/DD/YYYY HH24:MI:SS')
                                      AND TO_DATE ('02/15/2020 04:45:00',
                                                   'MM/DD/YYYY HH24:MI:SS')
                   AND OUTPUT_MSG = 'Success'
          GROUP BY TO_CHAR (
                      TO_DATE (SUBSTR (input_string, 52, 19),
                               'DD-MM-YYYY HH24:MI:SS'),
                      'MM/DD/YYYY HH24')) a,
         (SELECT job_execution_id,
                 job_date,
                 JOB_START_TIME,
                 JOB_END_TIME,
                     EXTRACT (
                        DAY FROM (JOB_END_TIME - JOB_START_TIME) DAY TO SECOND)
                   * 86400
                 +   EXTRACT (
                        HOUR FROM (JOB_END_TIME - JOB_START_TIME) DAY TO SECOND)
                   * 3600
                 +   EXTRACT (
                        MINUTE FROM (JOB_END_TIME - JOB_START_TIME) DAY TO
                                                                    SECOND)
                   * 60
                 + EXTRACT (
                      SECOND FROM (JOB_END_TIME - JOB_START_TIME) DAY TO SECOND)
                    AS total_job_exec_time_in_sec
            FROM (  SELECT job_execution_id,
                           TO_CHAR (START_TIME, 'MM/DD/YYYY HH24') job_date,
                           MIN (START_TIME)                    JOB_START_TIME,
                           MAX (end_time)                      JOB_END_TIME
                      FROM TRANSNOX_IOX.BATCH_STEP_EXECUTION
                     WHERE     step_name LIKE 'slave%'
                           AND status = 'COMPLETED'
                           AND START_TIME BETWEEN TO_DATE (
                                                     '02/15/2020 03:45:00',
                                                     'MM/DD/YYYY HH24:MI:SS')
                                              AND TO_DATE (
                                                     '02/15/2020 04:45:00',
                                                     'MM/DD/YYYY HH24:MI:SS')
                  GROUP BY job_execution_id,
                           TO_CHAR (START_TIME, 'MM/DD/YYYY HH24'))) b,
         (  SELECT TO_CHAR (settle_date, 'MM/DD/YYYY HH24') settle_date,
                   batch_status,
                   COUNT (DISTINCT ssb.batch_seq_id)    batches_posted,
                   COUNT (ts.transaction_id)
                      settled_transaction_count
              FROM TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH ssb,
                   transnox_iox.trans_settlement  ts
             WHERE     SSB.BATCH_SEQ_ID = TS.BATCH_SEQ_ID
                   AND batch_status = 'SUCCESS'
                   AND settle_date BETWEEN TO_DATE ('02/15/2020 03:45:00',
                                                    'MM/DD/YYYY HH24:MI:SS')
                                       AND TO_DATE ('02/15/2020 04:45:00',
                                                    'MM/DD/YYYY HH24:MI:SS')
                   AND time_stamp >
                          TO_DATE ('02/15/2020 03:45:00',
                                   'MM/DD/YYYY HH24:MI:SS')
          GROUP BY TO_CHAR (settle_date, 'MM/DD/YYYY HH24'), batch_status) c
   WHERE a.recon_time = b.job_date AND a.recon_time = c.settle_date
ORDER BY 1 ASC






------------------------------

-- resend last hour batches which is failed 


CREATE TABLE stujare.trans_settle_8_45_10_feb
NOLOGGING
AS
   SELECT *
     FROM transnox_iox.trans_settlement
    WHERE transaction_id IN
             (SELECT ts.transaction_id
                FROM TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH ssb,
                     transnox_iox.trans_settlement ts
               WHERE     ssb.batch_seq_id = ts.batch_seq_id
                     AND ssb.settle_date > SYSDATE - 2 / 24
                     AND ssb.batch_status = 'FAILED'
                     AND settlement_status = 'FAILED'
                     and ssb.batch_seq_id<>37123568);
                     
                    

 

UPDATE TRANSNOX_IOX.TRANS_SETTLEMENT TS
   SET TS.SETTLEMENT_STATUS = 'RESEND', TS.SETTLEMENT_TYPE = 'IMMEDIATE'
 WHERE TRANSACTION_ID IN
          (SELECT TRANSACTION_ID FROM stujare.trans_settle_8_45_10_feb);
          
          --2439 rows to be updated

 

UPDATE TRANSNOX_IOX.TRANSACTION XTN
   SET XTN.LAST_MODIFIED_TIME_STAMP = SYSDATE
 WHERE TRANSACTION_ID IN
          (SELECT TRANSACTION_ID FROM stujare.trans_settle_8_45_10_feb);
          
          --2439 rows to be updated





