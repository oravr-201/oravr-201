



cd /home/informix/work/disk_space
cat available_chunks.info
--09/14/2019 sum_week_20190909_chk01 vishalbh


# Check to seure there is not a link pointing to the raw volume you are about to use.
# ls -ltr /app/links/dceposr/ | grep -i spare

# Check to ensure that the raw volume you are about to use is not in use.
# /usr/sbin/fuser /dev/vg_ifx07/rspare1gb_4

# Check the actual size of the volume you are about to use.
# /usr/sbin/lvdisplay -v /dev/vg_ifx07/spare1gb_4 | grep "LV Size"

# If all is clear then build your link and then add your chunk.
# ln -s /dev/vg_ifx07/rspare1gb_4 /app/links/dceposr/??_??????201402??_chk02

# onspaces -a fe_child20140204 -p /app/links/dceposr/fe_child20140204_chk02 -o 0 -s 2048000



east :

/usr/sbin/fuser /dev/vg_ifx14/rspare23										-- from available space file 
/usr/sbin/lvdisplay -v /dev/vg_ifx14/spare23 | grep "LV Size"				---remove r

ln -s /dev/vg_ifx14/rspare23 /app/links/dcwposr/sum_week_20190909_chk01		--check existing file name and new name 

onspaces -a sum_week_20190909 -p /app/links/dcwposr/sum_week_20190909_chk01 -o 0 -s 2048000		----actual command check file size 


dbsavail |egrep 'sum_week_20190909|Free'


west :

/usr/sbin/fuser /dev/vg_ifx14/rspare23
/usr/sbin/lvdisplay -v /dev/vg_ifx14/spare23 | grep "LV Size"

ln -s /dev/vg_ifx14/rspare23 /app/links/dcwposr/sum_week_20190909_chk01

onspaces -a sum_week_20190909 -p /app/links/dcwposr/sum_week_20190909_chk01 -o 0 -s 2048000


dbsavail |egrep 'sum_week_20190909|Free'