Control M/SI 	PG1697 SR1286671				WO143524	
Map DEV			PG1702 SR1286689				WO143529
Map QA			PG1702 SR1286693				WO143533
Map UAT			PG1702 SR1286694				WO143535
SA QA			PG1657 SR1286705				WO143539
SA UAT			PG1657 SR1286705				WO143539



OMI 			: PG1676
map 			: PG1702
file			: PG1697

Product :

OMI 			: 1459
TRANSIT			: pr1030
map 			: PR1456
si				: pr1471
Control 		: pr1449


11g oracle patch 
--rsp file creation 
$ORACLE_HOME/OPatch/opatch version


$ORACLE_HOME/OPatch/ocm/bin/emocmrsp  -no_banner -output $ORACLE_HOME/dbs/ocm.rsp

chmod -R 775 $ORACLE_HOME/dbs/ocm.rsp

ls -altr $ORACLE_HOME/dbs/ocm.rsp
echo $ORACLE_HOME 

$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /u03/Patch/JULY2017_PATCH/26031209/26027154

$ORACLE_HOME/OPatch/opatch version

--database patch 

$ORACLE_HOME/OPatch/./opatch auto /recovery/oracle/software/patch/31305209 -oh $ORACLE_HOME -ocmrf $ORACLE_HOME/dbs/ocm.rsp

/opt/app/software/patch_apr19
--grid patch 

$ORACLE_HOME/OPatch/./opatch auto /opt/app/software/patch/31305209 -oh $ORACLE_HOME  -ocmrf $ORACLE_HOME/dbs/ocm.rsp


cd  /recovery/oracle/software/patch/31302572

$ORACLE_HOME/OPatch/./opatch apply


--rollback patch 

 opatch auto  -rollback -ocmrf $ORACLE_HOME/dbs/ocm.rsp
 
 
 
--jAVA PATCH 

$ORACLE_HOME/OPatch/./opatch apply -silent -ocmrf $ORACLE_HOME/dbs/ocm.rsp




$ORACLE_HOME/OPatch/./opatch prereq CheckConflictAgainstOHWithdetail -phbaseDIR /u03/Patch/JULY2017_PATCH/26031209/26027154




ssh devdbnode1 /opt/app/11.2.0/grid4/OPatch/./opatch lsinventory | grep applied
ssh devdbnode1 /opt/app/oracle/product/11.2.0/db_4/OPatch/./opatch lsinventory | grep applied

ssh devdbnode2 /opt/app/11.2.0/grid4/OPatch/./opatch lsinventory | grep applied
ssh devdbnode2 /opt/app/oracle/product/11.2.0/db_4/OPatch/./opatch lsinventory | grep applied

ssh wql1trandbs03 /opt/app/11.2.0/grid4/OPatch/./opatch lsinventory | grep applied
ssh wql1trandbs03 /opt/app/oracle/product/11.2.0/db_4/OPatch/./opatch lsinventory | grep applied







--scp -- Q3



--11g HP 
PSU : 	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31103343_112040_HPUX-IA64.zip .
OPa :	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p6880880_112000_HPUX-IA64.zip .

--11g 
PSU :	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31103343_112040_Linux-x86-64.zip .
OPa : 	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p6880880_112000_Linux-x86-64.zip .
GIP :	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31305209_112040_Linux-x86-64.zip .
JDK : 	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31302572_112040_Linux-x86-64.zip .

--12cR1
PSU : 	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31113348_121020_Linux-x86-64.zip .
JDK : 	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31302525_121020_Linux-x86-64.zip .
OPa :	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p6880880_122010_Linux-x86-64.zip .
--12cR2

PSU : 	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31312468_122010_Linux-x86-64.zip .
JDK :	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31302499_122010_Linux-x86-64.zip .
OPa :	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p6880880_122010_Linux-x86-64.zip .

--18c : 

PSU : 	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p31308624_180000_Linux-x86-64.zip .
OPa : 	scp -rv vishalbhandwalkar@wdl2tsysdbs03.tsysacquiring.org:/opt/app/software/patch/Q3_2020/p6880880_180000_Linux-x86-64.zip .





 


 


 



























opatchauto apply 


mkdir /tmp/patch_stat
cd   /tmp/patch_stat
ps -eaf | grep pmon | tee /tmp/patch_stat/Q3_pmon_`date +"%m-%d-%Y-%T"`_`hostname`.log
ps -eaf | grep pmon | tee /tmp/patch_stat/Q3_tns_`date +"%m-%d-%Y-%T"`_`hostname`.log
df -Ph  | /tmp/patch_stat/tee Q3_df_`date`_`hostname`.log
/opt/app/11.2.0/grid4/bin/./crsctl stat res -t | tee /tmp/patch_stat/Q3_crs_`date +"%m-%d-%Y-%T"`_`hostname`.log
/opt/app/11.2.0/grid4/bin/./crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
 awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}' | tee /tmp/patch_stat/Q3_crsstat_`date +"%m-%d-%Y-%T"`_`hostname`.log

 ls -altr 



ps -eaf | grep pmon | tee /acfs/patch_stat/os_pmon_`date +"%m-%d-%Y"`_`hostname`.log
ps -eaf | grep pmon | tee /acfs/patch_stat/os_tns_`date +"%m-%d-%Y"`_`hostname`.log
df -Ph  | /acfs/patch_stat/tee os_df_`date`_`hostname`.log
/opt/app/11.2.0/grid_1/bin/./crsctl stat res -t | tee /acfs/patch_stat/os_crs_`date +"%m-%d-%Y"`_`hostname`.log
/opt/app/11.2.0/grid_1/bin/./crsctl status res |grep -v "^$"|awk -F "=" 'BEGIN {print " "} {printf("%s",NR%4 ? $2"|" : $2"\n")}'|sed -e 's/ *, /,/g' -e 's/, /,/g'|\
 awk -F "|" 'BEGIN { printf "%-40s%-35s%-20s%-50s\n","Resource Name","Resource Type","Target ","State" }{ split ($3,trg,",") split ($4,st,",")}{for (i in trg) {printf "%-40s%-35s%-20s%-50s\n",$1,$2,trg[i],st[i]}}' | tee /acfs/patch_stat/os_crsstat_`date +"%m-%d-%Y"`_`hostname`.log



