SELECT *
  FROM (SELECT *
          FROM transnox_iox.trans_card tc,
               transnox_iox.card_number_master cnm
         WHERE     to_char(TC.CARD_NUMBER) =CNM.CARD_SEQNO(+)
               AND TC.TIMESTAMP >= sysdate-7/24 ) a
WHERE a.card_seqno IS NULL;


--create table 

create table stujare.cnm_20may_vb as
SELECT *
  FROM (SELECT *
          FROM transnox_iox.trans_card tc,
               transnox_iox.card_number_master cnm
         WHERE     to_char(TC.CARD_NUMBER) =CNM.CARD_SEQNO(+)
               AND TC.TIMESTAMP >= sysdate-7/24 ) a
WHERE a.card_seqno IS NULL;



-- wthout null 


create table dbhosale.cnm_mismatch_04112019 nologging as
select transaction_id, card_number,cnm.card_seqno, cnm.card_encrypt,cnm.card_mask
from transnox_iox.trans_card tc left join transnox_iox.card_number_master cnm on (to_char(tc.card_number)=cnm.card_seqno)
where cnm.card_seqno is null and tc.timestamp >= sysdate-5; 




create table dbhosale.cnm_mismatch_04112019_1_vb nologging as
select transaction_id, card_number,cnm.card_seqno, cnm.card_encrypt,cnm.card_mask
from transnox_iox.trans_card tc , transnox_iox.card_number_master cnm where  to_char(tc.card_number)=cnm.card_seqno(+)
and  cnm.card_seqno is null and tc.timestamp >= sysdate-1; 



--sync 
---------------------------------------------------------------
SELECT cnm.*
          FROM transnox_iox.trans_card@twgg tc,
               transnox_iox.card_number_master@twgg cnm
         WHERE     to_char(TC.CARD_NUMBER) =CNM.CARD_SEQNO(+)
               AND TC.TIMESTAMP >= sysdate-1/24

minus
SELECT cnm.*
          FROM transnox_iox.trans_card tc,
               transnox_iox.card_number_master cnm
         WHERE     to_char(TC.CARD_NUMBER) =CNM.CARD_SEQNO(+)
               AND TC.TIMESTAMP >= sysdate-1/24

---------------------------------------------------------------

SELECT tc.*
          FROM transnox_iox.trans_card@twgg tc,
               transnox_iox.card_number_master@twgg cnm
         WHERE     to_char(TC.CARD_NUMBER) =CNM.CARD_SEQNO(+)
               AND TC.TIMESTAMP >= sysdate-1/24
minus
SELECT tc.*
          FROM transnox_iox.trans_card tc,
               transnox_iox.card_number_master cnm
         WHERE     to_char(TC.CARD_NUMBER) =CNM.CARD_SEQNO(+)
               AND TC.TIMESTAMP >= sysdate-1/24

---------------------------------------------------------------


select count(1) from stujare.cnm_02242020_vb;