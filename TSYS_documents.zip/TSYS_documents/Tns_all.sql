DEVRACDB=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=devracdb.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=devracdb)
    )
  )
OEMREP_wpl2mltidbs01 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = wpl2mltidbs01.tsysacquiring.org)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = oemrep.tsysacquiring.org)
    )
  )

  
rcat_wpl2tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = wpl2tsysdbs01.vitalps.com)(PORT = 1529)
       )
    )
    (CONNECT_DATA =
      (SERVER=DEDICATED)
      (SID = rcat )
    )
  )

omimom_w_wml2tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = wml2tsysdbs01.tas.corp)(PORT = 1521)
       )
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = omimom_w)
    )
  )

rcat_wml2tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = wml2tsysdbs01.tas.corp)(PORT = 1529)
       )
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SID = rcat )
    )
  )


  
VDATAW =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = wpl1trandbs01.tsysacquiring.org)(PORT = 1521))
    (ADDRESS = (PROTOCOL = TCP)(HOST = wpl1trandbs01.tsysacquiring.org)(PORT = 1526))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = vdataw)
    )
  )
CCARCHW_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = wpl1tsysdbs01.vitalps.com)(PORT = 1533))
    )
    (CONNECT_DATA =
      (SID = ccarchw)
    )
  )


CCARCHE_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = epl1tsysdbs01.vitalps.com)(PORT = 1533))
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = ccarche)
      (UR = A)
    )
  )

CTLMSBE1_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = epl1tsysdbs01.vitalps.com)(PORT = 1522))
    )
    (CONNECT_DATA =
      (SID = ctlmsbe1)
      (SERVER = DEDICATED)
    )
  )

CONTROLM_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = wpl1tsysdbs01.vitalps.com)(PORT = 1522))
    )
    (CONNECT_DATA =
      (SID = controlm)
      (SERVER = DEDICATED)
    )
  )

RCAT_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = wpl1tsysdbs01.vitalps.com)(PORT = 1529))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = rcat)
    )
  )

CCHISTW_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = wpl1tsysdbs01.vitalps.com)(PORT = 1534))
    )
    (CONNECT_DATA =
      (SID = cchistw)
    )
  )

CCPRODW_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = wpl1tsysdbs01.vitalps.com)(PORT = 1532))
    )
    (CONNECT_DATA =
      (SID = ccprodw)
      (SERVER = DEDICATED)
    )
  )


  
REGRACDB=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=regracdb.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=regracdb2)
      (SERVICE_NAME=regracdb)
    )
  )

  
MAPDB_epl1mapxdbs01 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = epl1mapxdbs01.tsysacquiring.org)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = mapdb)
    )
  )

  
  
rcat_epl1mapxdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = epl1mapxdbs01.tsysacquiring.org)(PORT = 1521)
       )
    )
    (CONNECT_DATA =
      (SERVER=DEDICATED)
      (SID = rcat )
    )
  )

  
QARACDB=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=qaracdb.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=qaracdbtaf)
    )
  )

UATRACDBTAF=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=uatracdb.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=uatracdbtaf)
    )
  )

# DCW Primary database

TW_CPASS_RAC=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=w-transitdb-txn.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=transittxn)
    )
  )

#DCE Primary database

TE_CPASS_RAC=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=e-transitdb-txn.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=transittxn)
    )
  )

# DCW Reporting database

RW_CPASS_RAC=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=w-transitdb-rpt.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=transitrpt)
    )
  )

# DCE Reporting database

RE_CPASS_RAC=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=e-transitdb-rpt.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=transitrpt)
    )
  )

DEVDB_NODE2=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.100.226.232)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=devracdb2)
      (SERVICE_NAME=devracdb)
    )
  )

QADB_NODE1=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.100.224.172)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=qaracdb1)
      (SERVICE_NAME=qaracdb)
    )
  )

REGDB_Node2=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=regdbnode2.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=regracdb2)
      (SERVICE_NAME=regracdb)
    )
  )

NEW_TXNDCW_PF=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.100.226.87)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=txnDCW1)
      (SERVICE_NAME=txnDCW)
    )
  )

NEW_RPTDCW_PF=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.100.226.87)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=rptDCW1)
      (SERVICE_NAME=rptDCW)
    )
  )

NEW_TXNDCE_PF=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.100.224.174)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=txnDCE1)
      (SERVICE_NAME=txnDCE)
    )
  )

NEW_RPTDCE_PF=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.100.224.174)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=rptDCE1)
      (SERVICE_NAME=rptDCE)
    )
  )

DCW_TXNUATDB_51=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=192.168.64.51)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=uattxndb1)
      (SERVICE_NAME=uattransittxn)
    )
  )

DCW_RPTUATDB_51=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=192.168.64.51)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=uatrptdb1)
      (SERVICE_NAME=uatrptdb)
    )
  )

DCE_TXNUATDB_61=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=192.168.64.61)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=utxndb1)
      (SERVICE_NAME=utxndb)
    )
  )

DCE_RPTUATDB_61=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=192.168.64.61)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=urptdb1)
      (SERVICE_NAME=urptdb)
    )
  )

NEW_TXNDCW_PF2=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.100.226.85)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=txnDCW2)
      (SERVICE_NAME=txnDCW)
    )
  )

TE_N1=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.50.50.167)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=transitt1)
      (SERVICE_NAME=transittxn)
    )
  )

TW_N1=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.50.50.167)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=transitt1)
      (SERVICE_NAME=transittxn)
    )
  )

RW_N1=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.50.50.167)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=transitr1)
      (SERVICE_NAME=transitrpt)
    )
  )

TE_N2=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.50.50.168)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=transitt2)
      (SERVICE_NAME=transittxn)
    )
  )

TE_N2=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.50.50.168)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (INSTANCE_NAME=transitt2)
      (SERVICE_NAME=transittxn)
    )
  )

DEVTXNDB=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=devtransitdb-scan.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=devtxndbtaf.tsysacquiring.org)
    )
  )

REGTXNDB=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=regtransitdb-scan.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=regtxndbtaf.tsysacquiring.org)
    )
  )

  
  
    
SIPROD =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = dcwgisdb )(PORT = 1542)
       )
    )
    (CONNECT_DATA =
      (SERVER=DEDICATED)
      (SID = siprod )
    )
  )

rcat_dcwgisdb =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = dcwgisdb )(PORT = 1542)
       )
    )
    (CONNECT_DATA =
      (SERVER=DEDICATED)
      (SID = rcat )
    )
  )
  

omism_e_eml2tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = eml2tsysdbs01.tas.corp)(PORT = 1525)
       )
    )
    (CONNECT_DATA =
      (SERVER=DEDICATED)
      (SERVICE_NAME = omism_e)
    )
  )


sipeast_dcwgisdb =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = db.eph1tsysdbs01.vitalps.com )(PORT = 1530)
       )
    )
    (CONNECT_DATA =
      (SERVER=DEDICATED)
      (SID = sipeast )
    )
  )

  
  
 
CCPRODE_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = epl1tsysdbs01.vitalps.com)(PORT = 1532))
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SID = ccprode)
    )
  )

cchiste_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = epl1tsysdbs01.vitalps.com)(PORT = 1534)
       )
    )
    (CONNECT_ ATA =
      (SERVER = DEDICATED)
      (SID = cchiste )
    )
  )


CCARCHE_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = epl1tsysdbs01.vitalps.com)(PORT = 1533))
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SID = ccarche)
    )
  )

  
sauthp_e_epl2tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = epl2tsysdbs01.vitalps.com)(PORT = 1521)
       )
    )
    (CONNECT_DATA =
      (SERVER=DEDICATED)
      (SID = sauthp_e )
    )
  )


rcat_epl2tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS =
        (PROTOCOL = TCP)(HOST = epl2tsysdbs01.vitalps.com)(PORT = 1529)
       )
    )
    (CONNECT_DATA =
      (SERVER=DEDICATED)
      (SID = rcat )
    )
  )

  
RCAT_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = epl1tsysdbs01.vitalps.com)(PORT = 1529))
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SID = rcat)
    )
  )

CTLMPTCH_wpl1tsysdbs01 =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = epl1tsysdbs01.vitalps.com)(PORT = 1525))
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SID = ctlmptch)
    )
  )


 
  
  
  
OEMREP13 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = wml1tsysdbs01.vitalps.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = oemrep13.vitalps.com)
    )
  )

 
  
OEMREP =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = wdl2tsysdbs03.tsysacquiring.org)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = oemrep.tsysacquiring.org)
    )
  )

  
w_controlm=   
    (DESCRIPTION=
      (ADDRESS=
        (PROTOCOL=TCP)
        (HOST=wpl1tsysdbs01.vitalps.com)
        (PORT=1522)
      )
      (CONNECT_DATA=
        (SERVER=dedicated)
        (SID=controlm)
      )
    )
  )
  
12C_NEW_REGTXNDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = regtransitdb-scan.tsysacquiring.org)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = regtxndb.tsysacquiring.org)
    )
  )

12C_NEW_REGSRVPDB1=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=regtransitdb-scan.tsysacquiring.org)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=SRVPDB1.tsysacquiring.org)
    )
  )

  
  
  
  
    
12C_NEW_DEVTXNDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = devtransitdb-scan.tsysacquiring.org)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = devtxndb.tsysacquiring.org)
    )
  )


12C_NEW_DEVSRVPDB1=
		(DESCRIPTION=
			(ADDRESS=
			(PROTOCOL=TCP)
			(HOST=devtransitdb-scan.tsysacquiring.org)
			(PORT=1521)
			)
			(CONNECT_DATA=
			(SERVICE_NAME=SRVPDB1.tsysacquiring.org)
			)
		)
		
		
		
		
		
		
		
12C_NEW_QATXNDB =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = qatransitdb-scan.tsysacquiring.org)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = qatxndb.tsysacquiring.org)
    )
  )

12C_NEW_QA_SRV_PDB1 =
  (DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = qatransitdb-scan.tsysacquiring.org)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = qatxndbpdb1.tsysacquiring.org)
    )
  )

  
  
  
  
  VDATAW
CCARCHW_wpl1tsysdbs01  
CCARCHE_wpl1tsysdbs01  
CTLMSBE1_wpl1tsysdbs01  
CONTROLM_wpl1tsysdbs01  
RCAT_wpl1tsysdbs01  
CCHISTW_wpl1tsysdbs01  
CCPRODW_wpl1tsysdbs01
OEMREP_wpl2mltidbs01
rcat_wpl2tsysdbs01
omimom_w_wml2tsysdbs01
rcat_wml2tsysdbs01
rcat_epl1mapxdbs01
MAPDB_epl1mapxdbs01
SIPROD
omism_e_eml2tsysdbs01
rcat_dcwgisdb
sipeast_dcwgisdb
TW_CPASS_RAC
TE_CPASS_RAC
RW_CPASS_RAC
RE_CPASS_RAC
CCPRODE_wpl1tsysdbs01 
cchiste_wpl1tsysdbs01 
CCARCHE_wpl1tsysdbs01 
RCAT_wpl1tsysdbs01 
CTLMPTCH_wpl1tsysdbs01 
sauthp_e_epl2tsysdbs01
rcat_epl2tsysdbs01
CCARCHE_epl1tsysdbs01



  cat $ORACLE_HOME/network/admin/tnsnames.ora
