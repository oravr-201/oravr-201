CREATE OR REPLACE PROCEDURE TRANSITHA.sendmail_oracle (fromm    VARCHAR2,
                                      too      VARCHAR2,
                                      sub      VARCHAR2,
                                      BODY     VARCHAR2,
                                      port     NUMBER)
IS
   objConnection   UTL_SMTP.CONNECTION;
   vrData          VARCHAR2 (32000);
BEGIN
   objConnection := UTL_SMTP.OPEN_CONNECTION ('smtp.tsysacquiring.org', port);
   UTL_SMTP.HELO (objConnection, 'smtp.tsysacquiring.org');
   UTL_SMTP.MAIL (objConnection, fromm);
   UTL_SMTP.RCPT (objConnection, too);
   UTL_SMTP.OPEN_DATA (objConnection);
   /* ** Sending the header information */
   UTL_SMTP.WRITE_DATA (objConnection, 'From: ' || fromm || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, 'To: ' || too || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, 'Subject: ' || sub || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection,
                        'MIME-Version: ' || '1.0' || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, 'Content-Type: ' || 'text/html;');
   UTL_SMTP.WRITE_DATA (
      objConnection,
      'Content-Transfer-Encoding: ' || '"8Bit"' || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.WRITE_DATA (
      objConnection,
         UTL_TCP.CRLF
      || '<span style="color: red; font-family: Courier New;">'
      || BODY
      || '</span>');
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.CLOSE_DATA (objConnection);
   UTL_SMTP.QUIT (objConnection);
EXCEPTION
   WHEN UTL_SMTP.TRANSIENT_ERROR OR UTL_SMTP.PERMANENT_ERROR
   THEN
      UTL_SMTP.QUIT (objConnection);
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
   WHEN OTHERS
   THEN
      UTL_SMTP.QUIT (objConnection);
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
END sendmail_oracle;  /* GOLDENGATE_DDL_REPLICATION */
/
