CREATE OR REPLACE PROCEDURE TRANSITHA.html_request_load_report
AS
    l_boundary      VARCHAR2(255) DEFAULT 'a1b2c3d4e3f2g1';
    l_connection    UTL_SMTP.CONNECTION;
    l_body_html     CLOB := EMPTY_CLOB;  --This LOB will be the email message
    l_offset        NUMBER;
    l_ammount       NUMBER;
    l_temp          VARCHAR2(32767) DEFAULT NULL;
    XML CLOB;
  BODY CLOB;
  varsql      VARCHAR2(32000);
  fieldlist VARCHAR2(4000);
  tblfieldheader NVARCHAR2(2000) := '';
  tempfield NVARCHAR2(2000)      := '';
  i          INT                          := 1;
  j          INT                          := 1;
  SendEmail  INT;
  splitcnt   INT;
  fieldcount INT ;
  
  p_subject VARCHAR2(4000) := 'TransIT Load Monitoring Report';
  p_to1 VARCHAR2(4000) := 'ACQ-TransITLeads@tsys.com';
  p_to2 VARCHAR2(4000) := 'ACQ-TransITDB@tsys.com';
  p_to3 VARCHAR2(4000) := 'ACQ-Appl-ProductionSupport@tsys.com';
  p_to4 VARCHAR2(4000) := 'acq-commandcenter@tsys.com';
  p_to5 VARCHAR2(4000) := 'Ifx-dbalerts@tsys.com';
  p_to6 VARCHAR2(4000) := 'TransITAlerts@tsys.com';
--  p_to varchar2(4000) := 'dbhosale@tsys.com;HarshavardhanBandi@tsys.com;stujare@tsys.com';
--   p_to  varchar2(4000):=  'ACQ-TransITLeads@tsys.com;ACQ-TransITDB@tsys.com;Ifx-dbalerts@tsys.com;ACQ-Appl-ProductionSupport@tsys.com';
--  p_from varchar2(4000):= 'stujare@tsys.com';
   p_from VARCHAR2(4000):= 'Ifx-dbalerts@tsys.com';
   p_smtp_hostname VARCHAR2(100):= 'smtpeast.tas.corp';
   p_smtp_portnum VARCHAR2(100):= '25';
   p_text VARCHAR2(100):= 'TransIT Load Monitoring Report for last 3 Hours';
   
TYPE AllFieldNames
IS
  TABLE OF VARCHAR2(2000);
  TempFields AllFieldNames;
BEGIN
    l_connection := UTL_SMTP.OPEN_CONNECTION( p_smtp_hostname, p_smtp_portnum );
    UTL_SMTP.HELO( l_connection, p_smtp_hostname );
    UTL_SMTP.MAIL( l_connection, p_from );
    UTL_SMTP.RCPT( l_connection, p_to1 );
    UTL_SMTP.RCPT (l_connection, p_to2);
    UTL_SMTP.RCPT (l_connection, p_to3);
    UTL_SMTP.RCPT (l_connection, p_to4);
    UTL_SMTP.RCPT (l_connection, p_to5);
    UTL_SMTP.RCPT (l_connection, p_to6);

    l_temp := l_temp || 'MIME-Version: 1.0' ||  CHR(13) || CHR(10);
    l_temp := l_temp || 'To: ' || p_to1||';'|| p_to2 ||';'|| p_to3 ||';'|| p_to4 ||';'|| p_to5 ||';'||p_to6 ||';'||CHR(13) || CHR(10);
    l_temp := l_temp || 'From: ' || p_from || CHR(13) || CHR(10);
    l_temp := l_temp || 'Subject: ' || p_subject || CHR(13) || CHR(10);
    l_temp := l_temp || 'Reply-To: ' || p_from ||  CHR(13) || CHR(10);
    l_temp := l_temp || 'Content-Type: multipart/alternative; boundary=' || 
                         CHR(34) || l_boundary ||  CHR(34) || CHR(13) || 
                         CHR(10);

    ----------------------------------------------------
    -- Write the headers
    DBMS_LOB.CREATETEMPORARY( l_body_html, FALSE, 10 );
    DBMS_LOB.WRITE(l_body_html,LENGTH(l_temp),1,l_temp);
---******************************************
fieldlist := 'TRANSACTING_HOUR|WPL1TRANAPP03_6062|WPL1TRANAPP04_6062|WPL1TRANAPP01_6012|WPL1TRANAPP02_6012|WPL1TRANAPP03_6012|WPL1TRANAPP04_6012|EPL1TRANAPP03_6062|EPL1TRANAPP04_6062|EPL1TRANAPP01_6012|EPL1TRANAPP02_6012|EPL1TRANAPP03_6012|EPL1TRANAPP04_6012';
  --Find the number of fields in the query
  splitcnt := LENGTH(fieldlist)-LENGTH(REPLACE(fieldlist,'|',''));
  --Loop through the fields and put each on into the #Fields temp table as a new record
  FOR j IN 1..splitcnt
  LOOP
    SELECT x.s BULK COLLECT
    INTO TempFields
    FROM
      (SELECT REGEXP_SUBSTR (fieldlist, '[^|]+', 1, ROWNUM) s,
        ROWNUM rn
      FROM dual
        CONNECT BY LEVEL <= LENGTH (REGEXP_REPLACE (fieldlist, '[^|]+')) + 1
      ) x;
  END LOOP;
  --SELECT fieldcount = splitcnt + 1 --Will be the splitcnt + 1, otherwise MAX(ID) FROM TempFields
  --Start setting up the sql statement for the query.
  varsql := 'SELECT' || ' xmlagg(xmlelement("tr",xmlforest(';
  --Loop through the #Fields table to get the field list
  FOR I IN TempFields.first..TempFields.last
  LOOP
    --------------------------------------------------------------------------------------------------------------------------------------------------------------
    --This next section is required in case a field is aliased.  For the xml, we need to get rid of the aliases, the table header will only require the aliases.
    --NULL values need to be shown as a string = 'NULL' or the html table will just skip the cell and all values after that in the row will be shifted left.
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------
    IF SUBSTR(TempFields(I),-1) = ']' OR INSTR(UPPER(TempFields(I)),' AS ') = 0 THEN
      --Set the xml field to be the entire field name
      varsql := varsql || 'NVL(CAST(' || TempFields(I) || ' AS VARCHAR2(2000)),''NULL'') as "td", ';
      --Set the table header field to be the entire field name
      tblfieldheader := tblfieldheader || '<th>' || TempFields(I) || '</th>';
    ELSE
      --Set the xml field to be the field name minus the alias
      varsql := varsql || 'NVL(CAST(' || SUBSTR(TempFields(I),1,(INSTR(UPPER(TempFields(I)),' AS ',1))-1) || ' AS VARCHAR2(2000)),''NULL'') as "td", ';
      --Set the table header field to be the field name's alias
      tblfieldheader := tblfieldheader || '<th>' || SUBSTR(TempFields(I),INSTR(UPPER(TempFields(I)),' AS ',-1)+4) || '</th>';
    END IF;
    --Increment the counter.
  END LOOP;
  --Trim the extra two characters of the end of sql.
  varsql := SUBSTR(varsql,1, LENGTH(varsql)-2);
  --Add the end of the table tag
  varsql := varsql || '))).GetClobVal() ';
  --Add the from, where, group by, having, and order by clause to the select statement.
  varsql := varsql || 'from ( 
select to_char(min(transacting_hour),''MM/DD/YYYY HH24:MI:SS'') transacting_hour,
nvl(max(decode(server_ip,''wpl1tranapp03.tsysacquiring.org:6062'',request_count)),0) wpl1tranapp03_6062,
nvl(max(decode(server_ip,''wpl1tranapp04.tsysacquiring.org:6062'',request_count)),0) wpl1tranapp04_6062,
nvl(max(decode(server_ip,''wpl1tranapp01.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp01_6012,
nvl(max(decode(server_ip,''wpl1tranapp02.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp02_6012,
nvl(max(decode(server_ip,''wpl1tranapp03.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp03_6012,
nvl(max(decode(server_ip,''wpl1tranapp04.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp04_6012,
nvl(max(decode(server_ip,''epl1tranapp03.tsysacquiring.org:6062'',request_count)),0) epl1tranapp03_6062,
nvl(max(decode(server_ip,''epl1tranapp04.tsysacquiring.org:6062'',request_count)),0) epl1tranapp04_6062,
nvl(max(decode(server_ip,''epl1tranapp01.tsysacquiring.org:6012'',request_count)),0) epl1tranapp01_6012,
nvl(max(decode(server_ip,''epl1tranapp02.tsysacquiring.org:6012'',request_count)),0) epl1tranapp02_6012,
nvl(max(decode(server_ip,''epl1tranapp03.tsysacquiring.org:6012'',request_count)),0) epl1tranapp03_6012,
nvl(max(decode(server_ip,''epl1tranapp04.tsysacquiring.org:6012'',request_count)),0) epl1tranapp04_6012
from
(
select min(transacting_date) transacting_hour, server_ip,sum(xtn_count) request_count
from
(
select  to_date(to_char(SERVER_TIMESTAMP,''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') transacting_date,server_ip ,count(1) xtn_count
from TRANSNOX_IOX.REQUEST_AUDIT_TRAIL RAT
where RAT.SERVER_TIMESTAMP between to_date(to_char(SYSDATE-(1/24),''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') and to_date(to_char(SYSDATE,''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'')-1/86400 and server_ip is not null
group by to_date(to_char(SERVER_TIMESTAMP,''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') ,server_ip
)
group by server_ip 
)
union all
select to_char(min(transacting_hour),''MM/DD/YYYY HH24:MI:SS'') transacting_hour,
nvl(max(decode(server_ip,''wpl1tranapp03.tsysacquiring.org:6062'',request_count)),0) wpl1tranapp03_6062,
nvl(max(decode(server_ip,''wpl1tranapp04.tsysacquiring.org:6062'',request_count)),0) wpl1tranapp04_6062,
nvl(max(decode(server_ip,''wpl1tranapp01.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp01_6012,
nvl(max(decode(server_ip,''wpl1tranapp02.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp02_6012,
nvl(max(decode(server_ip,''wpl1tranapp03.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp03_6012,
nvl(max(decode(server_ip,''wpl1tranapp04.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp04_6012,
nvl(max(decode(server_ip,''epl1tranapp03.tsysacquiring.org:6062'',request_count)),0) epl1tranapp03_6062,
nvl(max(decode(server_ip,''epl1tranapp04.tsysacquiring.org:6062'',request_count)),0) epl1tranapp04_6062,
nvl(max(decode(server_ip,''epl1tranapp01.tsysacquiring.org:6012'',request_count)),0) epl1tranapp01_6012,
nvl(max(decode(server_ip,''epl1tranapp02.tsysacquiring.org:6012'',request_count)),0) epl1tranapp02_6012,
nvl(max(decode(server_ip,''epl1tranapp03.tsysacquiring.org:6012'',request_count)),0) epl1tranapp03_6012,
nvl(max(decode(server_ip,''epl1tranapp04.tsysacquiring.org:6012'',request_count)),0) epl1tranapp04_6012
from
(
select min(transacting_date) transacting_hour, server_ip,sum(xtn_count) request_count
from
(
select  to_date(to_char(SERVER_TIMESTAMP,''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') transacting_date,server_ip ,count(1) xtn_count
from TRANSNOX_IOX.REQUEST_AUDIT_TRAIL RAT
where RAT.SERVER_TIMESTAMP between to_date(to_char(SYSDATE-(2/24),''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') and to_date(to_char(SYSDATE-(1/24),''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'')-1/86400 and server_ip is not null
group by to_date(to_char(SERVER_TIMESTAMP,''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') ,server_ip
)
group by server_ip 
)
union all
select to_char(min(transacting_hour),''MM/DD/YYYY HH24:MI:SS'') transacting_hour,
nvl(max(decode(server_ip,''wpl1tranapp03.tsysacquiring.org:6062'',request_count)),0) wpl1tranapp03_6062,
nvl(max(decode(server_ip,''wpl1tranapp04.tsysacquiring.org:6062'',request_count)),0) wpl1tranapp04_6062,
nvl(max(decode(server_ip,''wpl1tranapp01.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp01_6012,
nvl(max(decode(server_ip,''wpl1tranapp02.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp02_6012,
nvl(max(decode(server_ip,''wpl1tranapp03.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp03_6012,
nvl(max(decode(server_ip,''wpl1tranapp04.tsysacquiring.org:6012'',request_count)),0) wpl1tranapp04_6012,
nvl(max(decode(server_ip,''epl1tranapp03.tsysacquiring.org:6062'',request_count)),0) epl1tranapp03_6062,
nvl(max(decode(server_ip,''epl1tranapp04.tsysacquiring.org:6062'',request_count)),0) epl1tranapp04_6062,
nvl(max(decode(server_ip,''epl1tranapp01.tsysacquiring.org:6012'',request_count)),0) epl1tranapp01_6012,
nvl(max(decode(server_ip,''epl1tranapp02.tsysacquiring.org:6012'',request_count)),0) epl1tranapp02_6012,
nvl(max(decode(server_ip,''epl1tranapp03.tsysacquiring.org:6012'',request_count)),0) epl1tranapp03_6012,
nvl(max(decode(server_ip,''epl1tranapp04.tsysacquiring.org:6012'',request_count)),0) epl1tranapp04_6012
from
(
select min(transacting_date) transacting_hour, server_ip,sum(xtn_count) request_count
from
(
select  to_date(to_char(SERVER_TIMESTAMP,''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') transacting_date,server_ip ,count(1) xtn_count
from TRANSNOX_IOX.REQUEST_AUDIT_TRAIL RAT
where RAT.SERVER_TIMESTAMP between to_date(to_char(SYSDATE-(3/24),''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') and to_date(to_char(SYSDATE-(2/24),''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'')-1/86400 and server_ip is not null
group by to_date(to_char(SERVER_TIMESTAMP,''MM/DD/YYYY HH24:MI''),''MM/DD/YYYY HH24:MI'') ,server_ip
)
group by server_ip 
)
)';

  --Run the sql that will create the xml.
  EXECUTE IMMEDIATE varsql INTO XML;
  --Capture whether or not any rows were returned
  IF LENGTH(XML) > 0 THEN
    --Create the body of the email, which contains the xml results of the query.
--    body := to_clob('<html><body><H3>') || p_text || '</H3><table border = 1><tr>' || tblfieldheader || '</tr>' || XML || '</table></body></html>';
    BODY := TO_CLOB('<html><p> <font face="calibri" size="3" >Hi All,</font></p><H4><font face="calibri" size="3" > <i>TransIT Load Monitoring Report for last 3 Hours.</i></font> </H4><body><table border = 1><font face="calibri" size="2.5" ><tr>') || tblfieldheader || '</tr>' || XML || '</font></table></body><footer><p><B><font face="calibri" size="3" >Thanks and Regards,</B></font><br><font face="calibri" size="3" >DBA Team.</font><br><font face="calibri" size="2" color="red">**This is autogenerated email via DB process.</font></p></footer></html>';
    
    --If rows were returned, send the email.
--    sys.utl_mail.SEND( 'Oracledbmail@domain.com', recipients,NULL, NULL, subject , body, 'text/html', 3);
  END IF;
--******************************************

--    ----------------------------------------------------
--    -- Write the text boundary
--    l_offset := dbms_lob.getlength(l_body_html) + 1;
--    l_temp   := '--' || l_boundary || chr(13)||chr(10);
--    l_temp   := l_temp || 'content-type: text/plain; charset=us-ascii' || 
--                  chr(13) || chr(10) || chr(13) || chr(10);
--    dbms_lob.write(l_body_html,length(l_temp),l_offset,l_temp);
--
--    ----------------------------------------------------
--    -- Write the plain text portion of the email
--    l_offset := dbms_lob.getlength(l_body_html) + 1;
--    dbms_lob.write(l_body_html,length(p_text),l_offset,p_text);
--
    ----------------------------------------------------
    -- Write the HTML boundary
    l_temp   := CHR(13)||CHR(10)||CHR(13)||CHR(10)||'--' || l_boundary || 
                    CHR(13) || CHR(10);
    l_temp   := l_temp || 'content-type: text/html;' || 
                   CHR(13) || CHR(10) || CHR(13) || CHR(10);
    l_offset := DBMS_LOB.GETLENGTH(l_body_html) + 1;
    DBMS_LOB.WRITE(l_body_html,LENGTH(l_temp),l_offset,l_temp);

    ----------------------------------------------------
    -- Write the HTML portion of the message
    l_offset := DBMS_LOB.GETLENGTH(l_body_html) + 1;
    DBMS_LOB.WRITE(l_body_html,LENGTH(BODY),l_offset,BODY);

    ----------------------------------------------------
    -- Write the final html boundary
    l_temp   := CHR(13) || CHR(10) || '--' ||  l_boundary || '--' || CHR(13);
    l_offset := DBMS_LOB.GETLENGTH(l_body_html) + 1;
    DBMS_LOB.WRITE(l_body_html,LENGTH(l_temp),l_offset,l_temp);


    ----------------------------------------------------
    -- Send the email in 1900 byte chunks to UTL_SMTP
    l_offset  := 1;
    l_ammount := 1900;
    UTL_SMTP.OPEN_DATA(l_connection);
    WHILE l_offset < DBMS_LOB.GETLENGTH(l_body_html) LOOP
        UTL_SMTP.WRITE_DATA(l_connection,
                            DBMS_LOB.SUBSTR(l_body_html,l_ammount,l_offset));
        l_offset  := l_offset + l_ammount ;
        l_ammount := LEAST(1900,DBMS_LOB.GETLENGTH(l_body_html) - l_ammount);
    END LOOP;
    UTL_SMTP.CLOSE_DATA(l_connection);
    UTL_SMTP.QUIT( l_connection );
    DBMS_LOB.FREETEMPORARY(l_body_html);
END;
/
