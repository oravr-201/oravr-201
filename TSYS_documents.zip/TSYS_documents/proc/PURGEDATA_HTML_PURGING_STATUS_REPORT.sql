CREATE OR REPLACE PROCEDURE PURGEDATA.HTML_PURGING_STATUS_REPORT
AS
    l_boundary      VARCHAR2(255) DEFAULT 'a1b2c3d4e3f2g1';
    l_connection    UTL_SMTP.CONNECTION;
    l_body_html     CLOB := EMPTY_CLOB;  --This LOB will be the email message
    l_offset        NUMBER;
    l_ammount       NUMBER;
    l_temp          VARCHAR2(32767) DEFAULT NULL;
    XML CLOB;
  BODY CLOB;
  varsql      VARCHAR2(32000);
  fieldlist VARCHAR2(4000);
  tblfieldheader NVARCHAR2(2000) := '';
  tempfield NVARCHAR2(2000)      := '';
  i          INT                          := 1;
  j          INT                          := 1;
  SendEmail  INT;
  splitcnt   INT;
  fieldcount INT ;
  
  p_subject VARCHAR2(4000) := 'TransIT-TE- Daily Purging Status.';
  p_to1 VARCHAR2(4000) := 'acq-commandcenter@tsys.com';
  p_to2 VARCHAR2(4000) := 'acq-dba@tsys.com';
--  p_to3 varchar2(4000) := 'PVora@tsys.com';
  p_to4 VARCHAR2(4000) := 'PPadmanabhan@tsys.com';
  p_to5 VARCHAR2(4000) := 'RShiwalkar@tsys.com';
  p_to6 VARCHAR2(4000) := 'DJoshi@tsys.com';
  p_to7 VARCHAR2(4000) := 'TransIT-Appl-ProductionSupport@tsys.com';
  p_to8 VARCHAR2(4000) := 'TransITAlerts@tsys.com';
  
--  p_to1 varchar2(4000) := 'stujare@tsys.com';
--  p_to2 varchar2(4000) := 'stujare@tsys.com';
--  p_to3 varchar2(4000) := 'stujare@tsys.com';
--  p_to4 varchar2(4000) := 'stujare@tsys.com';
--  p_to5 varchar2(4000) := 'stujare@tsys.com';
--  p_to6 varchar2(4000) := 'stujare@tsys.com';
  
   p_from VARCHAR2(4000):= 'Ifx-dbalerts@tsys.com';
   p_smtp_hostname VARCHAR2(100):= 'smtpeast.tas.corp';
   p_smtp_portnum VARCHAR2(100):= '25';
   p_text VARCHAR2(100):= 'TransIT-TE- Daily Purging Status.';
   
TYPE AllFieldNames
IS
  TABLE OF VARCHAR2(2000);
  TempFields AllFieldNames;
BEGIN
    l_connection := UTL_SMTP.OPEN_CONNECTION( p_smtp_hostname, p_smtp_portnum );
    UTL_SMTP.HELO( l_connection, p_smtp_hostname );
    UTL_SMTP.MAIL( l_connection, p_from );
    UTL_SMTP.RCPT( l_connection, p_to1 );
    UTL_SMTP.RCPT (l_connection, p_to2);
--    UTL_SMTP.RCPT (l_connection, p_to3);
    UTL_SMTP.RCPT (l_connection, p_to4);
    UTL_SMTP.RCPT (l_connection, p_to5);
    UTL_SMTP.RCPT (l_connection, p_to6);
    UTL_SMTP.RCPT (l_connection, p_to7);
    UTL_SMTP.RCPT (l_connection, p_to8);

    l_temp := l_temp || 'MIME-Version: 1.0' ||  CHR(13) || CHR(10);
--    l_temp := l_temp || 'To: ' || p_to || chr(13) || chr(10);
--    l_temp := l_temp || 'To: ' || p_to1||';'|| p_to2 ||';'|| p_to3 ||';'|| p_to4 ||';'|| p_to5 ||';'|| p_to6 ||';'|| p_to7 ||';'|| p_to8 ||';'|| chr(13) || chr(10);
    l_temp := l_temp || 'To: ' || p_to1||';'|| p_to2 ||';'|| p_to4 ||';'|| p_to5 ||';'|| p_to6 ||';'|| p_to7 ||';'|| p_to8 ||';'|| CHR(13) || CHR(10);
    l_temp := l_temp || 'From: ' || p_from || CHR(13) || CHR(10);
    l_temp := l_temp || 'Subject: ' || p_subject || CHR(13) || CHR(10);
    l_temp := l_temp || 'Reply-To: ' || p_from ||  CHR(13) || CHR(10);
    l_temp := l_temp || 'Content-Type: multipart/alternative; boundary=' || 
                         CHR(34) || l_boundary ||  CHR(34) || CHR(13) || 
                         CHR(10);

    ----------------------------------------------------
    -- Write the headers
    DBMS_LOB.CREATETEMPORARY( l_body_html, FALSE, 10 );
    DBMS_LOB.WRITE(l_body_html,LENGTH(l_temp),1,l_temp);
---******************************************
fieldlist := 'SRNO|Purge_Table_Name|Purge_Record_Count|Purging_From_Date|Purging_To_Date|Purge_Status|Purging_Start_Date|Purging_End_Date|Puring_Time_in_Min';
  --Find the number of fields in the query
  splitcnt := LENGTH(fieldlist)-LENGTH(REPLACE(fieldlist,'|',''));
  --Loop through the fields and put each on into the #Fields temp table as a new record
  FOR j IN 1..splitcnt
  LOOP
    SELECT x.s BULK COLLECT
    INTO TempFields
    FROM
      (SELECT REGEXP_SUBSTR (fieldlist, '[^|]+', 1, ROWNUM) s,
        ROWNUM rn
      FROM dual
        CONNECT BY LEVEL <= LENGTH (REGEXP_REPLACE (fieldlist, '[^|]+')) + 1
      ) x;
  END LOOP;
  --SELECT fieldcount = splitcnt + 1 --Will be the splitcnt + 1, otherwise MAX(ID) FROM TempFields
  --Start setting up the sql statement for the query.
  varsql := 'SELECT' || ' xmlagg(xmlelement("tr",xmlforest(';
  --Loop through the #Fields table to get the field list
  FOR I IN TempFields.first..TempFields.last
  LOOP
    --------------------------------------------------------------------------------------------------------------------------------------------------------------
    --This next section is required in case a field is aliased.  For the xml, we need to get rid of the aliases, the table header will only require the aliases.
    --NULL values need to be shown as a string = 'NULL' or the html table will just skip the cell and all values after that in the row will be shifted left.
    ---------------------------------------------------------------------------------------------------------------------------------------------------------------
    IF SUBSTR(TempFields(I),-1) = ']' OR INSTR(UPPER(TempFields(I)),' AS ') = 0 THEN
      --Set the xml field to be the entire field name
      varsql := varsql || 'NVL(CAST(' || TempFields(I) || ' AS VARCHAR2(2000)),''NULL'') as "td", ';
      --Set the table header field to be the entire field name
      tblfieldheader := tblfieldheader || '<th>' || TempFields(I) || '</th>';
    ELSE
      --Set the xml field to be the field name minus the alias
      varsql := varsql || 'NVL(CAST(' || SUBSTR(TempFields(I),1,(INSTR(UPPER(TempFields(I)),' AS ',1))-1) || ' AS VARCHAR2(2000)),''NULL'') as "td", ';
      --Set the table header field to be the field name's alias
      tblfieldheader := tblfieldheader || '<th>' || SUBSTR(TempFields(I),INSTR(UPPER(TempFields(I)),' AS ',-1)+4) || '</th>';
    END IF;
    --Increment the counter.
  END LOOP;
  --Trim the extra two characters of the end of sql.
  varsql := SUBSTR(varsql,1, LENGTH(varsql)-2);
  --Add the end of the table tag
  varsql := varsql || '))).GetClobVal() ';
  --Add the from, where, group by, having, and order by clause to the select statement.
  varsql := varsql ||  ' FROM (SELECT ROW_NUMBER () OVER (ORDER BY Batch_start_Time DESC) SRNO, Purge_Id Purge_Table_Name, Availble_Trns_Count Purge_Record_Count, trns_start_ts Purging_From_Date, trns_end_ts Purging_To_Date, Batch_Message Purge_Status, Batch_Start_Time Purging_Start_Date, Batch_End_Time Purging_End_Date, ROUND ( (  TO_DATE ( TO_CHAR (Batch_End_Time, ''dd/mm/yyyy hh24:mi:ss''), ''dd/mm/yyyy hh24:mi:ss'') - TO_DATE ( TO_CHAR (Batch_start_Time, ''dd/mm/yyyy hh24:mi:ss''), ''dd/mm/yyyy hh24:mi:ss'')) * (24 * 60), 2) Puring_Time_in_Min FROM Purgedata.Trns_Purge_Batch_Info WHERE Batch_start_Time >= TRUNC (SYSDATE) - 1) WHERE SRNO = 1';
  --Run the sql that will create the xml.
  EXECUTE IMMEDIATE varsql INTO XML;
  --Capture whether or not any rows were returned
  IF LENGTH(XML) > 0 THEN
    --Create the body of the email, which contains the xml results of the query.
--    body := to_clob('<html><body><H3>') || p_text || '</H3><table border = 1><tr>' || tblfieldheader || '</tr>' || XML || '</table></body></html>';
    BODY := TO_CLOB('<html><p> <font face="calibri" size="3" >Hi All,</font></p><H4><font face="calibri" size="3" > <i>TransIT East Transaction Daily Purging Status Report.</i></font> </H4><body><table border = 1><font face="calibri" size="2.5" ><tr>') || tblfieldheader || '</tr>' || XML || '</font></table></body><footer><p><B><font face="calibri" size="3" >Thanks and Regards,</B></font><br><font face="calibri" size="3">DBA Team.</font><br><font face="calibri" size="2" color="red">**This is autogenerated email via DB process.</font></p></footer></html>';
    --If rows were returned, send the email.
--    sys.utl_mail.SEND( 'Oracledbmail@domain.com', recipients,NULL, NULL, subject , body, 'text/html', 3);
  END IF;
--******************************************

--    ----------------------------------------------------
--    -- Write the text boundary
--    l_offset := dbms_lob.getlength(l_body_html) + 1;
--    l_temp   := '--' || l_boundary || chr(13)||chr(10);
--    l_temp   := l_temp || 'content-type: text/plain; charset=us-ascii' || 
--                  chr(13) || chr(10) || chr(13) || chr(10);
--    dbms_lob.write(l_body_html,length(l_temp),l_offset,l_temp);
--
--    ----------------------------------------------------
--    -- Write the plain text portion of the email
--    l_offset := dbms_lob.getlength(l_body_html) + 1;
--    dbms_lob.write(l_body_html,length(p_text),l_offset,p_text);

    ----------------------------------------------------
    -- Write the HTML boundary
    l_temp   := CHR(13)||CHR(10)||CHR(13)||CHR(10)||'--' || l_boundary || 
                    CHR(13) || CHR(10);
    l_temp   := l_temp || 'content-type: text/html;' || 
                   CHR(13) || CHR(10) || CHR(13) || CHR(10);
    l_offset := DBMS_LOB.GETLENGTH(l_body_html) + 1;
    DBMS_LOB.WRITE(l_body_html,LENGTH(l_temp),l_offset,l_temp);

    ----------------------------------------------------
    -- Write the HTML portion of the message
    l_offset := DBMS_LOB.GETLENGTH(l_body_html) + 1;
    DBMS_LOB.WRITE(l_body_html,LENGTH(BODY),l_offset,BODY);

    ----------------------------------------------------
    -- Write the final html boundary
    l_temp   := CHR(13) || CHR(10) || '--' ||  l_boundary || '--' || CHR(13);
    l_offset := DBMS_LOB.GETLENGTH(l_body_html) + 1;
    DBMS_LOB.WRITE(l_body_html,LENGTH(l_temp),l_offset,l_temp);


    ----------------------------------------------------
    -- Send the email in 1900 byte chunks to UTL_SMTP
    l_offset  := 1;
    l_ammount := 1900;
    UTL_SMTP.OPEN_DATA(l_connection);
    WHILE l_offset < DBMS_LOB.GETLENGTH(l_body_html) LOOP
        UTL_SMTP.WRITE_DATA(l_connection,
                            DBMS_LOB.SUBSTR(l_body_html,l_ammount,l_offset));
        l_offset  := l_offset + l_ammount ;
        l_ammount := LEAST(1900,DBMS_LOB.GETLENGTH(l_body_html) - l_ammount);
    END LOOP;
    UTL_SMTP.CLOSE_DATA(l_connection);
    UTL_SMTP.QUIT( l_connection );
    DBMS_LOB.FREETEMPORARY(l_body_html);
END;
/
