BEGIN
  SYS.DBMS_SCHEDULER.DROP_JOB
    (job_name  => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK');
END;
/

BEGIN
  SYS.DBMS_SCHEDULER.CREATE_JOB
    (
       job_name        => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
      ,start_date      => TO_TIMESTAMP_TZ('2019/08/22 22:51:42.942591 PST8PDT','yyyy/mm/dd hh24:mi:ss.ff tzr')
      ,repeat_interval => 'FREQ=MINUTELY; INTERVAL=3; BYSECOND=0;'
      ,end_date        => NULL
      ,job_class       => 'DEFAULT_JOB_CLASS'
      ,job_type        => 'PLSQL_BLOCK'
      ,job_action      => 'begin SNOX4TRANSNOX.PROC_ACTIVE_SESSION_CHECK(); end;'
      ,comments        => 'This procedure check active session count and if count goes beyond 800 sessions, it will send email.'
    );
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
     ,ATTRIBUTE => 'RESTARTABLE'
     ,VALUE     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
     ,ATTRIBUTE => 'LOGGING_LEVEL'
     ,VALUE     => SYS.DBMS_SCHEDULER.LOGGING_OFF);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( NAME      => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
     ,ATTRIBUTE => 'MAX_FAILURES');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( NAME      => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
     ,ATTRIBUTE => 'MAX_RUNS');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
     ,ATTRIBUTE => 'STOP_ON_WINDOW_CLOSE'
     ,VALUE     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
     ,ATTRIBUTE => 'JOB_PRIORITY'
     ,VALUE     => 3);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( NAME      => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
     ,ATTRIBUTE => 'SCHEDULE_LIMIT');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK'
     ,ATTRIBUTE => 'AUTO_DROP'
     ,VALUE     => TRUE);

  SYS.DBMS_SCHEDULER.ENABLE
    (NAME                  => 'SNOX4TRANSNOX.ACTIVE_SESSION_CHECK');
END;
/






























---------------------------------------------------------------------------------------------------------------------------------------------------------


CREATE OR REPLACE PROCEDURE SNOX4TRANSNOX.PROC_ACTIVE_SESSION_CHECK
IS
   v_session_cnt            NUMBER;
   
         
/******************************************************************************
   NAME:       Proc_Replication_check
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        22/8/2019  Sandip Tujare       1. Created this procedure.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     PROC_ACTIVE_SESSION_CHECK
      Sysdate:         22/8/2019
      Date and Time:   22/8/2019, 12:51:07 PM, and 22/8/2019 12:51:07 PM
      Username:       stujare (set in TOAD Options, Procedure Editor)

******************************************************************************/
BEGIN

   ----Check Database Role
   BEGIN
      SELECT COUNT(1)
        INTO v_session_cnt
        FROM V$SESSION
       WHERE STATUS = 'ACTIVE';
   END;

   
       IF v_session_cnt > 500  
       THEN 
       NULL;
       --Send Mail 
       --transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','acq-tasc@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       --transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','ifx-dbalerts@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       --transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','acq-commandcenter@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       --transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','ACQ-Appl-ProductionSupport@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
       --transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','TransITAlerts@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);
--       transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','TSC_Management@tsys.com','Alert : Lag on '||vDatabaseRole||' Database '||inDatabase||' - '||vDC||'.','Current Lag is '||vLag||' minutes at '||TO_CHAR(SYSDATE,'MM/DD/YYYY HH24MISS'),25);

        transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','stujare@tsys.com','TransIT-WestDC-RPT : Active session count is '||v_session_cnt,'Active session count is '||v_session_cnt,25);
        transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','vishalbhandwalkar@tsys.com','TransIT-WestDC-RPT : Active session count is '||v_session_cnt,'Active session count is '||v_session_cnt,25);
--        transitha.sendmail_oracle ('ifx-dbalerts@tsys.com','stujare@tsys.com','TransIT-WestDC : Active session count is '||v_session_cnt,'Active session count is '||v_session_cnt,25);
       END IF; 
   
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      NULL;
   WHEN OTHERS
   THEN
      -- Consider logging the error and then re-raise
      RAISE;
END PROC_ACTIVE_SESSION_CHECK;   /* GOLDENGATE_DDL_REPLICATION */
/




--------------------------------------------------------------------------------------------------------------------------------------------------------------



CREATE OR REPLACE PROCEDURE TRANSITHA.sendmail_oracle (fromm    VARCHAR2,
                                      too      VARCHAR2,
                                      sub      VARCHAR2,
                                      BODY     VARCHAR2,
                                      port     NUMBER)
IS
   objConnection   UTL_SMTP.CONNECTION;
   vrData          VARCHAR2 (32000);
BEGIN
--   objConnection := UTL_SMTP.open_connection ('smtp.tsysacquiring.org', port);
--   UTL_SMTP.helo (objConnection, 'smtp.tsysacquiring.org');
   objConnection := UTL_SMTP.OPEN_CONNECTION ('smtpwest.tas.corp', port);
   UTL_SMTP.HELO (objConnection, 'smtpwest.tas.corp');
   UTL_SMTP.MAIL (objConnection, fromm);
   UTL_SMTP.RCPT (objConnection, too);
   UTL_SMTP.OPEN_DATA (objConnection);
   /* ** Sending the header information */
   UTL_SMTP.WRITE_DATA (objConnection, 'From: ' || fromm || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, 'To: ' || too || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, 'Subject: ' || sub || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection,
                        'MIME-Version: ' || '1.0' || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, 'Content-Type: ' || 'text/html;');
   UTL_SMTP.WRITE_DATA (
      objConnection,
      'Content-Transfer-Encoding: ' || '"8Bit"' || UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF);
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.WRITE_DATA (
      objConnection,
         UTL_TCP.CRLF
      || '<span style="color: red; font-family: Courier New;">'
      || BODY
      || '</span>');
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.WRITE_DATA (objConnection, UTL_TCP.CRLF || '');
   UTL_SMTP.CLOSE_DATA (objConnection);
   UTL_SMTP.QUIT (objConnection);
EXCEPTION
   WHEN UTL_SMTP.TRANSIENT_ERROR OR UTL_SMTP.PERMANENT_ERROR
   THEN
      UTL_SMTP.QUIT (objConnection);
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
   WHEN OTHERS
   THEN
      UTL_SMTP.QUIT (objConnection);
      DBMS_OUTPUT.PUT_LINE (SQLERRM);
END sendmail_oracle;  /* GOLDENGATE_DDL_REPLICATION */
/
