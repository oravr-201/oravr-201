BEGIN
  SYS.DBMS_SCHEDULER.DROP_JOB
    (job_name  => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB');
END;
/

BEGIN
  SYS.DBMS_SCHEDULER.CREATE_JOB
    (
       job_name        => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
      ,start_date      => TO_TIMESTAMP_TZ('2017/09/29 00:07:13.867649 PST8PDT','yyyy/mm/dd hh24:mi:ss.ff tzr')
      ,repeat_interval => 'FREQ=DAILY;BYHOUR=01'
      ,end_date        => NULL
      ,program_name    => 'GGATE.INS_XTN_BILLING_SUMMARY_PRGM'
      ,comments        => 'Job to insert the data into billing summary table'
    );
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
     ,ATTRIBUTE => 'RESTARTABLE'
     ,VALUE     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
     ,ATTRIBUTE => 'LOGGING_LEVEL'
     ,VALUE     => SYS.DBMS_SCHEDULER.LOGGING_OFF);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( NAME      => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
     ,ATTRIBUTE => 'MAX_FAILURES');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( NAME      => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
     ,ATTRIBUTE => 'MAX_RUNS');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
     ,ATTRIBUTE => 'STOP_ON_WINDOW_CLOSE'
     ,VALUE     => FALSE);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
     ,ATTRIBUTE => 'JOB_PRIORITY'
     ,VALUE     => 3);
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE_NULL
    ( NAME      => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
     ,ATTRIBUTE => 'SCHEDULE_LIMIT');
  SYS.DBMS_SCHEDULER.SET_ATTRIBUTE
    ( NAME      => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB'
     ,ATTRIBUTE => 'AUTO_DROP'
     ,VALUE     => TRUE);

  SYS.DBMS_SCHEDULER.ENABLE
    (NAME                  => 'GGATE.XTN_BILLING_SUMMARY_PRGM_JOB');
END;
/
------------------------------------------------------------------------------------------
















BEGIN
  DBMS_SCHEDULER.DROP_PROGRAM
    (program_name          => 'GGATE.INS_XTN_BILLING_SUMMARY_PRGM');
END;
/

BEGIN
  SYS.DBMS_SCHEDULER.CREATE_PROGRAM
    (
      program_name         => 'GGATE.INS_XTN_BILLING_SUMMARY_PRGM'
     ,program_type         => 'PLSQL_BLOCK'
     ,program_action       => 'BEGIN
   INSERT INTO transnox_IOX.BILLING_SUMMARY_TABLE (SERVER_DATE,
                                                     Merchant_ID,
                                                     Device_ID,
                                                     ENCRYPTION_TYPE,
                                                     TRANSACTION_COUNT)
        SELECT TRUNC (XTN.TIME_STAMP)            SERVER_DATE,
               D.MERCHANT_ID,
               XTN.DEVICE_ID,
               ''TRANSACTION''                     ENCRYPTION_TYPE,
               NVL (COUNT (XTN.TRANSACTION_ID), 0) TRANSACTION_COUNT
          FROM transnox_IOX.TRANSACTION XTN,
               transnox_IOX.TRANS_DETAIL TD,
               SNOX4TRANSNOX.DEVICE D
         WHERE     XTN.DEVICE_ID = D.DEVICE_ID
               AND XTN.TRANSACTION_ID = TD.TRANSACTION_ID
               AND XTN.TIME_STAMP BETWEEN TRUNC (SYSDATE) - 1
                                      AND TRUNC (SYSDATE) - (1 / 86400)
               AND TD.DATE_CREATED BETWEEN TRUNC (SYSDATE) - 1
                                       AND TRUNC (SYSDATE) + (10 / 1440)
               AND XTN.TRANS_TYPE not in( ''_TOKEN'',''CREDIT_TOKEN'')
               AND D.PRODUCT_CODE = ''IFX_CPASS''
               AND   TD.PROCESSED_VIA_CHK_COMM = ''N''
      GROUP BY TRUNC (XTN.TIME_STAMP), D.MERCHANT_ID, XTN.DEVICE_ID;
END;'
     ,number_of_arguments  => 0
     ,enabled              => FALSE
     ,comments             => 'To Insert Data Into billing summary from TRANSACTION Table'
    );

  SYS.DBMS_SCHEDULER.ENABLE
    (NAME                  => 'GGATE.INS_XTN_BILLING_SUMMARY_PRGM');
END;
/
