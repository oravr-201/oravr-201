--------------------------------------------------------------------------
							ORACLE perfomance tuning  
--------------------------------------------------------------------------

 *. What is performance Tuning?
		Performance tuning is the term used to improve the performance of a C.P.U to increase the speed of response time with minimum resource.
		
*. 	What database aspects should be monitored?One should implement a monitoring system to constantly monitor the following 		aspects of a database. Writing custom scripts, implementing Oracle’s Enterprise Manager, or buying a third-party 
	  monitoring product can achieve this. If an alarm is triggered, the system should automatically notify the DBA (e-		mail, page, etc.) to take appropriate action.

Infrastructure availability: • Is the database up and responding to requests
                                         • Are the listeners up and responding to requests
                                         • Are the Oracle Names and LDAP Servers up and responding to requests
                                         • Are the Web Listeners up and responding to requests

Things that can cause service outages:• Is the archive log destination filling up?
                                                             • Objects getting close to their max extents
                                                             • Tablespaces running low on free space/ Objects what would not be able to extend
                                                             • User and process limits reached
															 
														
*.	What tuning indicators can a DBA use?The following high-level tuning indicators can be used to establish if a database is performing optimally or not:
		1 Buffer Cache Hit Ratio
		Formula: Hit Ratio = (Logical Reads - Physical Reads) / Logical Reads
		Action: Increase DB_CACHE_SIZE (DB_BLOCK_BUFFERS prior to 9i) to increase hit ratio
		2Library Cache Hit Ratio
		Action: Increase the SHARED_POOL_SIZE to increase hit ratio
		
*.	What are the values that can be specified for OPTIMIZER MODE Parameter?
	All_rows,rule,first_rows_1000,first_rows_100,first_rows_10,first_rows_1,choose,first_rows.
	
*.	 What is the function of Optimizer?
		The goal of the optimizer is to choose the most efficient way to execute a SQL statement.
		
*.	What is COST-based approach to optimization?
	Considering available access paths and determining the most efficient execution plan based on statistics in the data dictionary for the tables accessed by the statement and their associated clusters and indexes.
*.	 What is RULE-based approach to optimization?
	Choosing an executing plan based on the access paths available and the ranks of these access paths.

	
*.	What is mean by Program Global Area (PGA) ?
		The PGA (Program or Process Global Area) is a memory area (RAM) that stores data and control information for a single process. it typically contains a sort area, hash area, session cursor cache, etc.
		
*. 	How would you generating an EXPLAIN plan?
	It is pre execution plan .If you do an EXPLAIN PLAN, Oracle will analyze the statment and fill a special table with the Execution plan for that statement. If you omit the INTO TABLE_NAME clause, Oracle fills a table named PLAN_TABLE by default.
	Usage:explain plan into table_name for your-precious-sql-statement;
	The plan table is the table that Oracle fills when you have it explain an execution plan for an SQL statement. You must make sure such a plan table exists. Oracle ships with the script UTLXPLAN.SQL which creates this table, named PLAN_TABLE (which is the default name used by EXPLAIN PLAN). If you like, however, you can choose any other name for the plan table, as long as you have been granted insert on it and it has all the fields as here.
	
*.	Can you enable trace for a session?
	Yes. We can enable SQL trace for a session using “ALTER SESSION SET sql_trace=TRUE”. But it is not advisable as it is a performance issue. It has to be used only when you want to trace a session to monitor performance related issues and then stop it.
	
*. 	What is the parameter to set the user trace enabling?
	Sql_trace = true
	
*.	How to create a trace file?
	Set sql_trace=true
*.	What is Explain Plan? When do we take it?
	Explain plan tells us how the query is being executed, whether it is using index or not if so what kind of index, how many loops are being used, what is the cost of each line in the SQL query, total cost involved, estimated rows returned, estimated KB returned, types of joins used and stuff like that.
	
*.	 What is the cache hit ratio, what impact does it have on performance of anOracle database?For the buffer cache hit ratio, 		it calculates how often a requested block has been found in the buffer cache without requiring disk access. This ratio 		is computed using data selected from the dynamic performance view V$SYSSTAT. The buffer cache hit ratio can be used to 		verify the physical I/O as predicted by V$DB_CACHE_ADVICE.
*.	What are hints in Oracle? HINTS are nothing but the comments used in a SQL statement to pass instructions to the Oracle 	optimizer.The optimizer uses these hints  to an execution plan for the statement.

*.	You have 4 instances running on the same UNIX box. How can you determine which shared memory and semaphores are associated 		with which instance?
	Ipcs
	SQL> oradebug setmypid
	SQL> oradebug ipc
	SQL>oradebug tracfile_name

*.  If you want to configure shared servers which three parameters you need to specify in init.ora file?
	LOCAL_LISTENER, SHARED_SERVERS ,DISPATCHERS.
	
*. 4. What is the function of Dispatcher (Dnnn) ?
	Dispatcher (Dnnn) process is responsible for routing requests from connected user processes to available shared server processes and returning the responses back to the appropriate user processes
	
*.	How many Dispatcher Processes are created ?
	At least one Dispatcher process is created for every communication protocol in 	use.(V$dispatchers)





*.	Till yesterday a query is giving output in 1 min. today it is taking 5 min. how you  will troubleshoot this problem?
		We will start looking at the network issues
		Check if the query is changed from yesterday to today
		Check table statistics are upto date
		Generate explain plan and see where is the problem
*.	A job which will generally execute in 1 hour, now running since 5 hours, what  can be done to find out the problem?
		Check if any code change in the job
		Check table statistics 
		Generate explain plan for all the queries and DML/DDL statements in the job
		Better to disable indexes for time being in order to make it faster
*.	Users are complaining that database is running slow everyday between 11 AM t0  2 PM. How to find out what’s going wrong 	during that time?
		We can generate statspack or AWR report and will observe different sections
*.	What is the purpose of collecting statistics?
		It will help optimizer to generate best execution plan
*.	If you need to schedule a new analyze job for a single large schema, how you will  do that?
		We will schedule daily analyze job for frequently accessed tables
		Schedule weekly job for semi dynamic tables
*.	What things you will analyze in explain plan?
		We will check if query is using proper indexes are not. If not we will either create new indexes or can use hints to specify which indexes to use
*.	Have you ever done partitioning? What is its use?
		Yes. It will help in searching data easily as it is stored in multiple partitions
*.	Why to go for composite partitioning?
		In case we have very large table and want faster access
*.	What is the difference between local and global index?
		Local index is the one which we can create for a single partition. Global index can be used for entire table at a time
*.	How you will re-organize the database?
		If 9i we can use exp/imp or move table. From 10g, we can use shrink compact command
*.	Why indexes will become unusable during a table move?
		Because the row id’s will change when we move a table and index is based on that row id
*.	Can we move a table to the same tablespace?
		Yes, but we need to have enough free space
*.	What should the frequency of performing re-organization in a database?
		If we are using ASSM, there is no need to re-org. Else, it is preferred to do every 6 months
*.	How can avoid fragmentation in a table?
		By using automatic segment space management
*.	What is the difference between row chaining and row migration?
		Row chaining means splitting same row across multiple blocks. Row migration means moving row to another block. In both the cases, I/O will be increased
*.	What is mean by row chaining and when it will occur? Solutions to avoid it?
		Splitting a single row into various blocks is called row chaining. It will occur when the data size is more than blocksize. We can use non-default block size tablespaces to avoid this
*.	What is the benefit of using index?
		It will speed up the process of searching for data
*.	How index works in the database?
		Index will be stored as tree format and when a comparison is required, it will start with root node and will spread to branch or leaf nodes if required
*.	You want to drop and re-create a parent table. How you will do that without  affecting child tables?
		By disabling constraints first
*.	How you would go about increasing buffer cache hit ratio? Which view will help  in this case?
		V$buffer_cache_advice
*.	What is the difference between locks and latches?
		Locks are to maintain read consistency and will be applied on tables. If the same kind is on instance memory structures, it is called latches
*.	How you will manage locks?
		We doesn’t need to do anything about locks, oracle will take care of them
*.	What are the 3 advisory statistics that you can collect?
		Memory, segment and hit ratio’s advisory
*.	What you will analyze out of TKPROF report?
		It will help us in knowing how much time and cost a query is using in the database during its execution
*.	What options we can use with tkprof report?
		So many, listed in google (generally we will not use them)
*.	What is the use of keep cache and recycle cache?
		Keep cache can be used to store a table which is being frequently used and if we want to not flush from the instance. Recycle is used for full scan tables to flush the data immediately
*.	How you will determine for which resources sessions are waiting for?
		V$session_waits or v$system_waits
*.	What is the difference between a statspack and AWR report?
		AWR is advanced version of statspack report in which statstics collection will be done automatically every one hour
*.	How you will analyze AWR report?
		Refer to the documents provided along with class notes
*.	What are top 5 timed events in AWR report?
		Those will represent for what database is waiting mostly for
*.	What is ADDM in 10g?
		It is a utility helps in providing some recommendations based on the statistics collected every hour
*.	What is the difference between ANALYZE and DBMS_STATS?
		DBMS_STATS will collect more information than ANALYZE command
*.	When to use more than one DBWR process?
		If we have datafiles spread across multiple disks and mostly it is used in OLTP environment
*.	When a database object becomes invalid?
		If the underlying base objects gets modified
*.	How to find the no of blocks a table is occupied?
		dba_tables
*.	In which situations you will increase SHARED_POOL_SIZE parameter?
		When we observe that a frequently executed statement is undergoing hard parsing every time
*.	Which parameter helps in giving complete output for TKPROF report?
		SQL_TRACE
*.	When looking at v$sysstat, you observed sort(disk) is high, is this good or bad? If  bad, how you correct it?
		Its bad. We should not have more physical I/O
*.	What is the difference between instantaneous and cumulative buffer hit ratio?
		Reading data from instance is better than cumulative in which data should be read from disk which is costly
*.	If a tablespace is having zero pctincrease value, what could be the problem with  SMON?
		SMON will not coalesce the tablespace
*.	How can you tell if a tablespace has excessive fragmentation?
		If a select aganist dba_free_space shows the count of a tablespace extents is greater than the count of its datafiles, then it is fragmented
*.	What can cause high value for recursive calls? How to fix it?
		Improper cursor usage which should be fixed by code writers
*.	How you will identify that a deadlock occurred and what immediate action you will take?
		Oracle itself will detect that and will resolve that by rolling back a transaction
*.	What is ORA-600 error and what causes it to occur? How to resolve it?
		It is an internal error which can be occurred due to various reasons. We need to contact oracle support or using ora-600 lookup tool in metalink
*.	How oracle will maintain read consistency always?
		By using locks on the tables
*.	How many types of optimizers are there? What is the difference between them?
		Cost based and rule based optimization. Cost will generated better execution plan than rule based
*.	How you will specify a query to use full table scan even though it is having index?
		Using hint
*.	How do you identify which sessions are locking the objects? What is the way to clear them?
		By combining V$locked_object and v$session
*.	If we observe latch hit ratio is high, is it a good or bad sign?
		It is a good sign as every statement need not to wait for the free buffer
*.	In your experience, what are the different wait events noticed and tell how you resolved them?
		Read the PT docs provided and explain any 2 or 3 of them with solutions
*.	What is the use of iostat/vmstat/netstat command in Linux?
		Iostat – reports on terminal, disk and tape I/O activity.
		Vmstat – reports on virtual memory statistics for processes, disk, tape and CPU activity.
		Netstat – reports on the contents of network data structures.
		
*.	What is the difference between Redo,Rollback and Undo?
		I find there is always some confusion when talking about Redo, Rollback and Undo. They all sound like pretty much the same thing or at least pretty close.
		Redo: Every Oracle database has a set of (two or more) redo log files. The redo log records all changes made to data, including both uncommitted and committed changes. In addition to the online redo logs Oracle also stores archive redo logs. All redo logs are used in recovery situations.
		Rollback: More specifically rollback segments. Rollback segments store the data as it was before changes were made. This is in contrast to the redo log which is a record of the insert/update/deletes.
		Undo: Rollback segments. They both are really one in the same. Undo data is stored in the undo tablespace. Undo is helpful in building a read consistent view of data.
		
*.	