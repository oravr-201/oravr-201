-- What type of Topology does Goldengate support?
GoldenGate supports the following topologies. More details can be found here.

Unidirectional
Bidirectional
Peer-to-peer
Broadcast
Consolidation
Cascasding

-- What are the main components of the Goldengate replication?
The replication configuration consists of the following processes.

Manager
Extract
Pump
Replicate

-- What database does GoldenGate support for replication?
Oracle Database
TimesTen
MySQL
IBM DB2
Microsoft SQL Server
Informix
Teradata
Sybase
Enscribe
SQL/MX

-- What transaction types does Goldengate support for Replication?
Goldengate supports both DML and DDL Replication from the source to target.

-- What are the supplemental logging pre-requisites?
The following supplemental logging is required.

Database supplemental logging
Object level logging

-- Why is Supplemental logging required for Replication?
When a transaction is committed on the source database, only new data is written to the Redo log. However for Oracle to apply these transactions on the destination database, the before image key values are required to identify the effected rows. This data is also placed in the trail file and used to identify the rows on the destination, using the key value the transactions are executed against them.

-- List important considerations for bi-directional replication?
The customer should consider the following points in an active-active replication environment.

Primary Key: Helps to identify conflicts and Resolve them.

Sequences: Are not supported. The work around is use to use odd/even, range or concatenate sequences.

Triggers: These should be disabled or suppressed to avoid using uniqueness issue
Data Looping: This can easy avoided using OGG itself

LAG: This should be minimized. If a customer says that there will not be any LAG due to network or huge load, then we don’t need to deploy CRDs. 
But this is not the case always as there would be some LAG and these can cause Conflicts.

CDR (Conflict Detection & Resolution): OGG has built in CDRs for all kind of DMLs that can be used to detect and resolve them.

Packaged Application: These are not supported as it may contain data types which are not support by OGG or it might not allow the application 
modification to work with OGG.

-- Are OGG binaries supported on ASM Cluster File System (ACFS)?
Yes, you can install and configure OGG on ACFS.

-- Are OGG binaries supported on the Database File System (DBFS)? What files can be stored in DBFS?
No, OGG binaries are not supported on DBFS. You can however store parameter files, data files (trail files), and checkpoint files on DBFS.

-- What is the default location of the GLOBALS file?
A GLOBALS file is located under Oracle GoldenGate installation directory (OGG HOME)

-- Where can filtering of data for a column be configured?
Filtering of the columns of a table can be set at the Extract, Pump or Replicat level.

-- Is it a requirement to configure a PUMP extract process in OGG replication?
A PUMP extract is an option, but it is highly recommended to use this to safe guard against network failures. Normally it is configured 
when you are setting up OGG replication across the network.

-- What are the differences between the Classic and integrated Capture?
Classic Capture:

The Classic Capture mode is the traditional Extract process that accesses the database redo logs (optionally archive logs) to capture the DML 
changes occurring on the objects specified in the parameter files.

At the OS level, the GoldenGate user must be a part of the same database group which owns the database redo logs.
This capture mode is available for other RDBMS as well.
There are some data types that are not supported in Classic Capture mode.
Classic capture can’t read data from the compressed tables/tablespaces.
Integrated Capture (IC):

In the Integrated Capture mode, GoldenGate works directly with the database log mining server to receive the data changes in the form of 
logical change records (LCRs).
IC mode does not require any special setup for the databases using ASM, transparent data encryption, or Oracle RAC.
This feature is only available for oracle databases in Version 11.2.0.3 or higher.
 It also supports various object types which were previously not supported by Classic Capture.
This Capture mode supports extracting data from source databases using compression.
Integrated Capture can be configured in an online or downstream mode.

-- List the minimum parameters that can be used to create the extract process?
The following are the minimium required parameters which must be defined in the extract parameter file.

EXTRACT NAME
USERID
EXTTRAIL
TABLE

-- What are macros?
Macro is an easier way to build your parameter file. Once a macro is written it can be called from different parameter files. 
Common parameters like username/password and other parameters can be included in these macros. A macro can either be another parameter file or a library.

-- Where can macros be invoked?
The macros can be called from the following parameter files.

Manager
Extract
Replicat
Gobals

-- How is a macro defined?
A macro statement consists of the following.

Name of the Macro
Parameter list
Macro body
Sample:
MACRO #macro_name
PARAMS (#param1, #param2, …)
BEGIN
< macro_body >
END;

-- I want to configure multiple extracts to write to the same exttrail file? Is this possible?
Only one Extract process can write to one exttrail at a time. So you can’t configure multiple extracts to write to the same exttrail.

-- What type of Encryption is supported in Goldengate?
Oracle Goldengate provides 3 types of Encryption.

Data Encryption using Blow fish.
Password Encryption.
Network Encryption.

-- What are the different password encrytion options available with OGG?
You can encrypt a password in OGG using

Blowfish algorithm and
Advance Encryption Standard (AES) algorithm

-- What are the different encryption levels in AES?
You can encrypt the password/data using the AES in three different keys

a) 128 bit
b) 192 bit and
c) 256 bit

Is there a way to check the syntax of the commands in the parameter file without actually running the GoldenGate process
Yes, you can place the SHOWSYNTAX parameter in the parameter file and try starting. If there is any error you will see it.

-- How can you increase the maximum size of the read operation into the buffer that holds the results of the reads from the transaction log?
If you are using the Classical Extract you may use the TRANSLOGOPTION ASMBUFSIZE parameter to control the read size for ASM Databases.

-- What information can you expect when there us data in the discard file?
When data is discarded, the discard file can contain:
1. Discard row details
2. Database Errors
3. Trail file number

-- What command can be used to switch writing the trail data to a new trail file?
You can use the following command to write the trail data to a new trail file.
SEND EXTRACT ext_name, ROLLOVER

-- How can you determine if the parameters for a process was recently changed
When ever a process is started, the parameters in the .prm file for the process is written to the process REPORT. You can look at 
the older process reports to view the parameters which were used to start up the process. By comparing the older and the current 
reports you can identify the changes in the parameters.