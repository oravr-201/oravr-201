--- RMAN (Recovery Manager)


Explanation of RMAN Terminology

This section presents definitions of the RMAN terms used in the
subsequent sections of this chapter:
  
--RMAN TARGET DATABASE � 
An RMAN Target Database is the primary database that 
will be backed up for RAC Grid creation. In RMAN�s terminology, the term 
target database identifies the database that is undergoing a backup, 
restore or recovery operation by the RMAN Recovery Manager.
 
--RMAN AUXILIARY DATABASE � 
An Auxiliary Database is a RAC Grid that will be 
created as a result of the duplication of the target database. In RMAN�s 
terminology, Auxiliary instance identifies an instance which RMAN 
connects in order to execute the duplicate command.
 
--RMAN CHANNEL � 
An RMAN Channel is a communication pipeline between a RMAN 
executable and a target or auxiliary database. An RMAN channel consists 
of a server session on the target or auxiliary database and a data stream 
from the database to the backup device or vice-versa. RMAN console sends 
commands to the database using this channel, and the server session 
running on the database executes the command on behalf of the RMAN 
Recovery Manager.
 
--RMAN AUTOMATIC CHANNEL ALLOCATION � 
RMAN Channels can be configured to use a set of default attributes 
for each operation when a channel is not allocated manually. By default, RMAN configures a channel of 
device type, DISK, to be used for automatic channel allocation.
 
--RMAN MANUAL CHANNEL ALLOCATION - 
As the name suggests, a channel can be configured manually for special 
needs such as increasing the degree of parallelism. Channels can be allocated manually by using the 
ALLOCATE CHANNEL command in the RUN block of RMAN statement. 



RMAN 'Format_String' clause

The formatting of this information varies by platform.

Syntax:

  %c  The copy number of the backup piece within a set of duplexed
      backup pieces. If you did not duplex a backup, then this variable
      is 1 for backup sets and 0 for proxy copies.
      If one of these commands is enabled, then the variable shows the
      copy number. The maximum value for %c is 256. 

  %d  The name of the database. 

  %D  The current day of the month (in format DD)

  %F  Combination of DBID, day, month, year, and sequence into a unique
      and repeatable generated name. 

  %M  The month (format MM)

  %n  The name of the database, padded on the right with x characters
      to a total length of eight characters. 
      For example, if the scott is the database name, %n= scottxxx. 

  %p  The piece number within the backup set. This value starts at 1
      for each backup set and is incremented by 1 as each backup piece
      is created. Note: If you specify PROXY, then the %p variable must
      be included in the FORMAT string either explicitly or implicitly within %U. 

  %s  The backup set number. This number is a counter in the control file that
      is incremented for each backup set. The counter value starts at 1 and is
      unique for the lifetime of the control file. If you restore a backup
      control file, then duplicate values can result.
      Also, CREATE CONTROLFILE initializes the counter back to 1. 

  %t  The backup set time stamp, which is a 4-byte value derived as the
      number of seconds elapsed since a fixed reference time.
      The combination of %s and %t can be used to form a unique name for
      the backup set. 

  %T  The year, month, and day (YYYYMMDD)

  %u  An 8-character name constituted by compressed representations of
      the backup set number and the time the backup set was created. 

  %U  A convenient shorthand for %u_%p_%c that guarantees uniqueness in
      generated backup filenames.
      If you do not specify a format, RMAN uses %U by default. 

  %Y  The year (YYYY)

  %%  Specifies the '%' character. e.g. %%Y translates to %Y. 

-- devracdb_%u_%s_%T


-- create rman database as rcat.
/*
    This will be the different database then the target database. This rcat db will keep all backup information of target database.

give file path for redolog as per your machine path... and same for datafile in create tablespace script. 

*/
CREATE DATABASE rcat
	MAXLOGFILES 10
	MAXLOGMEMBERS 5
	MAXLOGHISTORY 5
	MAXDATAFILES 20
	MAXINSTANCES 2
	LOGFILE 
		GROUP 1
			('D:\oracle\oradata\rcat\redologs\redolog101.log',
			'D:\oracle\oradata\rcat\redologs\redolog102.log') SIZE 100m,
		GROUP 2
			('D:\oracle\oradata\rcat\redologs\redolog201.log',
			'D:\oracle\oradata\rcat\redologs\resolog202.log') SIZE 100m,
		GROUP 3
			('D:\oracle\oradata\rcat\redologs\redolog301.log',
			'D:\oracle\oradata\rcat\redologs\redolog302.log') SIZE 100m
	DATAFILE 	
			'D:\oracle\oradata\rcat\datafiles\system01.dbf' SIZE 500M AUTOEXTEND ON NEXT 10240k maxsize unlimited
    EXTENT MANAGEMENT LOCAL UNDO TABLESPACE undotbsrcat  datafile 'D:\oracle\oradata\rcat\datafiles\undotbsrcat.dbf'  size 200M AUTOEXTEND ON NEXT 5120k maxsize unlimited
	default temporary tablespace temp tempfile 'D:\oracle\oradata\rcat\datafiles\temp.dbf' size 50M autoextend on next 50M maxsize unlimited
	NOARCHIVELOG		
	CHARACTER SET WE8ISO8859P1;
	
	
	CREATE TABLESPACE USERS 
	    DATAFILE 'D:\oracle\oradata\rcat\datafiles\users01.dbf' SIZE 1000M AUTOEXTEND ON NEXT 10240k maxsize unlimited
	    EXTENT MANAGEMENT LOCAL 
        SEGMENT SPACE MANAGEMENT AUTO ;
	
	CREATE TABLESPACE TOOLS 
	    DATAFILE 'D:\oracle\oradata\rcat\datafiles\tools01.dbf' SIZE 800M AUTOEXTEND ON NEXT 10240k maxsize unlimited
	    EXTENT MANAGEMENT LOCAL 
        SEGMENT SPACE MANAGEMENT AUTO ;

	CREATE TABLESPACE INDX 
	    DATAFILE 'D:\oracle\oradata\rcat\datafiles\indx01.dbf' SIZE 1000M AUTOEXTEND ON NEXT 10240k maxsize unlimited
	    EXTENT MANAGEMENT LOCAL 
        SEGMENT SPACE MANAGEMENT AUTO ;      

	CREATE TABLESPACE RCVCAT 
	    DATAFILE 'D:\oracle\oradata\rcat\datafiles\RCVCAT01.dbf' SIZE 50M AUTOEXTEND ON NEXT 10240k maxsize unlimited
	    EXTENT MANAGEMENT LOCAL 
        SEGMENT SPACE MANAGEMENT AUTO ;      

        
---  schema in rcat db and in db which U want to registre for rman backup
CREATE USER RMAN IDENTIFIED BY RMAN DEFAULT TABLESPACE TOOL TEMPORARY TABLESPACE TEMP QUOTA UNLIMITED ON TOOL;


--- Give the privileges to RMAN user/schema
Sqlplus_rcat_db>GRANT CONNECT, RESOURCE, RECOVERY_CATALOG_OWNER, SYSDBA,dba TO rman; 

-- connect RMAN for creating catalog for database
C:\> rman catalog rman/rman@rcat

RMAN> create catalog;  -- will just create a catalog will not assign tablespace for the catalog user

RMAN> create catalog tablespace RMAN_DATA_TBLS; -- will create a catalog and will assign tablespace for the catalog user

-- this is used for dropping the catalog. Prompt will ask you again the execute the same command for confirmation...
RMAN> DROP CATALOG;

/*
   If you start RMAN without connecting to the target database, then you must issue CONNECT TARGET command at the RMAN prompt 
before you can begin performing backup and recovery operations for the target database.

RMAN>connect target sys/sysregdb@regdev

*/
-- then exit from catalog RMAN and again connect  with the target database
RMAN> EXIT



-- target db is your main database. rcat is rman db which will have all backups
C:\> rman catalog rman/rman@rcat target rman/rman@devracdb

RMAN>


-- then register the target database
RMAN>  REGISTER DATABASE;

RMAN>


--Un-register a database

sqlplus user/pass@rmandb

select * from rc_database;

select db_key, db_id from db;

-- to unregister the database from catalog
execute dbms_rcvcat.unregisterdatabase(<db_key>, <db_id>);
execute sys.dbms_rcvcat.unregisterdatabase(43607, '3944465021');

OR

rman CATALOG rman/rman@arccatdb
RMAN> RUN
{  
  SET DBID 376399349;   # specifies test database by DBID
  UNREGISTER DATABASE devracdb NOPROMPT;
}


In this example, you connect to the target database test1 and then unregister it:

rman TARGET SYS/oracle@devracbd CATALOG rman/rman@arccatdb
RMAN> UNREGISTER DATABASE NOPROMPT;

****************************************  Configuration Scripts  **************************************** 

--- Default Configuration 
RMAN> CONFIGURE CONTROLFILE AUTOBACKUP ON;

RMAN> CONFIGURE RETENTION POLICY TO NONE;

RMAN> CONFIGURE DEFAULT DEVICE TYPE TO sbt;

RMAN> CONFIGURE DEVICE TYPE sbt parallelism 8;

RMAN> CONFIGURE CHANNEL DEVICE TYPE sbt parms 'ENV=(NSR_SERVER=<DRIVE_NAME>, NSR_DATA_VOLUME_POOL=L1MI1Y)';

--Show all configurable settings:
RMAN> SHOW ALL;

--Write disk backups to the /tmp directory: (%U will be replaced with unique filenames)
RMAN> CONFIGURE CHANNEL DEVICE TYPE DISK FORMAT '/tmp/%U';

--Backup using a flash recovery area rather than disk
RMAN> CONFIGURE CHANNEL DEVICE TYPE DISK FORMAT CLEAR;

--Configure RMAN to back up the control file after each backup 
RMAN> CONFIGURE CONTROLFILE AUTOBACKUP ON; 

--By default, RMAN automatically names control file backups and stores them in the flash recovery area. 
-- To configure RMAN to write control file backups to the /cfilebackups directory: ( %F will generate a unique filename)

RMAN> CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '/recovery/oracle/rman_bkups/ctrlfile/controlfile_%F.ctl';

--Ensure that RMAN retains all backups needed to recover the database to any point in time in the last 7 days:
RMAN> CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 7 DAYS;

--Retain three backups of each datafile:
RMAN> CONFIGURE RETENTION POLICY TO REDUNDANCY 3;

--override the configured retention policy for individual backups - use BACKUP.. KEEP (or CHANGE.. KEEP)
--Configure backups to run in parallel by assigning two sbt channels:

RMAN> CONFIGURE DEVICE TYPE sbt PARALLELISM 2;

--Reset any CONFIGURE setting to its default by running the command with the CLEAR option
RMAN> CONFIGURE CHANNEL DEVICE TYPE sbt CLEAR; 
RMAN> CONFIGURE RETENTION POLICY CLEAR;

--Unique filenames are: DBID, day, month, year, and sequence number.
RMAN> CONFIGURE SNAPSHOT CONTROLFILE NAME CLEAR;
RMAN> CONFIGURE SNAPSHOT CONTROLFILE NAME TO '/backup/rmanbackup/control_file_snapshot/snapcf_transittxnw.ctl';
/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_devracdb_ctrlfile_%u.ctl

/backup/rmanbackup/control_file_snapshot

****************************************  Full and Incremental Backup Scripts  **************************************** 



-- full backup
create script full_backup
{
 allocate channel ch1 type disk;
 allocate channel ch2 type disk;
 backup
 full
 filesperset = 2
 format '/data/oracle92/rman_bck/oradb/arc_%d%t_s%s_p%p' -- path where you want to keep the backup file
 (database include current controlfile);
 sql "alter system archive log current";
 backup
 full
 format '/data/oracle92/rman_bck/oradb/arc_%d%t_s%s_p%p' -- path where you want to keep the backup file
 archivelog all DELETE input;
 release channel ch1;
 release channel ch2;
}

/data/oracle92/rman_bck/oradb
/data/oracle92/rman_bck/oradb

-- incremental backup
create script incr_backup
{
     allocate channel ch1 type disk;
     allocate channel ch2 type disk; 
     backup 
     incremental level 1
     format 'C:\oradb_backup\arc_%d%t_s%s_p%p' -- path where you want to keep the backup file
     (database include current controlfile); 
     sql "alter system archive log current";
     backup 
     incremental level 1
     archivelog all 
     format 'C:\oradb_backup\arc_%d%t_s%s_p%p';  -- path where you want to keep the backup file
     release channel ch1;      
     release channel ch2; 
}


-- execute the backup script
run{execute script full_backup;}


/*
    Create the DOS .cmd file from where the above run{} script will be called
    
    say you have created on rman_bkup_script.cmd in which you have written
    run{execute script full_backup;}
    
    and in second file (name as call_rman_Script.cmd which you have written the following things
*/

set targetdb_servicename=targetdb -- target db
set targetuser=system
set targetpass=manager

set catalog_servicename=catalogDB --rcat db

set cataloguser=rman
set catalogpass=rman

REM echo "Starting Database Backup"
rman target %targetuser%/%targetpass%@%targetdb_servicename% catalog %cataloguser%/%catalogpass%@%catalog_servicename%  cmdfile 'rman_bkup_script.cmd' msglog=D:\rman\log\RMAN_DEV.log -- give the rman log file path 
REM echo "Backup is Done"

/*

save the file here and exit and put the call_rman_Script.cmd file in task schedular 
so that it will run as per the given schedule

*/

create script full_backup
{
    allocate channel ch1 type disk;
    allocate channel ch2 type disk; 
    backup 
    full
    format '\\dbserver1\RMAN\TRANS\cfdb_%d%t_s%s_p%p'
    (database include current controlfile); 
    sql "alter system archive log current";
    backup
    full
    archivelog all
    format '\\dbserver1\RMAN\TRANS\log_%d%t_s%s_p%p' DELETE input; 
    release channel ch1;      
    release channel ch2;
}

create script incr_backup
{
     allocate channel ch1 type disk;
     allocate channel ch2 type disk; 
     backup 
     incremental level 2 
     format '\\dbserver1\RMAN\TRANS\cfdb_%d%t_s%s_p%p'
     (database include current controlfile); 
     sql "alter system archive log current";
     backup 
     incremental level 2
     archivelog all 
     format '\\dbserver1\RMAN\TRANS\log_%d%t_s%s_p%p'; 
     release channel ch1;      
     release channel ch2; 
}

--- By Replace command the existing script can be replaced with modified commands and values inside the scripts
replace script incr_backup
{
     allocate channel ch1 type disk;
     allocate channel ch2 type disk; 
     backup 
     incremental level 2 
     format '\\dbserver1\G\RMAN\\trans\cfdb_%d%t_s%s_p%p'
     (database include current controlfile); 
     sql "alter system archive log current";
     backup 
     incremental level 2
     archivelog all 
     format '\\dbserver1\G\RMAN\\trans\log_%d%t_s%s_p%p'; 
     release channel ch1;      
     release channel ch2; 
}

--Full restore and recovery
startup nomount;
run {
  allocate channel  t1 type disk;
  allocate channel  t2 type disk;
  allocate channel  t3 type disk;
  allocate channel  t4 type disk;
  restore controlfile;
  restore archivelog all;
  alter database mount;
  restore database;
  recover database;
}
sql 'alter database open resetlogs';

--Restore and roll forward to a point in time

startup nomount;
run {
  set until time ="to_date('30/08/2006 12:00','dd/mm/yyyy hh24:mi')";
  allocate channel  t1 type disk;
  allocate channel  t2 type disk;
  allocate channel  t3 type disk;
  allocate channel  t4 type disk;
  restore controlfile;
  restore archivelog all;
  alter database mount;
  restore database;
  recover database;
}
sql 'alter database open resetlogs';



--Backup a database

RMAN>backup database plus archivelog format '/u01/ora_backup/rman/%d_%u_%s';


run 
{
    allocate channel t1 type disk;
    backup current controlfile format '/u01/ora_backup/rman/%d_%u_%s';
    backup database format '/u01/ora_backup/rman/%d_%u_%s';
    backup archivelog all DELETE input format '/u01/ora_backup/rman/arch_%d_%u_%s';
    release channel t1;
}

--**************************************************************************************
---- final script 
BACKUP INCREMENTAL LEVEL 1 DATABASE FORMAT '/devdb_rmanbkups/rman_bkup/bkup_20Sep2013_%d_DB_%u_%s_%p.bak'

Start by checking your NFS file mount options for Oracle, and verify permissions, hard, rsize, wsize, and noac parms in your NFS mount command:

CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '/opt/app/oracle/product/11.2.0/db_1/controlfile_%F';

-- working fine
#!/bin/sh
#export ORACLE_SID=devracdb2
#export ORACLE_HOME=/opt/app/oracle/product/11.2.0/db_1

bkup_date=`date +%d%b%Y`
echo $bkup_date
#bkup_dir=/oradata2/oracle/devdb_rmanbkups/rman_bkup/devdb_bkup_$bkup_date
bkup_dir=/devdb_rmanbkups/rman_bkup/devdb_bkup_$bkup_date
mkdir -p $bkup_dir
echo $bkup_dir

rman catalog rman/rman_201@arccatdb<< EOF
connect target rman/rman@devracdb;
CONFIGURE CHANNEL DEVICE TYPE DISK FORMAT '$bkup_dir';
run
{
        ALLOCATE CHANNEL c1 device type disk;
        BACKUP DATABASE FORMAT '$bkup_dir/devracdb_%u_%s_%T.bak'
        include current controlfile;
        BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-8/24' DELETE INPUT FORMAT '$bkup_dir/archlogfiles_%u_%s_%T';
        RELEASE CHANNEL c1;
        sql 'alter system switch logfile';
}
resync catalog;
crosscheck backup;
crosscheck archivelog all;
exit
EOF


*/




DELETE ARCHIVELOG ALL UNTIL TIME 


run
{
        ALLOCATE CHANNEL c1 device type disk;
        BACKUP DATABASE FORMAT '/devdb_rmanbkups/rman_bkup/$bkup_dir/devracdb_%u_%s_%T.bak'
        include current controlfile;
        BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-8/24' DELETE INPUT FORMAT '/devdb_rmanbkups/rman_bkup/$bkup_dir/archlogfiles_%u_%s_%T';
        RELEASE CHANNEL c1;
        sql 'alter system switch logfile';
}

BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-8/24' DELETE INPUT FORMAT '/recovery/oracle/rman_arch/archFiles_bkup_%T_%u_%s';


-- will remove/delete the obsolete backups
delete noprompt obsolete;

-- delete backup using date
DELETE BACKUP OF DATABASE COMPLETED BEFORE 'SYSDATE-3' DEVICE TYPE DISK;   
DELETE ARCHIVELOG ALL COMPLETED BEFORE 'SYSDATE-2' BACKED UP 2 TIMES TO DEVICE TYPE SBT;




BACKUP ARCHIVELOG ALL  DELETE INPUT FORMAT '/recovery/oracle/rman_arch/archFiles__%d_%u_%s';

BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-8/24' DELETE INPUT FORMAT '/backup/oracle/rman_bkup/archFiles_bkup_%d_%u_%s';

catalog controlfilecopy '/devdb_rmanbkups/rman_bkup/controlfile_devracdb_27Sep2013.ctl'
 
BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-2' DELETE INPUT FORMAT '/devdb_rmanbkups/rman_bkup/archlogs_bkup_19Sep2013_%d_%u_%s';

-- please try both below options
backup archivelog all delete input until time 'sysdate-1' FORMAT '/recovery/oracle/rman_bkups/archlogs/archFiles_bkup_22Aug2013_%d_%u_%s';

-- backup and delete archive logs until last 1 day
backup archivelog until time 'sysdate-1' delete input FORMAT '/backup/oracle/rman_bkup/archlogs_bkup_02Sep2013_%d_%u_%s';

-- backup and delete archive logs until last 30 min
backup archivelog until time 'sysdate-30/1440' delete input FORMAT '/recovery/oracle/rman_bkups/archlogs/archFiles_bkup_26Aug2013_%d_%u_%s';


--- backup script for devracdb db -- node2

CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 7 DAYS;
run
{
	ALLOCATE CHANNEL RMAN_BACK_CH01 TYPE DISK;
	CROSSCHECK BACKUP;
	BACKUP AS COMPRESSED BACKUPSET INCREMENTAL LEVEL 1 DATABASE FORMAT '/d01/RMAN/databasefiles_%d_%u_%s_%T';
	sql 'ALTER SYSTEM ARCHIVE LOG CURRENT';
	BACKUP AS COMPRESSED BACKUPSET ARCHIVELOG ALL FORMAT '/d01/RMAN/archivelogs_%d_%u_%s_%T' DELETE INPUT;
	BACKUP AS COMPRESSED BACKUPSET CURRENT CONTROLFILE FORMAT '/d01/RMAN/controlfile_%d_%u_%s_%T';
	CROSSCHECK BACKUP;
	DELETE NOPROMPT OBSOLETE;
	DELETE NOPROMPT EXPIRED BACKUP;
	RELEASE CHANNEL RMAN_BACK_CH01;
}


--------------------------------------------------------------------------------------------------
--Backup Levels
Level = 0 			 -- � A level 0 incremental backup, similar to a full backup, contains all data file blocks.
Level = 1 			 -- � A differential level 1 incremental backup contains only blocks modified since the last incremental backup. 
Level = 1 CUMULATIVE -- � A cumulative level 1 incremental backup contains only blocks modified since the last level 0 incremental backup.

   
-- Monthly Backup
S  M  T  W  T  F  S
0  1  1  1C 1  1  1c

S  M  T  W  T  F  S
1C 1  1  1 1C  1  1 

S  M  T  W  T  F  S
1C 1  1  1 1C  1  1 

S  M  T  W  T  F  S
1C 1  1  1 1C  1  1 


-- Weekly Backup
S  M  T  W  T  F  S
0  1  1  1C 1  1 1C

S  M  T  W  T  F  S
0  1  1  1C 1  1 1C

S  M  T  W  T  F  S
0  1  1  1C 1  1 1C
	
S  M  T  W  T  F  S
0  1  1  1C 1  1 1C


-- Take the backup on Sunday using level 0
BACKUP DATABASE PLUS ARCHIVELOG LEVEL 0;

-- Take the backup on 
BACKUP INCREMENTAL LEVEL 1 DATABASE FORMAT  'c:\rman_bkups\';

Daily backup:
BACKUP INCREMENTAL LEVEL 1 CUMULATIVE DATABASE FORMAT 'c:\rman_bkups\';

--------------------------------------------------------------------------------------------------

rman catalog rman/rman_201@arccatdb target rman/rman@devracdb msglog=/devdb_rmanbkups/rman_bkup/rman_INCR_1_${ORACLE_SID}_$bkup_date.log


#!/bin/sh
export ORACLE_SID=arccatdb
bkup_date="`date +%m%d%Y`"
rman catalog rman/rman_201@arccatdb<< EOF
connect target sys/sysregracdb@regracdb
run
{
        ALLOCATE CHANNEL c1 device type disk;
        BACKUP
        FORMAT '/recovery/oracle/rman_bkups/bkups/$bkup_date_%d_DB_%u_%s_%p.bak'
        INCREMENTAL LEVEL = 0 (DATABASE include current controlfile);
        BACKUP ARCHIVELOG ALL
        DELETE INPUT FORMAT '/recovery/oracle/rman_bkups/archlogs/archFiles_$bkup_date_%d_%u_%s';
        RELEASE CHANNEL c1;
        sql 'alter system switch logfile';
}
exit;
EOF


--**************************************************************************************

run 
{
    allocate channel t1 type disk;
    backup archivelog all DELETE input format '/u01/ora_backup/rman/arch_%d_%u_%s';
    release channel t1;
}


Cold backup (archivelog or noarchivelog mode)
run 
{
    allocate channel t1 type disk;
    shutdown immediate;
    startup mount;
    backup database include current controlfile format '/u01/ora_backup/rman/%d_%u_%s';
    alter database open;
}


run 
{
     allocate channel  t1 TYPE DISK FORMAT '/ora1/nfs_shared_10/rman_dev14/archives/arch_%d_%u_%s';
     backup archivelog all DELETE input;
}

--When backing up to disk, you can spread the backup across several disk drives. Allocate one 
--DEVICE TYPE DISK channel for each disk drive and specify the format string so that the output 
--files are on different disks.

RUN
{
  ALLOCATE CHANNEL disk1 DEVICE TYPE DISK FORMAT '/ora1/nfs_shared_10/rman_dev14/%U'; 
  ALLOCATE CHANNEL disk2 DEVICE TYPE DISK FORMAT '/ora2/nfs_shared_10/rman_dev14/%U'; 
  BACKUP DATABASE PLUS ARCHIVELOG;
}




-- Creating Multiple Copies of a Backup on Tape

/*

In this example, four tape drives are available for writing: stape1, stape2, stape3, and stape4. 
You use the SET BACKUP COPIES command to indicate that RMAN should create two identical copies of 
the database. Because the guideline is that the number of tape channels should equal the number of 
tape devices divided by the number of duplexed copies, you allocate two channels. Note that in this 
case the BACKUP_TAPE_IO_SLAVES initialization parameter must be set to TRUE.

In the OB_DEVICE_n parameter for Oracle Secure Backup, the n specifies the copy number of the backup piece. 
RMAN writes copy 1 of each backup piece to tape drives stape1 and stape2 and writes copy 2 of each backup 
piece to drives stape3 and stape4. Thus, each copy of the database backup is distributed between two tape 
drives, so that part of the data is on each drive.

*/

RUN
{
  ALLOCATE CHANNEL t1 DEVICE TYPE sbt 
    PARMS 'ENV=(OB_DEVICE_1=stape1,OB_DEVICE_2=stape3)';
  ALLOCATE CHANNEL t2 DEVICE TYPE sbt 
    PARMS 'ENV=(OB_DEVICE_1=stape2,OB_DEVICE_2=stape4)';
  SET BACKUP COPIES 2;
  BACKUP DATABASE;
}




--1. Turn on block checking
--REASON: The aim is to detect, very early the presence of corrupt blocks in the database. 
--        This has a slight performance overhead, but Checksums allow Oracle to detect early corruption 
--		  caused by underlying disk, storage system, or I/O system problems.

SQL> alter system set db_block_checking = true scope=both;


--2. Turn on block tracking when using RMAN backups (if running 10g or above)
--REASON: This will allow RMAN to backup only those blocks that have changed since the last full backup, 
--		  which will reduce the time taken to back up, as less blocks will be backed up.

SQL> alter database enable block change tracking using file �/u01/oradata/ora1/change_tracking.f�;


--3. Duplex log groups and members and have more than one archive log dest
--REASON: If an archivelog is corrupted or lost, by having multiple copies in multiple locations, 
--		  the other logs will still be available and could be used.

-- If an online log is DELETEd or becomes corrupt, you will have another member that can be used to 
-- recover if required.

SQL> alter system set log_archive_dest_2='location=/new/location/archive2' scope=both;
SQL> alter database add logfile member '/new/location/redo21.log' to group 1;

/*
 4. When backing up the database use the 'check logical' parameter

REASON: This will cause RMAN to check for logical corruption within a block as well as the normal
head/tail checksumming. This is the best way to ensure that you will get a good backup.

*/

RMAN> backup check logical database plus archivelog DELETE input;

/*

5. Test your backup

REASON: This will do everything except actually restore the database. This is the best method to determine 
if your backup is good and usable before being in a situation where it is
critical and issues exist.
*/

RMAN> restore validate database;

/*

6. Have each datafile in a single backup piece

REASON: When doing a partial restore RMAN must read through the entire piece to get the
datafile/archivelog requested. The smaller the backup piece the quicker the restore can
complete. This is especially relevent with tape backups of large databases or where the
restore is only on individual / few files.

*/

RMAN> backup database filesperset 1 plus archivelog DELETE input;

/*
7. Maintain your RMAN catalog/controlfile
REASON: Choose your retention policy carefully. Make sure that it compliments your tape subsystem
retention policy, requirements for backup recovery strategy. If not using a catalog, ensure that your 
controlfile record keep time instance parameter matches your retention policy.
*/

SQL> alter system set control_file_record_keep_time=21 scope=both;
--This will keep 21 days of backup records.

--Run regular catalog maintenance.

--REASON: crosschecking will check that the catalog/controlfile matches the physical backups. If a backup 
-- is missing, it will set the piece to 'EXPIRED' so when a restore is started, that it will not be eligible, 
-- and an earlier backup will be used. To remove the expired backups from the catalog/controlfile use the 
-- DELETE expired command.

-- CROSSCHECK command checks the status of a backup or a copy on disk or tape
-- Crosscheck to check that files are in place ready for a restore
RMAN> crosscheck backup;

RMAN> CROSSCHECK BACKUP;
RMAN> CROSSCHECK COPY;
RMAN> CROSSCHECK backup of database; 
RMAN> CROSSCHECK backup of controlfile;
RMAN> CROSSCHECK archivelog all;

Query the media manager for the status of backup sets in a given date range:

RMAN> ALLOCATE CHANNEL FOR MAINTENANCE DEVICE TYPE sbt;
RMAN> CROSSCHECK BACKUP DEVICE TYPE sbt COMPLETED BETWEEN '01-AUG-04' AND '31-DEC-04';


-- DELETE command lists specified backup objects and prompts for confirmation to remove them, In below e.g. expired backups will be removed
RMAN> DELETE expired backup;

/*
8. Prepare for loss of controlfiles set autobackup on
REASON: This will ensure that you always have an up to date controlfile available that has been taken at the 
end of the current backup not during.
*/
RMAN> configure controlfile autobackup on;

--keep your backup logs
--REASON: The backup log contains parameters for your tape access, locations on controlfile backups that can 
-- be utilised if complete loss occurs.

/*
9. Test your recovery
REASON: During a recovery situation this will let you know how the recovery will go without actually doing it, 
and can avoid having to restore source datafiles again.
*/

SQL> recover database test;


/*

10. Do not specify 'DELETE all input' when backing up archivelogs
REASON: DELETE all input' will backup from one destination then DELETE both copies of the archivelog where as 
'DELETE input' will backup from one location and then DELETE what has been backed up. The next backup will back 
up those from location 2 as well as new logs from location 1, then DELETE all that are backed up. 
This means that you will have the archivelogs since the last backup available on disk in 
location 2 (as well as backed up once) and two copies backup up prior to the previous backup.

*/

************************************************************************************************** 


****************************************  RMAN Commands  **************************************** 

-- print the backup script on screen
print script devracdb_full_bkup;

---- allocate the channel for the maintenance of backup taken on disk device
allocate channel for maintenance type disk;

--- allocates the channel for the deletion of backup on disk storage device
allocate channel for DELETE type disk;

--- release the channel specified for disk / tape stroage
release channel;

-- sync catalog database and target database 
-- this command is very use full for making in sync
resync catalog;

RMAN> list failure; --- show the previous failed statements in rman, but this command is not supported on RAC env.

RMAN> list backupset;

RMAN> list backup of database;

RMAN> list backup of archivelog all;
RMAN> LIST ARCHIVELOG ALL;
RMAN> LIST BACKUP OF ARCHIVELOG ALL;
RMAN> LIST BACKUP;         --- show all backup details
RMAN> LIST BACKUP OF DATABASE;
RMAN> LIST BACKUP OF DATAFILE 1;
RMAN> LIST BACKUP SUMMARY;
RMAN> LIST INCARNATION;
RMAN> LIST BACKUP BY FILE;
RMAN> LIST COPY OF DATABASE ARCHIVELOG ALL;
RMAN> LIST COPY OF DATAFILE 1, 2, 3;
RMAN> LIST BACKUP OF DATAFILE 11 SUMMARY;
RMAN> LIST BACKUP OF ARCHIVELOG FROM SEQUENCE 1437;
RMAN> LIST CONTROLFILECOPY "/tmp/cntrlfile.copy";
RMAN> LIST BACKUPSET OF DATAFILE 1;
RMAN> LIST FAILURE 641231 detail;



--Show items that beed 7 days worth of archivelogs to recover completely
RMAN> REPORT need backup days = 7 database;  

-- Show datafiles that connot currently be recovered
RMAN> REPORT unrecoverable database;
RMAN> REPORT unrecoverable tablespace 'USERS';

RMAN> REPORT OBSOLETE; -- will REPORT all the expaire backup sets

RMAN> REPORT OBSOLETE redundancy = 2;
RMAN> REPORT OBSOLETE recovery window of 7 days; 
RMAN> REPORT OBSOLETE redundancy = 2 device type disk;

RMAN> REPORT unrecoverable; -- REPORT unrecoverable recovery backups

RMAN> REPORT schema; -- show current db files

RMAN> restore database validate; -- check the backup

-- DELETE OBSOLETE will remove backups that are outside your retention policy. If OBSOLETE backups 
-- are not DELETEd, the catalog will continue to grow until performance becomes an issue.

RMAN> DELETE OBSOLETE;

-- As there is no edit command
RMAN> DELETE script full_backup

-- Show/DELETE items not needed for point-in-time recovery within the last week
RMAN> DELETE OBSOLETE recovery window of 7 days;

-- Show/DELETE items with more than 2 newer copies available
RMAN> DELETE OBSOLETE redundancy = 2 device type disk;

RMAN> DELETE expired backup; -- DELETE epired backups found by crosscheck

cmd> target sys/xyzsys@scr10 catalog rman/rman@dbarep

RMAN> DELETE OBSOLETE REDUNDANCY = 1 device type disk; 

RMAN> DELETE OBSOLETE REDUNDANCY = 2 device type disk;

--Crosscheck the available archivelogs (fixes RMAN-06059)

RMAN> change archivelog all crosscheck;

RMAN> change archivelog all validate;

RMAN> crosscheck archivelog all; 

RMAN> DELETE expired archivelog all;

RMAN> DELETE NOPROMPT ARCHIVELOG UNTIL TIME "SYSDATE-5/24" --DELETE archive log older than...

RMAN> CONFIGURE CHANNEL DEVICE TYPE sbt;
RMAN> CROSSCHECK BACKUP OF TABLESPACE user_data COMPLETED BEFORE 'SYSDATE-14'; 
RMAN> DELETE NOPROMPT EXPIRED BACKUP OF TABLESPACE user_data COMPLETED BEFORE 'SYSDATE-14';
RMAN> DELETE BACKUP OF DATABASE LIKE '/tmp%';
RMAN> DELETE ARCHIVELOG ALL BACKED UP 2 TIMES TO DEVICE TYPE sbt;
RMAN> DELETE BACKUPSET 101, 102, 103;
RMAN> DELETE CONTROLFILECOPY '/tmp/cntrlfile.copy';
RMAN> DELETE BACKUP OF SPFILE TABLESPACE users DEVICE TYPE sbt;

-- DELETE backups and copies (and archived redo logs ) that will not be needed to perform any possible recovery of 
-- the database to any point in the last 7 days.
RMAN> DELETE NOPROMPT OBSOLETE RECOVERY WINDOW OF 7 DAYS;


--If you are using the Dbvisit Archive Management Module (AMM) to manage and DELETE the archive log 
--files and using flash recovery area, then you may run into the ORA-19809: limit exceeded for recovery 
--files error. 

--The issue is that eventhough there is sufficient space on the file system, the database thinks that 
--there is no more space available in the flash recovery area.

--To let the database know that there is enough space run the following commands at regular intervals 
--(once a week):

RMAN> connect target

-- marks the controlfile that the archives have been DELETEd
RMAN> crosscheck archivelog all; 

--DELETEs the log entries identified above and synchronises the database repository with the 
--free space on the file system.
RMAN> DELETE expired archivelog all; # 

-- STARTUP <DBA | FORCE | MOUNT | NOMOUNT>
RMAN> STARTUP MOUNT;

-- Upgrade Catalog

-- Upgrade the recovery catalog schema from an older version to the version required by RMAN

-- when you see the below error after connecting to catalog and target database, then you will have to upgrade the catalog.
-- PL/SQL package RCAT.DBMS_RCVCAT version 11.02.00.03 in RCVCAT database is not current
-- PL/SQL package RCAT.DBMS_RCVMAN version 11.02.00.03 in RCVCAT database is not current

RMAN> UPGRADE CATALOG;


--Restore and recover the whole Database:

RMAN> STARTUP FORCE MOUNT;
RMAN> RESTORE DATABASE;
RMAN> RECOVER DATABASE;
RMAN> ALTER DATABASE OPEN;

--Restore and recover a Tablespace:

RMAN> SQL 'ALTER TABLESPACE users OFFLINE';
RMAN> RESTORE TABLESPACE users;
RMAN> RECOVER TABLESPACE users;
RMAN> SQL 'ALTER TABLESPACE users ONLINE';

--Restore and recover a Datafile:

RMAN> SQL 'ALTER DATABASE DATAFILE 64 OFFLINE';
RMAN> RESTORE DATAFILE 64;
RMAN> RECOVER DATAFILE 64;
RMAN> SQL 'ALTER DATABASE DATAFILE 64 ONLINE';


--Restore the Control file, (to all locations specified in the parameter file) then restore the database, using that control file:

STARTUP NOMOUNT;
RUN
{
ALLOCATE CHANNEL c1 DEVICE TYPE sbt;
RESTORE CONTROLFILE;
ALTER DATABASE MOUNT;
RESTORE DATABASE;
}

--Restore Validation confirms that a restore could be run, by confirming that all database files exist and are free of physical 
--and logical corruption, this does not generate any output.
Example:

 RMAN> RESTORE DATABASE VALIDATE;
 
-- Validate

-- Examine a backup set and REPORT whether its data is intact. RMAN scans all of the backup pieces in the 
-- specified backup sets and looks at the checksums to verify that the contents can be successfully restored


************************************************************************************************** 


****************************************  VALIDATE Commands  **************************************** 
-- Validate archivelogs

VALIDATE ARCHIVELOG ALL
VALIDATE ARCHIVELOG LIKE '<string_pattern>'
VALIDATE ARCHIVELOG FROM SCN <integer>
VALIDATE ARCHIVELOG BETWEEN SCN <integer> AND SCN <integer>
VALIDATE ARCHIVELOG UNTIL SCN <integer>
VALIDATE ARCHIVELOG FROM SEQUENCE <integer> [THREAD <integer>]
VALIDATE ARCHIVELOG SEQUENCE <integer> [THREAD <integer>]
VALIDATE ARCHIVELOG SEQUENCE BETWEEN <integer> AND <integer>
VALIDATE ARCHIVELOG UNTIL SEQUENCE <integer> [THREAD <integer>] TIME BETWEEN '<date_string>' AND '<date_string>' UNTIL TIME '<date_string>'


-- Backupset
VALIDATE BACKUPSET <primaryKey>

-- Validate all control files copies

VALIDATE CONTROLFILECOPY ALL
VALIDATE CONTROLFILECOPY '<file_name>'
VALIDATE CONTROLFILECOPY LIKE '<string_pattern>'

-- Validate the current control file
VALIDATE CURRENT CONTROLFILE;


-- Validate all database, datafile, or tablespace copies

VALIDATE COPY OF DATABASE
VALIDATE COPY OF DATAFILE '<file_name>'
VALIDATE COPY OF DATAFILE <file_number>
VALIDATE COPY OF TABLESPACE '<tablespace_name>'

for e.g RMAN> VALIDATE COPY OF TABLESPACE 'TRANS_DATA';


**************************************************************************************************


-- for checking, which database is rigister in RMAN rcat DB
SELECT  DISTINCT rsc.db_name,rscl.script_name,rscl.text,rscl.line
FROM rc_stored_script rsc, rc_stored_script_line rscl
WHERE rsc.db_key=rscl.DB_KEY
ORDER BY rsc.db_name ,rscl.script_name,line


****************************************  Tablespace backups  **************************************** 

-- if you want to recover any tablespace the script will be 
run 
{
     allocate auxiliary channel dev1 type disk;
     recover tablespace tbs_2, tbs_3 until time 'Jan 10 1999 20:00:00'; 
}


or 

-- A subset of the database can be restored in a similar fashion:

run 
{
    sql 'ALTER TABLESPACE users OFFLINE IMMEDIATE';
    restore tablespace users;
    recover tablespace users;
    sql 'ALTER TABLESPACE users ONLINE'; 
}

/*
    The biggest advantage of RMAN is that it only backup used space in the database. 
    RMAN doesnot put tablespaces in backup mode, saving on redo generation overhead. RMAN will re-read database blocks until it gets a 
    consistent image of it. Look at this simple backup example. 
*/

rman target sys/change_on_install nocatalog 
	
run 
{ 
    allocate channel t1 type disk;
    backup 
       format '/app/oracle/db_backup/%d_t%t_s%s_p%p'
       ( database ); 
    release channel t1; 
}

-- Example RMAN restore: 

rman target sys/change_on_install nocatalog 

run 
{
    allocate channel t1 type disk;
    # set until time 'Aug 07 2000 :51';
    restore tablespace users; 
    recover tablespace users; 
    release channel t1; 
}


-- Recover Until given time

run{
	 SET UNTIL TIME "to_date('02/20/2009 23:59:59','mm/dd/yyyy hh24:mi:ss')"; 
	 restore database; 
	 recover database;
}

**************************************************************************************************

****************************************  Allocating Channels  **************************************** 

--Allocating a Single Channel for a Backup

--This command allocates a tape channel for a whole database backup: 
run {
     allocate channel dev1 type 'sbt_tape';
     backup database;
    
}

/*
    Spreading a Backup Set Across Multiple Channels
    When backing up to disk, you can spread your backup across several disk drives. 
    Allocate one type disk channel per disk drive and specify the format string so 
    that the filenames are on different disks:

    If do not want to spread backup files on different disk then do not 
    allocate channel on different disk.(Allocate channel for only one disk)
*/

run{ 
     allocate channel disk1 type disk format '/disk1/%d_backups/%U'; 
     allocate channel disk2 type disk format '/disk2/%d_backups/%U'; 
     allocate channel disk3 type disk format '/disk3/%d_backups/%U';
     backup database; 
} 

/*
    Duplexing a Backup Set

     When duplexing backup sets, specify the set duplex command (see "set_run_option")
     before allocating a channel. The following example generates four identical backups 
     of datafile 1: 
*/

run {
     set duplex = 4;
     allocate channel dev1 type 'sbt_tape';
     backup datafile 1;
}

/*
    Allocating an Auxiliary Channel
        When creating a duplicate database (see "duplicate"), allocate a channel using 
        the auxiliary option: 
*/

run { 
     allocate auxiliary channel c1 type disk; 
     allocate auxiliary channel c2 type disk; 
     duplicate target database to ndbnewh 
       logfile 
         '/oracle/dbs/log_1.f' size 200K, 
         '/oracle/dbs/log_2.f' size 200K 
     skip readonly 
     nofilenamecheck; 
}

---***********************---***********************---***********************
Note: RMAN cannot write image copies directly to tape. One needs to use a 
third-party media manager that integrates with RMAN to backup directly to 
tape. Alternatively one can backup to disk and then manually copy the backups 
to tape. 
---***********************---***********************---***********************

**************************************************************************************************


****************************************  Archive log DELETE  **************************************** 

/*
    One can backup archived log files using RMAN or any operating system 
    backup utility. Remember to DELETE files after backing them up to prevent 
    the archive log directory from filling up. If the archive log directory 
    becomes full, your database will hang! Look at this simple RMAN backup 
    script: 
*/

run 
{
	allocate channel dev1 type disk;
	backup
	  format '/app/oracle/arch_backup/log_t%t_s%s_p%p'
	  (archivelog all DELETE input);
	release channel dev1;
}

**************************************************************************************************


****************************************  Restoring Full database  **************************************** 

create catalog database with the file 

--d:\Rahulc\Scripts\backup and Recovery\RMAN recovery Catalog.sql

run 
{ 
    startup mount pfile=c:\Oracle\Admin\TSH1\pfile\init.ora;
    allocate channel ch1 type disk;
    restore database;
    recover database;
    release channel ch1;
}

/*
    This will result in all datafiles being restored then recovered. RMAN will 
    apply archive logs as necessary until the recovery is complete.

    Once this process us complete the database can be opened using the alter database open 
*/

ALTER DATABASE OPEN; 

**************************************************************************************************



****************************************  RMAN recovery from loss of all online redo log files  **************************************** 

If you had backup full database

/*
    To avoid such scenarios, we should be multiplexing the online redo log files. 
    Each group should have at least 2 members and each member should be located on a different physical disk.

    Loss of a single current online redo log file will require us to restore the entire database and
    do an incomplete recovery.

    We can simulate this scenario by deleting all the online redo log files at the OS level.
*/
SQL> select member from v$Logfile;

opsdba>rm redo*.log

--If the current online redo log file is lost,the database hangs and in the alert log file

we can see the following error message:

Tue Jan 30 00:47:19 2007
ARC1: Failed to archive thread 1 sequence 93 (0)
Tue Jan 30 00:47:24 2007
Errors in file /opt/oracle/admin/opsdba/bdump/opsdba_arc0_32722.trc:
ORA-00313: open failed for members of log group 2 of thread 1
ORA-00312: online log 2 thread 1: '/u02/ORACLE/opsdba/redo02.log'
ORA-27037: unable to obtain file status
Linux-x86_64 Error: 2: No such file or directory

-- Using RMAN we can recover from this error by restoring the database from the backup and recovering to the last available archived redo logfile.

-- From the alert log we can obtain the last archived file in our case it is sequence 92 as the error shows that it fails to archive the log file sequence 93.

SQL> select * from v$Log;

    GROUP#    THREAD#  SEQUENCE#      BYTES    MEMBERS ARC STATUS           FIRST_CHANGE# FIRST_TIM
---------- ---------- ---------- ---------- ---------- --- ---------------- ------------- ---------
         1          1         95   52428800          1 NO  CURRENT                3203078 30-JAN-07
         2          1         93   52428800          1 NO  INACTIVE               3202983 30-JAN-07
         3          1         94   52428800          1 NO  INACTIVE               3203074 30-JAN-07

SQL> archive log list
Database log mode              Archive Mode
Automatic archival             Enabled
Archive destination            /u02/ORACLE/opsdba/arch
Oldest online log sequence     92
Next log sequence to archive   93
Current log sequence           93

opsdba: cd /u02/ORACLE/opsdba/arc

opsdba:/u02/ORACLE/opsdba/arch> ls �lrt

total 54824
-rw-r-----    1 oracle   dba        714240 Jan 29 16:02 arch_1_90_613129285.dbf
-rw-r-----    1 oracle   dba      46281216 Jan 30 00:37 arch_1_91_613129285.dbf
-rw-r-----    1 oracle   dba         11264 Jan 30 00:41 arch_1_92_613129285.dbf

-- Shutdown the database

SQL> shutdown immediate;

-- Mount the database

SQL> startup mount;

-- Use RMAN connect to the target database:

rman target /

RMAN> run 
		{
			set until sequence 93; (Note: set this number to one higher than the last archived log available)
			restore database;
			recover database;
			 alter database open resetlogs;
		};

RMAN>exit

-- The recovery process creates the online redo logfiles at the operating system level also.

opsdba>ls -lrt redo*
-rw-r-----    1 oracle   dba      52429312 Jan 30 01:00 redo03.log
-rw-r-----    1 oracle   dba      52429312 Jan 30 01:00 redo02.log
-rw-r-----    1 oracle   dba      52429312 Jan 30 01:00 redo01.log

-- Since we have done an incomplete recover with open resetlogs, we should take a fresh complete backup of the database.

**************************************************************************************************



****************************************  Duplicate Database Data Files  **************************************** 

Setting New Filenames Manually

/*
    This example assumes that your target database is on HOST1 and you wish to duplicate your database to NEWDB on host2 with the file structure /oracle/dbs. 
    Because the filenames in HOST1 are irregularly named and located in various sub-directories, you use set newname commands to re-name the files consistently. 
    The duplicate command uses backup sets stored on tape to duplicate the target database to database NEWDB: 
    
*/

       c:\ connect target;
       
       c:\ connect catalog rman/rman@rmancat;
       
       c:\ connect auxiliary sys/change_on_install@newdb;
       
        run 
        {  
                allocate auxiliary channel newdb1 type 'sbt_tape'; 
                allocate auxiliary channel newdb2 type 'sbt_tape'; 
                allocate auxiliary channel newdb3 type 'sbt_tape'; 
                allocate auxiliary channel newdb4 type 'sbt_tape'; 
                set newname for datafile 1 TO '$ORACLE_HOME/dbs/newdb_data_01.f'; 
                set newname for datafile 2 TO '$ORACLE_HOME/dbs/newdb_data_02.f'; 
                set newname for datafile 3 TO '$ORACLE_HOME/dbs/newdb_data_11.f'; 
                set newname for datafile 4 TO '$ORACLE_HOME/dbs/newdb_data_12.f'; 
                set newname for datafile 5 TO '$ORACLE_HOME/dbs/newdb_data_21.f'; 
                set newname for datafile 6 TO '$ORACLE_HOME/dbs/newdb_data_22.f'; 
                duplicate target database to newdb logfile
                  group 1 ('$ORACLE_HOME/dbs/newdb_log_1_1.f', 
                           '$ORACLE_HOME/dbs/newdb_log_1_2.f') size 200K, 
                  group 2 ('$ORACLE_HOME/dbs/newdb_log_2_1.f', 
                           '$ORACLE_HOME/dbs/newdb_log_2_2.f') size 200K reuse; 
        }

-- Reusing the Target Filenames
/*
This example assumes that you are restoring to a new host and that: 

   * The target host and duplicate host have the same file structure. 
   * You wish to name the duplicate files exactly like the target database files. 
   * You are not using a recovery catalog.     
   * You do not want to duplicate read-only tablespaces.     
   * You want to prevent RMAN from checking whether files on the target database that 
     have the same names as the duplicated files are in use. 
*/
c:\ connect target
  
c:\ connect auxiliary sys/aux_pwd@newdb

run 
{ 
     allocate auxiliary channel ndbnewh1 type disk; 
     allocate auxiliary channel ndbnewh2 type disk; 
     duplicate target database to ndbnewh 
     logfile 
       '$ORACLE_HOME/dbs/log_1.f' size 200K, 
       '$ORACLE_HOME/dbs/log_2.f' size 200K 
     skip readonly 
     nofilenamecheck; 
}

--- same as above
connect target;
connect catalog rman/rman@rmancat;
connect auxiliary sys/change_on_install@dupssk;
create script dup_ssk
{  
    allocate auxiliary channel dupssk type 'disk'; 
    allocate auxiliary channel dupssk type 'disk'; 
    set newname for datafile 1 TO 'D:\ORACLE\ORADATA\SSK\SYSTEM01.DBF'; 
    set newname for datafile 2 TO 'D:\ORACLE\ORADATA\SSK\RBS01.DBF'; 
    set newname for datafile 3 TO 'D:\ORACLE\ORADATA\SSK\USERS01.DBF'; 
    set newname for datafile 4 TO 'D:\ORACLE\ORADATA\SSK\TEMP01.DBF'; 
    set newname for datafile 5 TO 'D:\ORACLE\ORADATA\SSK\TOOLS01.DBF'; 
    set newname for datafile 6 TO 'D:\ORACLE\ORADATA\SSK\INDX01.DBF'; 
    set newname for datafile 7 TO 'D:\ORACLE\ORADATA\SSK\USERDATA01.DBF'; 
    set newname for datafile 8 TO 'D:\ORACLE\ORADATA\SSK\SSK_DATA.DBF'; 
    set newname for datafile 9 TO 'D:\ORACLE\ORADATA\SSK\HBANK_DATA.DBF'; 
    set newname for datafile 10 TO 'G:\ORADATA\SSK\USERS02.DBF'; 
    set newname for datafile 11 TO 'G:\ORADATA\SSK\SNOX_DATA01.DBF'; 
    set newname for datafile 12 TO 'D:\ORACLE\ORADATA\TEST_ENCRYPTION\TEST_ENCRYPTIION01.DBF'; 
    set newname for datafile 13 TO 'D:\ORACLE\ORADATA\TEST_ENCRYPTION\TEST_ENCRYPTIION02.DBF'; 
    set newname for datafile 14 TO 'G:\ORADATA\RBS_ENCRYPT\RBS_ENCRYPT.DBF'; 
    duplicate target database to dupssk logfile
      group 4 ('D:\ORACLE\ORADATA\SSK\REDO04A.LOG', 
               'D:\ORACLE\ORADATA\SSK\REDO04B.LOG') size 200K reuse, 
      group 5 ('D:\ORACLE\ORADATA\SSK\REDO05A.LOG', 
               'D:\ORACLE\ORADATA\SSK\REDO05B.LOG') size 200K reuse,
      group 6 ('D:\ORACLE\ORADATA\SSK\REDO06A.LOG', 
               'D:\ORACLE\ORADATA\SSK\REDO06B.LOG') size 200K reuse; 
}               
#   skip readonly;
   nofilenamecheck;
}


**************************************************************************************************


****************************************  Auxiliary Instance  **************************************** 

/*
    The auxiliary instance must be accessible via Net8. Before proceeding, use SQL*Plus to 
    ensure that you can establish a connection to the auxiliary instance. Note that you must 
    connect to the auxiliary instance with SYSDBA privileges, so a password file must exist. 

    Use RMAN to connect to the target database, the duplicate database, and (if you use one) the recovery
    catalog database. In this example, connection is established without a recovery catalog using operating 
    system authentication: 
*/

$rman target / auxiliary sys/sys_pwd@dupdb 


--In this example, user SCOTT has SYSDBA privileges and a net service name is used for the target: 
$rman auxiliary scott/tiger@dupdb target sys/sys_pwd@prod 

-- In this example, connection is established to three databases, all using net service names: 
$rman catalog rman/rman@rcat target sys/sys_pwd@prod1 auxiliary scott/tiger@dupdb 

--Perform the following operations: 
1) Allocate at least one auxiliary channel. 
2) Specify the nofilenamecheck parameter. 

--For example, enter the following: 

run 
{ 
    allocate auxiliary channel ch1 type 'sbt_tape'; 
    duplicate target database to dupdb 
    nofilenamecheck; 
} 


-- RMAN uses all incremental backups, archived redo log backups, and archived redo logs to perform incomplete recovery and then opens the database 
--with the RESETLOGS option to create the online redo logs. 


****************************************************************************************************** 


****************************************  Resynchronizing the Recovery Catalog  **************************************** 

Resynchronizing the Recovery Catalog in ARCHIVELOG Mode: Example
This example performs a full resynchronization after archiving all unarchived redo logs:

SQL "ALTER SYSTEM ARCHIVE LOG ALL";
RESYNC CATALOG;

--Resynchronizing the Recovery Catalog After a Structural Change. Below E.g.. adds a datafile to tablespace users and then resynchronizes the catalog

-- connect in nocatalog mode and add datafile using one script
rman TARGET / NOCATALOG <<EOF
SQL "ALTER TABLESPACE users ADD DATAFILE ''?/oradata/trgt/users03.dbf'' 
     SIZE 1M AUTOEXTEND ON NEXT 10K MAXSIZE 10M";
EXIT
EOF

-- connect in catalog mode and resynchronize
rman TARGET / CATAOG rman/rman@catdb <<EOF
RESYNC CATALOG;
EOF
************************************************************************************************************************


**************************************** Restoring the Control File ****************************************
-- Restoring the Control File When Using a Recovery Catalog: 

E.g.

-- This will restores the control file to its default location, replicates it automatically to all CONTROL_FILES locations, and mounts the database:

RUN
{ # SET DBID is not necessary when connected to a recovery catalog
  STARTUP FORCE NOMOUNT;
  RESTORE CONTROLFILE;
  ALTER DATABASE MOUNT;
}
************************************************************************************************************************


**************************************** Restoring the Control File ****************************************

Restoring the Database with a Backup Control File: Example
This example restores the control file, replicates it to all control file locations specified in the parameter file, and then restores and recovers the database:

CONNECT TARGET /
STARTUP NOMOUNT;
SET DBID 320066378;  # required when restoring control file in NOCATALOG mode
RUN
{
  ALLOCATE CHANNEL c1 DEVICE TYPE sbt;
  RESTORE CONTROLFILE TO '/tmp/control01.ctl' FROM AUTOBACKUP;
  RESTORE CONTROLFILE FROM '/tmp/control01.ctl'; # restores to all CONTROL_FILES locations
  ALTER DATABASE MOUNT;
  RESTORE DATABASE;
  RECOVER DATABASE;
}
ALTER DATABASE OPEN RESETLOGS;
# if the database uses locally-managed temporary tablespaces, then add new tempfiles
# to these tablespaces after the RESETLOGS
SQL "ALTER TABLESPACE temp ADD TEMPFILE ''?/oradata/trgt/temp01.dbf'' REUSE";

Restoring Archived Redo Logs to a New Location: Example
This example restores all archived redo logs to the /oracle/temp_restore directory:

RUN
{ 
  SET ARCHIVELOG DESTINATION TO '/tmp';
  RESTORE ARCHIVELOG ALL;
}

Restoring a Control File Autobackup to a Nondefault Location: Example
This example restores the latest control file autobackup made on or before June 23, 2000 with a nondefault format of PROD_CF_AUTOBACKUP_%F. It starts searching for backups with a sequence number of 20, and searches backward for 5 months:

SET DBID 320066378;  # required when restoring control file in NOCATALOG mode
RUN
{
  SET UNTIL TIME '23-JUN-2001 00:00:00';
  SET CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE sbt TO 'prod_cf_autobackup_%F';
  ALLOCATE CHANNEL CHANNEL_1 DEVICE TYPE sbt;
  RESTORE CONTROLFILE TO '/tmp/autobackup_20001002.dbf' FROM AUTOBACKUP 
    MAXSEQ 20 MAXDAYS 150;
}

Restoring the Server Parameter File to Current Location: Example
The following shell script restores the current server parameter file in NOCATALOG mode:

#!/usr/bin/tcsh
rman TARGET / <<EOF
SET DBID 1447326980 # set dbid to dbid of target database
STARTUP FORCE NOMOUNT; # start instance with dummy SPFILE
RUN
{
  ALLOCATE CHANNEL c1 DEVICE TYPE sbt;
  RESTORE SPFILE FROM AUTOBACKUP; # FROM AUTOBACKUP needed in NOCATALOG mode
}
STARTUP FORCE; # start with restored SPFILE and open database
EXIT
EOF

Restoring the Server Parameter File to a Nondefault Location: Example
The following shell script restores a server parameter file that was backed up at least a month ago and restarts the database with the restored parameter file:

#!/usr/bin/tcsh
echo "SPFILE=/tmp/spfileTEMP.ora" > /tmp/initTEMP.ora
rman TARGET / <<EOF
STARTUP FORCE MOUNT; # make sure database is mounted so SET DBID not required
RESTORE SPFILE TO '/tmp/spfileTEMP.ora' UNTIL 'SYSDATE-31';
STARTUP FORCE PFILE=/tmp/initTEMP.ora; # start with restored SPFILE and open database
EXIT
EOF

************************************************************************************************************************

 
**************************************** Restoring the Control File ****************************************

-- for RESET DATABASE in RMAN

-- Reset the catalog after a restlogs on the target

--Restrictions and Usage Notes

-- 1) Execute RESET DATABASE only at the RMAN prompt.
-- 2) You must be connected to the target database.
-- 3) A recovery catalog connection is optional. Unlike in catalog mode, RESET DATABASE in nocatalog mode 
--	  changes the incarnation only for the current RMAN session.
-- 4) You must issue a RESET DATABASE command before you can use RMAN with a target database that has been 
--	  opened with the SQL statement ALTER DATABASE OPEN RESETLOGS option. If you do not, then RMAN refuses to 
--	  access the recovery catalog because it cannot distinguish between a RESETLOGS operation and an accidental 
--	  restore of an old control file. The RESET DATABASE command informs RMAN that you issued a RESETLOGS command.
-- 5) If RMAN is connected NOCATALOG, then you can only specify TO INCARNATION if the database is mounted and 
--	  the control file contains a record of the prior incarnation. If you do not run RESET DATABASE, RMAN 
--	  recovers to the last incarnation recorded in the control file.
-- 6) If RMAN is connected in CATALOG mode, then you can specify TO INCARNATION when the database is mounted. 
--	  If database is mounted, however, then the control file must have a record of the prior incarnation.



--Examples for Incarnation in NOCATALOG

--Resetting RMAN to a Previous Incarnation in NOCATALOG Mode: Example

--In NOCATALOG mode, you must mount a control file that knows about the incarnation that you want to recover. 
--The following scenario makes an old incarnation of database trgt current again:

CONNECT TARGET / NOCATALOG


--Step 1: start and mount a control file that knows about the incarnation to which you want to return. if the current control file does not know about it, then
-- you must restore an older control file


STARTUP NOMOUNT;
RESTORE CONTROLFILE UNTIL TIME 'SYSDATE-250';
ALTER DATABASE MOUNT;

--step 2: obtain the primary key of old incarnation
LIST INCARNATION OF DATABASE trgt;

--List of Database Incarnations
DB Key  Inc Key DB Name  DB ID            STATUS   Reset SCN  Reset Time
------- ------- -------- -------------    -------  ---------- ----------
1       2       TRGT     1334358386       PARENT   154381     OCT 30 2001 16:02:12
1       116     TRGT     1334358386       CURRENT  154877     OCT 30 2001 16:37:39

-- step 3: in this example, reset database to incarnation key 2
RESET DATABASE TO INCARNATION 2;

-- step 4: restore and recover the database to a point before the RESETLOGS
RESTORE DATABASE UNTIL SCN 154876;
RECOVER DATABASE UNTIL SCN 154876;

-- step 5: make this incarnation the current incarnation and then list incarnations:
ALTER DATABASE OPEN RESETLOGS;
LIST INCARNATION OF DATABASE trgt;

--List of Database Incarnations
DB Key  Inc Key DB Name  DB ID            STATUS  Reset SCN  Reset Time
------- ------- -------- ---------------- ------- ---------- ----------
1       2       TRGT     1334358386       PARENT  154381     OCT 30 2001 16:02:12
1       116     TRGT     1334358386       PARENT  154877     OCT 30 2001 16:37:39
1       311     TRGT     1334358386       CURRENT 154877     AUG 13 2002 17:17:03

--Resetting the Database After Incomplete Recovery: Example

-- This example assumes that an incomplete recovery or recovery with a backup control file was performed in NOCATALOG mode. Later, RMAN is 
-- started in CATALOG mode, but the RESYNC command fails because the incarnation has not been reset in the catalog.

Oracle:> rman target / catalog rman/rman@catdb

RMAN> RESYNC CATALOG;

RMAN-00571: ===========================================================
RMAN-00569: =============== ERROR MESSAGE STACK FOLLOWS ===============
RMAN-00571: ===========================================================
RMAN-03009: failure of resync command on default channel at 11/01/2001 12:00:43
RMAN-20003: target database incarnation not found in recovery catalog

RMAN> RESET DATABASE;

-- new incarnation of database registered in recovery catalog starting full resync of recovery catalog full resync complete

*/

RMAN>reset database;


************************************************************************************************************************

**************************************** Incremental Backups Theory ****************************************

-- Incremental Backups Revisited

/*
    RMAN includes an option for incremental backups. But truthfully, how often do you use it? Probably occasionally, 
    or possibly even never.

    This option instructs the tool to back up blocks that have changed since the last incremental backup at the same 
    level or below. For instance, a full backup (level_0) is taken on day 1 and two incrementals of level_1 are taken
    on days 2 and 3. The latter two merely back up the changed blocks between days 1 and 2 and days 2 and 3, not across 
    the entire backup time. This strategy reduces backup size, requiring less space, and narrows the backup window, 
    reducing the amount of data moving across the network.

    The most important reason for doing incremental backups is associated with data warehouse environments, where many 
    operations are done in NOLOGGING mode and data changes do not go to the archived log files�hence, no media recovery 
    is possible. Considering the massive size of data warehouses today, and the fact that most of the data in them does 
    not change, full backups are neither desirable nor practical. Rather, doing incremental backups in RMAN is an ideal 
    alternative.

    So why do many DBAs do incremental backups only rarely? One reason is that in Oracle9i and below, RMAN scans all
    the data blocks to identify candidates for backup. This process puts so much stress on the system that doing 
    incrementals becomes impractical.

    Oracle Database 10g RMAN implements incremental backups in a manner that disposes of that objection. It uses a 
    file, analogous to journals in filesystems, to track the blocks that have changed since the last backup. RMAN reads 
    this file to determine which blocks are to be backed up.

    You can enable this tracking mechanism by issuing the following command:
*/
SQL> alter database enable block change tracking using file '/rman_bkups/change.log';

--This command creates a binary file called /rman_bkups/change.log for tracking purposes. Conversely, you can disable tracking with

SQL> alter database disable block change tracking;

-- To see whether change tracking is currently enabled, you can query:

SQL> select filename, status from v$block_change_tracking;


RMAN>backup incremental level 1 for recover of copy tag 0 database;

Incremental Merge

Lets say you have the following backup schedule:

Sunday - Level 0 (full), with tag level_0
Monday - Level 1 (incremental) with tag level_1_mon
Tuesday - Level 1 (incremental) with tag level_1_tue

/*
    and so on. If the database fails on Saturday, prior to 10g you would have had to restore the tag level_0 and then 
    apply all six incrementals. It would have taken a long time, which is another reason many DBAs shun incremental 
    backups.

    Oracle Database 10g RMAN radically changes that equation. Now, your incremental backup command looks like this:
*/
RMAN> backup incremental level_1 for recover of copy with tag level_0 database;

/*
    Here we have instructed RMAN to make an incremental level_1 backup and merge that with the full backup copy with 
    the tag level_0. After this command, level_0 becomes a full backup of that day.

    So, on Tuesday, the backup with tag level_0, when merged with incremental level_1 backup, becomes identical to the 
    full Tuesday backup. Similarly, the incremental taken on Saturday, when applied to the backup on disk, will be
    equivalent to a full level_0 Saturday backup. If the database fails on Saturday, you just need to restore the 
    level_0 backup plus a few archive logs to bring the database into a consistent state; there is no need to apply 
    additional incrementals. This approach cuts down recovery time dramatically, speeds backup, and eliminates the need 
    to make a full database backup again.
*/

************************************************************************************************************************



**************************************** Where/Why is RMAN spending/taking time ****************************************

-- You can see where RMAN is spending its time by enabling debug mode as such:

run 
{
    debug on;
    restore archivelog .....;
}s

************************************************************************************************************************


**************************************** Cloning Database ****************************************

Primnary Database:guard ----------datafile and redo log path =/oracle/oradata/guard/
auxiliary DB(clone DB)=narendra---------datafile and redo log path=/oracle/oradata/narendra/ 



CONFIGURE CONTROLFILE AUTOBACKUP ON;
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '/home/oracle/rman/%F';

rman target sys/admin@guard13

run 
{ 
	allocate channel d1 type disk;
	backup format '/ora2/oracle/oradev_rman/df_t%t_s%s_p%p' database;
	backup format '/ora2/oracle/oradev_rman/al_t%t_s%s_p%p' archivelog all;
	release channel d1;
}

rman target sys/admin@guard13 auxiliary /

export ORACLE_SID=guard

rman target sys/sysdev@DEV10 auxiliary / log=/ora2/oracle/oradata/guard/guard/rman_guard.log
/ora2/oracle/admin/guard/pfile/INITGUARD.ORA

LOG_FILE_NAME_CONVERT= '/ora2/oracle/oradata/dev/','/ora2/oracle/oradata/guard/guard/'


run
{
	set newname for datafile 1 to '/ora2/oracle/oradata/guard/guard/system01.dbf';
	set newname for datafile 2 to '/ora2/oracle/oradata/guard/guard/undotbs01.dbf';
	set newname for datafile 3 to '/ora2/oracle/oradata/guard/guard/sysaux01.dbf';
	set newname for datafile 4 to '/ora2/oracle/oradata/guard/guard/users01.dbf';
	set newname for datafile '/ora2/oracle/oradata/dev/streams_tbs01.dbf' to '/ora2/oracle/oradata/guard/guard/streams_tbs01.dbf';
	set newname for datafile '/ora1/oracle/oradata/streams_tbs02.dbf' to '/ora2/oracle/oradata/guard/guard/streams_tbs02.dbf';
	set newname for tempfile 1  to '/ora2/oracle/oradata/guard/guard/temp01.dbf';
	allocate channel C1 device type disk;
	allocate auxiliary channel C2 device type disk;
	duplicate target database for standby dorecover;
}

run
{
set newname for datafile 1 to '/ora2/oracle/oradata/guard/guard/system01.dbf';
set newname for datafile 2 to '/ora2/oracle/oradata/guard/guard/undotbs01.dbf';
set newname for datafile 3 to '/ora2/oracle/oradata/guard/guard/sysaux01.dbf';
set newname for datafile 4 to '/ora2/oracle/oradata/guard/guard/users01.dbf';
set newname for datafile '/ora2/oracle/oradata/dev/streams_tbs01.dbf' to '/ora2/oracle/oradata/guard/guard/streams_tbs01.dbf';
set newname for datafile '/ora1/oracle/oradata/streams_tbs02.dbf' to '/ora2/oracle/oradata/guard/guard/streams_tbs02.dbf';
set newname for tempfile 1  to '/ora2/oracle/oradata/guard/guard/temp01.dbf';
duplicate target database to guard logfile
group 1 ('/ora2/oracle/oradata/guard/guard/redo01.log') size 50m reuse,
group 2 ('/ora2/oracle/oradata/guard/guard/redo02.log') size 50m reuse,
group 3 ('/ora2/oracle/oradata/guard/guard/redo03.log') size 50m reuse;
}

group 1 ('/oracle/oradata/narendra/redo01.log'size)  size 10m reuse,
group 2 ('/u01/app/oracle/testdata/logs/redo02a.log',
	     '/u01/app/oracle/testdata/logs/redo02b.log') size 10m reuse;



----------------Recovering datafile 

run{
	sql "alter database datafile 4 offline";
	set newname for datafile '/oracle/oradata/guard/users01.dbf' to '/oracle/oradata/guard/users01.dbf';
	restore datafile 4;
	switch datafile all; # Updates repository with new datafile location.
	recover datafile 4, 5;
	sql "alter database datafile 4 online";
}

--------------------------------Backup Script---------
rman target /
run {
	ALLOCATE CHANNEL C1 TYPE DISK;
	SQL 'ALTER SYSTEM ARCHIVE LOG CURRENT';
	BACKUP INCREMENTAL LEVEL=0 CUMULATIVE TAG WEEKLY_LEVEL0 format '/backup/level0' DATABASE;
	BACKUP ARCHIVELOG ALL format '/backup/archivelogs';
	BACKUP CURRENT CONTROLFILE TAG WEEKLY_CTL_PRI format '/backup/control_primary';
	BACKUP CURRENT CONTROLFILE FOR STANDBY TAG WEEKLY_CTL_STD format '/backup/control_standby';
	BACKUP SPFILE format '/backup/spfile.ora';
}
-------------------------------
run
{
	allocate channel ch1 type disk;
	backup incremental level 0 as backupset tag=full_backup (database);
	sql 'alter system archive log current';
	release channel ch1;
	allocate channel ch1 type disk;
	backup archivelog all tag=archives_backup
	DELETE all input;
	release channel ch1;

}
-------------------
resync catalog;
change archivelog all validate;
run{
allocate channel c1 type 'SBT_TAPE';
allocate channel c2 type 'SBT_TAPE';
backup
  format '/intr/cf_t%t_s%s_p%p'
  (current controlfile);
backup
  incremental level 0
  tag db_intr_0
  filesperset 5
  format '/intr/df_t%t_s%s_p%p'
  (database);
sql 'alter system archive log current';
backup
  filesperset 20
  format '/intr/rl_t%t_s%s_p%p'
  (archivelog all DELETE input);
release channel c1;
release channel c2;
} 

-------------Backup Script

RUN
{
  ALLOCATE CHANNEL d1 guardICE TYPE disk;
  ALLOCATE CHANNEL d2 guardICE TYPE disk;
  ALLOCATE CHANNEL d3 guardICE TYPE disk;
  BACKUP
  INCREMENTAL LEVEL = 0
  FORMAT = '/u01/rpprod1/backup/df_%d_%s_%p.bak';
  (DATAFILE 1, 4, 5 CHANNEL d1 tag=df1)
  (DATAFILE 2, 3, 6 CHANNEL d2 tag=df2)
  (DATAFILE 7, 8, 9 CHANNEL d3 tag=df3);
   sql 'alter system archive log current';
} 

************************************************************************************************************************

 sql "create pfile=/devdb_rmanbkups/rman_bkup/devracdb_init.ora from spfile=/devdb_rmanbkups/rman_bkup/devracdb_spfile.ora";


 

---------------------------------------------------
* It is better to use target database for running the script as it use the same amount of time either you run 
the script from archive - source (Catalog DB) DB or target DB for which you are taking backups.

* The one big difference will be Oracle user_id might be different on both the servers for oracle user and which will be affecting for the primmissions.

* Incremental Level 1 backup will be slow as it will be backing up only modified blocks

************************************************************************************************************************
-- Restoring the backup steps...


-- if there is are multiple DB's on the server
export ORACLE_SID=devracdb

Oracle>rman target /

RMAN> shutdown -- if the DB is already created/present on backup server
RMAN> startup nomount;
RMAN> restore spfile to '$ORACLE_HOME/dbs/initMEPC.ora' from autobackup db_recovery_file_dest='/mepc_backup/May22fullbkp' db_name='MEPC';


************************************************************************************************************************


-- CROSSCHECK ARCHIVELOG;
---------------------------------------

-- TransIT production db
-- execute it when /archivelogs disk is 75% full
DELETE NOPROMPT ARCHIVELOG UNTIL TIME "SYSDATE-5";



00 21 * * 5 /home/oracle/cronjobs/del_archlogs.sh > /home/oracle/cronjobs/cronjob_del_archlogs.log








-- devdb/qadb full backups

1) Backup format
/backups
	-- qadb
	    -- qadb_datewise (Formate of Date DDMONYEAR)
	        --->(7 days will backups be present, More then 7 days backup will be deleted through RMAN)
	-- devdb
	    -- devdb_datewise (Formate of Date DDMONYEAR)
	        --->(7 days will be present, More then 7 days backup will be deleted through RMAN)
	        
2) Restore 
    for first 3 months we will be restoring each Monday backup to check successful backups. After 3 Months if every thing works fine then we can have meeting to discuss about restoring the backups monthly/quarterly/yearly
    

backup storage option is NFS Mount point on target databases as discussion.



-- Production Backups
1)
/backups
	-- gca_leagcy --qcpw
	    -- rman_bkups_gca_xtns_25oct2013.bkp (7 days will be present, More then 7 days backup will be deleted)
	-- gca_transit -- gca
	   -- devdb_datewise (Formate of Date DDMONYEAR)
	       --->(7 days will be present, More then 7 days backup will be deleted)

 above backups will be created on Monday Full Backup and Tuesday till Sunday with Incremental 

( Databases --> Gca_reporting, CPass_Transit, Payfuse, Transending, etc...)

2) How to take backups
Sunday Incremental = 0 (Full Backup)
Monday - Saturday Incremental = 1 (Full Backup)

On Production we will not automate the RMAN backup, we will be running it manually for 7 days (Full backups and Incremental Backups) if there are no issues in then backups then we can make it automate.

This will be implemented on central RMAN Catalog in each DC (For Production DBs)... 


3) Restoring Backup
We can test with small production DB like Payfuse or MapDBs (Small Backups size DB). Full + Incremental backups will be restored on Monday for first 3 months... will discussed abfter 3 months for restoring points

4) How Many Backups on Production
To start with we can keep 1 month of backup as per Disk Space availability..


currently we are not considering tablespace wise backups...


we are taking RMAN HOT backups and will not required downtime on dev/qa/production database servers....









---- devracdb backup scripts

#!/bin/sh
#export ORACLE_SID=devracdb2
#export ORACLE_HOME=/opt/app/oracle/product/11.2.0/db_1

bkup_date=`date +%d%b%Y`
echo $bkup_date
bkup_dir=/backups/devracdb/rman_bkups/devdbnode2_rmanbkup_$bkup_date

#create the backup date folder
mkdir -p $bkup_dir

rmambkup_logs=/backups/devracdb/logs/devdbnode2_rmanbkup_$bkup_date.log

rman catalog rman/rman_201@arccatdb log=$rmambkup_logs<< EOF
connect target rman/rman@devracdb;
run
{
   ALLOCATE CHANNEL c1 device type disk;
   BACKUP DATABASE FORMAT '$bkup_dir/devracdb_%u_%s_%T.bak'
   include current controlfile;
   BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-8/24' DELETE INPUT FORMAT '$bkup_dir/archlogfiles_%u_%s_%T.arc';
   RELEASE CHANNEL c1;
   sql 'alter system switch logfile';
}

resync catalog;
exit
EOF
cd /oradata2/oracle/devdb_rmanbkups/rman_bkup
mv *.bak *.arcbak $bkup_dir


ARCCATDB

printing stored script: devracdb_full_bkup
{
        ALLOCATE CHANNEL c1 device type disk;
        BACKUP DATABASE FORMAT '/devdb_rmanbkups/rman_bkup/devracdb_%u_%s_%T.bak'
        include current controlfile;
        BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-8/24' DELETE INPUT FORMAT '/devdb_rmanbkups/rman_bkup/archlogfiles_%u_%s_%T.arcbak';
        RELEASE CHANNEL c1;
        sql 'alter system switch logfile';
}








-- Dev database Back script
#!/bin/sh
#export ORACLE_SID=devracdb2
#export ORACLE_HOME=/opt/app/oracle/product/11.2.0/db_1

bkup_date=`date +%d%b%Y`
echo $bkup_date

bkup_dir=/devdb_rmanbkups/rman_bkup/devdb_bkup_$bkup_date

mkdir -p $bkup_dir

cd $bkup_dir

touch $bkup_dir/rman_bkup_logs_$bkup_date.log

rman catalog rman/rman_201@arccatdb log=$bkup_dir/rman_bkup_logs_$bkup_date.log << EOF
connect target rman/rman@devracdb;
run
{
   SQL 'alter system switch logfile';
   BACKUP AS COPY CURRENT CONTROLFILE FORMAT '/recovery/oracle/rman_ctl_bkups/devracdb2_cntlfile_$bkup_date.ctl';
   ALLOCATE CHANNEL c1 device type disk;
   BACKUP DATABASE FORMAT '$bkup_dir/devracdb_%u_%s_%T.bak';
   --include current controlfile;
   BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-8/24' DELETE INPUT FORMAT '$bkup_dir/archlogfiles_%u_%s_%T.arcbak';
   RELEASE CHANNEL c1;
   SQL 'alter system switch logfile';
}
resync catalog;
exit
EOF

mv /recovery/oracle/rman_ctl_bkups/devracdb2_cntlfile_26Dec2013.ctl $bkup_dir




30 22 * * * sh /devdb_rmanbkups/scripts/devracdb_rman_script.sh






-- QA DB Back script
#!/bin/sh
#export ORACLE_SID=qaracdb2
#export ORACLE_HOME=/opt/app/oracle/product/11.2.0/db_1

bkup_date=`date +%d%b%Y`
echo $bkup_date

bkup_dir=/qadb_rmanbkups/rman_bkup/qadb_bkup_$bkup_date

mkdir -p $bkup_dir

cd $bkup_dir

touch $bkup_dir/rman_bkup_logs_$bkup_date.log

rman catalog rman/rman_201@arccatdb log=$bkup_dir/rman_bkup_logs_$bkup_date.log << EOF
connect target rman/rman@qaracdb;
run
{
   SQL 'alter system switch logfile';
   BACKUP AS COPY CURRENT CONTROLFILE FORMAT '/recovery/oracle/rman_ctl_bkups/qaracdb2_cntlfile_$bkup_date.ctl';
   ALLOCATE CHANNEL c1 qaice type disk;
   BACKUP DATABASE FORMAT '$bkup_dir/qaracdb_%u_%s_%T.bak';
   --include current controlfile;
   BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-8/24' DELETE INPUT FORMAT '$bkup_dir/archlogfiles_%u_%s_%T.arcbak';
   RELEASE CHANNEL c1;
   SQL 'alter system switch logfile';
}
resync catalog;
exit
EOF

mv /recovery/oracle/rman_ctl_bkups/qaracdb2_cntlfile_$bkup_date.ctl $bkup_dir


30 22 * * * sh /qadb_rmanbkups/scripts/qaracdb_rman_script.sh



Archived Log entry 5897 added for thread 2 sequence 4269 ID 0x166ec2f1 dest 1:
2013-12-26 04:01:34.858000 -08:00
Errors in file /opt/app/oracle/diag/rdbms/devracdb/devracdb2/trace/devracdb2_dia0_25463.trc  (incident=58082):
ORA-32701: Possible hangs up to hang ID=0 detected
Incident details in: /opt/app/oracle/diag/rdbms/devracdb/devracdb2/incident/incdir_58082/devracdb2_dia0_25463_i58082.trc
2013-12-26 04:01:37.950000 -08:00
Sweep [inc][58082]: completed
Sweep [inc2][58082]: completed





--*****************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************
-->> Restoring the SPFILE - with and without AUTOBACKUP

-- How to take a spfile backup
RMAN> backup spfile format '/oradata2/rmanbackup/mapdb_bkup_spfile_%u_%s_%T.spfbak';

/*
	Let us look at some backup and recovery scenarios pertaining to the SPFIILE. The SPFILE is a small but very important file and if we lose the spfile, 
we cannot start the database even if all the other database files are present and intact.

So in my opinion, it is quite an important thing to consider in our disaster recovery strategy.

Remember best practise is to turn the autobackup of the control file to ON (it is OFF by default).
*/

--SPFILE is automatically backed up along with the database control file when any of the following events occur and when the control file 
--autobackup has been enabled in RMAN. .

RMAN> show controlfile autobackup;

RMAN configuration parameters for database with db_unique_name GAVIN are:
CONFIGURE CONTROLFILE AUTOBACKUP ON;
When does the SPFILE gat backed up with AUTOBACKUP now tuned on?

/*
	* After every BACKUP or CREATE CATALOG command
	* After every BACKUP command contained in a RUN block
	* After every structural change to the database occurs like adding a new tablespace, altering the state of a tablespace or datafile 
	(for example, bringing it online), adding a new online redo log, renaming a file
*/ 

-- Where does the SPFILE autobackup reside?

RMAN> show controlfile autobackup format ;

RMAN configuration parameters for database with db_unique_name GAVIN are:
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F'; # default
This is the default setting for CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK

-- By default, RMAN will send the autobackup to the flash recovery area (if used).

-- Let us now remove the default keyword

RMAN> CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F';

new RMAN configuration parameters:
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F';
new RMAN configuration parameters are successfully stored

-- In this case the SPFILE (and control file) autobackup is located anywhere you specify, but default location will be 
-- %ORACLE_HOME%\Database on Windows and $ORACLE_HOME/dbs on UNIX.

RMAN> list backup of spfile;

using target database control file instead of recovery catalog

List of Backup Sets
===================

BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ ---------------
252     Full    9.73M      DISK        00:00:00     13-JUN-13
        BP Key: 267   Status: AVAILABLE  Compressed: NO  Tag: TAG20130613T144508
        Piece Name: /u01/app/oracle/product/11.2.0/dbhome_1/dbs/c-2968723077-20130613-00
        
-- Let us now specify an actual location on disk instead of just the %F,

RMAN> CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '/u01/backup/%F';

old RMAN configuration parameters:
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F';
new RMAN configuration parameters:
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '/u01/backup/%F';
new RMAN configuration parameters are successfully stored


RMAN> list backup of spfile;

using target database control file instead of recovery catalog

List of Backup Sets
===================


BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ ---------------
256     Full    9.73M      DISK        00:00:01     13-JUN-13
        BP Key: 271   Status: AVAILABLE  Compressed: NO  Tag: TAG20130613T155004
        Piece Name: /u01/backup/c-2968723077-20130613-01
Note the SPFILE autobackup is now located at /u01/backup and we can see the format of the backup file on disk is no longer OMF.

The DBID (2968723077) and the timestamp (20130613) is now contained in the backup file name c-2968723077-20130613-01

-- Let us now revert the autobackup back to the FRA.

RMAN> CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK CLEAR;


old RMAN configuration parameters:
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F';
RMAN configuration parameters are successfully reset to default value

RMAN> show CONTROLFILE AUTOBACKUP FORMAT;

RMAN configuration parameters for database with db_unique_name GAVIN are:
CONFIGURE CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '%F'; # default


RMAN> list backup of spfile;

using target database control file instead of recovery catalog

List of Backup Sets
===================


BS Key  Type LV Size       Device Type Elapsed Time Completion Time
------- ---- -- ---------- ----------- ------------ ---------------
266     Full    9.73M      DISK        00:00:01     13-JUN-13
        BP Key: 281   Status: AVAILABLE  Compressed: NO  Tag: TAG20130613T162411
        Piece Name: /u01/app/oracle/fast_recovery_area/GAVIN/autobackup/2013_06_13/o1_mf_s_818007851_8vlsdd3n_.bkp

Autobackup is now back to OMF.

-->> Recovery scenarios involving loss of SPFILE

Case 1) Autobackup in Flash (or now called Fast) Recovery Area

--		The SPFILE has accidently been deleted and now the database is not starting up after a shutdown has been executed.

--		FRA has been configured.

--		If FRA has been configured, the backup of the SPFILE is located in the autobackup sub-directory.

--		For example:

--			/u01/app/oracle/fast_recovery_area/GAVIN/autobackup/2013_06_10/ o1_mf_s_818007851_8vlsdd3n_.bkp

--		Note that it is stored in OMF format in this example. The �s� in the string identifies the OMF as a backup related to the SPFILE


--		To recover from loss of SPFILE if you are NOT using an RMAN Catalog, we need to do two things first :

--		1)	Set the DBID
--		2)	Issue the STARTUP NOMOUNT FORCE command from an RMAN prompt (note � not SQL*PLUS)

		RMAN> SET DBID=2968723077;

		executing command: SET DBID

		RMAN> startup force nomount;

		startup failed: ORA-01078: failure in processing system parameters
		LRM-00109: could not open parameter file '/u01/app/oracle/product/11.2.0/dbhome_1/dbs/initgavin.ora'

		starting Oracle instance without parameter file for retrieval of spfile
		Oracle instance started

		Total System Global Area     158662656 bytes

		Fixed Size                     2226456 bytes
		Variable Size                104859368 bytes
		Database Buffers              46137344 bytes
		Redo Buffers                   5439488 bytes
		This is a typical error we will face when either restoring the SPFILE or control file from an autobackup.

		RMAN>  restore controlfile from autobackup;

		Starting restore at 13-JUN-13
		using channel ORA_DISK_1

		channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130613
		channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130612
		channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130611
		channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130610
		channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130609
		channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130608
		channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130607
		channel ORA_DISK_1: no AUTOBACKUP in 7 days found
		RMAN-00571: ===========================================================
		RMAN-00569: =============== ERROR MESSAGE STACK FOLLOWS ===============
		RMAN-00571: ===========================================================
		RMAN-03002: failure of restore command at 06/13/2013 17:15:52
		RMAN-06172: no AUTOBACKUP found or specified handle is not a valid copy or piece
		The reason in this case is that since the spfile is missing and we have mounted the instance using a dummy spfile, the database needs to know where to look to find the autobackup of the spfile .

--		So now we include the db_file_recovery_dest and db_name parameters in the RESTORE SPFILE command.

		RMAN> restore spfile from autobackup db_recovery_file_dest='/u01/backup/fast_recovery_area' db_name='GAVIN';

		Starting restore at 13-JUN-13
		using channel ORA_DISK_1

		recovery area destination: /u01/backup/fast_recovery_area
		database name (or database unique name) used for search: GAVIN
		channel ORA_DISK_1: AUTOBACKUP /u01/backup/fast_recovery_area/GAVIN/autobackup/2013_06_10/o1_mf_s_818007851_8vlsdd3n_.bkp found in the recovery area
		channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130613
		channel ORA_DISK_1: restoring spfile from AUTOBACKUP /u01/backup/fast_recovery_area/GAVIN/autobackup/2013_06_10/o1_mf_s_818007851_8vlsdd3n_.bkp
		channel ORA_DISK_1: SPFILE restore from AUTOBACKUP complete
		Finished restore at 13-JUN-13
		
Case 2) Autobackup in non-FRA location � non OMF

	RMAN> startup nomount force

	startup failed: ORA-01078: failure in processing system parameters
	LRM-00109: could not open parameter file '/u01/app/oracle/product/11.2.0/dbhome_1/dbs/initgavin.ora'

	starting Oracle instance without parameter file for retrieval of spfile
	Oracle instance started

	Total System Global Area     158662656 bytes

	Fixed Size                     2226456 bytes
	Variable Size                104859368 bytes
	Database Buffers              46137344 bytes
	Redo Buffers                   5439488 bytes

	RMAN> set DBID=2968723077

	executing command: SET DBID

	RMAN>  run {
	2> set CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '/u01/backup/%F';
	3> restore spfile from autobackup;
	4> }

	executing command: SET CONTROLFILE AUTOBACKUP FORMAT

	Starting restore at 13-JUN-13
	using channel ORA_DISK_1

	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130613
	channel ORA_DISK_1: AUTOBACKUP found: '/u01/backup/c-2968723077-20130613-01
	channel ORA_DISK_1: restoring spfile from AUTOBACKUP '/u01/backup/c-2968723077-20130613-01
	channel ORA_DISK_1: SPFILE restore from AUTOBACKUP complete
	Finished restore at 13-JUN-13
	
Case 3) Total Disaster Recovery ( restore by specifying the backup file name)

	In this scenario, the entire database server has crashed and we have lost the entire database files including the SPFILE.

	A new server has been provisioned and all the latest backup files have been restored from tape to a location on disk /u01/backup.

	In this case the backup files are OMF and we have been able to identify the SPFILE backup file from the �s� keyword in the backup file name

	RMAN> restore spfile from '/u01/backup/o1_mf_s_818007851_8vlsdd3n_.bkp';

	Starting restore at 13-JUN-13
	using channel ORA_DISK_1

	channel ORA_DISK_1: restoring spfile from AUTOBACKUP /u01/backup/o1_mf_s_818007851_8vlsdd3n_.bkp
	channel ORA_DISK_1: SPFILE restore from AUTOBACKUP complete
	Finished restore at 13-JUN-13

Case 4) Total Disaster Recovery ( restore by specifying restore from AUTOBACKUP)

	In this case, the scenario is the same as the above.

	But what happens if we want to use the AUTOBACKUP command to restore the spfile because many backup files have been restored and we are not sure which backup file contains the SPFILE backup.

	But what happens in this case when we try to restore the SPFILE from the location where the backup has been restored.

	RMAN>  run {
	2> set CONTROLFILE AUTOBACKUP FORMAT FOR DEVICE TYPE DISK TO '/u01/backup/%F';
	3> restore spfile from autobackup;
	4> }

	executing command: SET CONTROLFILE AUTOBACKUP FORMAT

	Starting restore at 17-JUN-13
	using target database control file instead of recovery catalog
	allocated channel: ORA_DISK_1
	channel ORA_DISK_1: SID=171 device type=DISK

	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130617
	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130616
	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130615
	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130614
	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130613
	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130612
	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130611
	channel ORA_DISK_1: no AUTOBACKUP in 7 days found
	RMAN-00571: ===========================================================
	RMAN-00569: =============== ERROR MESSAGE STACK FOLLOWS ===============
	RMAN-00571: ===========================================================
	RMAN-03002: failure of restore command at 06/17/2013 15:29:58
	RMAN-06172: no AUTOBACKUP found or specified handle is not a valid copy or piece
	So to work around this, we tried to fool RMAN by creating the directory structure when using a FRA.

	We create the directory structure GAVIN/autobackup/2013_06_17 under the to level location /u01/backup and copy the backup pieces to this location.

	-bash-3.2$ cd /u01/backup
	-bash-3.2$ mkdir -p GAVIN/autobackup/2013_06_17
	-bash-3.2$ mv /u01/backup/o1* /u01/backup/GAVIN/autobackup/2013_06_17

	Now we are able to restore the SPFILE from autobackup!

	RMAN>  run {
	2> restore spfile from autobackup db_recovery_file_dest='/u01/backup/' db_name='GAVIN';
	3> }

	Starting restore at 17-JUN-13
	using channel ORA_DISK_1

	recovery area destination: /u01/backup/
	database name (or database unique name) used for search: GAVIN
	channel ORA_DISK_1: AUTOBACKUP /u01/backup/GAVIN/autobackup/2013_06_17/o1_mf_s_818349778_8vx79lo6_.bkp found in the recovery area
	channel ORA_DISK_1: looking for AUTOBACKUP on day: 20130617
	channel ORA_DISK_1: restoring spfile from AUTOBACKUP /u01/backup/GAVIN/autobackup/2013_06_17/o1_mf_s_818349778_8vx79lo6_.bkp
	channel ORA_DISK_1: SPFILE restore from AUTOBACKUP complete
	Finished restore at 17-JUN-13
--*****************************************************************************************************************************************************************
--*****************************************************************************************************************************************************************


mkdir cronjobs

crontab -e 

# Deleting one day old archive logfiles, using RMAN scripts
# Monday and Thursday @ 22:30 PST
30 22 * * 1,4 /home/oracle/cronjobs/delete_arch_1day_older.sh > /home/oracle/cronjobs/logs_cronjob_del_archlogs.log

# Deleting one day old archive logfiles, using RMAN scripts
# Monday and Thursday @ 22:30 PST
00 22 * * 1,4 /home/oracle/cronjobs/del_rptDCW1_archlogs.sh

# Deleting one day old archive logfiles, using RMAN scripts
# Monday and Thursday @ 22:30 PST
20 22 * * 1,4 /home/oracle/cronjobs/del_txnDCW1_archlogs.sh

vi /home/oracle/cronjobs/delete_arch_1day_older.sh

#!/bin/sh

ORACLE_HOSTNAME=wdl2mapxdbs01; export ORACLE_HOSTNAME
ORACLE_UNQNAME=mapdevdb; export ORACLE_UNQNAME
ORACLE_BASE=/opt/oracle; export ORACLE_BASE
#GRID_HOME=/home/oracle/11.2.0/grid; export GRID_HOME
DB_HOME=$ORACLE_BASE/product/11.2.0/dbhome_1; export DB_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
GRID_HOME=$ORACLE_BASE/product/11.2.0/grid; export GRID_HOME
ORACLE_SID=mapuatdb; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH; export PATH
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

rman target / <<EOF
CROSSCHECK ARCHIVELOG ALL;
DELETE NOPROMPT ARCHIVELOG UNTIL TIME "SYSDATE-3";
DELETE NOPROMPT EXPIRED ARCHIVELOG ALL;
EOF
exit


touch /home/oracle/cronjobs/logs_cronjob_del_archlogs.log


chmod 755 delete_arch_1day_older.sh



--------------------------------------------------------------------------------------------------------
-- RMAN Full backup script (INCREMENTAL LEVEL 0)

#!/bin/sh
# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs

PATH=$PATH:$HOME/bin

export PATH

# Oracle Settings
export HOST=`hostname`
export MLIST=acq-dba@tsys.com
export PLIST=""

ORACLE_HOSTNAME=$HOST; export ORACLE_HOSTNAME
ORACLE_UNQNAME=transittxnaz; export ORACLE_UNQNAME
ORACLE_BASE=/opt/app/oracle; export ORACLE_BASE
GRID_HOME=/opt/app/11.2.0/grid; export GRID_HOME
DB_HOME=$ORACLE_BASE/product/11.2.0/dbhome_1; export DB_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
ORACLE_SID=transitt1; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH:$GRID_HOME/bin:$GRID_HOME/OPatch; export PATH
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

# Get the Last Date of Monday, which will be start of week for Full Backup
weekStart_Date=`date -dlast-Monday +"%Y%b%a%d"`
#weekStart_Date=`date -dMonday +"%Y%b%a%d"`

# Get the coming Sunday, which will be End of Week.
weekEnd_Date=`date -dSunday +"%Y%b%a%d"`

# Get the current Date
date_format=`date +%d%b%Y`

weekly_dir=/backup/rmanbackup/transit_RMANBkup_${weekStart_Date}_${weekEnd_Date}

mkdir -p $weekly_dir

cd $weekly_dir

full_bkup_dir=transitt1_Full_rmanbkup_${date_format}

mkdir -p ${full_bkup_dir}

cd ${full_bkup_dir}

backup_path=${weekly_dir}/${full_bkup_dir}

rman  catalog rcat/rcat130@catlog log=${backup_path}/transitt1_rmanbkup_full_${date_format}.log << EOF
connect target rman/rman130;
run
{
   SQL 'alter system switch logfile';
   BACKUP SPFILE FORMAT '${backup_path}/transitt1_bkup_spfile_%u_%s_%T.spfbak';
   BACKUP AS COPY CURRENT CONTROLFILE FORMAT '${backup_path}/transitt1_cntlfile_%u.ctl';
   ALLOCATE CHANNEL c1 TYPE DISK;
   BACKUP DATABASE FORMAT '${backup_path}/transitt1_rmanbkup_%u_%s_%T.bak';
   BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-7' DELETE INPUT FORMAT '${backup_path}/transitt1_arclogfs_%u_%s_%T.arcbak';
   RELEASE CHANNEL c1;
   SQL 'alter system switch logfile';
}
resync catalog;
exit
EOF

echo "RMAN Backup of TransIT prod db is done"
--------------------------------------------------------------------------------------------------------



For the about a week I have been getting an �ORA-27054: NFS file system not mounted with correct options� error when running an RMAN 
backup to a NFS mount point. The system administrator has not been successful in identifying the cause as it shows that the correct mount 
point options are being used.


channel ORA_DISK_1: starting piece 1 at 29-FEB-2014 10:01:50
RMAN-00571: =======================================
RMAN-00569: ====== ERROR MESSAGE STACK FOLLOWS ====
RMAN-00571: =======================================
RMAN-03009: failure of backup command on ORA_DISK_1 channel at 29-FEB-2014 10:01:50
ORA-19504: failed to create file "/oracle/backup/"
ORA-27054: NFS file system where the file is created or resides is not mounted with correct options


Metalink Doc ID 1518979.1 sets the event 10298, by-passing this check and allows writing to the mount point. Obviously we don�t want 
to do that unless it cannot be avoided. I myself am not in favor of avoiding this check but am using this work around temporary. Posting 
this just in-case someone needs to do the same temporarily while trying to identify the root cause.

sqlplus -s / as sysdba <<EOF
alter system set events '10298 trace name context forever, level 32';
EOF

--------------------------------------------------------------------------------------------------------
FILESPERSET = integer
   Specifies the maximum number of input files in each backup set. If you set FILESPERSET = n, then RMAN never includes more than n files in a 
backup set. The default for FILESPERSET is the lesser of these two values: 64, number of input files divided by the number of channels. 
For example, if you back up 100 datafiles by using two channels, RMAN sets FILESPERSET to 50.

RMAN always attempts to create enough backup sets so that all allocated channels have work to do. An exception to the rule occurs when there 
are more channels than files to back up. For example, if RMAN backs up two datafiles when three channels are allocated and FILESPERSET = 1, 
then one channel is necessarily idle.
--------------------------------------------------------------------------------------------------------



#daily RMAN Backups
20 22 * * * sh /home/oracle/cronjobs/rman_bkups.sh




-- Oracle DBA Justin - How to restore and recover a cumulative incremental Oracle database backup
-- recovery exaamples
-- https://www.youtube.com/watch?v=w_cT4mdTf_U
rman target /

RMAN> startup nomunt;
RMAN> restore controlfile from '<<backup pies name>>'
RMAN> restore database;
RMAN> recover database;
RMAN> alter database open resetlogs;







rman target / <<EOF
run
{
	ALLOCATE CHANNEL c1 TYPE DISK;
	CROSSCHECK BACKUP;
	CROSSCHECK ARCHIVELOG ALL;
	DELETE NOPROMPT OBSOLETE;
	DELETE NOPROMPT EXPIRED BACKUP;
	DELETE EXPIRED ARCHIVELOG ALL;
	RELEASE CHANNEL c1;
}
exit 0
EOF