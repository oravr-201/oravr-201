-- oracle dataguard 

	"http://subbarav.blogspot.com/2016/03/oracle-data-guardinterview-questions.html"