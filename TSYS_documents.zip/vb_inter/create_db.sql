aq_tm_processes=1

background_dump_dest='/data/oracle/admin/dev/bdump'
compatible='9.2.0.0.0'
control_files='/data/oracle/oradata/dev/dbfiles/control01.ctl','/data/oracle/oradata/dev/dbfiles/control02.ctl','/data/oracle/oradata/dev/dbfiles/control03.ctl'
core_dump_dest='/data/oracle/admin/dev/cdump'
db_block_size=8192
db_cache_size=262144000
db_domain=''
db_file_multiblock_read_count=16
db_name='dev'
fast_start_io_target=1000
fast_start_mttr_target=300
hash_join_enabled=TRUE
instance_name='dev'
java_pool_size=83886080
job_queue_processes=10
large_pool_size=8388608
open_cursors=300
pga_aggregate_target=25165824
processes=500
query_rewrite_enabled='FALSE'
remote_login_passwordfile='EXCLUSIVE'
shared_pool_size=314572800
sort_area_size=524288
star_transformation_enabled='FALSE'
timed_statistics=TRUE
undo_management='AUTO'
undo_retention=10800
--undo_tablespace='UNDOTBS1'
user_dump_dest='/data/oracle/admin/dev/udump'
log_archive_start=TRUE
log_archive_dest_1='location=/data/oracle/admin/dev/archive'
log_archive_format='arch_%t_%s.arc'


 conn sys/change_on_install as sysdba
 
 startup nomount pfile=/data/oracle/admin/dev/pfile/initdev.ora

CREATE DATABASE dev
maxinstances     2
maxlogfiles     5
maxdatafiles   15
maxloghistory 100
Datafile '/data/oracle/oradata/dev/dbfiles/systemdbfile_01.dbf'size 300M reuse autoextend on next 15M maxsize unlimited
character set WE8MSWIN1252
logfile 
	 group 1 ('/data/oracle/oradata/dev/redologs/redo_101.log','/data/oracle/oradata/dev/redologs/redo_102.log') size 100m,
	 group 2 ('/data/oracle/oradata/dev/redologs/redo_201.log','/data/oracle/oradata/dev/redologs/redo_202.log') size 100M,
	 group 3 ('/data/oracle/oradata/dev/redologs/redo_301.log','/data/oracle/oradata/dev/redologs/redo_302.log') size 100M
default temporary tablespace TEMP tempfile '/data/oracle/oradata/dev/dbfiles/temp_01.dbf' size 100m
undo tablespace UNDO_TS datafile '/data/oracle/oradata/dev/dbfiles/undo_tbs_dbfile_01.dbf' size 100M reuse autoextend on next 15M maxsize unlimited;

 
