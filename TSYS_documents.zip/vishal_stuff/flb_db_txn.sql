-- ***Not appropriate for production use***
--
set echo on
update employees set department_id = 90 where job_id = 'IT_PROG';
update employees e set salary = least(e.salary,(select (min_salary + max_salary)/2 * 1.10 from jobs j where j.job_id = e.job_id)) where job_id not like 'AD_%';

commit;


