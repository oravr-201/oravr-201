BEGIN

-- This will produce an error the first
-- time it is run since MY_PROG does not exist
DBMS_SCHEDULER.DROP_PROGRAM (
   program_name           => '"SYSTEM"."MY_PROG"');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM(
program_name=>'"SYSTEM"."MY_PROG"',
program_action=>'DECLARE
 time_now DATE;
BEGIN

SELECT SYSDATE INTO time_now FROM DUAL;

END;',
program_type=>'PLSQL_BLOCK',
number_of_arguments=>0,
comments=>'Return the sysdate',
enabled=>TRUE);
END;
/

