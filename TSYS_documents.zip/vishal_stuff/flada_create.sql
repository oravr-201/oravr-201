REM   For demo purposes ONLY
REM   Execute script as archive_admin user 

CREATE FLASHBACK ARCHIVE fla1
TABLESPACE fla_tbs1 
QUOTA 10M
RETENTION 1 YEAR
/
