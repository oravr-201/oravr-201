#!/bin/bash

# delete the index on sales (cust_id) for the sqltuning practice

sqlplus -S /nolog > /tmp/sql.log 2>&1 <<EOF

CONNECT / as sysdba
 DROP INDEX SH.SALES_CUST_BIX;

EOF

