grant execute on DBMS_AQADM to test_user
grant execute on DBMS_AQADM_SYS to test_user;

EXECUTE DBMS_AQADM.DROP_QUEUE_TABLE('AQ$_AQ_EVENT_TABLE_E');

execute DBMS_AQADM.DROP_QUEUE_TABLE ('test_user.DEF$_AQCALL',TRUE)

   force             IN    BOOLEAN DEFAULT FALSE,
   auto_commit       IN    BOOLEAN DEFAULT TRUE);


EXECUTE DBMS_AQADM.STOP_QUEUE('test_user.DEF$_AQCALL',TRUE,TRUE,TRUE);

EXECUTE DBMS_AQADM.STOP_QUEUE('system.DEF$_AQERROR',TRUE,TRUE,TRUE);

select owner,object_type, object_name
from dba_objects where object_name like 'DEF$_AQCALL%';


 select * from dba_queue_tables; 


execute dbms_aqadm.drop_queue_table ('AQ_EVENT_TABLE',TRUE);
execute dbms_aqadm.drop_queue_table ('system.DEF$_AQERROR',TRUE);
execute dbms_aqadm.drop_queue_table ('AQ_SRVNTFN_TABLE',true);
execute dbms_aqadm.drop_queue_table ('AQ_EVENT_TABLE',true);
execute dbms_aqadm.drop_queue_table ('imp_test.DEF$_AQCALL',true,true);


select object_name,object_type, count(*) from dba_objects where object_name like 'SYS_IOT_TOP%' group by object_name,object_type ;


execute dbms_aqadm.drop_queue_table ('test_user.DEF$_AQCALL', TRUE); 

drop index SYS_IOT_TOP_27211
SYS_IOT_TOP_27276
SYS_IOT_TOP_27298
SYS_IOT_TOP_27325
SYS_IOT_TOP_27355
SYS_IOT_TOP_27361
SYS_IOT_TOP_27371
SYS_IOT_TOP_28730
SYS_IOT_TOP_28758
SYS_IOT_TOP_28763
SYS_IOT_TOP_28767
SYS_IOT_TOP_28798
SYS_IOT_TOP_28804
SYS_IOT_TOP_28808
SYS_IOT_TOP_28814
SYS_IOT_TOP_28846