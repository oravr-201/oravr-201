GGSCI (epl1trandbtxn1.tsysacquiring.org) 13> shell date

Mon Mar 31 10:37:16 PDT 2014


GGSCI (epl1trandbtxn1.tsysacquiring.org) 14> info all

Program     Status      Group       Lag at Chkpt  Time Since Chkpt

MANAGER     RUNNING
JAGENT      RUNNING
EXTRACT     STOPPED     EPTE        00:00:01      138:56:55
EXTRACT     RUNNING     PPTERE      00:00:00      00:00:10
EXTRACT     RUNNING     PPTERW      00:00:00      00:00:04
EXTRACT     RUNNING     PPTETW      00:00:00      00:00:09
REPLICAT    RUNNING     RPTETW      12:34:56      00:00:03

									12:49:02

									
									
-- Saqib Question
1) Lag Issues is there a work around after removing archive files
ANS--

2) In Pump params file Two Remote Host -- Scan Address..
ANS -- He will be sending the documents

3) In Replicate params files how to use service_name instead of SID

4) Replicating back from TE(DR site).. Currently we have Stopped the extract process ?
	If we start the extract on the DR site, will it capture the operations from the replicate.
	a) using stopping Pump process instead of extract process
	

5) Purge Process. We do not want to replicate a schema and its operations which will have purge related object (which is SP).. 
   in Other words, we do not want to replicate Delete from Transnox_IOX schema exc. by this user


-- Baidhar Questions
1) Rang Functionality: Do we need to have the list of tables
2) BatchSQL, Increase the performance for replication?
	a) How/when to use it.
	b) How much Performance we get ..

3) Parameter called GroupTransOPS
		a) How to use it.
		b) what is the idle number

4) if any process is ABENDED due to DDL Error, how to start it again.
	 a) Do we have to do Begin now always to stop the process and re-start it again or is there any work around to start it, once it is fixed in DB.

5) How do we know, how many tables are out of sync and what is the best practise to sync-up if there are any.

6) How to log DDL/DML related exception into one single table.

7) How to Monitoring the processes thr scronJobs in Linux, Is there a good shell scripts.

8) All the exceptions are logged into ggserr.log file does it also writes in other files 

9) compare the out of sync tables and repair it, if not then what is the work around for the same.

10) What type of activity/action we need to do with checkpoint table
		a) Process is hanging.
		b) if there are any backlogs

11) does it a good idea to put GoldenGate Manager Process in RAC env.

12) Take a Look in RAC/ASM/GoldenGate set-up



-- Rahul Question
1) If we use Marco to handle Exception, will it hit/decrease the Performance, as it will write each and every exception into table
2) What is the best idea for smooth switch between two DCs. like keeping all the processes on, on DR site or write a shell script to handle it 
   to start the DR site processes when switch over happens
   
3) How do we increase the performance to replicate the COLB/BOLB types of DataTypes
4) What are common possible reasons that the Extract/Pump/Replicat process will slow down 
5) If we introduce any New table to Transnox_IOX, Do we have to use TranData for new table.. As Already we have on the supplemental logging on database

6) What does it CHECKPOINTSECS params do, does it check the info in checkpoint table for mentioned secs ?


SNOX4TRANSNOX.SNOX_SCHEDULER_HISTORY
SNOX4TRANSNOX.DEVICE_PROCESSOR_INFO
TRANSNOX_IOX.TRANS_DETAIL
TRANSNOX_IOX.TRANS_CARD
TRANSNOX_IOX.TRANSACTION


-- Testing
1) OGG Purging Procedure from ggate schema, Try an do insert/delete in ggate schema and see if this is replicated
2) Add TransSchema for every newly created schemas including VBS
3) GROUPTRANSOPS


*) Create Exception Table in all DBs


-- Notes
1) Auto Start/stop scripts for switch over for all processes
2) OEM View for Primary and DR site ---




-- Note for DB Development 
Newly created table should have NOCOMPRESS and LOGGING

