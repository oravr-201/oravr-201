DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( JOB       => X 
   ,what      => 'DECLARE 
       a NUMBER; 
       b VARCHAR2(1000); 
BEGIN 
    Remindermail_Custcode_Merging(); 
END;   '
   ,next_date => TO_DATE('25/02/2009 01:30:00','dd/mm/yyyy hh24:mi:ss')
   ,INTERVAL  => 'TO_DATE(''25/02/2009 01:30:00'',''dd/mm/yyyy hh24:mi:ss'')+1'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(x));
COMMIT;
END;
/



DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( JOB       => X 
   ,what      => 'DECLARE 
       a NUMBER; 
       b VARCHAR2(1000); 
BEGIN 
    P0(a,b); 
END;   '
   ,next_date => TO_DATE('25/02/2009 02:30:00','dd/mm/yyyy hh24:mi:ss')
   ,INTERVAL  => 'TO_DATE(''25/02/2009 02:30:00 AM'',''dd/mm/yyyy hh24:mi:ss'')+1'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(x));
COMMIT;
END;
/