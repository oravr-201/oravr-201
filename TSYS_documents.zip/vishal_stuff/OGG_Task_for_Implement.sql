
Reminder


-- On PF HW I found that the Replicat Processes where ABENDED because of SN_TEMP tables which were created in VBS
* Include all VBS names in extract DDL include all, exclude OBJNAME VBS.SN_TEMP*
--- consider the schemas which are creating SN_TEMP and SC_TEMP
		TRANSNOX_IOX
		TRANSNOX_CAT
		SNOX4TRANSNOX
		ALL VERSION BASE SCHEMAS (VBS)


		
		




--- Task To get from Saqib 		
1) Understanding SQL Loader for MAP (fiji) DB
2) DataGuard archive logs deleting process
3) GCA Billing task if any
4) In-House Replication username/password
5) DataGuard switching between
6) Removing Archive files from Primary and Reporting DBs




	
expdp rchaudhari directory=dpump dumpfile=expdp_tsysjira.dmp logfile=expdp_tsysjira.log schemas=TSYSJIRA




-- snox4transnox.merchant_product
1) Create a backup tables on reporting DB
2) truncate a table 
3) To Sync-up the data snox4transnox.merchant_product table, insert the data using DBLink from primary to Reporting DB










API Release 
	Primary DB ---- 30
	Reporting DB ---- 15
	CAT Release ---- 15

SMSNox Release
	Primary DB ---- 10
	Reporting DB ---- 10

Replication Triggers -- 15

Rollbackup -- 1 Hrs































