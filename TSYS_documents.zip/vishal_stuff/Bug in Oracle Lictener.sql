
A potential security vulnerability has been discovered in Net8 
(formerly known as SQL*Net). :--->

When connecting to an Oracle database, a connection is first made to the listener 
process. This initial packet contains command data, such as the instance to 
connect to and the client information. This packet also contains a header 
with a field indicating the maximum transport data size of the client�s network.
If the maximum transport data size is set to 0, the listener will crash. Products
Oracle8i database server (all releases)



----create or replace procedure Testing_BUG

DECLARE
TEMP_OBJECT CHAR(10);
BEGIN
   SELECT SIOBNM FROM SLTEST.F9860 into TEMP_OBJECT WHERE SIUPMJ = 104234;
   IF TEMP_OBJECT <> 0 THEN
      TEMP_OBJECT := "F4211";
   ELSE 
      TEMP_OBJECT := "F4201";
   END IF; 
COMMIT;
END;
