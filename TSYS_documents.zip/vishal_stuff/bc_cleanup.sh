#!/bin/bash
# For training purpose only
#-- Cleanup the tablespace, and user from the corrupt blocks

sqlplus -S /nolog > /tmp/cleanup.lo 2>&1 <<EOF
connect / as sysdba

-- CLEANUP from previous run
DROP USER bc CASCADE;

DROP TABLESPACE bctbs INCLUDING CONTENTS AND DATAFILES;

EXIT;
EOF


