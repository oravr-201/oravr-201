CREATE OR REPLACE FUNCTION read_discard 
(
      DiscardName       VARCHAR2
) RETURN DiscardTable PIPELINED IS
 
    v_FileHandle        UTL_FILE.FILE_TYPE;
 
    DiscardRec          DISCARDRECORD;
    DiscardExtra        DISCARDRECORD;
 
    v_FileBuffer        VARCHAR2(32767);
    v_PartLine          VARCHAR2(32767);
 
    OutputRow           BOOLEAN;
    ErrorRow            BOOLEAN;
    FindingColumn       BOOLEAN;
    
    v_Insert_Flag       VARCHAR2(30);
    
    LineNumber          NUMBER := 0;
 
    /* Cursors */
 
    CURSOR get_cons_cols_curs (
          ConstraintOwner VARCHAR2
        , ConstraintName  VARCHAR2
    ) IS
        SELECT column_name
        FROM   dba_cons_columns
        WHERE  owner           = ConstraintOwner
        AND    constraint_name = ConstraintName
        AND    position        = 1;
 
    CURSOR get_pk_table_curs (
          ConstraintOwner VARCHAR2
        , ConstraintName  VARCHAR2
    ) IS
        SELECT pk.table_name
        FROM dba_constraints fk
           , dba_constraints pk
        WHERE pk.owner           = fk.r_owner
        AND   pk.constraint_name = fk.r_constraint_name
        AND   fk.owner           = ConstraintOwner
        AND   fk.constraint_name = ConstraintName;
 
    CURSOR get_pk_col_curs (
          TableOwner VARCHAR2
        , TableName  VARCHAR2
    ) IS
        SELECT col.column_name
        FROM   dba_cons_columns col
             , dba_constraints  pk
        WHERE  pk.owner           = TableOwner
        AND    pk.table_name      = TableName
        AND    pk.owner           = col.owner
        AND    pk.constraint_name = col.constraint_name
        AND    pk.constraint_type = 'P'
        AND    col.position       = 1;
 
    /* Procedures */
 
    PROCEDURE OpenDiscard
    IS
    BEGIN
        v_FileHandle := UTL_FILE.FOPEN('GGDISCARD',DiscardName||'.dsc','R');
    END OpenDiscard;
 
    PROCEDURE ReadDiscard
    IS
    BEGIN
        UTL_FILE.GET_LINE(v_FileHandle,v_FileBuffer);
 
        LineNumber := LineNumber + 1;
    END ReadDiscard;
 
    PROCEDURE CloseDiscard
    IS
    BEGIN
        UTL_FILE.FCLOSE(v_FileHandle);
    END CloseDiscard;
 
    PROCEDURE InitialiseRecord (
        Discard_INOUT IN OUT DISCARDRECORD
    ) IS
    BEGIN
        Discard_INOUT := DISCARDRECORD(
                 NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
                ,NULL
            );
    END InitialiseRecord;
 
BEGIN
    OpenDiscard;
 
    ErrorRow      := FALSE;
    FindingColumn := FALSE;
 
    InitialiseRecord(DiscardRec);
 
    LOOP
        ReadDiscard;
 
        WHILE v_FileBuffer IS NULL
        LOOP
                ReadDiscard;
        END LOOP;
 
        /* Read first 2 words */
 
        IF v_FileBuffer = '*' THEN
            v_PartLine := '*';
        ELSE
            v_PartLine := SUBSTR(v_FileBuffer,1,INSTR(v_FileBuffer,' ',2,2)-1);
        END IF;
        
        v_Insert_Flag := 'NO_INSERT';
        
        IF v_PartLine<>'Discarding record' OR v_PartLine<>'Oracle GoldenGate' THEN
            v_Insert_Flag := 'INSERT';
        END IF ;
        
        OutputRow := FALSE;
        IF v_Insert_Flag='INSERT' THEN
         
            CASE v_PartLine
                WHEN 'Oracle GoldenGate' THEN
                    IF ErrorRow  THEN
                        PIPE ROW (DiscardRec);
                        InitialiseRecord(DiscardRec);
                        ErrorRow := FALSE;
                    END IF;
     
                    DiscardRec.message_type := 'INFO';
                    DiscardRec.message      :=  SUBSTR(v_FileBuffer,19,INSTR(v_FileBuffer,' ',19,1)-19)
                                               ||' Process '
                                               ||SUBSTR( v_FileBuffer
                                                        ,INSTR(v_FileBuffer,'for Oracle process')+19
                                                        ,INSTR(v_FileBuffer,',')-(INSTR(v_FileBuffer,'for Oracle process')+19));
                    -- DiscardRec.message      := 'Capture Process '||SUBSTR(v_FileBuffer,47,INSTR(v_FileBuffer,',')-47);
                    DiscardRec.description  := SUBSTR( v_FileBuffer,INSTR(v_FileBuffer,',')+2
                                                      ,INSTR(v_FileBuffer,':') - (INSTR(v_FileBuffer,',')+2));
                    DiscardRec.message_date := TO_DATE( SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,':')+2)
                                                       ,'YYYY-MM-DD HH24:MI:SS');
                    DiscardRec.line_number  := LineNumber;
     
                    OutputRow := TRUE;
                WHEN 'Process Abending' THEN
                    IF ErrorRow  THEN
                        PIPE ROW (DiscardRec);
                        InitialiseRecord(DiscardRec);
                        ErrorRow := FALSE;
                    END IF;
     
                    DiscardRec.message_type := 'WARNING';
                    DiscardRec.message      := v_PartLine;
                    DiscardRec.message_date := TO_DATE(SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,':')+2),'YYYY-MM-DD HH24:MI:SS');
                    DiscardRec.line_number  := LineNumber;
     
                    OutputRow := TRUE;
                WHEN 'Current time:' THEN
                    IF ErrorRow THEN
                        PIPE ROW (DiscardRec);
                            InitialiseRecord(DiscardRec);
                    END IF;
     
                    DiscardRec.message_type := 'ERROR';
                    DiscardRec.message_date := TO_DATE(SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,':')+2),'YYYY-MM-DD HH24:MI:SS');
                    DiscardRec.line_number  := LineNumber;
     
                    ErrorRow  := TRUE;
                    OutputRow := FALSE;
                WHEN ' Error text' THEN
                    DiscardRec.oracle_error := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,', ')+2,INSTR(v_FileBuffer,':')-(INSTR(v_FileBuffer,', ')+2));
                    DiscardRec.error_number := TO_NUMBER(SUBSTR(DiscardRec.oracle_error,INSTR(DiscardRec.oracle_error,'-')+1));
                    DiscardRec.message      := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,':')+2,INSTR(v_FileBuffer,',',1,2)-(INSTR(v_FileBuffer,':')+2));
                    DiscardRec.description  := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,'SQL '));
     
                    OutputRow := FALSE;
                WHEN 'Operation failed' THEN
                    DiscardRec.operation_seqno := SUBSTR( v_FileBuffer,INSTR(v_FileBuffer,'seqno ')+6, INSTR(v_FileBuffer,' rba ')-(INSTR(v_FileBuffer,'seqno ')+6));
                    DiscardRec.operation_rba   := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,' rba ')+5);
     
                    OutputRow := FALSE;
                WHEN 'OCI Error' THEN
                    DiscardRec.oracle_error := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,' ',1,2)+1,INSTR(v_FileBuffer,':')-(INSTR(v_FileBuffer,' ',1,2)+1));
                    DiscardRec.error_number := TO_NUMBER(SUBSTR(DiscardRec.oracle_error,INSTR(DiscardRec.oracle_error,'-')+1));
                    DiscardRec.message      := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,':')+2,INSTR(v_FileBuffer,',')-(INSTR(v_FileBuffer,':')+2));
                    DiscardRec.description  := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,'SQL '));
     
                    CASE DiscardRec.error_number
                        WHEN 1 THEN
                            v_PartLine := SUBSTR( DiscardRec.message,INSTR(DiscardRec.message,'(')+1 ,INSTR(DiscardRec.message,')')-(INSTR(DiscardRec.message,'(')+1));
                            DiscardRec.error_object_owner := SUBSTR(v_PartLine,1,INSTR(v_PartLine,'.')-1);
                            DiscardRec.error_object_name  := SUBSTR(v_PartLine,INSTR(v_PartLine,'.')+1);
                        WHEN 2291 THEN
                            v_PartLine := SUBSTR( DiscardRec.message,INSTR(DiscardRec.message,'(')+1 ,INSTR(DiscardRec.message,')')-(INSTR(DiscardRec.message,'(')+1));
                            DiscardRec.error_object_owner := SUBSTR(v_PartLine,1,INSTR(v_PartLine,'.')-1);
                            DiscardRec.error_object_name  := SUBSTR(v_PartLine,INSTR(v_PartLine,'.')+1);
                        ELSE
                            NULL;
                    END CASE;
     
                    OutputRow := FALSE;
                WHEN 'Operation: 15' THEN -- 'Discarding record' 
                    DiscardRec.error_action := SUBSTR( v_FileBuffer,INSTR(v_FileBuffer,' ',1,4)+1 ,INSTR(v_FileBuffer,' ',1,5)-(INSTR(v_FileBuffer,' ',1,4)+1));
                    DiscardRec.error_number := TO_NUMBER(SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,' ',-1)));
                    DiscardRec.oracle_error := 'ORA-'||TO_CHAR(DiscardRec.error_number,'FM09999');
     
                    OutputRow := FALSE;
                WHEN 'Problem replicating' THEN
                    v_PartLine := SUBSTR( v_FileBuffer,INSTR(v_FileBuffer,' ',1,2)+1
                                       ,INSTR(v_FileBuffer,' to ')-(INSTR(v_FileBuffer,' ',1,2)+1));
                    DiscardRec.source_object_owner := SUBSTR(v_PartLine,1,INSTR(v_PartLine,'.')-1);
                    DiscardRec.source_object_name  := SUBSTR(v_PartLine,INSTR(v_PartLine,'.')+1);
     
                    v_PartLine := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,' to ')+4);
     
                    DiscardRec.target_object_owner := SUBSTR(v_PartLine,1,INSTR(v_PartLine,'.')-1);
                    DiscardRec.target_object_name  := SUBSTR(v_PartLine,INSTR(v_PartLine,'.')+1);
     
                    OutputRow := FALSE;
                WHEN 'Mapping problem' THEN
                    DiscardRec.error_operation := UPPER(SUBSTR( v_FileBuffer,INSTR(v_FileBuffer,' ',-1,4)+1 ,INSTR(v_FileBuffer,' ',-1,3)-(INSTR(v_FileBuffer,' ',-1,4)+1)));
     
                    OutputRow := FALSE;
                    WHEN 'Record not' THEN
                    DiscardRec.message := v_FileBuffer;
     
                    OutputRow := FALSE;
                WHEN '*' THEN
                    IF FindingColumn THEN
                        FindingColumn := FALSE;
                        OutputRow     := TRUE;
                    ELSE
                        /* Gather some information for specific messages */
     
                        CASE DiscardRec.error_number
                            WHEN 1      /* Unique constraint violation */ THEN
                                    /* Find the first column for the key and then be able to find it's value in the text */
     
                                    OPEN get_cons_cols_curs(DiscardRec.error_object_owner,DiscardRec.error_object_name);
     
                                    FETCH get_cons_cols_curs
                                    INTO  DiscardRec.error_column;
     
                                    CLOSE get_cons_cols_curs;
     
                            WHEN 1403   /* Row not found */ THEN
                                    /* Find the PK of the table and then find it's value - if possible */
     
                                    DiscardRec.error_object_owner := DiscardRec.source_object_owner;
                                    DiscardRec.error_object_name  := DiscardRec.source_object_name;
     
                                    OPEN get_pk_col_curs(DiscardRec.error_object_owner,DiscardRec.error_object_name);
     
                                    FETCH get_pk_col_curs
                                    INTO  DiscardRec.error_column;
     
                                    CLOSE get_pk_col_curs;
     
                            WHEN 2291   /* Integrity constraint violation */ THEN
                                    /* Find the FK table name , column name and then be able to find the value of the offending row */
                                    /* Get the column name */
     
                                    OPEN get_cons_cols_curs(DiscardRec.error_object_owner,DiscardRec.error_object_name);
     
                                    FETCH get_cons_cols_curs
                                    INTO  DiscardRec.error_column;
     
                                    CLOSE get_cons_cols_curs;
     
                                    /* Get primary key table name */
     
                                    OPEN get_pk_table_curs(DiscardRec.error_object_owner,DiscardRec.error_object_name);
     
                                    FETCH get_pk_table_curs
                                    INTO  DiscardRec.pk_table_name;
     
                                    CLOSE get_pk_table_curs;
                            ELSE
                                NULL;
                        END CASE;
     
                        FindingColumn := TRUE;
                    END IF;
                ELSE
                    IF FindingColumn THEN
                        IF DiscardRec.error_column IS NOT NULL THEN
                            IF DiscardRec.error_column = SUBSTR(v_FileBuffer,1,INSTR(v_FileBuffer,' = ')-1) THEN
                                DiscardRec.error_value := SUBSTR(v_FileBuffer,INSTR(v_FileBuffer,' = ')+3);
                            END IF;
                        END IF;
                    ELSE
                        /* Found something unusual so let's output an extra record */
     
                        InitialiseRecord(DiscardExtra);
                        DiscardExtra.message_type := 'UNKNOWN';
                        DiscardExtra.message      := SUBSTR(v_FileBuffer,1,120);
                        DiscardExtra.description  := SUBSTR(v_FileBuffer,120);
                        DiscardExtra.line_number  := LineNumber;
     
                        PIPE ROW (DiscardExtra);
                    END IF;
            END CASE;
        END IF;
 
        IF OutputRow THEN
            PIPE ROW (DiscardRec);
            InitialiseRecord(DiscardRec);
            ErrorRow := FALSE;
        END IF;
    END LOOP;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        /* Output last row if not output */
 
        IF DiscardRec.message_type IS NOT NULL THEN
            PIPE ROW(DiscardRec);
        END IF;
 
        CloseDiscard;
END read_discard;
/