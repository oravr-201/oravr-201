#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=$ORACLE_BASE/OraHome1
#export ORACLE_SID=aqprod

#.$ORACLE_BASE/.bash_profile

mydate=`date +%m%d%y%H`

cd /oracle/bkups

dumpfile=/oracle/bkups/dump

logs=/oracle/bkups/current_logs

ziploc=$dumpfile

mail_msg=/oracle/bkups/mailmsg

previous_logs=/oracle/bkups/previous_logs

# deleting all old logs
rm -rf $previous_logs/stag_export_log.log
rm -rf $previous_logs/qadev_export_log.log

mv $logs/stag_export_log.log $previous_logs
mv $logs/qadev_export_log.log $previous_logs

MAIL_FILE="/oracle/bkups/mail.txt"

stag_alertErr="/oracle/bkups/stag_alert.err"
qadev_alertErr="/oracle/bkups/qadev_alert.err"

####################################################################
#function for sending if export logfile conetents error else will send success mail

mail_status()
{
MAILSERVER="smtp.ifxsc.com"
MAIL_FROM="rahulc@infonox.com"
MAIL_TO="rahulc@infonox.com"
MAIL_CC="milindb@infonox.com"
MAIL_CC="gaurav@infonox.com"
MAIL_CC="narendra@infonox.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
Cc: $MAIL_CC
Cc: $MAIL_CC
Cc: $MAIL_CC
Subject: Backup export For Transending Schemas

Hi All,

   `cat ${MAIL_FILE}`

Regards,
 RahulC
.
"

echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
############################################################

# exporting stag schemas
exp expuser/expstag@stag file=$dumpfile/stag_exp_bkup_$mydate.dmp log=$logs/stag_export_log.log full=y rows=y statistics=none buffer=500000

#send mail if there is any ORA- error in import log files for staging DB
rm -rf stag_alert.err
cat $logs/stag_export_log.log | grep "ORA-" > stag_alert.err

COUNT=`cat stag_alert.err | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for stag bkups"
    echo "######################## stag Schemas #################################### " > $MAIL_FILE
    echo -e " \n No Errors in stag schemas export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of stag schemas" >> $MAIL_FILE
else
    echo " sending failure for stag bkups"
    echo "######################## stag Schemas #################################### " > $MAIL_FILE
    echo -e " \n Errors in export log file $logs/stag_export_log.log for stag schemas \n" >> $MAIL_FILE
    cat $stag_alertErr >> $MAIL_FILE
fi
###########################################################

# exporting qadev schemas
exp expuser/expqadev@qadev file=$dumpfile/qadev_exp_bkup_$mydate.dmp log=$logs/qadev_export_log.log full=y rows=y statistics=none buffer=500000

#send mail if there is any ORA- error in import log files for QADEV DB
rm -rf qadev_alert.err
cat $logs/qadev_export_log.log | grep "ORA-" > qadev_alert.err

COUNT=`cat qadev_alert.err | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for qadev bkups"
    echo "######################## qadev Schemas #################################### " > $MAIL_FILE
    echo -e " \n No Errors in qadev schemas export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of qadev schemas" >> $MAIL_FILE
else
    echo " sending failure for qadev bkups"
    echo "######################## qadev Schemas #################################### " > $MAIL_FILE
    echo -e " \n Errors in export log file $logs/qadev_export_log.log for stag schemas \n" >> $MAIL_FILE
    cat $qadev_alert.err >> $MAIL_FILE
fi
###########################################################

#tar file for stag
tar -cf $ziploc/stag_exp_bkup_$mydate.tar $dumpfile/stag_exp_bkup_$mydate.dmp

#tar file for qadev
tar -cf $ziploc/qadev_exp_bkup_$mydate.tar $dumpfile/qadev_exp_bkup_$mydate.dmp

rm -rf $dumpfile/stag_exp_bkup_$mydate.dmp
rm -rf $dumpfile/qadev_exp_bkup_$mydate.dmp

###########################################################
#moving bkup tar file of stag to 192.168.231.84 bkup server  
/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@192.168.231.84
expect "password:"
send "oracle123\r"
expect "sftp> "
send "put /oracle/bkups/dump/stag_exp_bkup_$mydate.tar /oracle/bkups/stag\r"
expect "sftp> "
send "put /oracle/bkups/dump/qadev_exp_bkup_$mydate.tar /oracle/bkups/qadev\r"
expect "sftp> "
send "exit\r"
SCRIPT_END

###########################################################
# removing the tar file from DB server 192.168.231.
rm -rm $ziploc/stag_exp_bkup_$mydate.tar
rm -rm $ziploc/qadev_exp_bkup_$mydate.tar

rm -rf /oracle/bkups/stag_alert.err
rm -rf /oracle/bkups/qadev_alert.err
