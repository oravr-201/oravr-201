REM "******************************************* "
REM "For training purposes ONLY:" Log into SQL*Plus as HR user

set echo on
set serveroutput on
-- set verify on
set term on
set lines 200
set pages 44

SELECT table_name
FROM   dict
WHERE  table_name LIKE '%FLASHBACK_ARCHIVE%'
/

exit
