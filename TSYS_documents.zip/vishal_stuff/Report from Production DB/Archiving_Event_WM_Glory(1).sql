alter session set current_schema=snox4transnox;

create table event_1 nologging tablespace SNOX_INDX
as
select *
from snox4transnox.event
where server_timestamp > sysdate-7;

alter table event rename to event_26Nov2012;
alter table event_1 rename to event;
alter table event logging;

drop index IDX_COMP_CTIME_STAMP;
drop index IDX_EV_CASCODE;

CREATE INDEX SNOX4TRANSNOX.IDX_COMP_CTIME_STAMP ON SNOX4TRANSNOX.EVENT
(SERVICE, WORKSTATIONCODE, SERVER_TIMESTAMP) TABLESPACE SNOX_DATA;

CREATE INDEX SNOX4TRANSNOX.IDX_EV_CASCODE ON SNOX4TRANSNOX.EVENT
(CASINOCODE) TABLESPACE SNOX_INDX;

grant select,update,insert,delete on snox4transnox.event to transnox_wm;
grant select,update,insert,delete on snox4transnox.event to transnox_glory;

CREATE or replace SYNONYM TRANSNOX_WM.EVENT FOR SNOX4TRANSNOX.EVENT;
CREATE or replace SYNONYM TRANSNOX_GLORY.EVENT FOR SNOX4TRANSNOX.EVENT;

exec dbms_utility.compile_schema(schema=>'SNOX4TRANSNOX');
exec dbms_utility.compile_schema(schema=>'TRANSNOX_WM');
exec dbms_utility.compile_schema(schema=>'TRANSNOX_GLORY');

