
-- Oracle version upgrade
http://onlineappsdba.com/index.php/2009/01/22/upgrade-oracle-database-10g-to-11g-r1-111x/


--********************************************************************--
-- recompile all objects

--please note that the process of recompiling an invalid object writes a significant amount of data to system tables and is fairly I/O intensive. 
--A slow disk system may be a significant bottleneck and limit speedups available from a higher degree of parallelism.

--Recompile all objects sequentially:
EXECUTE UTL_RECOMP.RECOMP_SERIAL();

--Recompile objects in schema SCOTT sequentially:
EXECUTE UTL_RECOMP.RECOMP_SERIAL('SCOTT');

--Recompile all objects using 4 parallel threads:
EXECUTE UTL_RECOMP.RECOMP_PARALLEL(4);

--Recompile objects in schema JOE using the number of threads specified in the parameter JOB_QUEUE_PROCESSES:
EXECUTE UTL_RECOMP.RECOMP_PARALLEL(NULL, 'JOE');


-- recompile the invalid objects in snox schema
exec dbms_utility.compile_schema(schema=>'SNOX');

--********************************************************************--

production VDI 10.132.0.4
from local laptop RDP to 10.132.9.42 to access the production DB

select org.owner, org.object_type, org.status, org.org_cnt,
       dup.owner, dup.object_type, dup.status, dup.dup_cnt
(
    select owner, object_type, status, count(*) org_cnt
    from dba_objects
    where owner='SNOX4TRANSNOX_API'
    GROUP BY OWNER, OBJECT_TYPE, STATUS
)org
(
    select owner, object_type, status, count(*) dup_cnt
    from dba_objects
    where owner='SNOX4TRANSNOX_API_PUNE'
    GROUP BY OWNER, OBJECT_TYPE, STATUS 
)dup
where org.owner = substr(dup.owner,1,length(dup.owner)-5)
  and org.object_type = dup.object_type
order by 1,2,3 asc  



****************************************  DBMS_UTILITY Package  **************************************** 
-- DBMS_UTILITY package

-- get the CPU time taken by the procedure
--Returns the current CPU time in 100th's of a second
DECLARE
 i NUMBER;
 j NUMBER;
 k NUMBER;
BEGIN
  i := dbms_utility.get_cpu_time;

  SELECT COUNT(*)
  INTO j
  FROM all_tables t, all_indexes i
  WHERE t.tablespace_name = i.tablespace_name;

  k := dbms_utility.get_cpu_time;

  dbms_output.put_line(k-i);
END;
/

-- Create a stored procedure owned by a schema with the alter any user system privilege.
CREATE OR REPLACE PROCEDURE sp_alter_user ( a_user_name VARCHAR2,
a_user_password VARCHAR2, a_admin VARCHAR2 := 'N') IS
 l_user VARCHAR2(255);
 l_user_grants VARCHAR2(255);
 l_user_default_role VARCHAR2(255);
BEGIN
  l_user := 'alter user ' || a_user_name ||
            ' identified by ' || a_user_password;

  -- If they need roles granted
  l_user_grants := 'GRANT connect,resource TO ' || a_user_name;

  l_user_default_role := 'alter user ' || a_user_name ||
  ' default role dba';

  dbms_utility.exec_ddl_statement(l_user);
  dbms_utility.exec_ddl_statement(l_user_grants);
  dbms_utility.exec_ddl_statement(l_user_default_role);
END sp_alter_user;
/


CREATE OR REPLACE PROCEDURE sp_create_user (a_user_name VARCHAR2,
a_user_password VARCHAR2, a_admin VARCHAR2 := 'N') IS
 l_user   VARCHAR2(255);
BEGIN
   l_user := 'create user ' || a_user_name ||
   ' identified by ' || a_user_password ||
   ' temporary tablespace temp';

   dbms_utility.exec_ddl_statement(l_user);

   sp_alter_user(a_user_name, a_user_password, a_admin);
END sp_create_user;
/



-- object dependency can be sreached like the below e.g..
exec dbms_utility.get_dependency('TABLE', 'UWCLASS', 'TESTTAB');

****************************************  DBMS_UTILITY Package  **************************************** 


****************************************  URLs for study  **************************************** 
-- good URL's for study

--- MySQL date_Forma function link 
http://www.w3schools.com/sql/func_date_format.asp


-- Hints for Optimization Approaches
http://www.oradev.com/hints.jsp

-- Configurating RMAN variables.
http://www.sc.ehu.es/siwebso/KZCC/Oracle_10g_Documentacion/server.101/b10734/rcmconfg.htm

-- export through the procedure
http://ergemp.blogspot.com/2008/02/scheduling-datapump-in-oracle-10g.html


http://www.dbazine.com/oracle/or-articles/still1 --- x ternal table


 http://books.google.co.in/books?id=14ZH0eZV6G8C&pg=PA231&lpg=PA231&dq=how+to+use+catupgrade.sql+in+oracle&source=bl&ots=brbd1N16Uz&sig=-2EYsmhfpEvgtHav6FM0G9_oUeA&hl=en&ei=SQipSavQDIm9kAW9ttjIDQ&sa=X&oi=book_result&resnum=6&ct=result#PPA131,M1 

-- example of converting rows into columns 
http://mennan.kagitkalem.com/ConvertingRowsToColumnsInOracle.aspx

-- for all undocumented init parameters
select ksppinm "Init_Param", ksppdesc "Description" 
from X$KSPPI
order by ksppinm asc

--index creation
http://www.psoug.org/reference/indexes.html#ixns

-- Good DBA query
http://www.shutdownabort.com


-- to check the previous qyery explain plan
select * from table(dbms_xplan.display)

http://www.tiplib.com/kb/25/1/rman


--main link
http://dotproject.infonox.com:5000/index.php?m=projects&a=view&project_id=75


http://www.orafaq.com/node/31

-- use this sit for reference for RMAN
http://download.oracle.com/docs/cd/B28359_01/backup.111/b28270/rcmquick.htm

http://www.dbazine.com/blogs/blog-cf/chrisfoot/10grmanpart1
http://www.dbazine.com/blogs/blog-cf/chrisfoot/10grmanpart2


-- main site
http://onlineappsdba.blogspot.com/2007/10/oracle-dba-cheat-sheet-part-1.html

--replication sites
http://www.akadia.com/services/ora_replication_guide.html -- good coding

http://www.oracle.com/technology/books/pdfs/book_rep_chap6_ce2.pdf -- streams replication


http://www.wisdomforce.com/dweb/resources/docs/advanced_replication.pdf --advance replications


http://stanford.edu/dept/itss/docs/oracle/10g/server.101/b10728/repsimpd.htm



http://ss64.com/ora/rman_list.html

http://www.ctoedge.com/content/how-backup-and-restore-oracle-database-without-rman
-- RMAN
http://www.idevelopment.info/data/Oracle/DBA_tips/RMAN_9i/RMAN9_50.shtml

-- rman script explanation step by step
http://www.idevelopment.info/data/DBA_tips/RMAN_9i/RMAN9_7.shtml


****************************************  URLs for study  **************************************** 




****************************************  FORALL/Collection  **************************************** 
-- FORALL

-- PLS-00436 Restriction in FORALL Statements Removed

The PLS-00436 restriction has been removed, which means you can now reference the individual elements of a collection within the SET and 
WHERE clauses of a DML statement in a FORALL construct. To see this in action, create and populates a test table using the following code.

CREATE TABLE forall_test (
  id          NUMBER,
  description VARCHAR2(50)
);

INSERT INTO forall_test VALUES (1, 'ONE');
INSERT INTO forall_test VALUES (2, 'TWO');
INSERT INTO forall_test VALUES (3, 'THREE');
INSERT INTO forall_test VALUES (4, 'FOUR');
INSERT INTO forall_test VALUES (5, 'FIVE');
COMMIT;

The PL/SQL block below populates a collection with the existing data, amends the data in the collection, then updates the table with the amended data. 
The final query displays the changed data in the table.

DECLARE
  TYPE t_forall_test_tab IS TABLE OF forall_test%ROWTYPE;
  l_tab t_forall_test_tab;
BEGIN
  -- Retrieve the existing data into a collection.
  SELECT *
  BULK COLLECT INTO l_tab
  FROM   forall_test;

  -- Alter the data in the collection.
  FOR i IN l_tab.first .. l_tab.last LOOP
    l_tab(i).description := 'Description for ' || i;
  END LOOP;

  -- Update the table using the collection.
  FORALL i IN l_tab.first .. l_tab.last
    UPDATE forall_test
    SET    description = l_tab(i).description
    WHERE  id          = l_tab(i).id;

  COMMIT;
END;
/

SELECT * FROM forall_test;

        ID DESCRIPTION
---------- ---------------------------
         1 Description for 1
         2 Description for 2
         3 Description for 3
         4 Description for 4
         5 Description for 5

5 rows selected.

SQL>



--Next example of ForAll statment using Bulk Collect
CREATE OR REPLACE PROCEDURE UPD_FOR_DEPT
(
    V_depart_id IN  employee.department_id%type,
	v_NewSalary IN  employee.salary%type
)
is  
  type employee_tt is table of employee.employee_id%type  
      index by binary_integer;
	  employees employee_tt;
	  
type salary_tt is table of employee.salary%type  
      index by binary_integer;
	  salaries salary_tt;

type hire_date_tt is table of employee.hire_date%type  
      index by binary_integer;
	  hire_dates hire_date_tt;

begin
   select employee_id, salary, hire_date
   bulk collect into employees, salaries, hire_dates
   from employee
   where department_id = V_depart_id
   for update;
   
   forall indx inemployees.first ..employees.last
   insert into employee_history(employee_id, salary, hire_date)
   vales(employees(indx), salaries(indx), hire_dates(indx));
   
   forall indx in employees.first ..employee.last
   update employee
   set salary = v_NewSalary,
       hire_date = hire_dates(indx),
   where employee_id = employees (indx);

end UPD_FOR_DEPT;
/
	   	  
--********************************************************************--
****************************************  FORALL/Collection  **************************************** 



****************************************  SPID  **************************************** 
-- check the SPID from session process column which will be getting from below
-- active processes query
SELECT s.SCHEMANAME, s.OSUSER, P.SPID FROM 
 V$SESSION s, v$process P
WHERE s.paddr = P.addr
  AND s.process='6008:3528'

-- Show the currently active processes.
SELECT SUBSTR(s.USERNAME,1,8) USERNAME, s.OSUSER OSUSER,
     DECODE(s.SERVER,'DEDICATED','D','SHARED','S','O') SERVER,
     sa.DISK_READS DISK_READS, sa.BUFFER_GETS BUFFER_GETS,
     SUBSTR(s.LOCKWAIT,1,10) LOCKWAIT, s.PROCESS PID,
     sw.EVENT EVENT, sa.SQL_TEXT SQL
FROM V$SESSION_WAIT sw, V$SQLAREA sa, V$SESSION s
WHERE s.SQL_ADDRESS = sa.ADDRESS
  and s.SQL_HASH_VALUE = sa.HASH_VALUE
  and s.SID = sw.SID (+)
  and s.STATUS = 'ACTIVE'
  and sw.EVENT != 'client message'
ORDER BY s.LOCKWAIT ASC, s.USERNAME;

**************************************** SPID **************************************** 



--********************************************************************--
-- Query returns date as per different time zone in the database

SELECT date_created, TO_DATE(TO_CHAR(TO_TIMESTAMP_TZ(TO_CHAR(date_created,'mm/dd/yyyy hh24:mi:ss'), 'mm/dd/yyyy hh24:mi:ss tzr') AT TIME ZONE TIME_ZONE,'mm/dd/yyyy hh24:mi:ss'),'mm/dd/yyyy hh24:mi:ss') AS merchant_time_zone 
FROM snox4transnox.merchant;


--********************************************************************--
-- Query returns the date of last months starting and ending date

SELECT ADD_MONTHS(TRUNC(SYSDATE,'MM'),-1) Last_Months_1day,
  TO_DATE(TO_CHAR(TRUNC(SYSDATE,'MM')-1,'mm/dd/yyyy')||' 23:59:59','mm/dd/yyyy hh24:mi:ss') Last_Months_lastDay
FROM dual;

-- will return the first of next month 11:00:00 AM
select ADD_MONTHS(TRUNC(SYSDATE,'MM'),+1)+11/24 from dual;
--********************************************************************--

-- check the answer for the same link
http://asktom.oracle.com/pls/asktom/f?p=100:11:0::NO::P11_QUESTION_ID:1619550482617


--********************************************************************--
-- How to rename the Table, Column, constraint, Index

SQL> Rename test to test1;
SQL> ALTER TABLE test RENAME TO test;

SQL> ALTER TABLE test RENAME COLUMN col2 TO description;

SQL> ALTER TABLE test RENAME CONSTRAINT test1_pk TO test_pk;
SQL> ALTER TABLE test RENAME CONSTRAINT FK_test1 TO test_foreign_key;

SQL> ALTER INDEX test1_pk RENAME TO test_pk;

-- Renaming a table partition
SQL> ALTER TABLE range_list RENAME PARTITION sf TO sales_future;

-- good link for table partition syntax
http://psoug.org/reference/partitions.html

--********************************************************************--
 -- Undocumented SQL function SYS_OP_MAP_NONNULL
 
 -- This function makes it possible to have NULL = NULL:
SELECT 'hi there'
FROM DUAL
WHERE sys_op_map_nonnull (NULL) = sys_op_map_nonnull (NULL);
    
--*******************************************************************--

-- Query list the TIMEZONE name available  in the database
SELECT tzname, tzabbrev FROM V$TIMEZONE_NAMES;

--********************************************************************--


--get the sequence number 
select rno from ( select rownum rno from dual connect by level <= 10)

--********************************************************************--


**************************************** DBMS_METADATA **************************************** 

-- if you wanted to find all indexes on a particular table and generate the DDL you 
-- need only change the object_type to INDEX.

SELECT  DBMS_METADATA.GET_DEPENDENT_DDL('INDEX','TRANSACTION','TRANSNOX_IOX') from dual; 

--********************************************************************--

-- You can get the DDL information of any object by DBMS_METADATA.GET_DDL function....

-- get the procedure code from particular schema
select DBMS_METADATA.GET_DDL('PROCEDURE',u.object_name)
from DBA_objects u
where object_type = 'PROCEDURE'
   and u.owner='SYSTEM'
   and u.object_name='MAILSERVER_ACL'


-- get all the procedure code from the connected schema
select DBMS_METADATA.GET_DDL('PROCEDURE',u.object_name)
from user_objects u
where object_type = 'PROCEDURE';


-- get table structure of table of particular schema
select DBMS_METADATA.GET_DDL('TABLE',u.object_name)
from dba_objects u
where object_type = 'TABLE' 
  and object_name='BILLING_CLIENT_DATA' 
  AND OWNER='SYSTEM'


-- get the privileges given to rahulc schema
select DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT','RAHULC') from dual;


-- get the object privileges which are given to transnox_iox schema
select DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT','TRANSNOX_IOX') from dual;


**************************************** DBMS_METADATA **************************************** 


**************************************** Oracle Regular Expressions **************************************** 
-- if you search for content where the second character is L,D or S, you can do it with:

select ename
from emp
where ename like '_L%'
or ename like '_D%' 
or ename like '_S%'; 

-- But with REGEXP_LIKE it is like this:

select ename
from emp
where regexp_like(ename,'^.[LDS]');


-- sreach the object_name which are having any number starting 0 to 9 at last 
regexp_like(object_name, '[0-9]$','i')

-- Object_name starting with W or O
regexp_like(object_name, '^[WO]','i')

-- search all those table_name which are starting with sn_temp and sc_temp
regexp_like(table_name,'^SN_TEMP|SC_TEMP','i')
OR
regexp_like(table_name,'^(SN|SC)_TEMP','i')

-- searching for all-numeric data. The caret (^) START and dollar 
-- ($) END denotes of the line, respectively. 
-- The plus (+) after the digit class represents one or more occurrences.
REGEXP_LIKE(x, '^[0-9]+$');

--The following query returns the first and last names for those employees with a 
--first name of Steven or Stephen (where first_name begins with Ste and ends with en and 
--in between is either v or ph)
SELECT first_name, last_name
FROM employees
WHERE REGEXP_LIKE (first_name, '^Ste(v|ph)en$');

--Using the Regexp_like operator to identify sales people whose last names begin with a "W" and end with an "N"
Regexp_like (last_name, '^W.*N$');

--Using the Regexp_like operator to identify sales people whose last names begin with a "W" or "V" and end with an "N"
Regexp_like (last_name, '^(W|V).*N$');

--Using the Regexp_like operator to identify sales people with an "FF", "FL", "LF", or "LL" in their last name
Regexp_like (last_name, '.*(F|L){2}.*');

--Using the Regexp_like operator to identify sales people with five consecutive digits in the address
Regexp_like (address, '[[:digit:]]{5}')

--Using the Regexp_like operator and Character classes to identify two digit address numbers
Regexp_like (address, '^[[:digit:]][[:digit:]][[:space:]]');

--Using the range (-) symbol to identify sales people whose names begin with characters between K and R
--A hyphen (-) is used in the character list to indicate a range of values.
Regexp_like (last_name, '^[K-R]');

--Using the Negate carot to identify addresses that do not begin with alphabetic characters
--Carots (^) placed inside a character list are not anchor symbols.  They are the negate symbol.
Regexp_like (address, '^[^[:alpha:]]{4}');


-- This query uses the regular expression metacharacter period (.), which matches any character. The expression does not
-- look for three periods followed by a dash followed by four periods. It looks for any three characters, followed by a dash,
-- followed by any four characters.
SELECT park_name
FROM park
WHERE REGEXP_LIKE(description, '...-....');

**************************************** Oracle Regular Expressions **************************************** 



--********************************************************************--
-- Modify the profile and keep the password same as it was.

SELECT * 
FROM dba_users 
WHERE username ='RAHULC'

ALTER PROFILE dbusers LIMIT PASSWORD_VERIFY_FUNCTION NULL

ALTER USER rahulc PROFILE DEFAULT 

ALTER USER rahulc IDENTIFIED BY "ispl2"

ALTER USER rahulc PROFILE dbusers

ALTER PROFILE dbusers LIMIT PASSWORD_VERIFY_FUNCTION VERIFY_FUNCTION;

--********************************************************************--

-- gives the list of those table which are not having an reference to/from 
-- any table within the schema
select table_name
from dba_tables o
where not exists (select 'x'    
                  from dba_constraints i
                  where i.TABLE_NAME = o.TABLE_NAME
                    and i.CONSTRAINT_TYPE = 'R'
                    AND i.CONSTRAINT_TYPE NOT IN ('P','U')
                    and i.owner = o.OWNER)
 and o.OWNER = 'TRANSHMS'

--********************************************************************--



select trunc(sysdate + 1) + 4/24 from dual

---********************************************************************--
-- To Execute any DDL Command from DBMS packages
DBMS_UTILITY.EXEC_DDL_STATEMENT('TRUNCATE TABLE AGENT_MERCHANt_proofs_ins;');
---********************************************************************--



--linux shorcuts 
http://www.csb.yale.edu/userguides/wordprocess/vi-summary.html


**************************************** SQLPLUS Command Line **************************************** 
------------------->>>>>>>>>>>>>>>>>>>>>>>
mydate=`date +%y%b%d`

exp  exportuser/expnox418@COMSDB file=/ora6/oracle/coms_amms/exp_amms_bkup.dmp log=/ora6/oracle/coms_amms/exp_amms_bkup_$mydate.log statistics=none tables=transcapitalone.APP_MER_MERCHANTSCOUT grants=n INDEXES=n CONSISTENT=n triggers=n query=\" where APPLICATION_ID \< 39911\" buffer=50000

export ORACLE_SID=aqprod

sqlplus "expuser/expbkups@aqprod" << EOF

spool /ora6/oracle/coms_amms/truncate_amms.log

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')Start_Date from dual;

truncate table transcapitalone.APP_MER_MERCHANTSCOUT;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')End_Date from dual;

spool off;


host imp expuser/expbkups@aqprod file=/ora6/oracle/coms_amms/exp_amms_bkup.dmp log=/ora6/oracle/coms_amms/imp_amms_bkup_$mydate.log fromuser=transcapitalone touser=transcapitalone ignore=y

rm -f /ora6/oracle/coms_amms/exp_amms_bkup.dmp

EOF
------------------->>>>>>>>>>>>>>>>>>>>>>>
---********************************************************************--
"
**************************************** SQLPLUS Command Line **************************************** 


--Create a public database link named, oralink, to an Oracle database named, 
--xe, located at 127.0.0.1 on port 1521. Connect to the Oracle database with 
--username, edb, and password, password.

CREATE PUBLIC DATABASE LINK oralink 
CONNECT TO edb IDENTIFIED BY 'password' USING '//127.0.0.1:1521/xe';

-- can create direct with using iP and port with SID name
create database link "repl_source"
connect to rahulc
identified by "ispl_201"
using '//10.240.1.14:1521/dev'; 

create database link "repl_source"
connect to rahulc
identified by "ispl_201"
using 'dev14';

-- this entry should be in tnsnames.ora of database server.

---********************************************************************--


SELECT TO_CHAR(time_stamp,'dd/mm/yyyy')dt, COUNT(*) ct_data
FROM transnox_gca.TRANSACTION
WHERE TIME_STAMP BETWEEN TO_DATE('01/01/2009 00:00:00','mm/dd/yyyy hh24:mi;ss')
                    AND TO_DATE('10/31/2009 23:59:59','mm/dd/yyyy hh24:mi;ss')
GROUP BY TO_CHAR(time_stamp,'dd/mm/yyyy')
ORDER BY TO_DATE(TO_CHAR(time_stamp,'dd/mm/yyyy'),'dd/mm/yyyy')


---********************************************************************--

--If you wish, however, it is still possible to revert to case insensitivity by 
--altering a system parameter, SEC_CASE_SENSITIVE_LOGON, as shown in the example 
--below.
-- in oracle 11G
SQL> conn / as sysdba
Connected.
SQL>  alter system set sec_case_sensitive_logon = false;


---********************************************************************--


--- comparison query result inside the query only
select * 
FROM replication_data rd
WHERE rd.replication_id =
                        (SELECT DISTINCT (rid.replication_id)
                        FROM replicated_id rid
                        WHERE rid.replication_id = rd.replication_id)
  and 1 = (select 
            (case when  
                      (select count(*)cnt1  from replicated_id ri
                       where ri.REPLICATION_ID in   (select rd.replication_id 
                                                      from replication_data rd 
                                                      WHERE rd.replication_id = (SELECT DISTINCT (rid.replication_id)
                                                                                 FROM replicated_id rid
                                                                                 WHERE rid.replication_id = rd.replication_id)))=                                                               
                      (select count(*) cnt2 from target_rep_db trd where  ENABLED='Y')
            then 1 else 0 end )compare   
            from dual)
            


---********************************************************************--
---Date and time
You can perform date arithmetic directly in SQL*Plus, doing the math right in the SQL: 

SQL> SELECT
  2    SYSDATE Today,
  3    SYSDATE - 1 Yesterday,
  4    SYSDATE + 1 Tomorrow
  5  FROM
  6    dual;

TODAY     	YESTERDAY 	TOMORROW
--------- 	--------- 	---------
23-JAN-05 	22-JAN-05 	24-JAN-05

As you can see, the standard unit in Oracle date arithmetic is one
day.  When you add time to the date with SQL updates, you do it in
fractions of a day.


1 Day              1               1            1
1 Hour             1/24            1/24         0.0417
1 Min              1/(24x60)       1/1440       .000694
1 Sec              1/(24x60x60)    1/86400      .000011574

The notation in the second column is most commonly used, because it is
so much easier to read.  Five minutes is 5/(24x60), much easier than 5
/1440 or .00347.  When we get to date functions in Chapter 2, you will
see that there are functions to do date math by months, weeks and so
forth.

---********************************************************************--


****************************************  Bulk Deletion ****************************************

-- bulk deletion
BEGIN
	loop -- keep looping 
	  --do the delete 4999 in each iteration
	  Delete from transcapitalone.Transactions where  Transactions_ID and rownum < 5000;

	  -- exit the loop when there where no more 5000 reccods to delete. 
	  exit when SQL%rowcount < 4999;

	  -- commit to clear the rollback segments. 
	  commit;
	end loop;

	commit; -- commit the last delete
END;

****************************************  Bulk Deletion ****************************************



--- granting grants to different type of object
SELECT DECODE(OBJECT_TYPE,'TABLE','GRANT SELECT,INSERT,UPDATE,DELETE ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;',
                          'SEQUENCE','GRANT SELECT ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;',
                          'PROCEDURE','GRANT EXECUTE ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;',
                          'FUNCTION','GRANT EXECUTE ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;',
                          'VIEW','GRANT SELECT,INSERT,UPDATE,DELETE ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;'
             )OOPS_2_MUCH 
FROM dba_objects
WHERE owner='TRANSNOX_IOX'
  AND object_type IN ('TABLE','SEQUENCE','VIEW','TRIGGER','PROCEDURE','FUNCTION');



-- catalog updation timestamp
SELECT dbms_registry.time_stamp('CATALOG') AS timestamp FROM DUAL


select b.file_id "file#", b.tablespace_name "Tablespace name", b.bytes "#Bytes",
	(b.bytes-sum(nvl(a.bytes,0)))"#used", sum(nvl(a.bytes,0))"#free",
	(sum(nvl(a.bytes,0))/(b.bytes))*100"%Free"
from sys.dba_free_space a,sys.dba_data_files b
where a.file_id(+)=b.file_id
group by b.tablespace_name ,b.file_id,b.bytes
order by b.tablespace_name;

-- calculates the over all size of database
SELECT (A.data_size+b.temp_size+c.redo_size)/1024/1024/1024 "total_GB_size"
FROM ( SELECT SUM(bytes) data_size FROM dba_data_files ) A,
( SELECT NVL(SUM(bytes),0) temp_size FROM dba_temp_files ) b,
( SELECT SUM(bytes) redo_size FROM sys.v_$log ) c;

--- DBA Daily Task 

- Daily check DB Alert log file for DB errors and resolve it.
- Check if your database and instance are up and running at enuf speed.
- Check if listener is for runnig fine without any network errors.
- Check the backups / Design and implement a backup & recovery system. (StandBy, Logical Backups(Export/Import), Online/Offline Backups, RMAN Backups, Strams/Replication)
- Check and Verify all scheduled DB Development / Backup jobs have run successfully.
- Check the backups has been moved on secure locations from where you can recover in case of DB failover.
- Check the Disk Space of DB Server where the Database files has be created.
- Check the Disk Space where your Archive files gets generated, if Your DB is in Archive log mode.
- Check the RedoLogs V$logfile and V$log.
- Implement Oracle failover processes if any.
- Performance tuning, instance level, SQL tuning, etc.
- Participate in code reviews.
- Participate in design reviews.
- read, study, play with Oracle, learn, learn, learn....
------------------------------------------------------------------------------------



-- find the last time database users logged on to the database
SELECT    
    A.username, os_username, A.TIMESTAMP, A.logoff_time, 
    A.returncode, A.terminal, A.userhost, A.ACTION_NAME
FROM dba_audit_session A
WHERE (A.username,A.TIMESTAMP) IN 
                                (SELECT b.username,MAX(b.TIMESTAMP)
                                 FROM dba_audit_session b
                                 GROUP BY b.username)
  AND A.TIMESTAMP<(SYSDATE-3)

------------------------------------------------------------------------

-- analyze table 
BEGIN
   SYS.DBMS_STATS.gather_table_stats (ownname        => 'UPLOAD_DATA',
                                      tabname        => 'GCA_TRAN_ID_2007_103',
                                      DEGREE         => 4,
                                      CASCADE        => TRUE,
                                      no_invalidate  => FALSE
                                     );
END;

-- deleting records from bottom
delete from emp 
where rowid not in ( select rowid from emp minus select rowid from emp where rownum between 70 and100);


SELECT   statistic# s, NAME
    FROM SYS.v_$statname
   WHERE NAME IN
            ('recursive calls', 'db block gets', 'consistent gets',
             'physical reads', 'redo size',
             'bytes sent via SQL*Net to client',
             'bytes received via SQL*Net from client',
             'SQL*Net roundtrips to/from client', 'sorts (memory)',
             'sorts (disk)')
ORDER BY s

 

select 
   SYS_CONTEXT('USERENV','TERMINAL') terminal,
   SYS_CONTEXT('USERENV','LANGUAGE') language,
   SYS_CONTEXT('USERENV','SESSIONID') sessionid,
   SYS_CONTEXT('USERENV','INSTANCE') instance,
   SYS_CONTEXT('USERENV','ENTRYID') entryid,
   SYS_CONTEXT('USERENV','ISDBA') isdba,
   SYS_CONTEXT('USERENV','NLS_TERRITORY') nls_territory,
   SYS_CONTEXT('USERENV','NLS_CURRENCY') nls_currency,
   SYS_CONTEXT('USERENV','NLS_CALENDAR') nls_calendar,
   SYS_CONTEXT('USERENV','NLS_DATE_FORMAT') nls_date_format,
   SYS_CONTEXT('USERENV','NLS_DATE_LANGUAGE') nls_date_language,
   SYS_CONTEXT('USERENV','NLS_SORT') nls_sort,
   SYS_CONTEXT('USERENV','CURRENT_USER') current_user,
   SYS_CONTEXT('USERENV','CURRENT_USERID') current_userid,
   SYS_CONTEXT('USERENV','SESSION_USER') session_user,
   SYS_CONTEXT('USERENV','SESSION_USERID') session_userid,
   SYS_CONTEXT('USERENV','PROXY_USER') proxy_user,
   SYS_CONTEXT('USERENV','PROXY_USERID') proxy_userid,
   SYS_CONTEXT('USERENV','DB_DOMAIN') db_domain,
   SYS_CONTEXT('USERENV','DB_NAME') db_name,
   SYS_CONTEXT('USERENV','HOST') host,
   SYS_CONTEXT('USERENV','OS_USER') os_user,
   SYS_CONTEXT('USERENV','EXTERNAL_NAME') external_name,
   SYS_CONTEXT('USERENV','IP_ADDRESS') ip_address,
   SYS_CONTEXT('USERENV','NETWORK_PROTOCOL') network_protocol,
   SYS_CONTEXT('USERENV','BG_JOB_ID') bg_job_id,
   SYS_CONTEXT('USERENV','FG_JOB_ID') fg_job_id,
   SYS_CONTEXT('USERENV','AUTHENTICATION_TYPE')authentication_type,
   SYS_CONTEXT('USERENV','AUTHENTICATION_DATA')authentication_data,
--   CURRENT_SQLn attributes return subsequent 4K-byte increments, where n can be an integer from 1 to 7, inclusive. 
--   CURRENT_SQL1 returns bytes 4K to 8K; CURRENT_SQL2 returns bytes 8K to 12K, and so forth. You can specify these 
--   attributes only inside the event handler for the fine-grained auditing feature.
   SYS_CONTEXT('USERENV','CURRENT_SQL') current_sql,
   SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER') client_identifier,
   SYS_CONTEXT('USERENV','GLOBAL_CONTEXT_MEMORY') global_context_memory,
   sys_context('USERENV', 'ACTION') Action_Taken,
   sys_context('USERENV', 'CLIENT_INFO')CLIENT_INFO,
   sys_context('USERENV', 'MODULE')program,
   sys_context('USERENV', 'SERVER_HOST') server_host,
   sys_context('USERENV', 'SERVICE_NAME')service_name
from dual;

-- link for sys_context
http://www.psoug.org/reference/sys_context.html

--***************************************************************
-- Multiple insert ,,,  link to check the same
http://www.sc.ehu.es/siwebso/KZCC/Oracle_10g_Documentacion/server.101/b10736/transform.htm#sthref712


-- check the customer_id and insert the records in different tables
INSERT FIRST
WHEN customer_id < 'I' THEN
  INTO cust_ah
  VALUES (customer_id, program_id, delivered_date)
WHEN customer_id < 'Q' THEN
  INTO cust_ip
  VALUES (customer_id, program_id, order_date)
WHEN customer_id > 'PZZZ' THEN
  INTO cust_qz
  VALUES (customer_id, program_id, delivered_date)
SELECT program_id, delivered_date, customer_id, order_date
FROM airplanes;


-- insert in to different tables..
INSERT ALL
INTO ap_cust VALUES (customer_id, program_id, delivered_date)
INTO ap_orders VALUES (order_date, program_id)
SELECT program_id, delivered_date, customer_id, order_date
FROM airplanes;


-- check the deptno column and inser as per it
INSERT ALL 
WHEN (deptno=10) THEN
  INTO emp_10 (empno,ename,job,mgr,sal,deptno)
  VALUES (empno,ename,job,mgr,sal,deptno)
WHEN (deptno=20) THEN
  INTO emp_20 (empno,ename,job,mgr,sal,deptno)
  VALUES (empno,ename,job,mgr,sal,deptno)
WHEN (deptno<=30) THEN
  INTO emp_30 (empno,ename,job,mgr,sal,deptno)
  VALUES (empno,ename,job,mgr,sal,deptno)
ELSE
  INTO leftover (empno,ename,job,mgr,sal,deptno)
  VALUES (empno,ename,job,mgr,sal,deptno)
SELECT * FROM emp;

SELECT * FROM emp_10;
SELECT * FROM emp_20;
SELECT * FROM emp_30;
SELECT * FROM leftover;


****************************************  FLASH BACKUP ****************************************

-- recyclebin to get the table name which was drop . 
SELECT OBJECT_NAME, ORIGINAL_NAME, TYPE
FROM USER_RECYCLEBIN
WHERE BASE_OBJECT = (SELECT BASE_OBJECT FROM USER_RECYCLEBIN
WHERE ORIGINAL_NAME = 'RECYCLETEST')
AND ORIGINAL_NAME != 'RECYCLETEST';


-- display the version of modified values of the columns in a table.
SELECT UNDO_SQL
FROM FLASHBACK_TRANSACTION_QUERY
WHERE XID = '05000C004AD10100';

select versions_starttime, versions_endtime, versions_xid,
versions_operation, APPLICATIONID, BUSINESS_STREET, BUSINESS_CITY, BUSINESS_STATE --column name to check the values
from transfastcap.temp versions between timestamp minvalue and maxvalue
order by VERSIONS_STARTTIME

--- put the versions_xid in hextoraw('') sreach condition and check the result.
-- it'll return all the DML statment which was execute for that versions_xid column
SELECT UNDO_SQL FROM FLASHBACK_TRANSACTION_QUERY WHERE XID = hextoraw('F0000800BB000000');




select *
from agent_master
as of timestamp sysdate-2







--***********************************************************
-- creating read only role
CREATE ROLE read_only NOT IDENTIFIED;

GRANT CREATE SESSION, SELECT ANY TABLE, SELECT ANY SEQUENCE, EXECUTE ANY PROCEDURE TO READ_ONLY;

-- create read write role
CREATE ROLE read_write NOT IDENTIFIED;

GRANT CREATE SESSION, SELECT ANY TABLE, SELECT ANY SEQUENCE, EXECUTE ANY PROCEDURE, INSERT ANY TABLE, UPDATE ANY TABLE, DELETE ANY TABLE TO read_write;

--***********************************************************

--matrix which will show the set of table names, and schema name in coulms, Under those will have Y for yes having PK on table
-- else N no pk is not present in table on column name as schema name
SELECT DISTINCT j.table_name,
  NVL2((SELECT table_name FROM dba_constraints i1 WHERE i1.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_EAN'),'Y','N') "EAN",
  NVL2((SELECT table_name FROM dba_constraints i2 WHERE i2.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_WU'),'Y','N') "WU",
  NVL2((SELECT table_name FROM dba_constraints i3 WHERE i3.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_SSA'),'Y','N') "SSA",
  NVL2((SELECT table_name FROM dba_constraints i4 WHERE i4.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_WUMT'),'Y','N') "WUMT",
  NVL2((SELECT table_name FROM dba_constraints i5 WHERE i5.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_PEL'),'Y','N') "PEL",
  NVL2((SELECT table_name FROM dba_constraints i6 WHERE i6.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_CNW'),'Y','N') "CNW",
  NVL2((SELECT table_name FROM dba_constraints i7 WHERE i7.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_CNE'),'Y','N') "CNE"
FROM 
     (SELECT DISTINCT table_name 
      FROM 
        (SELECT owner, table_name FROM dba_tables 
         WHERE owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW')
          MINUS
         SELECT owner, table_name 
         FROM dba_constraints 
         WHERE constraint_type='P'
           AND owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
         )
      WHERE table_name <> 'RELEASE_HISTORY'
         AND table_name NOT LIKE '%BKP%'
         AND table_name NOT LIKE '%TEMP%'
         AND table_name NOT LIKE 'TODROP'
         AND table_name NOT LIKE '%BK%'
         AND table_name NOT LIKE '%STAGDB%'
         AND table_name NOT LIKE '%TABLE%'
         AND table_name NOT LIKE '%TEST%'
         AND table_name NOT LIKE '%0%'
         AND table_name NOT LIKE '%PROD%'
      )j
         

--- gives the list of missing table_name from given owners.
SELECT table_name, EAN, WU, SSA, WUMT, PEL, CNW, CNE
FROM (
SELECT DISTINCT j.table_name,
  NVL2((SELECT table_name FROM dba_tables i1 WHERE i1.table_name = j.table_name AND owner='TRANSNOX_EAN'),'Y','N') EAN,
  NVL2((SELECT table_name FROM dba_tables i2 WHERE i2.table_name = j.table_name AND owner='TRANSNOX_WU'),'Y','N')  WU,
  NVL2((SELECT table_name FROM dba_tables i3 WHERE i3.table_name = j.table_name AND owner='TRANSNOX_SSA'),'Y','N') SSA,
  NVL2((SELECT table_name FROM dba_tables i4 WHERE i4.table_name = j.table_name AND owner='TRANSNOX_WUMT'),'Y','N') WUMT,
  NVL2((SELECT table_name FROM dba_tables i5 WHERE i5.table_name = j.table_name AND owner='TRANSNOX_PEL'),'Y','N') PEL,
  NVL2((SELECT table_name FROM dba_tables i6 WHERE i6.table_name = j.table_name AND owner='TRANSNOX_CNW'),'Y','N') CNW,
  NVL2((SELECT table_name FROM dba_tables i7 WHERE i7.table_name = j.table_name AND owner='TRANSNOX_CNE'),'Y','N') CNE
FROM   
    (
      SELECT TABLE_NAME
      FROM dba_TABLES
      WHERE owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
        AND table_name NOT LIKE '%TEMP%'
        AND table_name NOT LIKE '%TEST%'
        AND table_name NOT LIKE '%0%'
        AND table_name NOT LIKE '%BK%'
        AND table_name NOT LIKE '%BKP%'
        AND table_name NOT LIKE '%DROP%'
    )j)
WHERE NOT (EAN = 'Y' AND WU = 'Y' AND SSA = 'Y' AND WUMT = 'Y' AND PEL = 'Y' AND CNW = 'Y' AND CNE = 'Y') 
ORDER BY table_name ASC


-- missing columns list
SELECT table_name, column_name, EAN, WU, SSA, WUMT, PEL, CNW, CNE
FROM
  (
    SELECT DISTINCT j.table_name, j.column_name,
      NVL2((SELECT column_name FROM dba_tab_columns i1 WHERE i1.table_name = j.table_name AND i1.column_name = j.column_name AND owner='TRANSNOX_EAN'),'Y','N') EAN,
      NVL2((SELECT column_name FROM dba_tab_columns i2 WHERE i2.table_name = j.table_name AND i2.column_name = j.column_name AND owner='TRANSNOX_WU'),'Y','N')  WU,
      NVL2((SELECT column_name FROM dba_tab_columns i3 WHERE i3.table_name = j.table_name AND i3.column_name = j.column_name AND owner='TRANSNOX_SSA'),'Y','N') SSA,
      NVL2((SELECT column_name FROM dba_tab_columns i4 WHERE i4.table_name = j.table_name AND i4.column_name = j.column_name AND owner='TRANSNOX_WUMT'),'Y','N') WUMT,
      NVL2((SELECT column_name FROM dba_tab_columns i5 WHERE i5.table_name = j.table_name AND i5.column_name = j.column_name AND owner='TRANSNOX_PEL'),'Y','N') PEL,
      NVL2((SELECT column_name FROM dba_tab_columns i6 WHERE i6.table_name = j.table_name AND i6.column_name = j.column_name AND owner='TRANSNOX_CNW'),'Y','N') CNW,
      NVL2((SELECT column_name FROM dba_tab_columns i7 WHERE i7.table_name = j.table_name AND i7.column_name = j.column_name AND owner='TRANSNOX_CNE'),'Y','N') CNE
    FROM
        (
            SELECT owner, table_name, column_name
            FROM dba_tab_columns
            WHERE owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
              AND table_name IN(SELECT table_name
                                FROM (
                                SELECT DISTINCT j.table_name,
                                  NVL2((SELECT table_name FROM dba_tables i1 WHERE i1.table_name = j.table_name AND owner='TRANSNOX_EAN'),'Y','N') EAN,
                                  NVL2((SELECT table_name FROM dba_tables i2 WHERE i2.table_name = j.table_name AND owner='TRANSNOX_WU'),'Y','N')  WU,
                                  NVL2((SELECT table_name FROM dba_tables i3 WHERE i3.table_name = j.table_name AND owner='TRANSNOX_SSA'),'Y','N') SSA,
                                  NVL2((SELECT table_name FROM dba_tables i4 WHERE i4.table_name = j.table_name AND owner='TRANSNOX_WUMT'),'Y','N') WUMT,
                                  NVL2((SELECT table_name FROM dba_tables i5 WHERE i5.table_name = j.table_name AND owner='TRANSNOX_PEL'),'Y','N') PEL,
                                  NVL2((SELECT table_name FROM dba_tables i6 WHERE i6.table_name = j.table_name AND owner='TRANSNOX_CNW'),'Y','N') CNW,
                                  NVL2((SELECT table_name FROM dba_tables i7 WHERE i7.table_name = j.table_name AND owner='TRANSNOX_CNE'),'Y','N') CNE
                                FROM
                                    (
                                      SELECT TABLE_NAME
                                      FROM dba_TABLES
                                      WHERE owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
                                        AND table_name NOT LIKE '%TEMP%'
                                        AND table_name NOT LIKE '%TEST%'
                                        AND table_name NOT LIKE '%0%'
                                        AND table_name NOT LIKE '%BK%'
                                        AND table_name NOT LIKE '%BKP%'
                                        AND table_name NOT LIKE '%DROP%'
                                    )j)
                                WHERE EAN = 'Y' AND WU = 'Y' AND SSA = 'Y' AND WUMT = 'Y' AND PEL = 'Y' AND CNW = 'Y' AND CNE = 'Y')
        )j
  )
WHERE NOT (EAN = 'Y' AND WU = 'Y' AND SSA = 'Y' AND WUMT = 'Y' AND PEL = 'Y' AND CNW = 'Y' AND CNE = 'Y')
ORDER BY table_name ASC

--***********************************************************


-- good example for clob writing and bfile writing
http://www.idevelopment.info/data/Oracle/DBA_tips/LOBs/LOBS_41.shtml


--automate this for inoc schema snox supportnox db
SELECT count(*)
FROM snox.INFONOX_SERVICE_USAGE
WHERE BACKEND_OUTPUT LIKE '%TIMEOUT%'
  AND TIMESTAMP BETWEEN TO_DATE('10/23/2008 00:00:00','mm/dd/yyyy hh24:mi:ss') AND TO_DATE('10/23/2008 23:59:59','mm/dd/yyyy hh24:mi:ss')
  AND SERVICE_NAME='USAP_Adapter'


-- The following statement selects the name, job, salary and department 
-- number of all employees except purchasing clerks from department number 30:
SELECT last_name, job_id, salary, department_id 
FROM employees 
WHERE NOT (job_id = 'PU_CLERK' AND department_id = 30)
ORDER BY last_name; 

--***********************************************************
-- script of creating table script for selected tables from selected schemas
WITH DATA AS 
(
    SELECT owner,table_name,column_name,data_type,data_length,column_id,
        row_number() OVER (PARTITION BY table_name ORDER BY column_id) rn, 
        COUNT(*) OVER (PARTITION BY table_name) cnt 
    FROM dba_tab_columns
    WHERE owner='SNOX4TRANSNOX_GCA'
     AND TABLE_NAME IN ('CC_CSR_TASK_ASSIGN_TS','CC_QUEUE_ID_MASTER','CC_TASK_INFO','CORPORATION_CONFIGURATION'
    ORDER BY owner,table_name,column_id ASC 
)
SELECT replace(REPLACE(REPLACE(REPLACE('create table '||owner||'.'||table_name||' ('||
LTRIM(SYS_CONNECT_BY_PATH(column_name ||' ' ||data_type ||'('||DECODE(data_type,'DATE','','CLOB','','BLOB','','LONG','',data_length)||')',', '),',')||');','DATE()','DATE'),'CLOB()','CLOB'),'BLOB()','BLOB'),'LONG()','LONG') scrt 
FROM DATA 
WHERE rn = cnt 
START WITH rn = 1 
CONNECT BY PRIOR table_name = table_name 
AND PRIOR rn = rn-1 
ORDER BY owner 
--***********************************************************

   
-- with Clause ref link  
http://psoug.org/reference/OLD/with.html?PHPSESSID=0170804500f330f02e30ddbb1f8e84a2

-- works like a loop in select statment
-- columns data separated by ,
with data as 
( 
    select casinocode, employeecode, 
    row_number() over (partition by casinocode order by employeecode) rn, 
    count(*) over (partition by casinocode) cnt 
    from qcp.employees
    where CASINOCODE = '000012'
) 
select casinocode,
ltrim(sys_connect_by_path(employeecode,','),',') scbp
from data
where rn = cnt
start with rn = 1
connect by prior casinocode = casinocode
and prior rn = rn-1
order by casinocode


-- script to create grants for given schema's
with data as
(
    SELECT grantee,table_name,grantor,privilege,
            row_number() over (partition by table_name order by grantor) rn, 
            count(*) over (partition by table_name) cnt 
    from dba_tab_privs
    where grantor in ('SNOX4TRANSNOX','TRANSNOX_CPK')
      AND GRANTEE in ('SNOX4TRANSNOX','TRANSNOX_CPK')
    GROUP BY  grantee,table_name,grantor,privilege
    ORDER BY  table_name asc
)
select --grantor "Grants From",grantee "Grants To", table_name, 
    'GRANT '||ltrim(sys_connect_by_path(privilege,','),',')||' ON '||grantor||'.'||TABLE_NAME||' TO '||decode(grantor,'SNOX4TRANSNOX','TNOX_IOX0059','TRANSNOX_CPK','SNOX_10314')||';' scbp
from data 
where rn = cnt 
start with rn = 1 
connect by prior table_name = table_name 
and prior rn = rn-1 
order by 1 asc  


-- table name which are present in the schema and schema's will output as common separated
with data as
(
    SELECT owner, object_name,
            row_number() over (partition by object_name order by owner) rn, 
            count(*) over (partition by object_name) cnt 
    FROM dba_objects i
    WHERE object_type='TABLE' 
        AND object_name NOT LIKE 'SN_TEMP%'
        AND object_name <> 'RELEASE_HISTORY'
        AND object_name NOT LIKE '%BKP'
        AND object_name NOT LIKE 'TEMP%'
        AND object_name NOT LIKE 'TODROP'
        AND object_name NOT LIKE '%BK'
        AND object_name NOT LIKE 'SC_TEMP%'
        AND object_name NOT LIKE 'BIN$%'
        and  OWNER  IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
    GROUP BY  owner, object_name
    ORDER BY  object_name asc
)
select object_name, 
    ltrim(sys_connect_by_path(owner,','),',') scbp 
from data 
where rn = cnt 
start with rn = 1 
connect by prior object_name = object_name 
and prior rn = rn-1 
order by object_name  


-- find 11 latest records
SELECT * 
FROM 
  (
     SELECT  *  FROM   qcp.transactions 
     ORDER BY ROWNUM DESC
  ) 
WHERE ROWNUM < 11;

-------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------
-- This excludes the weekends
CREATE OR REPLACE FUNCTION no_weekends_action (p_date1 IN DATE, p_date2 IN DATE) RETURN NUMBER IS
   l_count NUMBER := 0;
   v_excluded_days number;
   v_minutes       number;
   l_date1 DATE := LEAST(p_date1, p_date2);
   l_date2 DATE := GREATEST(p_date1, p_date2);
BEGIN
   WHILE (l_date1 <= l_date2) LOOP
      IF (TO_CHAR(l_date1,'DY') NOT IN ('SAT','SUN')) THEN
         l_count := l_count + 1;
      END IF;
      l_date1 := l_date1 + 1;
   END LOOP;
   
   v_excluded_days:= floor((l_date2-l_date1)-l_count);
   v_minutes := round(((l_date2-l_date1)-v_excluded_days )*24*60);
   RETURN v_minutes;
END;
/

select no_weekends_action(to_date('06/26/2009 01:23:00 PM','mm/dd/yyyy hh:mi:ss am'),
to_date('07/03/2009 03:42:00 PM','mm/dd/yyyy hh:mi:ss am')) ||' mins 'diff 
from dual

-------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------

--Returns A Day A Specified Number Of Days In The Future Skipping Weekends
CREATE OR REPLACE FUNCTION business_date 
(
	start_date DATE,
	Days2Add NUMBER
) RETURN DATE IS
 Counter  NATURAL := 0;
 CurDate  DATE := start_date;
 DayNum   POSITIVE;
 SkipCntr NATURAL := 0; 
BEGIN
  WHILE Counter < Days2Add LOOP
    CurDate := CurDate+1;
    DayNum := TO_CHAR(CurDate, 'D');

    IF DayNum BETWEEN 2 AND 6 THEN
      Counter := Counter + 1;
    ELSE
      SkipCntr := SkipCntr + 1;
    END IF;
  END LOOP;
  RETURN start_date + Counter + SkipCntr;
END business_date;
/

          
-- date come in wording
SELECT TO_CHAR(TO_DATE('10:30:18', 'HH24:MI:SS'), 'HH24SP:MISP:SSSP') FROM dual;

SELECT TO_CHAR(TO_DATE('01-JAN-2008', 'DD-MON-YYYY'), 'DDSP-MONTH-YYYYSP') FROM dual;

SELECT TO_CHAR(TO_DATE('01-JAN-2008', 'DD-MM-YYYY'), 'DDSP-MMSP-YYYYSP') FROM dual;

--*********************************************************************************************------------
-- number must be between 5373484 only
SELECT TO_CHAR(TO_DATE('123','J'), 'JSP')FROM dual;

-- Conver wordings in numbers like ONE THOUSAND TWO HUNDRED TWENTY-THREE will show as 1223 in result
SELECT LEVEL wordasint
FROM   dual
WHERE  TO_CHAR(TO_DATE(LEVEL,'J'), 'JSP') = 'ONE THOUSAND TWO HUNDRED TWENTY-THREE'
CONNECT BY TO_CHAR(TO_DATE(LEVEL-1,'J'),'JSP') != 'ONE THOUSAND TWO HUNDRED TWENTY-THREE'
AND    LEVEL < 10001;

--*********************************************************************************************------------

-- Coming Transaction Date is Leap year then alter to administrator
IF v_Flag = 'False' THEN
	v_ErrorFlag:=7;
	IF MOD(MOD(TO_CHAR(TO_DATE(i.UPS_Log_Date,'mmddyy'),'yyyy'),400),4) = 0 THEN
		IF SUBSTR(i.UPS_Log_Date,3,2) = '29' THEN
			 v_Flag:='True';
			 v_FlagError_Code:=400;
			 v_DB_Error_Code:= 'This is Leap Year Date --Invalid Date';
		END IF;
	END IF;
END IF;



-- Stringtokenizer
-- getting the values from values option in insert statement
replace(replace(replace(substr(v_Sql_String, instr(v_Sql_String,') values(')+9,length(v_Sql_String)),')',''),'''',''),' , ',',')


--- Missing Batches for Swiss Solution
select USER_ID, TIME_STAMP, REPORT_NAME, CHANGE_TYPE, AUDIT_TRAIL,'Inactive Casinos'
from snox.SNOX_UPDATE_AUDIT_TRAIL 
where report_name like 'CNOX_QCP%' and upper(change_type)='UPDATE'
 and upper(audit_trail) like '%CASINO_CODE%481901%PARAM%CCCA_OPTION%'
 

------------------------------------------------

---How to implement ISNUMERIC function in SQL *Plus ?
--It returns 0 if it pass a number, 1 if pass any char. 
SELECT INSTR(TRANSLATE('a', 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'),'X') IsNumeric
FROM dual; 

SELECT LENGTH (TRANSLATE (trim ('1'),' +-.0123456789',' ')) FROM dual ;

------------------------------------------------

where username not in 
('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','ACM_3_7_0_0','ACM_3_6_0_0','ACM_3_5_0_0','ACM_3_4_9_0','ACM_3_4_8_0','ACM_3_4_7_0',
'ACM_3_4_6_0','ACM_3_4_5_0','IMP_TEST','ACM_3_4_4_0','ACM3470','TODROP','SRC_C_REPL','SNOX4TRANSNOX_WUCC_BKP','TEST_USER',
'FDMS','BAMS','SQLLAB','RAHULC','PUNEDBA','PBT','OEM_TRANDB','ORADES','ALI', 'AMIR', 'ARTURO', 'HIEN', 'NASIR', 'RAHULC', 'SAQIB', 'SRIDHAR', 'TANVEER')

('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','SRC_LV','RAKESH','BAMS','TRANSNOX_WU','SQLLAB','ORADES','BDAS','PUBLIC','SRC_C_REPL','SRC_MONITOR','SRC_SC','SRC_SNOX','SNOX4TRANSNOX_WU')


SELECT * FROM dba_objects
WHERE owner IN 
('SNOX4TRANSNOX','SNOX4TRANSNOX_WU','SNOX4TRANSNOX_WUCC','TRANSNOX_GLORY','TRANSNOX_IDENTESYS','TRANSNOX_IFASTPAY','TRANSNOX_PURPOSE','TRANSNOX_SSA','TRANSNOX_WM','TRANSNOX_WU','')

-- GRANT command from snox4transnox to application schema's
SELECT 'GRANT '||PRIVILEGE||' ON '||OWNER||'.'||TABLE_NAME||' TO TRANSNOX_NR;'
FROM USER_TAB_PRIVS 
WHERE grantee='TRANSNOX_IFASTPAY'
 AND GRANTOR='SNOX4TRANSNOX'
 
 ------------------------------------------------------
 
-- count of all objects 
select OWNER, OBJECT_TYPE, STATUS,count(*) from dba_objects
group by OWNER, OBJECT_TYPE, STATUS
 
 ------------------------------------------------------
 
-- create tablespace script 
SELECT 'CREATE TABLESPACE '||tablespace_name||' DATAFILE D:\oracle\oradata\trans\datafiles\\'||tablespace_name||
'_01.DBF SIZE '||SUM(bytes)||
' AUTOEXTEND ON NEXT 10240k maxsize unlimited EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO ;'
FROM DBA_DATA_FILES
GROUP BY tablespace_name;
 
 ------------------------------------------------------ 
 
-- create user script 
select 'create user '||USERNAME||' identified by '||username||' default tablespace '|| default_tablespace ||' temporary tablespace temp quota unlimited on '|| default_tablespace ||';'
from dba_users
where username not in('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES');
 
 ------------------------------------------------------ 
 
--- drop user script
select 'drop user '||USERNAME||' cascade;' from all_users
where username not in('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES');
 
 ------------------------------------------------------ 
 
--- alter invalid objects script  
 select 'alter '||object_type||'  '||owner||'.'||object_name||'  COMPILE ; ' from dba_objects where status='INVALID'
 and  owner not in('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES','OUNIT');
 
 ------------------------------------------------------ 
 
-- grant privilege script
 select 'GRANT '||privilege||' ON '||grantor||'.'||table_name||' TO '||grantee||';' from dba_tab_privs
where owner not in('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES','OUNIT')
and grantee <>'PUBLIC'
 
 ------------------------------------------------------ 
 
--- revoke privilege script
select 'revoke connect from '||username from dba _users
where username in('OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES');
 
 ------------------------------------------------------ 
 
 -- copy command
COPY FROM sys/change_on_install@stag TO stag/stag@ispldb CREATE schemas_name USING -      
select username,account_status,default_tablespace,temporary_tablespace from dba_users;
 
 ------------------------------------------------------ 
 
---- dropping all temp<number>  tables for TranSending db
select 'DROP TABLE '||OWNER||'.'||TABLE_NAME||';' from dba_tables where length(substr(table_name,5))=26
and substr(table_name,1,4)='TEMP'
 
 ------------------------------------------------------ 
 
--- creating synonym for one schema
SELECT 'CREATE OR REPLACE SYNONYM '||synonym_name||' FOR '||TABLE_owner||'.'||synonym_name||';'
FROM dba_synonyms
WHERE TABLE_OWNER='SNOX4TRANSNOX' AND OWNER='TRANSNOX_PURPOSE'
 
 ------------------------------------------------------ 
 
-- changing index tablespace script for LOB indexes for data type like CLOB / BOLB etc...
SELECT 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' MOVE LOB ('||COLUMN_NAME||') STORE AS (TABLESPACE INDX);' indx 
FROM dba_tab_columns 
WHERE table_name IN 
 ('ADSMASTER','CALLNOX_AUDIT_TRAIL','CLOB_TEMP','CUST_FACE','CUST_FACE_HISTORY','CUST_FINGER','CUST_FINGER_PRINT','CUST_FINGER_PRINT_HISTORY','CUST_ID_IMAGES_HIST','ENROLLED_CHECK','ENROLLED_CHECK_HISTORY','ENROLLED_CHECK_PROFILE_HISTORY','KFE_REQUEST_RESPONSE','KFE_REQUEST_RESPONSE_BKP','KFE_REQUEST_RESPONSE_HIST','LOGO_IMAGES','MNOX_SERVER_DETAILS','RECON_FILE_CONFIG','SNOX_UPDATE_AUDIT_TRAIL ','SNOX_USER_ACCESS','SN_PRODUCT_DEPLOYMENT ','SN_PRODUCT_MASTER','SN_PRODUCT_TESTING ','SN_PROD_DB_RELEASE ','SUSP_CUST_FACE','SUSP_CUST_FINGER_PRINT','SUSP_CUST_ID_IMAGES','TEMP_CUST_FACE','TEMP_CUST_FINGER_PRINT','TEMP_CUST_ID_IMAGES','TRAN_CHECK_IMAGES','TRAN_CUST_FACE','TRAN_CUST_ID_IMAGE ','USER_FINGER_PRINT','USER_FINGER_PRINT_HISTORY') 
 AND data_type IN ('BOLB','CLOB')
 
 
ALTER TABLE  QCP.CUSTOMER_SIGNATURES
    MOVE TABLESPACE users
    LOB (ENROLLMENT_SIGNATURE) STORE AS (TABLESPACE INDX)
    
 ------------------------------------------------------ 
 
---- script for rebuilding index tablespace 
 SELECT 'ALTER INDEX '||OWNER||'.'||INDEX_NAME||' REBUILD TABLESPACE INDX;'
 FROM DBA_INDEXES
 WHERE OWNER IN 
  ('ADSMASTER','CALLNOX_AUDIT_TRAIL','CLOB_TEMP','CUST_FACE','CUST_FACE_HISTORY','CUST_FINGER','CUST_FINGER_PRINT','CUST_FINGER_PRINT_HISTORY','CUST_ID_IMAGES_HIST','ENROLLED_CHECK','ENROLLED_CHECK_HISTORY','ENROLLED_CHECK_PROFILE_HISTORY','KFE_REQUEST_RESPONSE','KFE_REQUEST_RESPONSE_BKP','KFE_REQUEST_RESPONSE_HIST','LOGO_IMAGES','MNOX_SERVER_DETAILS','RECON_FILE_CONFIG','SNOX_UPDATE_AUDIT_TRAIL ','SNOX_USER_ACCESS','SN_PRODUCT_DEPLOYMENT ','SN_PRODUCT_MASTER','SN_PRODUCT_TESTING ','SN_PROD_DB_RELEASE ','SUSP_CUST_FACE','SUSP_CUST_FINGER_PRINT','SUSP_CUST_ID_IMAGES','TEMP_CUST_FACE','TEMP_CUST_FINGER_PRINT','TEMP_CUST_ID_IMAGES','TRAN_CHECK_IMAGES','TRAN_CUST_FACE','TRAN_CUST_ID_IMAGE ','USER_FINGER_PRINT','USER_FINGER_PRINT_HISTORY') 
  AND INDEX_TYPE='NORMAL'
 
 ------------------------------------------------------ 
-- SQL Query by CPU Usage

select * from 
(select 
    cpu_time/1000000 cpu_time, 
    elapsed_time/1000000 elapsed_time, 
    disk_reads, 
    buffer_gets, 
    rows_processed,
    sql_text
from v$sqlarea 
order by cpu_time desc, disk_reads desc
) 
where rownum < 21


---- the overall CPU usage for each thread
SELECT p.spid THREAD, s.username,
    DECODE(NVL(p.background,0),1,bg.description,s.program ) program,
    ss.VALUE/100 CPU,physical_reads disk_io
 FROM 
    v$process p,
    v$session s,
    v$sesstat ss,
    v$sess_io si,
    v$bgprocess bg
 WHERE s.paddr=p.addr
  AND ss.SID=s.SID
  AND ss.statistic#=12 
  AND si.SID=s.SID
  AND bg.paddr(+)=p.addr
 ORDER BY ss.VALUE DESC;
 
 ------------------------------------------------------ 
 
---- count of primary key columns 
SELECT constraint_name,table_name,owner,COUNT(*) cnt_cons 
FROM dba_cons_columns 
WHERE constraint_name LIKE 'PK%' 
  AND owner NOT IN 
   ('SYS','SYSTEM','WMSYS','ORDSYS','MDSYS','OLAPSYS','CTXSYS','WKSYS','DBSNMP','ISPL_DBA','RMAN','SRC_JAVA_REPL','SRC_C_REPL','TEST_USER') 
GROUP BY constraint_name,table_name,owner 
HAVING COUNT(*) >=1 
ORDER BY cnt_cons DESC
 
 ------------------------------------------------------ 
 
---- tables which are not having PK
SELECT OWNER,TABLE_NAME
FROM DBA_TABLES dt
WHERE NOT EXISTS (SELECT  'TRUE'
                  FROM DBA_CONSTRAINTS dc
                  WHERE dc.TABLE_NAME = dt.TABLE_NAME
                    AND dc.CONSTRAINT_TYPE='P')
  AND OWNER NOT IN ('SYS','SYSTEM','TOAD','OUTLN','WMSYS','ORDSYS','MDSYS','OLAPSYS','WKPROXY','CTXSYS','WKSYS','DBSNMP','ISPL_DBA','RMAN','SRC_JAVA_REPL','SRC_C_REPL','TEST_USER')
--ORDER BY OWNER, TABLE_NAME
 
 ------------------------------------------------------ 
 
--- table name and constraint name foreigen key plus pk
SELECT distinct 
   uc.owner, uc.table_name, uc.constraint_name, ucc.column_name,
   uc.r_constraint_name, pk_cons.table_name, pk_cons.column_name 
FROM dba_CONSTRAINTS uc, dba_CONS_COLUMNS ucc, 
(
   SELECT ucc2.constraint_name, ucc2.table_name, ucc2.column_name
   FROM dba_CONS_COLUMNS ucc2, dba_CONSTRAINTS uc
   WHERE ucc2.constraint_name = uc.constraint_name
     AND uc.constraint_type = 'P'
     and ucc2.TABLE_NAME='CC_CSR'
  )pk_cons
WHERE uc.constraint_name=ucc.constraint_name  
  AND uc.r_constraint_name = pk_cons.constraint_name
  AND uc.constraint_type='R'

------------------------------------------------------ 
 
--- primary key and no primary key tables
SELECT table_name, DECODE(constraint_type,'P','PK','NOPK') check_constraints
FROM(
SELECT table_name, constraint_type FROM USER_CONSTRAINTS
WHERE constraint_type='P'
UNION
SELECT table_name, NULL FROM USER_TABLES
WHERE table_name NOT IN(SELECT table_name
                        FROM USER_CONSTRAINTS
                        WHERE constraint_type='P'))
ORDER BY CONSTRAINT_TYPE ASC
 
 ------------------------------------------------------ 
 
--- query to list, all those table name which are having primary for all the column in table
SELECT table_name FROM USER_TABLES a
WHERE (SELECT COUNT(1) 
       FROM USER_CONS_COLUMNS b,USER_CONSTRAINTS c 
       WHERE a.table_name = b.table_name 
         AND b.constraint_name = c.constraint_name 
         AND c.constraint_type='P') = (SELECT COUNT(1) 
                                       FROM USER_TAB_COLUMNS b 
                                       WHERE a.table_name=b.table_name)
 
 ------------------------------------------------------ 
 
-- query to list all those tables which are having primary key but not those 
-- tables which are having primary key to all the columns in a table 
SELECT table_name FROM USER_TABLES
WHERE table_name IN(SELECT table_name
                 FROM USER_CONSTRAINTS
                 WHERE constraint_type='P')
  AND table_name NOT IN(SELECT table_name FROM USER_TABLES a
                        WHERE (SELECT COUNT(1) 
                               FROM USER_CONS_COLUMNS b,USER_CONSTRAINTS c 
                               WHERE a.table_name = b.table_name 
                                 AND b.constraint_name = c.constraint_name 
                                 AND c.constraint_type='P') = (SELECT COUNT(1) 
                                                               FROM USER_TAB_COLUMNS b 
                                                               WHERE a.table_name=b.table_name))
ORDER BY table_name ASC
 
 ------------------------------------------------------ 
 
--- will count records in all the table 
SELECT 'select '''||table_name||''', count(*) from '||table_name||';'qry
FROM user_tab_columns
WHERE column_name LIKE 'APPLICATION_ID'
ORDER BY table_name ASC
 
 ------------------------------------------------------ 
 
--- no primary key on tables
SELECT table_name FROM user_tables
MINUS
SELECT table_name FROM user_constraints WHERE constraint_type='P'
 
 ------------------------------------------------------ 
 
--- generate the script for invalid objects in database
SELECT 
   'Alter ' ||
   DECODE( object_type, 'PACKAGE BODY', 'PACKAGE', object_type ) ||
   ' ' ||
   owner || '.' || object_name || ' Compile ' ||  
   DECODE( object_type,'PACKAGE', 'SPECIFICATION','PACKAGE BODY', 'BODY') ||';' SQL_QUERY,
   DECODE( owner, 'SYS', 1,'SYSTEM', 2, 3) SORT_OWNER,
   DECODE( object_type,'VIEW', 1,'PACKAGE', 2,'TRIGGER', 9, 3) SORT_TYPE
FROM
   DBA_OBJECTS
WHERE status='INVALID'
  AND owner NOT IN
    ('SYS','SYSTEM','WMSYS','ORDSYS','MDSYS','OLAPSYS','CTXSYS','WKSYS','DBSNMP','ISPL_DBA','RMAN','SRC_JAVA_REPL','SRC_C_REPL','TEST_USER') 
ORDER BY
   SORT_OWNER, SORT_TYPE;
   
--- compile invalid object with in schema 
EXEC DBMS_UTILITY.COMPILE_SCHEMA( USER, FALSE );
SELECT 'ALTER '||OBJECT_TYPE||' '||OBJECT_NAME||' COMPILE;' FROM OBJ WHERE STATUS = 'INVALID'
 
 ------------------------------------------------------ 
 
-- the thrid highest value, just chage the value in place of 3 
-- and change the joing as per u want means what higest u want 
SELECT  eid FROM EMP1 c1
WHERE 3=(SELECT COUNT(*) FROM EMP1 c2 WHERE C1.eid >= C2.eid)   
 
 ------------------------------------------------------ 
 
--- Flash Back Query

-- Oracle Flashback Query can only be used if the server is configured to use Automatic 
-- Undo Management, rather than traditional rollback segments. The maximum time period 
-- that can be flashbacked to is defined using the UNDO_RETENTION parameter in the 
-- init.ora file. Alternatively, this parameter can be set using:

ALTER SYSTEM SET UNDO_RETENTION = <seconds>;

--- Query to get the deleted data before 10 minutes
SELECT * FROM LOOKUP_TRANS_STATUS
 AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE); 
 
-- so like wish u can insert the data back in the table  
INSERT INTO LOOKUP_TRANS_STATUS
 SELECT * FROM LOOKUP_TRANS_STATUS
  AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE);
-- if wanna selected data from deleted data then  
   WHERE CONDITION... = ?;
 
 

--To select data as if we where in the past, you can use a flashback query. How long 
--you can go back depends on the size of the UNDO tablespace and on how quickly that fills up. 

--If you want to see the content of the table 1 hour ago you can query it like:

SELECT *
FROM tablename
AS OF TIMESTAMP SYSTIMESTAMP - INTERVAL '1' HOUR;


--If you want to see the content of the table 2 days ago you can query it like:

SELECT *
FROM tablename
AS OF TIMESTAMP SYSTIMESTAMP - INTERVAL '2' DAY;

--or you can select the status per SCN number.

--To query the current SCN number:

SELECT DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER() FROM DUAL; 


--To select a SCN number (System Change Number) on a specific timestamp:

SELECT TIMESTAMP_TO_SCN('11-JUN-09 10.30.09.000000000 AM') FROM dual; 


--With this SCN number you can query in the past with "scn-number":

SELECT *
FROM tablename
AS OF SCN "scn-number";


--To select changes on a table since a specific System Change Numbers (SCN):

SELECT * FROM tabelnaam
VERSIONS BETWEEN SCN SCN_x AND MAXVALUE; 


--LASHBACK TABLE helps restore the state of a table to a certain point
--in time even if a table structure changed has occurred since then. The
--following simple command will take us to the table state at the
--specified timestamp.
FLASHBACK TABLE employee TO TIMESTAMP  to_date('27-Feb-09 05:00:00 PM','DD-MON-YY HH:MI:SS PM');


--Oracle 10g has provided another useful feature term as the Flashback
--drop. For our example if a DROP TABLE has been issued for the table
--EMPLOYEE we can still restore the whole table by issuing the following
--command.
FLASHBACK TABLE EMPLOYEE TO BEFORE DROP;
 

 ------------------------------------------------------ 
 
--- Values seprated by ','
SELECT SCORING_PROPERTY_NAME, MAX(CUSTOMER_CODE)
  FROM (SELECT rn, ROWNUM - LEVEL SCORING_PROPERTY_NAME, SYS_CONNECT_BY_PATH(CUSTOMER_CODE, ',') CUSTOMER_CODE
          FROM (SELECT ROWNUM rn, CUSTOMER_CODE FROM CUST_SCORE)
        CONNECT BY PRIOR rn = rn - 1 AND CUSTOMER_CODE != 48
         START WITH CUSTOMER_CODE = 48)a
 GROUP BY SCORING_PROPERTY_NAME
 ORDER BY SCORING_PROPERTY_NAME   
 
 ------------------------------------------------------ 

 --- referential constraint script from a schema
 SELECT 'ALTER TABLE '||uc.table_name||' ADD ('||CHR(13)||' CONSTRAINT '||uc.constraint_name||' FOREIGN KEY ('||ucc.column_name||')'||CHR(13)||'  REFERENCES '||pk_cons.table_name||'('||pk_cons.column_name||'));' CONS_QUERY 
 --   uc.table_name,uc.constraint_name,ucc.column_name,
  --  pk_cons.table_name"PK TableName",pk_cons.column_name "PK ColName" 
 FROM USER_CONSTRAINTS uc, USER_CONS_COLUMNS ucc, 
 (
    SELECT ucc.constraint_name,ucc.table_name,ucc.column_name
    FROM USER_CONS_COLUMNS ucc, USER_CONSTRAINTS uc
    WHERE ucc.constraint_name = uc.constraint_name
      AND uc.constraint_type='P'
   )pk_cons
 WHERE uc.constraint_name=ucc.constraint_name  
   AND uc.r_constraint_name = pk_cons.constraint_name
   AND uc.constraint_type='R'
ORDER BY uc.table_name ASC

------------------------------------------------------ 
 
-- deletion of child records
SELECT * FROM user_constraints WHERE constraint_Name = 'FK_CHKC_CS_HIST_XTNID'

SELECT * FROM chkc_transactions WHERE length(checkno) < 6

SELECT * FROM qcp.telechecktransactions WHERE length(checkno) < 6


DELETE FROM CHKC_CHECK_STATUS_HISTORY ch
WHERE ch.transactionid in 
 (
  SELECT
       ct.transactionid 
  FROM 
       chkc_transactions ct 
  WHERE 
       length (ct.checkno) < 6
 ) 


DELETE FROM chkc_transactions WHERE length(checkno) < 6

DELETE FROM qcp.telechecktransactions WHERE length(checkno) < 6

SELECT 
       CT.TRANSACTIONID, CT.CHECKNO, CH.TRANSACTIONID
FROM 
     CHKC_TRANSACTIONS CT, CHKC_CHECK_STATUS_HISTORY CH
WHERE 
      CT.TRANSACTIONID = CH.TRANSACTIONID
      AND LENGTH(CT.CHECKNO) < 6


DELETE FROM chkc_transactions A WHERE A.transactionid IN
(SELECT B.transactionID FROM CHKC_CHECK_STATUS_HISTORY B WHERE A.transactionid=B.transactionID)
 AND length(A.checkNo) < 6


---------------------------------------------------------------------

-- rowset will return the cursor records
SELECT deptno, depname, CURSOR( SELECT EMPLOYEE FROM EMP e WHERE e.LEVEL1 = dept.deptno )dep
FROM dept   WHERE deptno = 2;

---------------------------------------------------------------------

-- the procedure will return the result rowset 
CREATE OR REPLACE PACKAGE TYPES AS 
  TYPE cursor_type IS REF CURSOR;
END TYPES; 
/


CREATE OR REPLACE PROCEDURE GetEmpRS 
(
     i_LEVEL1    IN  NUMBER,
     p_recordset OUT TYPES.cursor_type
) AS 
BEGIN 
  OPEN p_recordset FOR
    SELECT LEVEL1, EMPLOYEE, EMP_ID, MGR_ID
    FROM   EMP
    WHERE  LEVEL1 = i_LEVEL1
    ORDER BY EMPLOYEE;
END GetEmpRS;
/

 SET SERVEROUTPUT ON SIZE 1000000
 DECLARE
   v_cursor  TYPES.cursor_type;
   
   v_LEVEL1   NUMBER; 
   v_EMPLOYEE  VARCHAR2(30);
   v_EMP_ID   NUMBER;
   v_MGR_ID   NUMBER;
   
 BEGIN
   GetEmpRS (i_LEVEL1    => 2,
             p_recordset => v_cursor);
             
   LOOP 
     FETCH v_cursor
     INTO  v_LEVEL1, v_EMPLOYEE, v_EMP_ID, v_MGR_ID;
     EXIT WHEN v_cursor%NOTFOUND;
     DBMS_OUTPUT.PUT_LINE(v_LEVEL1 || ' | ' || v_EMPLOYEE || ' | ' || v_EMP_ID || ' | ' || v_MGR_ID);
   END LOOP;
   CLOSE v_cursor;
 END;
 /


---------------------------------------------------------------------

 -- query which gives, difference between two dates 
 SELECT FLOOR((((SYSDATE-MAX(DATA_READING_TIMESTAMP))*24*60*60) -
  FLOOR(((SYSDATE-MAX(DATA_READING_TIMESTAMP))*24*60*60)/3600)*3600)/60)minutes
FROM SENSOR_DATA;


---------------------------------------------------------------------

set serveroutput on

variable v_username varchar2(4000);

exec :v_username := '&1';

declare 
   v_User_Name   VARCHAR2(4000);
   v_cntFlag     NUMBER;
   v_grantsSQL   VARCHAR2(100);
begin 
  begin 
    select username into v_User_Name from all_users where username= upper(''||:v_username||''); 
    v_cntFlag:=0;
  exception
    when no_data_found then
	  v_cntFlag:=1;
  end;
   
  if v_cntFlag = 1 then
     execute immediate 'create user &1 identified by &1._dev default tablespace users temporary tablespace temp';
    
     v_grantsSQL:='GRANT CONNECT, RESOURCE TO &1';
     execute immediate v_grantsSQL;
     
	 dbms_output.put_line('------------------------------------');
	 dbms_output.put_line('Schema Name '||:v_username||' was not found and so it was created');
	 dbms_output.put_line('------------------------------------'); 	
  else
     dbms_output.put_line('------------------------------------');
     dbms_output.put_line('Schema Name '||:v_username||' found');
     dbms_output.put_line('------------------------------------');   
  end if;
end;
/
exit


---------------------------------------------------------------------

--- storing milliseconds in oracle table

CREATE OR REPLACE JAVA SOURCE
NAMED "MyTimestamp"
AS
import java.lang.string;
import java.sql.timestamp;

PUBLIC CLASS MyTimestamp
{  PUBLIC static String getTimestamp()
   {
	RETURN (NEW TIMESTAMP(SYSTEM.currentTimeMillis())).toString();
   }
};
/

CREATE OR REPLACE FUNCTION my_timestamp RETURN VARCHAR2
AS LANGUAGE JAVA
NAME 'MyTimestamp.getTimestamp() return java.lang.String';
/

To use:
SELECT my_timestamp FROM DUAL ;

MY_TIMESTAMP
-----------------------
2002-04-18 16:54:38.688 
 
 
 -------------------------------------------------------------------------------
 -- Parent Child Seraching Function
   CREATE OR REPLACE FUNCTION sy_RF 
   (
      p_parent IN varchar
   )
          RETURN VARCHAR
   IS
          v_parent   varchar(50);
          v_val      varchar(50);
   	     v_val1     varchar(50);
   	     
 		 CURSOR c1  IS SELECT tree_node 
 		   			   FROM pstreenode a
 				 	   WHERE a.parent_node_name = p_parent AND a.effdt ='31-DEC-2006';
   BEGIN
      FOR dept IN c1
      LOOP
        DBMS_OUTPUT.put_line (dept.tree_node);
        
 	   declare
 	     cursor c2 is SELECT tree_node 
 	     			  FROM pstreenode a 
 	     			  WHERE a.parent_node_name =dept.tree_node
 	  					AND A.EFFDT='31-DEC-2006';
   		BEGIN
 		  FOR dept1 IN c2
 		  LOOP
 			 DBMS_OUTPUT.put_line ('-----'||dept1.tree_node);
 			 V_VAL:=DEPT1.TREE_NODE;
 			
 			 SELECT parent_node_name into v_val 
 			 FROM pstreenode a
 			 WHERE tree_node=V_VAL 
 			   AND a.effdt ='31-DEC-2006';
 			   
 			IF v_val=' ' THEN
 			  return ('TRUE1');
 			else
 			  V_VAL1:= sy_rf(DEPT1.TREE_NODE);
 			end if;
      	 END LOOP;
        End;
     END LOOP;
      RETURN ('TRUE');
 end;
 
 
 ****************************************  COUNT of ROWs  **************************************** 

 -- table_name and count of records as per tables
 -- to execute the query you need to connect specific schema
 SELECT
  table_name,
  TO_NUMBER(extractvalue(XMLTYPE(dbms_xmlgen.getxml('select count(*) c from '||table_name)),'/ROWSET/ROW/C')) COUNT
 FROM USER_TABLES 
ORDER BY 1;

-- table_name and count of records as per tables
-- you execute the query from DBA granted user
SELECT
  owner,
  table_name,
  TO_NUMBER(EXTRACTVALUE(XMLTYPE(DBMS_XMLGEN.GETXML('select count(*) c from '||owner||'.'||table_name)),'/ROWSET/ROW/C')) COUNT
FROM dba_TABLES 
where owner='SNOX4TRANSNOX'
ORDER BY 1;  


-- get the data count for column's data
SELECT dt.owner owner, dt.table_name table_name,'delete from '||dt.owner||'.'||dt.table_name||';'
  TO_NUMBER(EXTRACTVALUE(XMLTYPE(DBMS_XMLGEN.GETXML('select count(*) c from '||dt.owner||'.'||dt.table_name||' where '||dtc.column_name||'=566')),'/ROWSET/ROW/C')) data_cnt
FROM all_TABLES dt, all_Tab_Columns dtc
where dt.owner = dtc.owner
  and dt.table_name = dtc.table_name
  and dt.owner='TRANSMONERIS'
  AND dtc.COLUMN_NAME = 'AGENT_ID'
  and TO_NUMBER(EXTRACTVALUE(XMLTYPE(DBMS_XMLGEN.GETXML('select count(*) c from '||dt.owner||'.'||dt.table_name||' where '||dtc.column_name||'=566')),'/ROWSET/ROW/C')) <> 0
ORDER BY 3 desc 

****************************************  COUNT of ROWs  **************************************** 
 
 
 
****************************************  Multiple Columns in Single Row  **************************************** 

-- we can put mutiple columns in one single row
--- level is difine 3 so i have taken three columns, you can increase the level
--- and soo increase the column names and put them in first select 
SELECT DECODE(r, 1, TABLE_NAME, 2, OWNER, 3, SRC_TAB_ROW) col FROM 
 (SELECT TABLE_NAME, OWNER, SRC_TAB_ROW, ROWNUM rnum FROM REPL_TAB_SYNC) t,
 (SELECT LEVEL r FROM dual CONNECT BY LEVEL <=3)
 ORDER BY t.rnum, col

****************************************  Multiple Columns in Single Row  **************************************** 
 
 
****************************************  How Fast Tables is getting imported  ****************************************

---- Can one monitor how fast a table is imported?
 select substr(sql_text,instr(sql_text,'INTO "'),30) table_name,
         rows_processed,
         round((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60,1) minutes,
         trunc(rows_processed/((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60)) rows_per_min
  from   sys.v_$sqlarea
  where  sql_text like 'INSERT %INTO "%'
    and  command_type = 2
    and  open_versions > 0;
 
 ****************************************  How Fast Tables is getting imported  ****************************************

 
 ****************************************  Who is Locking what?  ****************************************
 --- who is locking what?
SELECT 
  oracle_username, os_user_name, locked_mode,
  object_name,object_type
FROM v$locked_object a,DBA_OBJECTS b
WHERE a.object_id = b.object_id    
 
SELECT Oracle_Username Username, owner Object_Owner, Object_Name, Object_Type, s.osuser, s.SID SID,
		s.SERIAL# SERIAL,DECODE(l.BLOCK, 0, 'Not Blocking', 1, 'Blocking', 2, 'Global') STATUS,
		DECODE(v.locked_mode, 0, 'None', 1, 'Null', 2, 'Row-S (SS)', 3, 'Row-X (SX)', 4, 'Share', 5, 'S/Row-X (SSX)', 6, 'Exclusive', TO_CHAR(lmode) ) MODE_HELD
FROM gv$locked_object v, dba_objects d, gv$lock l, gv$session s
WHERE v.object_id = d.object_id
  AND (v.object_id = l.id1)
  AND v.session_id = s.SID
ORDER BY oracle_username, session_id;

****************************************  Who is Locking what?  ****************************************

------------------------------------------------------------------------------
------------------------------------------------------------------------------
-- get the list of synonyms those have not got any privilege
SELECT SYNONYM_NAME,TABLE_OWNER,TABLE_NAME 
FROM USER_SYNONYMS A
WHERE NOT EXISTS (SELECT 'X' FROM USER_TAB_PRIVS_RECD B 
                  WHERE A.TABLE_OWNER=B.OWNER
						AND A.TABLE_NAME=B.TABLE_NAME)
ORDER BY 2,3 

------------------------------------------------------------------------------
------------------------------------------------------------------------------
-- counting all objects simple cursor

SELECT 
(CURSOR(
SELECT DECODE(GROUPING(a.owner), 1, 'All Owners',
a.owner) AS "Owner",
COUNT(CASE WHEN a.object_type = 'TABLE' THEN 1 ELSE NULL END) "TABLES",
COUNT(CASE WHEN a.object_type = 'INDEX' THEN 1 ELSE NULL END) "INDEXES",
COUNT(CASE WHEN a.object_type = 'PACKAGE' THEN 1 ELSE NULL END) "PACKAGES",
COUNT(CASE WHEN a.object_type = 'SEQUENCE' THEN 1 ELSE NULL END) "Sequences",
COUNT(CASE WHEN a.object_type = 'TRIGGER' THEN 1 ELSE NULL END) "TRIGGERS",
COUNT(CASE WHEN a.object_type NOT IN
('PACKAGE','TABLE','INDEX','SEQUENCE','TRIGGER') THEN 1 ELSE NULL END) "Other",
COUNT(CASE WHEN 1 = 1 THEN 1 ELSE NULL END) "Total"
FROM DBA_OBJECTS a
GROUP BY ROLLUP(a.owner))) Double_Click_Here
FROM dual;


 ------------------------------------------------------------------------------
 ------------------------------------------------------------------------------
---successful CCCA transactions 
select c.transactiondate, c.amount/100 "Dollar Amount", c.SERVICECHARGE/100 "Fee", c.CHECKNO "GCA Check No",
      a.casinocode, b.casinoname, a.MACHINEID "WorkStation Code", a.DESCRIPTION 
from qcp.machines a, qcp.casinos b, qcp.transactions c
where a.casinocode = b.casinocode 
  and b.casinocode = c.casinocode
  and c.transaction_status in ('ATC','AUT','PTC','PTS')
  and trunc(c.transactiondate) between to_date('02/24/2007','mm/dd/yyyy') and to_date('01/09/2008','mm/dd/yyyy')
  

 ------------------------------------------------------------------------------
 ------------------------------------------------------------------------------
-- spid of schema
SELECT p.spid, s.username, s.program 
FROM v$process p, v$session s 
WHERE p.addr=s.paddr 
ORDER BY 2, 3, 1 
  

 ------------------------------------------------------------------------------
 ------------------------------------------------------------------------------
--TOP N query
SELECT * FROM  
( SELECT * 
  FROM chkc_transactions 
  ORDER BY TIMESTAMP DESC ) 
 WHERE ROWNUM <= 10;

 
 ------------------------------------------------------------------------------
 ------------------------------------------------------------------------------
 -- SQL to compare rows within two tables
(select * from A  
 minus 
 select * from B) -- Rows in A that are not in B
union all 
(  
 select * from B  
 minus 
 select * from A
) -- rows in B that are not in A


 
****************************************  StringTonkenizer  ****************************************

-- Stringtokenizer procedure 
CREATE OR REPLACE PROCEDURE Stringtokenizer
(
	p_InputString					VARCHAR2,
	p_Seperator						CHAR,
	p_ElementNumber					NUMBER,
	p_OutputString			IN OUT	VARCHAR2
)
AS
	v_InputString					VARCHAR2(4000);
	v_Seperator						CHAR;
	v_SeperatorPosition				NUMBER;
	v_NextSeperator					NUMBER;
BEGIN
	v_InputString := p_InputString;
	v_Seperator   := p_Seperator;
	
	IF SUBSTR(v_InputString, 1, 1) <> v_Seperator THEN
		v_InputString := v_Seperator || v_InputString;
	END IF;
	IF SUBSTR(v_InputString, LENGTH(v_InputString)) <> v_Seperator THEN
		v_InputString := v_InputString || v_Seperator;
	END IF;
	v_SeperatorPosition := INSTR(v_InputString, v_Seperator, 1, p_ElementNumber) + 1;
	v_NextSeperator := INSTR(v_InputString, v_Seperator, v_SeperatorPosition);
	IF v_NextSeperator = 0 /*INSTR(v_InputString, 1, v_NextSeperator) = 0 */ THEN
		p_OutputString := NULL;
	ELSE
		p_OutputString := SUBSTR(v_InputString, v_SeperatorPosition, (v_NextSeperator - v_SeperatorPosition));
	END IF;

END;
/



-- Stringtokenizer for cuting strings
DECLARE

	v_Saperator				   	 VARCHAR2(1):='~';
	v_Element				   	 NUMBER;
	v_Image_Type_Str			 VARCHAR2(4000);
	
BEGIN	
   v_Element:=1;
   Stringtokenizer(i_DML_String, v_Saperator, v_Element, v_Image_Type_Str);
   WHILE v_Image_Type_Str IS NOT NULL
   LOOP
	
 	 ---- Your code here for tokenized string.

   	   v_Element:= v_Element + 1;
   	   Stringtokenizer(i_Image_Type, v_Saperator, v_Element, v_Image_Type_Str);
   END LOOP;
END;


 -- script for stringtokenizer to cut vales TOKENIZE_DML function has been used

  v_ErrorFlag:=3;
  v_main_str:=trim(TOKENIZE_DML(v_Sql_String));

  Stringtokenizer( v_main_str, ',', v_Element_Ins, v_ins_string);
  WHILE v_ins_string IS NOT NULL
  LOOP
		v_ErrorFlag:=4;
		v_Temp:=1;
		Stringtokenizer(v_ins_string, '|', v_Temp, v_ColName);
		Stringtokenizer(v_ins_string, '|', v_Temp+1, v_ColVal);

		v_ErrorFlag:=5;
		IF v_ColName = 'RATE_CODE' THEN
		   v_strRate_Code := v_ColVal;
		ELSIF v_ColName = 'BIN' THEN
		   v_strBin:= TO_NUMBER(v_ColVal) * 100;
		ELSIF v_ColName = 'FIXED_FEE' THEN
		   v_strFixed_Fee:= TO_NUMBER(v_ColVal) * 100;
		ELSIF v_ColName = 'PERCENT_FEEE' THEN
		   v_strPercent_Fee:= TO_NUMBER(v_ColVal);
		ELSIF v_ColName = 'MINIMUM_FEE' THEN
		   v_strMinimum_Fee:= TO_NUMBER(v_ColVal) * 100;
		END IF;

		IF UPPER(i_UpdateType)='INSERT' THEN 
			v_ErrorFlag:=6;
			INSERT INTO FEE_RATE_DETAIL(RATE_CODE, BIN, FIXED_FEE, PERCENT_FEE, MINIMUM_FEE)
			 VALUES(v_strRate_Code, v_strBin,  v_strFixed_Fee,  v_strPercent_Fee,  v_strMinimum_Fee);

		ELSIF UPPER(i_UpdateType)='UPDATE' THEN 
			v_ErrorFlag:=7;
			UPDATE FEE_RATE_DETAIL
			SET 
			  FIXED_FEE   = v_strFixed_Fee,
			  PERCENT_FEE = v_strPercent_Fee,
			  MINIMUM_FEE = v_strMinimum_Fee
			WHERE RATE_CODE = v_strRate_Code
			   AND BIN = v_strBin;

		END IF;

	v_Element_Ins:= v_Element_Ins + 1;
	Stringtokenizer( v_main_str, ',', v_Element_Ins, v_Primary_keys);
  END LOOP;
****************************************  StringTonkenizer  ****************************************

 
****************************************  Insert/Update in CLOB/BLOB  ****************************************
-- Inserting and updating in clob and blob data types  
CREATE OR REPLACE PROCEDURE Example_1a IS
 dest_lob IN OUT BLOB;
 src_lob IN OUT   BLOB; 
BEGIN
  -- get the LOB locators
  -- note that the FOR UPDATE clause locks the row
  SELECT b_lob INTO dest_lob
  FROM lob_table
  WHERE key_value = 12 
  FOR UPDATE;

  SELECT b_lob INTO src_lob
  FROM lob_table
  WHERE key_value = 21;

  dbms_lob.append(dest_lob, src_lob);
  COMMIT;
END;
****************************************  Insert/Update in CLOB/BLOB  ****************************************


**************************************** Database Trigger  ****************************************
-- trigger which block some users to create any ddl on any schema's

CREATE OR REPLACE TRIGGER DATABASE_DDL_TRIG 
before DDL on Database
DECLARE 
    v_Os_User        varchar2(30);
    v_Program        varchar2(500);
BEGIN 

    select SYS_CONTEXT('USERENV', 'OS_USER')OS_USER, UPPER(sys_context('USERENV', 'MODULE'))
    into v_Os_User, v_Program
    from dual;
    
    if upper(v_Os_User) in ('ASHWIN', 'TARANNUM', 'SANDEEP', 'NITIN', 'SAURABH','ANUPAM', 'NIRAV', 'DEVESH', 
                            'DHARMESH', 'VAIBHAV', 'UDAY', 'AMOL', 'ATUL', 'SHAILESH', 'MILINDT', 'PARESH', 
                            'PHILIP', 'DISHANT', 'GANESH', 'SAUMYA', 'RUSHIKESH', 'RANJAN', 'MANOJ', 
                            'AMIT', 'RAJANI', 'SANJIT', 'MILINDD', 'KARAN', 'DEBARGHA', 'MAHESH') 
            and (v_Program in ('SQL*PLUS','DREAMCODER','DBSAINT.EXE','SQL DEVELOPER') 
                    OR v_Program like 'TOAD%') then
         RAISE_APPLICATION_ERROR (-20905, 'Please do not execute any DDL commands '||UPPER(v_Os_User)||' , PLEASE CONTACT YOUR DBA');
    end if;
END;
/



-- Block developers from using TOAD and other tools on production databases.

CONNECT / AS SYSDBA;
 
CREATE OR REPLACE TRIGGER block_tools_from_prod
  AFTER LOGON ON DATABASE
DECLARE
  v_prog sys.v_$session.program%TYPE;
BEGIN
  SELECT program INTO v_prog 
    FROM sys.v_$session
  WHERE  audsid = USERENV('SESSIONID')
    AND  audsid != 0  -- Don't Check SYS Connections
    AND  ROWNUM = 1;  -- Parallel processes will have the same AUDSID's
 
  IF UPPER(v_prog) LIKE '%TOAD%' OR UPPER(v_prog) LIKE '%T.O.A.D%' OR -- Toad
     UPPER(v_prog) LIKE '%SQLNAV%' OR     -- SQL Navigator
     UPPER(v_prog) LIKE '%PLSQLDEV%' OR -- PLSQL Developer
     UPPER(v_prog) LIKE '%BUSOBJ%' OR   -- Business Objects
     UPPER(v_prog) LIKE '%EXCEL%'       -- MS-Excel plug-in
  THEN
     RAISE_APPLICATION_ERROR(-20000, 'Development tools are not allowed here.');
  END IF;
END;
/
SHOW ERRORS

****************************************  Database Trigger  ****************************************



****************************************  Eliminate Duplicates ****************************************

how does one eliminate duplicates rows from a table?

-- deleting duplicate records.
delete  sushil a WHERE rowid < (SELECT max(rowid) FROM sushil 
								WHERE name=a.name 
								GROUP BY name HAVING count (*)>1)

Choose one of the following queries to identify or remove duplicate rows from 
a table leaving only unique records in the table:
Method 1: 

     DELETE FROM table_name A WHERE ROWID > (
     SELECT min(rowid) FROM table_name B
     WHERE A.key_values = B.key_values);

Method 2: 
    create table table_name2 as select distinct * from table_name1;
    drop table_name1;
    rename table_name2 to table_name1;
    -- Remember to recreate all indexes, constraints, triggers, etc on table... 

Method 3: (thanks to Dennis Gurnick) 
    delete from my_table t1
    where  exists (select 'x' from my_table t2
                    where t2.key_value1 = t1.key_value1
                      and t2.key_value2 = t1.key_value2
                      and t2.rowid      > t1.rowid);

Note 1: One can eliminate N^2 unnecessary operations by creating an index on the 
        joined fields in the inner loop (no need to loop through the entire table on each 
        pass by a record). This will speed-up the deletion process. 
        
Note 2: If you are comparing NOT-NULL columns, use the NVL function. Remember that 
        NULL is not equal to NULL. This should not be a problem as all key columns should be 
        NOT NULL by definition. 


SELECT TASK_ID, DEVICE_ID FROM TRANSACTION
GROUP BY TASK_ID, DEVICE_ID
HAVING COUNT(*) > 1

****************************************  Eliminate Duplicates ****************************************






****************************************  REF CURSOR ****************************************

--- CURSOR examples
CURSOR cur_Payee IS SELECT * FROM PAYEE;

 	OPEN cur_Payee;
	  LOOP
	   FETCH cur_Payee INTO v_Payee_Rec;
	   EXIT WHEN cur_Payee%NOTFOUND;
				  v_ErrorFlag:=1;
			   -- Your Code here 
	  END LOOP;
    CLOSE cur_Payee ;


--- Ref CURSOR examples
TYPE Ref_Cursor_Type IS REF CURSOR ;
v_Ref_Cursor	Ref_Cursor_Type;

v_SQL_Str		VARCHAR2(4000);

BEGIN

   v_SQL_Str := 'SELECT EMPNO, ENAME, JOB, MGR from emp WHERE Empno = '||i_Empno;

   OPEN v_Ref_Cursor FOR v_SQL_Str;
	LOOP
	  FETCH v_Ref_Cursor INTO v_ENAME, v_JOB, v_MGR;
		EXIT WHEN v_Ref_Cursor%NOTFOUND;
		
		  --- Your Code here
		  
   END LOOP;
       
END;


--- Declaring TYPES
TYPE    TmpCurTyp IS REF CURSOR RETURN employees%ROWTYPE;
tmp_cv  TmpCurTyp; -- declare cursor variable

DECLARE
  TYPE EmpRecTyp IS RECORD (
                            employee_id     NUMBER,
							last_name 		VARCHAR2(25),
							salary 			NUMBER(8,2)
							);
TYPE EmpCurTyp IS REF CURSOR RETURN EmpRecTyp;
emp_cv EmpCurTyp; -- declare cursor variable
---------------------------------------------------------------


          TYPE Ref_Cur_Type IS REF CURSOR;
	      ref Ref_Cur_Type;

    OPEN ref FOR v_HeadDateQuery(run time select query);
       LOOP
		FETCH HeadDateQuery_Cur INTO  v_Timestamp,v_TotalBalance, v_description;
		EXIT WHEN ref%NOTFOUND;


--------------------------------------------------------------

OPEN HeadDateQuery_Cur FOR v_HeadDateQuery;
	LOOP
		FETCH HeadDateQuery_Cur INTO
		v_Binnumber,
		v_Denomination,
		v_Current_Balance_Amount,
		v_Current_Dispensed_Amount,
		v_Current_Retained_Amount,
		v_Config_Id;

		EXIT WHEN HeadDateQuery_Cur%NOTFOUND;
		v_InsertQuery :=    ' INSERT INTO ' || v_TempTable || '( '||
									' Sr_Nr,'||
									' Description,'||
									' Value '||
									' ) '||
									' VALUES ( :1,:2,:3)';

		EXECUTE IMMEDIATE v_InsertQuery	USING
		v_SerialNo,
		'Config ID For Bin '||v_Binnumber ,
		v_Config_Id;
		v_SerialNo := v_SerialNo +1;

	END LOOP;
	CLOSE HeadDateQuery_Cur;
	v_SerialNo := v_SerialNo +1;


-----------------------------------------------------------------------------------------
TYPE    TmpCurTyp IS REF CURSOR RETURN employees%ROWTYPE;
tmp_cv  TmpCurTyp; -- declare cursor variable

DECLARE
  TYPE EmpRecTyp IS RECORD (
                           employee_id NUMBER,
							last_name VARCHAR2(25),
							salary NUMBER(8,2)
							);
TYPE   EmpCurTyp IS REF CURSOR RETURN EmpRecTyp;
emp_cv EmpCurTyp; -- declare cursor variable

-----------------------------------------------------------------------------------------

DECLARE
CURSOR c1 IS SELECT last_name FROM employees ORDER BY last_name;
	name1 employees.last_name%TYPE;
	name2 employees.last_name%TYPE;
	name3 employees.last_name%TYPE;
BEGIN
OPEN c1;
	FETCH c1 INTO name1; -- this fetches first row
	FETCH c1 INTO name2; -- this fetches second row
	FETCH c1 INTO name3; -- this fetches third row
CLOSE c1;
END;

-------------------------------------------------------------------------------------------

BEGIN
FOR item IN
( SELECT last_name, job_id FROM employees WHERE job_id LIKE '%CLERK%'
AND manager_id > 120 )
LOOP
DBMS_OUTPUT.PUT_LINE('Name = ' || item.last_name || ', Job = ' ||
item.job_id);
END LOOP;
END;
/


---------------------------------------------------------------------------------------------

DECLARE
	   CURSOR c1 IS
	   		  SELECT t1.department_id, department_name, staff
			  FROM departments t1,
			  ( SELECT department_id, COUNT(*) AS staff
			    FROM employees GROUP BY department_id
			  ) t2
			  WHERE
			  t1.department_id = t2.department_id
			  AND staff >= 5;
BEGIN
	 FOR dept IN c1
	 	 LOOP
       DBMS_OUTPUT.PUT_LINE('Department = ' || dept.department_name || ', staff = ' || dept.staff);
		 END LOOP;
END;
/


-------------------------------------------------------------------------------------------------

DECLARE
	TYPE empcurtyp IS REF CURSOR RETURN employees%ROWTYPE;
	 emp empcurtyp;
-- after result set is built, process all the rows inside a single procedure
-- rather than calling a procedure for each row

	PROCEDURE process_emp_cv (emp_cv IN empcurtyp) IS
	person employees%ROWTYPE;
BEGIN
	DBMS_OUTPUT.PUT_LINE('-----');
	DBMS_OUTPUT.PUT_LINE('Here are the names from the result set:');
		
       LOOP
		FETCH emp_cv INTO person;
			EXIT WHEN emp_cv%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE('Name = ' || person.first_name ||' ' || person.last_name);
	END LOOP;
END;


BEGIN
-- First find 10 arbitrary employees.
OPEN emp FOR SELECT * FROM employees WHERE ROWNUM < 11;
process_emp_cv(emp);
CLOSE emp;
-- find employees matching a condition.
OPEN emp FOR SELECT * FROM employees WHERE last_name LIKE 'R%';
process_emp_cv(emp);
CLOSE emp;
END;



-------------------------------------------------------------------------------------------------


CREATE OR REPLACE PROCEDURE Cc_Assign_Csr_From_Queue
(
	i_Csr_Id		  IN		    VARCHAR2,
	
     o_OutputStatus 	  OUT 	    NUMBER,
	o_OutputMessage   OUT 	    VARCHAR2		  
)
AS 
	v_CSR_Queue	  	  	VARCHAR2(100);
	sqlStr				VARCHAR2(1000);
	v_ProductCode			VARCHAR2(50);
	v_ErrorFlag			NUMBER;
	
	CURSOR Csr_Weight(v_Curr_Task NUMBER)
	IS
		 SELECT
			Csr_Id
		 FROM
			CC_CSR CSR
		 WHERE
			CSR.Last_Poll_Time > SYSDATE-15/(24*60*60)
			AND	CSR.Max_Task > v_Curr_Task
		 ORDER BY
			CSR.Weight DESC;

	CURSOR csr_roundrobin (v_curr_task NUMBER, v_User_ID VARCHAR2,v_Product VARCHAR2)
	IS
		SELECT USER_ID FROM CC_CSR_TASK_cst.LAST_POLL_TIME > SYSDATE-15/(24*60*60));

	  V_ERROR_LOCATION   			   NUMBER;
BEGIN
	v_Csr_Id:=NULL;

	v_Current_Tasks:= Cc_Get_Csr_Task(i_Csr_Id);
	
	v_ErrorFlag := 1;
	
	sqlStr := 
	'SELECT	 	'||
		   'session_id,				'||
		   'task_id,				'||
		   'owner,					'||
		   'CSR_TASK_STATE, 		'||	
		   'TASK_SOURCE				'||		
	'FROM  						'||
		   'cc_csr_task tsk			'||
	'WHERE 						'||
		 'tsk.OWNER in (SELECT queue_id FROM cc_csr_queue WHERE csr_id = ''' || i_Csr_Id || ''')													'||
		 'AND tsk.TASK_SOURCE IN (SELECT CODE FROM PRODUCT_MASTER WHERE COMPANY_CODE IN' ||  i_Company || ')	'||
		 'AND rownum < 2		    '||
		 'AND CSR_TASK_STATE NOT IN (''END'',''ENDED'')' ||
	'ORDER BY tsk.START_TIME';
			

-------------
	
	EXECUTE IMMEDIATE sqlStr INTO v_session_id,v_task_id,v_Owner,v_Csr_task_state,v_ProductCode;
	 
		v_ErrorFlag := 2;
			
		IF UPPER(i_Algo) = 'BY_WEIGHTS' THEN
			BEGIN
				OPEN Csr_Weight(v_Current_Tasks);
				FETCH Csr_Weight INTO v_Csr_Id;
				IF Csr_Weight%ISOPEN THEN
					CLOSE Csr_Weight;
				END IF;
			END;
			v_ErrorFlag := 3;
			
		ELSIF UPPER(i_Algo) = 'ROUNDROBIN' THEN
			BEGIN
				OPEN Csr_RoundRobin(v_Current_Tasks,i_Csr_Id,v_ProductCode);
				FETCH Csr_Roundrobin INTO v_Csr_Id;
				IF csr_roundrobin%ISOPEN THEN
					CLOSE Csr_Roundrobin;
				END IF;
			END;
			v_ErrorFlag := 4;
			
		ELSIF UPPER(i_Algo) = 'RANDOM' THEN
			BEGIN
			    V_ERROR_LOCATION := 1;
		   		SELECT
		   		   Csr_Id
				INTO
				   v_Csr_Id
 	  		FROM
 	  		   CC_CSR CSR,
			   	   SNOX_USER_ACCESS su
	  		WHERE
	  		  csr.CSR_ID = su.USER_ID 
			      AND su.CALLNOX = 'G'
			      AND CSR.MAX_TASK > v_Current_Tasks 
				  AND Csr_Id = i_Csr_Id;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					 v_Csr_Id := NULL;			
			END;
		ELSE
		    v_ErrorFlag := 5;
			BEGIN
				SELECT
				   csr_id
				INTO
				   v_Csr_Id
				FROM
				   CC_CSR csr,
			   	   SNOX_USER_ACCESS su
				WHERE
	  		   csr.CSR_ID = su.USER_ID
			   	   AND su.CALLNOX = 'G' AND				
				   csr.MAX_TASK > v_Current_Tasks
				   AND csr_id = i_Csr_Id;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					 v_Csr_Id := NULL;				
			END;

			v_ErrorFlag := 6;
		END IF;
		
		v_ErrorFlag := 7;
		
    IF v_Csr_Id IS NOT NULL THEN
   	    BEGIN   		
	        Cc_Transfer_Csr
			  (
			  	 v_session_id,
				 v_Task_id,
				 i_Csr_Id,
				 v_Owner,
				 'Auto assigned task FROM queue to user',
				 o_OutputStatus,
				 o_OutputMessage
			  );
			  
			v_ErrorFlag := 8;
			  
			IF o_OutputStatus <> 0 THEN			
				RETURN;
			END IF;
			
			v_ErrorFlag := 9;
			
			UPDATE CC_CSR_TASK_ASSIGN_TS 
			SET LAST_ASSIGN_TIME = SYSDATE
			WHERE USER_ID = i_Csr_Id;
			
			v_ErrorFlag := 10;
			
			IF v_Owner= 'CSR_DE_QUEUE' AND v_Csr_task_state = 'END'	THEN
				UPDATE
				   CC_CSR_TASK
			   	SET
				   CSR_TASK_STATE = 'DATA_ENTRY'
			   	WHERE
			   	   session_id  = V_session_id
			   	   AND task_id = V_task_id ;
			END IF;
			
			o_OutputStatus	:= 0 ;
			--o_OutputMessage	:= 'SUCCESS';
			COMMIT;
   	  EXCEPTION
	   	    WHEN OTHERS THEN
			  		o_OutputStatus	:=	102;
			  		o_OutputMessage	:=	SUBSTR(SQLERRM,1,100);
	   END;
	 ELSE
			o_OutputStatus	:=	103;
			o_OutputMessage 	:= 'CSR Not elligible to own task.';			
		END IF;
		
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  		 o_OutputStatus := 104;
	  o_OutputMessage  := 'No Task to Assign';  			 

  WHEN OTHERS THEN
	  o_OutputStatus := 101 ;
	  o_OutputMessage  := 'Procedure Cc_Assign_Csr_From_Queue failed AT  ' || v_ErrorFlag || ':' || SUBSTR(SQLERRM,1,100);
END;
/

-------------------------------------------------------
Example 6-32 Fetching from a Cursor Variable into a Record

DECLARE
TYPE empcurtyp IS REF CURSOR RETURN employees%ROWTYPE;
   emp_cv empcurtyp;
   emp_rec employees%ROWTYPE;
BEGIN
	OPEN emp_cv FOR SELECT * FROM employees WHERE employee_id < 120;
		 LOOP
		 	 FETCH emp_cv INTO emp_rec; -- fetch from cursor variable
			 EXIT WHEN emp_cv%NOTFOUND; -- exit when last row is fetched
-- process data record
   		   DBMS_OUTPUT.PUT_LINE('Name = ' || emp_rec.first_name || ' ' ||emp_rec.last_name);
		 END LOOP;
	CLOSE emp_cv;
END;
/
-------------------------------------------------------
Example 6-33 Fetching from a Cursor Variable into Collections
DECLARE
	TYPE empcurtyp IS REF CURSOR;
	emp_cv empcurtyp;
	
	TYPE namelist IS TABLE OF employees.last_name%TYPE;
	names namelist;
	
	TYPE sallist IS TABLE OF employees.salary%TYPE;
	sals sallist;
BEGIN
	OPEN emp_cv FOR SELECT last_name, salary FROM employees WHERE job_id = 'SA_REP';
		 FETCH emp_cv BULK COLLECT INTO names, sals;
	CLOSE emp_cv;
-- loop through the names and sals collections
      FOR i IN names.FIRST .. names.LAST
	  	  LOOP
		   	  DBMS_OUTPUT.PUT_LINE('Name = ' || names(i) || ', salary = ' || sals(i));
		 END LOOP;
END;
/

****************************************  REF CURSOR ****************************************




****************************************  SQL SERVER ****************************************
 
 --- convert date time format mm-dd-yyyy hh:mi:ss
 select convert(VARCHAR(21),ActiveDate, 120) from Agencies
 
 --------------------------------------------------------------------------------
 
 -- counts all rows of all tables 
 SELECT [TableName] = so.name, [RowCount] = MAX(si.rows) 
 FROM  sysobjects so, sysindexes si 
 WHERE so.xtype = 'U' 
     AND si.id = OBJECT_ID(so.name) 
GROUP BY so.name 


---------------------------------------------------------------------------------
-- if you forgot the sa password for sql server,
-- execute the command in dos
osql -E -d  -Q "sp_password NULL, 'sa', 'sa'"

****************************************  SQL Server ****************************************





****************************************  SCHEDULED JOBS ****************************************

-- Scheduled Jobs 

/*
This part includes information about creating a Scheduled Job to run the export procedure periodically. As
Scheduled Jobs come with Oracle 10g, scripts in this article will work on databases later than Oracle 10.1.x.x

The sys package we will mainly use is DBMS_SCHEDULER. First we should create a job. You can find the following
command that i used to create a job. Alternate parameters are explained with comments.
*/


--The scheduler allows you to optionally create programs which hold metadata about a task, but no schedule information. A program may related 
--to a PL/SQL block, a stored procedure or an OS executable file. Programs are created using the CREATE_PROGRAM procedure:

-- Create the test programs.
BEGIN
  -- PL/SQL Block.
  DBMS_SCHEDULER.create_program (
	program_name   => 'test_plsql_block_prog',
	program_type   => 'PLSQL_BLOCK',
	program_action => 'BEGIN DBMS_STATS.gather_schema_stats(''SCOTT''); END;',
	enabled        => TRUE,
	comments       => 'Program to gather SCOTT''s statistics using a PL/SQL block.');

  -- Shell Script.
  DBMS_SCHEDULER.create_program (
	program_name        => 'test_executable_prog',
	program_type        => 'EXECUTABLE',
	program_action      => '/u01/app/oracle/dba/gather_scott_stats.sh',
	number_of_arguments => 0,
	enabled             => TRUE,
	comments            => 'Program to gather SCOTT''s statistics us a shell script.');

  -- Stored Procedure with Arguments.
  DBMS_SCHEDULER.create_program (
	program_name        => 'test_stored_procedure_prog',
	program_type        => 'STORED_PROCEDURE',
	program_action      => 'DBMS_STATS.gather_schema_stats',
	number_of_arguments => 1,
	enabled             => FALSE,
	comments            => 'Program to gather SCOTT''s statistics using a stored procedure.');

  DBMS_SCHEDULER.define_program_argument (
	program_name      => 'test_stored_procedure_prog',
	argument_name     => 'ownname',
	argument_position => 1,
	argument_type     => 'VARCHAR2',
	default_value     => 'SCOTT');

  DBMS_SCHEDULER.enable (name => 'test_stored_procedure_prog');
END;
/

-- Display the program details.
SELECT owner, program_name, enabled FROM dba_scheduler_programs;

--Programs can be deleted using the DROP_PROGRAM procedure:
BEGIN
  DBMS_SCHEDULER.drop_program (program_name => 'test_plsql_block_prog');
  DBMS_SCHEDULER.drop_program (program_name => 'test_stored_procedure_prog');
  DBMS_SCHEDULER.drop_program (program_name => 'test_executable_prog');
END;
/





BEGIN 
    DBMS_SCHEDULER.CREATE_JOB(
       job_name           =>  'log_to_table',
       job_type           =>  'STORED_PROCEDURE',   
                              -- Possible values could be:
                              -- PLSQL_BLOCK, 
                              -- STORED_PROCEDURE, 
                              -- EXECUTABLE, 
                              -- CHAIN.
       job_action         =>  'D_EPEKER.p_test_01', -- schemaname.procedure name to run
       start_date         =>  'to_date(''03/15/2009 22:00:00'',''mm/dd/yyyy hh24:mi:ss'')', -- date_to_start_execution date
       repeat_interval    =>  'FREQ=MONTHLY', -- every other day
                              
                              -- Possible values could be:
                              -- "FREQ = YEARLY" | "MONTHLY" | "WEEKLY" | 
                              -- "DAILY" | "HOURLY" | "MINUTELY" | "SECONDLY" 
                              -- INTERVAL = 1 through 99 
         
       end_date           =>  'sysdate+1',     -- date_to_end_execution
       job_class          =>  'logging_class',  
       enabled       	  => TRUE, -- it can flase to not start the job 
       comments           =>  'job_logs_something');-- explanation of the job
END;

/*

Jobs are created disabled by default and need to be enabled to run. You can find the following procedure to alter a
Scheduled Jobs attribute. By default a scheduled job drops itself after its execution ends. You should set
"auto_drop" attribute to FALSE to hold the Scheduled Job after its execution ends.

*/
-- 
-- enabling a job 
-- 
BEGIN
  SYS.DBMS_SCHEDULER.ENABLE 
    (name => 'D_EPEKER.LOG_TO_TABLE');
END;
/


--Jobs can be deleted using the DROP_JOB procedure:

BEGIN
  DBMS_SCHEDULER.drop_job (job_name => 'test_full_job_definition');
  DBMS_SCHEDULER.drop_job (job_name => 'test_prog_sched_job_definition');
  DBMS_SCHEDULER.drop_job (job_name => 'test_prog_job_definition');
  DBMS_SCHEDULER.drop_job (job_name => 'test_sched_job_definition');
END;
/


-- 
-- altering a job attribute
-- 
BEGIN
    DBMS_SCHEDULER.SET_ATTRIBUTE(
        name => 'log_to_table',  -- name of the job
        attribute => 'auto_drop',  -- attribute name
        value => FALSE  -- new value of the attribute
        );
END;

/*

As you can schedule a job, you can also run any Scheduled Job before its Scheduled time comes. To run or stop a job
immediately you can use the following command.

*/
-- 
-- executing a job immediately 

-- run the job
exec DBMS_SCHEDULER.RUN_JOB('log_to_table',FALSE);

-- stop the job
exec DBMS_SCHEDULER.STOP_JOB('log_to_table',TRUE);

/*
The most likely property of this newly "Scheduled Job" is that they can be easily
maintained and monitored by system views. You can find the related view in the
following.
*/
-- schedued jobs whichs owner is D_EPEKER
select * from dba_scheduler_jobs where owner='D_EPEKER';

-- you can also user user_scheduled_jobs view to find out the jobs and their properties
select * from user_scheduler_jobs;

-- Display the program details.
SELECT owner, program_name, enabled FROM dba_scheduler_programs;

-- run details of the scheduled jobs
select * from DBA_SCHEDULER_JOB_RUN_DETAILS 
  where lower(job_name) = 'log_to_file_external';

/*

For e.g..


BEGIN 
    DBMS_SCHEDULER.CREATE_JOB(
       job_name           =>  'Report_On_Comments_Count',
       job_type           =>  'STORED_PROCEDURE',   
       job_action         =>  'system.send_mail_column_report', -- schemaname.procedure name to run
       start_date         =>  TO_DATE('02/11/2011 11:30:00','mm/dd/yyyy hh24:mi:ss'), -- date_to_start_execution date
       repeat_interval    =>  'FREQ=WEEKLY; BYDAY=FRI;', -- will run on every friday 
       end_date           =>  NULL,     -- date_to_end_execution
       enabled             => TRUE, -- it can flase to not start the job 
       comments           =>  'Report on Table/Column comments count');-- explanation of the job
END;
/

BEGIN
  -- Run job synchronously.
  DBMS_SCHEDULER.run_job (job_name=> 'Report_On_Comments_Count', use_current_session => FALSE);
END;
/

BEGIN
  SYS.DBMS_SCHEDULER.ENABLE 
    (NAME => 'Report_On_Comments_Count');
END;
/

BEGIN
    DBMS_SCHEDULER.SET_ATTRIBUTE(
        NAME => 'Report_On_Comments_Count',  -- name of the job
        ATTRIBUTE => 'auto_drop',  -- attribute name
        VALUE => FALSE  -- new value of the attribute
        );
END;
/

exec DBMS_SCHEDULER.RUN_JOB('Report_On_Comments_Count',FALSE);

SELECT * FROM dba_scheduler_jobs WHERE job_name='REPORT_ON_COMMENTS_COUNT'

*/  
  
  
  
/*

There is a lot of way to determine the repeat interval. There is lots of examples 
in the following and you can also find the explanations of the frequencies.

*/
-- 
-- setting repeat_interval 
-- 
--Run every Friday
FREQ=DAILY; BYDAY=FRI;
FREQ=WEEKLY; BYDAY=FRI;
FREQ=YEARLY; BYDAY=FRI;

--Run every other Friday
FREQ=WEEKLY; INTERVAL=2; BYDAY=FRI;

--Run on the last day of every month.
FREQ=MONTHLY; BYMONTHDAY=-1;

--Run on the next to last day of every month.
FREQ=MONTHLY; BYMONTHDAY=-2;

--Run every 10 days
FREQ=DAILY; INTERVAL=10;

--Run daily at 4, 5, and 6PM.
FREQ=DAILY; BYHOUR=16,17,18;

--Run on the 15th day of every other month
FREQ=MONTHLY; INTERVAL=2; BYMONTHDAY=15;

--Run on the 29th day of every month
FREQ=MONTHLY; BYMONTHDAY=29;

--Run on the second Wednesday of each month
FREQ=MONTHLY; BYDAY=2WED;

--Run on the last Friday of the year.
FREQ=YEARLY; BYDAY=-1FRI;

--Run every 50 hours.
FREQ=HOURLY; INTERVAL=50;

--Run on the last day of every other month.
FREQ=MONTHLY; INTERVAL=2; BYMONTHDAY=-1;

--Run hourly for the first three days of every month.
FREQ=HOURLY; BYMONTHDAY=1,2,3;

--Run on the last workday of every month, excluding company holidays 
--(This example references an existing named schedule called Company_Holidays.)
FREQ=MONTHLY; BYDAY=MON,TUE,WED,THU,FRI; EXCLUDE=Company_Holidays; BYSETPOS=-1

--Run at noon every Friday and on company holidays.
FREQ=YEARLY;BYDAY=FRI;BYHOUR=12;INCLUDE=Company_Holidays


/*

-- To run everynight at midnight starting tonight
exec dbms_job.submit(:v_JobNo, 'proc1;', TRUNC(SYSDATE)+1, 'TRUNC(SYSDATE)+1');

-- To run every hour, on the hour, starting at the top of the hour
exec dbms_job.submit(:v_JobNo, 'proc2;', TRUNC(SYSDATE+(1/24), 'HH'),
'TRUNC(SYSDATE+(1/24),''HH'')');

-- To run every hour, starting now
exec dbms_job.submit(:v_JobNo, 'proc3;', INTERVAL => 'SYSDATE+(1/24)');

-- To run every ten minutes at 0,10,20,etc. minutes past the hour,
-- starting at the top of the hour
exec dbms_job.submit(:v_JobNo, 'proc4;', TRUNC(SYSDATE+(1/24), 'HH'),
'TRUNC(SYSDATE+(10/24/60),''MI'')');

-- To run every 2 min., on the minute, starting at the top of the 
-- minute
exec dbms_job.submit(:v_JobNo, 'proc5;', TRUNC(SYSDATE+(1/24/60), 'MI'),
'TRUNC(SYSDATE+(2/24/60),''MI'')');

-- To run every two minutes, starting now
exec dbms_job.submit(:v_JobNo, 'proc6;', INTERVAL => 'SYSDATE+(2/24/60)');

-- To run every half hour, starting at the top of the hour
exec dbms_job.submit(:v_JobNo, 'proc7;', TRUNC(SYSDATE+(1/24), 'HH'),
'TRUNC(SYSDATE+(30/24/60),''MI'')');


*/


-- Simple DB Job
-- which executes each day at 4:00 PM

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( job       => X
   ,what      => 'DECLARE
       a NUMBER;
       b VARCHAR2(1000);
BEGIN
    P0(a,b);
END;   '
   ,next_date => to_date('24/07/2010 04:00:00','dd/mm/yyyy hh24:mi:ss')
   ,interval  => 'trunc(sysdate + 1) + 4/24'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
COMMIT;
END;
/

****************************************  SCHEDULED JOBS ****************************************





****************************************  ACL NETWORK For Setup of MAILS ****************************************
-- connect to system user

SELECT ANY_PATH
FROM RESOURCE_VIEW
WHERE ANY_PATH LIKE '/sys/acls/dba%';


BEGIN
    DBMS_NETWORK_ACL_ADMIN.CREATE_ACL (
    ACL => 'dba.xml', -- case sensitive
    DESCRIPTION=> 'Network Access Control for the DBAs',
    PRINCIPAL => 'RAHULC', -- user or role the privilege is granted or denied (upper case)
    IS_GRANT => TRUE, -- privilege is granted or denied
    PRIVILEGE => 'connect', -- or 'resolve' (case sensitive)
    START_DATE => NULL, -- when the access control entity ACE will be valid
    END_DATE => NULL); -- ACE expiration date (TIMESTAMP WITH TIMEZONE format)
END;
/

BEGIN
 DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE 
  (
    ACL => 'dba.xml',
    PRINCIPAL => 'RAHULC',
    IS_GRANT => TRUE,
    PRIVILEGE => 'connect',
    START_DATE => NULL, -- if the time interval is defined,
    END_DATE => NULL
 ); -- the ACE will expire after the specified date range
END;
/

BEGIN
  DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL (
    acl         => 'dba.xml',
    HOST        => 'MAIL.INFONOX.COM', 
    lower_port  => 25,
    upper_port  => 25); 
    COMMIT;
END;
/

--------------------------------->>>>>>>>>>>>>>>>

SELECT host, lower_port, upper_port, acl
FROM   dba_network_acls;


BEGIN
  DBMS_NETWORK_ACL_ADMIN.drop_acl (acl => 'dba1.xml');
  COMMIT;
END;
/

begin
 DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE 
  (
    ACL => 'dba.xml',
    PRINCIPAL => 'RAHULC',
    IS_GRANT => TRUE,
    PRIVILEGE => 'connect',
    START_DATE => null, -- if the time interval is defined,
    END_DATE => null
 ); -- the ACE will expire after the specified date range
end;
/

BEGIN
  DBMS_NETWORK_ACL_ADMIN.delete_privilege ( 
    acl         => 'dba1.xml', 
    principal   => 'RAHULC',
    is_grant    => TRUE, 
    privilege   => 'execute');

  COMMIT;
END;
/

SELECT acl,
       principal,
       privilege,
       is_grant,
       TO_CHAR(start_date, 'DD-MON-YYYY') AS start_date,
       TO_CHAR(end_date, 'DD-MON-YYYY') AS end_date
FROM   dba_network_acl_privileges;

grant execute on UTL_SMTP to public
--------------------------------->>>>>>>>>>>>>>>>

---------------------*********************-------------------


CREATE OR REPLACE PROCEDURE RAHULC.SEND_EVENT_MAIL
(
    o_OutputStatus OUT  NUMBER,
    o_OutputMessage OUT VARCHAR2 
)
AS
        v_mailHost     VARCHAR2(50):='MAIL.INFONOX.COM';
        v_Connection UTL_SMTP.Connection;
        v_reply UTL_SMTP.REPLY;
        
        MESSAGE      VARCHAR2(32767);
        crlf         VARCHAR2(2):=CHR(13)||CHR(10);
        
        v_error_flag NUMBER;
        
        v_Sender     VARCHAR2(100); --- mail sender
        v_Recipient  VARCHAR2(100); --- CC list
        
        v_Subject    VARCHAR2(100); --- Mail subject
        
        v_Body       VARCHAR2(32767);  --- Mail body
        
        v_cc_recipt1 VARCHAR2(100);
        
        v_date       VARCHAR2(20);
        v_Data       VARCHAR2(32767);
        v_Data_f     VARCHAR2(32767);
        v_count      NUMBER;
BEGIN
        SELECT TO_CHAR(SYSDATE,'mm/dd/yyyy hh24:mi:ss') INTO v_date FROM dual;
        
        v_error_flag :=1;
        -- Mail sender
        v_Sender     := 'rahulc@infonox.com';
        
        -- TO list
        v_Recipient  := 'rahulc@infonox.com';
        v_cc_recipt1 := 'baidhar@infonox.com'; 

        v_data:=NULL;
        FOR z  IN
        ( SELECT SCHEMA_NAME, TABLE_NAME FROM TABLE_LIST ORDER BY 1, 2 ASC)
        LOOP
                v_error_flag:=3;
                v_data_f    :='<TR><TD>'||z.SCHEMA_NAME ||'</TD><TD>'||UPPER(z.TABLE_NAME) ||'</TD></TR>';
                v_error_flag:=4;
                v_data      := v_data_f||v_data;
        END LOOP;

        v_error_flag:=5;
        v_data      :='<TR bgcolor="#CCCCCC"><TD>SCHEMA_NAME</TD><TD>TABLE_NAME</TD></TR>'||v_data;

                v_error_flag:=6;
                v_Subject    := 'Oracle Version 11G from Dev11G DB 231.84' ;
                
                v_error_flag:=7;
                v_Body      := '<BODY><FONT FACE="Courier New" size="04"> Hi Baidhar, </FONT></BODY> <br>'|| 
                               '&nbsp;&nbsp;&nbsp;&nbsp;<BODY><FONT FACE="Courier New" size="04"> Sending the '||
                               'Mail from Oracle version 11g from devdb dev11g database 192.168.231.84. Just printing some table data result here in HTML format of date '||v_date||
                               '</FONT></BODY>. <br>'|| '<BODY><FONT FACE="Courier New" size="11"><TABLE BORDER="1">'||v_data||
                               '</TABLE></FONT></BODY> <br><br>'|| '<BODY><FONT FACE="Courier New" size="04">Regards<br>'|| 
                               '- Rahul Chaudhari </FONT></BODY>';
        
                v_error_flag :=8;
                
                v_Connection := UTL_SMTP.OPEN_CONNECTION(v_mailHost, 25);
                v_reply      := UTL_SMTP.HELO(v_Connection, v_mailHost);
                v_reply      := UTL_SMTP.MAIL(v_Connection, v_Sender);
                v_reply      := UTL_SMTP.RCPT(v_Connection, v_Recipient);
                
                v_error_flag:=9;

                IF v_cc_recipt1 IS NOT NULL THEN
                   UTL_SMTP.rcpt(v_Connection,v_cc_recipt1);
                END IF;
                    
                MESSAGE := 'From: '||v_Sender||crlf|| 
                           'To: '||v_Recipient||crlf|| 
                           'Subject: '||v_Subject||crlf||''||crlf||v_Body;
                
                v_error_flag:=10;
                
                UTL_SMTP.DATA(v_Connection,'Content-type: text/html'|| crlf||MESSAGE);
                UTL_SMTP.QUIT(v_Connection);
                

        o_OutputStatus:='0';
        o_OutputMessage:='SUCCESS';
        
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Step number: '||v_error_flag||' Message: '||SUBSTR(SQLERRM,1,100));
END SEND_EVENT_MAIL;
/


****************************************  ACL NETWORK For Setup of MAILS ****************************************



****************************************  External Tables ****************************************

-- Creating an External Table and Loading Data

/*
	The following example creates an external table, then uploads the data to a 
	database table. We have tested the examples in the Oracle9i Database 
	Administrators Guide Release 1 (9.0.1) using Oracle 9.0.1 on Windows 2000.

	The file empxt1.dat in C:\Users\Zahn\Work contains the following sample data:

	7369,Schmied,Schlosser,7902,17.12.1980,800,0,20
	7499,Zaugg,Verk�ufer,7698,20.02.1981,1600,300,30
	7521,M�ller,Verk�ufer,7698,22.02.1981,1250,500,30
	7566,Holzer,Informatiker,7839,02.04.1981,2975,0,20
	7654,Zahn,Verk�ufer,7698,28.09.1981,1250,1400,30
	7698,Sutter,Informatiker,7839,01.05.1981,2850,0,30
	7782,Graf,Informatiker,7839,09.06.1981,2450,0,10

	The file empxt2.dat in C:\Users\Zahn\Work contains the following sample data:

	7788,Gasser,Analytiker,7566,19.04.1987,3000,0,20
	7839,Kiener,Lehrer,,17.11.1981,5000,0,10
	7844,Stoller,Verk�ufer,7698,08.09.1981,1500,0,30
	7876,Amstutz,Automechaniker,7788,23.05.1987,1100,0,20
	7900,Weigelt,Automechaniker,7698,03.12.1981,950 ,0,30
	7902,Wyss,Analytiker,7566,03.12.1981,3000,0,20
	7934,Messerli,Automechaniker,7782,23.01.1982,1300,0,10

	The following SQL statements create an external table and load its data into 
	database table EMP of the user scott.

*/

sqlplus /nolog

SQL*Plus: Release 9.0.1.0.1 - Production on
Sat Jan 26 10:44:48 2002
(c) Copyright 2001 Oracle Corporation. All rights reserved.

CONNECT  SYS/MANAGER  AS SYSDBA;
SET ECHO ON;

CREATE OR REPLACE DIRECTORY dat_dir AS 'C:\Oracle\Data';
CREATE OR REPLACE DIRECTORY log_dir AS 'C:\Oracle\Log';
CREATE OR REPLACE DIRECTORY bad_dir AS 'C:\Oracle\Bad';

Directory created.

GRANT READ ON DIRECTORY dat_dir TO scott;
GRANT WRITE ON DIRECTORY log_dir TO scott;
GRANT WRITE ON DIRECTORY bad_dir TO scott;

Grant succeeded.

CONNECT scott/tiger;
DROP TABLE empxt;

CREATE TABLE empxt (empno       NUMBER(4),
                    ename       VARCHAR2(20),
                    job         VARCHAR2(20),
                    mgr         NUMBER(4),
                    hiredate    DATE,
                    sal         NUMBER(7,2),
                    comm        NUMBER(7,2),
                    deptno      NUMBER(2)
                   )
 ORGANIZATION EXTERNAL
 (
   TYPE ORACLE_LOADER
   DEFAULT DIRECTORY dat_dir
   ACCESS PARAMETERS
   (
     records delimited by newline
     badfile bad_dir:'empxt%a_%p.bad'
     logfile log_dir:'empxt%a_%p.log'
     fields terminated by ','
     missing field values are null
     ( empno,
       ename,
       job,
       mgr,
       hiredate char date_format date mask "dd.mm.yyyy",
       sal,
       comm,
       deptno
     )
   )
   LOCATION ('empxt1.dat', 'empxt2.dat')
 )
 PARALLEL
 REJECT LIMIT UNLIMITED;

Table created.

ALTER SESSION ENABLE PARALLEL DML;

Session altered.

/*
	The first few statements in this example create the directory objects for the 
	operating system directories that contain the data sources, and for the bad 
	record and log files specified in the access parameters. You must also grant 
	READ or WRITE directory object privileges, as appropriate.

	The TYPE specification is given only to illustrate its use. If not specified, 
	ORACLE_LOADER is the default access driver. The access parameters, specified 
	in the ACCESS PARAMETERS clause, are opaque to Oracle. These access parameters
	are defined by the access driver, and are provided to the access driver by 
	Oracle when the external table is accessed.

	The PARALLEL clause enables parallel query on the data sources. The granule 
	of parallelism is by default a data source, but parallel access within a data 
	source is implemented whenever possible. For example, if PARALLEL=3 were 
	specified, then more than one parallel execution server could be working on 
	a data source.

	The REJECT LIMIT clause specifies that there is no limit on the number of 
	errors that can occur during a query of the external data. For parallel 
	access, this limit applies to each parallel query slave independently. 
	For example, if REJECT LIMIT 10 is specified, each parallel query process 
	is allowed 10 rejections. Hence, the only precisely enforced values for 
	REJECT LIMIT on parallel query are 0 and UNLIMITED.

*/

****************************************  External Tables ****************************************







****************************************  Oracle Installation ****************************************
--- hidden commands for installing oracle and some commands useful while installing oracle
http://pafumi.net/RAC_10g_Vmware.html


http://www.petefinnigan.com/other.htm

Oracle Installation Stuff



# set the kernel parameters

vi /etc/sysctl.conf

				
kernel.shmall = 18874368
kernel.shmmax = 3147483648  -- Smallest of -> (Half the size of the physical memory) or (4GB - 1 byte)
kernel.shmmni = 4096 -- semaphores: semmsl, semmns, semopm, semmni
kernel.sem = 250 32000 100 128
fs.file-max = 65536 --# 512 * PROCESSES
net.ipv4.ip_local_port_range = 1024 65000
net.core.rmem_default=4194304
net.core.rmem_max=4194304
net.core.wmem_default=262144
net.core.wmem_max=262144

-- For Enterprise Linux 5.0, the following lines should be appended to the "/etc/sysctl.conf" file.

kernel.shmmni = 4096
# semaphores: semmsl, semmns, semopm, semmni
kernel.sem = 250 32000 100 128
net.ipv4.ip_local_port_range = 1024 65000
net.core.rmem_default=4194304
net.core.rmem_max=4194304
net.core.wmem_default=262144
net.core.wmem_max=262144

-- Run the following command to change the current kernel parameters:

    /sbin/sysctl -p
    
Notes: Execute sysctl -p to make these new settings take effect.

--------------------------------------------------------------------------

#set the limitation parameters.

 vi /etc/security/limits.conf

oracle           soft    nofile          63536
oracle           hard    nofile          63536

oracle           soft    nproc           16384
oracle           hard    nproc           16384

oracle           soft    memlock         3145728
oracle           hard    memlock         3145728


--------------------------------------------------------------------------
--Add the following line to the /etc/pam.d/login file, if it does not already exist:

vi /etc/pam.d/login

session    required     pam_limits.so


--------------------------------------------------------------------------
-- Disable secure linux by editing the /etc/selinux/config file, making sure the SELINUX flag is set as follows:

SELINUX=disabled
    
--------------------------------------------------------------------------
# change the hosts and ip address setting as per the db server name and ip

vi /etc/hosts


127.0.0.1       localhost.localdomain localhost  --- local ip and localhost
10.66.15.212    sc-siguedb2.ifxsc.com sc-siguedb2 --- ip and DB Server name
10.66.15.213    sc-siguedb1.ifxsc.com sc-siguedb1 -- ip and db server name of standby DB
10.65.235.60    sqlcluster SQLCLUSTER CLUSTER	  -- ip and db server name of cluster DB
# 65.216.123.102  sqlcluster SQLCLUSTER CLUSTER



# reboot the linux server to take the effect in above memory configuration files.
# you should be on root for executing the below command for rebooting the linux server

sync;sync;reboot



--------------------------------------------------------------------------

-- set up the vncserver by login into oracle account
-- execute all the below commands in oracle account for vncserver set and start.
service vncserver start / stop

vncpasswd

vncserver :1.1521 --- starts vncserver for 1521 port only on :1

login to vnc and start the runinstall.sh from oracle user account


-- changes in vncserver file for starting in gnome mode

vi /home/oracle/.vnc/xstartup --- this is the home directory of oracle change as per your's

#make the chages before EOF of the file
exec gnome-session &

-- save the vncserver file and exit from vi editor

#kill the session of vncserver
vncserver -kill :1



/*

 unset SESSION_MANAGER
 exec /etc/X11/xinit/xinitrc

[ -r $HOME/.Xresources ] && xrdb $HOME/.Xresources
xsetroot -solid grey
vncconfig -iconic &
xterm -geometry 80x24+10+10 -ls -title "$VNCDESKTOP Desktop" &
exec gnome-session
twm &

*/

--------------------------------------------------------------------------
To create the oracle account and groups, execute the following commands: 
su - root
groupadd dba          # group of users to be granted SYSDBA system privilege
groupadd oinstall     # group owner of Oracle files
useradd -c "Oracle software owner" -g oinstall -G dba oracle -d /ora1/oracle

passwd oracle

cd /home/oracle

mkdir OraHome1

chown -R oracle.oinstall /home/oracle/OraHome1
chmod -R 777 /home/oracle/OraHome1

chown -R oracle.dba /ora1
chown -R oracle.dba /ora2
chown -R oracle.dba /ora3

chmod -R 777 /ora1
chmod -R 777 /ora2
chmod -R 777 /ora3


--------------------------------------------------------------------------

login to oracle account and modify .bash_profile  
file as per the ORACLE_BASE / ORACLE_HOME and ORACLE_SID  and also set rest environment
variables in this file 

for e.g

vi .bash_profile

# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs
ORACLE_BASE=/oracle
ORACLE_HOME=/oracle/OraHome1

#ORACLE_SID=stag
#ORACLE_SID=qadb

export ORACLE_BASE
export ORACLE_HOME
export ORACLE_SID

unset TWO_TASK
export LD_ASSUME_KERNEL=2.4.20
PATH=$ORACLE_HOME/bin:/usr/bin:/bin:/usr/bin/X11:/usr/local/bin:/sbin:

#PATH=$PATH:$HOME/bin

export PATH
unset USERNAME

--------------------------------------------------------------------------

#execute the command for unzip the file having .cpio extension else make it unzip which is having .zip extension
cpio -idmv < <file_path.cpio>

unzip <file_patch_path.zip>


--------------------------------------------------------------------------

-- Listener settings
LISTENER =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = 10.120.90.63)(PORT = 1521))
    )
  )


SID_LIST_LISTENER =
    (SID_DESC =
      (GLOBAL_DBNAME = qadb)
      (ORACLE_HOME = $ORACLE_HOME)
      (SID_NAME = qadb)
    )
  )



--------------------------------------------------------------------------

-- TNS Entry settings
qadb =
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.120.90.63)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=qadb)
    )
  )
  
  
  
  
  
--Final Setup******************************************************************************************
Create the new groups and users:

    groupadd oinstall
    groupadd dba
    groupadd oper
    groupadd asmadmin

    useradd -g oinstall -G dba,oper,asmadmin oracle
    passwd oracle

Note. We are not going to use the "asmadmin" group, since this installation will not use ASM.

Create the directories in which the Oracle software will be installed:

    mkdir -p /u01/app/oracle/product/11.1.0/db_1
    chown -R oracle:oinstall /u01
    chmod -R 775 /u01

Login as root and issue the following command:

    xhost +<machine-name>

Login as the oracle user and add the following lines at the end of the .bash_profile file:


# Oracle Settings
TMP=/tmp; export TMP
TMPDIR=$TMP; export TMPDIR

ORACLE_HOSTNAME=octifxsdb01.ifxtempe.com; export ORACLE_HOSTNAME

ORACLE_BASE=/u01/app/oracle; export ORACLE_BASE
ORACLE_HOME=$ORACLE_BASE/product/11.1.0/db_1; export ORACLE_HOME

ORACLE_SID=devdb; export ORACLE_SID

ORACLE_TERM=xterm; export ORACLE_TERM

PATH=/usr/sbin:$PATH; export PATH

PATH=$ORACLE_HOME/bin:$PATH; export PATH

#LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib; export LD_LIBRARY_PATH
#CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

if [ $USER = "oracle" ]; then
  if [ $SHELL = "/bin/ksh" ]; then
	ulimit -p 16384
	ulimit -n 65536
  else
	ulimit -u 16384 -n 65536
  fi
fi



--Installation
Log into the oracle user. If you are using X emulation then set the DISPLAY environmental variable:

    DISPLAY=<machine-name>:0.0; export DISPLAY
    
****************************************  Oracle Installation ****************************************




****************************************  Linux Command ****************************************

-- Linux Helpfull Command List

-- replace the string in big files without opening the files
grep -rl US7ASCII test.log |xargs sed -i -e 's/US7ASCII/US7ASCII1267892345/g'

--Shell scripting with conditions 

If then else condition

-eq-Checks to see if arguments are equal (for example, if [ 2 -eq 5 ] )
-ne-Checks for inequality of arguments
-lt-Checks if argument 1 is less than argument 2
-le-Checks if argument 1 is less than or equal to argument 2
-gt-Checks if argument 1 is greater than argument 2
-ge-Checks if argument 1 is greater than or equal to argument 2
-f-Checks if a file exists (for example, if [ -f "filename" ] )
-d-Checks if a directory exists

------------------------------------------------------------------------------

USEFUL SHELL SCRIPT ARGUMENTS

execute the below using echo ARGUMENTS

$1,$2----Positional parameter representing command line argument
$#----Number of arguments specified in command line
$0----Name of executed commands  -- for eg. echo $"Usage: $0 {start|stop|status|reload|restart|condrestart}"
$*---Complete set of positional parameters as a single string
"$@"----Each quotated string treated as seprate argument (recommended over $*)
$?---Exit status of last command
$$-- pid of current shell
#!----Pid of last bagoround job

---------------------------------------------------------------------------------

-- returns all the lines that contain a string 
-- matching the expression "foo" in the file "snox4transnox_backup_logs". 
 grep ORA snox4transnox_backup_logs.log

----------------------------------------------------------------------------------

 --- last 2 weeks files
find transnox/wucc/exp*.dmp -mtime -14 -print
 
--- exclude files which are modified last 2 weeks back... and take all files 
find transnox/wucc/exp*.dmp ! -mtime -14 -ls


--- this command finds out file which are not in modified in 14 days and which are in between 26 days
 find ../../transnox/centennial/exp*.dmp ! -mtime +26 ! -mtime -14 -ls
 
 
 -- one day prevoius file sreaching
 find /ora3/oracle/oradata/coms/archive -type f -mtime +0 -exec ls -l {} \;
 
 
 -- sreaching for the days given 
 ls -ltrh |grep "Jul  5"

 -- remove the files up till date like Mar 12
 ls -ltr | grep "Mar 12" | awk '{print $9}'  | xargs rm -f
 
 
  tar -zvxf snoxgateway.tar.gz
 
 %s/angad/rahul
 
 %s/angad/rahul/g
 
%s/\/home\/angad/\/home\/rahul/g


-- vi option for replace in front of script
:%s/^/ mv /g 

-- vi option for replace at the end of the script
:%s/$/ \/moneris5\/old_archive\/coms /g


:%s/$/ \/ora10\/old_archive /g

/ora10




-- checking the multiple disk space on linux
#!/bin/bash
for ID in `df -h | grep -v none | grep -v Filesystem | grep -v "/" | grep -v -w "home"| awk '{if ($5 > "80%") print $1 " " $5}' | sed 's/ /=/g'`
do
        echo $ID | sed 's/=/ /g'
        excecute the script
done


-- checking the /home partition disk space on linux
VAL=`df -h | grep "/ora4" | awk '{print $5}'`

if [ $VAL > 80 ]
then
	execute script
else
	:
fi

--- we can move more the one files in one command
-- i is string and 
-- t is verbose
ls olddir | xargs -i -t mv olddir/ newdir/


--- scp command help
expect -c "
# exp_internal 1 # uncomment for debugging
spawn  scp -q qcp_xtns.dmp oracle@logarchive.ifxlv.com:/archive/bkups/dumps/transmoneris
expect { 
		"*password:*" { send oracle@7534\r\n; interact } 
		eof { exit }
	}
exit
"
 
------------------------------------------

 /* vi command option */
 
 vi command options
 
 esc :q!         --Just quit - donot save 
 esc :e!         --Revert to saved 
 esc :wq         --Save and exit 
 
 esc shift zz    --Save and exit 
 esc i           --Enter insert mode (edit mode) 
 esc a           --Enter append mode (edit mode) 
 esc             --Exit edit mode 
 esc r           --Replace a single character 
 esc x           --Delete a single character 
 esc dd          --Delete a single line 
 esc yy          --Copy a single line 
 esc p           --Paste a single line 
 .               --Repeat the last command 
 esc /           --String search 
 esc $           --Jump to end of line 
 esc ^           --Jump to begining of line 
 shift g         --Jump to the end of the file 
 :1              --Jump to the begining of the file 
 :.=             --Display the current line number 

----------------------------------------------------

--command finds the unique key values in a file
cat gcatest.log|awk -F ' ' {'print $3'}|uniq|sort|uniq

--- will delete the first thousand 
ls -ltrh|head -n 1000|awk '{print $9}'|xargs rm -f


00 19 * * * sh /archive/dba/bkups/bkups_scripts/veroDB_bkup_script.sh


-- to remove the 3 days older files
30 21 * * * find /ora1/oracle/bkups/dumps/transending/moneris/* -ctime +3 -exec rm -R {} \;




file:///E:/mainStuff/Oracle%20Doc/Oracle%2010G%20streams/Streams%20Demo%201.htm
--********************************************************************--
*/15 * * * *  sh /ora3/archive_cronjob/arch_1day_older_files.sh

#!/bin/bash

# checking the /ora3 disk partition space where archive files are getting create
VAL=`df -h | grep "/ora3" | awk '{print $5}'|sed 's/%//g'`

if [ $VAL '>' 78 ]
then
    echo  $VAL > log_no_ds.log
    echo "/ora3 Disk space above 80%"

	cd /ora3/oracle/oradata/tsnd/archive

	find 1_*.arc -type f -mtime +0 -exec ls -l {} \; > temp_file.sh

	for fn in `cat temp_file.sh |awk '{print $9}'`
	do
		echo " "

		# making the ta files
		MK_TAR=`echo $fn |sed 's/.arc/.tar.gz/g'`
		tar -cvzf $MK_TAR  $fn

		# deleting non tar files
		rm -f $fn

		# moving thetar file to different destination
		mv $MK_TAR  /ora4/old_archive
	done

	rm -f temp_file.sh
else
    echo "$VAL"
    echo "/ora3 Disk space is below 80%"
fi



*/30 * * * *  sh /ora3/old_archive/remove_old_arch_scrpt.sh


#!/bin/bash

# checking the /ora4 disk partition space where archive files are getting create
VAL=`df -h | grep "/ora4" | awk '{print $5}'|sed 's/%//g'`

if [ $VAL '>' 78 ]
then
    echo  $VAL > log_no_ds.log
    echo "/ora4 Disk space above 80%"

	cd /ora4/old_archive

	find *.tar.gz -type f -mtime +0 -exec ls -l {} \; | awk '{print $9}'|xargs rm -f

else
    echo "$VAL"
    echo "/ora4 Disk space is below 80%"
fi


--********************************************************************--
-- for standby database's
*/15 * * * *  sh /ora3/archive_cronjob/arch_1day_older_files.sh

#!/bin/bash

# checking the /ora3 disk partition space where archive files are getting create
VAL=`df -h | grep "/ora3" | awk '{print $5}'|sed 's/%//g'`

if [ $VAL '>' 76 ]
then
    echo  $VAL > log_no_ds.log
    echo "/ora3 Disk space above 80%"

	cd /ora3/oracle/oradata/tsnd/archive

	find 1_*.arc -type f -mtime +0 -exec ls -l {} \; | awk '{print $9}'|xargs rm -f 

else
    echo "$VAL"
    echo "/ora3 Disk space is below 80%"
fi


--********************************************************************--

*/
****************************************  Linux Command ****************************************
