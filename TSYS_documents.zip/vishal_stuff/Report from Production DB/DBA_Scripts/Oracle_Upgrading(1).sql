

/* Some points 

To minimize the downtime during the upgrade process one can switch the database to NOARCHIVELOG mode. Once the upgrade
has been completed successfully the ARCHIVELOG mode has to be switched on again.


*/






--------
Upgrading the CPU patches 

set the path of opatch utility

export PATH=$PATH:$ORACLE_HOME/OPatch

Use the following syntax for this command:

opatch napply [patch_location] [-id comma-separated list of patch IDs] [-delay <value> ] [ -force ] [-invPtrLoc <Path to oraInst.loc> ] [-jdk <LOC> ] [-jre <LOC> ] [ -local ] [-minimize_downtime ] [-no_bug_superset ] [-no_inventory ] [-oh <ORACLE_HOME> ] [-retry <value> ] [-silent ] [-verbose ]  [-no_relink] [-pre <parameters for the pre script in escaped double quotes> [-opatch_pre_end] ] [-post <parameters for the post script in escaped double quotes> [-opatch_post_end] ] [-no_sysmod] [ -property_file <Path to property file> ] [ -local_node <Local node name> ] [ -remote_nodes <List of remote nodes (node1,node2)> ] [ -all_nodes ] [ -phBaseFile <Path to the file containing the location of the patches to be applied> ] [-skip_subset] [-skip_duplicate] [-report]

Examples

1) The following example applies all patches under the <patch_location> directory:

opatch napply <patch_location>

2) The following example applies patches 1, 2, and 3 that are under the <patch_location> directory:

opatch napply <patch_location> -id 1,2,3

3) The following example applies all patches under the <patch_location> directory. OPatch skips duplicate patches and 
subset patches (patches under <patch_location> that are subsets of patches installed in the Oracle home).

opatch napply <patch_location> -skip_subset -skip_duplicate

for e.g..

opatch napply /home/oracle/software/psu_patches/cpu_patchset/10249534 -skip_subset -skip_duplicate


See the description for the skip_subset option in Table 7-3 for more information.

4) The following example applies patches 1, 2, and 3 that are under the <patch_location> directory. OPatch skips duplicate patches and 
subset patches (patches under <patch_location> that are subsets of patches installed in the Oracle home).

opatch napply <patch_location> -id 1,2,3 -skip_subset -skip_duplicate

See the description for the skip_subset option in Table 7-3 for more information.


-- Check once the Critical Patche Update is done by opatch utility
opatch lsinventory -detail



Patch Deinstallation Instructions:
----------------------------------

1. Make sure to follow the same pre-install steps when deinstalling
a patch.  This includes verifying the inventory and shutting down
any services running from the ORACLE_HOME / machine before rolling
the patch back.

2. Change to the directory where the patch was unzipped.
  cd <PATCH_TOP>/8639653

3. Run OPatch to deinstall the patch.
  opatch rollback -id 8639653











-----************************************************************************************
Final Setps

*** The first step is to take the required schemas backup.
*** Take the Spfile and Pfile backup.

SQL>CREATE PFILE='$ORACLE_HOME/dbs/initdevdb.ora' FROM SPFILE;

SQL> shutdown immediate
SQL> startup 
SQL> shutdown normal


Starting for Upgrading Oracle Patchset version 11.1.0.7.0 (R1)

1) download the latest patchset versionn for R1 release

2) unzip in different folder

mkdir patchset_070

mv p6890831_111070_Linux-x86-64.zip patchset_070/

cd patchset_070/

unzip p6890831_111070_Linux-x86-64.zip

3) loggin as sysdba and shutdown the database before starting installation of new oracle version patchset.

SQL>shutdown immediate;

4) stop the running listener

lsnrctl stop

4) start the VNCServer for installation of latest oracle version

vncserver :1

5) start installation of Oracle patchset latest version and check for any errors while installation of software 
and run the script which installation is asking while installing the software.

6) After installation is done successfully then connect to sysdba 

sqlplus / as sysdba

SQL>startup upgrade

If the errors is coming as 
ORA-03113: end-of-file on communication channel
Process ID: 5565
Session ID: 170 
Serial number: 3

while connecting starting the database in mount stage...

To resolve the Bug ... Bug 7272646: ORA-27103 WHEN MEMORY_TARGET > 3G

https://support.oracle.com/CSP/main/article?cmd=show&type=BUG&id=7272646


There are the parameteres in init parameter file .ora in which we have to look into

memory_target=13500416000
devdb.__pga_aggregate_target=5380243456
devdb.__sga_target=8120172544


resolve it by

commenting memory_target parameter and memory_target - devdb.__sga_target = devdb.__pga_aggregate_target


After modification in init parameter file save it 

7) Again connect to sysdba

sqlplus / as sysdba

SQL>create spfile from pfile='/home/oracle/app/oracle/product/11.1.0/db_1/dbs/initdevdb.ora';


SQL> startup upgrade

8) After successfully open database without any errors execute the script catupgrd.sql

Along with catalog.sql and catproc.sql, many other scripts will get execute by calling catupgrd.sql

SQL> @$ORACLE_HOME\rdbms\admin\catupgrd.sql


9) Restart the database using immediate keyword and restart the database with normal startup command

SQL> SHUTDOWN IMMEDIATE

SQL> STARTUP

10) Run the utlrp.sql script to recompile all invalid PL/SQL packages now instead of when the packages are accessed for the first time. This step is optional but recommended.

SQL> @ORACLE_BASE\ORACLE_HOME\rdbms\admin\utlrp.sql

--- should check for the invalid objects
SELECT COUNT(*) FROM UTL_RECOMP_COMPILED;

--- Use the command to flush the pool. 
ALTER SYSTEM FLUSH SHARED_POOL 





shared_pool_reserved_size - 
	Controls the amount of SHARED_POOL_SIZE reserved for large allocations. The fixed view V$SHARED_POOL_RESERVED helps you tune these parameters. 
Begin this tuning only after performing all other shared pool tuning on the system. 

shared_pool_reserved_min_alloc - 
	Controls allocation for the reserved memory. To create a reserved list, SHARED_POOL_RESERVED_SIZE must be greater than SHARED_POOL_RESERVED_MIN_ALLOC. 
Only allocations larger than SHARED_POOL_RESERVED_POOL_MIN_ALLOC can allocate space from the reserved list if a chunk of memory of sufficient size is 
not found on the shared pool free lists. The default value of SHARED_POOL_RESERVED_MIN_ALLOC should be adequate for most systems. 





Finally, a run of the post-upgrade status script utlu111s.sql is required to
verify that all components have been upgraded successfully to Oracle
Database 11g:

SQL>@?/rdbms/admin/utlu111s.sql




