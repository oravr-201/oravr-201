--- Flash Back Query

-- Oracle Flashback Query can only be used if the server is configured to use Automatic 
-- Undo Management, rather than traditional rollback segments. The maximum time period 
-- that can be flashbacked to is defined using the UNDO_RETENTION parameter in the 
-- init.ora file. Alternatively, this parameter can be set using:

ALTER SYSTEM SET UNDO_RETENTION = <seconds>;

--- privilege to flashback any table 
GRANT FLASHBACK ANY TABLE to <username>;

--- Query to get the deleted data before 10 minutes
SELECT * FROM LOOKUP_TRANS_STATUS
 AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE); 
 
-- so like wish u can insert the data back in the table  
INSERT INTO LOOKUP_TRANS_STATUS
 SELECT * FROM LOOKUP_TRANS_STATUS
  AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE);
-- if wanna selected data from deleted data then  
   WHERE CONDITION... = ?;
 
 

--To select data as if we where in the past, you can use a flashback query. How long 
--you can go back depends on the size of the UNDO tablespace and on how quickly that fills up. 

--If you want to see the content of the table 1 hour ago you can query it like:

SELECT *
FROM tablename
AS OF TIMESTAMP SYSTIMESTAMP - INTERVAL '1' HOUR;


--If you want to see the content of the table 2 days ago you can query it like:

SELECT *
FROM tablename
AS OF TIMESTAMP SYSTIMESTAMP - INTERVAL '2' DAY;

--or you can select the status per SCN number.

--To query the current SCN number:

SELECT DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER() FROM DUAL; 


--To select a SCN number (System Change Number) on a specific timestamp:

SELECT TIMESTAMP_TO_SCN('11-JUN-09 10.30.09.000000000 AM') FROM dual; 


--With this SCN number you can query in the past with "scn-number":

SELECT *
FROM tablename
AS OF SCN "scn-number";


--To select changes on a table since a specific System Change Numbers (SCN):

SELECT * FROM tabelnaam
VERSIONS BETWEEN SCN SCN_x AND MAXVALUE; 
 

-- Initialization Parameters 
 
--Setting the location OF the flashback 
recovery area db_recovery_file_dest=/oracle/flash_recovery_area 
 
 
--Setting the size OF the flashback 
recovery area db_recovery_file_dest_size=2147483648 
 
--Setting the retention TIME FOR flashback files (IN minutes)
-- 2 days
db_flashback_retention_target=2880 




/*
Flashback Table
Just like the flashback query helps retrieve rows of a table, 
FLASHBACK TABLE helps restore the state of a table to a certain 
point in time even if a table structure changed has occurred since 
then. The following command will take us to the table state at the
specified timestamp.
*/
 
FLASHBACK TABLE EMPLOYEE TO 
TIMESTAMP ('15-SEP-08 8:50:58','DD-MON-YY HH24: MI: SS');
 
/*
This command will not only restore the tables, but also the 
associated objects like indexes, constraints etc.
*/
 
 
/*
Flashback Drop
Oracle 10g introduces the function "Flashback drop". If a DROP 
TABLE command has been issued for the table EMPLOYEE, we can 
still restore the entire table by issuing the following command:
*/
 
FLASHBACK TABLE EMPLOYEE TO BEFORE DROP;
 
-- Recovering a dropped table doesn't any easier than this!
 
 
/*
Flashback database
Flashback Database requires the creation and configuration of 
an Oracle Flash Recovery Area before this feature can be used. 
 
"Flash Recovery Area", created by the DBA, is the allocation of 
space on the disk to hold all the recovery related files (Flashback 
Logs, Redo Archive logs, RMAN backups, and copies of control files).
 
Use the initialization parameters db_recovery_file_dest and 
b_recovery_file_dest_size to set the destination and the size 
of the recovery area.
 
Set Flashback to enabled to make Oracle database enter the 
flashback mode. The database must be mounted as Exclusive and 
not open. The database also has to be in the ARCHIVELOG MODE 
before we can use this feature:
*/
 
ALTER DATABASE ARCHIVELOG;
 
-- start the database in EXCLUSIVE mode:
 
SHUTDOWN IMMEDIATE;
STARTUP MOUNT EXCLUSIVE
 
 
-- enter flashback mode:
 
ALTER DATABASE FLASHBACK ON;
 
 
-- issue the Flashback command and rewind the database to 
-- the state it was in one hour ago.
 
Flashback database TO TIMESTAMP sysdate-(1/24);
 
-- after the system comes back with FLASHBACK COMPLETE, 
-- open the database:
 
ALTER DATABASE OPEN RESETLOGS;
 
-- the database is now restored. 
 
-- note that we have the option 
-- of using SCN instead of timestamp.
 
 
 
 
 
 
 
 
 
 
