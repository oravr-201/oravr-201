---- check for which session is locked
SELECT 
  oracle_username, os_user_name, locked_mode,
  object_name,object_type
FROM v$locked_object a,DBA_OBJECTS b
WHERE a.object_id = b.object_id    
 
SELECT Oracle_Username Username, owner Object_Owner, Object_Name, Object_Type, s.osuser, s.SID SID,
		s.SERIAL# SERIAL,DECODE(l.BLOCK, 0, 'Not Blocking', 1, 'Blocking', 2, 'Global') STATUS,
		DECODE(v.locked_mode, 0, 'None', 1, 'Null', 2, 'Row-S (SS)', 3, 'Row-X (SX)', 4, 'Share', 5, 'S/Row-X (SSX)', 6, 'Exclusive', TO_CHAR(lmode) ) MODE_HELD
FROM gv$locked_object v, dba_objects d, gv$lock l, gv$session s
WHERE v.object_id = d.object_id
  AND (v.object_id = l.id1)
  AND v.session_id = s.SID
ORDER BY oracle_username, session_id;
