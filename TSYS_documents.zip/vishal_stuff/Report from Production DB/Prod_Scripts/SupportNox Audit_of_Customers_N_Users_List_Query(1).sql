



SELECT SYS_CONTEXT('USERENV','DB_NAME') FROM dual;

-- Naming convention for the databases are 
1) ClassicGCA DB   -- QCPWDB primary database
2) TransITGCA DB   -- Transnox GCA primary database
3) Reporting DB	   -- SupportNox primary database
4) CPass DB        -- Counter Pass database
5) Transending DB  -- COMS/Moneris/Sigue Transending database
6) GIT DB          -- Transending GCA (transgca) database

SELECT DECODE(UPPER(SYS_CONTEXT('USERENV','DB_NAME')),'GITDB','GIT DB') "DB Name", 
   ab.grantee "Username", NVL(TRIM(granted_role),'NO PRIVILEGES') "Roles", 
   (CASE 
     WHEN granted_role = 'DBA' THEN 'Read+Write'
     WHEN granted_role = 'RESOURCE' THEN 'Read Only'
     WHEN granted_role = 'CONNECT' THEN 'Read Only'
     WHEN granted_role = 'VIEWER' THEN 'Read Only' 
     WHEN granted_role IN ('EXP_FULL_DATABASE','IMP_FULL_DATABASE','DATAPUMP_EXP_FULL_DATABASE','DATAPUMP_IMP_FULL_DATABASE') THEN 'Read Only(Backups)'
     WHEN granted_role = 'DB_RELEASE_GROUP' THEN 'Read+Write'
     WHEN granted_role = 'OPERATOR' THEN 'Read Only'
     ELSE 'SYSTEM'
   END) "Read/Write",
   du.account_status "Account_Status"
FROM 
 (
    SELECT username grantee, ' ' granted_role FROM dba_users WHERE username NOT IN (SELECT grantee FROM dba_role_privs) AND username NOT IN (SELECT grantee FROM dba_sys_privs) 
    UNION ALL
    SELECT  grantee, granted_role  granted_role FROM dba_role_privs WHERE grantee IN (SELECT username FROM dba_users)
    UNION ALL
    SELECT grantee, PRIVILEGE granted_role
    FROM dba_sys_privs
    WHERE grantee NOT IN (SELECT grantee FROM dba_role_privs)
      AND grantee IN (SELECT username FROM dba_users)
  ) ab,
  dba_users du
WHERE ab.grantee = du.username
 AND DU.USERNAME NOT IN ('ANONYMOUS','APEX_PUBLIC_USER','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_030000','FLOWS_FILES','MDDATA','MDSYS','MGMT_VIEW','OLAPSYS',
 'ORACLE_OCM','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS',
 'SYSMAN','SYSTEM','TSMSYS','WK_TEST','WKPROXY','WKSYS','WMSYS','XDB','XS$NULL')
ORDER BY 2 ASC  




--- Query to get non customer Accounts details


-- this query should be execute in 
1) snox schema Reporting DB
 
select 
    cc.CSR_ID "User_ID",
    cc.CSR_NAME "User_Name",
    cc.CSR_TYPE "User_Type",
    cc.CSR_STATUS "Current_Status",
    cc.ACCESS_PROFILE_NAME "Access_Profile",
    cc.REPORT_UPDATE_FLAG "Has_Report_Update_Rights",
    sua.SENSITIVE_DATA_VISIBLE "Sensitive_Data_Visible",
    sua.REPORTNOX "ReportNox_Access",
    sua.MONITORNOX "MonitorNox_Access",
    sua.CALLNOX "CallNox_Access",
    sua.ADMINNOX "AdminNox_Access",
    sua.RULENOX "RuleNox_Access",
    sua.GLUON_IDM "Gluon_Idm_Access",
    null "IDETransnox_Access",      --- for Classic SupportNox
    cc.COMPANY_CODE "User_Company",
    null "Business_Visible",    	--- for Classic SupportNox
    cc.EMAIL_ID "Email_Id",
    cc.MERCHANT_ID "Merchant_Only",
    null "Corporation_Only",    	--- for Classic SupportNox
    cc.IS_LOCKED "Is_Locked",
    cc.LAST_LOGIN_DATE "Last_Login",
    sua.OWNER "User_Created_By"  
from 
    snox.cc_csr cc, 
    snox.snox_user_access sua 
where 
    cc.CSR_ID = sua.USER_ID and 
    (UPPER(cc.email_id) like '%@INFONOX%' or UPPER(cc.email_id) like '%@TSYS%')


2) snox4transnox_gca Reporting DB
3) snox4transnox CPass DB
select 
    cc.CSR_ID "User_ID",
    cc.CSR_NAME "User_Name",
    cc.CSR_TYPE "User_Type",
    cc.CSR_STATUS "Current_Status",
    cc.ACCESS_PROFILE_NAME "Access_Profile",
    cc.REPORT_UPDATE_FLAG "Has_Report_Update_Rights",
    sua.SENSITIVE_DATA_VISIBLE "Sensitive_Data_Visible",
    sua.REPORTNOX "ReportNox_Access",
    sua.MONITORNOX "MonitorNox_Access",
    sua.CALLNOX "CallNox_Access",
    sua.ADMINNOX "AdminNox_Access",
    sua.RULENOX "RuleNox_Access",
    sua.GLUON_IDM "Gluon_Idm_Access",
    sua.IDETRANSNOX "IDETransnox_Access",   --- column not present in classic gca
    cc.COMPANY_CODE "User_Company",
    cc.COMPANY_ID "Business_Visible",       --- column not present in classic gca
    cc.EMAIL_ID "Email_Id",
    cc.MERCHANT_ID "Merchant_Only",
    cc.Corporation_ID "Corporation_Only",   --- column not present in classic gca
    cc.IS_LOCKED "Is_Locked",
    cc.LAST_LOGIN_DATE "Last_Login",
    sua.OWNER "User_Created_By" 
from 
    cc_csr cc, 
    snox_user_access sua 
where 
    cc.CSR_ID = sua.USER_ID and 
    (UPPER(cc.email_id) like '%@INFONOX%' or UPPER(cc.email_id) like '%@TSYS%')





--*************************************************************************************************************

--- Query to get customer Accounts details

1) snox schema Reporting DB
 
select 
    cc.CSR_ID "User_ID",
    cc.CSR_NAME "User_Name",
    cc.CSR_TYPE "User_Type",
    cc.CSR_STATUS "Current_Status",
    cc.ACCESS_PROFILE_NAME "Access_Profile",
    cc.REPORT_UPDATE_FLAG "Has_Report_Update_Rights",
    sua.SENSITIVE_DATA_VISIBLE "Sensitive_Data_Visible",
    sua.REPORTNOX "ReportNox_Access",
    sua.MONITORNOX "MonitorNox_Access",
    sua.CALLNOX "CallNox_Access",
    sua.ADMINNOX "AdminNox_Access",
    sua.RULENOX "RuleNox_Access",
    sua.GLUON_IDM "Gluon_Idm_Access",
--    sua.IDETRANSNOX "IDETransnox_Access",     ---
    null "IDETransnox_Access",     --- for Classic SupportNox
    cc.COMPANY_CODE "User_Company",
--    cc.COMPANY_ID "Business_Visible",       ---
    null "Business_Visible",    --- for Classic SupportNox
    cc.EMAIL_ID "Email_Id",
    cc.MERCHANT_ID "Merchant_Only",
--    cc.Corporation_ID "Corporation_Only",       ---
    null "Corporation_Only",    --- for Classic SupportNox
    cc.IS_LOCKED "Is_Locked",
    cc.LAST_LOGIN_DATE "Last_Login",
    sua.OWNER "User_Created_By"  
from 
    snox.cc_csr cc, 
    snox.snox_user_access sua 
where 
    cc.CSR_ID = sua.USER_ID and NOT
    (UPPER(cc.email_id) like '%@INFONOX%' or UPPER(cc.email_id) like '%@TSYS%')


2) snox4transnox_gca Reporting DB
3) snox4transnox CPass DB
select 
    cc.CSR_ID "User_ID",
    cc.CSR_NAME "User_Name",
    cc.CSR_TYPE "User_Type",
    cc.CSR_STATUS "Current_Status",
    cc.ACCESS_PROFILE_NAME "Access_Profile",
    cc.REPORT_UPDATE_FLAG "Has_Report_Update_Rights",
    sua.SENSITIVE_DATA_VISIBLE "Sensitive_Data_Visible",
    sua.REPORTNOX "ReportNox_Access",
    sua.MONITORNOX "MonitorNox_Access",
    sua.CALLNOX "CallNox_Access",
    sua.ADMINNOX "AdminNox_Access",
    sua.RULENOX "RuleNox_Access",
    sua.GLUON_IDM "Gluon_Idm_Access",
    sua.IDETRANSNOX "IDETransnox_Access",     ---
--    null "IDETransnox_Access",     --- for Classic SupportNox
    cc.COMPANY_CODE "User_Company",
    cc.COMPANY_ID "Business_Visible",       ---
--    null "Business_Visible",    --- for Classic SupportNox
    cc.EMAIL_ID "Email_Id",
    cc.MERCHANT_ID "Merchant_Only",
    cc.Corporation_ID "Corporation_Only",       ---
--    null "Corporation_Only",    --- for Classic SupportNox
    cc.IS_LOCKED "Is_Locked",
    cc.LAST_LOGIN_DATE "Last_Login",
    sua.OWNER "User_Created_By" 
from 
    cc_csr cc, 
    snox_user_access sua 
where 
    cc.CSR_ID = sua.USER_ID and NOT
    (UPPER(cc.email_id) like '%@INFONOX%' or UPPER(cc.email_id) like '%@TSYS%')





    
    
    
    