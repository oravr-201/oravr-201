/*

     PIF clear has to be done from Primary QCPW-DB, if the records are not present in primary database then first 
populate the records from reporting DB and the execute the update query in checkcash.chkc_transactions table
and make the accountstatuscode='CPC' which is Complete Payment Received


*/

--- pif clear query
SELECT CXT.TRANSACTIONID, CXT.AMOUNT+CXT.SERVICECHARGE amt, CXT.REF_NUMBER,CXT.ACCOUNTSTATUSCODE,CXT.TIMESTAMP,
  CXT.TRANSACTIONDATE, CXT.CHECKNO
FROM CHECKCASH.CHKC_TRANSACTIONS cxt
WHERE CXT.TRANSACTIONID='6948223890'
AND CXT.AMOUNT+CXT.SERVICECHARGE='13000'


-- CPC = Complete Payment Received.
select *
from checkcash.chkc_return_status_master
where return_status_code='CPC'

update CHECKCASH.CHKC_TRANSACTIONS
set ACCOUNTSTATUSCODE='CPC'
where <Where conditions ???>

commit;