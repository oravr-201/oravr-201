
SELECT /*+Ordered first_rows */
  xtn.TASK_ID "Task_ID",
  xtn.TRANSACTION_ID "Transaction_ID",
  ltt.DESCRIPTION "Transaction_Type",
  xtn.TIME_STAMP "Transaction_TimeStamp",
  xtn.CLIENT_TIMESTAMP "Client_Timestamp",
  Date_Diff_In_Time(sysdate,xtn.time_stamp) "Duration",
  NVL(xtn.CURRENCY,'NA') "Currency",
  NVL(xtn.AMOUNT,0)/100 "Transaction_Amount",
  NVL(xtn.FEE_CHARGED,0)/100 "Fee_Charged",
  NVL(cnm.CARD_ENCRYPT ,'927D3761EE3F952F6B28D9DAEEE5F879') "Card_Number",
  tc.ENTRY_MODE "Entry_Mode",
  NVL(
  (SELECT tb1.ACCOUNT_TYPE
  FROM TRANS_BANK_DETAIL tb1
  WHERE xtn.TRANSACTION_ID = tb1.TRANSACTION_ID
  AND tb1.TRANSFER_TYPE    = 'FROM'
  ),'NA') "From_Account",
  NVL(
  (SELECT tb1.ACCOUNT_TYPE
  FROM TRANS_BANK_DETAIL tb1
  WHERE xtn.TRANSACTION_ID = tb1.TRANSACTION_ID
  AND tb1.TRANSFER_TYPE    = 'TO'
  ),'NA') "To_Account",
  (
  CASE
    WHEN (xtn.REASON_CODE IS NOT NULL)
    THEN (xtn.REASON_CODE
      ||' - '
      ||ltrc.DESCRIPTION)
    ELSE ('NA')
  END) "Reason_Code",
  tc.SEQUENCE_NUMBER "Sequence_Number",
  td.SERVICE_CODE "Service_Code",
  td.SUBSERVICE_CODE "Sub_Service_Code",
  xtn.TRANS_STATUS "Transaction_Status",
  GET_DEVICE_POSTYPE(xtn.DEVICE_ID) "POS_Type",
  xtn.DEVICE_ID "Device_ID",
  dev.MERCHANT_ID "Merchant_ID",
  mer.CORPORATION_ID "Corporation_ID"
FROM TRANSACTION xtn,
  TRANS_DETAIL td,
  LOOKUP_TRANS_TYPE ltt,
  CARD_NUMBER_MASTER cnm,
  LOOKUP_TRANS_REASON_CODE ltrc,
  TRANS_CARD tc,
  DEVICE dev,
  MERCHANT mer,
  CORPORATION corp
WHERE xtn.TRANSACTION_ID=td.TRANSACTION_ID
AND td.SUBSERVICE_CODE  ='PRE_AUTH'
AND xtn.time_stamp     >= sysdate  - 5/24
AND xtn.TIME_STAMP BETWEEN SYSDATE - 3 AND SYSDATE - 5/1440
AND xtn.TRANS_STATUS   ='APPROVED'
AND ltt.CODE           =xtn.TRANS_TYPE
AND xtn.TRANSACTION_ID = tc.TRANSACTION_ID(+)
AND tc.CARD_NUMBER     = cnm.CARD_SEQNO(+)
AND xtn.REASON_CODE    = ltrc.CODE (+)
AND dev.DEVICE_ID      =xtn.DEVICE_ID
AND mer.MERCHANT_ID    =dev.MERCHANT_ID
AND corp.CORPORATION_ID=mer.CORPORATION_ID
AND corp.COMPANY_CODE  = 'GCA'
ORDER BY 1,  2



