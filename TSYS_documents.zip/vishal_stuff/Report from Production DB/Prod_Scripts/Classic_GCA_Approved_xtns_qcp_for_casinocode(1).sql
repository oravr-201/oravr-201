select mc.machineid, xtns.*
from qcp.transactions xtns, qcp.machines mc
where xtns.casinocode = mc.casinocode
and xtns.CASINOCODE='448204'
  and xtns.TIMESTAMP between to_date('01/01/2010','mm/dd/yyyy')
                         and to_date('01/31/2010 23:59:59','mm/dd/yyyy hh24:mi:ss')
  and mc.machineid in (204438,204439)
  and xtns.transaction_status in ('AUT','ATC','PTS','PTC','COM','CDC')
  and xtns.transaction_type in ('RBCA','RTCA','PSCA','RPCA','ACCA','RDCA','DBCA','QMCA','RMCA','OBCA','ARCA','RRCA')

                         
                         