-- To check the Risk process of TransCapitalOne
SELECT debug_seq_id, handle, time_stamp, CASE WHEN handle LIKE '%End%' THEN SUBSTR(TO_CHAR("Diff"),12,11)ELSE '-' END "Diff"
FROM 
(
    SELECT debug_seq_id, handle, time_stamp, time_stamp-lag(time_stamp,1) OVER(ORDER BY debug_seq_id, time_stamp) "Diff"
    FROM 
    (
        SELECT debug_seq_id, handle, MIN(time_stamp) time_stamp
        FROM TRANSCAPITALONE.RISK_DEBUG_LOG rdl
        WHERE RDL.TIME_STAMP >= TRUNC(SYSDATE)-1
          AND rdl.data1 IS NULL
        GROUP BY debug_seq_id, handle
        ORDER BY 1,3
    )
);
