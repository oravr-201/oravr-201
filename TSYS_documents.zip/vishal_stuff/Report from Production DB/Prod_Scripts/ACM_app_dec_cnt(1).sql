select 
	cas.casinoname "Casino_Name",
	cas.casinocode "Casino_Code",
	COUNT(DISTINCT mac.MACHINEID) "Transacting_Machines",
	(SELECT COUNT(am.MACHINEID) FROM ACM_MACHINES am WHERE am.CASINOCODE = cas.casinocode AND am.IS_ENABLED='Y') "Total_Active_Machines",
	SUM(Approved_XTN_Count) "App_Count",
	SUM(Approved_XTN_Count)/COUNT(DISTINCT mac.MACHINEID) "Avg_App_Count_Per_Machine",
	SUM(Approved_Amount) * 100/100 "App_Amount",
	SUM(Approved_Fee) * 100/100 "App_Fees",
	ROUND (SUM(Approved_Amount) / DECODE (SUM(Approved_XTN_Count), 0, 1, SUM(Approved_XTN_Count)) ) * 100/100 "App_Avg_Amount",
	SUM(Declined_XTN_Count) "Dec_Count",
	SUM(Declined_Amount)  * 100/100 "Dec_Amount",
	SUM(Declined_Fee)  * 100/100 "Dec_Fees",
	ROUND (SUM(Declined_Amount) / DECODE (SUM(Declined_XTN_Count), 0, 1, SUM(Declined_XTN_Count)) ) * 100/100 "Dec_Avg_Amount",
	SUM(Cancelled_XTN_Count) "Cancel_Count",
	SUM(Cancelled_Amount)  * 100/100 "Cancelled_Amount",
	SUM(Cancelled_Fee)  * 100/100 "Cancel_Fees",
	ROUND (SUM(Cancelled_Amount) / DECODE (SUM(Cancelled_XTN_Count), 0, 1, SUM(Cancelled_XTN_Count)) ) * 100/100 "Cancel_Avg_Amount",
	COUNT (DECODE (wsc.val, 'TRUE', 1, NULL )) "BioMetrics_ATMs" 
from 
	ACM_MACHINES mac,
	ACM_WSCONFIGURATIONS wsc,
	QCP_casinos cas,
	( SELECT  
		casinocode,  
		MACHINEID,  
		SUM (CASE WHEN transaction_state IN ('BME','DSF','DLF','CDC','CDS','CRC','CRS','TRA')THEN 1 ELSE 0 END) Approved_XTN_Count,  
		SUM (CASE WHEN transaction_state IN ('BME','DSF','DLF','CDC','CDS','CRC','CRS','TRA')THEN amount ELSE 0 END) Approved_Amount,  
		SUM (CASE WHEN transaction_state IN ('BME','DSF','DLF','CDC','CDS','CRC','CRS','TRA')THEN servicecharge ELSE 0 END) Approved_Fee,  
		SUM (CASE WHEN transaction_state IN ('EPT', 'ISF', 'CLE', 'INP', 'TRD', 'TRT') THEN 1 ELSE 0 END) Declined_XTN_Count,  
		SUM (CASE WHEN transaction_state IN ('EPT', 'ISF', 'CLE', 'INP', 'TRD', 'TRT') THEN amount ELSE 0 END) Declined_Amount,  
		SUM (CASE WHEN transaction_state IN ('EPT', 'ISF', 'CLE', 'INP', 'TRD', 'TRT') THEN servicecharge ELSE 0 END) Declined_Fee, 
		0 cancelled_XTN_Count, 
		0 cancelled_Amount,
		0 cancelled_Fee  
	FROM  
		acm_transactionS  
	WHERE  
		transactiondate between to_date('04/01/2008 00:00:00','mm/dd/yyyy hh24:mi:ss') and to_date('04/30/2008 23:59:59','mm/dd/yyyy hh24:mi:ss')  and  
		Transaction_Type IN ('ABCC', 'ABCK', 'ABSV','ACRT','ACRP','ACBT', 'AWCC', 'AWCK', 'AWSV' ,'CCCA', 'CCVP', 'CCAE', 'CCEN', 'CCER', 'CCFV', 'CCIE', 'CCLA', 'CCNB', 'CCNP', 'CCOC', 'CCPA', 'CCPF', 'CCRN', 'CCSN', 'CCVF', 'POSA', 'POSP', 'POOC', 'POLA', 'POAE','PODE','POTE','PADE','PATE','CCFA', 'CCFF','CCMS')  
	GROUP BY casinocode, MACHINEID  
	UNION   
	SELECT     
		qt.casinocode,  
		qt.WORKSTATIONCODE MACHINEID,  
		SUM (CASE WHEN qt.chkc_transaction_status in ( 'ATC', 'AUT', 'CDC', 'PTC', 'PTS', 'VDC', 'VOD') THEN 1 ELSE 0 END) Approved_XTN_Count,  
		SUM (CASE WHEN qt.chkc_transaction_status in ( 'ATC', 'AUT', 'CDC', 'PTC', 'PTS', 'VDC', 'VOD') THEN amount ELSE 0 END)/100 Approved_Amount,  
		SUM (CASE WHEN qt.chkc_transaction_status in ( 'ATC', 'AUT', 'CDC', 'PTC', 'PTS', 'VDC', 'VOD') THEN casinofee ELSE 0 END)/100 Approved_Fee,   
		SUM (CASE WHEN qt.chkc_Transaction_status  in  ('DEC','TRT') THEN 1 ELSE 0 END) Declined_XTN_Count,   
		SUM (CASE WHEN qt.chkc_Transaction_status  in  ('DEC','TRT') THEN amount ELSE 0 END)/100  Declined_Amount,    
		SUM (CASE WHEN qt.chkc_Transaction_status  in  ('DEC','TRT') THEN casinofee ELSE 0 END)/100 Declined_Fee,  
		SUM (CASE WHEN qt.chkc_Transaction_status  in  ('CSD','CMS', 'CDR','CCR','CST','CFV','CNI','CRC','CSC','CSV','CVD') THEN 1 ELSE 0 END) cancelled_XTN_Count,   
		SUM (CASE WHEN qt.chkc_Transaction_status  in  ('CSD','CMS', 'CDR','CCR','CST','CFV','CNI','CRC','CSC','CSV','CVD') THEN amount ELSE 0 END)/100  cancelled_Amount,    
		SUM (CASE WHEN qt.chkc_Transaction_status  in  ('CSD','CMS', 'CDR','CCR','CST','CFV','CNI','CRC','CSC','CSV','CVD') THEN casinofee ELSE 0 END)/100 cancelled_Fee   
	FROM   
		qcp_telechecktransactions qt,  
		acm_check_transactions act  
	WHERE  
		qt.transsource = 'A' AND  
		qt.chkc_transaction_status in ( 'ATC', 'AUT', 'CDC', 'PTC', 'PTS', 'VDC', 'VOD','CSD','CMS', 'CDR','CCR','CST','CFV','CNI','CRC','CSC','CSV','CVD','DEC','TRT') and
		act.transactionid = qt.transactionid AND 
		act.transactionid = qt.transactionid AND
		qt.transactiondate  between to_date('04/01/2008 00:00:00','mm/dd/yyyy hh24:mi:ss') and to_date('04/30/2008 23:59:59','mm/dd/yyyy hh24:mi:ss') 
		GROUP BY qt.casinocode,qt.WORKSTATIONCODE 
	) xtn 
where  
    wsc.casinocode = mac.casinocode  and
    wsc.workstationcode = mac.machineid  and  
    wsc.PARAM = 'IS_BIOMETRIC_AVAILABLE'  and  
    cas.casinocode = mac.casinocode  and
    xtn.casinocode  = mac.CASINOCODE  and
    xtn.MACHINEID  = mac.MACHINEID
GROUP BY cas.casinoname, cas.casinocode
