CREATE OR REPLACE PROCEDURE Pdnb_Send_File
(
i_Settle_Date         IN             DATE,
io_CSV_Data           IN OUT         CLOB,
o_OutPutStatus        OUT            NUMBER,
o_OutPutMessage       OUT            VARCHAR2
)
AS
v_Errorflag                          NUMBER;
v_Column_Heading_chck                VARCHAR2(2000);
v_Column_Heading_MO                  VARCHAR2(2000);
v_FROM_DATE                          DATE;
v_TO_DATE                            DATE;
v_Records                            CLOB;
V_nextline                           VARCHAR2(2);
v_string1                            CLOB;
v_string2                            VARCHAR2(4000);
v_string3                            VARCHAR2(4000);
v_string4                            VARCHAR2(4000);
v_string5                            VARCHAR2(4000);
v_string6                            VARCHAR2(4000);
v_string7                            VARCHAR2(4000);
v_string8                            VARCHAR2(4000);
v_file_name                          VARCHAR2(30);

BEGIN
v_Errorflag := 1;
          SELECT
          CHR(13)||''||CHR(10)
          INTO V_nextline
          FROM
          dual;
v_Errorflag := 2;

          v_file_name :='EOD_'||TO_CHAR(i_Settle_Date,'mmddyy')||'.CSV';

          v_FROM_DATE := TO_DATE(TO_CHAR( i_Settle_Date -1,'mm-dd-yyyy' ) ||' '|| '07:00:00' ,'mm-dd-yyyy hh24:mi:ss');
          v_TO_DATE := TO_DATE( TO_CHAR(  i_Settle_Date,'mm-dd-yyyy' ) ||' '|| '06:59:59' , 'mm-dd-yyyy hh24:mi:ss');

v_Errorflag := 3;

          DBMS_LOB.CREATETEMPORARY (v_Records, FALSE,10);  --- Work Clob Variable
          DBMS_LOB.CREATETEMPORARY (io_CSV_Data, FALSE,10); --- OutPut Variable

v_Errorflag := 4;
          /*   --- Columns Heading
          v_Column_Heading_chck :=
          Transaction_ID,
          Kiosks_ID,
          Merchant_ID,
          Transaction_Date,
          Transaction_Time,
          Transaction_Type,
          Transaction_Status,
          Reason,
          Terminal_ID,
          Provider_Confirmation_Number,
          Cash_In_out_indicator,
          Cash_Dispensed_Accepted,
          Amount_Remittance_to_SSA,
          Amount_Remittance_to_PDNB,
          SSA_Convenience_Fee '
          server_date
          server_time          ;

          --- giving column Heading first and then all records will be insert into v_Records variable
          DBMS_LOB.WRITEAPPEND(v_Records,LENGTH(v_Column_Heading_chck),v_Column_Heading_chck);
          */
          --- loop for Checkcashing Query to get records in one line separated by \n for new line record

v_Errorflag := 4;

-------------------------------------------------------  CHKC  ------------------------------------------------------------------------------------------

            FOR i IN (
          SELECT
                XTN.TRANSACTION_ID Transaction_ID,
                XTN.DEVICE_ID Kiosks_ID,
                dev.MERCHANT_ID Merchant_ID,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date ,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
                'CHKC' Transaction_Type,
                XTN.TRANS_STATUS Transaction_Status,
                ltrc.DESCRIPTION Reason,
                ( SELECT DISTINCT dt.TERMINAL_ID FROM Device_terminal dt  WHERE dt.DEVICE_ID = XTN.DEVICE_ID AND dt.TERMINAL_TYPE = 'ATM') Terminal_ID ,
                NULL Provider_Confirmation_Number,
                'DISPENSED' Cash_In_out_indicator,
                tc.AMOUNT_DISPENSED Cash_Dispensed_Accepted,
                '0' Amount_Remittance_to_SSA,
                ((tc.AMOUNT_DISPENSED) + (tfd.FEE - tfd.DISCOUNT) ) Amount_Remittance_to_PDNB ,
                (tfd.FEE - tfd.DISCOUNT) SSA_Convenience_Fee,
                TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
                TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
          FROM
                TRANSACTION XTN,
                device dev,
                LOOKUP_TRANS_REASON_CODE ltrc,
                TRANSACTION_FEE_DETAIL tfd,
                TRANS_CASH tc
          WHERE
                XTN.TRANSACTION_ID = tc.TRANSACTION_ID(+) AND
                tfd.TRANSACTION_ID(+) = XTN.TRANSACTION_ID AND
                XTN.DEVICE_ID = dev.DEVICE_ID AND
                XTN.REASON_CODE = ltrc.CODE (+) AND
                 Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
                XTN.TRANS_TYPE in ('CHKC','CHKC_B') AND
                tc.AMOUNT_DISPENSED  <> 0
          ORDER BY 1 )
      LOOP

          v_string1:= Pdnb_String_Function (i.Transaction_ID,i.Kiosks_ID,i.Merchant_ID,i.Transaction_Date,i.Transaction_Time,
          i.Transaction_Type,i.Transaction_Status,i.Reason,i.Terminal_ID,
          i.Provider_Confirmation_Number,i.Cash_In_out_indicator,i.Cash_Dispensed_Accepted,i.Amount_Remittance_to_SSA,
          i.Amount_Remittance_to_PDNB,i.SSA_Convenience_Fee,i.server_Date,i.server_Time
          );

          DBMS_LOB.WRITEAPPEND(v_Records,LENGTH(v_string1||V_nextline),(v_string1||V_nextline));

      END LOOP;

----------------------------------------------------  MORD  ------------------------------------------------------------------------

v_Errorflag := 5;
            FOR j IN (SELECT DISTINCT
                  XTN.TRANSACTION_ID Transaction_ID,
                  XTN.DEVICE_ID Kiosks_ID ,
                  dev.MERCHANT_ID Merchant_ID,
                  TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
                  TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
                  XTN.TRANS_TYPE Transaction_Type,
                  XTN.TRANS_STATUS Transaction_Status,
                  ltrc.DESCRIPTION Reason,
                  xtn.device_id Terminal_ID,
                  NULL Provider_Confirmation_Number,
                  'ACCEPTED' Cash_In_out_indicator,
                  tc.AMOUNT_DEPOSITED Cash_Dispensed_Accepted,
                  (tc.AMOUNT_DEPOSITED - tc.AMOUNT_DISPENSED) Amount_Remittance_to_SSA,
                  '0' Amount_Remittance_to_PDNB,
                  '0' SSA_Convenience_Fee,
                  TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
                  TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
            FROM
                  TRANSACTION XTN,
                  device dev,
                  LOOKUP_TRANS_REASON_CODE ltrc,
                  TRANSACTION_FEE_DETAIL tfd,
                  TRANS_CASH tc
            WHERE
                  XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'A') AND
                  XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
                  tfd.TRANSACTION_ID (+)= XTN.TRANSACTION_ID AND
                  XTN.DEVICE_ID = dev.DEVICE_ID AND
                  XTN.REASON_CODE = ltrc.CODE (+) AND
                   Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
                  XTN.TRANS_TYPE ='MORD' AND
                  tc.AMOUNT_DEPOSITED <> 0
            UNION                     ------------------
                  SELECT DISTINCT
                  XTN.TRANSACTION_ID Transaction_ID,
                  XTN.DEVICE_ID Kiosks_ID,
                  dev.MERCHANT_ID Merchant_ID,
                  TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
                  TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
                  XTN.TRANS_TYPE Transaction_Type,
                  XTN.TRANS_STATUS Transaction_Status,
                  ltrc.DESCRIPTION Reason,
                  ( SELECT DISTINCT dt.TERMINAL_ID FROM Device_terminal dt  WHERE dt.DEVICE_ID = XTN.DEVICE_ID AND dt.TERMINAL_TYPE = 'ATM') Terminal_ID,
                  NULL Provider_Confirmation_Number,
                  'DISPENSED' Cash_In_out_indicator ,
                  tc.AMOUNT_DISPENSED Cash_Dispensed_Accepted ,
                  0 Amount_Remittance_to_SSA,
                  '0' Amount_Remittance_to_PDNB,
                  '0' SSA_Convenience_Fee,
                  TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
                  TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
            FROM
                  TRANSACTION XTN,
                  device dev,
                  LOOKUP_TRANS_REASON_CODE ltrc,
                  TRANSACTION_FEE_DETAIL tfd,
                  TRANS_CASH tc
            WHERE
                  XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'D') AND
                  XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
                  tfd.TRANSACTION_ID (+)= XTN.TRANSACTION_ID AND
                  XTN.DEVICE_ID = dev.DEVICE_ID AND
                  XTN.REASON_CODE = ltrc.CODE (+) AND
                  Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
                  XTN.TRANS_TYPE ='MORD' AND
                  tc.AMOUNT_DISPENSED <> 0
            ORDER BY 1,11
            )
          LOOP

                    v_string2:=Pdnb_String_Function(j.Transaction_ID,j.Kiosks_ID,j.Merchant_ID,j.Transaction_Date,j.Transaction_Time,
                    j.Transaction_Type,j.Transaction_Status,j.Reason,j.Terminal_ID,
                    j.Provider_Confirmation_Number,j.Cash_In_out_indicator,j.Cash_Dispensed_Accepted,j.Amount_Remittance_to_SSA,
                    j.Amount_Remittance_to_PDNB,j.SSA_Convenience_Fee,j.server_Date,j.server_Time
                    );

                    DBMS_LOB.WRITEAPPEND(v_Records,LENGTH(v_string2||V_nextline),(v_string2||V_nextline));

          END LOOP;

-----------------------------------------------------  MTPR -------------------------------------------------------------
v_Errorflag := 6;

        FOR k IN (SELECT DISTINCT
                XTN.TRANSACTION_ID Transaction_ID,
                XTN.DEVICE_ID Kiosks_ID,
                dev.MERCHANT_ID Merchant_ID,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
                XTN.TRANS_TYPE Transaction_Type,
                XTN.TRANS_STATUS Transaction_Status,
                ltrc.DESCRIPTION Reason,
                ( SELECT DISTINCT dt.TERMINAL_ID FROM Device_terminal dt  WHERE dt.DEVICE_ID = XTN.DEVICE_ID AND dt.TERMINAL_TYPE = 'ATM') Terminal_ID,
                NULL Provider_Confirmation_Number,
                'DISPENSED' Cash_In_out_indicator ,
                tc.AMOUNT_DISPENSED Cash_Dispensed_Accepted,
                '0' Amount_Remittance_to_SSA,
                ((XTN.AMOUNT) - (XTN.FEE_WAIVED)) Amount_Remittance_to_PDNB,
                '0' SSA_Convenience_Fee,
                TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
                TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
        FROM
                TRANSACTION XTN,
                device dev,
                LOOKUP_TRANS_REASON_CODE ltrc,
                TRANSACTION_FEE_DETAIL tfd,
                TRANS_CASH tc
        WHERE
                XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'D') AND
                XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
                tfd.TRANSACTION_ID (+)= XTN.TRANSACTION_ID AND
                XTN.DEVICE_ID = dev.DEVICE_ID AND
                XTN.REASON_CODE = ltrc.CODE (+) AND
                Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
                XTN.TRANS_TYPE ='MTPR' AND
                tc.AMOUNT_DISPENSED <> 0
        ORDER BY 1  )

        LOOP

              v_string3:= Pdnb_String_Function(k.Transaction_ID,k.Kiosks_ID,k.Merchant_ID,k.Transaction_Date,k.Transaction_Time,
              k.Transaction_Type,k.Transaction_Status,k.Reason,k.Terminal_ID,
              k.Provider_Confirmation_Number,k.Cash_In_out_indicator,k.Cash_Dispensed_Accepted,k.Amount_Remittance_to_SSA,
              k.Amount_Remittance_to_PDNB,k.SSA_Convenience_Fee,k.server_Date,k.server_Time
              );

              DBMS_LOB.WRITEAPPEND(v_Records,LENGTH(v_string3||V_nextline),(v_string3||V_nextline));

          END LOOP;

-------------------------------------------------  MTSR  ----------------------------------------------------------------

v_Errorflag := 7;
      FOR l IN (
      SELECT DISTINCT
              XTN.TRANSACTION_ID Transaction_ID,
              XTN.DEVICE_ID Kiosks_ID,
              dev.MERCHANT_ID Merchant_ID,
              TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
              TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
              XTN.TRANS_TYPE Transaction_Type,
              XTN.TRANS_STATUS Transaction_Status,
              ltrc.DESCRIPTION Reason,
              XTN.DEVICE_ID Terminal_ID,
              NULL Provider_Confirmation_Number,
              'ACCEPTED' Cash_In_out_indicator,
              tc.AMOUNT_DEPOSITED Cash_Dispensed_Accepted,
              tc.AMOUNT_DEPOSITED Amount_Remittance_to_SSA,
              0 Amount_Remittance_to_PDNB,
              '0' SSA_Convenience_Fee ,
              TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
              TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
      FROM
              TRANSACTION XTN,
              device dev,
              LOOKUP_TRANS_REASON_CODE ltrc,
              TRANSACTION_FEE_DETAIL tfd,
              TRANS_CASH tc
      WHERE
              XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'A') AND
              XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
              tfd.TRANSACTION_ID (+) = XTN.TRANSACTION_ID AND
              XTN.DEVICE_ID = dev.DEVICE_ID AND
              XTN.REASON_CODE = ltrc.CODE (+) AND
              Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
              XTN.TRANS_TYPE ='MTSR' AND
              tc.AMOUNT_DEPOSITED <> 0
      UNION
      SELECT DISTINCT
              XTN.TRANSACTION_ID Transaction_ID,
              XTN.DEVICE_ID Kiosks_ID,
              dev.MERCHANT_ID Merchant_ID,
              TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
              TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
              XTN.TRANS_TYPE Transaction_Type,
              XTN.TRANS_STATUS Transaction_Status,
              ltrc.DESCRIPTION Reason,
              ( SELECT DISTINCT dt.TERMINAL_ID FROM Device_terminal dt  WHERE dt.DEVICE_ID = XTN.DEVICE_ID AND dt.TERMINAL_TYPE = 'ATM') Terminal_ID,
              NULL Provider_Confirmation_Number,
              'DISPENSED' Cash_In_out_indicator,
              tc.AMOUNT_DISPENSED Cash_Dispensed_Accepted,
              0 Amount_Remittance_to_SSA,
              tc.AMOUNT_DISPENSED Amount_Remittance_to_PDNB,
              '0' SSA_Convenience_Fee,
              TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
              TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
      FROM
              TRANSACTION XTN,
              device dev,
              LOOKUP_TRANS_REASON_CODE ltrc,
              TRANSACTION_FEE_DETAIL tfd,
              TRANS_CASH tc
      WHERE
              XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'D') AND
              XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
              tfd.TRANSACTION_ID (+)= XTN.TRANSACTION_ID AND
              XTN.DEVICE_ID = dev.DEVICE_ID AND
              tc.AMOUNT_DISPENSED <> 0 AND
              XTN.REASON_CODE = ltrc.CODE (+) AND
              Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
              XTN.TRANS_TYPE in ('MTSR','MTQC')
      ORDER BY 1,11
      )

      LOOP

              v_string4:= Pdnb_String_Function(l.Transaction_ID,l.Kiosks_ID,l.Merchant_ID,l.Transaction_Date,l.Transaction_Time,
              l.Transaction_Type,l.Transaction_Status,l.Reason,l.Terminal_ID,
              l.Provider_Confirmation_Number,l.Cash_In_out_indicator,l.Cash_Dispensed_Accepted,l.Amount_Remittance_to_SSA,
              l.Amount_Remittance_to_PDNB,l.SSA_Convenience_Fee,l.server_Date,l.server_Time
              );

              DBMS_LOB.WRITEAPPEND(v_Records,LENGTH(v_string4||V_nextline),(v_string4||V_nextline));

      END LOOP;

------------------------------------------------------- MTQC -----------------------------------------------
v_Errorflag := 8;

          FOR m IN (
          SELECT DISTINCT
                XTN.TRANSACTION_ID Transaction_ID,
                XTN.DEVICE_ID Kiosks_ID,
                dev.MERCHANT_ID Merchant_ID,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
                XTN.TRANS_TYPE Transaction_Type,
                XTN.TRANS_STATUS Transaction_Status,
                ltrc.DESCRIPTION Reason,
                XTN.DEVICE_ID Terminal_ID,
                NULL Provider_Confirmation_Number,
                'ACCEPTED' Cash_In_out_indicator,
                tc.AMOUNT_DEPOSITED Cash_Dispensed_Accepted,
                ((XTN.AMOUNT) + (XTN.FEE_WAIVED)) Amount_Remittance_to_SSA,
                '0' Amount_Remittance_to_PDNB,
                '0' SSA_Convenience_Fee ,
                TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
                TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
          FROM
                TRANSACTION XTN,
                device dev,
                LOOKUP_TRANS_REASON_CODE ltrc,
                TRANSACTION_FEE_DETAIL tfd,
                TRANS_CASH tc
          WHERE
                XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'A') AND
                XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
                tfd.TRANSACTION_ID(+) = XTN.TRANSACTION_ID AND
                XTN.DEVICE_ID = dev.DEVICE_ID AND
                XTN.REASON_CODE = ltrc.CODE (+) AND
                Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
                XTN.TRANS_TYPE ='MTQC' AND
                tc.AMOUNT_DEPOSITED <> 0
          ORDER BY 1 )

          LOOP

                v_string5:= Pdnb_String_Function(m.Transaction_ID,m.Kiosks_ID,m.Merchant_ID,m.Transaction_Date,m.Transaction_Time,
                m.Transaction_Type,m.Transaction_Status,m.Reason,m.Terminal_ID,
                m.Provider_Confirmation_Number,m.Cash_In_out_indicator,m.Cash_Dispensed_Accepted,m.Amount_Remittance_to_SSA,
                m.Amount_Remittance_to_PDNB,m.SSA_Convenience_Fee,m.server_Date,m.server_Time
                );

                DBMS_LOB.WRITEAPPEND(v_Records,LENGTH(v_string5||V_nextline),(v_string5||V_nextline));

          END LOOP;

          ------------------------------------------------------- Bill Pay -----------------------------------------------
v_Errorflag := 8;

                    FOR n IN (              ---**For Bill Payment with Amount deposited  equals to bill amount and Fee**--
           SELECT DISTINCT
                XTN.TRANSACTION_ID Transaction_ID,
                XTN.DEVICE_ID Kiosks_ID,
                dev.MERCHANT_ID Merchant_ID,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
                'BPAY' Transaction_Type,
                XTN.TRANS_STATUS Transaction_Status,
                 (case when xtn.TRANSACTION_ID = bpt.IFX_XTNID and bpt.RECON_STATUS = 'SETTLED_TRANSACTION' then 'Reconciled' else 'Not_Reconciled' end )|| '_'||ltrc.DESCRIPTION Reason,
                XTN.DEVICE_ID Terminal_ID,
                NULL Provider_Confirmation_Number,
                'ACCEPTED'  Cash_In_out_indicator,
                to_char(tc.AMOUNT_DEPOSITED) Cash_Dispensed_Accepted,
                '0' Amount_Remittance_to_SSA,
                ((XTN.AMOUNT) + (XTN.FEE_CHARGED )) Amount_Remittance_to_PDNB,
                '0' SSA_Convenience_Fee ,
                TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
                TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
           FROM
                TRANSACTION XTN,
                device dev,
                LOOKUP_TRANS_REASON_CODE ltrc,
                TRANSACTION_FEE_DETAIL tfd,
                TRANS_CASH tc,
                BILL_PAY_FILE_TRANSACTIONS bpt
           WHERE
                xtn.TRANSACTION_ID = bpt.IFX_XTNID(+) and
                XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'A') AND
                XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
                tfd.TRANSACTION_ID(+) = XTN.TRANSACTION_ID AND
                XTN.DEVICE_ID = dev.DEVICE_ID AND
                XTN.REASON_CODE = ltrc.CODE (+) AND
                Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
                XTN.TRANS_TYPE in ('BPAY','UTILITY_PAY') AND
                tc.AMOUNT_DEPOSITED <> 0
          union                         ---**For Bill Payment with Amount despensed **--
           SELECT DISTINCT
                XTN.TRANSACTION_ID Transaction_ID,
                XTN.DEVICE_ID Kiosks_ID,
                dev.MERCHANT_ID Merchant_ID,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
                'BPAY' Transaction_Type,
                XTN.TRANS_STATUS Transaction_Status,
                 (case when xtn.TRANSACTION_ID = bpt.IFX_XTNID and bpt.RECON_STATUS = 'SETTLED_TRANSACTION' then 'Reconciled' else 'Not_Reconciled' end )|| '_'||ltrc.DESCRIPTION Reason,
                XTN.DEVICE_ID Terminal_ID,
                NULL Provider_Confirmation_Number,
                'DISPENSED'  Cash_In_out_indicator,
                to_char(tc.AMOUNT_DISPENSED) Cash_Dispensed_Accepted,
                '0' Amount_Remittance_to_SSA,
                tc.AMOUNT_DISPENSED Amount_Remittance_to_PDNB,
                '0' SSA_Convenience_Fee ,
                TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
                TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
          FROM
                TRANSACTION XTN,
                device dev,
                LOOKUP_TRANS_REASON_CODE ltrc,
                TRANSACTION_FEE_DETAIL tfd,
                TRANS_CASH tc,
                BILL_PAY_FILE_TRANSACTIONS bpt,
                trans_bill_pay tbp
          WHERE
                xtn.TRANSACTION_ID = bpt.IFX_XTNID(+) and
                xtn.TRANSACTION_ID = tbp.TRANSACTION_ID(+) and
                XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'D') AND
                XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
                tfd.TRANSACTION_ID(+) = XTN.TRANSACTION_ID AND
                XTN.DEVICE_ID = dev.DEVICE_ID AND
                XTN.REASON_CODE = ltrc.CODE (+) AND
                Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
                XTN.TRANS_TYPE in ('BPAY','UTILITY_PAY') AND
                tc.AMOUNT_DISPENSED <> 0
         union            ---**For Bill Payment with amount creaded or buy Flex Card **--
          SELECT DISTINCT
                XTN.TRANSACTION_ID Transaction_ID,
                XTN.DEVICE_ID Kiosks_ID,
                dev.MERCHANT_ID Merchant_ID,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
                TO_CHAR(XTN.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
                'BPAY' Transaction_Type,
                XTN.TRANS_STATUS Transaction_Status,
                (case when xtn.TRANSACTION_ID = bpt.IFX_XTNID and bpt.RECON_STATUS = 'SETTLED_TRANSACTION' then 'Reconciled' else 'Not_Reconciled' end )|| '_'||ltrc.DESCRIPTION Reason,
                XTN.DEVICE_ID Terminal_ID,
                NULL Provider_Confirmation_Number,
                'DISPENSED'  Cash_In_out_indicator,
                '0' Cash_Dispensed_Accepted,
                '0' Amount_Remittance_to_SSA,
                tbp.CUST_AMOUNT Amount_Remittance_to_PDNB,
                '0' SSA_Convenience_Fee ,
                TO_CHAR(XTN.TIME_STAMP,'MMDDYYYY') server_Date ,
                TO_CHAR(XTN.TIME_STAMP,'HH24MISS') server_Time
          FROM
                TRANSACTION XTN,
                device dev,
                LOOKUP_TRANS_REASON_CODE ltrc,
                TRANSACTION_FEE_DETAIL tfd,
                TRANS_CASH tc,
                BILL_PAY_FILE_TRANSACTIONS bpt,
                trans_bill_pay tbp
          WHERE
                xtn.TRANSACTION_ID = bpt.IFX_XTNID(+) and
                xtn.TRANSACTION_ID = tbp.TRANSACTION_ID(+) and
                XTN.TRANSACTION_ID IN  ( SELECT TRANSACTION_ID  FROM TRANS_CASH_DETAILS tcd  WHERE CASH_TYPE = 'D') AND
                XTN.TRANSACTION_ID = tc.TRANSACTION_ID AND
                tfd.TRANSACTION_ID(+) = XTN.TRANSACTION_ID AND
                XTN.DEVICE_ID = dev.DEVICE_ID AND
                XTN.REASON_CODE = ltrc.CODE (+) AND
                Xtn.TIME_STAMP  BETWEEN v_FROM_DATE AND v_TO_DATE AND
                XTN.TRANS_TYPE in ('BPAY','UTILITY_PAY') AND
                tbp.PAYEE_ID = '111'
            ORDER BY 1,11
                )

          LOOP

                v_string7:= Pdnb_String_Function(n.Transaction_ID,n.Kiosks_ID,n.Merchant_ID,n.Transaction_Date,n.Transaction_Time,
                n.Transaction_Type,n.Transaction_Status,n.Reason,n.Terminal_ID,
                n.Provider_Confirmation_Number,n.Cash_In_out_indicator,n.Cash_Dispensed_Accepted,n.Amount_Remittance_to_SSA,
                n.Amount_Remittance_to_PDNB,n.SSA_Convenience_Fee,n.server_Date,n.server_Time
                );

                DBMS_LOB.WRITEAPPEND(v_Records,LENGTH(v_string7||V_nextline),(v_string7||V_nextline));

          END LOOP;

-------------------------------------------------------  'ADCB','ADCA','ADEB' -------------------------------------------

v_Errorflag := 9;

        FOR o IN (SELECT
              axtn.ADMIN_TRANS_ID Transaction_ID,
              axtn.DEVICE_ID Kiosks_ID,
              dev.MERCHANT_ID Merchant_ID,
              TO_CHAR(axtn.CLIENT_TIMESTAMP,'MMDDYYYY') Transaction_Date,
              TO_CHAR(axtn.CLIENT_TIMESTAMP,'HH24MISS') Transaction_Time,
              axtn.ADMIN_TRANS_TYPE  Transaction_Type,
              NULL Transaction_Status,
              NULL Reason,axtn.device_id Terminal_ID,
              NULL Provider_Confirmation_Number,
              NULL Cash_In_out_indicator,
              '0' Cash_Dispensed_Accepted,
              '0' Amount_Remittance_to_SSA,
              '0' Amount_Remittance_to_PDNB,
              '0' SSA_Convenience_Fee,
              TO_CHAR(axtn.TIME_STAMP,'MMDDYYYY') server_Date,
              TO_CHAR(axtn.TIME_STAMP,'HH24MISS') server_Time
        FROM
              ADMIN_TRANSACTION axtn,
              ADMIN_TRANS_CASH_BALANCE atcb,
              device dev
        WHERE
              axtn.ADMIN_TRANS_ID = atcb.ADMIN_TRANS_ID AND
              axtn.ADMIN_TRANS_TYPE IN ('ADCB','ADCA','ADEB') AND
               axtn.TIME_STAMP BETWEEN v_FROM_DATE AND v_TO_DATE AND
              dev.DEVICE_ID = axtn.DEVICE_ID
              GROUP BY axtn.ADMIN_TRANS_ID,axtn.DEVICE_ID,dev.MERCHANT_ID,TO_CHAR(axtn.CLIENT_TIMESTAMP,'MMDDYYYY'),
              TO_CHAR(axtn.CLIENT_TIMESTAMP,'HH24MISS'),axtn.ADMIN_TRANS_TYPE,TO_CHAR(axtn.TIME_STAMP,'MMDDYYYY'),
              TO_CHAR(axtn.TIME_STAMP,'HH24MISS')
              ORDER BY axtn.DEVICE_ID,axtn.ADMIN_TRANS_ID
        )
        LOOP
              v_string6:= Pdnb_String_Function(o.Transaction_ID,o.Kiosks_ID,o.Merchant_ID,o.Transaction_Date,o.Transaction_Time,
              o.Transaction_Type,o.Transaction_Status,o.Reason,o.Terminal_ID,
              o.Provider_Confirmation_Number,o.Cash_In_out_indicator,o.Cash_Dispensed_Accepted,o.Amount_Remittance_to_SSA,
              o.Amount_Remittance_to_PDNB,o.SSA_Convenience_Fee ,o.server_Date,o.server_Time);

              DBMS_LOB.WRITEAPPEND(v_Records,LENGTH(v_string6||V_nextline),(v_string6||V_nextline));

        END LOOP;


          v_Errorflag := 10;
          io_CSV_Data := v_Records;

--------------------------  Finally Inserting Appended record into RECON_PBN_SEND_FILEDATA table --------------------------------------

INSERT INTO RECON_PBN_SEND_FILEDATA  VALUES ( v_file_name, trim(v_records), SYSDATE);

o_OutPutStatus  := 0;
o_OutPutMessage := 'Success ';
EXCEPTION
WHEN OTHERS THEN
o_OutPutStatus  := -1;
o_OutPutMessage := 'Procedure Pdnb_Send_File failed at step no:-  '||v_Errorflag||' SQL ERROR:-  '||SUBSTR(SQLERRM,1,100);
END  ;
/