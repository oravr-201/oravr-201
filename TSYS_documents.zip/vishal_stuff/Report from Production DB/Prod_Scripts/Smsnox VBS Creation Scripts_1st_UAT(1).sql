--BASE schemas
TRANSNOX_CPASS
SNOX4TRANSNOX_CPASS

--TFE VBS schema names.
TNOXPASS_SMSNOX_20173
SNOXPASS_SMSNOX_20173


-- Creating VBS schemas
-- Transnox Application Schemas------------------------------------------------------------------------------------------------------------
CREATE USER SNOXPASS_SMSNOX_20173 IDENTIFIED BY snox4transnox_cpassstag DEFAULT TABLESPACE users TEMPORARY TABLESPACE temp;

CREATE USER TNOXPASS_SMSNOX_20173 IDENTIFIED BY transnox_cpassstag DEFAULT TABLESPACE users TEMPORARY TABLESPACE temp;

GRANT CONNECT, RESOURCE, CREATE TABLE, CREATE SYNONYM, CREATE VIEW, CREATE MATERIALIZED VIEW, DEBUG CONNECT SESSION TO TNOXPASS_SMSNOX_20173;

GRANT CONNECT, RESOURCE, CREATE TABLE, CREATE SYNONYM, CREATE VIEW, CREATE MATERIALIZED VIEW, DEBUG CONNECT SESSION TO SNOXPASS_SMSNOX_20173; 

-- Grants script.
select 'grant '||decode(object_type,'TABLE','select,insert,update,delete','SEQUENCE',' select ')||' on '||owner||'.'||object_name||' to '||DECODE(OWNER,'SNOX4TRANSNOX_CPASS','SNOXPASS_SMSNOX_20173','TRANSNOX_CPASS','TNOXPASS_SMSNOX_20173')||';'oops
from dba_objects
where owner in ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
 and object_type in ('TABLE','SEQUENCE')
 and regexp_like(object_name,'[^0-9]$')
order by object_type,owner asc;


-- creating synonyms for schema table
select 'create or replace synonym '||DECODE(OWNER,'SNOX4TRANSNOX_CPASS','SNOXPASS_SMSNOX_20173','TRANSNOX_CPASS','TNOXPASS_SMSNOX_20173')||'.'||object_name||' for '||owner||'.'||object_name||';'oops
from dba_objects
where owner in ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
 and object_type in ('TABLE','SEQUENCE')
 and regexp_like(object_name,'[^0-9]$')
order by object_type,owner asc;

----------------------------------------------------------

-- Grants for cross schema tables.
select 'grant select,insert,update,delete on '||owner||'.'||object_name||' to '||DECODE(OWNER,'SNOX4TRANSNOX_CPASS','TNOXPASS_SMSNOX_20173','TRANSNOX_CPASS','SNOXPASS_SMSNOX_20173')||';'oops
from dba_objects
where owner in ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
 and object_type='TABLE'
 and regexp_like(object_name,'[^0-9]$');


-- Creating synonym for cross schema tables
select 'create or replace synonym '||DECODE(OWNER,'SNOX4TRANSNOX_CPASS','TNOXPASS_SMSNOX_20173','TRANSNOX_CPASS','SNOXPASS_SMSNOX_20173')||'.'||object_name||' for '||owner||'.'||object_name||';'oops
from dba_objects
where owner in ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
 and object_type='TABLE'
 and regexp_like(object_name,'[^0-9]$');

------***************************************************************************************************


------**************************************************************

------------------------------- PROCEDURES, FUNCTIONS, TRIGGER --------------

select 'GRANT execute, all on '||owner||'.'||object_name||' to '||decode(owner,'SNOX4TRANSNOX_CPASS','SNOXPASS_SMSNOX_20173','TRANSNOX_CPASS','TNOXPASS_SMSNOX_20173')||';' oops
from dba_objects
where owner in ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
 and object_type in ('PROCEDURE','FUNCTION','PACKAGE')
 and object_name not like '%AS400%';

select 'create or replace synonym '||decode(owner,'SNOX4TRANSNOX_CPASS','SNOXPASS_SMSNOX_20173','TRANSNOX_CPASS','TNOXPASS_SMSNOX_20173')||'.'||object_name||' for '||owner||'.'||object_name||';' oops
from dba_objects
where owner in ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
 and object_type in ('PROCEDURE','FUNCTION','PACKAGE')
 and object_name not like '%AS400%';
 
 ------------------------------------------------------ Done --------------------------------------------------------------------------