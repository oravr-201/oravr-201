
--ACM Approved Decilent Count
SELECT 
    TIMESTAMP,
    sum(Approved_XTN_Count),
    sum(Declined_XTN_Count)
FROM
    (SELECT  
        TO_CHAR(servertime,'mm/dd/yyyy')TIMESTAMP,
        SUM (CASE WHEN transaction_state IN ('BME','DSF','DLF','CDC','CDS','CRC','CRS','TRA')THEN 1 ELSE 0 END) Approved_XTN_Count,  
        SUM (CASE WHEN transaction_state IN ('EPT', 'ISF', 'CLE', 'INP', 'TRD', 'TRT') THEN 1 ELSE 0 END) Declined_XTN_Count
    FROM  
        snoxdevices.acm_transactionS  
    WHERE servertime BETWEEN TO_DATE('02/01/2008 00:00:00','mm/dd/yyyy hh24:mi:ss') AND TO_DATE('02/29/2008 23:59:59','mm/dd/yyyy hh24:mi:ss')  
      AND Transaction_Type IN ('ABCC', 'ABCK', 'ABSV','ACRT','ACRP','ACBT', 'AWCC', 'AWCK', 'AWSV' ,'CCCA', 'CCVP', 'CCAE', 'CCEN', 'CCER', 'CCFV', 'CCIE', 'CCLA', 'CCNB', 'CCNP', 'CCOC', 'CCPA', 'CCPF', 'CCRN', 'CCSN', 'CCVF', 'POSA', 'POSP', 'POOC', 'POLA', 'POAE','PODE','POTE','PADE','PATE','CCFA', 'CCFF','CCMS')  
    GROUP BY TO_CHAR(servertime,'mm/dd/yyyy') 
    UNION   
    SELECT
        TO_CHAR(TIMESTAMP,'mm/dd/yyyy')TIMESTAMP,
        SUM (CASE WHEN qt.chkc_transaction_status IN ( 'ATC', 'AUT', 'CDC', 'PTC', 'PTS', 'VDC', 'VOD') THEN 1 ELSE 0 END) Approved_XTN_Count,  
        SUM (CASE WHEN qt.chkc_Transaction_status  IN  ('DEC','TRT') THEN 1 ELSE 0 END) Declined_XTN_Count  
    FROM   
        snoxdevices.qcp_telechecktransactions qt,  
        snoxdevices.acm_check_transactions act  
    WHERE qt.transactionid = act.transactionid 
       AND qt.transsource = 'A'   
       AND qt.chkc_transaction_status IN ( 'ATC', 'AUT', 'CDC', 'PTC', 'PTS', 'VDC', 'VOD','CSD','CMS', 'CDR','CCR','CST','CFV','CNI','CRC','CSC','CSV','CVD','DEC','TRT')
       AND  qt.transactiondate   BETWEEN TO_DATE('02/01/2008 00:00:00','mm/dd/yyyy hh24:mi:ss') AND TO_DATE('02/29/2008 23:59:59','mm/dd/yyyy hh24:mi:ss')
    GROUP BY TO_CHAR(TIMESTAMP,'mm/dd/yyyy')
    ) xtn 
group by TIMESTAMP
order by TIMESTAMP 