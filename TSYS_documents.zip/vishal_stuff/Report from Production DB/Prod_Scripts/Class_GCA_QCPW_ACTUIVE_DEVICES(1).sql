

-- synonym of QCP.MACHINES table which privileges like select to snoxdevices schema
SELECT COUNT(1)
FROM SNOXDEVICES.QCP_MACHINES 
WHERE IS_DELETED = 'N';



--- Send Mail procedure for Active devices


CREATE OR REPLACE PROCEDURE SNOXDEVICES.QCPW_ACTIVE_DEVICES
AS
    v_Connection            UTL_SMTP.Connection;
    v_reply                 UTL_SMTP.REPLY;

    Message                 VARCHAR2(4000);
    crlf                    VARCHAR2(2):=CHR(13)||CHR(10);
    
    v_Sender                VARCHAR2(100);
    v_Recipient             VARCHAR2(100);
    v_Subject               VARCHAR2(100);
    v_Body                  VARCHAR2(1000);

    v_cc_recipt1            VARCHAR2(100);
    
    v_head_count            NUMBER;
    v_current_date          VARCHAR2(30);
    
BEGIN
    v_Sender     := 'db_dev@infonox.com';--'db_dev@infonox.com';              -- sender will be InOC
    v_Recipient  := 'Inoc@infonox.com';              -- TO: db_dev

    SELECT TO_CHAR(SYSDATE,'dd/mon/yyyy') INTO v_current_date
    FROM dual;


-- synonym of QCP.MACHINES table which privileges like select to snoxdevices schema
    SELECT COUNT(1) INTO v_head_count
    FROM SNOXDEVICES.QCP_MACHINES 
    WHERE IS_DELETED = 'N';

    v_Subject    := 'Count of active devices in QCPW on date  '||v_current_date; -- mail  subject
    
    -- Body text 
    v_Body  := 'Hi All,<br><br>'||
               '&nbsp;&nbsp;&nbsp;&nbsp;The Number of Active DEVICES in QCPW is <b><font color="red">'||v_head_count||'</font></b>.<br><br>'||
               'Regards<br>'||
               'DB Team<br>'||
               '(automated email via DB process)';
                           
    v_cc_recipt1  := 'db_dev@infonox.com';            --  CC: InOC
  
    -- smpt.ifxlv.com connection is opened here
    v_Connection := UTL_SMTP.OPEN_CONNECTION('smtp.ifxtempe.com',25) ;
    v_reply      := UTL_SMTP.HELO(v_Connection,'smtp.ifxtempe.com') ;
    v_reply      := UTL_SMTP.MAIL(v_Connection,v_Sender);
    v_reply      := UTL_SMTP.RCPT(v_Connection,v_Recipient);

    IF v_cc_recipt1 IS NOT NULL THEN
        UTL_SMTP.rcpt(v_Connection,v_cc_recipt1);
    END IF;

   Message := 'From: '||v_Sender||crlf|| 
               'To: '||v_Recipient||crlf||
               'Cc: '||v_cc_recipt1||crlf||
               'Subject: '||v_Subject||crlf||''||crlf||v_Body;

    UTL_SMTP.DATA(v_Connection,'MIME-Version: 1.0'||crlf||'Content-type: text/html' || crlf||Message);
    UTL_SMTP.QUIT(v_Connection);
END QCPW_ACTIVE_DEVICES;
/