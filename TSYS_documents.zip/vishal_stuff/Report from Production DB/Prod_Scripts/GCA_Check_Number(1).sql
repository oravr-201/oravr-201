/*

		To check the GCA check number first check what information InOC had send, based on that retriview the data.

They might be sending CasinoCode, CasinoName (Location), checkNo(ChckNo), Timestamp, CustomerName(Name), CustomerCode

*/


CHECK ON Tempe_21/Col_121 reporting DATABASE


SELECT transactiondate, c.casinoname,firstname||' '||b.MIDDLEINITIAL ||' '||lastname NAME, 
    gca_checknumber, amount+ A.SERVICECHARGE Amount
FROM checkcash.chkc_transactions A, qcp.customers b, qcp.casinos c
WHERE (( CHECKNO  LIKE '%1197'
 AND amount+SERVICECHARGE='6270'
 AND TIMESTAMP  BETWEEN '20-nov-2007' AND '24-nov-2007')
OR (ecatraceid=1090948))
 AND A.customercode=b.customercode
 AND A.casinocode=c.casinocode
 AND gca_checknumber IS NOT NULL;
 




---- final query
SELECT CXTN.TRANSACTIONDATE, CAS.CASINONAME, CUST.FIRSTNAME||' '||CUST.MIDDLEINITIAL||' '||CUST.LASTNAME CUST_Name,
       CXTN.GCA_CHECKNUMBER, CXTN.AMOUNT+CXTN.SERVICECHARGE amount, CXTN.CHECKNO
FROM CHECKCASH.CHKC_TRANSACTIONS cxtn, QCP.CUSTOMERS cust, QCP.CASINOS cas
WHERE CXTN.CUSTOMERCODE = CUST.CUSTOMERCODE
  AND CXTN.CASINOCODE = CAS.CASINOCODE 
  AND REGEXP_LIKE(CASINONAME,'^*menominee*','i')
--  AND CXTN.CUSTOMERCODE='4890778162'
  AND CXTN.TIMESTAMP BETWEEN TO_DATE('10/31/2009 00:00:00','mm/dd/yyyy hh24:mi:ss')
                         AND TO_DATE('10/31/2009 23:59:59','mm/dd/yyyy hh24:mi:ss')
                            
SELECT *
FROM QCP.CASINOS
WHERE REGEXP_LIKE(CASINONAME,'^*menominee*','i')
 
SELECT CXTN.TRANSACTIONDATE, CAS.CASINONAME, CUST.FIRSTNAME||' '||CUST.MIDDLEINITIAL||' '||CUST.LASTNAME CUST_Name,
       CXTN.GCA_CHECKNUMBER, CXTN.AMOUNT+CXTN.SERVICECHARGE amount, CXTN.CHECKNO, CXTN.REF_NUMBER
FROM CHECKCASH.CHKC_TRANSACTIONS cxtn, QCP.CUSTOMERS cust, QCP.CASINOS cas
WHERE CXTN.CUSTOMERCODE = CUST.CUSTOMERCODE
  AND CXTN.CASINOCODE = CAS.CASINOCODE 
--  AND REGEXP_LIKE(CASINONAME,'^*sycuan*','i')
--  AND CAS.CASINOCODE='400107'
--  AND CXTN.CUSTOMERCODE='4890778162'
  AND REGEXP_LIKE(CXTN.CHECKNO,'1133','i')
  AND CXTN.AMOUNT+CXTN.SERVICECHARGE='80000'
--  AND REGEXP_LIKE(CUST.lastNAME,'^mckenzie*','i')
--  AND CXTN.REF_NUMBER='153830199' 
  AND CXTN.TIMESTAMP BETWEEN TO_DATE('05/03/2010 00:00:00','mm/dd/yyyy hh24:mi:ss')
                         AND TO_DATE('05/06/2010 23:59:59','mm/dd/yyyy hh24:mi:ss')
                            
  

  
 