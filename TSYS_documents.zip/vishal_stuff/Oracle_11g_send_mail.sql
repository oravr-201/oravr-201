-- connect to system user

SELECT ANY_PATH
FROM RESOURCE_VIEW
WHERE ANY_PATH LIKE '/sys/acls/dba%';


BEGIN
    DBMS_NETWORK_ACL_ADMIN.CREATE_ACL (
    ACL => 'dba.xml', -- case sensitive
    DESCRIPTION=> 'Network Access Control for the DBAs',
    PRINCIPAL => 'RAHULC', -- user or role the privilege is granted or denied (upper case)
    IS_GRANT => TRUE, -- privilege is granted or denied
    PRIVILEGE => 'connect', -- or 'resolve' (case sensitive)
    START_DATE => NULL, -- when the access control entity ACE will be valid
    END_DATE => NULL); -- ACE expiration date (TIMESTAMP WITH TIMEZONE format)
END;
/

BEGIN
 DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE 
  (
    ACL => 'dba.xml',
    PRINCIPAL => 'RAHULC',
    IS_GRANT => TRUE,
    PRIVILEGE => 'connect',
    START_DATE => NULL, -- if the time interval is defined,
    END_DATE => NULL
 ); -- the ACE will expire after the specified date range
END;
/

BEGIN
  DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL (
    acl         => 'dba.xml',
    HOST        => 'MAIL.INFONOX.COM', 
    lower_port  => 25,
    upper_port  => 25); 
    COMMIT;
END;
/

---------------------*********************-------------------


CREATE OR REPLACE PROCEDURE RAHULC.SEND_EVENT_MAIL
(
    o_OutputStatus OUT  NUMBER,
    o_OutputMessage OUT VARCHAR2 
)
AS
        v_mailHost     VARCHAR2(50):='MAIL.INFONOX.COM';
        v_Connection UTL_SMTP.Connection;
        v_reply UTL_SMTP.REPLY;
        
        MESSAGE      VARCHAR2(32767);
        crlf         VARCHAR2(2):=CHR(13)||CHR(10);
        
        v_error_flag NUMBER;
        
        v_Sender     VARCHAR2(100); --- mail sender
        v_Recipient  VARCHAR2(100); --- CC list
        
        v_Subject    VARCHAR2(100); --- Mail subject
        
        v_Body       VARCHAR2(32767);  --- Mail body
        
        v_cc_recipt1 VARCHAR2(100);
        
        v_date       VARCHAR2(20);
        v_Data       VARCHAR2(32767);
        v_Data_f     VARCHAR2(32767);
        v_count      NUMBER;
BEGIN
        SELECT TO_CHAR(SYSDATE,'mm/dd/yyyy hh24:mi:ss') INTO v_date FROM dual;
        
        v_error_flag :=1;
        -- Mail sender
        v_Sender     := 'rahulc@infonox.com';
        
        -- TO list
        v_Recipient  := 'rahulc@infonox.com';
        v_cc_recipt1 := 'baidhar@infonox.com'; 

        v_data:=NULL;
        FOR z  IN
        ( SELECT SCHEMA_NAME, TABLE_NAME FROM TABLE_LIST ORDER BY 1, 2 ASC)
        LOOP
                v_error_flag:=3;
                v_data_f    :='<TR><TD>'||z.SCHEMA_NAME ||'</TD><TD>'||UPPER(z.TABLE_NAME) ||'</TD></TR>';
                v_error_flag:=4;
                v_data      := v_data_f||v_data;
        END LOOP;

        v_error_flag:=5;
        v_data      :='<TR bgcolor="#CCCCCC"><TD>SCHEMA_NAME</TD><TD>TABLE_NAME</TD></TR>'||v_data;

                v_error_flag:=6;
                v_Subject    := 'Oracle Version 11G from Dev11G DB 231.84' ;
                
                v_error_flag:=7;
                v_Body      := '<BODY><FONT FACE="Courier New" size="04"> Hi Baidhar, </FONT></BODY> <br>'|| 
                               '&nbsp;&nbsp;&nbsp;&nbsp;<BODY><FONT FACE="Courier New" size="04"> Sending the '||
                               'Mail from Oracle version 11g from devdb dev11g database 192.168.231.84. Just printing some table data result here in HTML format of date '||v_date||
                               '</FONT></BODY>. <br>'|| '<BODY><FONT FACE="Courier New" size="11"><TABLE BORDER="1">'||v_data||
                               '</TABLE></FONT></BODY> <br><br>'|| '<BODY><FONT FACE="Courier New" size="04">Regards<br>'|| 
                               '- Rahul Chaudhari </FONT></BODY>';
        
                v_error_flag :=8;
                
                v_Connection := UTL_SMTP.OPEN_CONNECTION(v_mailHost, 25);
                v_reply      := UTL_SMTP.HELO(v_Connection, v_mailHost);
                v_reply      := UTL_SMTP.MAIL(v_Connection, v_Sender);
                v_reply      := UTL_SMTP.RCPT(v_Connection, v_Recipient);
                
                v_error_flag:=9;

                IF v_cc_recipt1 IS NOT NULL THEN
                   UTL_SMTP.rcpt(v_Connection,v_cc_recipt1);
                END IF;
                    
                MESSAGE := 'From: '||v_Sender||crlf|| 
                           'To: '||v_Recipient||crlf|| 
                           'Subject: '||v_Subject||crlf||''||crlf||v_Body;
                
                v_error_flag:=10;
                
                UTL_SMTP.DATA(v_Connection,'Content-type: text/html'|| crlf||MESSAGE);
                UTL_SMTP.QUIT(v_Connection);
                

        o_OutputStatus:='0';
        o_OutputMessage:='SUCCESS';
        
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Step number: '||v_error_flag||' Message: '||SUBSTR(SQLERRM,1,100));
END SEND_EVENT_MAIL;
/
