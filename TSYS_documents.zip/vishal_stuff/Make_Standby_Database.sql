--   
--			Documentation on Standby Database
--


--- Points to noted before creating Standby Database
1) Oracle software release must be same on both primary and standby database.
2) OS must be same but OS release may not need to be same. 
3) Primary db must run in ARCHIVELOG mode. 
4) Destination of dbfiles must be same. if the location is different then change the init parameter file as per destination.
5) both db primary and standby db must have there own controlfile. 
6) Primary database must be FORCE LOGGING mode.

---- Preparing Primary Database for Standby Database creation 

1] Ensure primary database is in ARCHIVELOG mode
	
	sql> archive log list
	
	
2] Identify the primary database Datafiles 

	sql> select name from v$datafile;
	
3] Shutdown the primary database with normal mode
	
	sql>shut normal;

4] copy REDOLOG files and DATAFILES of Primary Db. 

5] after coping the dbfiles start the primary db
	
	sql> startup

6] modify the tnsnames.ora file of primary db. create the tns entry for the standby db host

7] issue the following command on primary database to create control file for the standby database. 
	
	sql>alter database create standby controlfile as 'location_on_standby_db_host';
													 '\\rahulc\dupssk\dbfiles\controlfile_stdby003.ctl'	

8] Do not SHUTDOWN the PRIMARY DB as u create the STANDBY CONTROLFILE, else it will be INCONSISTENT CONTROLFILE.

9] copy the init parameter file from primary db and modify the following params...

    On Primary DB
     
       	* log_archive_start = true
	   	* log_archive_dest_1 = "location=c:\Oracle\oradata\SID\archive mandatory reopen=5"
	   	* log_archive_dest_state_1 = enable
	   	* log_archive_format = %%ORACLE_SID%%T%TS%S.ARC

	   	* log_archive_dest_2 = "service=STBY optional reopen=5"
	   	* log_archive_dest_state_2 = enable

    On Standby DB
		 #reference the standby controlfile
		* control_files = ("c:\Oracle\oradata\SID\stbycf.f")
		 #switch archiving and reference archive directory
		* log_archive_start = false
		* log_archive_dest = c:\Oracle\oradata\SID\archive
		* standby_archive_dest = c:\Oracle\oradata\SID\archive
		* log_archive_format = %%ORACLE_SID%%T%TS%S.ARC	
		
		* db_file_name_convert=('primary db datafile location','standby db datafile location') 
		* log_file_name_convert=('primary db redolog file location','standby db redolog file location')  

   Rest of init parameters will be same.....
   
10] create service for standby db on the standby db host.

	c:\> oradim -new -sid <primary_db_name> -intpwd <password> -startmode AUTO -pfile '<location of init parameter file>'
	 
	 	   primary_db_name will same as primary db has...
	 	   
11] create listener for standby db

12] set the environment variable
	 
	c:\> set oracle_sid=<db_name>

13] start the standby db
	
	c:\>sqlplus /nolog
	
	sql> startup nomount pfile=<pfile location>
	
	sql> alter database mount standby database;
	
	sql> alter database recover managed standby database;
	 
	     to magaged archive logfile fire the above command on standby db. This window will 
	     then hang indefinitely while it continues to look for archive logs to apply. 
	     To stop the recovery open another sqlplus session and type:


	sql> alter database recover managed standby database cancel;


14] from primary db execute the command
	
	sql> alter system switch logfile;
	
15] check archive file are created on standby db host.
	Now go to primary database prompt

	sql> alter system switch logfile;

	Go to stand by database prompt

	sql> alter database open read only;

16] check for the other changes / modifications on standby db of primary db


Backup Standby Database

Backups of the standby database can only be performed if the database is shut down or 
in read only mode. Read only mode is best for managed recovery systems as archive logs 
will still be transfered during the backup process, thus preventing gap sequences. Once 
the server is in the desired mode simple copy the appropriate database files.

