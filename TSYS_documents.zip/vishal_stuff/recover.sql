_allow_resetlogs_corruption = true
_allow_read_only_corruption = true

recover database until time '2008-04-02:15:59:59'



FAST_START_MTTR_TARGET=600

CREATE CONTROLFILE SET DATABASE "AQPROD" RESETLOGS  NOARCHIVELOG
    MAXLOGFILES 16
    MAXLOGMEMBERS 3
    MAXDATAFILES 100
    MAXINSTANCES 8
    MAXLOGHISTORY 5842
LOGFILE
  GROUP 1 (
    '/ora2/oracle/oradata/aqprod/redo101.log',
    '/ora1/oracle/oradata/aqprod/redo102.log'
  ) SIZE 100M,
  GROUP 2 (
    '/ora2/oracle/oradata/aqprod/redo201.log',
    '/ora1/oracle/oradata/aqprod/redo202.log'
  ) SIZE 100M,
  GROUP 3 (
    '/ora2/oracle/oradata/aqprod/redo301.log',
    '/ora1/oracle/oradata/aqprod/redo302.log'
  ) SIZE 100M
-- STANDBY LOGFILE
DATAFILE
  '/ora2/oracle/oradata/aqprod/system01.dbf',
  '/ora2/oracle/oradata/aqprod/undotbs01.dbf',
  '/ora2/oracle/oradata/aqprod/sysaux01.dbf',
  '/archive/oradata/aqprod/users02.dbf',
  '/ora3/oracle/oradata/aqprod/trans_data02.dbf',
  '/ora3/oracle/oradata/aqprod/trans_data01.dbf',
  '/ora3/oracle/oradata/aqprod/trans_200702.dbf',
  '/archive/oradata/aqprod/trans_200701.dbf',
  '/ora1/oracle/oradata/aqprod/archive_data01.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA02.dbf',
  '/archive/oradata/aqprod/users102.dbf',
  '/ora1/oracle/oradata/aqprod/users101.dbf',
  '/archive/oradata/aqprod/users04.dbf',
  '/archive/oradata/aqprod/users01.dbf',
  '/archive/oradata/aqprod/trans_200705.dbf',
  '/archive/oradata/aqprod/trans_200704.dbf',
  '/archive/oradata/aqprod/trans_200702.dbf',
  '/archive/oradata/aqprod/trans_200708.dbf',
  '/archive/oradata/aqprod/trans_200707.dbf',
  '/archive/oradata/aqprod/trans_200706.dbf',
  '/archive/oradata/aqprod/users08.dbf',
  '/archive/oradata/aqprod/users07.dbf',
  '/archive/oradata/aqprod/users06.dbf',
  '/archive/oradata/aqprod/users05.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA08.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA07.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA06.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA05.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA04.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA03.dbf',
  '/ora2/oracle/oradata/aqprod/trans_2007bb102.dbf',
  '/ora2/oracle/oradata/aqprod/trans_2007b101.dmp'
CHARACTER SET WE8ISO8859P1





select member from v$logfile lf , v$log l where l.status='CURRENT' and lf.group#=l.group#;




 run{SET UNTIL TIME "to_date('02/20/2009 23:59:59','mm/dd/yyyy hh24:mi:ss')"; restore database; recover database;}


