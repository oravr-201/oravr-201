REM Execute this script script for training purposes only
REM Undo Setup for Flashback Data Archive
REM Execute script as SYSDBA

set echo on
set serveroutput on
-- set verify on
set term on
set lines 200
set pause on

connect / as sysdba
set echo off
CREATE SMALLFILE UNDO TABLESPACE undotbs1
DATAFILE '$HOME/BACKUP/undotbs01.dbf'
SIZE 105M REUSE AUTOEXTEND ON NEXT 5120K MAXSIZE 32767M
/
set echo on

ALTER SYSTEM SET UNDO_TABLESPACE=undotbs1
/
DROP TABLESPACE fla_tbs1 INCLUDING CONTENTS
/
DROP TABLESPACE fla_tbs2 INCLUDING CONTENTS
/

DROP TABLESPACE undotbs2 INCLUDING CONTENTS
/
host rm -f $HOME/BACKUP/fla_tbs01.dbf 
host rm -f $HOME/BACKUP/fla_tbs02.dbf 
host rm -f $HOME/BACKUP/undotbs02.dbf

prompt Flashback Data Archive cleanup complete.
pause Press [Enter] to continue...
exit
