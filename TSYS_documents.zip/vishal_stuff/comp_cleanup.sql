-- Oracle Server Technologies - Curriculum Development
-- *** For training only***
set echo on
set timing off

connect / as sysdba

/*== Drop test tablespace and user ==*/
DROP USER compi CASCADE;
DROP TABLESPACE compi_tbs INCLUDING CONTENTS;

REM  *** Finished clean-up of demo objects.
