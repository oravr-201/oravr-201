DECLARE
 sql_addr VARCHAR2(20);
 sql_hash VARCHAR2(20);

 SQL_ID_val VARCHAR2(20) := 'fu02q80b2kva1';

BEGIN
 
  select address, hash_value into sql_addr, sql_hash
    from v$sqlarea
    where sql_id = SQL_ID_val;

  DBMS_SHARED_POOL.purge(sql_addr||','||sql_hash,'C');

END;
