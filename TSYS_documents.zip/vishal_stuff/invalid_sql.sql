-- find all the cursors for a particular SQL statement
-- and PURGE them to ensure the use of SQL Profile

create or replace PROCEDURE purge_SQL (p_sql_id IN VARCHAR2) as

  sql_addr		VARCHAR2(8);
  sql_hash_value	VARCHAR2(20);
  v_addr_hash		VARCHAR2(40);

  cursor c1 is 
     select address,hash_value
       from v$sqlarea
       where sql_id = p_sql_id;

BEGIN
  FOR sql_c in c1 LOOP 

  v_addr_hash := to_char(sql_c.address)||','||to_char(sql_c.hash_value);  

  DBMS_OUTPUT.PUT_LINE('variable is :'||v_addr_hash);

  DBMS_SHARED_POOL.PURGE(v_addr_hash,'C');

  END LOOP;
END;
.
/
