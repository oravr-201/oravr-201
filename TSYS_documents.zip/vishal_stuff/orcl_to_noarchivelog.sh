#!/bin/sh
#
# Run as: oracle
# This changes the orcl instance to run in NOARCHIVELOG mode.
#
# Written by: Tom Best
export ORACLE_SID=orcl
sqlplus -s / as sysdba <<-EOI
  shutdown immediate
  startup mount
  alter database noarchivelog;
  alter database open;
  quit
EOI
exit
