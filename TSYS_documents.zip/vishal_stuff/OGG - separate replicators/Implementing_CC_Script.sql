-- RE TE
GGSCI (epl1trandbrpt1.tsysacquiring.org) 6> info RPRETE01

REPLICAT   RPRETE01  Last Started 2016-05-04 23:51   Status STOPPED
Checkpoint Lag       00:00:00 (updated 00:07:52 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/EA044239
                     2016-05-22 22:37:16.999945  RBA 84216342
			 
ADD REPLICAT RPRETELG, EXTTRAIL /acfs/goldengate/dirdat/EA

alter RPRETELG, extseqno 44239, extrba 84216342

alter RPRETE01, extseqno 44239, extrba 84216342

--------------------------------------------------------------------------------------------
-- RE TW RPRETW01
GGSCI (epl1trandbrpt1.tsysacquiring.org) 8> info RPRETW01

REPLICAT   RPRETW01  Last Started 2016-05-04 23:51   Status STOPPED
Checkpoint Lag       00:00:00 (updated 00:00:10 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/WC049056
                     2016-05-22 23:18:17.022943  RBA 99937993
					 
ADD REPLICAT RPRETWLG, EXTTRAIL /acfs/goldengate/dirdat/WC


alter RPRETWLG, extseqno 49056, extrba 99937993

alter RPRETW01, extseqno 49056, extrba 99937993

--------------------------------------------------------------------------------------------
-- RW TE 
GGSCI (wpl1trandbrpt1.tsysacquiring.org) 6> info RPRWTE01

REPLICAT   RPRWTE01  Last Started 2016-05-05 00:02   Status STOPPED
Checkpoint Lag       00:00:00 (updated 00:00:10 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/EC045046
                     2016-05-22 23:37:46.025280  RBA 91468311

GGSCI (wpl1trandbrpt1.tsysacquiring.org) 7>

ADD REPLICAT RPRWTELG, EXTTRAIL /acfs/goldengate/dirdat/EC

alter RPRWTELG, extseqno 45046, extrba 91468311

alter RPRWTE01, extseqno 45046, extrba 91468311

--------------------------------------------------------------------------------------------
-- RW TW
GGSCI (wpl1trandbrpt1.tsysacquiring.org) 32> info RPRWTW01

REPLICAT   RPRWTW01  Last Started 2016-05-05 00:02   Status STOPPED
Checkpoint Lag       00:00:00 (updated 00:00:09 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/WA049091
                     2016-05-22 23:53:21.002148  RBA 54593584

ADD REPLICAT RPRWTWLG, EXTTRAIL /acfs/goldengate/dirdat/WA

alter RPRWTWLG, extseqno 49091, extrba 54593584

alter RPRWTW01, extseqno 49091, extrba 54593584

--------------------------------------------------------------------------------------------
-- TE TW
GGSCI (epl1trandbtxn1.tsysacquiring.org) 31> info RPTETW01

REPLICAT   RPTETW01  Last Started 2016-05-04 23:55   Status STOPPED
Checkpoint Lag       00:00:00 (updated 00:01:04 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/WB049063
                     2016-05-23 00:05:00.022979  RBA 94821643

GGSCI (epl1trandbtxn1.tsysacquiring.org) 32>

ADD REPLICAT RPTETWLG, EXTTRAIL /acfs/goldengate/dirdat/WB

alter RPTETWLG, extseqno 49063, extrba 94821643

alter RPTETW01, extseqno 49063, extrba 94821643

--------------------------------------------------------------------------------------------
-- TW TE
GGSCI (wpl1trandbtxn1.tsysacquiring.org) 16> info RPTWTE01

REPLICAT   RPTWTE01  Last Started 2016-05-04 22:12   Status STOPPED
Checkpoint Lag       00:00:00 (updated 00:00:06 ago)
Log Read Checkpoint  File /acfs/goldengate/dirdat/EB045049
                     2016-05-23 00:14:02.038502  RBA 95195347

GGSCI (wpl1trandbtxn1.tsysacquiring.org) 17>

ADD REPLICAT RPTWTELG, EXTTRAIL /acfs/goldengate/dirdat/EB

alter RPTWTELG, extseqno 45049, extrba 95195347

alter RPTWTE01, extseqno 45049, extrba 95195347













