#!/bin/sh 
#
# Run as: oracle
#
. oraenv << EOI
orcl
EOI

rman target / catalog rcatowner/oracle_4U@rcat << EOI
  configure ARCHIVELOG DELETION POLICY TO BACKED UP 1 TIMES to device type disk;
  backup database plus archivelog delete all input;
  exit
EOI

exit

