
++========================================================++
||  	FOREIGN KEY CONSTRAINT							  ||
++========================================================++


+-----------+
|	QCP		|
+-----------+

+---------------------------------------------------------------------------------------------------------+
|			+------------------------------------------------------+									  |			
|			|  VERIBIOMATRICS SCHEMA							   |									  |
|			+------------------------------------------------------+									  |
|																										  |
|		ALTER TABLE BX_BANK_ACCOUNT MODIFY ACCOUNT_NUMBER VARCHAR2(25);	   								  |
|																		   								  |
|		--- ACOUNT_NUMBER_MASTER TABLE									   								  |
|																		   								  |
|		ALTER TABLE BX_BANK_ACCOUNT ADD (								   								  |
|		  CONSTRAINT FK_BXBANK_ACCOUNTNO FOREIGN KEY (ACCOUNT_NUMBER) 	   								  |
|			REFERENCES ACCOUNT_NUMBER_MASTER (ACCOUNT_SEQNO));			   								  |
|																		   								  |
|	 	 																								  |
|		ALTER TABLE BX_CARD MODIFY CARD_NUMBER VARCHAR2(25);											  |
|																										  |
|		INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)								  |
|		  SELECT DISTINCT CARD_NUMBER, SUBSTR(CARD_NUMBER, -4), CARD_NUMBER FROM QCP.Bx_Card			  |
|		   WHERE CARD_NUMBER NOT IN (SELECT Card_Seqno FROM Card_Number_Master);						  |
|																										  |
|		ALTER TABLE BX_CARD ADD (																		  |
|		  CONSTRAINT FK_BX_CARD FOREIGN KEY (CARD_NUMBER) 												  |
|			REFERENCES CARD_NUMBER_MASTER (CARD_SEQNO));												  |
|		ALTER TABLE BX_ID ADD TESTID VARCHAR2(30);														  |
|																										  |
|		UPDATE BX_ID SET TESTID = ID_NUMBER;															  |
|																										  |
|		ALTER TABLE BX_ID DROP CONSTRAINT PK_BX_ID														  |
|																										  |
|		UPDATE BX_ID SET ID_NUMBER = NULL;																  |
|																										  |
|		--DELETE FROM BX_ID WHERE LENGTH(ID_NUMBER) > 25;												  |
|																										  |
|		ALTER TABLE BX_ID MODIFY ID_NUMBER VARCHAR2(25);												  |
|																										  |
|		UPDATE BX_ID SET ID_NUMBER = TESTID;															  |
|																										  |
|		ALTER TABLE BX_ID DROP COLUMN TESTID;															  |
|																										  |
|		ALTER TABLE BX_ID ADD CONSTRAINT PK_BX_ID PRIMARY KEY(ID_NUMBER);								  |
|																										  |
|		INSERT INTO Id_Number_Master (Id_Seqno, Id_Mask, Temp_Idno)										  |
|		  SELECT DISTINCT ID_NUMBER, SUBSTR(ID_NUMBER, -4), ID_NUMBER FROM QCP.Bx_Id					  |
|		   WHERE ID_NUMBER NOT IN (SELECT Id_Seqno FROM Id_Number_Master); 								  |
|																										  |
|		ALTER TABLE BX_ID ADD (																			  |
|		  CONSTRAINT FK_BX_ID_IDNUMBER FOREIGN KEY (ID_NUMBER) 											  |
|			REFERENCES ID_NUMBER_MASTER (ID_SEQNO));													  |
|																										  |
+---------------------------------------------------------------------------------------------------------+

ALTER TABLE STEP ADD (											
  CONSTRAINT FK_STEP_ACCOUNTNO FOREIGN KEY (ACCOUNTNO) 			
	REFERENCES ACCOUNT_NUMBER_MASTER (ACCOUNT_SEQNO));			
																
ALTER TABLE STEP_BANKACCOUNTS ADD (								
  CONSTRAINT FK_STEP_BANKACCOUNTS FOREIGN KEY (ACCOUNTNO) 		
	REFERENCES ACCOUNT_NUMBER_MASTER (ACCOUNT_SEQNO));			
 
INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCP.Chargebackblock
   WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master)AND Cardno IS NOT NULL;
	
ALTER TABLE CHARGEBACKBLOCK ADD (
  CONSTRAINT FK_CHARGEBACKBLOCK_CARDNO FOREIGN KEY (CARDNO) 
    REFERENCES CARD_NUMBER_MASTER (CARD_SEQNO));
	
ALTER TABLE STEP ADD (
  CONSTRAINT FK_STEP_CARDNO FOREIGN KEY (CARDNO) 
    REFERENCES CARD_NUMBER_MASTER (CARD_SEQNO));
	
ALTER TABLE STEP_CARDS ADD (
  CONSTRAINT FK_STEPCARDS_CARDNO FOREIGN KEY (CARDNO) 
    REFERENCES CARD_NUMBER_MASTER (CARD_SEQNO));

ALTER TABLE MERCHANT_STEP ADD TESTID VARCHAR2(30);

UPDATE MERCHANT_STEP SET TESTID = ID_NUMBER;

ALTER TABLE MERCHANT_STEP DISABLE CONSTRAINT UNQ_MERCHANT_STEP; 

UPDATE MERCHANT_STEP SET ID_NUMBER = NULL;

--DELETE FROM MERCHANT_STEP WHERE LENGTH(ID_NUMBER) > 25;

ALTER TABLE MERCHANT_STEP MODIFY ID_NUMBER VARCHAR2(25);

UPDATE MERCHANT_STEP SET ID_NUMBER = TESTID;

ALTER TABLE MERCHANT_STEP DROP COLUMN TESTID;

ALTER TABLE MERCHANT_STEP ENABLE CONSTRAINT UNQ_MERCHANT_STEP;

ALTER TABLE MERCHANT_STEP ADD (
  CONSTRAINT FK_MSTEP_ID_NUMBER FOREIGN KEY (ID_NUMBER) 
    REFERENCES ID_NUMBER_MASTER (ID_SEQNO));


GRANT REFERENCES ON ACCOUNT_NUMBER_MASTER TO CHECKCASH;

GRANT REFERENCES ON CARD_NUMBER_MASTER  TO QCREDIT;

GRANT REFERENCES ON ACCOUNT_NUMBER_MASTER TO QCREDIT;

=============================================================================
=============================================================================

+----------------------------------+
|	CHECKCASHING 				   |
+----------------------------------+

INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno) 
  SELECT DISTINCT Accountno, SUBSTR(Accountno, -4), Accountno FROM CHECKCASH.Chkc_Return_Checks 
   WHERE Accountno NOT IN (SELECT Account_Seqno FROM Account_Number_Master);

ALTER TABLE CHKC_RETURN_CHECKS ADD (
  CONSTRAINT FK_CHKC_RETURN_CHECKS FOREIGN KEY (ACCOUNTNO) 
    REFERENCES ACCOUNT_NUMBER_MASTER (ACCOUNT_SEQNO));
	
ALTER TABLE CHKC_ECHO_RECON ADD (
  CONSTRAINT FK_CHKC_ECHO_RECON FOREIGN KEY (ACCOUNTNO) 
    REFERENCES ACCOUNT_NUMBER_MASTER (ACCOUNT_SEQNO));

ALTER TABLE CHKC_TCK_RECON ADD (
  CONSTRAINT FK_CHKC_TCK_RECON FOREIGN KEY (ACCOUNTNO) 
    REFERENCES ACCOUNT_NUMBER_MASTER (ACCOUNT_SEQNO));

=============================================================================
=============================================================================

+----------------------------------+
|	QCREDIT   				       |
+----------------------------------+

ALTER TABLE QC_CARD_TRANSACTIONS ADD (
  CONSTRAINT FK_QC_CARD_TRANSACTIONS FOREIGN KEY (CARDNO) 
    REFERENCES CARD_NUMBER_MASTER (CARD_SEQNO));

ALTER TABLE QC_CREDITDEBITCARDS ADD (
  CONSTRAINT FK_QC_CDCARDS_CARDNO FOREIGN KEY (CARDNO) 
    REFERENCES CARD_NUMBER_MASTER (CARD_SEQNO));
	
ALTER TABLE QC_EXPERIAN_TRADELINE ADD (
  CONSTRAINT FK_QC_EXPERIAN_TRADELINE FOREIGN KEY (ACCOUNTNUMBER) 
    REFERENCES ACCOUNT_NUMBER_MASTER (ACCOUNT_SEQNO));

ALTER TABLE QC_BANKACCOUNTS ADD (
  CONSTRAINT FK_QC_BANKACCOUNTS_ACCNO FOREIGN KEY (ACCOUNTNO) 
    REFERENCES ACCOUNT_NUMBER_MASTER (ACCOUNT_SEQNO));

++=============================================================================++
|| 							END   SCRIPT									   ||
++=============================================================================++
          