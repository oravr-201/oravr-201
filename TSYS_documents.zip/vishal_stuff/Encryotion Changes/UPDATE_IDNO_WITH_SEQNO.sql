CREATE OR REPLACE PROCEDURE Update_Idno_With_Seq
(
	o_OutputStatus      OUT     NUMBER,
    o_OutputMessage     OUT     VARCHAR2
)
IS
 	v_Temp_idno 			   VARCHAR2(25);
	v_idseqno 			  	   VARCHAR2(25);
	vtemp 					   VARCHAR2(25);
	totrec 					   NUMBER;
	v_Seq_No				   NUMBER;
	v_Counter				   NUMBER:=1;
	v_Error					   NUMBER;
	v_error_mess			   VARCHAR(200);					   					   					   
	
CURSOR cur_IDNM 
IS
  SELECT 
  	 TEMP_IDNO
  FROM 
  	 ID_NM_TEMP;
	 
BEGIN
	EXECUTE IMMEDIATE 'TRUNCATE TABLE SEQUENCE_ERROR_LOG ' ;
	EXECUTE IMMEDIATE 'SET TRANSACTION USE ROLLBACK SEGMENT RBS_ENCRYPTION' ; 
	OPEN cur_IDNM;
	IF NOT Cur_TempCardNo%ISOPEN  THEN
	   o_OutputMessage := 'CURSOR NOT OPEN';
	   RETURN; 
	END IF;	
	LOOP
		FETCH cur_IDNM INTO v_Temp_idno;
		EXIT WHEN cur_IDNM%NOTFOUND;
		v_Counter := v_Counter  + 1;
		
		v_Error := 1;	
		SELECT IDNumseqno.NEXTVAL INTO v_Seq_No FROM dual;  
		
		v_Error := 2;
		BEGIN  
		
			UPDATE QCPTEST.ID_NUMBER_MASTER SET ID_SEQNO = v_Seq_No
			WHERE TEMP_IDNO = v_Temp_idno;
				  
			v_Error := 3;		  
			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 4;
					 v_error_mess := SUBSTR(SQLERRM,1,200); 
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'ID_NUMBER_MASTER', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;

---------------------------------------------------------------------------------------
---- QCP SCHEMA TABLES
		
		v_Error := 5;
		BEGIN		
			UPDATE QCPTEST.IDS SET IDNO = v_Seq_No
			WHERE IDNO = v_Temp_idno;
			
			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 6;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'IDS', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;
		
		v_Error := 7;
		BEGIN		
			UPDATE QCPTEST.BX_ID SET ID_NUMBER  = v_Seq_No
			WHERE ID_NUMBER  = v_Temp_idno;

			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 8;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'BX_ID', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;
				
		v_Error := 9;
		BEGIN		
			UPDATE QCPTEST.MERCHANT_STEP SET ID_NUMBER  = v_Seq_No
			WHERE ID_NUMBER  = v_Temp_idno;

			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 10;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'MERCHANT_STEP', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;
		
		v_Error := 11;
		BEGIN		
			UPDATE QCPTEST.MERCHANT_STEP_HISTORY SET ID_NUMBER  = v_Seq_No
			WHERE ID_NUMBER  = v_Temp_idno;

			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 12;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'MERCHANT_STEP_HISTORY', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;

---------------------------------------------------------------------------------------
---- CHECKCASH SCHEMA TABLES
		 
		v_Error := 13;
		BEGIN		
			UPDATE CHECKCASH.CHKC_TCK_RECON SET IDNO1 = v_Seq_No
			WHERE IDNO1  = v_Temp_idno;

			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 14;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'CHKC_TCK_RECON', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;

---------------------------------------------------------------------------------------
---- QCREDIT SCHEMA TABLES

		v_Error := 15;
		BEGIN		
			UPDATE QCREDITTEST.QC_ADDITIONAL_IDS SET IDNO = v_Seq_No
			WHERE IDNO  = v_Temp_idno;

			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 16;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'QC_ADDITIONAL_IDS', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;

		v_Error := 17;
		BEGIN		
			UPDATE QCREDITTEST.QC_CUSTOMER_MASTER SET IDNO = v_Seq_No
			WHERE IDNO  = v_Temp_idno;

			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 18;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'QC_CUSTOMER_MASTER', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;

		v_Error := 19;
		BEGIN		
			UPDATE QCREDITTEST.QC_CUSTOMER_HISTORY SET IDNO = v_Seq_No
			WHERE IDNO  = v_Temp_idno;

			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 20;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'QC_CUSTOMER_HISTORY', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;

---------------------------------------------------------------------------------------
---- WUMT SCHEMA TABLES

		v_Error := 21;
		BEGIN		
			UPDATE WUMTTEST.ADDITIONAL_IDS SET IDNO = v_Seq_No
			WHERE IDNO  = v_Temp_idno;

			EXCEPTION
				WHEN OTHERS THEN
					 v_Error := 22;
					 v_error_mess := SUBSTR(SQLERRM,1,200);
					 INSERT INTO
						   SEQUENCE_ERROR_LOG
						   (
							   SEQ_NO, 
							   TEMP_ENCRYPTNO, 
							   TABLE_NAME, 
							   RECORD_COUNT, 
							   ERROR_MESSAGE,
							   UPDATE_TYPE
						   )
					 VALUES(
							   v_Seq_No, 
							   v_Temp_idno, 
							   'ADDITIONAL_IDS', 
							   NULL, 
							   v_error_mess,
							   'ID_NUMBER'
						   );
		END;
---------------------------------------------------------------------------------------

		v_Error := 23;
		IF v_Counter > 100 THEN
			 INSERT INTO
				   SEQUENCE_ERROR_LOG
				   (
					   SEQ_NO, 
					   TEMP_ENCRYPTNO, 
					   TABLE_NAME, 
					   RECORD_COUNT, 
					   ERROR_MESSAGE,
					   UPDATE_TYPE
				   )
			 VALUES(
					   v_Seq_No, 
					   v_Temp_idno, 
					   NULL, 
					   v_Counter, 
					   'SUCCESS',
					   'ID_NUMBER_MASTER'
				   );
		   v_Counter := 0;	   
   		   COMMIT;
		   EXECUTE IMMEDIATE 'SET TRANSACTION USE ROLLBACK SEGMENT RBS_ENCRYPTION' ;
		END IF;
	END LOOP;
CLOSE Cur_TempCardNo ;
EXCEPTION
    WHEN OTHERS THEN    
    	ROLLBACK;
		o_OutputStatus	:= -1;
		o_OutputMessage	:= 'ERROR IN Update_Idno_With_Seq AT :' ||SUBSTR(SQLERRM,1,100);
END;
/
