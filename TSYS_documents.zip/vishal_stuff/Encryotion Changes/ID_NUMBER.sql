VERO                   CUST_ID                    			ID_NUMBER
VERO                   CUST_ID_IMAGES             			ID_NUMBER

QCP                    ADDITIONAL_IDS             			IDNO
QCP                    BX_ID                    			ID_NUMBER
QCP                    CTRREPORT                   			IDNO
QCP                    IDS                    				IDNO
QCP                    MERCHANT_PREF_CUSTOMERS     			ID_NUMBER
QCP                    MERCHANT_PREF_CUST_HISTORY  			ID_NUMBER
QCP                    MERCHANT_STEP               			ID_NUMBER
QCP                    MERCHANT_STEP_HISTORY       			ID_NUMBER
QCP                    TELECHECKTRANSACTIONS       			IDNO

CHECKCASH              CHKC_TCK_RECON              			ID1
CHECKCASH              CHKC_TRANSACTIONS           			IDNO
CHECKCASH              CTRREPORT                   			IDNO

QCREDIT                QC_ADDITIONAL_IDS           			IDNO
QCREDIT                QC_CUSTOMER_HISTORY         			IDNO
QCREDIT                QC_CUSTOMER_MASTER          			IDNO

REALTIMERPT            CTRREPORT                   			IDNO
REALTIMERPT            CTRREPORT_GCA               			IDNO

WUMT                   ADDITIONAL_IDS              			IDNO
-----------------------------------------------------------------------


QCP                    ADDITIONAL_IDS             			IDNO
QCP                    BX_ID                    			ID_NUMBER
QCP                    IDS                    				IDNO
QCP                    MERCHANT_PREF_CUSTOMERS     			ID_NUMBER
QCP                    MERCHANT_PREF_CUST_HISTORY  			ID_NUMBER
QCP                    MERCHANT_STEP               			ID_NUMBER
QCP                    MERCHANT_STEP_HISTORY       			ID_NUMBER
QCP                    TELECHECKTRANSACTIONS       			IDNO

CHECKCASH              CHKC_TCK_RECON              			ID1
CHECKCASH              CHKC_TRANSACTIONS           			IDNO

QCREDIT                QC_ADDITIONAL_IDS           			IDNO
QCREDIT                QC_CUSTOMER_HISTORY         			IDNO
QCREDIT                QC_CUSTOMER_MASTER          			IDNO

WUMT                   ADDITIONAL_IDS              			IDNO
