CREATE OR REPLACE PROCEDURE UPDATE_IDNO_TO_SEEQNO
(
	o_OutputStatus		OUT 	   NUMBER,
	o_OutputMessage		OUT 	   VARCHAR2				  
)
AS
 	v_Temp_IDNM 				   ID_NM_TEMP.TEMP_IDNO%TYPE;
	v_IDNumberseqno 			   VARCHAR2(25);
	 vtemp 						   VARCHAR2(25);
CURSOR cur_IDNM 
IS
  SELECT 
  	 TEMP_IDNO
  FROM 
  	 ID_NM_TEMP;
BEGIN
	OPEN cur_IDNM;
	LOOP
	SELECT IDNumseqno.NEXTVAL INTO v_IDNumberseqno FROM DUAL;
	FETCH cur_IDNM INTO v_Temp_IDNM;
	--- update Master table
--		SELECT TEMP_IDNO INTO vtemp FROM ID_NM_TEMP WHERE TEMP_IDNO = v_Temp_IDNM;
		
		UPDATE ID_NM_TEMP SET ID_SEQNO = v_IDNumberseqno
		WHERE TEMP_IDNO = v_Temp_IDNM;
		--- update child tables now
		--------------------------------------------
		UPDATE IDS_temp SET IDNO = v_IDNumberseqno
		WHERE IDNO = v_Temp_IDNM;
		----------------------------------------------
 		UPDATE BX_ID_temp SET ID_NUMBER = v_IDNumberseqno
		WHERE ID_NUMBER = v_Temp_IDNM;
		----------------------------------------------
		UPDATE MERCHANT_STEP_temp SET ID_NUMBER = v_IDNumberseqno
		WHERE ID_NUMBER = v_Temp_IDNM;
	
	IF MOD(cur_IDNM%ROWCOUNt,200)=0 THEN
	   COMMIT;
	END IF;
	
	END LOOP;
	CLOSE cur_IDNM;
		
	o_OutputStatus  := 0;
	o_OutputMessage := 'Success';
EXCEPTION
	WHEN OTHERS THEN
	ROLLBACK;
	o_OutputStatus  := -1;
	o_OutputMessage := 'Procedure Failed Sql Error := '||SUBSTR(SQLERRM,1,100);
END;
/
