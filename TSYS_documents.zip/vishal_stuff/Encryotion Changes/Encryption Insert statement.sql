/*
SCHEMA : QCP	
----------------------------------------------------------

CREDITDEBITCARDS					CARDNO
CUSTOMER_CREDITDEBITCARDS			CARDNO
BX_CARD								CARD NO
CHARGEBACKBLOCK						CARD NO
STEP								CARDNO
STEP_CARDS							CARDNO

CUSTOMER_BANKACCOUNTS				ACCOUNTNO
BX_BANK_ACCOUNT						ACCOUNTNO

IDS									IDNO
BX_ID								IDNO

MERCHANT_STEP						ID
STEP								ACCOUNTNO
STEP_BANKACCOUNTS					ACCOUNTNO

		
SCHEMA : QCREDIT	
----------------------------------------------------------
QC_CARD_TRANSACTIONS				CARDNO
QC_CREDITDEBITCARDS					CARDNO
QC_EXPERIAN_TRADELINE				CARDNO/ACCOUNTNO
		
		
SCHEMA : CHECKCASHING		
----------------------------------------------------------
CHKC_RETURN_CHECKS					ACCOUNTNO
CHKC_ECHO_RECON						ACCOUNTNO
CHKC_TCK_RECON						ACCOUNTNO

*/


/*
INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno)
SELECT DISTINCT Accountno, SUBSTR(Accountno, -4), Accountno FROM Customer_Bankaccounts;


INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM Customer_Creditdebitcards;


INSERT INTO Id_Number_Master (Id_Seqno, Id_Mask, Temp_Idno)
SELECT DISTINCT Idno, SUBSTR(IDNO, -4), Idno FROM IDS;
*/
/*
---------------------------------------------------------------------------------
	+------------------------------------------+
	|			INSERT STATEMENTS			   |
	+------------------------------------------+
----------------------------------------------------------------------------------

------------------   SCHEMA NAME :  QCP 
*/

INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCP.Creditdebitcards
   WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master)AND Cardno IS NOT NULL;
 
---- Changes R done from first only..............
INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCP.Customer_Creditdebitcards			
   WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master); 

     
INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno)
  SELECT DISTINCT Accountno, SUBSTR(Accountno, -4), Accountno FROM QCP.Customer_Bankaccounts
   WHERE Accountno NOT IN (SELECT Account_Seqno FROM Account_Number_Master); 


INSERT INTO Id_Number_Master (Id_Seqno, Id_Mask, Temp_Idno)
  SELECT DISTINCT Idno, SUBSTR(IDNO, -4), Idno FROM IDS
   WHERE Idno NOT IN (SELECT Id_Seqno FROM Id_Number_Master); 


------------------------------------------

----- ACCOUNT_NUMBER Varchar2(15) /25
INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno)
  SELECT DISTINCT ACCOUNT_NUMBER, SUBSTR(ACCOUNT_NUMBER, -4), ACCOUNT_NUMBER FROM QCP.Bx_Bank_Account
   WHERE ACCOUNT_NUMBER NOT IN (SELECT Account_Seqno FROM Account_Number_Master); 
   

----Data type CARD_NUMBER varchar2(19)  /25
INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT CARD_NUMBER, SUBSTR(CARD_NUMBER, -4), CARD_NUMBER FROM QCP.Bx_Card
   WHERE CARD_NUMBER NOT IN (SELECT Card_Seqno FROM Card_Number_Master);
 
----- ID_NUMBER varchar2(30)  /25
INSERT INTO Id_Number_Master (Id_Seqno, Id_Mask, Temp_Idno)
  SELECT DISTINCT ID_NUMBER, SUBSTR(ID_NUMBER, -4), ID_NUMBER FROM QCP.Bx_Id
   WHERE ID_NUMBER NOT IN (SELECT Id_Seqno FROM Id_Number_Master); 
  
  
INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCP.Chargebackblock
   WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master)AND Cardno IS NOT NULL;
  

------------------ Varchar2(30)  /25  
INSERT INTO Id_Number_Master (Id_Seqno, Id_Mask, Temp_Idno)
  SELECT DISTINCT ID_NUMBER, SUBSTR(ID_NUMBER, -4), ID_NUMBER FROM QCP.Merchant_Step 
   WHERE ID_NUMBER NOT IN (SELECT Id_Seqno FROM Id_Number_Master); 
  
 
INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCP.Step 
   WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master)AND Cardno IS NOT NULL;
  
  
INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno)
  SELECT DISTINCT Accountno, SUBSTR(Accountno, -4), Accountno FROM QCP.Step 
   WHERE ACCOUNTNO NOT IN (SELECT Account_Seqno FROM Account_Number_Master) AND ACCOUNTNO IS NOT NUll;
 
 
INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCP.Step_Cards 
    WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master);

 
INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCP.Step_Cards 
   WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master);
	

-----------------------------------------------------------------------------------------  
------------------   SCHEMA NAME : QCREDIT	

INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCREDIT.Qc_Card_Transactions 
   WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master);

INSERT INTO Card_Number_Master (Card_Seqno, Card_Mask, Temp_Cardno)
  SELECT DISTINCT Cardno, SUBSTR(Cardno, -4), Cardno FROM QCREDIT.Qc_Creditdebitcards 
   WHERE Cardno NOT IN (SELECT Card_Seqno FROM Card_Number_Master);

INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno)
  SELECT DISTINCT Accountnumber, SUBSTR(Accountnumber, -4), Accountnumber FROM QCREDIT.Qc_Experian_Tradeline qet 
    WHERE qet.Accountnumber NOT IN (SELECT Account_Seqno FROM Account_Number_Master) 
     AND qet.Accountnumber IS NOT NULL;
     
INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno)
  SELECT DISTINCT Accountnumber, SUBSTR(Accountnumber, -4), Accountnumber FROM QCREDIT.Qc_Bankaccounts qet 
    WHERE qet.Accountnumber NOT IN (SELECT Account_Seqno FROM Account_Number_Master) 
      AND qet.Accountnumber IS NOT NULL;
      
---------------------------------------------------------------------------------------  
------------------   SCHEMA NAME : CHECKCASHING 
 
INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno) 
  SELECT DISTINCT Accountno, SUBSTR(Accountno, -4), Accountno FROM CHECKCASH.Chkc_Return_Checks 
   WHERE Accountno NOT IN (SELECT Account_Seqno FROM Account_Number_Master);
  
INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno)
  SELECT DISTINCT Accountno, SUBSTR(Accountno, -4), Accountno FROM CHECKCASH.Chkc_Echo_Recon 
   WHERE Accountno NOT IN (SELECT Account_Seqno FROM Account_Number_Master);
 
INSERT INTO Account_Number_Master (Account_Seqno, Account_Mask, Temp_Accountno)
  SELECT DISTINCT Accountno, SUBSTR(Accountno, -4), Accountno FROM CHECKCASH.Chkc_Tck_Recon 
   WHERE Accountno NOT IN (SELECT Account_Seqno FROM Account_Number_Master);
