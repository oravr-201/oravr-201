select address,hash_value from v$sqlarea
where sql_id = 'fu02q80b2kva1'
/
