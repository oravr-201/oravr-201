#!/bin/sh 
#
# Run as: oracle
#
# Copy the datafile for the USERS tablespace. This is in ASM, so asmcmd must
# be used. Have to find the actual file name using ASM. This is used to 
# later catalog this image copy in the recovery catalog. 
# Written by: Tom Best
export ORACLE_SID=+ASM
rm -f /tmp/users_copy.dat
asmcmd cp data/orcl/datafile/`asmcmd ls  data/orcl/datafile/users*` /tmp/users_copy.dat
