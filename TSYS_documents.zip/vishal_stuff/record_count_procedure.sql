CREATE TABLE RECORD_COUNT
(
  OWNER         VARCHAR2(30 BYTE),
  TABLE_NAME    VARCHAR2(30 BYTE),
  RECORD_COUNT  NUMBER
)
TABLESPACE USERS


CREATE OR REPLACE PROCEDURE RAHULC.Get_Record_Count
(
    o_outputMessage  OUT VARCHAR2
)
AS
  v_cnt        NUMBER;
  v_select_stmt    VARCHAR2(200);
BEGIN

  EXECUTE IMMEDIATE 'truncate table record_count';

  FOR i IN (SELECT owner, table_name 
            FROM ALL_TABLES 
            WHERE table_name NOT LIKE 'SN_TEMP%' 
              AND owner IN ('SNOX4TRANSNOX','TRANSNOX_GLORY','TRANSNOX_WM','SNOX')
            ORDER BY 1,2 ASC)
  LOOP
  
    v_select_stmt:='select count(*) from '||i.owner||'.'||i.table_name;  
    
    EXECUTE IMMEDIATE  v_select_stmt INTO v_cnt;
    
    INSERT INTO record_count(owner,table_name,record_count)
     VALUES (i.owner,i.table_name,v_cnt);
     
    COMMIT;
    
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    o_outputMessage:= 'Procedure failed for  '||SUBSTR(SQLERRM,1,100);
END;
/



copy from schema1 to schema2 create rc1 using
select * from record_count;



select t1.OWNER, t1.TABLE_NAME, t2.RECORD_COUNT t67,t1.RECORD_COUNT t66, 
(case when (t2.record_count < t1.record_count) then (t1.RECORD_COUNT-t2.RECORD_COUNT) else 0 end ) diff
from record_count t1, rc67 t2
where t1.owner=t2.owner
 and t1.table_name = t2.table_name
  and t1.record_count <> t2.RECORD_COUNT
order by diff desc  



