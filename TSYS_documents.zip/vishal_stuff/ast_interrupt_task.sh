#!/bin/bash
# For training purpose only, execute as oracle OS user

sqlplus / as sysdba <<EOF!

connect / as sysdba
set echo on
--
-- Interrupt the task
--
exec dbms_sqltune.interrupt_tuning_task('SYS_AUTO_SQL_TUNING_TASK');

EOF!

