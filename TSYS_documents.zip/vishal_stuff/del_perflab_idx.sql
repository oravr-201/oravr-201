DECLARE 
  sql_stmt VARCHAR2(2000);
  idx_name VARCHAR2(30);

BEGIN

  SELECT index_name INTO idx_name
    FROM DBA_INDEXES
    WHERE owner = 'SH'
    AND index_name LIKE 'IDX$$%'
    AND table_name = 'CUSTOMERS';

  sql_stmt := 'DROP INDEX SH.'||idx_name;

  EXECUTE IMMEDIATE sql_stmt;

END;
/
