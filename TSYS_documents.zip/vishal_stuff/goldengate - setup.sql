/*

-- Extract process
ADD EXTRACT eprc, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/ss, EXTRACT eprc, MEGABYTES 100

-- Pump Process
ADD EXTRACT pprc, EXTTRAILSOURCE /acfs/goldengate/dirdat/ss
ADD RMTTRAIL /acfs/goldengate/dirdat/xy, EXTRACT pprc, MEGABYTES 100

-- Replication Process
ADD REPLICAT rprc, EXTTRAIL /acfs/goldengate/dirdat/xy


*/


----- Below are the processes setup on DCW GoldenGate

-- TW (txnDCW) Database Processes 
ADD EXTRACT EPTW, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LC, EXTRACT EPTW, MEGABYTES 100

-- Pump Process for replicating data in RW DB
ADD EXTRACT PPTWRW, EXTTRAILSOURCE /acfs/goldengate/dirdat/LC
ADD RMTTRAIL /acfs/goldengate/dirdat/WA, EXTRACT PPTWRW, MEGABYTES 100

-- Pump Process for replicating data in TE DB
ADD EXTRACT PPTWTE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LC
ADD RMTTRAIL /acfs/goldengate/dirdat/WB, EXTRACT PPTWTE, MEGABYTES 100

-- Pump Process for replicating data in RE DB
ADD EXTRACT PPTWRE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LC
ADD RMTTRAIL /acfs/goldengate/dirdat/WC, EXTRACT PPTWRE, MEGABYTES 100
-----------------------------------------------------------------------------

--- RW (rptDCW) Database processes
ADD EXTRACT EPRW, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LD, EXTRACT EPRW, MEGABYTES 100

-- Pump Process for replicating data in RW database
ADD EXTRACT PPRWRE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LD
ADD RMTTRAIL /acfs/goldengate/dirdat/WS, EXTRACT PPRWRE, MEGABYTES 100
-----------------------------------------------------------------------------

-- Replicating from TE DB to TW DB
ADD REPLICAT RPTWTE, EXTTRAIL /acfs/goldengate/dirdat/EB
-- Replicating from TW DB to RW DB
ADD REPLICAT RPRWTW, EXTTRAIL /acfs/goldengate/dirdat/WA
-- Replicating from TE DB to RW DB
ADD REPLICAT RPRWTE, EXTTRAIL /acfs/goldengate/dirdat/EC
-- Replicating from RE DB to RW DB
ADD REPLICAT RPRWRE, EXTTRAIL /acfs/goldengate/dirdat/RA



----- Below are the processes setup on DCE GoldenGate

-- TE (txnDCE) Database Process es
ADD EXTRACT EPTE, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LA, EXTRACT EPTE, MEGABYTES 100

-- Pump Process for replicating data in RE DB
ADD EXTRACT PPTERE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LA
ADD RMTTRAIL /acfs/goldengate/dirdat/EA, EXTRACT PPTERE, MEGABYTES 100

-- Pump Process for replicating data in TW DB
ADD EXTRACT PPTETW, EXTTRAILSOURCE /acfs/goldengate/dirdat/LA
ADD RMTTRAIL /acfs/goldengate/dirdat/EB, EXTRACT PPTETW, MEGABYTES 100

-- Pump Process for replicating data in RW DB
ADD EXTRACT PPTERW, EXTTRAILSOURCE /acfs/goldengate/dirdat/LA
ADD RMTTRAIL /acfs/goldengate/dirdat/EC, EXTRACT PPTERW, MEGABYTES 100
---------------------------------------------------------------------------------------

--- RE (rptDCE) Database processes
ADD EXTRACT EPRE, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LB, EXTRACT EPRE, MEGABYTES 100

-- Pump Process for replicating data in RW DB
ADD EXTRACT PPRERW, EXTTRAILSOURCE /acfs/goldengate/dirdat/LB
ADD RMTTRAIL /acfs/goldengate/dirdat/RA, EXTRACT PPRERW, MEGABYTES 100

---------------------------------------------------------------------------------------
-- Replicating from TW DB to TE DB
ADD REPLICAT RPTETW, EXTTRAIL /acfs/goldengate/dirdat/WB
-- Replicating from TE DB to RE DB
ADD REPLICAT RPRETE, EXTTRAIL /acfs/goldengate/dirdat/EA
-- Replicating from TW DB to RE DB
ADD REPLICAT RPRETW, EXTTRAIL /acfs/goldengate/dirdat/WC
-- Replicating from RW DB to RE DB
ADD REPLICAT RPRERW, EXTTRAIL /acfs/goldengate/dirdat/WS

---------------------------------------------------------------------------------------

-->>DCW Manager Process 
GGSCI (wdl1trandbs01.tsysacquiring.org) 17> sh cat dirprm/mgr.prm

PORT 15001
DYNAMICPORTLIST 15002-15025

USERID ggate, PASSWORD tsys123

--AUTOSTART JAGENT

AUTORESTART EXTRACT EPRW, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART EXTRACT EPTW, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART EXTRACT PPRWRE, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART EXTRACT PPTWRE, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART EXTRACT PPTWRW, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART EXTRACT PPTWTE, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30

AUTORESTART REPLICAT RPRWRE, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART REPLICAT RPRWTE, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART REPLICAT RPRWTW, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
AUTORESTART REPLICAT RPTWTE, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30

LAGCRITICALMINUTES 5

LAGINFOMINUTES 10

LAGREPORTMINUTES 60

PURGEOLDEXTRACTS /acfs/goldengate/dirdat/*, USECHECKPOINTS, MINKEEPDAYS 2 --*/

-- To keep the GG Marker and DDL history tables a reasonable size
PURGEMARKERHISTORY MINKEEPDAYS 3, MAXKEEPDAYS 5, FREQUENCYMINUTES 30
PURGEDDLHISTORY MINKEEPDAYS 3, MAXKEEPDAYS 5, FREQUENCYMINUTES 30

GGSCI (wdl1trandbs01.tsysacquiring.org) 18>
---------------------------------------------------------------------------------------

-->> DCW ./GLOBAL Process
GGSCI (wdl1trandbs01.tsysacquiring.org) 16> sh cat ./GLOBALS

GGSCHEMA ggate
CHECKPOINTTABLE GGATE.CHKPTAB
ENABLEMONITORING

GGSCI (wdl1trandbs01.tsysacquiring.org) 17>
---------------------------------------------------------------------------------------

-->> DCW JAgent Process for Monitoring
GGSCI (wdl1trandbs01.tsysacquiring.org) 18>  sh cat dirprm/jagent.prm

COMMAND export JAVA_HOME=/acfs/goldengate/java_jdk/jdk1.6.0_45
COMMAND /acfs/goldengate/java_jdk/jdk1.6.0_45/bin/java -jar -Xms64m -Xmx512m /acfs/goldengate/dirjar/jagent.jar


GGSCI (wdl1trandbs01.tsysacquiring.org) 19>
---------------------------------------------------------------------------------------



