#!/bin/sh 
#
# Run as: oracle
#

rm -f /tape/*

exit

