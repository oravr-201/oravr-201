#!/bin/sh 
#
# Run as: oracle
#

echo Setting up ORCL environment. 
. oraenv <<-EOI
orcl
EOI

sqlplus / as sysdba <<-EOI
  alter system set filesystemio_options = none scope = spfile;
  ALTER SYSTEM SET DISK_ASYNCH_IO = FALSE SCOPE=SPFILE;
  shutdown immediate
  startup
  exit
EOI

exit
