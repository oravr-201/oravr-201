
/etc/init.d/oracleasm createdisk ASMGOLDENGATE /dev/mapper/asmgoldengate

mount -t acfs /dev/asm/goldengate-5 /home/oracle/acfs/

useradd -u 503 -g oinstall -G dba goldengate

chage -I -1 -m 0 -M 99999 -E -1 goldengate

id goldengate

history | grep goldengate

id goldengate

id goldengate

usermod -g dba -G oinstall goldengate

/opt/app/11.2.0/grid/bin/srvctl stop filesystem -d /dev/asm/goldengate-405

/opt/app/11.2.0/grid/bin/srvctl remove filesystem -d /dev/asm/goldengate-405

cp /home/oracle/.bash_profile /home/goldengate/bash

chown -R goldengate.dba /home/goldengate

su -l goldengate

history |grep golden


alter table TRANSNOX_IOX.REQUEST_AUDIT_TRAIL modify SOURCE varchar2(500);







