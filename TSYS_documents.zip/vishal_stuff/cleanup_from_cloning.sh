#!/bin/sh 
#
# Run as: oracle
#
# Written by: Tom Best

rm -f /backup/*

. oraenv <<-EOI
odup
EOI

sqlplus / as sysdba <<-EOI
	shutdown immediate
	exit
EOI

# This also starts up the ORCL instance
~/labs/orcl_to_archivelog.sh

. oraenv <<-EOI
rcat
EOI

sqlplus / as sysdba <<-EOI
	startup
	exit
EOI

exit
