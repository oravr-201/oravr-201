REM "For training purposes ONLY
REM  Connected as SYSDBA user with the oracle_4U password

set echo on
set linesize 120
col member format a43
col status format a10

select l.group#, l.sequence#, l.archived,l.status, f.member
  from v$log l, v$logfile f
  where l.group#=f.group#;






