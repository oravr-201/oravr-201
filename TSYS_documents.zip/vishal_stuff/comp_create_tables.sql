REM For training only
-- Hybrid Columnar Compression COMPRESS FOR QUERY
connect compi

DROP TABLE cust_nocomp purge;
DROP TABLE cust_hcc_query;
DROP TABLE cust_hcc_archive;

-- Table with uncompressed data
CREATE TABLE cust_nocomp
 AS SELECT * FROM SH.CUSTOMERS;

-- Hybrid Columnar Compression COMPRESS FOR QUERY
CREATE TABLE cust_hcc_query
 COMPRESS FOR QUERY
 AS SELECT * FROM SH.CUSTOMERS;

-- Hybrid Columnar Compression COMPRESS FOR ARCHIVE
CREATE TABLE cust_hcc_archive
 COMPRESS FOR ARCHIVE HIGH
 AS SELECT * FROM SH.CUSTOMERS;
