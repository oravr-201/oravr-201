REM For training only
set timing on
set serveroutput on
declare
total_rows number := 0;
begin
 for rec in (select cust_id,CUST_VALID
               from cust_nocomp
            )
 loop
  total_rows := total_rows + 1;
 end loop;
 dbms_output.put_line(total_rows||' rows selected.');
end;
/
