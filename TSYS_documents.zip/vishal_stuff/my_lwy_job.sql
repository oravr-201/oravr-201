REM For training only
set echo on

BEGIN
-- Cleanup from previous runs
-- These two calls will produce errors on the first run
sys.dbms_scheduler.disable('"SYSTEM"."MY_LWT_JOB"');
sys.dbms_scheduler.drop_job('"SYSTEM"."MY_LWT_JOB"');
END ;
/

BEGIN
-- Create the Job
sys.dbms_scheduler.create_job(
job_name => '"SYSTEM"."MY_LWT_JOB"',
program_name => '"SYSTEM"."MY_PROG"',
repeat_interval => 'FREQ=MINUTELY;INTERVAL=3',
start_date => systimestamp at time zone 'America/Chicago',
job_class => '"DEFAULT_JOB_CLASS"',
job_style => 'LIGHTWEIGHT',
comments => 'Lightweight job',
enabled => TRUE);
sys.dbms_scheduler.enable( '"SYSTEM"."MY_LWT_JOB"' );
END;
/

