sqlplus / as sysdba <<EOF

drop table hr.departments cascade constraints;

select * from hr.departments;
select * from hr.departments;
select * from hr.departments;
exit

EOF
