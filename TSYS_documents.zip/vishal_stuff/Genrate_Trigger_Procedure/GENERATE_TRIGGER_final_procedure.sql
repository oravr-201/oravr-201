CREATE TABLE REPL_TRI.Z_REPLICATION_DATA
(
  REPLICATION_ID  NUMBER,
  TIMESTAMP       DATE,
  USER_NAME       VARCHAR2(20 BYTE),
  TABLE_NAME      VARCHAR2(50 BYTE),
  OPERATION       VARCHAR2(10 BYTE),
  PRIMARY_COLS    VARCHAR2(100 BYTE),
  PRIMARY_VALS    VARCHAR2(100 BYTE),
  COLS            VARCHAR2(1000 BYTE),
  VALS            VARCHAR2(4000 BYTE),
  CHILD_RECORD    VARCHAR2(1 BYTE)              DEFAULT 'N',
  REPLICATED      NUMBER
)
TABLESPACE USERS
NOLOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE REPL_TRI.Z_REPLICATION_DATA_EX
(
  REPLICATION_ID  NUMBER,
  COLNAME         VARCHAR2(30 BYTE),
  COLTYPE         VARCHAR2(30 BYTE)
)
TABLESPACE USERS
NOLOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE REPL_TRI.Z_TARGET_REP_DATA
(
  REPLICATION_ID  NUMBER,
  TIMESTAMP       DATE,
  USER_NAME       VARCHAR2(20 BYTE),
  TABLE_NAME      VARCHAR2(50 BYTE),
  OPERATION       VARCHAR2(10 BYTE),
  PRIMARY_COLS    VARCHAR2(100 BYTE),
  PRIMARY_VALS    VARCHAR2(100 BYTE),
  COLS            VARCHAR2(1000 BYTE),
  VALS            VARCHAR2(4000 BYTE),
  CHILD_RECORD    VARCHAR2(1 BYTE)              DEFAULT 'N',
  REPLICATED      NUMBER
)
TABLESPACE USERS
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE REPL_TRI.Z_TARGET_REP_DATA_EX
(
  REPLICATION_ID  NUMBER,
  COLNAME         VARCHAR2(30 BYTE),
  COLTYPE         VARCHAR2(30 BYTE)
)
TABLESPACE USERS
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE TABLE REPL_TRI.Z_TRIGGER_CREATION_TBL
(
  TRIGGER_DATA  LONG
)
TABLESPACE USERS
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;





CREATE OR REPLACE PROCEDURE REPL_TRI.GENERATE_TRIGGER
(
	o_Message 			OUT 	LONG
)
AUTHID CURRENT_USER
IS
    v_tble_SchemaName           VARCHAR2(30):='SNOX4TRANSNOX_GCA';  

    v_ErrorFlag	   				NUMBER; 
	
	v_sql 			 			VARCHAR2(32000);
	
	v_Flagcnt 					VARCHAR2(6);
	
	v_Trigger_Count				NUMBER:=0;
	v_Table_Name				VARCHAR2(40);

	v_sqlString					VARCHAR2(2000);
	v_pk_columns				VARCHAR2(32000);
    
    v_sql_insert_str1           VARCHAR2(32000);
		
	v_clob_blob_strSQL			LONG; --VARCHAR2(32000);
	v_without_clob_blob_sqlstr  LONG; --VARCHAR2(32000);
	v_clbl_string				LONG; --VARCHAR2(32000);
	v_sqlstr					LONG; --VARCHAR2(32000);
	v_string					LONG; --VARCHAR2(32000);
	v_insert_string				LONG; --VARCHAR2(32000);
		
	v_Col_Name					VARCHAR2(30);	
 	v_Data_Type					VARCHAR2(30);	
	
	v_Col_Name1					VARCHAR2(30);	
 	v_Data_Type1				VARCHAR2(30);	
	v_prikeyCol_Name			VARCHAR2(30);

	v_pcols       				VARCHAR2(4000);
	v_pvals       				VARCHAR2(4000);
	v_Cols        				VARCHAR2(15000);
	v_vals        				VARCHAR2(30000);

	v_msg						NUMBER;
    
    v_errormsage                VARCHAR2(1000);
    
    v_len_check                 NUMBER;
    
    v_vals_CB                   VARCHAR2(100); -- for handling CLOB and BLOB
    v_Clob_Blob_flag            VARCHAR2(10):='FALSE';
	
	TYPE C_REF_CUR IS REF CURSOR;
	REF_COLNAME C_REF_CUR;
	
BEGIN

    --DBMS_OUTPUT.ENABLE(1000000); -- to increase the buffer of DBMS_OUTPUT function
   
	--Z_TRIGGER_CREATION_TBL
	
   v_Cols := NULL;
   v_Vals := NULL;
   
	v_ErrorFlag:=1;
	-- delete all records from Z_TRIGGER_CREATION_TBL  
	EXECUTE IMMEDIATE 'TRUNCATE TABLE Z_TRIGGER_CREATION_TBL';
    

	v_msg := 105;
    
       v_ErrorFlag:=1.2;
	-- list all those table which are having primary key and not having primary key
	-- execpt all those tables which are having primary key to all the columns in a table    
	FOR z IN (SELECT Table_Name, DECODE(Constraint_Type,'P','PK','NOPK') Check_Constraints
              FROM		
                  (SELECT ut.Table_Name, uc.Constraint_Type 
                   FROM USER_TABLES ut, USER_CONSTRAINTS uc
                   WHERE ut.Table_Name = uc.Table_Name
                     AND uc.constraint_type='P'
                     AND ut.Table_Name IN(SELECT Table_Name
                                          FROM USER_CONSTRAINTS
                                          WHERE Constraint_Type='P')
                     AND ut.Table_Name NOT IN(SELECT Table_Name FROM USER_TABLES A
                                              WHERE (SELECT COUNT(1) 
                                                     FROM USER_CONS_COLUMNS b,USER_CONSTRAINTS c 
                                                     WHERE A.Table_Name = b.Table_Name 
                                                       AND b.Constraint_Name = c.Constraint_Name 
                                                       AND c.Constraint_Type='P') = (SELECT COUNT(1) 
                                                                                     FROM USER_TAB_COLUMNS b 
                                                                                     WHERE A.Table_Name=b.Table_Name))
                    UNION
                    SELECT Table_Name, NULL FROM USER_TABLES
                    WHERE Table_Name NOT IN(SELECT Table_Name
                                           FROM USER_CONSTRAINTS
                                           WHERE Constraint_Type='P') AND table_name NOT IN('DEVICE_SERVICE','OPERATOR_FEEDBACK','TRANSACTION','Z_TRIGGER_CREATION_TBL','Z_REPLICATION_DATA', 'Z_REPLICATION_DATA_EX', 'Z_TARGET_REP_DATA', 'Z_TARGET_REP_DATA_EX'))abc
        --				  WHERE table_name='PAYMENTECH_TRANSACTIONS'
                  ORDER BY Check_Constraints ASC
             )
	LOOP
      
          -- these condition is for primary key columns 
          IF z.CHECK_CONSTRAINTS ='PK' THEN
                v_Table_Name:=z.table_name;
    			
                  IF v_msg= 106 THEN
                      EXECUTE IMMEDIATE 'INSERT INTO Z_TRIGGER_CREATION_TBL VALUES ('''||CHR(10)||'-- Trigger Script for primary key tables'')'||CHR(10)||'';
                      --DBMS_OUTPUT.PUT_LINE(''||CHR(10)||'Trigger Script for primary key tables '||CHR(10));
                      v_msg:= 107;			  
                  END IF;				
    			
                BEGIN
                    v_pcols      := NULL;
                    v_pvals      := NULL;
                    v_Cols       := NULL;
                    v_vals       := NULL;

                    -- query for those cloumns which are having primary key difined 
                    v_ErrorFlag:=11;
                    v_pk_columns:=
                    ' SELECT Column_Name '||
                    ' FROM USER_CONS_COLUMNS ACC, USER_CONSTRAINTS AC  '||
                    ' WHERE ACC.Constraint_Name = AC.Constraint_Name   '||
                    '   AND AC.Constraint_Type  = ''P''				   '||
                    '   AND ACC.Table_Name	  = '''||v_Table_Name||'''';

                    -- start loop for columns difined with primary key 
                   OPEN REF_COLNAME FOR v_pk_columns;
                    LOOP
                      FETCH REF_COLNAME INTO v_prikeyCol_Name;
                       EXIT WHEN REF_COLNAME%NOTFOUND;
    				   
                         -- pk columns
                         v_ErrorFlag:=12;
                         IF v_pcols IS NOT NULL THEN
                             v_pcols := v_pcols ||'^~'||v_prikeyCol_Name;
                         ELSE
                             v_pcols := v_prikeyCol_Name;
                         END IF;

                         -- pk values
                         v_ErrorFlag:=13;
                         IF v_pvals IS NOT NULL THEN
                             v_pvals := v_pvals||'|| ''^~'' ||'||' :OLD.'||v_prikeyCol_Name;
                         ELSE
                             v_pvals := ':OLD.'||v_prikeyCol_Name;
                         END IF;
                    END LOOP;	 
    				
                    -- query to get column_name and there data_type for those tables, which are having pk 
                    v_ErrorFlag:=14;
                    v_sqlString:= 
                      ' SELECT COLUMN_NAME, DATA_TYPE '||
                      ' FROM USER_TAB_COLUMNS utb     '||
                      ' WHERE column_name NOT IN(SELECT Column_Name '||
                      '  	     				 FROM USER_CONS_COLUMNS acc, USER_CONSTRAINTS ac '||
                      '		 				     WHERE acc.table_name = utb.table_name		  	 '|| 
                      '							   AND ACC.Constraint_Name = AC.Constraint_Name  '||
                      '		   				       AND AC.Constraint_Type  = ''P'')              '||
                      '   AND utb.table_name='''||v_Table_Name||'''';
    				  
                    EXECUTE IMMEDIATE v_sqlString;

                    -- start loop
                    OPEN REF_COLNAME FOR v_sqlString;
                     LOOP
                      FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
                       EXIT WHEN REF_COLNAME%NOTFOUND;
                            -- only column values for those columns which are having data type like varchar, char number, integer
                            IF v_Data_Type IN ('VARCHAR2', 'CHAR', 'NUMBER', 'INTEGER','DATE') THEN
                               v_Cols  := v_Cols ||'^~'||v_Col_Name;
                            END IF;

                            -- all values
                            IF v_Data_Type = 'DATE' THEN
                               v_vals := v_vals ||'|| ''^~'' ||'||'''TO_DATE(''''''|| TO_CHAR (:NEW.'||v_Col_Name||', ''MMDDYYYY HH24MISS'')||'''''', ''''MMDDYYYY HH24MISS'''')''';
                            ELSIF v_Data_Type IN ('VARCHAR2', 'CHAR', 'NUMBER', 'INTEGER') THEN
                               v_vals := v_vals ||'|| ''^~'' ||'||' :NEW.'||v_Col_Name;
                            END IF;
                            
                            -- Actually Do nothing when CLOB/BLOB data type is coming, just taking in variable as null.. 
                            -- we can remove the  below if condition code
                            IF v_Data_Type IN ('BLOB','CLOB') THEN
                               v_vals_CB :='''''';
                               v_Clob_Blob_flag:='TRUE'; -- it will true when there is any clobn/blob in table
                            END IF;
                     END LOOP;
    				 
                     IF v_vals <> '''''' THEN
                        v_vals := SUBSTR(v_vals,11);
                        IF SUBSTR(v_vals,1,2)= '||' THEN
                          v_vals := SUBSTR(v_vals,3);
                        END IF;
                     END IF;
                ----------------------------------------------------------------------------------------------------

                    -- here stars the trigger creation scripts
                    v_sql := 'CREATE OR REPLACE TRIGGER '||SUBSTR(v_Table_Name,1,24)||'_REPL'           ||CHR(10)||
                    ' AFTER INSERT OR UPDATE OR DELETE'															||CHR(10)||
                    ' ON '	   	  		 																||CHR(10)||
                    '	'||v_Table_Name																	||CHR(10)||
                    ' FOR EACH ROW '																	||CHR(10)||
                    ' DECLARE '	   																		||CHR(10)||
                    ' 	v_Ref_Id      	NUMBER; '														||CHR(10)||
                    '	v_Operation   	VARCHAR2(10); '													||CHR(10)||
                    '	v_pcols       	VARCHAR2(1000)	:= NULL; '										||CHR(10)||
                    '	v_pvals       	VARCHAR2(1000)	:= NULL; '										||CHR(10)||
                    '	v_Cols        	VARCHAR2(4000)	:= NULL; '										||CHR(10)||
                    '	v_vals        	VARCHAR2(4000)	:= NULL; '										||CHR(10)||
                    '	v_child        	VARCHAR2(2); '													||CHR(10)||
                    ' BEGIN '							   						   						||CHR(10)||
                    ' 	   																			'   ||CHR(10)||
                    '   SELECT SRC_C_REPL.REPLICATION_SEQ.NEXTVAL INTO v_Ref_Id FROM Dual; 		    '   ||CHR(10)||		 
                    ' 	   																			'   ||CHR(10)||	
                    '   IF DELETING THEN '																||CHR(10)||
                    '      v_operation := ''DELETE''; '												||CHR(10)||
                    '      v_pcols     := '''||v_pcols||'''; '										||CHR(10)||
                    '      v_pvals     := '||v_pvals||';'	  											||CHR(10)||
                    '   END IF;	'		   																||CHR(10)||
                    ' 	   																			'   ||CHR(10)||
                    '   IF UPDATING THEN '																||CHR(10)||
                    '      v_operation := ''UPDATE''; '													||CHR(10)||
                    '      v_pcols     := '''||v_pcols||'''; '											||CHR(10)||
                    '      v_pvals     := '||v_pvals||'; '	  											||CHR(10)||
                    '      v_cols      := '''||SUBSTR(v_Cols,3)||'''; '									||CHR(10)||
                    '      v_vals      := '||NVL(v_vals,'''''')||'; ' 							        ||CHR(10)||
                    '   END IF; ' 		   				 											    ||CHR(10)||
                    ' 	   																			'   ||CHR(10)||
                    '   IF INSERTING THEN '																||CHR(10)||
                    '      v_operation := ''INSERT''; '													||CHR(10);
    --				'      v_pcols     := '''||v_pcols||'''; '										||CHR(10)||
    --				'      v_pvals     := '||REPLACE(v_pvals,':OLD.',':NEW.')||'; '					||CHR(10);
    				
                    IF v_Clob_Blob_flag = 'TRUE' THEN
                      v_insert_string:=	
                        '      v_cols      := '''||v_pcols||''';	'	   	 							||CHR(10)||				  
                        '      v_vals      := '||REPLACE(v_pvals,':OLD.',':NEW.')||';	'				||CHR(10)||
                        '   END IF;	';
                        
                        v_Clob_Blob_flag:= 'FALSE'; -- mkae false clob/blob work is done
                    ELSE	
                      v_insert_string:=	
                        '      v_cols      := '''||v_pcols||'^~'||SUBSTR(v_Cols,3)||''';	'	   	 				||CHR(10)||
                        '      v_vals      := '||REPLACE(v_pvals,':OLD.',':NEW.')||'|| ''^~'' ||'||NVL(v_vals,'''''')||';	'||CHR(10)||
                        '   END IF;	';
                    END IF; 		
    				
                    --- break for clob, blob, long raw insertion in SRC_C_REPL.REPLICATION_DATA_EX
    				
                    -- query will return only those column name which are having blob, clob datatype 				
                    v_clob_blob_strSQL := 'SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '''||v_Table_Name||''' AND DATA_TYPE IN(''BLOB'',''CLOB'')';
                    EXECUTE IMMEDIATE v_clob_blob_strSQL;
    				
                    -- start loop for clob and blob
                    OPEN REF_COLNAME FOR v_clob_blob_strSQL;
                     LOOP
                      FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
                       EXIT WHEN REF_COLNAME%NOTFOUND;
    				     
                         -- for each blob and clob column will have to generate seprate insert statmenet
                         IF v_Data_Type='BLOB' THEN
                             v_clbl_string:=
                               '     INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
                               '      VALUES (v_ref_id, ''BLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
                               '		   			  												       ';
                         ELSIF v_Data_Type='CLOB' THEN
                             v_clbl_string:=
                               '     INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
                               '      VALUES (v_ref_id, ''CLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
                               '		   			  												       ';
                         END IF;	   
    					 
                            v_string := v_string||CHR(10)||v_clbl_string;
    				   		
                            v_Flagcnt:='TRUE';		
                     END LOOP;
    					
                    IF v_Flagcnt='TRUE' THEN
                        -- insert block for clob and blob data types	
                        v_sqlstr:=	
                           ' 	   																		' ||CHR(10)||					  			   
                           '   v_child :=''Y'';'			  					  	  			          ||CHR(10)||
                           '  		 																    ' ||CHR(10)||
                           '   IF INSERTING OR UPDATING THEN '										      ||CHR(10)||
                           '     '||v_string 	 		  	   											  ||CHR(10)||          
                           '     v_child :=''N'';'			  					  	  			          ||CHR(10)||
                           '   END IF;'			  					  	  			          		  	  ||CHR(10)||
                           '    ';
                        -- make string empty for next blob and clob variables	
                        v_string:='';	
    				
                    END IF;

                    -- final block for inserting into replication_data table	 						 
                    v_without_clob_blob_sqlstr:=
                        ' 	   																			'   ||CHR(10)||
                        '   INSERT INTO SRC_C_REPL.REPLICATION_DATA   '||CHR(10)||
                        '    VALUES (v_ref_id,SYSDATE,'''||v_tble_SchemaName||''','''||v_Table_Name||''',v_operation, v_pcols, v_pvals,v_cols,v_vals,nvl(v_child,''N''),0);'	||CHR(10)||
                        ' 	   																			'   ||CHR(10)||
                        ' END;																			'   ||CHR(10)||
                        '/';
                        
                        -- taken the variable for checking the length of the inserted record
                        --v_len_check:=LENGTH(v_SQL||v_insert_string||CHR(10)||v_without_clob_blob_sqlstr||CHR(10));
                       
    				
                    BEGIN 
                        -- flag is difine for clob and blob trigger creation script
                        -- if the flag is true then it means that the script is having
                        -- clob and blob insertion script                                                  
                        IF v_Flagcnt='TRUE'  THEN 
                                  
                          v_sql_insert_str1:= v_SQL||v_insert_string||CHR(10)||v_sqlstr||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                                  
                          INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                          COMMIT;
                          v_Flagcnt:='FLASE';
                        ELSE
                                
                          v_sql_insert_str1:= v_SQL||v_insert_string||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                                  
                          INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                          COMMIT;
                        END IF;
                    EXCEPTION
                      WHEN OTHERS THEN
                        v_errormsage := SUBSTR(SQLERRM,1,100);
                         NULL;
                    END;

                    v_Trigger_Count := v_Trigger_Count +1 ;
    				
                    --DBMS_OUTPUT.PUT_LINE('Trigger created. -- '||SUBSTR(v_Table_Name,1,24)||'_REPL');

                EXCEPTION
                    WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Trigger not created for table '||v_Table_Name||' error is '||SQLERRM);
                END;
                
                COMMIT;
                
                -- variable making empty
                v_sql_insert_str1:=NULL;
                
          ELSIF z.CHECK_CONSTRAINTS ='NOPK' THEN
    		
                  v_Table_Name       := NULL;
                  v_sql		         := NULL;
                  v_pcols 	         := NULL;
                  v_pvals 	         := NULL;
                  v_Cols  	         := NULL;
                  v_vals  	         := NULL;
                  v_clob_blob_strSQL := NULL;
                  v_clbl_string 	 := NULL;
                  v_string      	 := NULL;
    			  
                  v_Table_Name:=z.table_name;
    			  
                  IF v_msg= 105 THEN
                      EXECUTE IMMEDIATE 'INSERT INTO Z_TRIGGER_CREATION_TBL VALUES ('''||CHR(10)||'-- Trigger Script for those tables which are not having primary key '')'||CHR(10)||'';
                      --DBMS_OUTPUT.PUT_LINE(''||CHR(10)||'Trigger script for those tables which are not having primary key'||CHR(10));
                      v_msg:=106;			  
                  END IF;				
    			    			  								  
                    v_sqlString:= 
                      ' SELECT COLUMN_NAME, DATA_TYPE '||
                      ' FROM USER_TAB_COLUMNS utb     '||
                      ' WHERE column_name NOT IN(SELECT Column_Name '||
                      '  	     				 FROM USER_CONS_COLUMNS acc, USER_CONSTRAINTS ac '||
                      '		 				     WHERE acc.table_name = utb.table_name		  	 '|| 
                      '							   AND ACC.Constraint_Name = AC.Constraint_Name  '||
                      '		   				       AND AC.Constraint_Type  = ''P'')              '||
                      '   AND utb.table_name='''||v_Table_Name||'''';
     
                  EXECUTE IMMEDIATE v_sqlString;
    		  	  
                  v_Table_Name:=''||v_Table_Name||'';
    		  
                BEGIN
                     OPEN REF_COLNAME FOR v_sqlString;
                      LOOP
                       FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
                       EXIT WHEN REF_COLNAME%NOTFOUND;				  	  
    					  
                          v_cols := v_cols||'^~'||v_Col_Name;
    					  	  
                          IF v_Data_Type='DATE' THEN
                             v_vals  := v_vals ||'|| ''^~'' ||'||'''TO_DATE(''''''|| TO_CHAR (:NEW.'||v_Col_Name||', ''MMDDYYYY HH24MISS'')||'''''', ''''MMDDYYYY HH24MISS'''')''';
                          ELSIF v_Data_Type IN ('VARCHAR2','CHAR','NUMBER') THEN
                             v_vals := v_vals ||'|| ''^~'' ||'||' :NEW.'||v_Col_Name; 
                          END IF;			  
    					   
                      END LOOP;
    		  
                      v_vals := SUBSTR(v_vals,11); --,LENGTH(v_vals));
                     -----------------------------------------------------------------------------
    				 
                      v_sql := 'CREATE OR REPLACE TRIGGER '||SUBSTR(v_Table_Name,1,24)||'_REPL'           ||CHR(10)||
                      ' AFTER INSERT '															  		  ||CHR(10)||
                      ' ON '	   	  		 															  ||CHR(10)||
                      '	'||v_Table_Name																	  ||CHR(10)||
                      ' FOR EACH ROW '																	  ||CHR(10)||
                      ' DECLARE '	   																	  ||CHR(10)||
                      '      v_Ref_Id      	NUMBER; '													  ||CHR(10)||
                      '      v_Operation   	VARCHAR2(10); '												  ||CHR(10)||
                      '      v_pcols       	VARCHAR2(1000)	:= NULL; '									  ||CHR(10)||
                      '      v_pvals       	VARCHAR2(1000)	:= NULL; '									  ||CHR(10)||
                      '      v_Cols        	VARCHAR2(4000)	:= NULL; '									  ||CHR(10)||
                      '      v_vals        	VARCHAR2(4000)	:= NULL; '									  ||CHR(10)||
                      '      v_child        	VARCHAR2(2); '											  ||CHR(10)||
                      ' BEGIN '							   						   						  ||CHR(10)||
                      ' 	   																			' ||CHR(10)||
                      '   SELECT SRC_C_REPL.REPLICATION_SEQ.NEXTVAL INTO v_Ref_Id FROM Dual; '			  ||CHR(10)||
                      ' 	   																			' ||CHR(10)||
                      '   IF INSERTING THEN '															  ||CHR(10)||
                      '      v_operation := ''INSERT''; '												  ||CHR(10)||
                      '      v_cols      := '''||SUBSTR(v_Cols,3)||''';	'	   							  ||CHR(10)||
                      '      v_vals      := '||NVL(v_vals,'''''')||';        '										  ||CHR(10)||
                      '   END IF;';
    				
                    --- break for clob, blob, long raw insertion in SRC_C_REPL.REPLICATION_DATA_EX
    				
                    -- query will return only those column name which are having blob, clob datatype 				
                    v_clob_blob_strSQL := 'SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '''||v_Table_Name||''' AND DATA_TYPE IN(''BLOB'',''CLOB'')';
                    EXECUTE IMMEDIATE v_clob_blob_strSQL;
    				
                    -- start loop for clob and blob
                    OPEN REF_COLNAME FOR v_clob_blob_strSQL;
                     LOOP
                      FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
                       EXIT WHEN REF_COLNAME%NOTFOUND;
    				     
                         -- for each blob and clob column will have to generate seprate insert statmenet
                         IF v_Data_Type='BLOB' THEN
                             v_clbl_string:=
                               '   INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
                               '    VALUES (v_ref_id, ''BLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
                               '		   			  												       ';
                         ELSIF v_Data_Type='CLOB' THEN
                             v_clbl_string:=
                               '   INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
                               '    VALUES (v_ref_id, ''CLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
                               '		   			  												       ';
                         END IF;	   
    					 
                            v_string := v_string||CHR(10)||v_clbl_string;
    				   		
                            v_Flagcnt:='TRUE';		
                     END LOOP;

                    IF v_Flagcnt='TRUE' THEN
                        -- insert block for clob and blob data types	
                        v_sqlstr:=	
                           ' 	   														  				   ' ||CHR(10)||					  			   
                           '   v_child :=''Y'';'			  					  	  					     ||CHR(10)||
                           '  		 													  				   ' ||CHR(10)||
                           '   IF INSERTING OR UPDATING THEN '											     ||
                           '          '||v_string	 		  	   											 ||CHR(10)||          
                           '          v_child :=''N'';'														 ||
                           '   END IF;'			  					  	  			        				 ||CHR(10)||
                           '    ';

                       -- make string empty for next blob and clob variables	
                       v_string:='';	
                    END IF;

                    -- final block for inserting into replication_data table	 			
                    v_without_clob_blob_sqlstr:=
                        ' 	   															 				   ' ||CHR(10)||
                        '   INSERT INTO SRC_C_REPL.REPLICATION_DATA   '									   	 ||CHR(10)||
                        '    VALUES (v_ref_id,SYSDATE,'''||v_tble_SchemaName||''','''||v_Table_Name||''',v_operation, v_pcols, v_pvals,v_cols,v_vals,nvl(v_child,''N''),0);'	||CHR(10)||
                        ' 	   															 		   		   ' ||CHR(10)||
                        ' END;															 				   ' ||CHR(10)||
                        '/';
                        
                    BEGIN
                        -- flag is difine for clob and blob trigger creation script
                        IF v_Flagcnt='TRUE' THEN 
                           -- to avoid the inserting concatenation is too long error, inserting through the variable
                           v_sql_insert_str1:= v_SQL||CHR(10)||v_sqlstr||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                        
                           INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                           COMMIT;
                          v_Flagcnt:='FLASE';
                        ELSE
                           -- to avoid the inserting concatenation is too long error, inserting through the variable
                           v_sql_insert_str1:=v_SQL||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                        
                           INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                           COMMIT;
                        END IF;
                    EXCEPTION
                      WHEN OTHERS THEN
                          v_errormsage:= SUBSTR(SQLERRM,1,100);
                         DBMS_OUTPUT.PUT_LINE(v_errormsage);
                    END;

                    COMMIT;
                    
                     v_vals      := NULL;
                     v_Cols      := NULL;
    				  
                     v_Col_Name  := NULL;
                     v_Data_Type := NULL;
    					
                     v_Trigger_Count := v_Trigger_Count + 1;

                     --DBMS_OUTPUT.PUT_LINE('Trigger created. -- '||SUBSTR(v_Table_Name,1,24)||'_REPL');

                EXCEPTION
                  WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Trigger not created for table '||v_Table_Name||' error is '||SQLERRM);
                END;		 
          END IF;
          
          -- variable making empty
          v_sql_insert_str1:=NULL;
    
	END LOOP;

	COMMIT;

	v_Trigger_Count := v_Trigger_Count;

	-- list of all those tables which are having primary key to 
	-- all the columns in a table
	FOR i IN (SELECT Table_Name FROM USER_TABLES A
			  WHERE (SELECT COUNT(1) 
				     FROM USER_CONS_COLUMNS b,USER_CONSTRAINTS c 
				   	 WHERE A.Table_Name = b.Table_Name 
				       AND b.Constraint_Name = c.Constraint_Name 
					   AND c.Constraint_Type='P') = (SELECT COUNT(1) 
					 	 						     FROM USER_TAB_COLUMNS b 
												   	 WHERE A.Table_Name=b.Table_Name)
			  ORDER BY Table_Name ASC)
	LOOP
	   BEGIN
             v_Table_Name       := NULL;
             v_sql		        := NULL;
             v_pcols 	        := NULL;
             v_pvals 	        := NULL;
             v_Cols  	        := NULL;
             v_vals  	        := NULL;
             v_clob_blob_strSQL := NULL;
             v_clbl_string 	    := NULL;
             v_string      	    := NULL;

	         v_Table_Name:= i.Table_Name;
	   	    
              IF v_msg = 107 THEN
                  EXECUTE IMMEDIATE 'INSERT INTO Z_TRIGGER_CREATION_TBL VALUES ('''||CHR(10)||'-- Trigger Script for those tables which are having primary key to all the columns in a table.'')'||CHR(10)||'';
                  --DBMS_OUTPUT.PUT_LINE(''||CHR(10)||'TRIGGER SCRIPT FOR THOSE TABLE WHICH ARE HAVING PRIMARY KEY FOR ALL COLUMNS IN A TABLE '||CHR(10));
                  v_msg:=NULL;			  
              END IF;		  

			 -- query for those cloumns which are having primary key difined 
			 v_pk_columns:=
			  ' SELECT Column_Name '||
			  ' FROM USER_CONS_COLUMNS ACC, USER_CONSTRAINTS AC  '||
			  ' WHERE ACC.Constraint_Name = AC.Constraint_Name   '||
			  '   AND AC.Constraint_Type  = ''P''				   '||
			  '   AND ACC.Table_Name	  = '''||v_Table_Name||'''';

			 -- start loop for columns difined with primary key 
   			 OPEN REF_COLNAME FOR v_pk_columns;
		      LOOP
		       FETCH REF_COLNAME INTO v_prikeyCol_Name;
		        EXIT WHEN REF_COLNAME%NOTFOUND;

			     -- pk columns
				 IF v_pcols IS NOT NULL THEN
					 v_pcols := v_pcols ||'^~'||v_prikeyCol_Name;
				 ELSE
					 v_pcols := v_prikeyCol_Name;
				 END IF;

				 -- pk values
				 IF v_pvals IS NOT NULL THEN
					 v_pvals := v_pvals||'|| ''^~'' ||'||' :OLD.'||v_prikeyCol_Name;
				 ELSE
					 v_pvals := ':OLD.'||v_prikeyCol_Name;
				 END IF;
			  END LOOP;	 
		  
		     v_sqlstring := 'SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '''||v_Table_Name||'''';
		     EXECUTE IMMEDIATE v_sqlstring; 
		  
			 OPEN REF_COLNAME FOR v_sqlString;
			  LOOP
			   FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
			   EXIT WHEN REF_COLNAME%NOTFOUND;				  	  
				  
				  v_cols := v_cols||'^~'||v_Col_Name;
				  
				  IF v_Data_Type='DATE' THEN
				    v_vals  := v_vals ||'|| ''^~'' ||'||'''TO_DATE(''''''|| TO_CHAR (:NEW.'||v_Col_Name||', ''MMDDYYYY HH24MISS'')||'''''', ''''MMDDYYYY HH24MISS'''')''';
				  ELSE
				    IF v_Data_Type IN ('VARCHAR2','CHAR','NUMBER','DATE') THEN
				       v_vals := v_vals ||'|| ''^~'' ||'||' :NEW.'||v_Col_Name;
					END IF;
				  END IF;			  
				   
		      END LOOP;
	  
	  		  v_vals := SUBSTR(v_vals,11);--,LENGTH(v_vals));
			 -----------------------------------------------------------------------------
			 
			  v_sql := 'CREATE OR REPLACE TRIGGER '||SUBSTR(v_Table_Name,1,24)||'_REPL'         ||CHR(10)||
			  ' AFTER INSERT '																	||CHR(10)||
			  ' ON '	   	  		 															||CHR(10)||
			  '	'||v_Table_Name																	||CHR(10)||
			  ' FOR EACH ROW '																	||CHR(10)||
			  ' DECLARE '	   																	||CHR(10)||
			  '      v_Ref_Id      	NUMBER; '													||CHR(10)||
			  '      v_Operation   	VARCHAR2(10); '												||CHR(10)||
			  '      v_pcols       	VARCHAR2(1000)	:= NULL; '									||CHR(10)||
			  '      v_pvals       	VARCHAR2(1000)	:= NULL; '									||CHR(10)||
			  '      v_Cols        	VARCHAR2(4000)	:= NULL; '									||CHR(10)||
			  '      v_vals        	VARCHAR2(4000)	:= NULL; '									||CHR(10)||
			  '      v_child        VARCHAR2(2); '												||CHR(10)||
			  ' BEGIN '							   						   						||CHR(10)||
			  ' 	   																		'	||CHR(10)||
			  '   SELECT SRC_C_REPL.REPLICATION_SEQ.NEXTVAL INTO v_Ref_Id FROM Dual; '			||CHR(10)||
			  ' 	   																		'	||CHR(10)||
			  '   IF INSERTING THEN '															||CHR(10)||
			  '      v_operation := ''INSERT''; '												||CHR(10)||
			  '      v_pcols     := '''||v_pcols||'''; '										||CHR(10)||
			  '      v_pvals     := '||REPLACE(v_pvals,':OLD.',':NEW.')||'; '					||CHR(10)||
			  '      v_cols      := '''||SUBSTR(v_Cols,3)||''';	'	   							||CHR(10)||
			  '      v_vals      := '||NVL(v_vals,'''''')||';        '							||CHR(10)||
			  '   END IF;	';
			
			--- break for clob, blob, long raw insertion in SRC_C_REPL.REPLICATION_DATA_EX
			
			-- query will return only those column name which are having blob, clob datatype 				
	  	    v_clob_blob_strSQL := 'SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '''||v_Table_Name||''' AND DATA_TYPE IN(''BLOB'',''CLOB'')';
			EXECUTE IMMEDIATE v_clob_blob_strSQL;
			
			-- start loop for clob and blob
		    OPEN REF_COLNAME FOR v_clob_blob_strSQL;
		     LOOP
		      FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
		       EXIT WHEN REF_COLNAME%NOTFOUND;
			     
				 -- for each blob and clob column will have to generate seprate insert statmenet
				 IF v_Data_Type='BLOB' THEN
					 v_clbl_string:=
					   '   INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
					   '    VALUES (v_ref_id, ''BLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
					   '		   			  												       ';
				 ELSIF v_Data_Type='CLOB' THEN
					 v_clbl_string:=
					   '   INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
					   '    VALUES (v_ref_id, ''CLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
					   '		   			  												       ';
				 END IF;	   
				 
				    v_string := v_string||CHR(10)||v_clbl_string;
			   		
				  	v_Flagcnt:='TRUE';		
		     END LOOP;

			IF v_Flagcnt='TRUE' THEN
				-- insert block for clob and blob data types	
				v_sqlstr:=	
			       ' 	   									  ' ||CHR(10)||					  			   
				   '   v_child :=''Y'';'			  			||CHR(10)||
				   '  		 								  ' ||CHR(10)||
				   '   IF INSERTING OR UPDATING THEN '		    ||
				   '      '||v_string 	 		  	   		    ||CHR(10)||          
				   '      v_child :=''N'';'			  		    ||
				   '   END IF;'			  					    ||CHR(10)||
				   '    ';
			   -- make string empty for next blob and clob variables	
			   v_string:='';	
			END IF;

			-- final block for inserting into replication_data table	 	
			v_without_clob_blob_sqlstr:=
				' 	   										  ' ||CHR(10)||
				'   INSERT INTO SRC_C_REPL.REPLICATION_DATA   ' ||CHR(10)||
				'    VALUES (v_ref_id,SYSDATE,'''||v_tble_SchemaName||''','''||v_Table_Name||''',v_operation, v_pcols, v_pvals,v_cols,v_vals,nvl(v_child,''N''),0);'	||CHR(10)||
				' 	   										  ' ||CHR(10)||
				' END;										  ' ||CHR(10)||
				'/';
			
            BEGIN
                -- flag is difine for clob and blob trigger creation script
                IF v_Flagcnt='TRUE' THEN 
                
                   v_sql_insert_str1:= v_SQL||CHR(10)||v_sqlstr||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                
                  INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                  COMMIT;
                  v_Flagcnt:='FLASE';
                ELSE
                
                    v_sql_insert_str1:= v_SQL||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                
                  INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                  COMMIT;
                END IF;
            EXCEPTION
              WHEN OTHERS THEN
                  v_errormsage:= SUBSTR(SQLERRM,1,100);
                 DBMS_OUTPUT.PUT_LINE(v_errormsage);
            END;

            COMMIT;
            
			 v_vals      :=NULL;
			 v_Cols      :=NULL;
			 
			 v_Col_Name  :=NULL;
			 v_Data_Type :=NULL;		  
		  
	         v_Trigger_Count := v_Trigger_Count + 1;
		  	 
			 --DBMS_OUTPUT.PUT_LINE('Trigger created. -- '||SUBSTR(v_Table_Name,1,24)||'_REPL');

	   EXCEPTION
	     WHEN OTHERS THEN
		   DBMS_OUTPUT.PUT_LINE('Trigger not created for table '||v_Table_Name||' error is '||SQLERRM);
	   END;	
       
       v_sql_insert_str1 := NULL;
       
	END LOOP;

	COMMIT;
	
    
	o_Message := v_Trigger_Count;
	DBMS_OUTPUT.PUT_LINE('Total triggers created are - '||v_Trigger_Count);
EXCEPTION
	WHEN OTHERS THEN
		o_Message := 'ERROR NO '||TO_CHAR(v_ErrorFlag)||' '||SQLERRM;
END GENERATE_TRIGGER;
/
