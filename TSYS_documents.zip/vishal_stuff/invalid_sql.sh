#-- invalidate the SQL statement 
#-- to force the explain plan to 
#-- pick up the SQL Profile

sqlplus -s / as sysdba <<EOF
@invalid_sql.sql
exec purge_sql('2h07gm2pknbdy');
EXIT;
EOF

