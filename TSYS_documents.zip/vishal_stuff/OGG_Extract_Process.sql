--
--                   TSYS
--
-- 
-- DCE Extract Process Primary DB (PEPRE)
-- 
--
-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
--  CHECKPARAMS
--
-- Extracts all objects for all of the Schemas in the Source.
--
-- Set the runtime attributes for an Extract which reads
-- Oracle Redo/Archive logs for change data capture and stores
-- this data locally.

-- EXTRACT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (PEPRE.prm) must exist in the
-- dirprm directory/folder.
EXTRACT EPRE 

-- EXTTRAIL indentifies the local directory/folder and
-- file identifier where Extract will write its data. When the
-- file is created on disk, six digits are appended to the two
-- character identifier; starting with 000000. As the file reaches
-- maximum capacity a new file is created and Extract rolls to that
-- new file. A maximun of 999999 Extract Trail files may exist
-- per GoldenGate Extract.
EXTTRAIL /acfs/goldengate/dirdat/LB

-- This area is used for creating and monitoring environments
-- Must set environments
-- If you change servers you will need to change SID
-- IF fails, do a view report SEVICE-NAME to see env
SETENV (ORACLE_SID  = "transitr1")
SETENV (ORACLE_HOME = "/opt/app/oracle/product/11.2.0/dbhome_1")

-- Import Language Settings
-- SETENV (NLS_LANG="AMERICAN_AMERICA.US7ASCII")

-- The login credentials GoldenGate is to use to access the database.
USERID ggate, PASSWORD tsys123

-- TRANLOGOPTIONS EXCLUDEUSER GGATE COMPLETEARCHIVEDLOGTIMEOUT 600
TRANLOGOPTIONS DBLOGREADER

-- DDL Parameter
-- DDL INCLUDE MAPPED;
--DDL INCLUDE ALL, EXCLUDE OBJNAME "TRANSNOX_IOX.REPORT_USAGE_SEQ", EXCLUDE OBJNAME "TRANSNOX_IOX.CUSTOM_SEQ", &
--				 EXCLUDE OBJNAME TRANSNOX_IOX.SN_TEMP*, EXCLUDE OBJNAME SNOX4TRANSNOX.SN_TEMP*
DDL INCLUDE ALL

-- Add Trandata for DDL
DDLOPTIONS report, ADDTRANDATA

-- THREADOPTIONS PROCESSTHREADS SELECT 1
-- THREADOPTIONS PROCESSTHREADS SELECT 2

DBOPTIONS ALLOWUNUSEDCOLUMN
--DBOPTIONS ALLOWNOLOGGING

-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-------------------------------------------------------------------------------------
-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 00:01

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 00:01

-- REPORTCOUNT denotes that every 60 seconds the Extract report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE

-- End of "best practices" section
-------------------------------------------------------------------------------------

GETTRUNCATES

-- Sequence Parameter
-- and must be terminated with a semi-colon. Each table must be listed; however,
-- wildcards are allowed, with the * wildcard denoting all tables in the database.

-- List of Sequences
SEQUENCE TRANSNOX_IOX.REPORT_USAGE_SEQ;
SEQUENCE TRANSNOX_IOX.CUSTOM_SEQ;

-- List of Mother schemas
TABLE TRANSNOX_IOX.CUSTOM_REPORT;
TABLE TRANSNOX_IOX.REPORT_USAGE_AUDITTRAIL;

