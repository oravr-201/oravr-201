#!/bin/bash

mysql -u root -proot66 -h 192.168.231.66 dotproject > dotproject_bkup.sql

#dropping the two database dotproject and dotproject_test from 10.240.1.69
mysql -u root -proot69 -h 10.240.1.69 -e"drop database dotproject"
mysql -u root -proot69 -h 10.240.1.69 -e"drop database dotproject_test"

#creating the two database dotproject and dotproject_test on 10.240.1.69
mysql -u root -proot69 -h 10.240.1.69 -e"create database dotproject"
mysql -u root -proot69 -h 10.240.1.69 -e"create database dotproject_test"

#importing the latest backup script into both the databases on 10.240.1.69
mysql -u root -proot69 -h 10.240.1.69 dotproject < dotproject_bkup.sql

mysql -u root -proot69 -h 10.240.1.69 dotproject_test < dotproject_bkup.sql