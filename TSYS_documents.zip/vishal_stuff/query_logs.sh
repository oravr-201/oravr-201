#!/bin/sh
#
# Run as: oracle
# Query the log file info to see the status and member names.
#
# Written by: Tom Best

sqlplus / as sysdba <<-EOI
  column member format a45
  column status format a8
  shutdown immediate
  startup mount
  select member, vl.group#, vl.status, archived
    from v\$log vl, v\$logfile vlf
    where vl.group# = vlf.group#
    order by vl.group#;
exit
EOI
exit
