CREATE OR REPLACE PROCEDURE Monthly_Device_Counts
AS
    v_Connection            UTL_SMTP.Connection;
    v_reply                 UTL_SMTP.REPLY;

    Message                 VARCHAR2(4000);
    crlf                    VARCHAR2(2):=CHR(13)||CHR(10);

    v_Subject               VARCHAR2(100);
    v_html_BodyCode         VARCHAR2(1000);
    v_Body                  VARCHAR2(1000);

    v_Sender                VARCHAR2(100);
    v_Recipient             VARCHAR2(100);
    v_cc_recipt1            VARCHAR2(100);
    v_cc_recipt2            VARCHAR2(100);

    v_daily_date            VARCHAR2(100); -- for storing month and year. used in subject line

--    v_fromdate              VARCHAR2(100); -- for storing start date
--    v_todate                VARCHAR2(100); -- for storing end date
    v_data                  CLOB:= EMPTY_CLOB(); -- storing excel data
    v_len                    INTEGER;
    v_index                  INTEGER;
        
    v_Mime_Boundary CONSTANT VARCHAR2(256) := '-------SECBOUND';

    v_ErrorFlag             NUMBER;

    v_Total_91x_Machines    NUMBER;        -- used for counting total number of machine for 91x
    v_Total_NRT_Machines    NUMBER;        -- used for counting total number of machine for NRT
    v_Total_Hypc_Machines   NUMBER;        -- used for counting total number of machine for HyperCom
BEGIN
        v_ErrorFlag:=1;
        --- Last Month in format MONYYYY e.g.. AUG2012
        SELECT TO_CHAR(LAST_DAY(TRUNC(ADD_MONTHS(SYSDATE,-1),'mm')),'MONyyyy') INTO v_daily_date FROM dual;
        
        v_ErrorFlag:=2;
        -- Monthly count for 91x Devices
        SELECT COUNT (DISTINCT xtns.device_id) Devices_91x INTO v_Total_91x_Machines
        FROM Transnox_GCA.TRANSACTION xtns
        WHERE xtns.time_stamp BETWEEN TRUNC(ADD_MONTHS(SYSDATE,-1),'mm')
                                  AND TO_DATE(TO_CHAR(LAST_DAY(TRUNC(ADD_MONTHS(SYSDATE,-1),'mm')),'mm/dd/yyyy')||' 23:59:59','mm/dd/yyyy hh24:mi:ss')
          AND EXISTS (SELECT 1 FROM Snox4transnox_GCA.Device_Connectivity_Info dci
                      WHERE dci.DEVICE_ID = xtns.DEVICE_ID)
          AND REGEXP_LIKE (xtns.device_id,'^(X|N)','i'); --(xtns.Device_Id LIKE 'X%' OR xtns.Device_Id LIKE 'N%');          
          
        v_ErrorFlag:=3; 
        -- Monthly count for NRT Devices
        SELECT /*+ FIRST_ROWS*/COUNT (DISTINCT xtns.device_id) NRT_Devices  INTO v_Total_NRT_Machines
        FROM Transnox_GCA.TRANSACTION xtns
        WHERE xtns.time_stamp BETWEEN TRUNC(ADD_MONTHS(SYSDATE,-1),'mm')
                                  AND TO_DATE(TO_CHAR(LAST_DAY(TRUNC(ADD_MONTHS(SYSDATE,-1),'mm')),'mm/dd/yyyy')||' 23:59:59','mm/dd/yyyy hh24:mi:ss')
          AND REGEXP_LIKE(xtns.device_id,'^[N]','i')
          AND NOT EXISTS (SELECT 1
                          FROM Snox4transnox_GCA.Device_Connectivity_Info dci
                          WHERE dci.device_id = xtns.device_id );          
        
        v_ErrorFlag:=4;
        -- Query to get total transacting machines
          SELECT COUNT(DISTINCT device_id) HyperCom_Devices INTO v_Total_Hypc_Machines
          FROM transnox_gca.TRANSACTION
          WHERE REGEXP_LIKE(device_id,'79')
            AND LENGTH(device_id)=8
            AND time_stamp BETWEEN TRUNC(ADD_MONTHS(SYSDATE,-1),'mm')
                               AND TO_DATE(TO_CHAR(LAST_DAY(TRUNC(ADD_MONTHS(SYSDATE,-1),'mm')),'mm/dd/yyyy')||' 23:59:59','mm/dd/yyyy hh24:mi:ss');         

       v_ErrorFlag:=5;
        FOR i IN (SELECT pu.MERCHANT_ID||','||mo.DEVICE_ID||','||CORPORATION_ID||','||NAME||','||REPLACE(STREET1,',','')||','||CITY||','||STATE_CODE||','||COUNTRY_CODE col_list
                    FROM snox4transnox_gca.merchant pu, snox4transnox_gca.device mo
                   WHERE pu.country_code<>'MO'
                     AND pu.merchant_id = mo.merchant_id
                     AND pu.merchant_status='E'
                     AND mo.device_status='E')
        LOOP
            v_data:=v_data||CHR(10)||i.col_list;
        END LOOP;
       
       v_ErrorFlag:=6; 
        -- mail sender and recipient's entery
        v_Sender:='ifx-dbpune@tsys.com';
        v_Recipient:='rchaudhari@tsys.com'; --'ifx-inoc@tsys.com'; 
        v_cc_recipt2:='stujare@tsys.com'; --'ifx-dbdev@tsys.com';

        -- subject line for the mail
        v_Subject:='Device Count for '||v_daily_date;
        
        v_ErrorFlag:=7;
        v_connection := UTL_SMTP.open_connection('mail.infonox.com',25);
        UTL_SMTP.HELO(v_connection, 'mail.infonox.com');
        UTL_SMTP.MAIL(v_connection, v_Sender);
        UTL_SMTP.RCPT(v_connection, v_Recipient);
        UTL_SMTP.RCPT(v_connection, v_cc_recipt2);
        UTL_SMTP.OPEN_DATA(v_connection);

        UTL_SMTP.write_data(v_connection, 'From: ' || v_Sender || UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection, 'To: ' || v_Recipient || UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection, 'Cc: ' || v_cc_recipt2 || UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection, 'Subject: '|| v_Subject || UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection, 'MIME-Version: 1.0'|| UTL_TCP.crlf);

        UTL_SMTP.write_data (v_connection, 'Content-Type: multipart/mixed; boundary="' || v_Mime_Boundary || '"' || UTL_TCP.crlf);
        
        UTL_SMTP.write_data(v_connection, UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,'This is a multi-part message in MIME format.' || UTL_TCP.crlf);

        UTL_SMTP.write_data(v_connection, '--' || v_Mime_Boundary || UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection, 'Content-Type: text/plain; charset="us-ascii"' || UTL_TCP.crlf);

        UTL_SMTP.write_data(v_connection,'Hi All,'||UTL_TCP.crlf||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,CHR(32)||CHR(32)||'Here is the Device count for the Month of '||v_daily_date||UTL_TCP.crlf||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,CHR(32)||CHR(32)||CHR(32)||CHR(32)||'Devices Name'||CHR(32)||CHR(32)||CHR(32)||CHR(32)||'Total Machine Count'||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,CHR(32)||CHR(32)||CHR(32)||CHR(32)||'-----------------------------------'||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,CHR(32)||CHR(32)||CHR(32)||CHR(32)||CHR(32)||'91x         '||CHR(32)||CHR(32)||'--->'||CHR(32)||CHR(32)||v_Total_91x_Machines||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,CHR(32)||CHR(32)||CHR(32)||CHR(32)||CHR(32)||'NRT         '||CHR(32)||CHR(32)||'--->'||CHR(32)||CHR(32)||v_Total_NRT_Machines||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,CHR(32)||CHR(32)||CHR(32)||CHR(32)||CHR(32)||'HyperCom    '||CHR(32)||CHR(32)||'--->'||CHR(32)||CHR(32)||v_Total_Hypc_Machines||UTL_TCP.crlf||UTL_TCP.crlf||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,'Regards'||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,'-DB Team'||UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection,'-(automated email via DB process, Please do not reply to mail)'||UTL_TCP.crlf);
        
        UTL_SMTP.write_data(v_connection, '--' || v_Mime_Boundary || UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection, 'Content-Type: text/plain; charset="us-ascii"; name="'|| 'GCA_Macau_'||v_daily_date||'.csv"' || UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection, 'Content-Transfer_Encoding: 8bit' || UTL_TCP.crlf);    
        UTL_SMTP.write_data(v_connection,'Content-Disposition: attachment; filename="'|| 'GCA_Macau_'||v_daily_date||'.csv"' || UTL_TCP.crlf );
        UTL_SMTP.write_data(v_connection, 'MERCHANT_ID,DEVICE_ID,CORPORATION_ID,NAME,ADDRESS,CITY,STATE_CODE,COUNTRY_CODE');
        
        v_len := DBMS_LOB.getlength(v_data);
        v_index := 1;

        WHILE v_index <= v_len
        LOOP
            UTL_SMTP.write_data(v_connection, DBMS_LOB.SUBSTR(v_data, 32000, v_index));
            v_index := v_index + 32000;
        END LOOP;

        --
        -- End attachment
        UTL_SMTP.write_data(v_connection, UTL_TCP.crlf);
        UTL_SMTP.write_data(v_connection, '--' || v_Mime_Boundary || '--' || UTL_TCP.crlf);

        UTL_SMTP.CLOSE_DATA(v_connection);
        UTL_SMTP.QUIT(v_Connection);        
END Monthly_Device_Counts;
/