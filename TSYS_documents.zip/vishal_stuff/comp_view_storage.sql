REM For training only
--SELECT segment_name,sum(bytes)/1024/1024 MB
col segment_name format a40
set linesize 200

set timing off
SELECT segment_name,sum(bytes)/1024/1024 MB
  FROM user_segments
 WHERE segment_name in ('CUST_NOCOMP','CUST_HCC_QUERY','CUST_HCC_ARCHIVE')
 GROUP BY segment_name
 ORDER BY MB
/

set serveroutput on
declare
 nocomp_bytes number;
begin
 select bytes into nocomp_bytes
   from user_segments
  where segment_name = 'CUST_NOCOMP';

 dbms_output.put_line('STORAGE SAVINGS');
 dbms_output.put_line('--------------------------------------------');
 for rec in (select segment_name, nocomp_bytes/bytes compression_ratio
               from dba_segments
              where segment_name in ('CUST_HCC_QUERY','CUST_HCC_ARCHIVE')
            )
 loop
  dbms_output.put_line(rec.segment_name||': '||rec.compression_ratio||'X Savings.');
 end loop;
end;
/

select table_name,compression,compress_for
  from user_tables
 where table_name in ('CUST_NOCOMP','CUST_HCC_QUERY','CUST_HCC_ARCHIVE');
