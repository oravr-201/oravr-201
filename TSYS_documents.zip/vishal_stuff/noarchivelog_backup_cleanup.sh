rm -f /backup/*
