#!/bin/bash

#take a manual AWR snapshot

sqlplus -S sys/oracle as sysdba <<EOF
exec DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT();
exit
EOF
