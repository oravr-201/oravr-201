

select ANY_PATH
from RESOURCE_VIEW
where ANY_PATH LIKE '/sys/acls/dba%'


begin
    DBMS_NETWORK_ACL_ADMIN.CREATE_ACL (
    ACL => 'dba.xml', -- case sensitive
    DESCRIPTION=> 'Network Access Control for the DBAs',
    PRINCIPAL => 'RAHULC', -- user or role the privilege is granted or denied (upper case)
    IS_GRANT => TRUE, -- privilege is granted or denied
    PRIVILEGE => 'connect', -- or 'resolve' (case sensitive)
    START_DATE => null, -- when the access control entity ACE will be valid
    END_DATE => null); -- ACE expiration date (TIMESTAMP WITH TIMEZONE format)
end;
/



BEGIN
  DBMS_NETWORK_ACL_ADMIN.assign_acl (
    acl         => 'dba.xml',
    host        => 'MAIL.INFONOX.COM', 
	IS_GRANT => TRUE,
    PRIVILEGE => 'connect',
    START_DATE => null, -- if the time interval is defined,
    END_DATE => null    
    lower_port  => 25,
    upper_port  => 25); 
    commit;
end;
/

SELECT host, lower_port, upper_port, acl
FROM   dba_network_acls;


BEGIN
  DBMS_NETWORK_ACL_ADMIN.drop_acl (acl => 'dba1.xml');
  COMMIT;
END;
/

begin
 DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE 
  (
    ACL => 'dba.xml',
    PRINCIPAL => 'RAHULC',
    IS_GRANT => TRUE,
    PRIVILEGE => 'connect',
    START_DATE => null, -- if the time interval is defined,
    END_DATE => null
 ); -- the ACE will expire after the specified date range
end;
/

BEGIN
  DBMS_NETWORK_ACL_ADMIN.delete_privilege ( 
    acl         => 'dba1.xml', 
    principal   => 'RAHULC',
    is_grant    => TRUE, 
    privilege   => 'execute');

  COMMIT;
END;
/

SELECT acl,
       principal,
       privilege,
       is_grant,
       TO_CHAR(start_date, 'DD-MON-YYYY') AS start_date,
       TO_CHAR(end_date, 'DD-MON-YYYY') AS end_date
FROM   dba_network_acl_privileges;



grant execute on UTL_SMTP to public