


11.2.0.3 reconfigure OHAS (Oracle High Availability Services) services. (Single instance ASM)

To create a single-instance database 11gR2 based ASM, you first need to install the Grid Infrastructure software, you only need to install the software on the line, Bahrain ASM software we can create a volume group using ASMCA, ASMCMD other tools. Next, we installed stand-alone version of the database, When building a database to select ASM volume group on the line after the entire Bahrain, we can log in to the user under the Grid view is shown below.:

  [Grid @ asm ~] $ crsctl stat res -t
 -------------------------------------------------- ------------------------------
 NAME TARGET STATE SERVER STATE_DETAILS
 -------------------------------------------------- ------------------------------
 Local Resources
 -------------------------------------------------- ------------------------------
 ora.DATA.dg
                ONLINE ONLINE asm
 ora.LISTENER.lsnr
                ONLINE ONLINE asm
 ora.asm
                ONLINE ONLINE asm Started
 ora.ons
                ONLINE ONLINE asm
 -------------------------------------------------- ------------------------------
 Cluster Resources
 -------------------------------------------------- ------------------------------
 ora.cssd
       1 ONLINE ONLINE asm
 ora.diskmon
       1 OFFLINE OFFLINE
 ora.evmd
       1 ONLINE ONLINE asm
 ora.orcl.db
       1 ONLINE ONLINE asm Open 
You can see the following resource. Caveat here is ora.diskmon this resource, this resource under 11.2.0.3 non-Exadata environment, no longer needed. Because this process is responsible for Exadata I / O protection process. Then pick Under wrote about how to reconfigure after the OHAS deleted.

1 Stop OHAS service.

  [Grid @ asm ~] $ crsctl check has
 CRS-4638: Oracle High Availability Services is online
 [Grid @ asm ~] $ crsctl stop has
 CRS-2791: Starting shutdown of Oracle High Availability Services-managed resources on 'asm'
 CRS-2673: Attempting to stop 'ora.orcl.db' on 'asm'
 CRS-2673: Attempting to stop 'ora.LISTENER.lsnr' on 'asm'
 CRS-2677: Stop of 'ora.LISTENER.lsnr' on 'asm' succeeded
 CRS-2677: Stop of 'ora.orcl.db' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.DATA.dg' on 'asm'
 CRS-2677: Stop of 'ora.DATA.dg' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.asm' on 'asm'
 CRS-2677: Stop of 'ora.asm' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.cssd' on 'asm'
 CRS-2677: Stop of 'ora.cssd' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.ons' on 'asm'
 CRS-2673: Attempting to stop 'ora.evmd' on 'asm'
 CRS-2677: Stop of 'ora.ons' on 'asm' succeeded
 CRS-2677: Stop of 'ora.evmd' on 'asm' succeeded
 CRS-2793: Shutdown of Oracle High Availability Services-managed resources on 'asm' has completed
 CRS-4133: Oracle High Availability Services has been stopped.
 [Grid @ asm ~] $ crsctl check has
 CRS-4639: Could not contact Oracle High Availability Services 
Log in to the root user to remove OHAS configuration where we need to go on Grid users run $ ORACLE_HOME roothas.pl script.

  [Root @ asm ~] # /oracle/app/11.2.0/grid/crs/install/roothas.pl -deconfig -force
 Using configuration parameter file: /oracle/app/11.2.0/grid/crs/install/crsconfig_params
 CRS-4639: Could not contact Oracle High Availability Services
 CRS-4000: Command Stop failed, or completed with errors.
 CRS-4639: Could not contact Oracle High Availability Services
 CRS-4000: Command Delete failed, or completed with errors.
 CRS-4544: Unable to connect to OHAS
 CRS-4000: Command Stop failed, or completed with errors.
 Successfully deconfigured Oracle Restart stack 
3 Log on to the root user to run roothas.pl reconfigure Also the script is located in the Grid users $ ORACLE_HOME.

 [Grid @ asm ~] $ crsctl check has CRS-4047: No Oracle Clusterware components configured CRS-4000:. Command Check failed, or completed with errors [root @ asm ~] # cd /oracle/app/11.2.0/. grid / crs / install [root @ asm install] # id uid = 0 (root) gid = 0 (root) groups = 0 (root), 1 (bin), 2 (daemon), 3 (sys), 4 (adm ), 6 (disk), 10 (wheel) [root @ asm install] # ./roothas.pl Using configuration parameter file: ./crsconfig_params LOCAL ADD MODE Creating OCR keys for user 'grid', privgrp 'oinstall' .. Operation .. successful LOCAL ONLY MODE Successfully accumulated necessary OCR keys Creating OCR keys for user 'root', privgrp 'root' .. Operation successful CRS-4664:. Node asm successfully pinned Adding Clusterware entries to inittab asm 2012/03/15 04. : 47: 55 /oracle/app/11.2.0/grid/cdata/asm/backup_20120315_044755.olr Successfully configured Oracle Grid Infrastructure for a Standalone Server 
4 enter the Grid users to view resource under the state, the resource status is set to AUTOSTART

  [Grid @ asm ~] $ crsctl stat res -t
 -------------------------------------------------- ------------------------------
 NAME TARGET STATE SERVER STATE_DETAILS
 -------------------------------------------------- ------------------------------
 Local Resources
 -------------------------------------------------- ------------------------------
 ora.ons
                OFFLINE OFFLINE asm
 -------------------------------------------------- ------------------------------
 Cluster Resources
 -------------------------------------------------- ------------------------------
 ora.cssd
       1 OFFLINE OFFLINE
 ora.diskmon
       1 OFFLINE OFFLINE
 ora.evmd
       1 ONLINE ONLINE asm [/ java] 
Here you can see the resources we need to deal with in addition to ora.diskmon outside, ora.cssd and ora.ons are offine and we make the following modifications, so that these services can be started up automatically. [Java] [/ java] [grid @ asm ~] $ crsctl modify resource "ora.cssd" -attr "AUTO_START = 1" [grid @ asm ~] $ srvctl enable ons
Restart OHAS, query again, these services have automatically started.

  [Grid @ asm ~] $ crsctl stop has
 CRS-2791: Starting shutdown of Oracle High Availability Services-managed resources on 'asm'
 CRS-2673: Attempting to stop 'ora.evmd' on 'asm'
 CRS-2677: Stop of 'ora.evmd' on 'asm' succeeded
 CRS-2793: Shutdown of Oracle High Availability Services-managed resources on 'asm' has completed
 CRS-4133: Oracle High Availability Services has been stopped.
 [Grid @ asm ~] $ crsctl start has
 CRS-4123: Oracle High Availability Services has been started.
 [Grid @ asm ~] $ crsctl status res -t
 -------------------------------------------------- ------------------------------
 NAME TARGET STATE SERVER STATE_DETAILS
 -------------------------------------------------- ------------------------------
 Local Resources
 -------------------------------------------------- ------------------------------
 ora.ons
                ONLINE ONLINE asm
 -------------------------------------------------- ------------------------------
 Cluster Resources
 -------------------------------------------------- ------------------------------
 ora.cssd
       1 ONLINE ONLINE asm
 ora.diskmon
       1 OFFLINE OFFLINE
 ora.evmd
       1 ONLINE ONLINE asm 
5. Add ora.asm service. Provides management of asm instance. 
Here we need to find the spfile our asm instance, ASM instance is closed at this time, we have no way to see our spfile file storage location, same time our asmcmd command not available, I can only asm The alter log files to find the path to spfile stored.

  [Grid @ asm trace] $ pwd
 / Oracle / app / grid / diag / asm / + asm / + ASM / trace
 [Grid @ asm trace] $ cat alert_ + ASM.log | grep spfile
 Using parameter settings in server-side spfile + DATA / asm / asmparameterfile / registry.253.777951757
 Diskgroup with spfile: DATA 
Here I found the path of my spfile file, so I manually add asm resources.

  [Grid @ asm trace] $ srvctl add asm -p + DATA / asm / asmparameterfile / registry.253.777951757
 [Grid @ asm trace] $ srvctl start asm
 [Grid @ asm trace] $ crsctl status res -t
 -------------------------------------------------- ------------------------------
 NAME TARGET STATE SERVER STATE_DETAILS
 -------------------------------------------------- ------------------------------
 Local Resources
 -------------------------------------------------- ------------------------------
 ora.asm
                ONLINE ONLINE asm Started
 ora.ons
                ONLINE ONLINE asm
 -------------------------------------------------- ------------------------------
 Cluster Resources
 -------------------------------------------------- ------------------------------
 ora.cssd
       1 ONLINE ONLINE asm
 ora.diskmon
       1 OFFLINE OFFLINE
 ora.evmd
       1 ONLINE ONLINE asm

6 manually mount a volume group. 
At this point we can find resources ora.DATA.dg volume group does not exist, then we go with asmcmd command not see anything and we need to manually mount a volume group, then mount complete, it will automatically load the volume group resources .

  [Grid @ asm dbs] $ asmcmd
 ASMCMD> ls
 ASMCMD> exit
 [Grid @ asm dbs] $ sqlplus / as sysasm

 SQL * Plus: Release 11.2.0.3.0 Production on Thu Mar 15 05:38:47 2012

 Copyright (c) 1982, 2011, Oracle. All rights reserved.

 Connected to:
 Oracle Database 11g Enterprise Edition Release 11.2.0.3.0 - 64bit Production
 With the Automatic Storage Management option

 SQL> select name, state from v $ asm_diskgroup;
 NAME STATE
 ----------- --------------------
 DATA DISMOUNTED
 SQL> alter diskgroup data mount;
 Diskgroup altered.
 [Grid @ asm dbs] $ crsctl stop has
 CRS-2791: Starting shutdown of Oracle High Availability Services-managed resources on 'asm'
 CRS-2673: Attempting to stop 'ora.DATA.dg' on 'asm'
 CRS-2677: Stop of 'ora.DATA.dg' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.asm' on 'asm'
 CRS-2677: Stop of 'ora.asm' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.cssd' on 'asm'
 CRS-2677: Stop of 'ora.cssd' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.ons' on 'asm'
 CRS-2673: Attempting to stop 'ora.evmd' on 'asm'
 CRS-2677: Stop of 'ora.ons' on 'asm' succeeded
 CRS-2677: Stop of 'ora.evmd' on 'asm' succeeded
 CRS-2793: Shutdown of Oracle High Availability Services-managed resources on 'asm' has completed
 CRS-4133: Oracle High Availability Services has been stopped.
 [Grid @ asm dbs] $ crsctl start has
 CRS-4123: Oracle High Availability Services has been started.
 [Grid @ asm dbs] $ crsctl status res -t
 -------------------------------------------------- ------------------------------
 NAME TARGET STATE SERVER STATE_DETAILS
 -------------------------------------------------- ------------------------------
 Local Resources
 -------------------------------------------------- ------------------------------
 ora.DATA.dg
                ONLINE ONLINE asm
 ora.asm
                ONLINE ONLINE asm Started
 ora.ons
                ONLINE ONLINE asm
 -------------------------------------------------- ------------------------------
 Cluster Resources
 -------------------------------------------------- ------------------------------
 ora.cssd
       1 ONLINE ONLINE asm
 ora.diskmon
       1 OFFLINE OFFLINE
 ora.evmd
       1 ONLINE ONLINE asm 
7 added to the cluster database

Before adding, our primary database to find the spfile.

  [Grid @ asm ~] $ asmcmd
 ASMCMD> ls
 DATA /
 ASMCMD> cd DATA
 ASMCMD> ls
 ASM /
 ORCL /
 ASMCMD> cd ORCL
 ASMCMD> pwd
 + DATA / ORCL
 ASMCMD> ls -l spfileorcl.ora
 Type Redund Striped Time Sys Name
 N spfileorcl.ora => + DATA / ORCL / PARAMETERFILE / spfile.267.777943741 
Path is + DATA / ORCL / spfileorcl.ora, pay attention to the case here. Adding database users need to switch to the oracle runs below.

  [Root @ asm ~] # su - oracle
 [Oracle @ asm ~] $ srvctl add database -h
 Adds a database configuration to be managed by Oracle Restart.
 Usage: srvctl add database -d <db_unique_name> -o <oracle_home> [-m <domain_name>] [-p <spfile>] [-r {PRIMARY | PHYSICAL_STANDBY | LOGICAL_STANDBY | SNAPSHOT_STANDBY}] [-s <start_options>] [ -t <stop_options>] [-n <db_name>] [-i <inst_name>] [-y {AUTOMATIC | MANUAL | NORESTART}] [-a "<diskgroup_list>"]
 -d <db_unique_name> Unique name for the database
 -o <oracle_home> ORACLE_HOME path
 -m <domain> Domain for database. Must be set if database has DB_DOMAIN set.
 -p <spfile> Server parameter file path
 -r <role> Role of the database (primary, physical_standby, logical_standby, snapshot_standby)
 -s <start_options> Startup options for the database. Examples of startup options are OPEN, MOUNT, or 'READ ONLY'.
 -t <stop_options> Stop options for the database. Examples of shutdown options are NORMAL, TRANSACTIONAL, IMMEDIATE, or ABORT.
 -n <db_name> Database name (DB_NAME), if different from the unique name given by the -d option
 -i <inst_name> Instance name
 -y <dbpolicy> Management policy for the database (AUTOMATIC, MANUAL, or NORESTART)
 -a "<diskgroup_list>" Comma separated list of disk groups
 -h Print usage
 [Oracle @ asm ~] $ srvctl add database -d orcl -n orcl -o /oracle/app/oracle/product/11.2.0/db_1/ -p + DATA / ORCL / spfileorcl.ora -s OPEN -y AUTOMATIC - a "DATA" -t IMMEDIATE 
After the addition is complete, we can modify the properties so that the database follows the cluster automatically start.

  [Oracle @ asm ~] $ crsctl status res ora.orcl.db -p | grep AUTO_START
 AUTO_START = restore
 [Oracle @ asm ~] $ crsctl modify resource "ora.orcl.db" -attr "AUTO_START = 1" 
8 Add the listener. 
Here the user to switch to the grid below, and then add a listener.

  [Root @ asm ~] # su - grid
 [Grid @ asm ~] $ srvctl add listener -h
 Adds a listener configuration to be managed by Oracle Restart.
 Usage: srvctl add listener [-l <lsnr_name>] [-s] [-p "[TCP:] <port> [, ...] [/ IPC: <key>] [/ NMP: <pipe_name>] [ / TCPS: <s_port>] [/ SDP: <port>] "] [-o <oracle_home>]
 -l <lsnr_name> Listener name (default name is LISTENER)
 -o <oracle_home> ORACLE_HOME path (default value is CRS_HOME)
 -s Skip the checking of ports
 -p "[TCP:] <port> [, ...] [/ IPC: <key>] [/ NMP: <pipe_name>] [/ TCPS: <s_port>] [/ SDP: <port>]" Comma separated tcp ports or listener endpoints
 -h Print usage
 [Grid @ asm ~] $ srvctl add listener -l LISTENER -p TCP: 1521 -o /oracle/app/11.2.0/grid/ 
At this point, all resources have been added over. Could try to stop OHAS, then restart OHAS, check whether each resource starts normally.

  [Grid @ asm ~] $ crsctl stop has
 CRS-2791: Starting shutdown of Oracle High Availability Services-managed resources on 'asm'
 CRS-2673: Attempting to stop 'ora.DATA.dg' on 'asm'
 CRS-2677: Stop of 'ora.DATA.dg' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.asm' on 'asm'
 CRS-2677: Stop of 'ora.asm' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.cssd' on 'asm'
 CRS-2677: Stop of 'ora.cssd' on 'asm' succeeded
 CRS-2673: Attempting to stop 'ora.evmd' on 'asm'
 CRS-2673: Attempting to stop 'ora.ons' on 'asm'
 CRS-2677: Stop of 'ora.ons' on 'asm' succeeded
 CRS-2677: Stop of 'ora.evmd' on 'asm' succeeded
 CRS-2793: Shutdown of Oracle High Availability Services-managed resources on 'asm' has completed
 CRS-4133: Oracle High Availability Services has been stopped.
 [Grid @ asm ~] $ crsctl start has
 CRS-4123: Oracle High Availability Services has been started.
 [Grid @ asm ~] $ crsctl status res -t
 -------------------------------------------------- ------------------------------
 NAME TARGET STATE SERVER STATE_DETAILS
 -------------------------------------------------- ------------------------------
 Local Resources
 -------------------------------------------------- ------------------------------
 ora.DATA.dg
                ONLINE ONLINE asm
 ora.LISTENER.lsnr
                ONLINE ONLINE asm
 ora.asm
                ONLINE ONLINE asm Started
 ora.ons
                ONLINE ONLINE asm
 -------------------------------------------------- ------------------------------
 Cluster Resources
 -------------------------------------------------- ------------------------------
 ora.cssd
       1 ONLINE ONLINE asm
 ora.diskmon
       1 OFFLINE OFFLINE
 ora.evmd
       1 ONLINE ONLINE asm
 ora.orcl.db
       1 ONLINE ONLINE asm Open

Share to: QQ???????????? More 0
Post a Comment

You MUST be logged in to POST a comment.

� Start srvctl start database error database newspaper CRS-5010 solution
Installing Grid Control (10.2.0.3) ON Oracle Enterprise Linux 5.4 �
�Home

About This Post

Written by Buddy
March 16th, 2012 at 13:23
Categories

High Availability
Oracle
Tags

Interact

Post a comment
Trackback URI
RSS Feeds

Comments to this post
All posts
All comments
Search


blog.txt theme by Scott Allan Wallick