REM "******************************************* "
REM "For demo purposes ONLY:"
REM "  * Setup for Flashback Data Archive"
REM "Execute script as SYSDBA" 

CONNECT / AS SYSDBA

set echo on
set serveroutput on
-- set verify on
set term on
set lines 200
set pages 44
set pause on

/*== Create a tablespace for your flashback data archive ==*/
DROP TABLESPACE fla_tbs1 INCLUDING CONTENTS
/
CREATE SMALLFILE TABLESPACE fla_tbs1 
DATAFILE '$HOME/BACKUP/fla_tbs01.dbf' 
SIZE 10M REUSE AUTOEXTEND ON NEXT 640K MAXSIZE 32767M 
NOLOGGING EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO
/


pause Press [Enter] to continue...

/*== Create a second undo tablespace for testing ==*/

DROP TABLESPACE undotbs2 INCLUDING CONTENTS
/
CREATE SMALLFILE UNDO TABLESPACE undotbs2
DATAFILE '$HOME/BACKUP/undotbs02.dbf'
SIZE 105M REUSE AUTOEXTEND ON NEXT 5120K MAXSIZE 32767M
/
pause Press [Enter] to continue...

/*== Create an ARCHIVE_ADMIN user like the HR user ==*/
/*==   with FLA_TBS1 default tablespace ==*/
CREATE USER ARCHIVE_ADMIN PROFILE DEFAULT IDENTIFIED BY "oracle_4U"
DEFAULT TABLESPACE FLA_TBS1 TEMPORARY TABLESPACE TEMP
ACCOUNT UNLOCK;
pause Press [Enter] to continue...
GRANT ALTER SESSION TO ARCHIVE_ADMIN;
GRANT CREATE DATABASE LINK TO ARCHIVE_ADMIN;
GRANT CREATE SEQUENCE TO ARCHIVE_ADMIN;

GRANT CREATE SESSION TO ARCHIVE_ADMIN;
GRANT CREATE SYNONYM TO ARCHIVE_ADMIN;
GRANT CREATE VIEW TO ARCHIVE_ADMIN;
GRANT UNLIMITED TABLESPACE TO ARCHIVE_ADMIN;
GRANT EXECUTE ON SYS.DBMS_STATS TO ARCHIVE_ADMIN;
GRANT CONNECT, RESOURCE TO ARCHIVE_ADMIN;


/*== Setup for Flashback Data Archive completed ==*/
/*== The ARCHIVE_ADMIN user has the password: oracle_4U ==*/


pause Press [Enter] to continue...
exit
