#!/bin/sh
#
# Run as: oracle
# This creates the APPRAISAL tablespace.
#
# Written by: Mark Fuller
. oraenv << EOI
orcl
EOI
 
sqlplus -s / as sysdba << EOI2
  insert into hr.emp select * from hr.emp;
  commit;
  insert into hr.emp select * from hr.emp;
  commit;
  quit
EOI2
exit

