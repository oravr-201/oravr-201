CREATE OR REPLACE PROCEDURE Update_Device_Merchant
(
   i_NrOfStmts	  		 IN			NUMBER,
   i_Update_Type		 IN			VARCHAR2,
   i_DML_Statement		 IN 		VARCHAR2,
   i_Primary_Key		 IN			VARCHAR2,
   
   o_OutputStatus		 OUT 		NUMBER,
   o_OutputMessage		 OUT		VARCHAR2
)
AS
   v_ErrorFlag	  					NUMBER;
   
   v_Company_Code					VARCHAR2(50);
   v_Product_code					VARCHAR2(50); 
   v_Corporation_Id					VARCHAR2(50);
     
   v_Separator						CHAR(1) := ';';
   v_Element						NUMBER := 1;
   
   v_Sub_Separator					CHAR(1) := ',';
   v_Sub_Element					NUMBER;

   v_sql_string  				    VARCHAR2(4000);
   v_Stmt							VARCHAR2(4000);
   v_sqlstring  				    VARCHAR2(4000);
   					
BEGIN

   v_Stmt:=i_DML_Statement;
   
   IF UPPER(i_Update_Type)='INSERT' THEN
	    v_ErrorFlag:=1;
		v_Stmt:= SUBSTR(v_Stmt,(INSTR(v_Stmt,'values',1,1)+7));
		
		v_ErrorFlag:=2;
	    v_sql_string:= SUBSTR(v_Stmt,1,LENGTH(v_Stmt)-1);
	
	    v_sql_string:= REPLACE(v_sql_string, '''');
		
	    v_ErrorFlag:=3;
		Stringtokenizer(v_sql_string, v_Separator, v_Element, v_sqlstring);
		WHILE v_sql_string IS NOT NULL
		LOOP	
		
	      v_Sub_Element := 1;
		  Stringtokenizer(v_sqlstring, v_Sub_Separator, v_Sub_Element, v_Company_Code);
		   
	      v_Sub_Element := v_Sub_Element + 1;
	      Stringtokenizer(v_sqlstring, v_Sub_Separator, v_Sub_Element, v_Product_code);  
	
	      v_Sub_Element := v_Sub_Element + 1;
	      Stringtokenizer(v_sqlstring, v_Sub_Separator, v_Sub_Element, v_Corporation_Id);  
	
		  v_ErrorFlag:=4;		  
	      DELETE FROM COMPANY_PRODUCT_CORP_MAP 
		  WHERE CORPORATION_CODE = trim(v_Corporation_Id);

		  v_ErrorFlag:=5;
		  EXECUTE IMMEDIATE  i_DML_Statement;
		  
		  v_ErrorFlag:=6;	  
		  UPDATE DEVICE
		  SET PRODUCT_CODE = TRIM(v_Product_code)
		  WHERE DEVICE_ID='DUMMY_DEVICE'
		    AND MERCHANT_ID = 'DUMMY_MERCHANT';
		  				  
	  	  v_Element := v_Element + 1;
		  Stringtokenizer(i_DML_Statement, v_Separator, v_Element,v_sql_string);
		END LOOP ;
	ELSIF UPPER(i_Update_Type)='DELETE' THEN
	   EXECUTE IMMEDIATE i_DML_Statement;
	END IF;	

   o_Outputstatus  := 0;
   o_OutputMessage := 'SUCCESS';
	
EXCEPTION  
  WHEN OTHERS THEN
   o_Outputstatus  := -1;
   o_OutputMessage := 'Procedure Update_Device_Merchant failed at step no :=  '||v_ErrorFlag||' SQL ERROR :=  '||SUBSTR(SQLERRM,1,100);
END Update_Device_Merchant;
/