

Change the names of all processes as discussion in Meeting.

ADD MISSING SCHEMA TRANSTSYSPAYMENTGW and TRANSNOX_CAT in all the params files

DO NOT REPLICAT SN_TEMP<NUMBER>, so include the exclude statement

create a pfile to start process thr one file .oby over the DC


-- Processes on DCE Primary DB

--- CreateSource.oby file 

-- Extract Process on DCE Primary Database
ADD EXTRACT EPTE, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LA, EXTRACT EPTE, MEGABYTES 100

-- Pump Process for replicating data in DCE reporting database
ADD EXTRACT PPTERE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LA
ADD RMTTRAIL /acfs/goldengate/dirdat/EA, EXTRACT PPTERE, MEGABYTES 100

-- Pump Process for replicating data in DCW Primary database
ADD EXTRACT PPTETW, EXTTRAILSOURCE /acfs/goldengate/dirdat/LA
ADD RMTTRAIL /acfs/goldengate/dirdat/EB, EXTRACT PPTETW, MEGABYTES 100

-- Pump Process for replicating data in DCW reporting database
ADD EXTRACT PPTERW, EXTTRAILSOURCE /acfs/goldengate/dirdat/LA
ADD RMTTRAIL /acfs/goldengate/dirdat/EC, EXTRACT PPTERW, MEGABYTES 100


-- Replicating from DCW Primary DB to DCE Primary DB
ADD REPLICAT RPTETW, EXTTRAIL /acfs/goldengate/dirdat/WB

------------------------------------------------------------------------------------------------
-- Processes on DCE Reporting DB


--- CreateSource.oby file for On DCE Primary Database
ADD EXTRACT EPRE, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LB, EXTRACT EPRE, MEGABYTES 100

-- Pump Process for replicating data in DCW reporting database
ADD EXTRACT PPRERW, EXTTRAILSOURCE /acfs/goldengate/dirdat/LB
ADD RMTTRAIL /acfs/goldengate/dirdat/RA, EXTRACT PPRERW, MEGABYTES 100

-- Replicating from DCE Primary DB to DCE reporting DB
ADD REPLICAT RPRETE, EXTTRAIL /acfs/goldengate/dirdat/EA

-- Replicating from DCW Primary DB to DCE reporting DB
ADD REPLICAT RPRETW, EXTTRAIL /acfs/goldengate/dirdat/WC

-- Replicating from DCW Reporting DB to DCE reporting DB
ADD REPLICAT RPRERW, EXTTRAIL /acfs/goldengate/dirdat/WS


------------------------------------------------------------------------------------------------
-- Processes on DCW Primary DB

--- CreateSource.oby file for On DCW Primary Database
ADD EXTRACT EPTW, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LC, EXTRACT EPTW, MEGABYTES 100

-- Pump Process for replicating data in DCW reporting database
ADD EXTRACT PPTWRW, EXTTRAILSOURCE /acfs/goldengate/dirdat/LC
ADD RMTTRAIL /acfs/goldengate/dirdat/WA, EXTRACT PPTWRW, MEGABYTES 100

-- Pump Process for replicating data in DCE Primary database
ADD EXTRACT PPTWTE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LC
ADD RMTTRAIL /acfs/goldengate/dirdat/WB, EXTRACT PPTWTE, MEGABYTES 100

-- Pump Process for replicating data in DCE reporting database
ADD EXTRACT PPTWRE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LC
ADD RMTTRAIL /acfs/goldengate/dirdat/WC, EXTRACT PPTWRE, MEGABYTES 100

-- Replicating from DCE Primary DB to DCW Primary DB
ADD REPLICAT RPTWTE, EXTTRAIL /acfs/goldengate/dirdat/EB



------------------------------------------------------------------------------------------------
-- Processes on DCW Reporting DB

--- CreateSource.oby file for On DCE Primary Database
ADD EXTRACT EPRW, TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /acfs/goldengate/dirdat/LD, EXTRACT EPRW, MEGABYTES 100

-- Pump Process for replicating data in DCW reporting database
ADD EXTRACT PPRWRE, EXTTRAILSOURCE /acfs/goldengate/dirdat/LD
ADD RMTTRAIL /acfs/goldengate/dirdat/WS, EXTRACT PPRWRE, MEGABYTES 100

-- Replicating from DCW Primary DB to DCW reporting DB
ADD REPLICAT RPRWTW, EXTTRAIL /acfs/goldengate/dirdat/WA

-- Replicating from DCE Primary DB to DCW reporting DB
ADD REPLICAT RPRWTE, EXTTRAIL /acfs/goldengate/dirdat/EC

-- Replicating from DCE Reporting DB to DCW reporting DB
ADD REPLICAT RPRWRE, EXTTRAIL /acfs/goldengate/dirdat/RA













-- Configure param file for conflict resolution using the parameters.
-- This should be done in Replication params file
Map HR.EMPLOYEES, Target HR.EMPLOYEES, 
RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, USEMAX (DML_TIMESTAMP))), 
RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, USEMAX (DML_TIMESTAMP))), 
RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, OVERWRITE)), 
RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, OVERWRITE)), 
RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, DISCARD));
