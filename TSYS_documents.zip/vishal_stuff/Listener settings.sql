in tnsnames.ora paste these
DB1.ISPL.BAN.IN =
  (DESCRIPTION =
    (ADDRESS_LIST =
      (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.253.46)(PORT = 1521))
    )
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = subrato)
    )
  )
  
  -- just check the tnsname is working or not by utility 
  --  "tnsping <Tnsname_Host_Name>"


and in listener.ora paste these
DB1 =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS_LIST =
        (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.253.46)(PORT = 1521))
      )
    )
  )

Or 

GetDB.ISPL.BAN.IN =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS_LIST =
        (ADDRESS = (PROTOCOL = IPC)(KEY = EXTPROC))
      )
      (ADDRESS_LIST =
        (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.253.46)(PORT = 1521))
      )
    )
  )

SID_LIST_LISTENER =
  (SID_LIST =
    (SID_DESC =
      (SID_NAME = subrato)
        (PROGRAM = extproc)
    )
)



and in sqlnet.ora
    NAMES.DEFAULT_DOMAIN = ISPL.BAN.IN   
    
    SQLNET.AUTHENTICATION_SERVICES= (nts)
    
    NAMES.DIRECTORY_PATH= (TNSNAMES,hostname)


