-- Oracle Database 11gR2: Administration Workshop II
-- Server Technologies Curriculum
SELECT  sid, start_time, elapsed_seconds, time_remaining
  FROM  v$session_longops 
  WHERE sid = &sid_from_backup_output
  AND   time_remaining != 0
/
