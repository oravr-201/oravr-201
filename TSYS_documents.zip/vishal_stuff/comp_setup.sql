-- Oracle Server Technologies - Curriculum Development
-- *** For training only***

connect / as sysdba

/*== Drop and create a demo tablespace and user ==*/
set echo off
DROP USER compi CASCADE;
DROP TABLESPACE compi_tbs INCLUDING CONTENTS;

set echo on
CREATE SMALLFILE TABLESPACE COMPI_TBS 
   DATAFILE '+DATA' 
   SIZE 100M REUSE AUTOEXTEND ON NEXT 640K MAXSIZE 32767M NOLOGGING 
   EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

CREATE USER compi IDENTIFIED BY "oracle_4U" 
   DEFAULT TABLESPACE compi_tbs TEMPORARY TABLESPACE temp;

GRANT connect, resource, dba to compi;
GRANT ALL on sh.sales TO compi;

