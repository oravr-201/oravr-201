A 		Object code library
A 		Library file (Unix)
AA		Audible audio file (commonly used for downloadable audio books)
AAM 	Authorware shocked file
AAS 	Authorware shocked packet
AB  	Applix Builder file
ABF 	Adobe Binary Screen Font
ABK 	Backup file (PrintMaster Gold)
ABK 	Corel Draw AutoBackup
ABM 	Audio album file (HitPlayer)
ABO 	Applix Builder Turbo file
ABS 	MPEG Audio Sound file
ABS 	Standard GNU compiler output file for a PC platform
ABS 	Sometimes used to denote an abstract (as in an abstract or summary of a scientific paper) AutoBackup
ACA 	Project Manager Workbench file
ACA 	HTTP animation file (Microsoft Agent)
ACB 	ACBM Graphic image
ACC 	DR-DOS Viewmax file
ACD 	Character definiton file (Microsoft Agent)
ACE 	ACE Archiver Compression file
ACF 	HTTP character file (Microsoft Agent)
ACI 	ACI development appraisal (ACIWEB)
ACL 	Corel Draw 6 keyboard accelerator file
ACM 	Windows system directory file
ACM 	Interplay compressed sound file (Fallout 1,2, Baulder Gate)
ACM 	Dynamic Link Library (DLL)
ACP 	Microsoft Office Assistant Preview file
ACR 	American College of Radiology file
ACS 	Character structered storage file (Microsoft Agent)
ACT 	Microsoft Office Assistant Actor file
ACT 	FoxPro Foxdoc Action Diagram
ACT 	Action Presentation
ACT 	Documenting wizard action diagram (Microsoft Visual FoxPro)
ACV 	Used to Compress and decompress audio data
AD  	After Dark screensaver
Ada 	Ada source text file (non-GNAT)
ADB 	Ada source text body file (GNAT)
ADB 	HP 100LX Organizer Appointment database
ADC 	Scanstudio 16 color Bitmap Graphic file
ADD 	OS/2 adapter driver file used in the boot process
ADF 	Amiga disk file
ADI 	AutoCAD device-independent binary plotter file
ADL 	QEMM Mca adaptor description library
ADM 	After Dark MultiModule screensaver (Microsoft)
ADM 	Windows NT policy template
ADN 	Lotus 1-2-3 Add-In file
ADP 	Dynamic Page file (AOLserver)
ADP 	FaxWorks Faxmodem setup file
ADP 	Astound Dynamite file
ADR 	After Dark Randomizer screensaver
ADR 	Smart Address address book
ADS 	Ada source text specification file (GNAT)
ADT 	HP NewWave datafile for card applications
ADT 	AdTech Fax file
ADX 	Dynazip Active Delivery script
ADX 	Lotus Approach dBase Index
ADX 	Archetype Designer Document
ADZ 	Packed ADF file (Extracts with WinZip)
AE 		Author/Editor file (SoftQuad)
AEP  	ArcExplorer project file
AF2  	ABC FlowCharter 2.0 Flowchart
AF3  	ABC Flowchart
AFC  	Apple Sound file
AFI  	Truevision Bitmap graphic
AFM  	Adobe metrics
AFM  	HP NewWave Cardfile application
AG   	Applix graphic
AI   	Adobe Illustrator drawing
AI   	Corel Trace drawing
AIF  	Audio Interchange File, a sound format used by Silicon Graphics and Macintosh applications
AIFC 	Similar to AIF (compressed)
AIFF 	Similar to AIF
AIM 	AOL Instant Messenger Launch file
AIN 	AIN Compressed archive
AIO 	APL transfer file
AIS 	ACDSee Image Sequence
AIS 	Velvet Studio Instruments file
AIS 	Xerox Arry of Intensity Samples Graphic
AIX 	HP NewWave Cardfile Application data
AKW 	Contains all A-keywords in the RoboHELP Help Project Index Designer not associated with topics
ALAW 	European Telephony audio
ALIAS 	Alias Image
ALB 	JASC Image Commander album
ALI 	Document file (SAP proprietary format)
ALL 	Arts & Letters Library
ALL 	WordPerfect for Windows General printer information file
ALS 	Alias Image
ALT 	WordPerfect Library Menu
AM  	Applix SHELF Macro
AMF 	Music file (Advanced Module Format)
AMF 	DSMIA/Asylum module music (Crusader,No Remorse,Aladdin)
AMG 	AMGC Compressed archive
AMG 	ACTOR System image
AMI 	Annotation file (Cocreate SolidDesigner)
AMS 	Velvet Studio music module (MOD) file
AMS 	Extreme Tracker module
AN  	Text file (Sterling Software) (Groundworks COOL Business Team Model)
ANC 	Canon Computer Pattern Maker file that is a selectable list of pattern colors
ANI 	Microsoft Windows Animated cursor
ANM 	DeluxPaint Animation
ANN 	Windows 3.x Help annotation
ANS 	ANSI Text file
ANT 	SimAnt for Windows saved game
AOS 	Nokia 9000 Add-on software
AOT 	Applicatio binary object template file (ZenWorks snAPPshot)
AP  	Applix Presents file
AP 		WHAP Compressed Amiga archive
APC 	Compiled application file (Centura Team Developer)
APC 	Lotus 1-2-3 Printer driver
APD 	Dynamic application library file (Centura Team Developer)
APD 	Lotus 1-2-3 Printer driver
APF 	Lotus 1-2-3 Printer driver
APF 	Project file (Allaire) (Created by Homesite)
API 	Application Program Interface; used by Adobe Acrobat
API 	Lotus 1-2-3 Printer driver
APL 	Application library file (Centura Team Developer)
APL 	APL Workspace file
APP 	Normal mode application file (Centura Team Developer)
APP 	Symphony Add-in Application
APP 	Generated application or active document (Microsoft Visual FoxPro)
APP 	dBase Application Generator Object
APP 	DR-DOS Executable Application
APP 	FoxPro Generated Application
APR 	ArcView project file
APR 	Employee Appraiser Performance Review file
APR 	Lotus Approach 97 View file
APS 	Microsoft Visual C++ file
APS 	Advanced patching systems with error checking, (Similar to IPS)
APT 	Lotus Approach Data view file
APT 	Text mode application file (Centura Team Developer)
APX 	Lotus Approach Paradox-Specific information file
APX 	Borland C++ Appexpert database
AQ  	Applix data
ARC 	LH ARC (old version) compressed archive
ARC 	SQUASH Compressed archive
ARF 	Automatic Response file
ARI 	ARI Compressed archive
ARI 	Aristotle audio file
ARJ 	Robert Jung ARJ compressed archive (ARJ)
ARK 	ARC File Archiver CPM/Port archive
ARL 	AOL v4.0 organizer file
ARR 	Atari Cubase Arrangement
ART 	Xara Studio drawing
ART 	Canon Crayola art
ART 	Clip Art
ART 	Ray Tracer file
ART 	First Publisher Raster graphic
ART 	AOL Image file compressed using the Johson-Grace compression algorithm
ARX 	ARX Compressed Archive
AS  	Applix Spreadsheet
ASA 	Microsoft Visual InterDev file
ASC 	ASCII text file
ASC 	PGP armored encrypted file
ASD 	WinWord AutoSave file
ASD 	Lotus 1-2-3 Screen driver
ASD 	Microsoft Advanced Streaming Format (ASF) description file; opens with NSREX
ASD 	Astound Presentation
ASE 	Velvet Studio Sample file
ASF 	Music file (Electronic Arts)
ASF 	Microsoft Advanced Streaming Format
ASF 	StratGraphics Datafile
ASF 	Lotus 1-2-3 Screen font
ASH 	TASM 3.0 Assembly language header
ASI 	Borland C++/Turbo C Assembler Include file
ASM 	Assembler Language source file
ASM 	Pro/E assembly file
ASO 	Astound Dynamite Object
ASP 	Active Server Page (an HTML file containing a Microsoft server-processed script)
ASP 	Procomm Plus setup and connection script
ASP 	Astound Presentation
AST 	Astound multimedia file
AST 	Claris Works "assistant" file
ASV 	DataCAD Autosave file
ASX 	Cheyenne Backup script
ASX 	Microsoft Advanced Streaming Redirector file
ASX 	Video file
AT2 	Aldus Persuasion 2.0 Auto Template
ATM 	Adobe Type Manager data/info file
ATT 	AT&T Group 4 bitmap
ATW 	AnyTime Deluxe for Windows personal information manager file from Individual Software MultiModule screensaver
AU  	Sun/NeXT/DEC/UNIX sound file
AU  	Audio U-law (pronounced mu-law)
AUD 	Audio file (Westwood Studios) (Ky*****a 3,C&C,RedAlert,C&C:TS)
AUX 	TeX/LaTeX Auxilliary Reference file
AUX 	ChiWriter Auxilliary Dictionary file
AVA 	Avagio Publication
AVB 	Inculan Anti-Virus virus infected file
AVI 	Microsoft Audio Video Interleaved file for Windows movie
AVR 	Audio Visual Research file
AVS 	Application Visualization System file
AVS 	Stardent AVS-X Image
AVX 	File Extension (ArcView)
AW  	HP AdvanceWrite Text file
AW  	Applix Words file
AWD 	FaxView Document image
AWK 	AWK Script/Program
AWM 	Animation Works Movie
AWR 	Telsis file for digitally stored audio
AWS 	StatGraphics Data file
AXL 	ArcIMS XML project file
AXT 	ASCII application object template (ZenWorks snAPPshot)
AXX 	ARJ compressed file from a multi-volume archive (xx = a number from 01 to 99)
A3L 	Authorware 3.x library
A4L 	Authorware 4.x library
A5L 	Authorware 5.x library
A3M 	Authorware MacIntosh file (unpackaged)
A4M 	Authorware MacIntosh file (unpackaged)
A4P 	Authorware file (packaged without runtime)
A3W 	Authorware Windows file (unpackaged)
A4W 	Authorware Windows file (unpackaged)
A5W 	Authorware Windows file (unpackaged)

---------------------------------------------------------------------------------

B 		Applause Batch list
BAD 	Oracle bad file
BAK 	Backup file
BAL 	Ballade Music score
BAR 	dBase Application Generator Horizontal menu object
BAS 	BASIC source code
BAT 	Batch file
BB  	Papyrus Database backup
BBL 	TeX/BibTeX Bibliographic reference file
BBM 	Deluxe Paint Bitmap image
BBS 	Bulletin Board Sytem text
BCH 	Batch Process Object (dBase Application Generator)
BCH 	Datalex Entry Point 90 Data file
BCM 	Microsoft Works Communications file
BCO 	Bitstream Outline font description file
BCP 	Borland C++ Makefile
BCW 	Borland C++ 4.5 Environment settings file
BDB 	Microsoft Works Dababase file
BDF 	West Point Bridge Designer file
BDF 	Egret Datafile
BDR 	Microsoft Publisher Border
BEZ 	Bitstream Outline font description
BF2 	Bradford 2 Font
BFC 	Windows 95 Briefcase Document
BFM 	Font Metrics file (Unix/Mainframe)
BFX 	Fax document file (BitFax)
BG  	Microsoft Backgammon Game file
BGA 	OS/2 Graphic array
BGI 	Borland Graphics Interface Driver
BGL 	Microsoft Flight Simulator Scenery file
BHF 	pcAnywhere Host file
BI  	Binary file
BIB 	Bibliography file (ASCII)
BIB 	TeX/BibTeX Literature Database
BIB 	Database
BIF 	GroupWise initialization file
BIF 	Image Capture Board Binary Image black & white graphic
BIFF 	XLITE 3D file
BIN  	Binary file
BIO  	OS/2 Bios file
BIT  	X11 Bitmap
BK   	Backup file (Generic)
BK   	JetFax Faxbook file
BK$ 	Backup file (Generic)
BK! 	WordPerfect for Windows Document backup
BK1 	WordPerfect for Windows Timed backup file for document window 1
BK2 	WordPerfect for Windows Timed backup file for document window 2
BK3 	WordPerfect for Windows Timed backup file for document window 3
BK4 	WordPerfect for Windows Timed backup file for document window 4
BK5 	WordPerfect for Windows Timed backup file for document window 5
BK6 	WordPerfect for Windows Timed backup file for document window 6
BK7 	WordPerfect for Windows Timed backup file for document window 7
BK8 	WordPerfect for Windows Timed backup file for document window 8
BK9 	WordPerfect for Windows Timed backup file for document window 9
BKP 	TurboVidion Dialog Designer Backup
BKS 	IBM BookManager Read bookshelf file
BKS 	Microsoft Works Spreadsheet Backup
BKW 	FontEdit Fontset mirror image
BLB 	Resource archive (DreamWorks),(Neverhood)
BLD 	BASIC Bloadable picture file
BLK 	Alias Wavefront Image
BLK 	WordPerfect for Windows Temporary file
BM  	Windows system Bitmap
BMF 	Corel Gallery file
BMK 	Windows Help bookmark
BMP 	Windows or OS/2 bitmap
BM1 	Apogee BioMenace data
BN  	Instrument bank file (AdLib)
BNK 	Sound effects bank file (Electronic Arts)
BNK 	Instrument Bank file (AdLib)
BOL 	Compressed archive library file (Microsoft Booasm.arc)
BOM 	Bill of materials file (Orcad Schematic Capture)
BOO 	Microsoft Booasm.arc Compressed archive
BOOK 	Adobe FrameMaker Book
BOX 	Lotus Notes file
BPC 	Business Plan Toolkit Chart
BPL 	Borland Delphi 4 packed library
BPS 	Microsoft Works Document
BPT 	CorelDraw Bitmap fills file
BPX 	Truevision Targa Bitmap
BQY 	BrioQuery file
BR  	Bridge Script
BRD 	Eagle Layout file
BRK 	Brooktrout Fax-Mail file
BRW 	Application file associated with financial institution(s) loan applications
BRX 	A file for browsing an index of multimedia options
BRZ 	DbBRZ file for very large Db backup or restore
BSA 	BSARC Compressed archive
BSC 	Apple II Compressed archive
BSC 	Fortran Pwbrmake Object
BSC 	MS Developer Studio (MSDev) browser information
BSP 	Quake map file
BS1 	Apogee Blake Stone data file
BS_ 	Microsoft Bookshelf Find Menu shell extension
BTM 	Batch file used by Norton Utilities
BTR 	Database file (Btrieve 5.1)
BUD 	Backup disk for Quicken
BUG 	Bugs and Problems file
BUN 	CakeWalk Audio Bundle (a MIDI program)
BUP 	Backup
BUT 	Buttons! Button definition
BUY 	Movie data file
BV1 	WordPerfect for Windows Overflow file below insert point in document 1
BV2 	WordPerfect for Windows Overflow file below insert point in document 2
BV3 	WordPerfect for Windows Overflow file below insert point in document 3
BV4 	WordPerfect for Windows Overflow file below insert point in document 4
BV5 	WordPerfect for Windows Overflow file below insert point in document 5
BV6 	WordPerfect for Windows Overflow file below insert point in document 6
BV7 	Wordperfect for Windows Overflow file below insert point in document 7
BV8 	WordPerfect for Windows Overflow file below insert point in document 8
BV9 	WordPerfect for Windows Overflow file below insert point in document 9
BW 		SGI Black and White image file
BW 		Silicon Graphics Raw red,green and blue bytes file
BWB 	Visual Baler Spreadsheet application
BWR 	Kermit Beware buglist
BWV 	Business Wave file
BYU 	BYU Movie
BZ  Bzip compressed file (Inix)
BZ2 Bzip compressed file (Unix) (replaces Bz)
B1N 1st Reader Mono and color binary screen image
B30 ABC Ventura publisher printer font
B4 Helix Nuts and Bolts file
B8 Raw graphic file (Piclab Plane II)
B_W Atari/Macintosh black and white graphic
B&W Atari/Macintosh black and white graphic
B&W 1st Reader Mono binary screen image

------------------------------------------------------------------------------------

C C code
C Site configuration for Secure Remote (CheckPoint VPN)
CA Telnet Server Initial cache data file
CAB Microsoft cabinet file (program files compressed for software distribution)
CAC dBase IV Executable file
CAD Softdesk Drafix Cad file
CAG Catalog file (Microsoft Clip Gallery v. 2.x,3.x,4.x)
CAL CALS Compressed Bitmap
CAL SuperCalc 4/5 Spreadsheet
CAL Calendar schedule data file
CAM Casio camera file
CAN Navigator Fax
CAP Ventura Publisher Caption
CAP Compressed music file
CAP Telix Session Capture file
CAR AtHome assistant file
CAS Comma-delimited ASCII file
CAT Quicken IntelliCharge categorization file
CAT dBase Catalogue file
CB Microsoft clean boot file
CBC CubiCalc Fuzzy Logic System file
CBF Vietcong (game) Pterodon big file
CBI Column binary file (used in IBM mainframe systems)
CBL Cobol Source code
CBM XLib Compiled Bitmap
CBR Comic book or paperback RAR file (decompress with RAR utility)
CBT Generic Computer based training file
CBZ Comic book or paperback ZIP file (decompress with WinZip or similar program)
CC Visual dBASE custom class file
CC C++ Source code
CC3 Close Combat 3 file?
CCA cc:mail archive file
CCB Visual Basic Animated Button configuration file
CCC Curtain Call Native bitmap graphic
CCE Data file (Calendar Creator Plus)
CCF Multimedia Viewer configuration file used in OS/2
CCF Symphony Communications Configuration file
CCH Corel Chart
CCL Intalk Communication Command Language
CCM Lotus CC:Mail "box" file (for example, INBOX.CCM)
CCO CyberChat data file
CCO XBTX Graphics
CCT Macromedia Director Shockwave cast file
CDA CD Audio Track
CDB Clipboard file
CDB CardScan Database (CardScan)
CDB TCU Turbo C Utilities Main database
CDB Conceptual model backup file (PowerDesigner)
CDF Netcdf Graphic file
CDF Microsoft Channel Definition Format
CDFS Compact Disk filing system (WindRiver)
CDI Phillips Compact Disk Interactive file
CDK Atari Calamus Document
CDM Conceptual model file (PowerDesigner)
CDM Visual dBASE custom data module
CDM Conceptual data model file (PowerDesigner Data Architect) (Sybase)
CDR Corel Draw Vector drawing file
CDR Raw Audio-CD data file
CDT Corel Draw template
CDT CorelDraw Data file
CDX Corel Draw compressed drawing
CDX Microsoft Visual Foxpro index
CE The FarSide Computer Calendar Main CE file
CEF Cruzer encrypted file (used to secure files on Cruzer USB flash drives)
CEG Tempra Show Bitmap graphic
CEL CIMFast Event Language file
CEL AutoDesk Animator Cel Image
CER Certificate file (MIME x-x509-ca-cert)
CEX Caddie Exchange file
CF Imake Configurtion file
CFB Comptons Multimedia file
CFG Configuration file
CFL CorelFLOW Chart
CFM ColdFusion template
CFM Visual dBASE Windows customer form
CFM Corel FontMaster file
CFN Atari Calamus Font data file
CFO TCU Turbo C Utilities C form object
CFP The Complete Fax Portable fax file
CGA Ventura Publisher Display font file
CGI Common gateway interface script
CGM Computer Graphic Metafile
CH OS/2 configuration file
CH Clipper 5 Header
CH3 Harvard Graphics 3.0 Chart
CH4 Charisma 4.0 Presentation
CHD FontChameleon Font descriptor
CHF pcAnywhere remote control file
CHI ChiWriter Document
CHK File fragments saved by Windows Disk Defragmenter or ScanDisk
CHK WordPerfect for Windows Temporary file
CHL Configuration History Log
CHM Compiled HTML file
CHN Ethnograph Data file
CHP Ventura Publisher Chapter file
CHR Character Sets (Font file)
CHT ChartViewer file
CHT Harvard Graphics Vector file
CHT ChartMaster dBase Interface file
CIF CalTech Intermediate Graphic
CIF Easy CD Creator image
CIF pcAnywhere caller file
CIL Clip Gallery download package file
CIM Sim City 2000 file
CIN OS/2 change control file that tracks changes to an INI file
CIX TCU Turbo C Utilities Database Index
CK1 iD/Apogee Commander Keen 1 data
CK2 iD/Apogee Commander Keen 2 data
CK3 iD/Apogee Commander Keen 3 data
CK4 iD/Apogee Commander Keen 4 data
CK5 iD/Apogee Commander Keen 5 data
CK6 iD/Apogee Commander Keen 6 data
CKB Borland C++ Keyboard mapping file
CKF Casio Keyboard File
CL Generic LISP Source code
CL3 Layout file (Adaptec Easy CD Creator)
CLASS Java class
CLC TI-83 Plus Flash Debugger file
CLG Disk Catalog database
CLL Cricket Software Clicker File
CLO Cloe Image
CLP Windows Clipboard
CLP Quattro Pro Clip art
CLP Clipper 5 Compiler Script
CLR 1st Reader Binary color screen image
CLR PhotStyler Color defintion
CLS Visual Basic Class Module
CLS C++ Class Definition
CM Craftman Data
CMA Database file in plain text format (APPLIX TM1)
CMD Command file for Windows NT (similar to a DOS .BAT file), OS/2
CMD DOS CP/M command file
CMD dBase-II program file
CMD 1st Reader External Command Menu
CMF Corel Metafile
CFM Creative FM-Music
CMG Chessmaster saved game
CMK Card Shop Plus file
CMM CEnvi Batch file
CMP JPEG Bitmap
CMP Address document
CMP CorelDRAW 4.0 Postscript Printer Header
CMP Route 66 Address Document
CMP Microsoft Word for DOS User dictionary
CMR MediaPlayer Movie
CMV Corel Move animation
CMX Corel Presentation Exchange image
CMYK Raw cyan, magenta, yellow, and black bytes file
CNC CNC General Program data
CNF Configuration file used by Telnet, Windows, and other applications with varying internal formats
CNM Windows application menu options and setup file
CNQ Compuworks Design Shop file
CNT Windows (or other) system content files for the help index and other purposes
CNV Word for Windows Data conversion support file
CNV WordPerfect for Windows Temporary file
CNV Conversion files (WS_FTP Pro) files that will be converted from (Example) "HTML-"HTM" for upload
COB trueSpace 2 object
COB COBOL Source code
COD Microsoft C compiler output as displayable machine language/assembler with original C as comments
COD FORTRAN Compiled code
COD dBase Application Generator Template source file
COD Video Text file
COL AutoDesk Animator Color Palette
COL Microsoft Multiplan Spreadsheet
COM Command file (program)
CON Simdir Configuration file
CP CryptoPad.NET Encrypted document
CP8 CP8 256 Gray Scale image
CPD Corel PrintOffice file (drawing)
CPD Fax Cover document
CPD Complaints Desk Script
CPE Fax Cover document
CPF The Complete Fax (Fax file)
CPH Image file (Corel Print House) see CPO
CPI Microsoft MS-DOS code page information
CPI ColorLab Processed Image bitmap
CPJ CeQuadrant CD Project
CPL Control Panel Module
CPL Compel Presentation
CPL Corel color palette
CPM Turbo Pascal DOS file
CPO Image file (Corel Print Office)
CPP C++ Source code
CPP CA-Cricket Presents presentation
CPR Corel Presents presentation
CPS Central Point PC Tools Backup
CPS Coloured postscript
CPT Corel Photo-Paint image
CPT Macintosh Compressed Archive
CPT dBase Encrypted Memo
CPT CA-Cricket Presents Template
CPX Corel Presentation Exchange compressed drawing
CPY Data file (Copy Books)
CPZ COMPOZ Music Text
CRC Circular reference file (Pro/Engineer)
CRC Check file (Win-SFV32)(Fantasia Software)
CRD Microsoft Windows 3.x Cardfile
CRF Zortech C++ cross-reference
CRH Image file (Microsoft Golf)
CRP Corel Presents run-time presentation
CRP Visual dBASE custom report
CRP dBase IV Encrypted database
CRS WordPerfect 5.1 for Windows File Conversion resource
CRT Certificate file
CRT Oracle Terminal settings information
CRT Crontab file)
CRU CRUSH Compressed archive
CS1 Sinar CaptureShop raw file for Macintosh
CS4 Sinar CaptureShop raw file for Macintosh
CS16 Sinar CaptureShop raw file for Macintosh
CSA Comma deliminated text
CSC Corel script
CSG Statistica/w Graph file
CSH C shell script files (Hamilton Labs)
CSM Borland C++ 4.5 Precompiled header
CSM Script file (Kodak Dc265 Camera)
CSO Customer service data and outcome file
CSP PC Emcee On-Screen image
CSS Stats+ Datafile
CSS Statistica/w Datasheet
CSS vCascading Style Sheet (MIME)
CST Macromedia Director "Cast" (resource) file
CSV Comma-separated values file
CSV CompuShow Adjusted EGA/VGA Palette
CT Scitex CT bitmap
CT A graphic file associated with the Paint Shop Pro Graphic Editor
CTC PC Installer Control
CTF Symphony Character code translation
CTL Used in general for files containing control information. FAXWorks uses it to keep information about each fax sent and received.
CTL dBase IV Control
CTX Visual Basic User control binary file
CTX Pretty Good Privacy (PGP) Ciphertext file
CTX Microsoft Online Course Text
CUE Microsoft Cue Cards data
CUL Cursor library file (IconForge)
CUR Windows Cursor
CURSOR Sun Microsystems Cursor
CUT Dr Halo Bitmap
CV Corel Versions archive
CV Microsoft CodeView information screen
CVG Image
CVS Canvas drawing file
CWK Claris Works data
CWS Claris Works template
CXT Macromedia Director protected (not editable) "Cast" (resource) file
CXX C++ source code
C-- Sphinx C-- Source code
C00 Ventura Publisher Print file
C01 Typhoon wave
C86 Computer Innovation (C86) Source code

-------------------------------------------------------------------------------------------------------------


DAO Windows Registry Backup
DAP Data access page (Microsoft Access 2000)
DAT Data file
DAT A data file extension used to designate an error message in a inbound internet email message (Microsoft Exchange Server v 5.0)
DAT WordPerfect Merge Data
DAT Extension used for some MPEG files
DB Borderland Paradox 7 table database
DBC Microsoft Visual FoxPro database container file
DBF A dBASE file, a format originated by Ashton-Tate, but understood by Act!, Clipper,FoxPro, Arago, Wordtech, xBase, and similar database or database-related products.
DBF Enable database (can be opened with Excel 97)
DBF Oracle 8.1.x tablespace file
DBK dBase Database Backup
DBK Schematic backup file (Orcad Schematic Capture)
DBO Compiled program file (dBase IV)
DBQ Paradox Memo
DBS Managing Your Money data file
DBS Microsoft Word printer description file
DBS PRODAS data file
DBS SQL Windows database
DBT dBase Text Memo
DBV Memo field file (Flexfile 2)
DBW Microsoft Windows 9.x Database file (DataBoss)
DBX DataBeam image
DBX Outlook Express mail folder?
DBX Microsoft Visual FoxPro Table file
DC CAD file (DesignCAD)
DC2 CAD file (DesignCAD)
DCA Document Content Architecture Text file (IBM DisplayWrite)
DCA Visual Basic Active designer cache
DCF Disk Image file
DCF Data file (Dyadic)
DCIM Digital Imaging and Communications in Medicine (image and data)
DCM DCM module
DCP Data CodePage (OS/2)
DCR Shockwave file
DCS Desktop Color Separation file
DCS Bitmap Graphics (Quark XPress)
DCS Datafile (ACT! Activity file)
DCT Microsoft Visual FoxPro database container file
DCT Database Dictionary file (Clarion Database Developer)
DCT Database SpellCheck Dictionary (Harvard Graphics 3.0-Symphony)
DCU Delphi compiled unit
DCX Microsoft Visual FoxPro database container file
DCX Fax image (based on PCX)
DCX Macro file
DCX Bitmap Graphics file (Multipage PCX)
DC5 DataCAD Drawing
DD Compressed Archive (Macintosh DISKDOUBLER)
DDB Bitmap Graphics file
DDF Btrieve or Xtrieve Data Definition File, which contains metadata describing a Btrieve or Xtrieve file
DDI Image File (DISKDUPE)
DDIF Digital Equipment or Compaq file. Used for storing images and their word processing documents
DDP Device Driver Profile (OS/2)
DEB Debug Script (DOS Debug)
DEF SmartWare II data
DEF Define Module file (3-D Fassade Plus)
DEF C++ definition file
DEF Assembly Header file (Geoworks)
DEFI Oracle 7 de-install script
DEM Demo file (Descent)
DEM A file with USGS standards for Digital Elevation Models (Vista Pro)
DEM Graphics file (Vista Pro)
DEP Visual Basic Setup Wizard Dependency file
DER Certificate file
DEV Device Driver
DEWF Macintosh SoundCap/SoundEdit recorded instrument file
DEZ Encrypted zip file (DES Encryption)
DFD Data Flow Diagram Graphic (Prosa)
DFI Outline Font description (Digifont)
DFL Default Program Settings (Signature)
DFM Data Flow Diagram model (Prosa)
DFS Sound File (Delight)
DFV Printing Form value (Microsoft Word)
DGN Bentley Systems drawing file
DGN Microstation95 CAD drawing
DGS Diagnostics Report
DH Dependency Information file (Geoworks)
DHP Graphic file (Dr. Halo II-III PIC Format)
DHT Datafile (Gauss)
DIA Diagraph Graphics file (Computer Support Corporation)
DIB Device-independent bitmap
DIC Dictionary file
DIC Dictionary file (Lotus Notes, Domino)
DICM Digital imaging and communications in medicine file (DICOM)
DIF Data Interchange Format spreadsheet
DIF Database file (VisiCalc)
DIF Data Interchange Output file
DIF Text file (Output from Data Interchange Format)
DIG Digilink file
DIG Sound Designer I audio
DIP Graphics file
DIR Macromedia Director file
DIR Dialing Directory (ProComm Plus)
DIR Directory (VAX) (DEC)
DIR Movie (MacroMind Director 4.x)
DIS Ray Tracer file
DIS Distribution file (VAX Mail)
DIS Thesaurus file (CorelDraw)
DIZ Description file (Description in ZIP)
DJS Data Junction Integration map
DJS NASCAR Thunder game music file
DJVU DjVu compressed image file
DKB Graphics file (Ray Traced DKBTrace)
DL Image
DLD Datafile (Lotus 1-2-3)
DLG C++ Dialogue Script
DLL Dynamic-link library file
DLL Export/Import Filter (CorelDraw)
DLS Downloadable sound
DLS Interactive music architecture (IMA)(Microsoft),(Blood2)
DLS Setup file (Norton DiskLock)
DMD Visual dBASE data module
DMF Packed Amiga disk image
DMF X-Trakker music module (MOD)
DMG Macintosh disk image file (copy of contents of a hard disk or CD)
DMO Demo file (Derive)
DMP Dump file (Screen or Memory)
DMS Compressed Archive (Amiga DISKMASHER)
DOB Visual Basic User document
DOC FrameMaker or FrameBuilder document
DOC WordStar document
DOC WordPerfect document
DOC Microsoft Word document
DOC DisplayWrite document
DOC Document format (Interleaf)
DOG Screen Saver file (Laughing Dog Screen Saver)
DOH Dependency Information file (Geoworks)
DOS External Command file (1st Reader)
DOS Network Driver file (PKT_DIS.dos)
DOS Text file (DOS)
DOT Word Document Template (Microsoft Word for Windows)
DOT Line-Type definition (CorelDraw)
DOX User document binary form (Visual Basic)
DOX Text file (MultiMate 4.x)
DOZ Description out of Zip (VENDINFO)
DP Calendar file (Daily Planner)
DP Datafile (DataPhile)
DPL Borland Delphi 3 packed library
DPR Project header (Borland C++)
DPT Publication file (Publish-It!)
DRA Dragon NaturallySpeaking file
DRAW Acorn object-based vector image
DRC Design rules check report file (Orcad Schematic Capture)
DRS Display Resource file (WordPerfect for Windows)
DRV Driver
DRV Device Driver (Required to make a device function)
DRW Caddie CAD drawing
DRW Lotus Freelance image
DRW Micrografx vector graphics file
DRW Pro/E drawing
DS4 Micrografx Designer Image
DR9 Directory file
DS4 Vector Graphics (Micrografx)
DSC Discard file (Oracle)
DSD Database file (DataShaper)
DSF Micrografx Designer v7.x file
DSG DooM saved game
DSK Project Desktop file (Borland C++/Turbo Pascal)
DSK Driver file (Novell Netware)
DSM Dynamic Studio music module (MOD)
DSM Digital Sound Module (DSI)
DSM Music module file (DSIK)
DSN ODBC Data source
DSN Design (Object System Designer)
DSN Schematic file (Orcad Schematic Capture)
DSP Microsoft Developer Studio project
DSP Display parameters (Signature)
DSP Graphics Display driver Dr. Halo)
DSQ Corel QUERY
DSR Visual Basic Active designer file
DSR Driver Resource (WordPerfect for Windows)
DSS Screensaver file (DCC)
DSS Digital Sound file (Digital Soup))
DST Embroidery machines graphic file
DST Distribution file (PC-RDist, by Pyzzo)
DSW Desktop settings (Borland C++ 4.5)
DSW Microsoft Developer Studio workspace file
DSX Visual Basic Active designer binary file
DT_ Data file fork (Macintosh)
DTA World Bank STARS data
DTA Datafile (Turbo C++)
DTD SGML Document Type Definition (DTD) file
DTED Digital terrain elevation data (geographic data format)
DTF Database file (PFS-Questions & Answers)
DTF Symantec Q&A relational database
DTM Module file (DigiTrakker)
DTP Desktop layout file (SecurDesk!/SecurDesk! LV)
DTP Text Document (Timeworks Publisher 3.x)
DTP Template file (Pressworks)
DUN Microsoft Dial-up Networking Export file
DUP Duplicate Backup
DUS Readiris font dictionary
DV Digital video (MIME)
DVC Datafile (Lotus 1-2-3)
DVF Graphics file associated with camcorders (DV Studio)
DVI Binary file (TeX)
DVI Device Independent Document (TeX) (LaTeX)
DVP Desqview Program information (DESQview)
DVP Device parameter file (AutoCAD)
DW2 Drawing file (DesignCAD for Windows)
DWC Compressed Archive (DWC)
DWD DiamondWare digitized file
DWF Vector graphic (Autodesk)
DWF Drawing Web file (Microsoft WHIP autoCAD reader)
DWG AutoCAD Drawing
DWG AutoCAD drawing, or older Generic CAD drawing file
DWP Document file (DeScribe)
DWS Workspace file (Dyadic)
DX Digital Electric Corporation (DEC) Data exchange file
DXF Drawing Interchange (eXchange) format,a text representation of the binary DWG format
DXF Drawing Interchange Format (AutoCAD)
DXF Data Exchange File
DXN Fax document (Fujitsu dexNet)
DXR Macromedia Director protected (not editable) movie file
DYN Datafile (Lotus 1-2-3)
D2D 2D/3D object file (3-D Fassade Plus)
D64 Commodore 64 emulator disk image


----------------------------------------------------------------------------------------------------------


EBJ Error Checking Object file (Geoworks)
ED5 EDMICS image
ED6 EDMICS image
EDA Ensoniq ASR disk image
EDB ROOTS3 Geneological data file
EDE Ensoniq EPS disk image
EDD Element Definition document (FrameMaker+SGML documents)
EDK Ensoniq KT disk image
EDQ Ensoniq SQ1/SQ2/KS32 disk image
EDS Ensoniq SQ80 disk image
EDT Default settings (VAX Edt editor)
EDV Ensoniq VFX-SD disk image
EEB Button Bar for Equation editor (WordPerfect for Windows)
EFA Ensoniq ASR file
EFE Ensoniq EPS file
EFK Ensoniq KT file
EFQ Ensoniq SQ1/SQ2/KS32 file
EFS Ensoniq SQ80 file
EFT High Resolution Screen Font (ChiWriter)
EFV Ensoniq VFX-SD file
EFX Fax Document (Everex EFax)
EFX Fax document (Efax Reader)
EGA EGA Display font (Ventura Publisher)
EGM Bentley Systems drawing file
EL Lisp Source code (eMacs)
ELC eMac Lisp Source code (byte-compiled)
ELM Theme-Pack file for (Microsoft FrontPage)
ELT Event List Text file (Prosa)
EMAIL Microsoft Outlook Express mail message (save to desktop, scan for viruses, then convert to an EML file before opening)
EMB Embedded bank File (Everest)
EMD ABT Extended MoDule
EMF Enhanced Windows Metafile
EML Microsoft Outlook Express mail message (MIME RFC 822)
EMS Enhanced Menu System Configuration file (PC Tools)
EMU Terminal Emulation Data file (BITCOM)
EMZ Windows Compressed Enhanced Metafile, a graphic format used in Office and Visio
ENC Music file (Encore)
ENC Video file
ENC Encoded file (UUENCODEd File, Lotus 1-2-3)
END Arrow-Head Definition Table (CorelDraw)
ENFF Neutral Format
ENG Dictionary Engine file (Sprint)
ENG Chart Graphics file (EnerGraphics)
ENV Enveloper Macro (WOPR)
ENV Environment file (WordPerfect for Windows)
EPD Publication file (Express Publisher)
EPHTML Enhanced Perl-parsed HTML
EPI Document file (Express Publisher)
EPS Encapsulated Postscript Vector graphics (Adobe Illustrator)
EPS Printer font (Epson, Xerox, Ventura Publisher)
EPS2 Adobe Level II Encapsulated Postscript
EPS Encapsulated Postscript image file
EPSF Encapsulated PostScript
EPSI Adobe Encapsulated Postscript Interchange
EQN Equation file (WordPerfect for Windows)
ER1 ERWin file
ERD Entity Relationship Diagram graphic file (Prosa)
ERM Entity Relationship Diagram Model file (Prosa)
ERR Stores the error messages that result when the RoboHELP Help Compiler attempts to compile the source files of a Help system
ERR Compilation error file (Microsoft Visual FoxPro)
ERX ERWin file
ESH Extended Shell Batch file (DOS)
ESL Distributable support library file (Microsoft Visual FoxPro)
ESPS ESPS audio file
ESU ESRI Single Use License Information file
ETH Document file (Ethnograph 3.x)
ETX Structure Enhanced text (SetText)
EUI Ensoniq ESP family compacted disk image
EVT Event Log (Microsoft Windows NT, 2000)
EVY Document (WordPerfect for Windows Envoy)
EWD Text Document (Express Publisher for Windows)
EWL Microsoft Encarta document
EXT2 Second extended file system (Linux)
EXT3 Third extended file system (Linux)
EX3 Device Driver file (Harvard Graphics 3.x)
EXC Microsoft Word Exclusion Dictionary file
EXC Source Code file (Rexx VM/CMS)
EXC Exclude file for Optimize (do not process, QEMM)
EXE Executable file (program)
EXP Saved chat (ICQ)
EXT ASCII binary transfer file (WS_FTP PRO) (IPSWITCH Software)
EZP Compressed file (Edify.zip) (Edify Electronic Workforce Backup Utility)
E00 Coverage export file (ArcInfo)


------------------------------------------------------------------------------------------------------------

FORTRAN file
F Compressed file archive (FREEZE)
FAC Face graphic
FAQ Frequently Asked Questions document
FAR Music module (MOD) (Farandole Composer)
FAS Basic module file (3-D Fassade Plus)
FAV Navigation bar (Microsoft Outlook)
FAX FAX Type image
FBK Backup (Navison Financials)
FC Spell Check dictionary file (Harvard Graphics)
FCD Virtual CD-ROM file
FCM Binary file patch (Forward Compression)
FD Declaration file (FORTRAN)
FD Field offsets for compiler (DataFlex)
FDB Database (Navison Financials)
FDF Forms Document (Adobe Acrobat)
FDW Document form (F3 Design and Mapping)
FEB Button Bar for Figure Editor (WordPerfect for Windows)
FEM CADRE Finite Element Mesh
FF Outline Font description (AGFA CompuGraphics)
FFA MS find fast file
FFF Fax document (defFax)
FFF GUS PnP bank file
FFL MS fast find file
FFL Image file (PrintMaster Gold)
FFO MS fast find file
FFT Final Form Text (part of IBM DCA)
FFX MS fast find file
FH3 Aldus Freehand 3 drawing (Vector graphic)
FH4 Aldus Freehand 4 drawing (Vector graphic)
FH9 Macromedia Freehand 9 graphic file
FI File Interface (FORTRAN)
FIF Fractal Image
FIG REND386/AVRIL file
FIL File template (Application Generator)
FIL File List Object (dBase Application Generator)
FIL Overlay (WordPerfect for Windows)
FILE AS/400 physical file
FIN Print formatted text (Perfect Writer)
FIT Graphic (FITS)
FIT File index table (Microsoft Windows NT)
FITS CCD camera image
FITS Flexible Image Transport System file
FIX Patch file (Generic)
FKY Macro (Microsoft FoxPro)
FLA Movie (Macromedia Flash)
FLB Format library (Papyrus)
FLC FLIC animation (AutoDesk)
FLD File folder (Charisma)
FLD Field define module file (3-D Fassade Plus)
FLF Delived form (Corel Paradox)
FLF License (Navison Financials)
FLI FLIC animation (AutoDesk)
FLI Font library (EmTeX)
FLF Driver (OS/2)
FLL Distributable dynamic link library (DLL) (Microsoft Visual FoxPro)
FLM Film Roll (AutoCAD)
FLO FlowCharter file (MicroGrafx)
FLS Filelist document (Farrukh Imposition Publisher)
FLT Graphics filter (Microsoft)
FLT Filter (Corel)
FLT Filter (Micrografx Picture Publisher)
FLT Graphics filter support file (Asymetrix ToolBook)
FLT Music module (MOD) (StarTrekker)
FLT Open Flight file (MulitGen)
FLX Compiled binary file (DataFlex)
FM Spreadsheet (FileMaker Pro)
FM FrameMaker Document (Adobe)
FM1 Spreadsheet (Lotus 1-2-3, version 2.x)
FM3 Device driver (Harvard Graphics, version 3.0)
FM3 Spreadsheet (Lotus 1-2-3, version 3.x)
FMB Binary source code for form, (Oracle, v4.x and later)
FMB File Manager button bar (WordPerfect for Windows)
FMF Font or Icon (IBM LinkWay)
FMK MakeFile (FORTRAN PowerStation)
FML Mirror list (Oracle)
FMO Compiled format (dBase IV)
FMP Document file (FileMaker Pro)
FMT Text format for form file (Oracle, v4.x and later)
FMT Print file (Microsoft Schedule+)
FMT Style sheet (Sprint)
FMT Csreen format file (Microsoft Visual FoxPro)
FMX Executable form, (Oracle,v4.x and later)
FN3 Font (Harvard Graphics)
FNC Functions file in a neural network application
FNC Fixed neighbors constraint file in RMC++ application
FND Saved Search (Find applet) (Microsoft Explorer)
FNG Font group (Font Navigator)
FNK Module (FunkTracker)
FNT Font (Generic)
FNX Inactive font (Exact)
FO1 Font (Borland Turbo C)
FO2 Font (Borland Turbo C)
FOG Fontographer font
FOL Saved message folder (1st Reader)
FON Font (Generic)
FON Call log (Procomm Plus)
FON System font (Generic)
FON Dialing directory (Telix)
FOR FORTRAN source code
FOR Form (WindowBase)
FOT Font-related file (Generic)
FOT Installed TrueType font (Microsoft Windows Font Installer)
FP Configuration file (FoxPro)
FP FileMaker Pro file
FP1 "Flying Pigs" screensaver datafile (Microsoft Windows 9.x)
FP3 FileMaker Pro v.3 & 4 document file
FP5 Document file (FileMaker Pro v.5)
FPC Catalog file (FoxPro)
FPT FileMaker Pro file
FPT Memo fields (Microsoft FoxPro)
FPW Floorplan drawing (FloorPlan Plus for Windows)
FPX Bitmap (FlashPix)
FR3 Renamed dBaseIII+ form (dBase IV)
FRF Font (FontMonger)
FRG Uncompiled report (dBase IV)
FRK Zip (compressed ) file (Macintosh)
FRM Form (Generic)
FRM Document (FrameMaker or FrameBuilder)
FRM Executable file (Oracle,v3.0 and earlier)
FRM Form (Visual Basic)
FRM Merge form (WordPerfect for Windows)
FRM Symbol Report (DataCAD)
FRO Compiled report (dBase IV)
FRP Form (PerForm PRO Plus)
FRS Screen Font Resource (WordPerfect for Windows)
FRT Report menu (FoxPro)
FRX Form stash file (Visual Basic)
FRX Report (Microsoft FoxPro)
FSF fPrint Audit Tool
FSL Paradox 7 form (Borderland)
FSL Form (Paradox for Windows)
FSL Saved form (Corel Paradox)
FSM Sample file (Farandoyle)
FST Linkable program (dBFast)
FSX Data (Lotus 1-2-3)
FT Full text index (Lotus Notes)
FTB Index file (Roots3)
FTF Client access data specification file (AS/400) (Client to Server)
FTG Help system full-text search group file (Microsoft Windows)
FTM Font (MicroGrafx)
FTP File transfer protocol (Internet Generic)
FTS Help system full-text search index (Windows)
FTW Document file (Family Tree Maker)
FW Database (Framework II)
FW2 Database (Framework II)
FW3 Database (Framework III)
FW4 Database (Framework IV)
FWB Data file backup for file splitting configuration (FileWrangler)
FWP Microsoft FrontPage Web package (archive format for Web site content)
FWS Data file for file splitting configuration (FileWrangler)
FX On-Line guide (FastLynx)
FXD Phonebook (FAXit)
FXP Compiled source code (FoxPro)
FXS Fax Transmit graphic (WinFax)
FZB Bank dump file (Casio FZ-1)
FZF Full dump file (Casio FZ-1)
FZV Voice dump file (Casio FZ-1)
F01 Fax document (Perfect Fax)
F06 Dos screen text font (height= 6 pixels)
F07 Dos screen text font (height= 7 pixels)
F08 Dos screen text font (height= 8 pixels)
F09 Dos screen text font (height= 9 pixels)
F10 Dos screen text font (height= 10 pixels)
F11 Dos screen text font (height= 11 pixels)
F12 Dos screen text font (height= 12 pixels)
F13 Dos screen text font (height= 13 pixels)
F14 Dos screen text font (height= 14 pixels)
F15 Dos screen text font (height= 15 pixels)
F16 Dos screen text font (height= 16 pixels)
F2R Linear music module (Farandole)
F3R Blocked music module (Farandole)
F77 Source code file (FORTRAN 77)
F90 FORTRAN file
F96 Fax document (Frecom FAX96)


-----------------------------------------------------------------------------------------------------------

G Data chart (APPLAUSE)
GAL Album (Corel Multimedia Manager)
GAM Fax document (GammaFax)
GB Emulator ROM image file (Nintendo GameBoy)
GBC Color emulator ROM image file (Nintendo GameBoy)
GBL Global definitions (VAXTPU Editor)
GC1 Lisp source code (Golden Common Lisp 1.1)
GC3 Lisp source code (Golden Common Lisp 1.1)
GCD Generic (TM) CADD drawing (later versions)
GCP Image processing file (Ground Control Point)
GDB Database file (InterBase)
GDF Dictionary file (GEOS)
GDM Bells, whistles, and sound boards module
GED Genealogical data (GEDCOM)
GED Graphic Environment Document (drawing)
GED Graphics editor native format (Arts & Letters)
GED Graphics editor file (EnerGraphics)
GEM Metafile (GEM)
GEM Vector graphics (Ventura Publisher)
GEN Generated text (Ventura Publisher)
GEN Compiled template (dBase Application Generator)
GEO Geode (Geoworks)
GetRight Unfinished-Download (GetRight)
GFB Compressed gif image (GIFBLAST)
GFC Patton&Patton Flowcharting 4 flowchart
GFI Graphics Link presentation (Genigraphics)
GFT Font (NeoPaint)
GFX Genigraphics Graphics Link presentation
GHO Symantec ghost image file
GHS Symantec ghost segment file (automatically spanning files over 2 GB in size)
GIB Chart (Graph-in-the-Box)
GID Windows 95 global index (containing help status)
GIF Bitmap (CompuServe)
GIM Graphics Link presentation (Genigraphics)
GIW Presentation (Graph-in-the-Box for Windows)
GIX Graphics Link presentation (Genigraphics)
GKH Ensoniq EPS family disk image
GKS GripKey document (Gravis)
GL Animation file (GRASP graphical System for Presentation)
GBL Global file?
GBM Genie Backup Manager file
GLB Textured 3-D scene file format?
GLB Microsoft Exchange Server resynchronization file
GLM Datafile (Glim)
GLS Datafile (Across)
GLY Glossary (Microsoft Word)
GMF CGM Graphics (APPLAUSE)
GMP Tile map (Geomorph) (SPX)
GMR Graphical monitor record (Schlafhorst Automation)
GNA Graphics Link presentation (Genigraphics)
GNO Genealogy document file (Genopro)
GNT Generated executable code (Micro Focus)
GNX Graphics Link presentation (Genigraphics)
GOC Goc sorce code (Geoworks)
GOH Goc header (Geoworks)
GP Geode parameter file (Geoworks Glue)
GPH Graph (Lotus 1-2-3/G)
GPK Program package (Omnigo)
GPP Graph paper application file (GraphPap) (Generates graph paper)
GR2 Screen driver (Microsoft Windows 3.x)
GRA Graph (Microsoft)
GRA Datafile (SigmaPlot)
GRB Shell Monitor (MS-DOS v5.0)
GRD Image processing grid (CHIPS)
GRF Grapher (Golden Software) graph
GRF Graph (Charisma Graph Plus)
GRP Program Manager Group (Microsoft)
GRP Pictures group (PixBase)
GRY Raw graphic (GREY)
GS1 Presentation (GraphShow)
GSD Vector graphic (Professional Draw)
GSM Audio stream Raw GSM (6.10 audio stream)
GSM Audio stream Raw byte aligned (GSM 6.10 audio stream)
GSM GSM w.o. header/VoiceGuide/RapidComm file (US Robotics voice modems)
GSM GSM w. header/QuickLink file (US Robotics voice modems)
GSP Sketch pad file (GeoMeter Sketch Pad)
GSP Zip file (Gnuzip) (Allows for output to html)
GSW Worksheet (GraphShow)
GTH Lotus Domino document manager file?
GTH IBM Gatherer file
GTK Music module (Graoumftracker) (old) (MOD)
GT2 Music module (Graoumftracker) (new) (MOD)
GUP Data (PopMail)
GVL RCL Software Gravel (astronomy simulator) file
GWI Novell GroupWise file?
GWP Greetings WorkShop (now Microsoft Picture It) file
GWX Graphics Link presentation (Genigraphics)
GWZ Graphics Link presentation (Genigraphics)
GXL Graphics library (Genus)
GZ Compressed file (Unix gzip)
G721 Raw CCITT G.721 //$bit ADPCM data
G723 Raw CCITT G.723 3 or 5bit ADPCM data
G8 Raw Graphics (one byte per pixel) Plane III (PicLab)

G Data chart (APPLAUSE)
GAL Album (Corel Multimedia Manager)
GAM Fax document (GammaFax)
GB Emulator ROM image file (Nintendo GameBoy)
GBC Color emulator ROM image file (Nintendo GameBoy)
GBL Global definitions (VAXTPU Editor)
GC1 Lisp source code (Golden Common Lisp 1.1)
GC3 Lisp source code (Golden Common Lisp 1.1)
GCD Generic (TM) CADD drawing (later versions)
GCP Image processing file (Ground Control Point)
GDB Database file (InterBase)
GDF Dictionary file (GEOS)
GDM Bells, whistles, and sound boards module
GED Genealogical data (GEDCOM)
GED Graphic Environment Document (drawing)
GED Graphics editor native format (Arts & Letters)
GED Graphics editor file (EnerGraphics)
GEM Metafile (GEM)
GEM Vector graphics (Ventura Publisher)
GEN Generated text (Ventura Publisher)
GEN Compiled template (dBase Application Generator)
GEO Geode (Geoworks)
GetRight Unfinished-Download (GetRight)
GFB Compressed gif image (GIFBLAST)
GFC Patton&Patton Flowcharting 4 flowchart
GFI Graphics Link presentation (Genigraphics)
GFT Font (NeoPaint)
GFX Genigraphics Graphics Link presentation
GHO Symantec ghost image file
GHS Symantec ghost segment file (automatically spanning files over 2 GB in size)
GIB Chart (Graph-in-the-Box)
GID Windows 95 global index (containing help status)
GIF Bitmap (CompuServe)
GIM Graphics Link presentation (Genigraphics)
GIW Presentation (Graph-in-the-Box for Windows)
GIX Graphics Link presentation (Genigraphics)
GKH Ensoniq EPS family disk image
GKS GripKey document (Gravis)
GL Animation file (GRASP graphical System for Presentation)
GBL Global file?
GBM Genie Backup Manager file
GLB Textured 3-D scene file format?
GLB Microsoft Exchange Server resynchronization file
GLM Datafile (Glim)
GLS Datafile (Across)
GLY Glossary (Microsoft Word)
GMF CGM Graphics (APPLAUSE)
GMP Tile map (Geomorph) (SPX)
GMR Graphical monitor record (Schlafhorst Automation)
GNA Graphics Link presentation (Genigraphics)
GNO Genealogy document file (Genopro)
GNT Generated executable code (Micro Focus)
GNX Graphics Link presentation (Genigraphics)
GOC Goc sorce code (Geoworks)
GOH Goc header (Geoworks)
GP Geode parameter file (Geoworks Glue)
GPH Graph (Lotus 1-2-3/G)
GPK Program package (Omnigo)
GPP Graph paper application file (GraphPap) (Generates graph paper)
GR2 Screen driver (Microsoft Windows 3.x)
GRA Graph (Microsoft)
GRA Datafile (SigmaPlot)
GRB Shell Monitor (MS-DOS v5.0)
GRD Image processing grid (CHIPS)
GRF Grapher (Golden Software) graph
GRF Graph (Charisma Graph Plus)
GRP Program Manager Group (Microsoft)
GRP Pictures group (PixBase)
GRY Raw graphic (GREY)
GS1 Presentation (GraphShow)
GSD Vector graphic (Professional Draw)
GSM Audio stream Raw GSM (6.10 audio stream)
GSM Audio stream Raw byte aligned (GSM 6.10 audio stream)
GSM GSM w.o. header/VoiceGuide/RapidComm file (US Robotics voice modems)
GSM GSM w. header/QuickLink file (US Robotics voice modems)
GSP Sketch pad file (GeoMeter Sketch Pad)
GSP Zip file (Gnuzip) (Allows for output to html)
GSW Worksheet (GraphShow)
GTH Lotus Domino document manager file?
GTH IBM Gatherer file
GTK Music module (Graoumftracker) (old) (MOD)
GT2 Music module (Graoumftracker) (new) (MOD)
GUP Data (PopMail)
GVL RCL Software Gravel (astronomy simulator) file
GWI Novell GroupWise file?
GWP Greetings WorkShop (now Microsoft Picture It) file
GWX Graphics Link presentation (Genigraphics)
GWZ Graphics Link presentation (Genigraphics)
GXL Graphics library (Genus)
GZ Compressed file (Unix gzip)
G721 Raw CCITT G.721 //$bit ADPCM data
G723 Raw CCITT G.723 3 or 5bit ADPCM data
G8 Raw Graphics (one byte per pixel) Plane III (PicLab)


----------------------------------------------------------------------------------------------------------


Program header (C)
HA Compressed archive (HA)
HAM Driver file (Novell Netware)
HAM Vector graphics saved file (Amiga)
HAP Compressed archive (HA)
HBI Handy Backup file
HBK Handbook (MathCad)
HBK Accounting data file (Humanic Software)
HCM Configuration file (IBM HCM)
HCOM Sound Tools file (HCOM)
HCR Production configuration file (IBM HCD/HCM)
HDF National Center for Supercomputing Applications (NCSA) Geospatial Hierarchical Data
HDF Help file (Help development kit)
HDL Alternate download listing (ProComm Plus)
HDR Database header (Pc-File+)
HDR Datafile (Egret)
HDR Message header text (ProComm Plus)
HDR Message header text (1st Reader)
HDW Vector graphics (Harvard Draw)
HDX Help index (AutoCAD)
HDX Help index (Zortech C++)
HED Document (HighEdit)
HEL Hellbender saved game (Microsoft)
HEX Macintosh BinHex 2.0 file
HFI HP font info (GEM)
HGL Drawing file (HP Graphics Language)
HH Help system map (Generic)
HH Header file (C++)
HHH Precompiled header (Power C)
HHP Help information for remote users (ProComm Plus)
HIT Audio file (HitPlayer)
HLB Help library (VAX)
HLP Help file (Generic)
HLP Windows Help file (DataCAD)
HMI Human machine interfaces MIDI music file (Descent)
HMM Alternate mail read option menu (ProComm Plus)
HMP Human machine interfaces MIDI music file (Descent)
HNC Program files (CNC)
HOG Lucas Arts Dark Forces WAD file
HOG Mission file (Descent 1-2)
HOG Main data package file (Descent3)
HOT Document file (HotSend)
HP8 Ascii text Roman8 character set (NewWave Write)
HPC Font language file (Hewlett-Packard)
HPF HP LaserJet font (Adobe Pagemaker)
HPF Partial download file (HotLine)
HPG HPGL Plotter vector graphics (AutoCAD)
HPG HPGL Plotter vector graphics (Harvard Graphics)
HPI Font information (GEM)
HPJ Help Project file (Visual Basic)
HPK Compressed archive (HPACK)
HPM Emm text (HP NewWave)
HPM Alternative menu for privileged users (ProComm Plus)
HPP Program header (C++)
HPP Header file (Zortech C++)
HQX BinHex (Macintosh 4.0)
HRF Rastor graphic (Hitachi)
HRM Alternate menu for limited users (ProComm Plus)
HS2 Monochrome image (Postering)
HSC FM synthesized music file (Used by many old games, e.g.:FINTRIS, ROL)
HSI Graphic (Handmade Software, Inc.)
HST History file (Generic)
HST History file (ProComm Plus)
HT HyperTerminal file
HTA A HTML file that has been used to by viruses to update the system registry
HTM A Web page (a file containing Hypertext Markup Language - HTML - markup)
HTML A Web page (a file containing Hypertext Markup Language - HTML - markup)
HTT Hypertext template (Microsoft)
HTX Template (Extended HTML)
HWD Presentation (Hollywood)
HWP Korean word processor document format (HanGul)
HXM HAM extension (Descent2)
HXM Alternate protocal selection menu (ProComm Plus)
HXX Header file (C++)
HY1 Hyphenation algorythm (Ventura Publisher)
HY2 Hyphenation algorythm (Ventura Publisher)
HYC Datafile (WordPerfect for Windows)
HYD Hyphenation dictionary (WordPerfect for Windows)
HYM 3D Image binary file (Hymarc Scandata Scanner)
HYP Compressed archive (HYPER)
H! On-line Help (Flambeaux Help!)
H++ Header file (C++)
H-- Header file (Sphinx C--)


-----------------------------------------------------------------------------------------------------

Intermediate file (Borland C++)
IAN Text file (Sterling Software) (Groundworks COOL Business Team Model)
IAX Bitmap (IBM Image Acess eXecutive)
IBM Compressed archive (ARCHDOS, IBM Internal only)
ICA Citrix file
ICA Bitmap graphic (Image Object Content Architecture)
ICB Targa bitmap
ICC Printer file (Kodak)
ICC Catalog file (IronClad)
ICD Drawing file (IronClad)
ICL Icon Library (Generic industry standard)
ICM Image Color Matching profile
ICN Icon source code
ICO Icon (Microsoft Windows 3.x)
ICS Scene file (IronClad)
ID Disk identification file (Generic)
IDB Intermediate file (Microsoft Developer)
IDD MIDI Instrument Definition
IDE Project file (Borland C++ v4.5)
IDF MIDI Instrument Definition (Windows 95 required file)
IDIF Identification file (Netscape saved address book)
IDL OMG Interface Definition Language (IDL) file
IDW Vector graphic (IntelliDraw)
IDX Relational database index (Microsoft FoxPro)
IDX Relational database index (Symantec Q&A)
IDX Microsoft Outlook Express file
IDX Index file (Microsoft Clip Gallery v. 1.x)
IDX Index file (Pro/Engineer)
IFD Form (JetForm Design)
IFD Adobe Output Designer forms definition source file
IFF Interchange file, (general purpose data storage format))
IFF Image (Sun TAAC/SDSC Image Tool)
IFO Digital Video Disk (DVD) datafile
IFO Graphic object layer data (ImageForge Pro)
IFP Script file (KnowledgeMan)
IFS Compressed fractal image (Yuvpak)
IFS System file (OS/2)
IFS Create executable library (ImageForge/ImageForge Pro)
IGES Initial Graphics Exchange Specification (Generic)
IGF Metafile (Inset Systems)
IIF Interchange file (QuickBooks for Windows)
IIM Music module
ILB Datafile (Scream Tracker)
ILBM Bitmap (graphic image)
ILK Program outline (Microsoft ILink incremental linker)
IM8 Raster graphic (Sun Microsystems)
IMA Image (WinImage)
IMA Vector graphic (EGO,Chart)
IMF MIDI music file (Corridor 7, Blake Stone, Wolfenstein 3D, Spear of Destiny)
IMG Image (GEM)
IMG Bitmap graphic (Ventura Publisher)
IMP Spreadsheet (Lotus Improv)
IMQ Image presentation (ImageQ)
IMS Create executable library data (IconForge)
IN$ Installation file (HP NewWave)
IN3 Input device driver (Harvard Graphics v3.0)
INB Test script (Vermont High Test)
INC Include file (Assembler language or Active Server)
IND Index (dBase IV)
IND Shared Database file (Specifically in Microsoft Windows)
INDD Adobe InDesign document
INF Information file (Generic)
INF Type I LaserJet font information file
INF Install script (Generic)
INI Initialization file (Generic)
INI Setup file (MWave DSP synth mwsynth.ini GM)
INI Bank setup file (Gravis UltraSound)
INK Pantone reference fills file (CorelDRAW)
INL Inline function file (Microsoft Visual C++)
INP Source code for form, (Oracle,version 3.0 and earlier)
INRS INRS-Telecommunications audio
INS Inspiration file
INS Install script (InstallShield)
INS Sign-up file (X-Internet)
INS Instrument file (Ensoniq EPS Family)
INS Sample (Cell/II MAC/PC instruments)
INS Datafile (WordPerfect for Windows)
INS Installation script (1st Reader)
INS Instrument music file (Adlib)
INT Intermediate executable code (Produced when a source program is syntax-checked)
INT Interfaced units (Borland)
INX Index file (Foxbase)
IO Compressed archive (CPIO)
IOB 3D graphics database (TDDD format)
IOC Organizational chart (Instant ORGcharting!)
IOF Findit document (Microsoft Findit)
ION File description (4dos descript.ion)
IPL Pantone Spot reference pallette (CorelDRAW)
IPS International patching system binary patch file
IQY Internet inquiry (Microsoft)
ISO Lists the files on a CD-ROM; based on the ISO 9660 CD-ROM file system standard
IRS Resource file (WordPerfect for Windows)
ISD Spell checker dictionary (RapidFile)
ISH Compressed archive (ISH)
ISO ISO (International Standards Organization table, aka: ISO)
ISP Sign-up file(X-Internet)
IST Instrument file (Digitaltracker)
ISU Uninstall script (InstallShield)
IT Settings file (intalk)
ITF Interface file (JPI Pascal TopSpeed)
IT Music module (MOD) (Impulse Tracker)
ITI Instrument file (Impulse Tracker)
ITS Sample file (Impulse Tracker)
ITS Internet document set (possibly a Microsoft file)
IV Open Inventor file
IVD Microdata dimension or variable-level file (Beyond 20/20)
IVP User subset profile (Beyond 20/20)
IVT Table or aggregate data (Beyond 20/20)
IVX Microdata directory (Beyond 20/20)
IW Screensaver (Idlewild)
IW Presentation flowchart (IconAuthor-HSC Interactive)
IWA Text file (IBM Writing Assistant)
IWC Install Watch document
IWM Start file (IconAuthor)
IWP Text file (Wang)
IZT Binary token file (IZT)


------------------------------------------------------------------------------------------------------

J62 Ricoh camera format file
JAD Java Application Descriptor file
JAR Java ARchive (a compressed file containing a package of Java application-related files)
JAS Graphic (Generic)
JAVA Source code (Java)
JBD Datafile (SigmaScan)
JBF Image browser file (Paint Shop Pro)
JBX Project file (Project Scheduler 4.0)
JCP Java Community Process file?
JCW Java Callable Wrapper file?
JDF Job Description File (proposed XML-based standard for end-to-end job ticket specification)
JFF JPEG image
JIF JPEG image
JFIF JPEG image
JMG Laservision projection graphics file
JMP Discovery chart-to-statistics (SAS JMP)
JN1 Jill of the Jungle data (Epic MegaGames)
JNB Workbook file (Sigma Plot 5)
JOB Vector graphics file created by conversion of a IMG file (QuestVision)
JOR Journal (Microsoft SQL Server)
JOU Journal backup (VAX Edt editor)
JPC Graphic (Japan PIC)
JPE JPEG image
JPEG JPEG compressed bitmap
JPG JPEG bitmap
JPG2 JPEG 2000 image (bitmap) file
JS JavaScript source code
JSD Jet Suite document (eFAX)
JSP A HTML page containing a reference to a Java servlet
JTF JPEG bitmap
JTF Fax document (Hayes JT Fax)
JTF Bitmap graphic (JPEG Tagged Interchange Format)
JTK Java ToolKit file (Sun Microsystems)
JW Text document (JustWrite)
JWL Library (JustWrite)
JZZ Spreadsheet (Jazz)

K25 Sample file (Kurzweil 2500)
KAR MIDI file (text+MIDI) (Karaoke)
KB Keyboard script (Borland C++ 4.5)
KB Program source code (Knowledge Pro)
KBD Keyboard mapping script (Procomm Plus, LocoScript, Signature)
KBM Keyboard mapping script (Reflection 4.0)
KCL Lisp source code (Kyoto Common Lisp)
KDC Image (Kodak Photo-Enhancer)
KEX Macro (KEDIT)
KEY Icon toolbar (DataCAD)
KEY Datafile (Forecast Pro)
KEY Keyboard Macro
KEY Security file (Such as a software registration number)
KFX Image (KoFax Group 4)
KIZ Digital postcard (Kodak)
KKW Contains all K-keywords in the RoboHELP Help project Index Designer not associated with topics
KMP KeyMaP (Korg Trinity)
KPP Toolpad (SmartPad)
KPS Bitmap graphic (IBM KIPS)
KQP Native Camera file (Konica)
KR1 Sample (multi-floppy) file (Kurzweil 2000)
KRZ Sample file (Kurzweil 2000)
KSF Sample File (Korg Trinity)
KYB Keyboard mapping (FTP)
KYE Game data (Kye)


---------------------------------------------------------------------------------------------------------

L Source code (Lex)
L Source code (Lisp)
L Linker directive file (WATCOM wlink)
LAB Datafile (NCSS-SOLO)
LAB Label file (Visual dBase)
LAB Mailing labels (Microsoft Excel)
LAN Loadable module (LAN DLL) (NetWare)
LAY Word Chart layout (APPLAUSE)
LAY Clipart file (Printmaster Gold)
LBG Label generator data (dBase IV)
LBL Label (dBase IV)
LBL Label (Clipper 5)
LBL Label (dBFast)
LBM Bitmap (DeluxePaint)
LBM Linear Bitmap graphics (XLib)
LBO Compiled label (dBase IV)
LBR Compressed archive (LU)
LBR Display driver (Lotus 1-2-3)
LBT Labels (Microsoft FoxPro)
LBX Labels (Microsoft FoxPro)
LCF Linker control file (Norton Guides compiler)
LCH Used in a program (unknown) that monitors a network response time
LCK Lockfile (Paradox)
LCL Datafile (FTP)
LCN Lection document (WordPerfect for Windows)
LCS Data History file (ACT!)
LCW Spreadsheet (Lucid 3-D)
LD Long distance area codes file (Telix)
LD1 Overlay file (dBase)
LDB Lock file (Microsoft Access)
LDF Library definition file (Geoworks Glue)
LDIF Structured text file used for sharing information between E-Mail clients (Microsoft, Netscape and others)
LDL Library (Corel Paradox)
LEG Legacy document
LES System game profiles (same as REG file) (Logitec Entertainment)
LET Broderbund CreataCard Letterhead file
LET Genesis 2000 mortgage application file
LET Letter (generic)
LET Unknown photo image
LEV Level file (NetHack 3.x)
LEX Dictionary file (Generic)
LFD Data resource file (LucasArts Dark Forces)
LFP LaserForms Plus file (Evergreen)
LFT Loft file (3-D Studios) (DOS)
LFT Laser printer font (ChiWriter)
LG Logo procedure definition (LSRHS Logo)
LGC Application log file
LGD Application log file
LGO Logo file (PaintBrush)
LGO Header and footer logo (SuperFax)
LGO Startup logo (Microsoft Windows 3.x-9.x)
LHA Alternate file suffix for LZH
LHA Compressed Archive (LHA/LHARC)
LHW Compressed Amiga archive (LHWARP)
LIB Library file (Generic)
LIF Logical Interchange data (Hewlett-Packard)
LIF Compressed archive (Generic)
LIM Compressed archive (LIMIT)
LIN Line type file (DataCad)
LIN Interactive music sequencing data file (Electronic Arts)
LIS Output file produced by a Structured Query Reporting (SQR) program
LIS Listing (VAX)
LIT eBook file for Microsoft Reader
LIX Logos library system file
LJ Text file (Hewlett-Packard LaseJet II printer)
LK Database file (OpenSight-16 bit)
LKO Linked object (Microsoft Outlook Express Junkmail file)
LL3 Document file (LapLink III)
LLX Exchange agent (Laplink)
LNK Shortcut file (Microsoft Windows 9.x)
LNK Linker response file (RTLink)
LNK Datafile (Revelation)
LNT LiveNote Transcript file
LOD Load file (Generic)
LOG Log file (Generic)
LOK Compressed file (FileWrangler)
LP A document reader used for downloading mortgage closing information (DesertDocs)
LPC Printer driver (TEKO)
LPD Helix Nuts and Bolts file
LPI Information file for laser printers (common with some scanning sofware)
LRC Video phone file (Intel)
LRF Linker response file (Microsoft C/C++)
LRS Language resource file (WordPerfect for Windows)
LSF Logos library system file
LSL Saved library (Corel Paradox)
LSL Script library (Lotus)
LSP AutoLISP, CommonLISP, and other LISP language files
LSS Spreadsheet (Legato)
LST List file (Generic)
LST Keyboard macro (1st Reader)
LST SAS text output
LST Spool file (Oracle)
LTM Form (Lotus Forms)
LU Library unit file (ThoughtWing)
LVL Miner Descent/D2 Level extension (Parallax Software)
LWA Lightwave Scene (version 6 and up)
LWD Text document (LotusWorks)
LWF Wavelet graphics file (Luratech)
LWLO Layered Object file (Lightwave)
LWO Lightwave Object (version 6 and up)
LWOB Object file (Lightwave)
LWP Wordpro 96/97 file (Lotus)
LWSC Scene file (Lightwave)
LWZ Linguistically enhanced sound file (Microsoft)
LYR Layer file (DataCAD)
LZD Difference file for binaries (Ldiff 1.20)
LZH Compressed archive (LH ARC)
LZS Compressed archive (LARC)
LZS Data file (Skyroads)
LZW Compressed Amiga archive (LHWARP)
LZX Compressed archive (Generic)


-----------------------------------------------------------------------------------------------------------

M Program file (Matlab)
M Macro module (Brief)
M Standard package (Mathematica)
M11 Text file (MASS11)
M1U Pocket TV (PDA) file
M1V MPEG-related file (MIME type mpeg)
M2P Canopus MPEG-2 video file
M3 source code file (Modula 3)
M3D 3D animation (Corel Motion)
M3U MPEG URL (MIME audio file) (MP3 Playlist)
M4 M4 Preprocessor file (Unix)
M4A Unprotected AAC audio file
M4A Protected AAC audio file (possibly from iTunes Music Store)
M_U Hard Drive Boot sector backup (MazeGold)
MA3 Macro (Harvard Graphics 3.0)
MAC Image (MacPaint)
MAC Macro (Generic)
MAD Module (Microsoft Access)
MAF Form (Microsoft Access)
MAG A graphics format found in some Japanese files
MAG MAG graphics format created by Woody Lynn (MPS Magro Paint System)
MAGIC Configuration file (Magic Mail Monitor)
MAI Mail (VAX)
MAK Project (Visual Basic or Microsoft C++)
MAK Makefile (Generic)
MAM Macro (Microsoft Access)
MAN Manual page output (Unix)
MAN Command module (Unix)
MAP Map file (Generic)
MAP WAD game file (Duke Nukem 3D)
MAP Color pallette (Generic)
MAP Format data (Micrografx Picture Publisher)
MAP Linker map file
MAP Map file used for color choices (Pro/Engineer)
MAP Map file (Atlas MapMaker)
MAP Network map (AccView)
MAQ Query (Microsoft Access)
MAR Report (Microsoft Access)
MAR Assembly program (VAX Macro)
MAS Graphics file (Lotus Freelance Smartmaster)
MAT Binary file (Matlab)
MAT Table (Microsoft Access)
MAUD Sample format (Maud)
MAX 3D scene (Kinetix 3D Studio Max)
MAX Document (Paperport)
MAX Layout file (OrCad)
MAX Source code (MAX)
MAZ Maze data file (Hover)
MAZ A format use by Division dVS/dVISE
MB Memo field values for database (Paradox)
MB1 Data file (Apogee Monster Bash)
MBK Multiple index archive (dBase IV)
MBOX Mailbox file (Berkeley Unix)
MBX Extension Microsoft Outlook adds to saved email, Eudora mailboxes
MCC Calling card (Dialer10)
MCC Configuration file (MathCad)
MCD Document (MathCad)
MCF Font file (MathCad)
MCF Magic control file
MCI Command script (Media Control Interface)
MCP Project file (Metrowerks CodeWarrior)
MCP Application script (Capsule)
MCP Printer driver (MathCad)
MCR Keyboard macro file (DataCad)
MCW Document (Microsoft Word for Macintosh)
MCW Text document (MacWrite II)
MD Compressed archive (MDCD)
MDA Add-in file (Microsoft Access)
MDA Workgroup (Microsoft Access version 2)
MDB Database (Microsoft Access)
MDE MDE file (Microsoft Access)
MDF Adobe Output Designer and Central Pro Server Compiled Forms Definition
MDL Spreadsheet (CA-Compete!)
MDL Music module (MOD) (Digital Trakker)
MDL Model (3D Design Plus)
MDL Model file (Quake)
MDL Model file element (Rational Rose)
MDM Modem definition (Telix)
MDN Blank database template (Microsoft Access)
MDT Data table (Microsoft ILink incremental linker)
MDT Add-in file (Data) (Microsoft Access)
MDW Workgroup (Microsoft Access)
MDX Multiple index file (dBase IV)
MDZ Wizard template (Microsoft Access)
ME ASCII text document (Generic)
MEB Macro editor bottom overflow library (WordPerfect for Windows)
MED Music module (MOD) (OctaMed Music Editor)
MED Macro editor delete save file (WordPerfect for Windows)
MEM Macro editor macro (WordPerfect for Windows)
MEM Memory variable save file (Clipper)
MEM Memory variable save file (dBase IV)
MEM Memory variable save file (Microsoft FoxPro)
MEQ Macro editor print queue file (WordPerfect for Windows Library)
MER Format for interchanging spreadsheet/database data; recognized by Filemaker, Excel, and others
MER Macro editor resident area (WordPerfect for Windows Library)
MES Macro editor workspace file (WordPerfect for Windows)
MES Message file (Generic)
MET Presentation Manager metafile
MET Macro editor top overflow file (WordPerfect for Windows Library)
MET Document file (OmniPage Pro)
MEU Menu group (DOS Shell)
MEX Executable command (Matlab)
MEX Macro editor expound file (WordPerfect for Windows)
MF Metafont text file
MFG Manufacturing file (Pro/ENGINEER)
MGF Font file (MicroGrafx)
MGF A file in a Materials and Geometry Format
MHP Microsoft Home Publishing file
MHT MHTML document (Microsoft)
MHTM MHTML document (MIME)
MHTML MHTML document (MIME)
MI Data file (Cocreate ME10)
MI Miscellaneous file (Generic)
MIC Image Composer file (Microsoft)
MID MIDI music
MIF Interchange format (Adobe FramMaker)
MIFF Machine Independent File (Generic)
MII Datafile (MicroStat-II)
MIM A multipart file in the Multi-Purpose Internet Mail Extensions (MIME) format; often created as the result of sending e-mail with attachments in AOL. The files in a multipart MIM file can be "opened" (unarchived and separated into individual files) using Winzip or a similar program.
MIME See MIM.
MIX Object file (Power C)
MIX Picture file (Microsoft PhotoDraw 2000)
MIX Picture file (Microsoft Picture-It!)
MIX Package file (Command & Conquer)
MIX Resource archive (Westwood Studios)
MJF Audio file similar to MP3 (Mjuice) (Opens with WinAmp)
MK Makefile (Generic)
MKE Makefile (Microsoft Windows SDK)
MKI Graphic Image (MagView 5.0) (Japanese)
MKS Datafile (TACT)
ML3 Project file (Milestones 3.x)
MLB Macro library (Symphony)
MLI A file in 3D Studio Material-Library format
MLID Muliple link interface driver file (Generic)
MLM Groupwise email file (Novell Groupwise)
MM Text file (MultiMate Advantage II)
MMC Catalog file (Microsoft Clip Gallery 5.x)
MME A multipart file in the Multi-Purpose Internet Mail Extensions (MIME) format; often created as the result of sending e-mail with attachments in AOL. The files in a multipart MME file can be "opened" (unarchived and separated into individual files) using Winzip or a similar program.
MMF Meal Master Format, a recipe catologing format
MMF Mail file (Microsoft)
MMG Beyond 20/20 table or aggregate data file
MML Bulk mail file (Created by MyMailList)
MMM Multimedia movie (Microsoft)
MMM Multimedia movie (MacroMind Director 3.x)
MMO Memo Writer file (RapidFile)
MMP MindManager file (MindMapor)
MMP Output video (Bravado)
MN2 Mission file (Descent2)
MN3 Mission file (Descent3)
MND Menu source (AutoCAD Menu Compiler)
MND Mandelbrot for Windows
MNG Map (DeLorme MapnGo)
MNG Multi-image Network Graphics
MNI Mandelbrot for Windows
MNT Menu file (Microsoft FoxPro)
MNU Menu file (Visual dBase)
MNU Advanced macro (HP NewWave)
MNU Interact menu (Intertal Systems)
MNU Menu (AutoCAD Menu Compiler)
MNU Menu (Norton Commander)
MNX Menu (Microsoft FoxPro)
MNX Compiled menu (AutoCAD)
MNY Account book (Microsoft Money)
MOB Device definition (PEN for Windows)
MOD FastTracker, StarTrekker, Noise Tracker (etc.) music module file
MOD Spreadsheet (Microsoft Multiplan)
MOD Modula-2 source code file (Clarion Modula-2)
MOD Kernel module (Microsoft Windows 9.x)
MOD Amiga/PC tracker module
MOF Windows Management Object file
MON Monitor description (ReadMail)
MOV Movie (QuickTime for Microsoft Windows)
MOV Movie (AutoCAD/AutoFlix)
MOZ Zipped (Compressed) mod file
MP2 MPEG Audio Layer 2 file (MIME video file)
MP3 MPEG Audio Layer 3 (AC3) file
MP4A MPEG Audio Layer 4 file
MPA MPEG-related file (MIME type mpeg)
MPC Calendar file (Microsoft Project)
MPD Database file (Microsoft Project)
MPE MPEG animation
MPEG MPEG animation
MPG MPEG animation
MPM Mathplan Macro library (WordPerfect for Windows)
MPP Project file (Microsoft Project)
MPP Drawing file (CAD)
MPQ Blizzard game data file
MPR Menus (compiled) (Microsoft FoxPro)
MPT Bitmap graphics (Multipage TIFF)
MPV View file (Microsoft Project)
MPX Compiled menu program (Microsoft FoxPro)
MPX Exchange file (Microsoft Project) used for exporting data
MPZ DraCAD (Japanese?) file
MRB Multiple resolution bitmap graphics (Microsoft C/C++)
MRI MRI Scan
MRS Macro resource file (WordPerfect for Windows)
MSA Archive (Magic Shadow)
MSC Makefile (Microsoft C)
MSC Common console document (Microsoft Windows 2000)
MSD Diagnostics report file (Microsoft MSD) (Diagnostics)
MSDL Scene Description Language (Manchester)
MSF Network 7.0 mail file
MSG Mail message (Microsoft)
MSI Installer package (Microsoft Windows)
MSN Network document (Microsoft)
MSN Mission File (Descent)
MSP Paint bitmap (Microsoft)
MSP Windows Installer patch file
MSS Manuscript text file (Perfect Writer)
MSS Manuscript text file (Scribble)
MSS Manuscript text file (MINCE)
MSS Manuscript text file (Jove)
MST Windows Installer transform
MST Minispecification file (Prosa)
MST Setup script (Microsoft SDK)
MSV Sony Memory Stick Compressed Voice File; requires Sony plug-in for Windows Media Player
MSW Text file (Microsoft Word)
MSX Compressed CP/M archive (MSX)
MTH Math file (Derive)
MTM Music module (MOD) (Multitracker)
MTW Datafile (Minitab)
MTX Twain device driver (32 bit)(UMax)
MU Menu (Quattro Pro)
MUL Online game called Ultima online
MUS Music (Generic)
MUS Interactive music audio data file (Electronic Arts)
MUS Music (MusicTime)
MUS10 Audio (Mus10)
MV Server-side script file (Miva)
MVA Video accelerator file (Matrox)
MVB Multimedia Viewer file (Microsoft)
MVC Image file (Sony Digital Mavica)
MVE Interplay video file (Descent2, Fallout2)
MVF Stop frame file (AutoCAD-AutoFlix)
MVI Movie command file (AutoCAD-AutoFlix)
MVL 3D ultrasound file
MVL Descent 2 (game) movie archive
MVW Log file (Saber LAN)
MWF Animation (ProMotion)
MWP Smartmaster file (Lotus WordPro 97)
MXD Map file (ArcInfo)
MXT Datafile (Microsoft C)
MYP Presentation file (Make Your Point)


------------------------------------------------------------------------------------------------------------

NAN Nanoscope files (Raw Grayscale)
NAP Metafile (NAP)
NAP Video file (EnerGraphics)
NB Text file (Nota Bene)
NC Instructions for numerical control machine (CAMS)
NCB Developer Studio file (Microsoft)
NCC CNC (Computer Numeric Control) file (CamView 3D)
NCD Change directory (Norton)
NCF Command File (Netware)
NCF Internal clipboard (Lotus Notes)
NCH Outlook Express folder file
NCO Nero BackItUp compressed backup file
NDB Network database (Intellicom)
NDB NetOp database (Danware Data)
NDO 3D low-polygon modeler (Nendo)
NDX Index file (dBase II-III-IV)
NDX Database file (1ACT! for Microsoft Windows)
NDX Index file (Cindex)
NEO Raster graphics (Atari Neochrome)
NES Emulator ROMS for game console (Nintendo)
NET Network configuration file
NET Netlist output file (Orcad Schematic Capture)
netCDF Network Common Data Form
NEW New info
NEZ Emulator file used for game consoles (NES)
NFF Neutral File Format
NFO Info file database text
NFO Infobase file (Folio)
NFT Template file (Netobject Fusion)
NG Online documentation database (Norton Guide)
NIL Icon Library file (EasyIcons-compatible) (Norton)
NIST Audio (NIST Sphere)
NLB Data (Oracle 7)
NLM Loadable Module (Netware)
NLO NetG Skill Builder file
NLS National Language Support file used for localization (for example, by Uniscape)
NLU E-Mail Trigger file (Norton LiveUpdate)
NLX Form (FormWorx 3.0)
NOD File (Netobject Fusion)
NP Project schedule (Nokia Planner)
NP Project schedule (Visual Planner 3.x)
NPI Source for interpreter (dBase Application Generator)
NRF Data file (NICOLET)
NRG Image file (Nero)
NRI iManage file
NRL iManage infoRite document hyperlinks
NRL Template (Microsoft Outlook)
NSF Database (Lotus Notes)
NSO Document file (NetObject Fusion)
NST Music module (MOD) (Noise Tracker)
NSV Nullsoft streaming video file that comes with Winamp
NS2 Database (Lotus Notes version 2)
NS3 Database (Lotus Notes version 3)
NS4 Database (Lotus Notes version 4)
NT Startup files (Microsoft Windows NT)
NTF Database template (Lotus Notes)
NTR Executable ASCII text file
NTS Tutorial (Norton)
NTS Executable ASCII text file
NTX Index file (CA-Clipper)
NUF Message for new users (1st call) (Procomm Plus)
NWC Song file (Noteworthy Composer)
NWS News message (MIME RFC822) (Microsoft Outlook Express)
NXT Sound file (NeXT)
O Object file (Unix)
O Object file (Atari)
O Object file (GCC)
OAS Word processor document (Fujitsu OAS)(Japanese)
OAZ Fax (NetFax Manager)
OB Object cut/paste file (IBM LinkWay)
OBD Binder template (Microsoft Office)
OBD Binder (Microsoft Office)
OBJ Object file
OBR Object browser data file (Borland C++)
OBS Script (ObjectScript)
OBV Visual interface (ObjectScript)
OBZ Binder Wizard (Microsoft Office)
OCF Object craft file (Object Craft)
OCR Transcribed fax-to-text file (FAXGrabber)
ODL Type library source (Visual C++)
ODS Mailbox file (Microsoft Outlook Express)
OFD Form definition (ObjectView)
OFF Object File (3D Mesh)
OFN FileNew file (Microsoft Office)
OFT Template (Microsoft Outlook)
OGG Ogg Vorbis audio file
OGM Ogg Media video file
OKR Feldeinteilung module file (3-D Fassade Plus)
OKT Music module (MOD) (Oktalyzer)
OLB Object Library (OLE) (Microsoft)
OLB Object library (VAX)
OLD Backup file (Generic)
OLE Object Linking and Embedding (OLE) custom control (Microsoft)
OLI Text file (Olivetti)
OMC Atrac3 (Sony Music Store) audio file
OO1 Voice file (Typhoon)
OOGL Object Oriented Graphics Library
OOM Swap file (Shroom)
OPJ Project file (Orcad Schematic Capture)
OPL Organiser Programming Language source file (Psion/Symbian)
OPN Active options (Exact)
OPO Output executable file (OPL)
OPT Developer Studio file (Microsoft)
OPT Optimize support file (QEMM)
OPW Organization chart (Org Plus for Windows)
OPX Extension DLL (OPL)
OPX Inactive options (Exact)
OPX Microsoft Organizer Organization Chart
ORA Parameter file (Oracle)
ORC Script (Oracle 7)
ORG Calendar file (Lotus Organizer)
OR2 Calendar file (Lotus Organizer 2)
OR3 Lotus Organizer 97 file
ORA Configuration file (Oracle 7)
OSS Search file (Microsoft Office)
OST Offline file (Microsoft Exchange/Outlook)
OTL Outline font description (Z-Soft Type Foundry)
OTL Template file (Super NoteTab) (Fookes)
OTL Template file (PrintMaster Gold)
OTX Text file (Olivetti Olitext Plus)
OUT Output file (Microsoft C)
OV Database file (Revelation-DOS)
OV1 Overlay file
OV2 Overlay file
OVD Datafile (ObjectVision)
OVL Overlay file
OVR Overlay file
O$$ Outfile (Sprint)

------------------------------------------------------------------------------------------------------------------

P Source code (Pascal)
P Application parameter file (ReaGeniX code generator)
P Picture file (APPLAUSE)
PA Print Artist Project file
PA1 Worktable (PageAhead)
PAB Personal Address Book (Microsoft)
PAC Package file (Sound Blaster Studio II)
PAC Image (Stad)
PAD Keypad definition (Telemate)
PAF Personal Ancestry File (free genealogy software from the Mormon Church)
PAK Compressed archive (PAK)
PAK WAD file (Quake)
PAL A compressed file (Generic)
PAL Color palette (Microsoft)
PAN Printer specific file (CorelDRAW)
PAQ Password encrypted zip file (Hewlett-Packard)
PAR Parts application (Digitalk PARTS)
PAR Parameter file (Fractint)
PAR Permanent output file (Microsoft Windows 3.x)
PAS Source code file (Borland Pascal)
PAT Hatch pattern file (DataCAD)
PAT Pattern file (CorelDRAW)
PAT Patch file (Advanced Gravis Ultrasound/Forte Technologies)
PAT exePatch utility used for Warcraft2 (WarHack)
PB Fax (FAXability Plus)
PB Phone book (WinFax Pro)
PB Setup file (PixBase)
PB1 Document (First Publisher for Windows)
PBA Source code file (Powerbasic BASIC) (Genus)
PBD Phone book (FaxNOW!-Faxit)
PBD Dynamic library, an alternative to a native DLL (PowerBuilder)
PBF Turtle Beach Pinnacle Bank File
PBI Include file (PowerBasic) (Genus)
PBI Profiler binary input file (Microsoft Source Profiler)
PBK Microsoft Phonebook
PBL Library file used in a development environment (PowerBuilder)
PBL PowerBasic library (Genus)
PBM Portable bitmap graphic
PBM Planar bitmap graphic (XLib)
PBN Portable Bridge Notation file
PBO Profiler binary output (Microsoft Source Profiler)
PBR Resource file (PowerBuilder)
PBT Profiler binary table (Microsoft Source Profiler)
PC Text file (IBM)
PC3 Custom palette (Harvard Graphics 3.0)
PC8 Ascii text IBM8 character set (NewWave Write)
PCB Application data file (Microsoft Powerpoint)
PCC Cutout picture vector graphics (PC Paintbrush)
PCD Image (Kodak Photo-CD)
PCD P-Code compiled test scripts as in Microsoft Test and Microsoft Visual Test
PCE Maps Eudora mailbox names to DOS filenames
PCF Profiler command file (Microsoft Source Profiler)
PCH Patch file (Generic)
PCH Precompiled header file (Microsoft C/C++)
PCI PCI Miniport file (Microsoft Windows System file)
PCJ Multimedia authoring tool graphics (IBM Linkaway-Live)
PCK Pickfile (Turbo Pascal)
PCL Printer Control Language file (printer-ready bitmap) (Hewlett-Packard)
PCM Audio file
PCM PCM file (OKI MSM6376 Sythesizer Chip)
PCP Live Update Pro file (Symantec)
PCS Animation (PICS)
PCS Picture storage file (Microsoft)
PCT PICT drawing (Macintosh)
PCW Text file (PC Write)
PCX PC Paintbrush bitmap (ZSoft)
PDA Bitmap graphics
PDB Data file (TACT)
PDB Physical model backup file (PowerDesigner)
PDB Database file (3Com PalmPilot)
PDB Brookhaven Protein Database file
PDD Graphic image that can be opened with Paint Shop Pro and Adobe PhotoDeluxe
PDF Portable Document file (Adobe Acrobat) (displayable with a Web browser)
PDF Definition File
PDF Printer Definition File (Netware)
PDF Graphics file (ED-SCAN 24bit)
PDL Project description language file (Borland C/C++)
PDM Physical model file (PowerDesigner)
PDP Print Shop Deluxe file (Broderbund)
PDQ Flowcharting PDQ Lite file (Patton&Patton)
PDS Photographic image file (origin not yet identified)
PDS Hardware assembly source code file (Pldasm)
PDT Database file (ProCite)
PDV Printer driver (Paintbrush)
PDW Document (Professional Draw)
PDX Database index file (ProCite)
PE3 Image archive file (Ulead PhotoImpact)
PE3 Image archive file (QuickViewer)
PE4 Image archive file (Ulead PhotoImpact v.4.0)
PEB Program Editor bottom overflow file (WordPerfect for Windows Library)
PED Program Editor delete save file (WordPerfect for Windows)
PEM Program Editor macro (WordPerfect for Windows library)
PEQ Program Editor print queue file (WordPerfect for Windows)
PER Program Editor resident area file (WordPerfect for Windows Library)
PES Program Editor work space file (WordPerfect for Windows Library)
PET Program Editor top overflow file (WordPerfect for Windows Library)
PF Encrypted file (Alladin Systems)
PF Windows XP prefetch file (data read into RAM in anticipation of a user asking for it)
PFA Type 3 font (ASCII)
PFB Type 1 font (binary)
PFC PF Component file
PFC Text file (First Choice)
PFC Personal filing cabinet file (AOL)
PFD SoftPro Real Estate Proform Document Format
PFF Paraform file for 3D modeling (Scandata)
PFK Programmable function keys (XTreePro)
PFM Printer Font Metrics (Microsoft)
PFS Database text file (PFS:Write)
PFT Printer font (ChiWriter)


----------------------------------------------------------------------------------------------------------

PG Page cut/paste file (IBM LinkWay)
PGI Printer graphics file device driver (PGRAPH Library)
PGL Plotter drawing (Hewlett-Packard)
PGM Portable Graymap (bitmap)
PGM Program file (Signature)
PGN Portable game notation file (ChessMaster and others)
PGP PGP encrypted file
PGS Manual page (man4dos)
PH Temporary file generated by Microsoft Help Compiler
PH Optimized .goh file (Geoworks)
PH Perl header file
PH Phrase-table (Microsoft C/C++)
PHN Phone list (UltraFax)
PHN Phone list (QmodemPro)
PHO Phone database (Metz Phone for Windows)
PHP HTML page that includes a PHP script
PHP3 HTML page that includes a PHP script
PHR Phrases (LocoScript)
PHTML HTML page that includes a PHP script
PHTML perl-parsed HTML
PI1 Low resolution picture file (Dages Elite)
PI2 Medium resolution picture file (Dages Elite)
PI3 High resolution picture file (Dages Elite)
PIC Bitmap (PC Paint)
PIC Pixar picture file (SDSC Image Tool)
PIC Picture file (Lotus)
PIC PICT drawing (Macintosh)
PIC 3D Image file (SoftImage)
PICT PICT image file (Macintosh)
PIF Program Information File
PIF PIF drawing (IBM)
PIF Vector graphics GDF file (IBM Mainframe)
PIF Compressed archive (Macintosh)
PIG WAD file (Lucas Arts Dark Forces
PIN Data file (Epic Pinball)
PIN Data file (Epic Pinball)
PINS Password file of the program PINs, Passwords & Co.
PIX Bitmap (Inset Systems)
PIX Alias image file (SDSC Image Tool)
PJ Project file (CA-SuperProject)
PJ Source Integrity file (MKS)
PJT Visual FoxPro memo file (Microsoft)
PJT Visual Foxpro Project (Microsoft)
PJX Visual FoxPro project file (Microsoft)
PK Packed bitmap font file (TeX DVI)
PKA Compressed file archive (PKARC)
PKG Developer Studio application extension (similar to a DLL file) (Microsoft)
PKG Installer script (NEXT)
PKR Public Keyring (PGP)
PKT Packet file (Fidonet)
PL Interleaf printerleaf (or WorldView) format
PL Source code file (Perl)
PL Source code file (Prolog)
PL Property list font metric file (TeX)
PL Palette (Harvard Graphics)
PL1 Room plan (3D Home Architect)
PL3 Chart palette (Harvard Graphics 3.0)
PLB Library file (Microsoft FoxPro)
PLC Add-in file (Lotus 1-2-3)
PLG A format use by REND386/AVRIL
PLI Data description file (Oracle 7)
PLL Pre-linked library file (Clipper 5)
PLM Module (DisorderTracker2)
PLN Spreadsheet (WordPerfect for Windows)
PLR Pilot file (Descent 1-3)
PLS Sample file (DisorderTracker2)
PLS MPEG PLayList file (used by WinAmp)
PLS MYOB Plus file
PLT Drawing (HPGL Plotter)
PLT Plot drawing (AutoCAD)
PLT Palette (Generic)
PLT Pre-linked transfer file (Clipper 5)
PLT Sign-making software (Gerber Optical)
PLY Data file (PopMail)
PLY Presentation screen (Harvard Spotlight)
PM Bitmap graphics (Presentation Manager)
PM Module (Perl)
PM3 Document (PageMaker 3.0)
PM4 Document (PageMaker 4.0)
PM5 Document (PageMaker 5.0)
PM6 Document (PageMaker 6.0)
PMC Graphics (A4TECH Scanner)
PMD Adobe PageMaker 7.x file
PMM Program file (Amaris BTX/2)
PN3 Printer device driver (Harvard Graphics 3.0)
PNG Bitmap (Portable Network Graphics)
PNG Browser catalogue (Paint Shop Pro)
PNG Bitmap file (MacroMedia FireWorks)
PNM Portable aNY Map graphics (PBM)
PNT Graphic file (MacPaint)
PNT QWK reader pointer file (MarkMail 2.x)
PNT Pen Table plotting file (Pro/Engineer)
PNTG Same as PNT file
POG PIG file extension (Descent2)
POH Optimized .goh file (Geoworks)
POL Windows NT Policy file
POL 3D polygonal modeling file (Innovmetric)
POP Popup file (Visual dBase)
POP Message index (PopMail)
POT PowerPoint template (Microsoft)
POV Persistence of Vision file (Ray-Tracer)
POW Chord chart (PowerChords)
PP Compressed Amiga archive (POWERPACKER)
PP4 Bitmap (Picture Publisher 4)
PPA PowerPoint Add-in (Microsoft)
PPB Button bar for print preview (WordPerfect for Windows)
PPD PostScript Printer definition file specification (Adobe Acrobat v.4.0)
PPF Pinnacle Program File (Turtle Beach)
PPI Graphics file (Microsoft PowerPoint)
PPL PolaroidPalettePlus ColorKey device driver (Harvard Graphics 3.0)
PPM Portable Pixelmap bitmap
PPO Pre-processed output file (Clipper 5)
PPP Document or finished project (Parson Power Publisher)
PPP Desktop publishing default output file (Serif PagePlus)
PPS PowerPoint slide show (Microsoft)
PPS Storyboard (Personal Producer)
PPT PowerPoint presentation (Microsoft)
PQB Master boot backup file (PowerQuest BootMagic)
PQI Drive image file (PowerQuest)
PR2 Presentation (Aldus Persuasion 2.x)
PR2 Printer driver (dBase IV)
PR3 Postscript printer driver (dBase IV)
PR3 Presentation (Aldus Persuasion 3.x)
PRC Resource (text or program) file (3com PalmPilot)
PRD Printer driver (Generic)
PRE Presentation (Lotus Freelance)
PRE Settings (Programmer WorkBench)
PRE Settings (Microsoft C/C++)
PRF System file (Microsoft Windows)
PRF Settings file (Macromedia Director)
PRF Pixel Run Format graphics (Improces-Fastgraph)
PRF Printer driver (dBase IV)
PRF Output file (Profiler)
PRG Program source files (dBase IV, Clipper 5, and Microsoft FoxPro)
PRG Program source files (Atari)
PRG Program file (WAVmaker)
PRI Printer definitions (LocoScript)
PRJ Project file (3D Studio) (DOS)
PRM MYOB Premier file
PRM Parameter file (Generic)
PRN Print Table (space delimited text)
PRND PageMaker 7.0 file
PRN Windows Printer file (DataCAD)
PRN Printer driver (Signature)
PRN Text file (Lotus 1-2-3-Symphony)
PRO Source code file (Prolog)
PRO Configuration file (Pro/Engineer)
PRO Graphics profile file (DOS)
PRO Project file (Terramodel)
PRP Data conversion saved project file (Oberon Prospero)
PRS Presentation file (Harvard Graphics for Windows)
PRS Printer resource font file (WordPerfect for Windows)
PRS Procedure file (dBase IV)
PRT A print-formatted file
PRT Printer driver (Dr. Halo)
PRT Part file (Pro/Engineer)
PRT Part file (CADkey)
PRT Unigraphics CAD file
PRV Internet provider template file (psiMail)
PRX Compiled program (Microsoft FoxPro)
PRZ Graphics file (Lotus Freelance 97)
PS Postscript-formatted file (a Postscript printer-ready file)
PSB Sound Bank file (Pinnacle)
PSD Bitmap (Adobe Photoshop)
PSE Bitmap graphics (IBM printer Page SEgment)
PSF Outline PostScript printer font (ChiWriter)
PSI A-law audio file (psion)
PSM Studio module (ProTracker)
PSM Sound data file (Epic Pinball)
PSM Symbol table of IDE (Turbo Pascal)
PSP Image file (PaintShop Pro)
PSP Procedure (Prodea Synergy)
PSR Report file (PowerSoft)
PST Personal Folder File (Microsoft Outlook)
PT3 Device driver (Harvard Graphics 3.0)
PT3 Template (PageMaker 3.0)
PT4 Template (PageMaker 4.0)
PTB Peachtree backup file
PTB Script file (PubTech BatchWorks)
PTB Table file (Pro/Engineer)
PTD LiveNote Portable Transcript document
PTD Table file (Pro/ENGINEER)
PTF LiveNote Portable Transcript file
PTF ProTracker Tennis Match file
PTL Petal file (ASCII version of Microsoft Visual Modeler)
PTM Macro (PubTech BatchWorks)
PTM Music module (MOD) (Polytracker)
PTN PaperPort (ScanSoft) thumbnail image index file
PTR QWK reader pointer file (QMail)
PTX RealLegal Portable E-Transcript viewer file
PUB Publication (Ventura Publisher)
PUB Document (Microsoft Publisher)
PUB Public key ring file (PGP)
PUD Map file (WarCraftII)
PUT Compressed archive (PUT)
PVD Script file (Instalit)
PVL Library file (Instalit)
PVT Local pointlist (Fidonet)
PW Text file (Professional Write)
PWD Word document (Microsoft Pocket)
PWL Password list file (Microsoft Windows 9.x)
PWP Image file (a roll of film viewed using Photoworks)
PWP Text document (Professional WritePlus)
PWZ PowerPoint wizard (Microsoft)
PX Primary database index (Paradox)
PXW Pixtran file
PXL Pocket Excel spreadsheet (Microsoft)
PY Saved emessages (YAHOO)
PY python Script file
PYC python Compiled script file
PZD Default settings (Pizazz Plus)
PZO Overlay file (Pizazz Plus)
PZP Palette (Pizazz Plus)
PZS Settings (Pizazz Plus)
PZT Transfer file (Pizazz Plus)
PZX Swap file (Pizazz Plus)
P3 Project Planner file (Primavera)
P10 Plot 10 drawing (Tektronics)
P16 16 Channel Music file (ProTracker 16)
P22 Patch file (Patch 22)
P65 Document file (PageMaker 6.0)
P7C Digital ID file (MIME)

QAD Document (PF QuickArt)
QAG Quick Access Group data file (Norton Desktop)
QAP Application file (Omnis Quartz)
QBE Saved query (dBase IV)
QBE Saved Query (Quattro Pro)
QBO Compiled query (dBase IV)
QBS Program file (Microsoft QuickBasic)
QBW Spreadsheet data (QuickBooks for Windows)
QCP Voice file (Qualcomm Pure Voice)
QD0 Data file-segment 10 (Omnis Quartz)
QD1 Data file segment 1 (Omnis Quartz)
QD2 Data file segment 2 (Omnis Quartz)
QD3 Data file segment 3 (Omnis Quartz)
QD3D QuickDraw 3D Metafile (Apple)
QD4 Data file segment 4 (Omnis Quartz)
QD5 Data file segment 5 (Omnis Quartz)
QD6 Data file segment 6 (Omnis Quartz)
QD7 Data file segmnet 7 (Omnis Quartz)
QD8 Data file segment 8 (Omnis Quartz)
QD9 Data file segment 9 (Omnis Quartz)
QDF Data file (Quicken)
QDK Backup of startup files (QEMM)
QDT Data file from the Quicken UK Accountancy/Tax/Invoice program (QuickBooks)
QDV Graphics file (Steve Blackstock Giffer)
QEF Query file (Microsoft Excel)
QEL Electronic library file (Quicken)
QFL Document (FAMILY LAWYER)
QFX Fax (QuickLink)
QIC Backup file (Microsoft)
QIF Image (MIME)(QuickTime)
QIF Import file (Quicken)
QLB Library file (Quick)
QLB Library file (Microsoft C/C++)
QLC Data (PostScript help file)
QLP Printer driver (QuickLink)
QM Motion file (Quality)
QM4 Option or services file (QMail 4.x Mail Door)
QPR Generated query program (Microsoft FoxPro)
QPR Print queue device driver (OS/2)
QPX Compiled query program (Microsoft FoxPro)
QQT Qardware definition file (Quick Qard Technology)
QRP Report builder file (Centura)
QRP Report file (Liberty for Windows 2.0)
QRS Equation Editor support file (WordPerfect for Windows)
QRT QRT graphics file (Ray Tracer)
QRY Query (Microsoft)
QRY Query (dBase IV)
QSD Datafile (Quicken)
QST Tab file (Quake Spy)
QT Movie file (QuickTime)
QTI Image file (QuickTime)
QTIF Image file (QuickTime)
QTM Movie file (QuickTime)
QTP Preferences file (QuickTime)
QTS PICT image file (Macintosh)
QTS Image file (QuickTime)
QTX Image file (QuickTime)
QW Write program file (Symantec Q&A)
QWK Message file (QWK Reader)
QXD Data file (QuarkXpress)
QXL Element library (QuarkXpress)
QXP Project file (replaces QXD file as of QuarkXPress 6)
QXT Template file (QuarkXpress)

--------------------------------------------------------------------------------------------------------------

R Ratfor file (FORTRAN Preprocessor)
R Resource file (Pegasus Mail)
RA RealMedia streaming audio file
RAD Radar data file (Radar ViewPoint)
RAM RealMedia metafile
RAO ReadAllOver (YOUniverse)
RAR RAR compressed archive (Eugene Roshall format)
RAS Bitmap (Sun Raster Images)
RAT Datafile (RATS)
RAV Rave file (used by programmers?)
RAV Norton Antivirus file?
RAW Raw File Format (bitmap)
RAW Raw signed PCM data
RAW Raw signed PCM data
RBF Datafile (Rbase)
RBH Maintained by RoboHELP, the RBH file adds to the information contained in the Help project file
RC Resource script (Micosoft C/C++)
RC Resource script (Borland C++)
RC Configuration file (emacs)
RCG Newsgroup file (Netscape)
RD1 Registered level file (Descent1)
RDF Resource Description Framework file (related to XML and metadata)
RDF Compiled UIC source code (Geoworks UI Compiler)
RDF Research document information format
RDI Device-independent bitmap file
RDL Registered Level file (Descent)
RDX Datafile (Reflex)
RDZ RemoteDocs compressed and encrypted file
REC Datafile (EpiInfo)
REC Recorded macro (Microsoft Windows 3.x)
REC Voice file (RapidComm)
REC Record file (Sprint)
RED Path information file (Clarion Modula-2)
REF Reference file (Generic)
REG Registration file
REG Registration file (Corel)
REG OLE registration file (Microsoft Windows 3.x)
REM Remarks file (Generic)
REP Reply file (QWK Reader)
REP Report file (Visual dBase)
REP Report file (Report Designer)
REP Report file (DataBoss)
REP Report file (CodeReporter)
REQ Request file (Generic)
RES Resource file (Microsoft Visual C++)
RES Compiled resource file (Borland C++)
RES Resource file (dBase IV)
REV Revision file (GeoWorks)
REX Source code file (REXX)
REX Report definition (Oracle)
REZ Resource file (Generic)
RF Raster graphics file (Sun)
RFT Revisable Form Text (part of IBM DCA or Document Content Architecture)
RGB, SGI RGB files (Silicon Graphics)
RGX Symbol tables (ReaGeniX code generator)
RH Resource header file (Borland C++ 4.5)
RI Data file (Lotus 1-2-3)
RIB Graphics in Renderman format (3DReality)
RIC Fax document (Ricoh)
RIF RIFF bitmap graphics (Fractal Design Painter)
RIF Image file (Metacreations Painter 5)
RIP Graphics (remote access)
RIX Bitmap graphics (ColorRIX VGA Paint)
RL1 Regestered level file (Descent1)
RL2 Registered level file (Descent2)
RL4 Bitmap graphics file
RL8 Bitmap graphics file
RLA Wavefront raster image (SDSC Image Tool)
RLB Data file (Harvard Graphics Win 9.x)
RLC Graphics file (1 bit per pixel scanner output file)
RLE Run-Length Encoded bitmap (SDSC Image Tool)
RLZ Realizer source code file (CA-Realizer)
RM Video file (RealAudio)
RMD Document (Microsoft RegMaid)
RMF Rich Map Format (used by 3-D game editors to store a map)
RMF Rich music format (Beatnik)
RMI MIDI music
RMK Makefile (Clipper RMake)
RN Xpl Program file (Nota Bene)
RND Rendering slide (AutoCAD-AutoShade)
RNO Runoff file (VAX)
ROL FM music Adlib Music file (Roland)
ROM Cartridge-based home video game emulator file (exact copy of ROM contents in cartridges from Atari 2600, Colecovision, Sega, Nintendo, etc.; not interchangeable between emulators)
ROV Data file (Rescue Rover)
RPD Database (RapidFire)
RPL Text document (Replica)
RPL Video file (Tomb Raider)
RPM Package Manager (RedHat Linux)
RPT Crystal Reports file ( and a sub-set of Microsoft Visual Basic)
RRS Saved game file (Ace Road Rash)
RS Datafile (Amiga Resource Reassembler)
RSB Red Storm bitmap (Rainbow 6 (Game) and several image editing programs)
RSC Resource file (Generic)
RSL Paradox 7 reports (Broderland)
RSM Resume file (WinWay Resume Writer)
RSP Response file (Generic)
RS_ Resource fork file (Macintosh Mac-ette)
RTC Rich Text Compressed file
RTF Rich Text Format document
RTF Help file script (Microsoft Windows 9.x)
RTL Run Time library (NU 7.0)
RTM Music module (MOD) (Real Tracker)
RTK Used by RoboHELP to simulate the search feature of Windows help
RTL Text file (Generic)
RTP Software update package data file (RTpatch)
RTS RTSL document (RealAudio)
RTS Runtime library file (CA-Realizer)
RTS RoboHELP to speed complex operations
RUL Extension used in InstallShield
RUN Compiled output p-code file (Softworks basic compiler) (SoftworksLtd)
RVP Scan Configuration file (MIME) (Microsoft)
RVW Review file (Generic)
RWS Resource Workshop data file (Borland C++)
RWX Script file (RenderWare)
RXX RAR compressed files from a multi-volume archive (xx = a number from 01 to 99)
R8 Raw graphics (One byte per pixel) plane one (PicLab)
R8P Pcl 4 bitmap font (Intellifont)


------------------------------------------------------------------------------------------------------------

S Assembler source code (Unix)
S Source code file (Scheme)
SAI Encrypted video file (Integrated Sensors)
SAL Datafile (SORITEC)
SAM Document (AMI Professional)
SAM Signed 8bit sample data file
SAR Compressed archive (SAR)
SAS SAS program file
SAS7BCAT SAS system catalog
SAS7BDAT SAS system data set
SAS7BNDX SAS system index
SAV Saved game file (Generic)
SAV Backup file (Generic)
SAV Configuration file (Generic)
SB Raw Signed Byte (8bit) audio data
SBD Storyboard data file (Storyboard Editor)
SBD Data definition file (Superbase)
SBF File data (Superbase)
SBI Instrument file (Creative Labs SoundBlaster)
SBK Bank file (Soundblaster)/EMU SoundFont v1.x (Creative Labs Soundfont 1.0)
SBL Flash object (ShockWave)
SBP Dml program file (Superbase 4)
SBP Program file (Superbase)
SBQ Query definition file (Superbase)
SBR Support file (Source Browser)
SBT Notes related to record data (Superbase 4 for Windows)
SBV Form definition file (Superbase)
SB! Locking file (Superbase)
SC Pal script (Paradox)
SC Display driver (Framework II)
SC2 Schedule+ 7.0 file (Microsoft)
SC2 SAS 6.12 catalog (Windows 95/NT, OS/2, Mac)
SC3 Saved game file (SIMM City 3000)
SC3 Renamed dBase III screen mask file (dBase IV)
SC3 Screen device driver (Harvard Graphics 3.0)
SC4 Level file (Roller Coaster Tycoon)
SC7 SAS 8.2 catalog
SCA Datafile (SCA)
SCC Source Safe file (Microsoft)
SCC Text file (Generic)
SCD Slide image (Matrix/Imapro SCODL)
SCD Object description language graphics (Scodl Scan Conversion)
SCD Datafile (Microsoft Schedule+ 7.0)
SCF Command file (Microsoft Windows Explorer)
SCF Multimedia show (ScoreMaker)
SCF Spell checker configuration file (Symphony)
SCH Datafile (Microsoft Schedule+ 7.0)
SCH Schematics file (ORCAD)
SCI Inspire native format (ScanVec)
SCI System configuration information file (Generic)
SCI Fax document (SciFAX)
SCM Scheme source code file (Generic)
SCM Video game console ROM emulater file
SCN Scene data file (TrueSpace2)
SCN Screen file (Kermit)
SCN Videowave Scene file
SCO High score file (Generic game file)
SCP Dial-Up Networking Script
SCP Script file (BITCOM)
SCR Screensaver file (Microsoft Windows 9.x)
SCR Fax image (Generic)
SCR Debug source code (DOS Debug)
SCR Screen snapshot file (dBase IV)
SCR Screen snapshot file (Procomm Plus)
SCR Screen font file (LocoScript)
SCT SAS catalog (Dos)
SCT CT bitmap (Scitex)
SCT FoxPro forms (Microsoft)
SCT01 SAS catalog (Unix)
SCV CASmate Native format (ScanVec)
SCX FoxPro forms (Microsoft)
SCX Bitmap graphics (ColorRIX)
SCX Chart (Stanford Chart)
SCX Screen file (Microsoft FoxPro)
SCY Security file (ReaGeniX)
SD Audio (Sound Designer I)
SD2 Flattened file/data fork (Sound Designer II)
SD2 SAS 6.12 data set (Windows 95/NT OS/2, Mac)
SD7 SAS 8.2 data set
SDA File archive description (Fidonet Software Distribution Network)
SDC Spreadsheet (Staroffice)(StarCalc)
SDD Presentation file (Staroffice)(Starimpress)
SDF System Data File Format - legacy Unisys (Sperry) format
SDI Software distribution network information file
SDK Floppy disk image (Roland)
SDL Library file (SmartDraw)
SDN Software distribution network compressed archive
SDP Datafile (Cocreate SolidDesigner)
SDPC Datafile (Cocreate SolidDesigner)
SDR Drawing (SmartDraw)
SDS Raw Midi Sample Dump Standard file
SDT Template (SmartDraw)
SDV Semicolon Divided Values file
SDW Graphic file (Lotus WordPro)
SDW Raw Signed DWord (32bit) data
SDX Midi Sample Dump Standard files compacted by SDX
SEA Self-expanding archive (used by Stuffit for Mac files and possibly by others)
SEC Secret key ring file (PGP)
SEC Secured animation file (Disney Animation Studio)
SED Screen editor script files (SED)
SEL Data file (Copy Books)
SEP Tagged Image File Format (TIFF) bitmap
SEP Printer seperator page (Generic)
SEQ Animation file (Atari)
SEQ Sequential instruction file (Bubble Chamber)
SES Session file (Cool Edit) (common digital audio editor file )
SES Session information file (Clarion Modula-2)
SESSION Internet Security Scanner file (ISS)
SET Configuration file (1st Reader)
SET Install driver sets (Symphony)
SET Setup option file (Generic)
SET Voice set files (Quartet)
SEW Sewing program file (Generic)
SF SoundFile format (IrCam)
SF Wps attribute storage file (OS/2 WorkPlace Shell)
SF2 SoundFont file (EMU version 2.0)
SF2 Bank file (Creative Labs Soundfont 2.0)(Soundblaster)
SFD Sound File Data (SoundStage)
SFI Sound File Info (SoundStage)
SFI Graphics file (SIS Framegrabber)
SFI Printer font file (Hewlett-Packard Laser Jet Landscape)
SFI Printer font file (Ventura Publisher)
SFK Sound file (Sonic Foundry)
SFL Pcl 4 bitmap font (LandScape)
SFL Pcl 4 bitmap font (Ventura Publisher)
SFL Pcl 4 bitmap font (Intellifont)
SFN Font file (SPX)
SFP Pcl bitmap font (Portrait)
SFP Pcl bitmap font (Intellifont)
SFP Pcl bitmap font (Ventura Publisher)
SFR Sample Resource (Sonic Foundry)
SFS Pcl 5 scalable font file (Intellifont)
SFT Screen font (ChiWriter)
SFW Mangled JPEG (Seattle Filmworks)
SFX Self-extracting archive (RAR)
SG Image file (SnapGraphix)
SG1 Graphics file (Stanford Graphics)
SGF Document w/graphics (StarWriter)
SGF Graphics file (Sonique)
SGI Graphics file (IRIS)
SGI Graphics file (Silicon Graphics)
SGML Standard Generalized Markup Language
SGP Statistics file (STATGRAPHICS Plus)
SGT Save/Get keyboard macro (Signature)
SH Shell script (Unix)
SH ASCii archive (Unix/SHAR)
SH3 Presentaion file (Harvard Graphics)
SHB Presentation (Corel Show)
SHB Document shortcut file
SHG Bitmap (HotSpot)
SHK Compressed Apple archive (SHRINKIT)
SHK Compressed archive (Arthurian Shrink Archiver)
SHM Shell macro (WordPerfect for Windows Library)
SHN Audio compression file (Shorten)
SHP DOS shapes file (3D Studios)
SHP File format used by some programs for 3D modeling of multipart interactive triangle models
SHP Shapefile spatial data format (used by many GIS programs)
SHP Source code and shape file for text fonts (AutoCAD)
SHR File archive (Unix ASCii) (SHAR)
SHS Shell scrap file; reportedly used to send "password stealers"
SHT Pocket Spreadsheets file
SHTML HTML file containing Server Side Includes (SSI)
SHW Presentation (Corel Show)
SHW Presentation (Harvard Graphics 2.0)
SHW Slide Show (WordPerfect for Windows)
SHX Shape entities (AutoCAD)
SHX Shapefile spatial index file (ArcView)
SIF Setup installation files (Microsoft Windows NT)
SIG Signature file (PopMail)
SIG Current program settings (Signature)
SIK Backup files (Microsoft Word for Windows)
SIK Backup files (Sicherungskopie)
SIT Compressed archive of Mac files (Stuffit)
SIZ Configuration file (Oracle 7)
SIZED Gallery resized photo image
SKA Secret Keyring file (PGP)
SKF Drawing file (AutoSketch)
SKL Resource file (Macromedia Director)
SL Save Layout extension (PACT)
SL Source code file (S-Lang)
SLB Slide Library File (AutoCAD)
SLC Compiled SALT script (Telix)
SLD Slide File (AutoCAD)
SLI Slide file (MAGICorp Slide Service)
SLK Symbolic link spreadsheet (SLYK)
SLL Sound data file (Generic)
SLT Script application language (SALT) (Telix script source)
SM Source code file (Smalltalk)
SM Maillist (SoftSpoken Mailer)
SM Script file (ScriptMaker)
SM Text file (Samna Word)
SM3 Symbol file (DataCAD)
SMD Video game console ROM emulator file
SMF Fax document (SMARTFAX)
SMK Image file (Deer Revenge)
SMK Image file (Smack Player)
SMK Image file (Nascar Racing 99)
SMM Macro (AMI Pro)
SMP Samplevision format
SMP Sample file (AdLib Gold)
SMS Emulator ROM image file (8-bit Sega Master System)
SMT Text file (Smart Ware II)
SMT SmartObject file (IconAuthor)
SNA Drive Snapshot compressed Disk Image file
SND Sound file (NeXt)
SND Sound resource (Macintosh)
SND Raw unsigned PCM data
SND Sample (AKAI MPC)
SNDR Sound file (Sounder)
SNDT Sound file (SndTool)
SNG Midi song file (Midisoft Studio)
SNG Midi song file (Prism)
SNM Mailbox (mail folder) index (Netscape)
SNO Source code file (Snobol4)
SNP Microsoft Access database snapshot file
SNP Output video file (Computer Eyes)
SO Shared library file (Unix)(equivalent to a Windows DLL)
SOL Solution file (Common used with game examples,tutorials)
SOM Network serial numbers (Quattro Pro)
SOM Sort information files (Paradox)
SON Song file (Creative Labs SoundBlaster Studio II)
SOU Sound file (Creative Labs SoundBlaster Studio)
SP Compressed archive for Unix (Sprint)

----------------------------------------------------------------------------------------------------------.


SP2 Quake2 pcx 8-bit sprite builder file
SP3 Quake2 pcx 32-bit sprite builder file (for use with CyberPunkQE)
SP4 Saved game (Roller Coaster Tycoon)
SPA FutureSplash Flash file (Macromedia)
SPC Program file (Microsoft MultiPlan)
SPC Temporary file (WordPerfect for Windows)
SPD Data file (Speech)
SPD Scalable font (Speedo)
SPD Scalable font (Harvard Graphics 3.0)
SPF Slide presentation file (EnerGraphics)
SPG Glossary file (Sprint)
SPI Graphics file (Siemens Scanner)
SPI Graphics file (Phillips Scanner)
SPL Object file (ShockWave Flash)
SPL Sample file (DigiTracker)
SPL Compressed archive (SPLINT)
SPL Customized printer driver (Sprint)
SPL Personal spell dictionary (Signature)
SPL Printer spool file (Microsoft Windows 3.x)
SPL Sample file (Generic)
SPM Data file (WordPerfect for Windows)
SPP Printer file (Sprint)
SPPACK Sound sample (SP Pack)
SPR Document letter (Sprint)
SPR Generated screen program (Microsoft FoxPro)
SPR Sprite (Image layering and resizing)
SPRITE Bitmap file (Acorn)
SPS Spssx source code file (VAX/VMS)
SPS Screen driver (Sprint)
SPT Source code file (Spitbol)
SPT Support file (MITAC disk/system management utility package)
SPU Picture file (Spectrum 512)
SPW Worksheet (SigmaPlot)
SPX Compiled screen program (Microsoft FoxPro)
SQC Structured Query Language (SQL) common code file
SQL SQL queries (Informix)
SQL Generally used by database products as an extension for SQL queries (scripts, text, or binary)
SQP Query result of audio search (Sonique)
SQR Structured Query Language (SQL) program file
SQZ Compressed archive (SQUEEZE)
SRE Undefined file (Motorola)
SRF Raster graphics file (Sun)
SRM Video game console ROM emulator file
SRP SCript file (QuickLink)
SRZ Source file (DataFlex)
SS Bitmap graphics (Splash)
SSA Video file (Sub Station Alpha)
SSD Datafile (SAS/PC)
SSD01 SAS data sets (Unix)
SSD SAS database (Dos)
SSF Spreadsheet file (Enable)
SSP Datafile (SAS Transport)
ST Source code file (Little SmallTalk)
ST Instrument library (Scream Tracker)
ST Disk Image file (Atari)
ST Stamp file (NeoPaint)
STA Saved state (Reflection 4.0)
STA Stack file (SpinMaker Plus)
STB Stub library (Genus GX Kernel)
STD State transition diagram graphic file (Prosa)
STD Standard script file (LocoScript)
STF Compressed archive (SHRINKTOFIT)
STL Stereolithography file
STM Shorter suffix for .shtml, an HTML file containing a server side include (SSI)
STM Music module (MOD) (Scream Tracker 2)
STM State transition diagram model file (Prosa)
STM Music file (Scream Tracker)
STO Pascal stub OBJ file (Genus GX Kernel)
STP Catia file
STQ Text file (Statistica) (StatSoft Software)
STR Screensaver file
STR Structure list OBJ file (dBase IV Application Generator)
STS Project status information file (Microsoft C/C++)
STS Song file (Music) (Scream Tracker)
STT Taci Pixia palette file
STY Style sheet (Ventura Publisher)
STW Data file (SmartTerm for Windows)
STX Electronic book file (SmarText)
STX Tax form (CA-Simply Tax)
STY Style sheet (Generic text and graphics programs0
SUI Suit library (Simple User Interface Toolkit)
SUM Summary file (Generic)
SUN Rasterfile graphics (Sun)
SUP Supplementary dictionary files (WordPerfect for Windows)
SVD Autosave file for document (WordPerfect for Windows)
SVF Simple Vector Format 2D image (Microstation)
SVG Autosave file for glossary (WordPerfect for Windows)
SVG Scalable vector graphics file (Adobe)
SVP Graphics file (Sonique)
SVS Autosave file for style sheet (WordPerfect for Windows)
SVX Sound file (Amiga 8SVX)
SVX Interchange file format, 8SVX/16SV
SVY Database file (SAVVY/PC)
SW Raw signed Word (16bit) data
SWA Shockwave audio file in Macromedia Director (an MP3 file)
SWF Object (ShockWave Flash)
SWG Swag Packet file (SWAG Reader)
SWP Swap file (DataCAD)
SWP Document backup file (Sprint)
SWP Swap file (DOS)
SXC OpenOfficeCalc file
SY1 Smartpix symbol library (Ami Pro)
SY3 Symbol file (Harvard Graphics 2.0)
SYD Backup of startup files (QEMM)
SYLK Microsoft Excel spreadsheet file
SYM Precompiled header file (Borland C++)
SYM Program symbol table (Generic to compilers)
SYM Symbol file (Harvard Graphics 2.0)
SYN SDSC Synu image file (SDSC Image Tool)
SYN Synonym file (Microsoft Word 5.0)
SYS System file (Generic)
SYS Datafile (SYGRAPH)
SYS Datafile (SYSTAT)
SYS Datafile (SPSS/PC)
SYS System file Device driver or hardware configuration file
SYW Wave file (Yamaha SV-series)
SYW Graphics symbols (Harvard Graphics)
S3I Instrument file (Scream Tracker v 3.0)
S3M 16 channel music file (Scream Tracker v 3.0)
S$$ Temporary sort file (Sprint)
T Source file (TADS)
T Tape archive (TAR) (Without compression)
T Tester symbol file (ReaGeniX code generator)
TAB Table file (MapInfo GIS)
TAB Guitar Tablature file
TAG Query tag name file (DataFlex)
TAH Turbo assembler help file (Borland C++)
TAL Text illustration file (TypeAlign)
TAR Tape Archive
TAR Compressed archive (TAR)
TAZ Gzip/Tape archive (Unix)
TAZ Compressed ASCII archive (TAR)
TAZ Compressed ASCII archive (COMPRESS)
TB1 Font file (Borland Turbo C)
TB2 Font file (Borland Turbo C)
TBF Fax document (Imavox TurboFax)
TBK Interactive multimedia files (Asymetrix Toolbook)
TBK Memo backup file (dBase IV)
TBK Memo backup file (Microsoft FoxPro)
TBK Toolbook file (Asymetrix Toolbook)
TBL Graphics (Native format) (Pagemaker TableEditor)
TBL Table of values (OS/2)
TBS Text elements (Microsoft Word for Windows)
TBX Table (Project Scheduler 4)
TC Configuration file (Turbo C)
TC Configuration file (Borland C++)
TCH Turbo C Help file (Borland C++)
TCL Script in the TCL/TK Language
TCW Drawing file (TurboCAD for Windows)
TD Configuration file (Turbo Debugger for DOS)
TD0 Disk image file (Teledisk)
TD2 Configuration file (Turbo Debugger for WIN32)
TD4 Saved track design (Roller Coaster Tycoon)
TDB Database file (Thumbs Plus)
TDB Database file (TACT)
TDDD A file format use by the Imagine & Turbo Silver ray-tracers
TDF Font file (TheDraw)
TDF Typeface definition file (Speedo)
TDH Help file (Turbo Debugger0
TDK Keystroke recording file (Turbo Debugger)
TDS Symbol table (Turbo Debugger)
TDW Configuration file (Turbo Debugger for Windows)


---------------------------------------------------------------------------------------------------

TEF Fax document (Relisys TEFAX)
TEL Hostfile (Telnet)
TEM Turbo Editor Macro Language script (Borland C++)
TEM Input template (IconAuthor)
TEX Texture file
TEX TEX text file (Scientific Word)
TEX Datasheet file (Idealist)
TF Configuration file (Turbo Profiler)
TFA Area file (Turbo Profiler)
TFC Catalogue file (Tobi Floppy Disk Cataloguer)
TFH Help file (Turbo Profiler)
TFM Form file (Form Tool Gold)
TFM TeX font metrics file (TeX)
TFM Tagged font metric file (TeX)
TFS Statistics file (Turbo Profiler)
TFW ArcView World file for TIF image (GIS application)
TG1 Project file (On Target)
TGA Targa bitmap (Adobe Acrobat,TrueVision)
TGA Targa bitmap (Countour Mortgage Loan Format)
TGA Winpoint Loan file (Microsoft Excel)
TGQ Movie file (Dungeon Keeper 2) (Bullfrog Software)
TGV Video file (Electronic Arts) (Need for Speed I/II/III, NBA 96)
TGZ Gzip/Tape archive (Unix)
THAI Husquvania sewing machine file
THEME Desktop theme (Microsoft Windows 9.x)
THM Thumbnail image file (Microsoft Clip Gallery v.1.x)
THN Thumbnail (Graphics Workshop for Windows)
THS Thesaurus dictionary (WordPerfect for Windows)
TIF Tag image bitmap file (TIFF)
TIFF Tag image bitmap file (TIFF)
TIG Map file (Tiger) (Used by the US Government to distribute Map files)
TIL Fuzzy Logic knowledge base file (Togai InfraLogic Fuzzy-C Compiler)
TIM Texture/Image file (Playstation)
TIS Tile set (MahJongg 3.0)
TJF backup files (VAXTPU Editor)
TLB OLE type library files (Microsoft)
TLB Reference table (Bubble Editor)
TLB Text library (VAX)
TLB Type library (Visual C++)
TLC Compiled tool command language source code file (Swat)
TLE Two-Line element set (NASA)
TLP Project timeline file (Microsoft Project)
TLX Data file (Trellix)
TMD TextMaker document from SoftMaker
TMF Tagged font metric file (WordPerfect for Windows)
TMO Ztg global optimizer default optimizer file (Zortech C++)
TMP Temporary file (Microsoft Windows) (ALL)
TMS Script file (Telemate)
TNV Data file (BitWare)
TOC Table of contents file (Eudora Mailbox)
TOL Image file (Kodak Photo Enhancer)
TORRENT BitTorrent file
TOS The Operation System for Atari line of 16/32 and 32/32 computers
TOS Self-Extracting archive (Atari ST)
TP Configuration file (Turbo Pascal)
TP Sesson-state file (Turbo Profiler)
TP4 Saved picture file (Roller Coaster Tycoon)
TPB Downloadable PCL Soft font file backup (HiJaak)
TPF Downloadable PCL Soft font file (HiJaak)
TPH Help file (Turbo Pascal)
TPL Residents units library (Turbo Pascal)
TPL Template file ( Cakewalk Audio)
TPL Template file (Harvard Graphics 2.0)
TPL Template file (DataCAD)
TPL Encrypted lesson file (TutorPro)
TPP Project file (Teleport Pro)
TPP Protected mode units (Borland Pascal 7.0)
TPU Turbo Pascal Unit (Turbo Pascal)(BGI)
TPU Command file (VAXTPU Editor)
TPV Packed graphics file (TutorPro)
TPW Session-state file (Turbo Profiler for Microsoft Windows)
TPW Packed wave files (TutorPro)
TPW Turbo Pascal Unit (BGI) (Turbo Pascal for Windows 9.x)
TPX Image file (ULead Photo Express)
TPZ Compressed archive (TAR)
TPZ Compressed archive (GNUzip)
TP3 Template file (Harvard Graphics)
TR Session-state settings (Turbo Charge Debugger for DOS)
TR2 Session-state settings (Turbo Charge Debugger for Win32)
TRA Saved game file (Coaster)
TRC Debug support file (Power CTrace)
TRE Directory tree file (PC-Tools)
TRK Script file (Kermit)
TRM Terminal file (Generic)
TRM Terminal settings file (Microsoft Windows 3.x)
TRN Translation support file (Quattro Pro)
TRN Project usage log (MKS Source Integrity)
TRS Executable file (MicroGraphix)
TRW Session-state settings (Turbo Debugger for Windows)
TS HDTV sample file (Transport Stream MPEG-2 video stream)
TSH Broderbund Creatacard Transfer Project
TSK Compaq iPaq picture image
TST Printer test file (WordPerfect for Windows)
TSV Tab-separated values file
TTF TrueType font (Generic)
TTK Translation tool kit file (Corel Catalyst)
TTO Client access data specification file (AS/400) (Server to Client)
TUV Tutorial file (Many programs use this suffix for their tutorials) (Generic)
TV Table view settings (Paradox)
TV1 Overflow file above insert point in document 1 (WordPerfect for Windows)
TV2 Overflow file above insert point in document 2 (WordPerfect for Windows)
TV3 Overflow file above insert point in document 3 (WordPerfect for Windows)
TV4 Overflow file above insert point in document 4 (WordPerfect for Windows)
TV5 Overflow file above insert point in document 5 (WordPerfect for Windows)
TV6 Overflow file above insert point in document 6 (WordPerfect for Windows)
TV7 Overflow file above insert point in document 7 (WordPerfect for Windows)
TV8 Overflow file above insert point in document 8 (WordPerfect for Windows)
TV9 Overflow file above insert point in document 9 (WordPerfect for Windows)
TVF Table view settings (dBase IV)
TWF Data file (TABWorks)
TWW Template file (TagWrite)
TX8 MS-DOS text
TXB Encoded briefing file (Descent/D2)
TXF Compressed archive (TAR)
TXF Compressed archive (FREEZE)
TXF Tax exchange format (Quicken and others)
TXI Support file (TeX)
TXT ASCII text-formatted data
TXW Wave file (Yamaha TX16W)
TYM Time Stamp files (PageMaker 4.0)
TZ Old compression file (TAR), (COMPRESS)
TZB Compressed archive (Tar)
T2T Modeling software file (Sonata CAD)
T44 Temporary file for sorting index (dBase IV)
T64 Emulator tape image file (Commodore 64)

UAP User agent profile (Used by wireless telephony applications)
UB Raw unsigned byte (8-bit) data
UC2 Compressed archive (UltraCompressor II)
UCN New compressed archive (UltraCompressor II)
UDF Unique Database (Microsoft Windows NT)
UDF Image filter (Photostyler)
UDW Raw unsigned doubleword (32-bit) data
UE2 Encrypted archive (UltraCompressor II)
UFO Object file (Ulead)
UG Drawing file (AutoCAD and others)
UHS Binary file (Universal Hint System)
UI Espire source code (Geoworks UI Compiler)
UI User interface file (Sprint)
UIF Long prompts for Microsoft Windows (WordPerfect for Windows)
UIH Espire header file (Geoworks UI Compiler)
UL Audio file (ULAW)
ULAW (CCITT G.711) audio (US Telephony)
ULD Uploaded file information (Procomm Plus)
ULT Music module (MOD) (UltraTracker)
UMB Backup file (archive) (MemMaker)
UNI UniMod music module (MOD) (MikMod)
UNI Datafile (Forcast Pro)
UNX Text file (Unix specific information)
UPD Updated program data (Generic)
UPD Updated program data (dBase)
UPI Program file (ULead Photo Impact)
UPO Compiled updated datafile (dBase)
UPX Saved Image file (ULead Photo Express)
URF Universal radar format (Radar ViewPoint)
URL Internet shortcut file (Universal Resource Locator)
USE Source Integrity file (MKS)
USP Printer font w/updated USACII extended character set (Pagemaker)
USR User database file (Procomm Plus)
USR Audit trail file (Pro/Engineer)
USR User database file (Turbo C++)
USR User database file (Tour)
UU UU-encoded file
UU Compressed ASCII archive (UUDE/ENCODE)
UUE Executable compressed ASCII archive (UUDE/ENCODE)
UUE UU-encoded file
UW Raw unsigned 16-bit) datafile (Word)
UWF Wave file (UltraTracker)


-------------------------------------------------------------------------------------

V Consistency check support file (ReaGeniX Code Generator)
V Main image input file (Vivid 2.0)
VAL Validity checks/referential integrity checks (Paradox for Windows)
VAL Values list object file (dBase Application Generator)
VAL Asset management document (Milliplex OmniValue)
VAN Animation file (VistaPro)
VAP Annotated speech file (Generic)
VAR Variable file (IconAuthor)
VAR ASCII text file for data dictionary (Sterling Software Groundworks, COOL Business Team Enterprise Model)
VBA VBase file
VBP Project file (Microsoft Visual Basic)
VBR Remote automated registration file (Microsoft Visual Basic)
VBS Script file (Microsoft Visual Basic)
VBW Workspace file (Microsoft Visual Basic)
VBX Custom control file (Microsoft Visual Basic)
VBX Visual basic extension (Microsoft Visual Basic)
VC Include file with color definitions (Vivid 2.0)
VC Spreadsheet (VisaCalc)
VCB Visual COMMBasic or VCBasic macro definition (created with Outsideview)
VCE Unformatted voice file (used by Cool Edit)
VCE Unformatted voice file (Natural Microsystems) (NMS)
VCF Virtual card file (Netscape)
VCF Virtual card file (Many programs use this extension)
VCF Configuration file; defines objects for use with Sense8 WorldToolKit (Vevi)
VCT Class library (Microsoft FoxPro) (MFC)
VCW Visual workbench information file (Microsoft Visual C++)
VCX Class library (Microsoft FoxPro)(MFC)
VDA Targa bitmap
VDA Graphics image (Generic)
VDR Drawing file (ComputerEasy Draw)
VDX Vector graphic file
VDX Virtual device driver
VDX XML for Visio drawing file
VEL 3D drawing file (CAD( (Ashlar)
VEW View file (Clipper 5)
VEW View file (Lotus Approach)
VFL Clip art file (PrintMaster Gold)
VFM Voting form (Voter)
VFN Voting form for customers (VFN)
VGA Video graphics array (Monitor type, also defines if your monitor is compliant with the new (1994) SVGA (Super Video Graphics Array) (SVGA)
VGA Video graphics array (Font type for display on a VGA Monitor)
VGD Visual display driver ( Generic CADD)
VGR Graphics file (Ventura Publisher)
VI Graphics file (Jovian Logic VI)
VI Virtual Instrument file (National Instruments LABView)
VIC Graphics file (Vicar)
VID Shell monitor file (Microsoft DOS v.5)
VID Screen device driver (Microsoft Word)
VID Bitmap graphics (YUV12C M-Motion Frame Buffer)
VID Bethesda video files (Terminator, Future Shock)
VIF Khoros Visualisation image (SDSC Image Tool)
VIFF Khoros Visualisation image (SDSC Image Tool)
VIK Graphics Image (Viking)
VIR File identified as a virus-infected file by Norton AntiVirus and possibly others
VIS Graphics image file (VIS)
VIV Streaming video file (VivoActive)
VIZ dVS/dVISE file (Division)
VLB Library file (Corel Ventura)
VLM Drafting program file (Vellum, by Ashler)
VM Virtual memory file (Geoworks)
VMC Virtual memory configuration file (Adobe Acrobat Reader)
VMD On-line video file (Sierra) (Torin Passage)
VMF Audio file (FaxWorks)
VMF Font characteristics file (Ventura Publishing)
VML Vector markup language (used by Microsoft Office 2000)
VMS Text file with vms specific information
VNC Virtual Network Computing file used by Real and Tight VNC
VO Include file with object definiton (Vivid 2.0)
VOB Encrypted video and audio files used on current DVD (Digital Video Disk)
VOC Audio file (Creative Labs Sound Blaster)
VOC Audio file (Quartet)
VOC Audio file (generated by RCA digital voice recorder)
VOF Object folder (VZ Programmer)
VOX Dialogic audio file coded using ADPCM
VOX Formatted voice file (Natural Microsystems) (NMS)
VOX Audio file (Talking Technology)
VP Publication (Ventura Publisher)
VPG Graphics image file (VPGraphics)
VQA Video files (Westwood Studios)
VQE VQ Locator file (Yamaha Sound)
VQF VQ file (Yamaha Sound) (possible emerging standard)
VQL VQ Locator file (Yamaha Sound)
VRF Configuration file (Oracle 7)
VRM Overlay file (Quattro Pro)
VRML A VRML file
VRP Project file (VXRexx)
VRS Video device driver (WordPerfect for Windows)
VS Include file w/surface definition (Vivid 2.0)
VSD Drawing file (flow chart or schematic)(Shapeware Visio)
VSL Download List file (GetRight)
VSM Simulation model (VisSim)
VSN A Windows 9x/NT ViruSafe version file; used to keep information about all the files in a directory; when a file is accessed, information is compared with the VSN information to ensure that they match
VSP Image sprite (SPX)
VSP Data print file (Schedule Soft)
VSS Stencil file (Shapeware Visio)
VSS Smartshapes image file (Shapeware Visio)
VST Targa bitmap (Generic)
VST Bitmap graphic file (TrueVison Vista)
VSW Workspace file (Shapeware Visio)
VUE Animation file (3D Studio)
VUE View file (dBase IV)
VUE View file (Microsoft FoxPro)
VW Text file (Volkswriter)
VWP Audio MetaSound plug-in (VoxWare Audio Compression Toolkit version 2.02.61)
VWP Audio plug-in (Voxware MetaVoice Toolkit)
VWR File viewer (PC Tools)
VXD Virtual device driver (Microsoft Windows 9.x)
V8 8-bit audio file (CoVox)

W Word chart file (APPLAUSE)
W30 Printer font (AST TurboLaser)
W30 Printer font (Ventura Publisher)
W31 Startup file (Microsoft Windows 3.1)
W3L W3Launch file
W44 Temporary file for Sort or Index (dBase)
WAB Outlook file (Microsoft Outlook, Outlook Express)
WAD Large file for Doom game containing video, player level, and other information
WAL Texture file (Quake 2)
WAS Script source code file (Procomm Plus Aspect)
WAV Waveform sound (Microsoft Windows)
WAX Compiled script file (Procomm Plus Aspect)
WB1 Notebook (QuattroPro for Windows)
WB2 Spreadsheet (QuattroPro for Windows)
WB3 Text file (QuattroPro for Windows)
WBC Image file (Webshots)
WBF Batch file (Microsoft Windows 9.x)
WBK Backup file (Microsoft Word for Windows)
WBL Upload file (Argo Webload II)
WBR WordBar File (Crick Software)
WBT Batch file (WinBatch)
WBT Wordbar template (Crick Software)
WBZ WebShots image
WCD Macro token list file (WordPerfect for Windows)
WCM Macro (WordPerfect fdor Windows)
WCM Data transmission file (Microsoft Works)
WCP Product information description file (WordPerfect for Windows)
WD1 Word Express file
WD2 Database file (Info Select) by (Micro Logic)
WDB Database file (Microsoft Works)
WDF WebArt data file (database file that can be converted for use in many programs)
WDG Warftpd remote daemon file
WDM Microsoft Visual InterDev98 templates Web Project Items file
WEB Web document (Corel Zara)
WEB Web source code file
WFB Bank file (Maui/Rio/Monterey) (Turtle Beack WaveFront)
WFD Drum set (Maui/Rio/Monterey)(Turtle Beach WaveFront)
WFD Audio waveform (WaveForm Manager Pro)
WFL Flowchart file (Winflow)
WFM Windows form (Virtual dBase)
WFN Symbol (Corel Draw)
WFP Program file (Turtle Beach WaveFront)(Maui/Rio/Monterey)
WFT Data file (NICOLET (Old Format), see NRF)
WFX Data file (WinFax)
WG1 Worksheet (Lotus 1-2-3/G)
WG2 Worksheet (Lotus 1-2-3 for O/S2)
WGP Data file (Wild Board Games)
WI Wavelet compressed bitmap (Corel)
WID Width table (Ventura Publisher)
WIF Wavelet image file (see WI)
WIL WinImage file
WIM Wireless identity module (Used by wireless application protocols)
WIN Window file (Microsoft FoxPro)
WIN Window file (dBase)
WIN Window preference file (Pro/Engineer)
WIS Script file (Reynolds & Reynolds) (Stores the results of a database query)
WIZ Wizard file (Microsoft Word)
WIZ Page wizard (Microsoft Publisher)
WK1 Spreadsheet (Lotus 1-2-3 v. 1 and 2)
WK3 Spreadsheet (Lotus 1-2-3 v. 3)
WK4 Spreadsheet (Lotus 1-2-3 v. 4)
WKB Document file (WordPerfect for Windows)
WKE Spreadsheet (Lotus 1-2-3 Educational version)
WKQ Spreadsheet (Quattro Pro)
WKS Spreadsheet (Symphony 1.0)
WKS Worksheet spreadsheet (Lotus 1-2-3)
WKS Document (Microsoft Works)
WKS Workspace file (Xlisp)
WLD REND386/AVRIL file
WLF Upload file (Argo Upload I)
WLK Graphics file (Virtus Walkthrough)
WLL Add-In file (Microsoft)
WMA Audio file in Microsoft Windows Media format (Can be changed to ASF) Siren (Sonic Foundry)
WMC Backup files for startup (MathCAD for Windows)
WMC Macro file (WordPerfect for Windows)
WMC Text file (WordMARC)
WMF Metafile (Microsoft Windows)
WMV Windows Media Player visual/audio file
WMZ Windows Media Player skins file
WN Text file (NeXT WriteNow)
WNF Outline font description file (CorelDRAW)
WOA Swap file (Microsoft Windows 3.x)
WOC Organization chart (Microsoft Windows OrgChart)
WOW Music module (MOD) (Grave Composer)

-------------------------------------------------------------------------------------------------------------


WP Document file (WordPerfect for Windows)
WPA Word processor document (ACT!)
WP4 Document (WordPerfect for Windows 4.0)
WP5 Document (WordPerfect for Windows 5.0)
WP6 Document (WordPerfect for Windows 6.0)
WPD Demo file (WordPerfect for Windows) (ALL)
WPD Document (WordPerfect for Windows)
WPF Document (Enable)
WPF Fax document (WorldPort)
WPF Form file (WordPerfect for Windows)
WPG Microsoft Word for Windows vector graphics (DrawPerfect)
WPG Graphics file (Microsoft Word for Windows)
WPK Macro (Microsoft Word for Windows)
WPM Macro (Microsoft Word for Windows)
WPS Text document (Microsoft Works)
WPT Template (Microsoft Word for Windows)
WPW PerfectWorks document (Novell)
WQ! Compressed spreadsheet (QuattroPro)
WQ1 Spreadsheet (QuattroPro/DOS)
WQ2 Spreadsheet (QuattroPro version 5)
WR1 Symphony file (Lotus)
WR1 Spreadsheet (Symphony 1.1-2)
WRAP MediaForge (XMLAuthor) media content file
WRD Template (Charisma)
WRG ReGet document
WRI Write document (Windows Write)
WRK Project file (CakeWalk Music Audio)
WRK Spreadsheet (Symphony 1.0)
WRL Virtual Reality model
WRP Compressed Amiga archive (WARP)
WRP 3D modeling file (Raindrop Geomagic) (Scandata)
WRS Resource file (Microsoft Word for Windows)
WRZ Another VRML fileject
WS Text file (WordStar)
WS1 Document (WordStar for Windows version 1)
WS2 Document (WordStar for Windows version 2)
WS3 Document (WordStar for Windows version 3)
WS4 Document (WordStar for Windows version 4)
WS5 Document (WordStar for Windows version 5)
WS6 Document (WordStar for Windows version 6)
WS7 Document (WordStar for Windows version 7)
WSD Document (WordStar for Windows 2000)
WSP WorkSpace file (Fortran PowerStation)
WST Document (WordStar for Windows)
WSZ Skin (WinAmp)
WTA Used by wireless telephony applications
WV WavPack lossless compressed audio file
WVL Wavelet Compressed Bitmap
WVW Interleaf WorldView format (a PDF format)
WWB Button bar for document window (WordPerfect for Windows)
WWK Keyboard layout file (WordPerfect for Windows)
WWL Add-in file (Microsoft Word)
WXD Music resource file (Relic Entertainment)(Home World)
WXP Document file (EXP for Microsoft Windows)

AVS image (SDSC Image Tool)
X Source code file (Lex)
XAR Corel Xara drawing
XBM A MIME X11" bitmap image
XCI XML Configuration Information (Adobe enterprise forms product)
XDL XML Schema file
XFD Acu4GL/ACUCOBOL extended file description (from Acucorp)
XFN Printer font file (Xerox)
XFN Printer font file (Ventura Publisher)
XFT Printer font file (24 Pin) (ChiWriter)
XFT XML Forms Template (from Adobe enterprise forms products such as Adobe Forms Designer)
XFX Fax Document (Various)
XHTML eXtensible hypertext markup language
XI Instrument sample file (ScreamTracker)
XI Instrument file (FastTracker II)
XIF Wang imaging file (Included with Windows 95)
XIF Image file (Xerox) (same as TIF)
XIF Image file (Pagis)
XIF Image file eXtended (ScanSoft) the file is similar to TIFF and is a (Pagis) native format
XLA Add-in file (Microsoft Excel)
XLA Archive (Xlib)
XLB Toolbar file (Microsoft Excel)
XLB Datafile (Microsoft Excel)
XLC Chart file (Microsoft Excel)
XLD Dialogue file (Microsoft Excel)
XLK Backup file (Microsoft Excel)
XLL Add-in file (Microsoft Excel)
XLL Dynamic link library (Microsoft Excel)
XLM Macro file (Microsoft Excel)
XLR Microsoft Works spreadsheet or chart
XLS Worksheet file (Microsoft Excel)
XLT Template file (Microsoft Excel)
XLT Translation table (Lotus 1-2-3)
XLT Translation table (Symphony)
XLT Translation table (Procomm Plus)
XLV VBA module (Microsoft Excel)
XLW Workbook (Microsoft Excel)
XM Music module (MOD) (Fast Tracker 2)
XMI Compressed midi music (eXtended)
XML eXtensible markup language
XNF Network file (Standard)
XNK Shortcut file (Microsoft Exchange)
XON Datafile (Axon)
XPM X BitMap format
XQT Executable file (Waffle)
XQT Macro file (SuperCalc)
XXX XXXX
XR1 Data file (Epic Megagames Xargon)
XRF Cross-reference file (Generic)
XSX Schema view layout description file (Microsoft XML Designer)
XTB External translation table (LocoScript)
XTP Data file (Xtree)
XWD X Window Dump format (SDSC Image Tool)
XWF Works file (Yamaha XG) (MIDI sequencing)
XWK Keyboard mapping file (Crosstalk)
XWP Session file (Crosstalk)
XWP Text file (Xerox Writer)
XX Compressed ASCII archive (XXENCODE)
XXE Compressed ASCII archive (XXENCODE)
XY Text file (XYWrite)
XY3 Document file (XYWrite III)
XY4 Document file (XYWrite IV)
XYP Document file (XYWrite III Plus)
XYW Document file (XYWrite for Windows 4.x)
X01 Secondary index file (Paradox)
X02 Secondary index file (Paradox)
X03 Secondary index file (Paradox)
X04 Secondary index file (Paradox)
X05 Secondary index file (Paradox)
X06 Secondary index file (Paradox)
X07 Secondary index file (Paradox)
X08 Secondary index file (Paradox)
X09 Secondary index file (Paradox)
X16 Macromedia Extra (program extension), 16 bit
X32 Macromedia Extra (program extension), 32 bit

Y Grammar file (Yaac)
Y Compressed Amiga archive (YABBA)
YAL Clipart library (Arts & Letters)
YBK Yearbook file (Microsoft Encarta)
YUV Graphics file (YUV)
YZ Compressed file archive (YAC)
Y01 Secondary index file (Paradox)
Y02 Secondary index file (Paradox)
Y03 Secondary index file (Paradox)
Y04 Secondary index file (Paradox)
Y05 Secondary index file (Paradox)
Y06 Secondary index file (Paradox)
Y07 Secondary index file (Paradox)
Y08 Secondary index file (Paradox)
Y09 Secondary index file (Paradox)

Compressed ASCII archive (COMPRESS)
Z Unix file Compressed
ZAP Software installation settings file (Microsoft Windows)
ZAP Compressed file (FileWrangler)
ZDG Compressed text document (Zview)
XDP Label file using Avery DesignerPro Label Design)
ZER Data file (Zerberus)
ZGM Graphics file (ZenoGraphics)
ZIP Zip file Compressed archive
ZOM Compressed Amiga archive (ZOOM)
ZOO An early compressed file format
ZVD Voice file (Zyxel Z-Fax)
Z3 Game module (Infocom)

000 Data file (GEOWorks)
000-20009 Used to number old (backup) versions of files (for example, CONFIG.SYS when changed by an installation program); also used to number related data files for multiple users of a small-scale PC application
1ST Documenting wizard list (Microsoft Visual FoxPro)
001-999 Database index files used by (Superbase)
8 Source file (Assembly) (Similar to Microsoft Assembler)
113 Backup data file (Iomega Backup)
12M Smartmaster file (Lotus 1-2-3 97)
123 Lotus 123 97 file
1-STEP Backup file (Iomega Backup)
2D Two-dimensional drawing file (VersaCAD) (http://www.versacad.com/vcadhome.htm)
2GR and 3GR VGA Graphics driver/configuration files (Microsoft Windows)
3D Three-dimensional drawing file (VersaCAD) (http://www.versacad.com/vcadhome.htm)
3DM 3D NURBS modeler, (Rhino)
3DS A file in 3D Studio (for DOS) format
386 A file for use in an 80386 or higher microprocessor
411 Data file (Used by digital cameras)
4GE Compiled code (Informix 4GL)
4GL Source code (Informix 4GL)
4V Music file (Quartet)
669 Music mod file (Composer 669)(Unis Composer)
669 Tracker module (Composer 669)
#01 and higher A method of numbering picture files for a roll of film that has been scanned for computer presentation
$$$ Used by OS/2 to keep track of archived files
~PR Project backup file (Terramodel)
~$~ Temporary file (1ST Reader)
~AP AppExpert project database file (Borland C++ 4.5)
~DE Project backup file (Borland C++ 4.5)
~MN Menu backup (Norton Commander)
@@@ Screen files used in the installation and instruction on use of such applications as Microsoft Codeview for C

---------------------------------------------------------------------------------------------------

