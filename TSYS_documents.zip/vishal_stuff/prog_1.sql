REM For training only
set echo on

BEGIN
-- This will produce an error the first
-- time it is run since PROG_1 does not exist 

DBMS_SCHEDULER.DROP_PROGRAM (
   program_name           => '"SYSTEM"."PROG_1"');
END;
/
BEGIN
DBMS_SCHEDULER.CREATE_PROGRAM(
program_name=>'"SYSTEM"."PROG_1"'
,program_action=>'DECLARE
 time_now DATE;
BEGIN
 INSERT INTO test_log VALUES(''LWT'',''DONE'',SYSTIMESTAMP);
END;'
, program_type=>'PLSQL_BLOCK'
, number_of_arguments=>0,
comments=>'Insert a timestamp into the test_log'
,enabled=>TRUE);
END;
/
