SET DEFINE OFF;
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (659, 12920187, 15012399, TO_DATE('03/02/2009 22:52:44', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:21:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db Team,\n \nPlease process this request..\n \nRegards,\nNitin\n \nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: Joan Lomelo \nSent: Monday, March 02, 2009 11:47\nSubject: Merge - Silvia Mihilli\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (658, 4618798172, 117714899, TO_DATE('03/02/2009 22:37:50', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 00:01:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Narendra/Milind,\n \nPlease  process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 10:22\nSubject: Merge - Judith Koerner\n\n\nThanks!\n', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (660, 4618980994, 6892030631, TO_DATE('03/02/2009 23:04:12', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 05:52:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi DB Team,\n \nPlease could you process the request...\n \nRegards,\nNitin\n \nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 16:15\nSubject: Merge - Sallee Kosterman\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (662, 4618980994, 4218483233, TO_DATE('03/02/2009 23:04:13', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 05:52:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi DB Team,\n \nPlease could you process the request...\n \nRegards,\nNitin\n \nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 16:15\nSubject: Merge - Sallee Kosterman\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (663, 4618980994, 15427813, TO_DATE('03/02/2009 23:04:13', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 05:52:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi DB Team,\n \nPlease could you process the request...\n \nRegards,\nNitin\n \nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 16:15\nSubject: Merge - Sallee Kosterman\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (661, 4618980994, 6999530819, TO_DATE('03/02/2009 23:04:12', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 05:52:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi DB Team,\n \nPlease could you process the request...\n \nRegards,\nNitin\n \nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 16:15\nSubject: Merge - Sallee Kosterman\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (657, 4649556854, 15764848, TO_DATE('03/02/2009 22:33:41', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/02/2009 23:39:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Gaurav,\n \nPlease can you process this request...\n \nRegards,\nNitin\n \nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 10:06\nSubject: Merge - Skipper Stevens\n\n\nThanks!\n', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (664, 4890468497, 15573976, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (665, 4890468497, 17296674, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (666, 4890468497, 4649209185, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (667, 4890468497, 4790695826, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (668, 4890468497, 7011703, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (669, 4890468497, 14995083, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (670, 4890468497, 15776335, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (671, 4890468497, 4618648320, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (672, 4890468497, 4890362424, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
Insert into MERGECUSTCODE.MERGING_CUSTOMERCODE
   (serial_number, customer_code, duplicate_custcode, timestamp, requested_by, requested_date, comments, status, completion_date)
 Values
   (673, 4890468497, 7000152031, TO_DATE('03/03/2009 01:25:10', 'MM/DD/YYYY HH24:MI:SS'), 'Molly Windle', 
    TO_DATE('03/03/2009 01:04:00', 'MM/DD/YYYY HH24:MI:SS'), 'Hi Db team,\n \nPlease process this request..\n \nRegards,\nSumit\nInOC�\nInfonox Operations Center\n----- Original Message ----- \nFrom: Windle, Molly \nTo: InOC \nCc: sallen ; Joan Lomelo \nSent: Monday, March 02, 2009 11:29\nSubject: Merge - Ian Jones\n\n\nThanks!', 'N', NULL);
COMMIT;



CREATE OR REPLACE PROCEDURE REMINDERMAIL_CUSTCODE_MERGING
AS
    v_Connection                        UTL_SMTP.Connection;
    v_reply                             UTL_SMTP.REPLY;

    Message                             VARCHAR2(20000);
    crlf                                VARCHAR2(2):=CHR(13)||CHR(10);
    
    v_Sender                            VARCHAR2(1000);
    v_Recipient                         VARCHAR2(1000);
    v_Subject                           VARCHAR2(1000);
    v_Body                              VARCHAR2(20000);
    
    v_Body1                             VARCHAR2(20000);

    v_cc_recipt1                        VARCHAR2(1000);
    v_cc_recipt2                        VARCHAR2(1000);
    v_cc_recipt3                        VARCHAR2(1000);
    
----
    v_Customer_Name                     VARCHAR2(10000); -- customer's full name(<first_name>||' '||<Last_Name>)
    
    v_mail_flag                         VARCHAR2(10):='N'; -- this will be Y when merging process will come
    
    v_errorflag                         VARCHAR2(1000);
BEGIN
    
    
    v_Sender     := 'db_dev@infonox.com';              -- sender will be InOC
    v_Recipient  := 'rahulc@infonox.com';              -- TO: db_dev

    FOR i IN (SELECT Serial_Number, Customer_Code, Duplicate_Custcode 
              FROM MERGING_CUSTOMERCODE 
              WHERE STATUS='N' 
              ORDER BY Customer_Code)
    LOOP
        
            SELECT FirstName||' '||LastName
            INTO v_Customer_Name
            FROM QCP.Customers
            WHERE Customercode = i.Customer_Code;
            
            v_Body    := 'Customer Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:= <b><font color="red">'||v_Customer_Name||'</font></b><br>'||
                         'Duplicate CustomerCode&nbsp;:= <b><font color="red">'||i.Duplicate_Custcode||'</font></b><br>'||
                         'Correct CustomerCode&nbsp;&nbsp;&nbsp;:= <b><font color="red">'||i.Customer_Code||'</font></b>';
             
            v_Body1 := v_Body1||' '||'<br><br>'||v_Body;
            
            v_mail_flag:='Y';
            
    END LOOP;
    

    IF v_mail_flag = 'Y' THEN
        
        v_Subject := 'Remainder mail for customer code merging process';
        
        v_Body := 'Hi All,<br><br>'||
                  '&nbsp;&nbsp;&nbsp;&nbsp; Below are the Customer Code which are given for Merge.'||
                   v_Body1 ||'<br><br> Merging process for above records will begin after 60 mins, Please reverify the inputs, If any detail are wrong then please inform DB team.'||
                  '<br><br>Regards<br>'||'- DB Team';


        v_cc_recipt1  := 'dba_pune@infonox.com';
        -- v_cc_recipt2  := 'narendra@infonox.com'; open if required
      
        -- smpt.ifxlv.com connection is opened here
        v_Connection := UTL_SMTP.OPEN_CONNECTION('smtp.ifxlv.com',25) ;
        v_reply      := UTL_SMTP.HELO(v_Connection,'smtp.ifxlv.com') ;        
        
        v_reply      := UTL_SMTP.MAIL(v_Connection,v_Sender);
        v_reply      := UTL_SMTP.RCPT(v_Connection,v_Recipient);


        IF v_cc_recipt1 IS NOT NULL OR v_cc_recipt2 IS NOT NULL  THEN
            UTL_SMTP.rcpt(v_Connection,v_cc_recipt1);
            --UTL_SMTP.rcpt(v_Connection,v_cc_recipt2);
        END IF;
        
        BEGIN
        
       Message := 'From: '||v_Sender||crlf|| 
                   'To: '||v_Recipient||crlf||
                   'Cc: '||v_cc_recipt1||crlf||
                   'Subject: '||v_Subject||crlf||''||crlf||v_Body;
        EXCEPTION
          WHEN OTHERS THEN
            v_errorflag:=SUBSTR(SQLERRM,1,100);
        END;

        UTL_SMTP.DATA(v_Connection,'MIME-Version: 1.0'||crlf||'Content-type: text/html' || crlf||Message);
        UTL_SMTP.QUIT(v_Connection);
    END IF;
END REMINDERMAIL_CUSTCODE_MERGING;
/
