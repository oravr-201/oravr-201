REM "******************************************* "
REM "  * Setup for Flashback Transaction"
REM "Execute script as SYSDBA" 

set echo on
set serveroutput on
set term on
set lines 200
set pause on

/*== Set up the HR database account for this OBE ==*/

ALTER DATABASE ADD SUPPLEMENTAL LOG DATA;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (PRIMARY KEY) COLUMNS;
GRANT EXECUTE ON dbms_flashback TO hr;
GRANT select any transaction TO hr;
pause Press [Enter] to exit...

exit
