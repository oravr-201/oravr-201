

When Things Look Bad!

If you have a process/script that shows poor performance you should do the following:

1] Write sensible queries in the first place! 
2] Identify the specific statement(s) that are causing a problem. The simplest way to do this usually involves 
   running the individual statements using SQLPlus and timing them (SET TIMING ON) 
3] Use EXPLAIN to look at the execution plan of the statement. Look for any full table accesses that look 
   dubious.Remember, a full table scan of a small table is often more efficient than access by rowid. 
4] Check to see if there are any indexes that may help performance. A quick way to do this is to run 
   the statement using the Rule Based Optimizer (RBO) (SELECT /*+ RULE */ ). Under the RBO, if an 
   index is present it will be used. The resultant execution plan may give you some ideas as to 
   what indexes to play around with. You can then remove the RULE hint and replace it by the 
   specific index hints you require. This way, the CBO will still be used for table accesses 
   where hints are not present. Remember, if data volumes change over time, the hint  
   that helped may become a hindrance! For this reason, hints should be avoided if 
   possible, especially the /*+ RULE */ hint. 
5] Try adding new indexes to the system to reduce excessive full table scans. Typically, 
   foreign key columns should be indexed as these are regularly used in join conditions. On occasion it 
   may be necessary to add composite (concatenated) indexes that will only aid individual queries. Remember, 
   excessive indexing can reduce INSERT, UPDATE and DELETE performance. 
