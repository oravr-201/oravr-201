REM   For demo purposes ONLY
REM   Execute script as HR user 

SELECT employee_id, last_name, salary
FROM   hr.employees AS OF TIMESTAMP 
       (SYSTIMESTAMP - INTERVAL '15' MINUTE)
WHERE  last_name = 'Fox';

