Clust Name : w-transitdb-rpt
SCAN Name  : w-transitdb-rpt.tsysacquiring.org

ASM and sys password: Wpl1trandbrpt$123
Oracle SYS : Wpl1trandb$123


SYSTEM : Wpl1transitrpt$123


cd /acfs/goldengate
/acfs/goldengate/ggsci
