#!/bin/sh 
#
# Run as: oracle
#
# Written by: Tom Best

echo Setting up ORCL environment. 
. oraenv <<-EOI
orcl
EOI
echo Setting to NOARHIVELOG mode
~/labs/orcl_to_noarchivelog.sh

echo Creating pfile
sqlplus / as sysdba <<-EOI
	create pfile = '/tmp/pfile_for_clone.ora' from spfile;
	exit
EOI

echo Removing quotes
# Remove all single quotes. Also, comment out the one parameter setting
# that has single quotes that cannot be removed.
cat /tmp/pfile_for_clone.ora | sed s/\'//g | sed s/"*.dispatchers"/"#*.dispatchers"/ | sed s/"*.control_files"/"#*.control_files"/ >/tmp/pfile_for_clone2.ora

echo "*.control_files=/tmp/ctl.bak" >>/tmp/pfile_for_clone2.ora

echo restarting with pfile
sqlplus / as sysdba <<-EOI
	shutdown immediate
	startup pfile='/tmp/pfile_for_clone2.ora'
	exit
EOI
echo Shutting down RCAT instance
sqlplus sys/oracle@rcat as sysdba <<-EOI
	shutdown immediate
	exit
EOI

exit
