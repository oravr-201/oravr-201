CREATE OR REPLACE TRIGGER SYSTEM.DATABASE_DDL_TRIG 
BEFORE DDL ON DATABASE
DECLARE 
    v_Os_User        VARCHAR2(30);
    v_Program        VARCHAR2(500);
BEGIN 

-- PLEASE do not drop / modifiy the trigger, RahulC had created this trigger

    SELECT SYS_CONTEXT('USERENV', 'OS_USER')OS_USER, UPPER(SYS_CONTEXT('USERENV', 'MODULE'))
    INTO v_Os_User, v_Program
    FROM dual;
    
    IF UPPER(v_Os_User) IN ('MAHESH','DEBARGHA', 'KARAN', 'TARANNUM', 'NITIN',  'NIRAV', 'DEVESH', 'DHARMESH', 
    						'VAIBHAV', 'UDAY', 'AMOL', 'SURENDER', 'SUMEET', 'IMRAN') 
            AND (v_Program IN ('SQL*PLUS','DREAMCODER','DBSAINT.EXE','SQL DEVELOPER') OR v_Program LIKE 'TOAD%') THEN
         
         -- raising application error    
         RAISE_APPLICATION_ERROR (-20000, '"'||UPPER(v_Os_User)||'" Please do not execute any DDL commands, Please Contact Your DBA');
         
    END IF;
END;
/


