#!/bin/sh
#
# Run as: oracle
# This turns on AUTOBACKUP of controlfiles.
#
# Written by: Tom Best
export ORACLE_SID=orcl
rman target / catalog rcatowner/oracle@rcat <<-EOI
  configure controlfile autobackup on;
  quit
EOI
exit
