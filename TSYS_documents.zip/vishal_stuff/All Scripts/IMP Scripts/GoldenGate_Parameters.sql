
-- mgr parameter same on both Primary and reporting DBs..
GGSCI>> edit params mgr
PORT 15001
DYNAMICPORTLIST 15002-15025
PURGEOLDEXTRACTS /opt/app/goldengate/dirdat/*, USECHECKPOINTS, MINKEEPDAYS 2
AUTORESTART ER *, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30
-->> End of File */


-->> GLOBALS parameters same on Primary and Reporting DBs...
GGSCI>> edit params ./GLOBALS
GGSCHEMA ggate
CHECKPOINTTABLE GGATE.CHECKPOINT
ENABLEMONITORING
-->> End of File


-->> extract parameter epte 
GGSCI>> edit params eptw
-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
-- CHECKPARAMS

-- Last modified 05/24/2013  William Kendall
-- GoldenGate Extract Parameter File (EPTW.prm)
-- Extracts all objects for all of the Schemas in the Source.
--
-- Set the runtime attributes for an Extract which reads
-- Oracle Redo/Archive logs for change data capture and stores
-- this data locally.

-- EXTRACT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (EPTW.prm) must exist in the
-- dirprm directory/folder.
EXTRACT EPTW

-- EXTTRAIL indentifies the local directory/folder and
-- file identifier where Extract will write its data. When the
-- file is created on disk, six digits are appended to the two
-- character identifier; starting with 000000. As the file reaches
-- maximum capacity a new file is created and Extract rolls to that
-- new file. A maximun of 999999 Extract Trail files may exist
-- per GoldenGate Extract.
EXTTRAIL /opt/app/goldengate/dirdat/LA

-- This area is used for creating and monitoring environments
-- Must set environments
-- If you change servers you will need to change SID
-- IF fails, do a view report SEVICE-NAME to see env
SETENV (ORACLE_SID  = "txnDCW1")
SETENV (ORACLE_HOME = "/opt/app/oracle/product/11.2.0/db_1")

-- Import Language Settings
-- SETENV (NLS_LANG="AMERICAN_AMERICA.US7ASCII")

-- The login credentials GoldenGate is to use to access the database.
USERID ggate, PASSWORD tsys123

-- Eable this for by-Directional replication
-- TRANLOGOPTIONS EXCLUDEUSER GGATE COMPLETEARCHIVEDLOGTIMEOUT 600

-- Enable this for single replication
TRANLOGOPTIONS DBLOGREADER

-- DDL Parameter
--DDL INCLUDE MAPPED;
DDL INCLUDE ALL

-- Add Trandata for DDL
DDLOPTIONS report, ADDTRANDATA


-- THREADOPTIONS PROCESSTHREADS SELECT 1
-- THREADOPTIONS PROCESSTHREADS SELECT 2
DBOPTIONS ALLOWUNUSEDCOLUMN
--DBOPTIONS ALLOWNOLOGGING

--------------------------------------------------------------------------------------------------
-- Reports

-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 00:01

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 00:01

-- REPORTCOUNT denotes that every 60 seconds the Extract report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE

-- End of "best practices" section
--------------------------------------------------------------------------------------------------

GETTRUNCATES


-- Sequence Parameter
-- and must be terminated with a semi-colon. Each table must be listed; however,
-- wildcards are allowed, with the * wildcard denoting all tables in the database.

-- sequence mapping
SEQUENCE KEYNOX_FX.*;
SEQUENCE TRANSNOX_CPASS.*;
SEQUENCE SNOX4TRANSNOX_CPASS.*;

--exclude Tables

-- List of Mother schemas
TABLEEXCLUDE TRANSNOX_CPASS.MV*
TABLEEXCLUDE TRANSNOX_CPASS.DBMS_TABCOMP_TEMP_UNCMP
TABLE TRANSNOX_CPASS.*;

TABLEEXCLUDE SNOX4TRANSNOX_CPASS.MV*
TABLE SNOX4TRANSNOX_CPASS.*;

TABLEEXCLUDE KEYNOX_FX.MV*
TABLE KEYNOX_FX.*;

-- Currently Used VBS Schemas
TABLEEXCLUDE SNOXPASS_SMSNOX_305.MV*
TABLE SNOXPASS_SMSNOX_305.*;

TABLEEXCLUDE TNOXPASS_SMSNOX_305.MV*
TABLE TNOXPASS_SMSNOX_305.*;

TABLEEXCLUDE SNOXPASS_GWAY_010.MV*
TABLE SNOXPASS_GWAY_010.*;

TABLEEXCLUDE TNOXPASS_GWAY_010.MV*
TABLE TNOXPASS_GWAY_010.*;

TABLEEXCLUDE TNOXPASS_TFE_2015.MV*
TABLE TNOXPASS_TFE_2015.*;

TABLEEXCLUDE SNOXPASS_TFE_2015.MV*
TABLE SNOXPASS_TFE_2015.*;

-- List of New VBS schemas
TABLEEXCLUDE SNOXPASS_GWAY_012.MV*
TABLE SNOXPASS_GWAY_012.*;

TABLEEXCLUDE TNOXPASS_GWAY_012.MV*
TABLE TNOXPASS_GWAY_012.*;

TABLEEXCLUDE TNOXPASS_TFE_2016.MV*
TABLE TNOXPASS_TFE_2016.*;

TABLEEXCLUDE SNOXPASS_TFE_2016.MV*
TABLE SNOXPASS_TFE_2016.*;

TABLEEXCLUDE TNOXPASS_SMSNOX_306.MV*
TABLE TNOXPASS_SMSNOX_306.*;

TABLEEXCLUDE SNOXPASS_SMSNOX_306.MV*
TABLE SNOXPASS_SMSNOX_306.*;
-->> End of File



-- extract parameter dpump
GGSCI>> edit params pptw
-- Tsys
--
-- Set the runtime attributes for an Exract Data Pump which reads
-- from a local Extract Trail, then transmits the data to a Remote
-- file location (RMTTRAIL) on the target GoldenGate server..
--

-- EXTRACT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (PPTW.prm) must exist in the
-- dirprm directory/folder.
EXTRACT PPTW

-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
-- CHECKPARAMS

-- RMTHOST defines the target server Extract will transmit to.
-- <host/ipaddress> is the target server DNS name, or configured
-- tcp/ip address. MGRPORT is the GoldenGate Manager
-- Listener port configured in the target mgr.prm file. COMPRESS
-- states that outgoing blocks of records are to be compressed to
-- reduce bandwidth requirements. A 4:1 compressioin ratio, or more
-- is not uncommon; however additional CPU resource is required for
-- compression on the source side, and decmpression on the target.
-- Replace <host/ipaddress> with the target GoldenGate server
-- name or ip address.
RMTHOST loadrpdbnode1.tsysacquiring.org, MGRPORT 15001, COMPRESS

-- RMTTRAIL indentifies thedirectory/folder and file identifier on the
-- target server where Extract will write its data. When the
-- file is created on disk, six digits are appended to the two
-- character identifier; starting with 000000. As the file reaches
-- maximum capacity a new file is created and Extract rolls to that
-- new file. A maximun of 999999 Extract Trail files may exist
-- per GoldenGate Extract; however, each file name set must be
-- unique for the server where the Extract runs.
RMTTRAIL /opt/app/goldengate/dirdat/RA

-- PASSTHRU denotes that the Extract does not evaluate the data,
--meaning that it does not log into the database and lookup the table
-- definitions. The data is read and passed through to the target server.
PASSTHRU

--------------------------------------------------------------------------------------------------
-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 00:01

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 00:01

-- REPORTCOUNT denotes that every 60 seconds the Extract report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE

-- End of "best practices" section
--------------------------------------------------------------------------------------------------

---Sequences
--SEQUENCE KEYNOX_FX.*;
SEQUENCE TRANSNOX_CPASS.*;
SEQUENCE SNOX4TRANSNOX_CPASS.*;

TABLE KEYNOX_FX.*;
TABLE TRANSNOX_CPASS.*;
TABLE SNOX4TRANSNOX_CPASS.*;

-- Currently used VBS
TABLE SNOXPASS_SMSNOX_305.*;
TABLE TNOXPASS_SMSNOX_305.*;
TABLE SNOXPASS_GWAY_010.*;
TABLE TNOXPASS_GWAY_010.*;
TABLE TNOXPASS_TFE_2015.*;
TABLE SNOXPASS_TFE_2015.*;

-- List of New VBS Schemas
TABLE SNOXPASS_GWAY_012.*;
TABLE TNOXPASS_GWAY_012.*;
TABLE TNOXPASS_TFE_2016.*;
TABLE SNOXPASS_TFE_2016.*;
TABLE TNOXPASS_SMSNOX_306.*;
TABLE SNOXPASS_SMSNOX_306.*;
-->> End of File

-- create the Goldengate DB user login script
GGSCI (loadtxdbnode1.tsysacquiring.org) 19>  shell vi dirsql/dblogin.sql
dblogin userid ggate, password tsys123
-->> End of File

-- execute belo command to login to goldengate DB
GGSCI (loadtxdbnode1.tsysacquiring.org) 19>  obey dirsql/dblogin.sql


-- create source script
GGSCI (loadtxdbnode1.tsysacquiring.org) 18> shell vi dirsql/CreateSource.oby
ADD EXTRACT EPTW,TRANLOG, THREADS 3, BEGIN NOW
ADD EXTTRAIL /opt/app/goldengate/dirdat/LA, EXTRACT EPTW, MEGABYTES 100

ADD EXTRACT PPTW, EXTTRAILSOURCE /opt/app/goldengate/dirdat/LA
ADD RMTTRAIL /opt/app/goldengate/dirdat/RA, EXTRACT PPTW, MEGABYTES 100
-->> End of File


-- will execute the script
GGSCI (loadtxdbnode1.tsysacquiring.org) 18> obey dirsql/CreateSource.oby




GGSCI (loadtxdbnode1.tsysacquiring.org) 31> edit params rdcw1
--
--
--
-- Last Modified 05/22/2013 William Kendall
-- GoldenGate Replicat Parameter File (RPRW.prm)
--
-- Set the runtime attributes for a Replicat which reads
-- from a GoldenGate Remote Trail and applies the data
-- to a target set of tables
--

-- REPLICAT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (RPRW.prm) must exist in the
-- dirprm directory/folder.
REPLICAT RDCW1

-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
-- CHECKPARAMS

-- Set environment
-- This area is used for creating and monitoring environments
-- Must set environments
-- If you change servers you will need to change SID
-- IF fails, do a view report SEVICE-NAME to see env
 SETENV (ORACLE_SID  = "txnDCW1")
 SETENV (ORACLE_HOME = "/opt/app/oracle/product/11.2.0/db_1")

-- Import Language Settings
-- SETENV (NLS_LANG="AMERICAN_AMERICA.US7ASCII")

-- The login credentials GoldenGate is to use to access the database.
USERID ggate, PASSWORD tsys123

-- The ASSUMETARGETDEFS means that the target table schema is
-- the same as the source. For this to be valid, the column names,
-- and data types, are the same and they appear in the same order
-- as the source tables.
ASSUMETARGETDEFS


-- DBOPTIONS SUPPRESSTRIGGERS parameter to prevent triggers on target
-- when user is GoldenGate user (oraclegg). Package
-- dbms_goldengate_auth.grant_admin_privilege must be run for GoldenGate user
--    exec dbms_goldengate_auth.grant_admin_privilege(grantee => 'ORACLEGG', grant_select_privileges => TRUE);
DBOPTIONS SUPPRESSTRIGGERS

-- DDLERROR is a catch all for DDL to just ignore all DDL errors.
-- use this only for troubleshooting
--DDLERROR default ignore

DDLERROR DEFAULT IGNORE

-- DDL Parameter
DDL INCLUDE ALL EXCLUDE OBJNAME "TRANSNOX_IOX.REPORT_USAGE_SEQ" EXCLUDE OBJNAME "TRANSNOX_CPASS.REPORT_USAGE_SEQ"


-- The DISCARD file is where Replicat writes transaction information
-- when it encounters a data issue
DISCARDFILE /opt/app/goldengate/dirrpt/RDCW1.dsc, APPEND, MEGABYTES 500

-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 00:01

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 00:01

-- REPORTCOUNT denotes that every 60 seconds the Replicat report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE

-- End of "best practices" section

-- Overlap Mode Processing
-- Handlecollisions and End Runtime are to be used only when the target
-- database is being instantiated. Once the initial load extract and replicat
-- complete, we start change data replicat with these options.
-- Handlecollisions sets the replicat to ignore missing data in the target
-- and to overlay the row if it already exists.
-- End Runtime sets replicat to terminate normally whenever it encounters
-- a record that matches, or is after the process start time.
-- Never, never set this is a running production environment!
--HANDLECOLLISIONS
--END 2012-06-20 15:56:00
--END 2010-06-15 09:45:00

ALLOWNOOPUPDATES
--
-- The MAP statement sets the correlation between the source and
-- target tables. The source schema and tables are identified on the left
-- hand side of the statement and the target schema and tables are
-- identified after the keyword TARGET. Wildcards are allowed, and the
-- * wildcard denotes all tables. The MAP statement must be terminated
-- by a semi-colon.
-- MAP WEBRATER_OWNER.QUOTE, TARGET WEBRATER_OWNER.QUOTE, FILTER (@RANGE(1, 3));
--MAPEXCLUDE SCOTT.DEPT

REPERROR (-1403, DISCARD)
REPERROR (DEFAULT, EXCEPTION)
REPERROR (DEFAULT2, EXCEPTION)
REPERROR (-1, EXCEPTION)
-- Handling GoldenGate Exceptions and Errors with REPERROR

-- By default, Oracle GoldenGate synchronizes insert, update, and delete operations. You can
-- use the following parameters in the Extract or Replicat parameter file to control which
-- kind of operations are processed, such as only inserts or only inserts and updates.
-- IGNOREINSERTS | GETINSERTS
-- IGNOREUPDATES | GETUPDATES
-- IGNOREDELETES | GETDELETES
--- If you want to ignore DELETE DML on any table


-- List of Mother Schemas
MAPEXCLUDE TRANSNOX_CPASS.REPORT_USAGE_AUDITTRAIL
MAP TRANSNOX_CPASS.*, TARGET TRANSNOX_CPASS.* ;
MAP SNOX4TRANSNOX_CPASS.*, TARGET SNOX4TRANSNOX_CPASS.* ;
MAP KEYNOX_FX.*, TARGET KEYNOX_FX.* ;


-- Currently Used VBS schemas
MAP SNOXPASS_SMSNOX_305.*, TARGET SNOXPASS_SMSNOX_305.* ;
MAP TNOXPASS_SMSNOX_305.*, TARGET TNOXPASS_SMSNOX_305.* ;

MAP SNOXPASS_GWAY_010.*, TARGET SNOXPASS_GWAY_010.* ;
MAP TNOXPASS_GWAY_010.*, TARGET TNOXPASS_GWAY_010.* ;

MAP TNOXPASS_TFE_2015.*, TARGET TNOXPASS_TFE_2015.* ;
MAP SNOXPASS_TFE_2015.*, TARGET SNOXPASS_TFE_2015.* ;

-- New VBS schemas
MAP SNOXPASS_GWAY_012.*, TARGET SNOXPASS_GWAY_012.* ;
MAP TNOXPASS_GWAY_012.*, TARGET TNOXPASS_GWAY_012.* ;

MAP TNOXPASS_TFE_2016.*, TARGET TNOXPASS_TFE_2016.* ;
MAP SNOXPASS_TFE_2016.*, TARGET SNOXPASS_TFE_2016.* ;

MAP TNOXPASS_SMSNOX_306.*, TARGET TNOXPASS_SMSNOX_306.* ;
MAP SNOXPASS_SMSNOX_306.*, TARGET SNOXPASS_SMSNOX_306.* ;
-->> End of File


-- if you want to create replicat process on same machine where extract process is present
GGSCI (loadtxdbnode1.tsysacquiring.org) 20> shell vi dirsql/CreateTarget2.oby
ADD REPLICAT RDCW1, EXTTRAIL /opt/app/goldengate/dirdat/RA
-->> End of File

-- will execute the script
GGSCI (loadtxdbnode1.tsysacquiring.org) 18> obey dirsql/CreateSource.oby










