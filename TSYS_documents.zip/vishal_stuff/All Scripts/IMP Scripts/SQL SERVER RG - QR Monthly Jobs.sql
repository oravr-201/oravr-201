-- This is command is showing if there is any one locking to DB
select cmd,* from sys.sysprocesses
where blocked > 0

--**********************************************************************************************************
--
--       1st day Refreshing Commissions Job...
--
/*

	Every 1st date of the Month (30th or 31st of every Month 20:30 PST, but before 23:59:59 PST) 
	at time 09:00 AM (IST) execute the scripts step by step refreshing commissions�
	
	-- To check the monthly data in all countries
	
	-- if the .GCA file as reran then followup the below process
	
	USE GCA
	SELECT A.HISTORY_SETTLE_DATE, SUM(A.USA_CNT), 
	      SUM(A.CACHE_CNT), SUM(A.USA_CNT) - SUM(A.CACHE_CNT)  
	FROM (
	        SELECT HISTORY_SETTLE_DATE, COUNT (*) USA_CNT, NULL CACHE_CNT 
	          FROM HISTORY 
	         WHERE HISTORY_SETTLE_DATE >= 20140501
	         GROUP BY HISTORY_SETTLE_DATE
	        UNION
	        SELECT HISTORY_SETTLE_DATE, NULL USA_CNT, COUNT (*) CACHE_CNT 
	          FROM CACHE 
	         WHERE HISTORY_SETTLE_DATE >= 20140501
	         GROUP BY HISTORY_SETTLE_DATE
	) A 
	GROUP BY A.HISTORY_SETTLE_DATE
	
	Check the result of above query, if you found that data elser then the previous count, then you will have to re-ran the AutoReplicator
	
	* If the Autoreplicator has started running automatically then wait for the mail of History Download, once you get the 
	  mail "HISTORY Downloaded successfully for the Settle Date : <<DATE>>", then Stop/Kill the Autoreplicator.exe program from Task Manager,

	* Take the backup and Delete the data from HISTORY, CACHE (For countries GCA, BELGDB, CANADA, CZECHDB, FRANCEDB, MACAUDB, SWITZDB, UKDB) and UKDB..HISTORY_OTHER_COUNTRIES 
	  for the sepecific date only
	
	select * into qmdb..gca_history_30May2014 from gca..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	select * into qmdb..gca_cache_30May2014 from gca..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	select * into qmdb..belgdb_history_30May2014 from belgdb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	select * into qmdb..belgdb_cache_30May2014 from belgdb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	select * into qmdb..canada_history_30May2014 from canada..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	select * into qmdb..canada_cache_30May2014 from canada..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	select * into qmdb..CZECHDB_history_30May2014 from CZECHDB..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	select * into qmdb..CZECHDB_cache_30May2014 from CZECHDB..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	select * into qmdb..francedb_history_30May2014 from francedb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	select * into qmdb..francedb_cache_30May2014 from francedb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	select * into qmdb..macaudb_history_30May2014 from macaudb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	select * into qmdb..macaudb_cache_30May2014 from macaudb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	select * into qmdb..switzdb_history_30May2014 from switzdb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	select * into qmdb..switzdb_cache_30May2014 from switzdb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	select * into qmdb..ukdb_history_30May2014 from ukdb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	select * into qmdb..ukdb_cache_30May2014 from ukdb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	select * into qmdb..history_other_country30May2014 from ukdb..history_other_countries where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	begin tran
	delete from gca..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	delete  from gca..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	delete  from belgdb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	delete  from belgdb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	delete  from canada..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	delete  from canada..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	delete  from CZECHDB..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	delete  from CZECHDB..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	delete  from francedb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	delete  from francedb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	delete  from macaudb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	delete  from macaudb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	delete  from switzdb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	delete  from switzdb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	delete from ukdb..history where history_settle_date >= 20140530 and history_settle_date < 20140531
	delete from ukdb..cache where history_settle_date >= 20140530 and history_settle_date < 20140531
	
	delete from ukdb..history_other_countries where history_settle_date >= 20140530 and history_settle_date < 20140531
	commit tran

	* ask Indsys to transfer the reran .GCA unzipped file (This reran .GCA file might not be present on 
	  NDM server, it might be present on recon server),  file transfer to location \\cvs.infonox.com\dblogs\RahulC_Stuffs

	* Transfer the file from CVS to GCASQLDB machine in "D:\GCADOWNLOADFILES"

	* run the Autoreplicator, click on OK Button, Date 201405030 (YYYYMMDD format), check on SQL only and run the program
	it will ask to give the .GCA file name, select the copied .GCA file for which the .GCA was reran
	
	* Once the History is uploaded successfully then then check again with above query, if the data has been 
	 populated correctly for all days of a Month	
	
	
	
*/
--**********************************************************************************************************


--- Follow the below steps for Monthly refreshing the commissions over SQL SERVER database.

--- Run the script in Transnox_GCA schema (Oracle DB) Primary DB (If this is taking more than 2 min then 
--- run it from DR site DBs) to create the table and check transactions...

--- If there are no transactions in select statement then send the mail to ICP team to check the issues�

--- The date format should be for time 150000 till current month's 145959
--- for e.g 30Jul2013 15:00:00 till 31Aug2013 14:59:59

--- If Oracle SQL query is taking more time then 5/10 min max then stop running in primary DB and run the same in alternate DR DB

--- Here we are creating a table for TID which is mapped in below recrdite query..

--- The name of the file should be ending with Month's Name like TID_NOC, RECERDIT_NOC, POSP_NOV....

--- 1) TID_NOV.txt file Query
SELECT DISTINCT D.DEVICE_ID, D.MERCHANT_ID , 'aaa'  LOCATION , D.DEVICE_TYPE , di.PROCESSOR_TERM 
FROM SNOX4TRANSNOX_GCA.DEVICE D, SNOX4TRANSNOX_GCA.DEVICE_PROCESSOR_INFO di 
WHERE D.DEVICE_ID = DI.DEVICE_ID
  AND DI.PROCESSOR_CODE in ('SAR','VLP', 'VAL')
  AND D.MERCHANT_ID IN (SELECT DISTINCT m.MERCHANT_ID
				  		FROM SNOX4TRANSNOX_GCA.MERCHANT m, SNOX4TRANSNOX_GCA.MERCHANT_PROCESSOR_INFO mi 
				  		WHERE m.MERCHANT_ID = mi.MERCHANT_ID
				    	  AND mi.PROCESSOR_CODE IN ('SAR','VLP', 'VAL'))

-- 2) RECERDIT_NOV.txt file Query (Copy the result including headers - columns) 
DROP TABLE GCASQLDB_RECREDIT;

CREATE TABLE RAHULC.GCASQLDB_RECREDIT AS
SELECT TASK_ID 
FROM TRANSNOX_GCA.TRANSACTION A 
WHERE A.TIME_STAMP BETWEEN TO_DATE ('12/31/2013 15:00:00','MM/DD/YYYY HH24:MI:SS')
				       AND TO_DATE ('01/31/2014 14:59:59','MM/DD/YYYY HH24:MI:SS')
  AND A.TRANS_TYPE LIKE '%RETURN%'
  AND A.TRANS_STATUS = 'APPROVED'

SELECT t.TRANSACTION_ID, AAA.Rec_transaction_id, tri.APPROVAL_CODE, nvl(tri.HOST_SEQUENCE_NUMBER,t.REFERENCE_NUMBER) REF_NUMBER , tch.CHECK_NUMBER, T.CURRENCY
FROM TRANSNOX_GCA.TRANSACTION t, TRANSNOX_GCA.TRANS_RESPONSE_INFO tri, TRANSNOX_GCA.TRANS_CHECK tch,
(
	SELECT MIN(a.TRANSACTION_ID) AUTH_TRANSACTION_ID, max(a.TRANSACTION_ID) REC_TRANSACTION_ID, a.TASK_ID, COUNT(1) 
	FROM TRANSNOX_GCA.TRANSACTION a 
	WHERE a.TASK_ID in (SELECT TASK_ID FROM GCASQLDB_RECREDIT) 
	  AND A.TRANS_STATUS = 'APPROVED' 
	GROUP BY a.TASK_ID
) AAA
WHERE t.TRANSACTION_ID = AAA.Auth_transaction_id
  AND t.TRANSACTION_ID = tri.TRANSACTION_ID  
  AND t.TRANSACTION_ID = tch.transaction_id(+)

-- 3) POSP_NOV.txt file Query  
DROP TABLE GCASQLDB_POSP_FILE PURGE;

CREATE TABLE GCASQLDB_POSP_FILE AS
SELECT MAX(A.TRANSACTION_ID) TRANSACTION_ID 
FROM TRANSNOX_GCA.TRANS_ADDITIONAL_INFO tai, TRANSNOX_GCA.TRANSACTION A 
WHERE tai.TRANSACTION_ID = A.TRANSACTION_ID 
  AND tai.VALUE = 'POSPR'
  AND A.TRANS_STATUS = 'APPROVED'
  AND A.TRANS_TYPE = 'DEBIT_SETTLE'
  AND A.TIME_STAMP BETWEEN TO_DATE ('12/31/2013 15:00:00','MM/DD/YYYY HH24:MI:SS')
                         AND TO_DATE ('01/31/2014 14:59:59','MM/DD/YYYY HH24:MI:SS')
GROUP BY A.TRANSACTION_ID;

SELECT * FROM GCASQLDB_POSP_FILE;

--- using Toad copy the result of all the three queries to generate three files TID_NOV, RECREDIT_NOV and POSP_NOV
--- and the value should be (|) pipe separated values in a files...

--- Once the result of above queries are taken into three files then transfer the files to GCASQLDB machine
--- to import into sqlserver DB.

-- This are the three files which we have to run in Month End Job in sql server
1)TID  --- Terminal ID which will be imported in UK DB
2)POSP  -- POSPlus file, which will be imported in GCA DB
3)recredit -- Recon Credit file, which be imported in GCA DB

Transfer the file to 192.168.229.30 sqlserver vps8sys user account
username - vps8sys
password - Infonox1234

Use sftp 10.175.157.195 for file trasfer on QR Application Server -- be sure to disconnect once the work is done from your VDIPROD
login:     qrmanager
pass:      2Kilo_Apples

Now login to GCASQLDB

on DeskTop there is shortcut of WS_FTP Pro, open it 

sftp://192.168.229.195/home/sites/qrmanager
login:     qrmanager
pass:      2Kilo_Apples
Port 22

On Right Side There is a Open a Remote Connection Click on it, from Site Manager, Connect to QRM, and Transfer the files (TID_AUG, POSP_AUG, RECREDIT_AUG).
 
Transfer the files from path "/home/sites/qrmanager/QMDownload" to path "d:\GCADOWNLOADFILES\FROMGCA" (path of GCASQLDB)
 
--- Once you copy the files from QR WebServer, delete the files and disconect and close it safly..
 
How to Import the files in SQL SERVER database...

--- Import the TID_NOV file in UK DB only and
--- POSP_NOV and RECREDIT_NOV files should be imported in GCA DB only.

SrNo  DBs 		File Names
----------------------------------
1.	  UKDB		TID_<Month_Name>
2.	  GCA		RECREDIT_<Month_Name>
3.	  GCA		POSP_<Month_Name>


-- How Do I Import the files in SQL Server
In Object Explorer  -- SQL Server Database
gcasqlDB (SQL Server 10.50.1600 -sa)
	|
	Databases
	|
	UKDB
	|
	Right click of Mouse Button
	|
	Task
	|
	Import Data
	|
	SQL Server Import and Export Wizard
	|
	Data Source -- Flat File Source
	check on -- Column names in the first data row
	|
	Next
	|
	Next
	|
	Import into UK Database -- Import the TID file into UKDB and Rest two (RECREDIT,POSP) in GCA DB
	|
	Next
	|
	Next
	|
	Next
	|
	Finish
	
--- Once it is done, Import other two files into GCA DB -- RECREDIT and POSP files in same way

--- Check the AutoReplicator logs before executing script to refreshe the commissions
check the file import process from path - "D:\AUTOREPLICATOR_MACUA\Log.Txt"


--- Start executing the script to refresh the Monthly commissions.

--- Month End script, This are the three scripts which had to execute every Month End...
1) Monthly commission_run.sql  -- Path is "D:\sridhar\GCA QR Issues\MONTHLY Commission RUN.txt"
2) Monthly Commission RUN for NON USA countries.txt -- Path is "D:\sridhar\GCA QR Issues\MONTHLY Commission RUN for NON USA countries.txt"
3) Run Recredit script -- Path is "D:\RahulC_Stuff\Monthly Recredit Updates.txt"

--- Modify the dates for current Month yyyymmdd format for e.g. (20131101) (20131130)

--- replace the dates and replace the temp table name with Month at the end of table name 
--- like _Jun format (e.g.. _Jan, _Feb, _Mar, etc...)

--- Save the changes in both the files

--- above dates modification should be done in both the script Monthly commission and Non Monthly Commission scripts

/*

After modifying the script for dates, Open the "Monthly Commission_run.sql" script, the first query is to check and verify 
the data is present for all the dates in UKDB, GCA and CANADA DBs, if the data is not present (Mainly in GCA and CANADA DBs) for 
all months day then wait till the files get loads through AutoReplicator scheduled Job..

AutoReplicator Job is scheduled for 1015 PM PST (1230 PM IST).. you can execute a job before the time also if the files are present...
Check with Indsys before running executing it manually 

You will get the mail "HISTORY Downloaded successfully for the Settle Date : 11/30/2013 or for 31st Date" which means till the date, the 
data has been populated in the tables.... The data for GCA and CANADA DBs should be matching for last month of day (30/31)
in the file and in the queried result for both the DBs.. There might be or might not be the data for UKDB, which is fine..

So all the data should be present for full Month (Till Date - 30/31)

*/


"Monthly commission_run.sql" -- script schould be run in only GCA DB, do not run it for other DBs ** Be sure for this

"Monthly Commission RUN for NON USA countries.txt" -- script should be run in all below DBs only ** Be sure for this

BELGDB
BELIDB
CANADA
FRANCEDB
MACAUDB
STKITTSDB
SWITZDB
UKDB

Start with Monthly commission_run.sql script, Open the script in Notepad++

select all the text from 1st line till linenumber 261 -- END OF monthly run

Copy the script and paste it into SQL Server editor

In Monthly commission_run.sql script, first select statement will be run against (to check in) 
UK, GCA and CANADA DBs for verification that all the records are good.

--- There should be (mostly) 30/31 records (for 31 days for a Month) in the executed script, mostly this will be 
--- showing records for GCA and CANADA DB, the records might not be present for UK DB which is fine...
--- Last column should be zero(0) in all 30/31 records.

In script Monthly commission_run.sql, TID_NOV script should be executed in UK DB only.

Then Run the script for GCA DB from "-- use GCA" line in the script

--- Always check in which DB you are running the scripts.

-- This will take almost 1 hr to run/execute the scripts in GCA DB..

--Now execute second script
2) Monthly Commission RUN NON GCA countries.sql

-- This script will be executed for all countries except GCA DB and QR related DBs

--- run the script for all countries and check for records, if there are zero 
-- records then do not run for other countries....


3) Run Recredit script... for GCA/CANADA DBs
-- Make sure to change the dates for the current months



----------------------------------------------------

-- END of all the script execution for Monthly Job
--**********************************************************************************************************

-------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------




--- if any user is locked in SQL Server - QRReport -QRprodDB then 

check qrprod.user_data table is_locked column





--**********************************************************************************************************
--
--       CCCA/ATM Commissions for QR
--
/*
	Once the main commissions are calculated on 1st of every months, after 3/4 days run the CCCA/ATM (Spider) Commissions 
	for QR (Marc Team will sending a mail to start importing the Spider commissions)
	
	Commissions for QR CCCA & Commissions for QR ATM
*/
--**********************************************************************************************************

-- Start of CCCA Commissions

-- 2 Commission files are to be run (can run anyone, there is no sequence)

** CCCA commission  --- file path D:\COMMISSION4QR_CCCA

-- CCCA Commission are also called Spider Commissions for the Month

-- run ATM/CCCA Commissions for the of Jan2014, means (In Feb2014, We are running 
-- the CCCA/ATM commissions for the Month of Jan2014)


-- Below is the Script to be executed, first in GCA DB and then in Canada DB, only.
D:\COMMISSIONS4QR_CCCA\QR UPDATES.txt

Or 

D:\RahulC_Stuff\CCCA-Spider Commissions Monthly Updates.txt -- Updated file

-- GCA will take 5-6 min (depending on the records) and Canada will take around 1 min to execute the scripts

--Once the above script are execute then Run the executable located in 
D:\COMMISSIONS4QR_CCCA\STANDARDREPORTS.exe

--with proper month and year. press Ok when next windows will come check the Month for which you have to run the referesher reports.
--checked the button on for Update only QR and run it... once it is done it will automatically close the window

-- End of CCCA Commissions

-- Verify the CCCA Commissions data is Correctly populated into below tables for Report_Month and Report_Year.... 

-- At the end... The below tables are refereshed by .exe program, if you do not see any data in the tables then you will have to 
-- re-run the .exe program to referesh the commissions data for the Month and Years

-- If there is any errors, then you can delete all the records for that Report_Month and Report_Year and 
-- start .exe again to referesh the commissions.. This is into QRPROD databases

SELECT * FROM COMMISSION_DAILY WHERE REPORT_MONTH = 03 AND REPORT_YEAR = 2014
SELECT * FROM COMMISSION_CARD WHERE REPORT_MONTH = 03 AND REPORT_YEAR = 2014
SELECT * FROM COMMISSION_TRANSACTION WHERE REPORT_MONTH = 03 AND REPORT_YEAR = 2014
SELECT * FROM TERMINAL_ACTIVITY WHERE REPORT_MONTH = 03 AND REPORT_YEAR = 2014


DELETE FROM COMMISSION_DAILY WHERE REPORT_MONTH = 11 AND REPORT_YEAR = 2013
DELETE FROM COMMISSION_CARD WHERE REPORT_MONTH = 11 AND REPORT_YEAR = 2013
DELETE FROM COMMISSION_TRANSACTION WHERE REPORT_MONTH = 11 AND REPORT_YEAR = 2013
DELETE FROM TERMINAL_ACTIVITY WHERE REPORT_MONTH = 11 AND REPORT_YEAR = 2013

/*

If there is any issues in CCCA Spider Commissions .exe program then check the HISTORY_MERCHANT_NUMBER column in CACHEJULY table and which should not be null, if so delete them..

-- As Per Sridhar
The reason why the import for CCCA commission is failing because of issue in the history table.
CCCA commission are being imported from cachejuly table and cachejuly table is copy of cache table in GCA db. 
The issue is cache or history table is having 7 records with history_merchant_number as null. 

I am not sure why would cache or history table ever have null values for history_merchant_number column.

Quick fix: I had deleted 7 records from cachejuly table (this is a staging table for each month's commission. it gets loaded from cache table when you run the ccca commission script).

Now, after deleting 7 records, I had rerun the ccca commission and it worked fine now.

for next month, please make sure there are not records with missing history_merchant_number. If that happens then delete the records in cachejuly table before executing ccca commission vb job.
------------------------

SELECT * FROM CACHEJULY WHERE HISTORY_MERCHANT_NUMBER IS NULL;

DELETE FROM CACHEJULY WHERE HISTORY_MERCHANT_NUMBER IS NULL;
       
SELECT SUM(history_calc_trans_count) TRANS_COUNT, sum(history_calc_credit_amt) CREDIT_AMOUNT, 
	   SUM(history_calc_void_amt) VOID_AMOUNT, sum(history_calc_req_face_value) FACE, 
	   SUM(history_calc_surcharge) SURCHARGE, sum(history_calc_total_amt) AMOUNT, 
	   SUM(history_calc_gross_commission) COMMISSION, history_settle_date, history_merchant_number 
FROM cachejuly 
WHERE history_settle_date between  20140801 And 20140831 
  AND history_settled_flag = 1 
  AND history_note not like 'GCC%'
GROUP BY history_settle_date, history_merchant_number 
ORDER BY history_merchant_number


begin tran
 delete qrprod..COMMISSION_DAILY where report_month = 8 and report_year =2014
commit tran

*/ 

-----------------------------------------------------------------------------------------------------------------------

-- Start of ATM Commissions

** ATM commission   --- file path D:\COMMISSION4QR_ATM

-- For the ATM Commissions, GCA is sending some files which we have to download from their machine to SQL Server machine. If those files
-- are not present in those mapped drive then send the mail to marc - 

-- If  the files are present on mapped driver then ... follow the below setups 


1) Map the drive of GCA to sqlserver machine -- \\172.16.16.163\corporate 
--- if the mapped drive is giving access denied error then remap it from Windows Explorer "Computer" by right click select "MAP Network Driver"

2) Once the 16.163 machine is mapped then check folder INOX-Exports -- \\172.16.16.163\INOX-Exports\
--//inox-imports\Pmi9%2
//inox-exports/8$nn3u3 -- use this loging for copy/paste the files from GCA corporate drive (corporate (\\172.16.16.163))
--//inox-specreq/#5hh454

/*

 Here you will have to check for the current date's folder like 1307 folder was 
 for date Jul2013 or 1308 for Aug2013. Latest Directory
 
 So for the Month of Jul-2013 scripts the folder should be named as 1307 -- this folders and files are created by GCA
 
 Conacte GCA if you do not find any current date's folder and files in the path
 
*/

3) From this folder copy the below three files to sqlserver machine on path "D:\GCADOWNLOADFILES\FROMGCA folder"
  1) ArchiveATMDailySum.txt -- 1
  2) ArchUnsuccessfull.txt  -- 2
  3) Commission.txt         -- 3

-- It will replace the above three files of periviou's month files, So replace them all

4) Import the above three files into SQL Server QRPROD DB
-- while importing make sure to delete the rows first and import into same tables
QRPORD
|
Task
|
Import Data
|
	Data Source >> select "Flat File Source"
	|
	Browse >> D:\GCADOWNLOADFILES\FROMGCA folder\ >> take one by one file for importing
	|
	Click on checkBox "Column name in the first data row"
|
Next
|--- check the data here
Next
|
Database >> select "QRPROD"
|
Next
|
Click on Button "Edit Mappings..."
		|
		Click on Radio Button "Delete rows in destination table"
		|
		Clikc on "Ok" Button
		|
|
Next
|
Next
|
Finesh

-- Do it for rest of the 2 files one by one importing into QRPROD DB

5) open the "ATM Commissions Monthly Updates.txt" script from path "D:\COMMISSION4QR_ATM\ATM_COMM_monthly_updates.txt"
in the script on the first part there is truncate table script... as we have deleted the rows while importing itself so we can ignore this 
truncate script on three tables.

6) Copy the script from below of "use qrpord" untill "-- Run the atm commission app" in script

7) Paste the script in SQLServer and run it in 1 by 1... in QRPROD DB -- I have modified the script to point the schemaname.tablename

-- Before running the script make sure to modify the dates in Number for Report_Month 8 (for AUG) and Report_Year 2013 (2013 year)
-- Rest all the information is updated in script file "D:\COMMISSION4QR_ATM\ATM_COMM_monthly_updates.txt"

8) Once all the script is execute in QRPROD DB.. go to folder and open the VBs app 
"D:\COMMISSION4QR_ATM\ATMREPORTS4QR.exe"

ATMREPORTS4QR.exe
|
click ok
|
check the moth for which you are updating the records
|
check on Update QR only checkBox
Click on run Button
|
On Confirm Windows check the Month again, Click on Yes Button if the month is correct


this will update the records from temporary table to actual tables. once it is done it will be automatically closed.

--- End of ATM Commissions
--**********************************************************************************************************







--**********************************************************************************************************
--
--           QR Telecheck Monthly Job
--
/*
	
	QR TelecheckTransaction Monthly Job - This is been send by GCA "Sosa, Sara" <ssosa@gcamail.com>

The files are send over the mail with attachement of 4 files

1) QR_201308.xls
2) QR_201308.csv  -- importing file
3) Aug 2013 Gaming Report.xls
4) Aug 2013 Gaming Report.txt/.csv --- importing file
	
*/
--**********************************************************************************************************

--- Monthly Job for QR DB

1) Aug 2014 Gaming Report.txt
2) QR_201403.csv

check the header and footer of the both the files
Before you upload those files, pls validate to remove ' " and comma with in "'

Use the script for telecheck updates. 

This are for importing TelecheckTransactions data

1) Rename the file "Aug 2013 Gaming Report.txt" to "Aug2013.txt" on local Disk only

2) Open .csv/.txt files QR_201308.csv and Aug2013.txt to remove the headers and footers.

3) Replace all double, single qutoes (' and " ') and commas in between "," with space

4) In QR_201308.csv file just remove the footers (,,,,,, all) donot remove the column names in heaters. 
last row in the file should be empty, else it will be giving errors while importing

5) Copy the Files to GCASQLDB .. i.e SQL Server DB

6) Once you copy the files Import them into QRPROD DB

Importing first files Aug2013.txt into QRPORD DB

QRPORD
|
Task
|
Import Data
|
Data Source >> select a Option of "Flat File"
	|
	Browse and select the file name/path
	|
	Do not click on CheckBox of "Column names in the first data row"
|
Next
|
Next
|
Check the Database name is QRPROD
and click Next Button
|
Next
|
Next
|
Finish

Do the same for second file QR_201308.csv

QRPORD
|
Task
|
Import Data
|
Data Source >> select a Option of "Flat File"
	|
	Browse and select the file name/path
	|
	click on CheckBox of "Column names in the first data row"
|
Next
|
Next
|
Check the Database name is QRPROD
and click Next Button
|
Next
|
Next
|
Finish


Once the importing is done, copy the script from "D:\RahulC_Stuff\QR Telecheck Monthly Script.txt" to sql server editor

-- Dates are as per filenames like .csv and .txt
-- Suppose the files are coming for Aug2013.txt then the dates should 8, Year 2013
change the dates as per mention in script and execute the script in QRPORD DB...

rest all the details are present in the file script....

-- END the script of Telecheck Updates for the Month

Send the mail to ACQ-Marc, This is done



--**********************************************************************************************************

 Problem in Downloading the file from FTP. Filename : 20130805.GCA
 
 If there are such mails coming then rerun the replicator job from windows scheduler Jobs windows.
 
 JOB Name: AUTOREPLICATOR
 
 Loging to IP - 192.168.229.101
 From Path : /home/sites/ndmjobs/prod/smsnox/gcaufiles
 
 -- Path of .GCA files
 /home/sites/ndmjobs/prod/smsnox -- new path
 
 Get latested .GCA file...
 
 --- Password of ndm4cb
 ndmjobs/NdmJ0b$@Tempe
 
 ------------------------------------------------------------------------------------------------------------
  
 Saturday is a Non Processing day for Macau
 
 Sunday is a Non Processing day for US 
 
 -- *** Problem in AutoUpload ChargeBack(US) Program. File Not Found
 -- *** Problem in AutoUpload ChargeBack(MACAU) Program. File Not Found
 
 -- To resolve the issue of Uploading ChargeBack File for US or MACAU
 
  If there is any maill from Marc team related to chargeback files like the below one for US and MACAU
  
  *** Problem in AutoUpload ChargeBack(US) Program. File Not Found
  OR
  *** Problem in AutoUpload ChargeBack(MACAU) Program. File Not Found
  
  Then we have to manually run the program from the below path. 
  
  D:\UPLOAD_CHARGEBACKS_GW\AutoUploadCB.exe
  
  1) click on AutoUploadCB.exe 
  2) enter 1 (For US) or 2 (For MACAU) 
  3) Date (Date Format should be MM/DD/YYYY).. 04/01/2014
  
  once all the needed requrest has been entered then it will run for 5 min, and mail will be send to a group
  
  If the files are failling, and You re-running the file on same day then run the file from scheduler window
  
  Worked CB for US    --- is for ChargeBack US
  Worked CB for MACAU --- is for ChargeBack MACAU 
  
  If the day is passed then you will have to run it manually using above mention process
 
 In Windows Scheduler the program Upload_CB is for Chargback (US)
 
 ChargeBack files are stored on below locations. Here you will *.CBM and *.CBU (were M stands for Macau and U stands for US)
 
  D:\GCADOWNLOADFILES\CBFILES 
  
  -- ChargeBack(Macau) Files
  OUT.FTP7639A.B7639CHB
  
  -- ChargeBack(US) Files
  OUT.FTP7539A.B7539CHB
  
  -- NDMJobs, from where files are copyied to GCASQLDB machine 
  10.175.169.156
    
  -- Stores ChargeBack files
  /home/sites/ndmjobs/prod/smsnox
  
  ls -ltr *CHB* 
  
  -- Stores .GCA files
/home/sites/ndmjobs/prod/smsnox/gcaufiles 
  
 ------------------------------------------------------------------------------------------------------------
 
 select i.* from QRPROD..AUG2013_IM1593192 i, QRPROD..TC_QR_DETAILS o
 where [COLUMN 1]= o.ACCOUNTNO
   and [COLUMN 3]=o.CHECKS_APP_COUNT
   and o.REPORT_MONTH = 8
   and o.REPORT_YEAR = 2013
 order by 2,3 asc 
 
 begin tran
 update QRPROD..TC_QR_DETAILS
 set 
 	CHECKS_APP_COUNT 	= o.[COLUMN 3],
 	CHECKS_APP_AMOUNT	= o.[COLUMN 4],
 	CODE3_COUNT			= o.[COLUMN 5],
 	CODE3_AMOUNT		= o.[COLUMN 6],
 	CODE4_COUNT			= o.[COLUMN 7],
 	CODE4_AMOUNT		= o.[COLUMN 8],
 	TELECHECK_BILLING	= o.[COLUMN 9]
 from QRPROD..Feb2013_Q292545 o
 where ACCOUNTNO = o.[COLUMN 1]
   and REPORT_MONTH=2
   and REPORT_YEAR=2013
 commit tran 
 
 
 
 select ACCOUNTNO, REPORT_MONTH, REPORT_YEAR, COUNT(*)
 from QRPROD..TC_QR_DETAILS
 where REPORT_MONTH=2 and REPORT_YEAR=2013
 GROUP by ACCOUNTNO, REPORT_MONTH, REPORT_YEAR
 having COUNT(*)>1

 
 
 
 select  
 	ACCOUNTNO, CHECKS_APP_COUNT, CHECKS_APP_AMOUNT, 
 	CODE3_COUNT, CODE3_AMOUNT, CODE4_COUNT, CODE4_AMOUNT,
 	TELECHECK_BILLING, REPORT_MONTH, REPORT_YEAR
 from QRPROD..TC_QR_DETAILS 
 where ACCOUNTNO=878 and CHECKS_APP_COUNT=475 and REPORT_MONTH=9 and REPORT_YEAR=2012
 
 select 
 	[COLUMN 1] ACCOUNTNO, [COLUMN 3] CHECKS_APP_COUNT, [COLUMN 4] CHECKS_APP_AMOUNT, 
 	[COLUMN 5] CODE3_COUNT, [COLUMN 6] CODE3_AMOUNT, [COLUMN 7] CODE4_COUNT, [COLUMN 8] CODE4_AMOUNT, 
 	[COLUMN 9] TELECHECK_BILLING, 9 REPORT_MONTH, 2013 AS REPORT_YEAR
 from QRPROD..Sep2012_Q292545 
where [COLUMN 1]=878 and [COLUMN 3]=475


BEGIN TRAN
INSERT INTO QRPROD..TC_QR_DETAILS 
(
	ACCOUNTNO, CHECKS_APP_COUNT, CHECKS_APP_AMOUNT, 
	CODE3_COUNT, CODE3_AMOUNT, CODE4_COUNT, CODE4_AMOUNT,
	TELECHECK_BILLING, REPORT_MONTH, REPORT_YEAR
)
SELECT 
	[COLUMN 1], [COLUMN 3], [COLUMN 4], 
	[COLUMN 5], [COLUMN 6], [COLUMN 7], [COLUMN 8], 
	[COLUMN 9], [COLUMN 10], [COLUMN 11]
FROM QRPROD..eureka_issues_25oct2013
COMMIT TRAN

BEGIN TRAN
INSERT INTO QRPROD..TC_QR_DETAILS 
(
	ACCOUNTNO, CHECKS_APP_COUNT, CHECKS_APP_AMOUNT, 
	CODE3_COUNT, CODE3_AMOUNT, CODE4_COUNT, CODE4_AMOUNT,
	TELECHECK_BILLING, REPORT_MONTH, REPORT_YEAR
)
values
(
'2119','3393','1461231',522,'283771.8',62,'16042.9','35069.55',11,2014
'2116','1932','641462.2',141,'67070',24,'4148.2','15395.09',11,2014
'2113','1268','370894',191,'83850.3',21,'5984.2','8901.46',11,2014

'2119','3881','1751285',536,'321818.1',61,19997,'42030.85',12,2014
'2116','1861','693118.1',167,'83115.4',20,4375,'16634.83',12,2014
'2113','1466','435177.7',178,'96872.4',24,9822,'10444.26',12,2014


)
COMMIT TRAN

-----------------------------------------------------------------------------------------------------------------------------------------------
[COLUMN 0] [COLUMN 1]  [COLUMN 2]						[COLUMN 3]  [COLUMN 4]  [COLUMN 5]  [COLUMN 6]  [COLUMN 7]  [COLUMN 8]  [COLUMN 9]  
-----------------------------------------------------------------------------------------------------------------------------------------------
GCA			Bill 		To	Name						Count		Amount		Code 3 #	Code 3 $	Code 4 #	Code 4 $	Revenue
-----------------------------------------------------------------------------------------------------------------------------------------------
November										
GCA			Bill 		To	Name						Count		Amount		Code 3 #	Code 3 $	Code 4 #	Code 4 $	Revenue
527403		2119		WINSTAR							3393		1461231		522			283771.8	62			16042.9		35069.55
527402		2116		RIVERWIND CASINO				1932		641462.2	141			67070	24	4148.2		15395.09
527401		2113		NEWCASTLE						1268		370894		191			83850.3	21	5984.2		8901.46

December												
GCA			Bill 		To	Name						Count		Amount		Code 3 #	Code 3 $	Code 4 #	Code 4 $	Revenue
527403		2119		WINSTAR							3881		1751285		536			321818.1	61			19997		42030.85
527402		2116		RIVERWIND CASINO				1861		693118.1	167			83115.4	20	4375		16634.83
527401		2113		NEWCASTLE						1466		435177.7	178			96872.4	24	9822		10444.26


GCA			Bill 		To	Name						Count		Amount		Code 3 #	Code 3 $	Code 4 #	Code 4 $	Revenue
527403		'2119','3393','1461231',522,'283771.8',62,'16042.9','35069.55',11,2014
527402		'2116','1932','641462.2',141,'67070',24,'4148.2','15395.09',11,2014
527401		'2113','1268','370894',191,'83850.3',21,'5984.2','8901.46',11,2014

December												
GCA			Bill 		To	Name						Count		Amount		Code 3 #	Code 3 $	Code 4 #	Code 4 $	Revenue
527403		'2119','3881','1751285',536,'321818.1',61,19997,'42030.85',12,2014
527402		'2116','1861','693118.1',167,'83115.4',20,4375,'16634.83',12,2014
527401		'2113','1466','435177.7',178,'96872.4',24,9822,'10444.26',12,2014



--------------------------
-- issues to be understand from Sridhar...
1) Encryption failed mail related..
2) Autoreplication Failed Mail


insert into qrprod.tc_qr_master values('400500','FOXWOODS CASINO AND RESORT','400500','Jim Dougherty',NULL,'2.00%','0','1000')



--- Query to check the data is present for the given date
use GCA 
select a.history_settle_date, sum(a.usa_cnt) , sum(a.cache_cnt), sum(a.usa_cnt) - sum(a.cache_cnt)  from (
select history_settle_date, count(*) USA_cnt, null cache_cnt from history where history_settle_date >= 20130801 and history_settle_date <= 20130831
group by history_settle_date
union
select history_settle_date, null USA_cnt, count(*) cache_cnt from cache where  history_settle_date >= 20130801 and history_settle_date <= 20130831
group by history_settle_date
) a group by a.history_settle_date
order by a.history_settle_date desc





Select * from [dbo].[TRANSACTIONS_HISTORY_SUMMARY]  
where TRANSDATE = '2013-08-30' and CASINOCODE = '547200' 


On Thu, Dec 5, 2013 at 1:27 PM, Matt Johnson <mjohnson@icp-inc.com> wrote: 



SELECT ths.casinocode thecode, c.casinoname thename, 
	   STR(SUM(ROUND(ths.amountsum,0)),12,2) AS amtsum, 
	   SUM(ths.transcount) AS counttotal  
FROM Transactions_History_Summary ths, casinos c 
WHERE ths.transdate BETWEEN 8-1-2013 AND 8-31-2013 23:59:59.997 
  AND ths.casinocode='547200'  
  AND ths.terminalid = '99999999' 
  AND c.casinocode = ths.casinocode  
GROUP BY ths.casinocode, c.casinoname;  


SELECT ths.casinocode thecode, c.casinoname thename,   
       STR(SUM(ROUND(ths.amountsum,0)),12,2) AS amtsum,        
       SUM(ths.transcount) AS counttotal  
FROM transactions_history_summary ths, casinos c 
WHERE ths.transdate BETWEEN 10-30-2013 AND 10-30-2013 23:59:59.997     
  AND ths.casinocode='547200'   
  AND ths.terminalid = '99999999'         
  AND c.casinocode = ths.casinocode  
  GROUP BY ths.casinocode, c.casinoname


--- Question to Ask Sridhar in Meeting
1) Where are files coming from... (Process I7539NTC (NDMH) )
2) If any data is missing how do we handle it (mail ref.. IM1570220)
3) Last time ICP told me to check data in Transactions_History_Summary table, for some dates an which was missing.. 
   How does this table is populated?
4) Encryption related Jobs



--- Quick Marketing 
-- When the QM Tool is down.
Step 1. Check the Disk Space on C: drive
Step 2. if there is no space clear it by deleting old logs from path C:\QMOUT
Step 3. execute the below update query. Get the QMID from MARC Team


Normally, even a large size reports should finish within 2-3 hours. If the report doesnot show up and the status doesnot change. 
Following procedure needs to be followed:
1. The user can cancel it and rerun it
2. If the user is unable to cancel from the GUI interface of Quik marketing, GCA need to open a ticket with MARC indicating the issue with report 
ID and provide a screen.
3. MARC will go ahead and further escalate the issue to DB Team (Rahul, Saqib and Baidhar), so that they manually update the status of the report as 
"Failed" in the report generator Quik Report database. (in case, three of them are not unavailable, MARC need to get in touch with Amir Siddiqui)
Note: Under Quik Marketting, all submitted reports run sequentially and one report can block everything else behind it in the queue, even those 
submitted by other users. 



SELECT * FROM QRPROD..QM_LOG_HISTORY WHERE QMID LIKE '%3622'

begin tran
update qrprod..QM_LOG_HISTORY
set STATUS='Failed'
where QMID like '%3622'
commit tran


Tables in QRPROD and starting with QM_? are used for Quick Marketing purpose


-- open a command prompt and take a backup of task scheduler windows
-- it will generate the AllTasks.xml file in C:\ colon
schtasks /Query /XML > c:\AllTasks.xml


------------------------------------------------------------------
--- check the application logs for quick reports
10.175.157.195
cd /home/sites/quikreports/current/logs/
ls -ltr
tail -f  -- last log file

and ask Marc to execute the reports
------------------------------------------------------------------


select * from QRPROD..TC_QR_MASTER where CASINOCODE=530311


select * from QRPROD..TC_QR_MASTER where ACCOUNTNO=2012


select * from QRPROD..CASINOS where CASINOCODE=530315

begin tran
insert into qrprod..TC_QR_MASTER values
('2028','ADA GAMING CENTER','530315','','','2%',null,null)
commit tran


begin tran
update qrprod..TC_QR_MASTER set ACCOUNTNO=2009 where CASINOCODE=530302





select * from QRPROD..CASINOS where CASINOCODE=530800

select transdate,count(*) 
from qrprod..transactions_history_summary
where transdate between '2014-06-010' And '2014-06-13'


select max(history_settle_date)
from gca..history
where history_settle_date >= 20140604 and history_settle_date < 20140605 


select history_settle_date, COUNT(*)
from gca..history
where history_settle_date >= 20140604 and history_settle_date < 20140605 
group by history_settle_date



select COUNT(b.*) 
from gca..cache_Jun2014 a inner join gca..cache_duplicate_may2014 b
on a.hist_ident = b.history_ident



select * into gca..cache_org_dup from gca..cache_duplicate_may2014 
where history_ident in (select hist_ident from gca..cache_Jun2014)

select * from gca..cache_org_dup

select history_ident, max(history_calc_ident) hist_calc_ident into gca..cache_unique from GCA..cache_org_dup
group by history_ident

select * from gca..cache_unique 

SET IDENTITY_INSERT gca..cache ON

begin tran
insert into gca..cache
(
history_calc_ident, history_terminal_seq, history_merchant_number, history_card_type, history_completed, history_surcharge, history_settled_flag, 
history_printed_flag, history_settle_date, history_settle_time, history_check_number, history_extended_card_type, history_phone_area, history_phone_exchange, 
history_phone_number, history_zip, history_auth, history_ref, history_card, history_terminal_id, history_address, history_city, history_state, history_last_name, 
history_first_name, history_middle_initial, history_cust_address, history_cust_city, history_cust_state, history_calc_settle_year, history_calc_settle_month, 
history_calc_settle_day, history_calc_corporation_name, history_calc_merchant_name, history_calc_card_type,
history_calc_ext_card_type, history_calc_trans_count, history_calc_credit_amt, history_calc_void_amt, history_calc_debit_reimb, history_calc_req_face_value, 
history_calc_surcharge, history_calc_total_amt, history_calc_gross_commission, history_calc_terminal_desc, history_calc_terminal_ty_desc, 
history_calc_propexpenses, history_calc_usaexpenses, history_calc_binrange, history_calc_phoneno, history_calc_settle_date, history_calc_settle_charmonth, 
history_ident, history_calc_m_prop_type, SExecutive_Name, history_note, history_acm_trans, history_Trans_Type, history_Paper_Type
)
select 
history_calc_ident, history_terminal_seq, history_merchant_number, history_card_type, history_completed, history_surcharge, history_settled_flag, 
history_printed_flag, history_settle_date, history_settle_time, history_check_number, history_extended_card_type, history_phone_area, history_phone_exchange, 
history_phone_number, history_zip, history_auth, history_ref, history_card, history_terminal_id, history_address, history_city, history_state, history_last_name, 
history_first_name, history_middle_initial, history_cust_address, history_cust_city, history_cust_state, history_calc_settle_year, history_calc_settle_month, 
history_calc_settle_day, history_calc_corporation_name, history_calc_merchant_name, history_calc_card_type,
history_calc_ext_card_type, history_calc_trans_count, history_calc_credit_amt, history_calc_void_amt, history_calc_debit_reimb, history_calc_req_face_value, 
history_calc_surcharge, history_calc_total_amt, history_calc_gross_commission, history_calc_terminal_desc, history_calc_terminal_ty_desc, 
history_calc_propexpenses, history_calc_usaexpenses, history_calc_binrange, history_calc_phoneno, history_calc_settle_date, history_calc_settle_charmonth, 
inr.history_ident, history_calc_m_prop_type, SExecutive_Name, history_note, history_acm_trans, history_Trans_Type, history_Paper_Type
 from gca..cache_org_dup inr inner join gca..cache_unique otr on otr.hist_calc_ident = inr.history_calc_ident
commit tran

SET IDENTITY_INSERT gca..cache off

select * from gca..cache_org_dup where history_calc_ident=158047210





SELECT A.*, B.HISTORY_IDENT 
INTO TEMPSRI_RC_NEW 
FROM GCA..RECREDIT_MAY2014 A JOIN TEMPSRI_RC B ON (SUBSTRING(A.rec_transaction_id,2,10) = B.TRANSIT_ID)


-----------------------------------------------------------------------------------------------------------------------------------------

---'7ECDyjQdqGJpIE8f3rupCfD1aZ4=' ---Changeme1 password 
--'N6hf+S0y3dVPBEm+dXAHxZXSQ1A=' --old password of LOGIN_NAME='njenkins_su'  modified on date 05Jul2013

select * from user_Data where LOGIN_NAME in ('njenkins_su','inoc')

-- Below script is for updating password to Changeme1
begin tran
update USER_DATA
set PASSWORD='7ECDyjQdqGJpIE8f3rupCfD1aZ4=', FORCE_PWD_CHANGE='T'
where LOGIN_NAME='njenkins_su'
commit tran


-- Below script is for creating Super User Account for Quik Reports
begin tran
insert into QRPROD..USER_DATA
select 'mgryzbowski_su' LOGIN_NAME, '7ECDyjQdqGJpIE8f3rupCfD1aZ4=' PASSWORD, 'Michael' FIRST_NAME, MIDDLE_INITIALS, 'Grzybowski' LAST_NAME, 
	getdate() ACCOUNT_CREATION_DATE, getdate() LAST_MODIFIED_DATE, LAST_MODIFIED_BY, LAST_LOGIN, 
	LAST_PASSWORD_CHANGE, IS_LOCKED, ACCOUNT_TYPE, CREATED_BY, 'T' FORCE_PWD_CHANGE, DELETED, POSITION, 
	'mgrzybowski@gcamail.com' EMAIL, TELEPHONE_NO, CASINOCODE, LAST_PASSWORD, COUNT_LOGIN_FAIL 
from QRPROD..USER_DATA 
where login_NAme like 'sridhar_SU%'
commit tran

-- Lookup table for account type
select * from USER_DATA_LOOKUP

-- remove the supper user account for login name, now the person will be normal user
begin tran
update USER_DATA set ACCOUNT_TYPE='U' where LOGIN_NAME in ('rgilliam_su')
commit tran

-- GCA admin account script
begin tran
insert into QRPROD..USER_DATA
select 'lpry_gau' LOGIN_NAME, '7ECDyjQdqGJpIE8f3rupCfD1aZ4=' PASSWORD, 'Lance' FIRST_NAME, MIDDLE_INITIALS, 'Pry' LAST_NAME, 
	getdate() ACCOUNT_CREATION_DATE, getdate() LAST_MODIFIED_DATE, LAST_MODIFIED_BY, LAST_LOGIN, 
	LAST_PASSWORD_CHANGE, IS_LOCKED, ACCOUNT_TYPE,'' CREATED_BY, 'T' FORCE_PWD_CHANGE, DELETED, POSITION, 
	'lpry@gcamail.com' EMAIL, TELEPHONE_NO, CASINOCODE, LAST_PASSWORD, COUNT_LOGIN_FAIL 
from QRPROD..USER_DATA 
where login_NAme ='jarellano_gau'
commit tran



-- QR Related Issues
select * from QRPROD..USER_DATA where LOGIN_NAME like 'williswilliams' or LOGIN_NAME like 'mgryzbowski%' or login_NAme like 'sridhar_SU%'

select * from QRPROD..USER_DATA_LOOKUP


select * from QRPROD..eureka_issues_25JAN2014



BEGIN TRAN
INSERT INTO QRPROD..TC_QR_DETAILS 
(
	ACCOUNTNO, CHECKS_APP_COUNT, CHECKS_APP_AMOUNT, 
	CODE3_COUNT, CODE3_AMOUNT, CODE4_COUNT, CODE4_AMOUNT,
	TELECHECK_BILLING, REPORT_MONTH, REPORT_YEAR
)
SELECT 
	[COLUMN 1], [COLUMN 3], [COLUMN 4], 
	[COLUMN 5], [COLUMN 6], [COLUMN 7], [COLUMN 8], 
	[COLUMN 9], [COLUMN 10], [COLUMN 11]
FROM QRPROD..eureka_issues_25JAN2014
COMMIT TRAN


select * from QRPROD..TC_QR_MASTER where CASINOCODE=437620

select * from QRPROD..TC_QR_MASTER where ACCOUNTNO=1035

select * from qrprod..CASINOS where CASINOCODE=466302

------==============  Sridhar, I am doing one example here
--- find the casino code that needs to be inserted. you will need account no, 
-- casino name(casino table), casino code before inserting
BEGIN TRAN
INSERT INTO QRPROD..TC_QR_MASTER
   (ACCOUNTNO ,ACCOUNT_NAME ,CASINOCODE ,CONTACT_NAME ,CONTACT_EMAIL ,INQUIRY_RATE ,TRANSACTION_CHARGE ,WARRANTY_MAXIMUM)
VALUES
    ('11076','MARK TWAIN CAF�','509514','','','2%',null,null)
COMMIT TRAN



-- Check if the accountno or casinocode is assign to other properties
select * from QRPROD..TC_QR_MASTER where  accountno=2100 or CASINOCODE=437647

-- take the correct property name
select * from QRPROD..CASINOS where CASINOCODE=437647

-- Insert script
BEGIN TRAN
INSERT INTO QRPROD..TC_QR_MASTER
   (ACCOUNTNO ,ACCOUNT_NAME ,CASINOCODE ,CONTACT_NAME ,CONTACT_EMAIL ,INQUIRY_RATE ,TRANSACTION_CHARGE ,WARRANTY_MAXIMUM)
VALUES
    ('2100','HOLLYWOOD GAMING AT MAHONING VALLEY RACE','437647','','','2%',null,null)
COMMIT TRAN

-- success message


begin tran
update QRPROD..TC_QR_MASTER
set CASINOCODE=541300, ACCOUNT_NAME='BALLYS TUNICA PAYROLL'
where ACCOUNTNO=1312
commit tran



select * from QRPROD..TC_QR_MASTER where CASINOCODE=444806

select * from QRPROD..TC_QR_MASTER where ACCOUNTNO=542

select * from QRPROD..CASINOS where CASINOCODE=518801

begin tran
update QRPROD..TC_QR_MASTER
set CASINOCODE=444806
where ACCOUNTNO=542 and CASINOCODE=444825
commit tran


begin tran
update QRPROD..TC_QR_MASTER
set ACCOUNTNO=496
where CASINOCODE=527411
commit tran

begin tran
update QRPROD..TC_QR_MASTER
set account_name='CHNOVAW CASINO IDABEL PR'
where ACCOUNTNO=1094 and CASINOCODE=527411
commit tran


begin tran
delete from qrprod..TC_QR_MASTER where ACCOUNTNO=1095 and CASINOCODE=527411
commit tran

-- need to confirm with Sridhar
-- for modifing the casinoname in casinos table
-- Mail subject line  -- QR UPDATES [Q361258]
begin tran
update QRPROD..CASINOS
set CASINONAME='MONTANA LILS NORTHERN LOUNGE'
where CASINOCODE=518801
commit tran

-----------------------------------------------------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------------------------------------------------
-- Encryption command
C:\DBEncryptServer\bin>SET JAVA_HOME=C:\java\jdk1.6.0_23

C:\DBEncryptServer\bin>SET CLASSPATH=;.;..\jars\xalan200.jar;..\jars\xerces123.jar;..\jars\jce1_2_2.jar;..\jars\sunjce_provider.jar;..\jars\local_policy.jar;..\jars\US_export_policy.jar

C:\DBEncryptServer\bin>SET CLASSPATH=;.;..\jars\xalan200.jar;..\jars\xerces123.jar;..\jars\jce1_2_2.jar;..\jars\sunjce_provider.jar;..\jars\local_policy.jar;..\jars\US_export_policy.jar;.;..\jars\jcert.jar;..\jars\jnet.jar;..\jars\jsdk.jar;..\jars\jsse.jar;..\jars\SocketServerAdapter.jar;..\jars\InfoNoxUtilPkg.jar

C:\DBEncryptServer\bin>C:\java\jdk1.6.0_23\bin\java -server -classpath ;.;..\jars\xalan200.jar;..\jars\xerces123.jar;..\jars\jce1_2_2.jar;..\jars\sunjce_provider.jar;..\jars\local_policy.jar;..\jars\US_export_policy.jar;.;..\jars\jcert.jar;..\jars\jnet.jar;..\jars\jsdk.jar;..\jars\jsse.jar;..\jars\SocketServerAdapter.jar;..\jars\InfoNoxUtilPkg.jar com.infonox.common.serverSocket.StartSocketServer


Quik marketing queries are stored in c:\QMOUT, if needed we can manualy upload them to the qr web server using ws_ftp.

uploaded files are stored in /home/sites/qrmanager/QMDownload on the quik reports server (10.175.157.195)


-- When/if the server reboots, How to Start DBEncryptions
DB will start automatically but we need to start the DBEncrypt manually from c:\DBEncryptServer\bin\

Run start.bat first, once launched this window shall remain open all the time.

then click on "keyInitialzer.bat" from the same path, it will open another DOS window and ask for password, enter "test", 
this window will close in a second or two. 

-- If success then check the logs folder where current date's log file would be created
-----------------------------------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------------------------------
-- AMS 
unzip the ams.zip to d:\ams folder
copy some file in d:\asm\tmp folder

then from tmp folder move the files to c:\ams

-- Remove the below files from main AMS directory and copy the remaining files to c:\ams
Directory of D:\AMS

11/23/2011  04:41 PM    <DIR>          .
11/23/2011  04:41 PM    <DIR>          ..
01/25/2010  01:39 PM             6,559 AddressMatch.cls
12/12/2001  05:13 PM             2,392 AddressNox.cls
07/31/2007  11:09 AM            36,864 AMSAPI.dll
07/31/2007  11:09 AM               956 AMSAPI.exp
07/31/2007  11:09 AM             2,586 AMSAPI.lib
11/24/2008  09:58 AM               846 AMSAPI.vbp
01/29/2010  12:15 PM                68 AMSAPI.vbw
03/18/2010  04:59 PM            86,016 AMSXAPI.dll
11/07/2011  11:11 AM               696 CopyAMS_PC.bat
12/11/2006  04:26 PM             7,440 Form1.frm
01/25/2010  01:39 PM                62 Group1.vbg
01/24/2010  12:16 PM            10,612 modAMSAPI.bas
01/29/2010  01:05 PM             7,952 NEW_AMSTEST.frm
06/28/2011  04:43 PM               727 NEW_AMSTEST.vbp
06/28/2011  04:43 PM                50 NEW_AMSTEST.vbw
11/24/2008  09:58 AM               734 Project1.vbp
01/29/2010  12:15 PM                50 Project1.vbw
06/29/2011  09:52 AM            69,632 QrAddressUpdate.exe
06/29/2011  09:52 AM            52,419 QrAddressUpdate.frm
06/29/2011  09:52 AM             1,133 QrAddressUpdate.vbp
07/05/2011  01:43 PM                50 QrAddressUpdate.vbw
01/28/2010  05:00 PM                42 REG_AMSXAPI.BAT
11/23/2011  04:41 PM                 0 removefiles.txt
01/28/2010  04:52 PM            24,576 TestAMS.exe
09/28/2010  10:05 AM               541 working copy of z4cxlog.dat
07/19/2011  12:28 PM               953 z4config.dat
11/23/2011  04:34 PM               541 z4cxlog.dat
              27 File(s)        314,497 bytes
               2 Dir(s)  57,028,329,472 bytes free

-- Once you copy the files into c:\, run the testams.exe program
c:\ams\testams.exe
|
|--> expresion date 
		if do not get any resposne then get the new AMS file from ICP Team..
		check the AMS left message 
		
		version button -- gives the version of AMS
		
del *.ver from AMS.zip (Which is send by ICP Team) and then copy all the files into c:/ams of GSQLSQLDB machine.
-----------------------------------------------------------------------------------------------------------------------------------------

C:\Windows\SysWOW64\odbcad32.exe - 32 bit ODBC administrator in Windows 2008 R2




-- below procedure is for autmation purpose
-- Get all required database name in cursor in which the scripts has to be executed
DECLARE AllDatabases CURSOR FOR
SELECT name FROM master.dbo.sysdatabases 
WHERE  name in ('BELGDB','BELIDB','CANADA','FRANCEDB','MACAUDB','STKITTSDB','SWITZDB','UKDB')
order by name asc

-- Open the cursor
OPEN AllDatabases

-- Declare all the variables
DECLARE @DBNameVar NVARCHAR(128),@Statement NVARCHAR(300)
DECLARE @START_DATE NVARCHAR(30), @END_DATE NVARCHAR(30)

-- Initialize the variables
SET @START_DATE=20150728
SET @END_DATE=20150729

-- Fetch the data values from cursor into declared variables
FETCH NEXT FROM AllDatabases INTO @DBNameVar
WHILE (@@FETCH_STATUS = 0)
BEGIN
	-- print the database name in which current script will be executed
	PRINT N'CHECKING DATABASE ' + @DBNameVar
	
	-- build the dynamic sql script
	SET @Statement = N'USE ' + @DBNameVar + CHAR(13)
				   + N'SELECT COUNT(*) 
				         FROM ' + @DBNameVar + '..HISTORY 
					    WHERE HISTORY_SETTLE_DATE BETWEEN ' + @START_DATE + ' AND ' + @END_DATE
				   + N'SELECT COUNT(*) 
				         FROM ' + @DBNameVar + '..CACHE 
					    WHERE HISTORY_SETTLE_DATE BETWEEN ' + @START_DATE + ' AND ' + @END_DATE	

    -- execute the dynamic sql scripts
	EXEC sp_executesql @Statement
	PRINT CHAR(13) + CHAR(13)

	-- fetch the next database value
	FETCH NEXT FROM AllDatabases INTO @DBNameVar
END
-- close and deallocate the open cursor
CLOSE AllDatabases
DEALLOCATE AllDatabases



-----
-- populate the cache table
Use GCA
Begin transaction
exec Generate_Cache_GW 20150823
exec Generate_Cache_GW 20150824 
Commit Transaction 



-- check the space
SELECT DB_NAME(database_id) AS DatabaseName, SUM( (size*8)/1024 ) SizeMB
FROM sys.master_files
WHERE DB_NAME(database_id) IN ('BELGDB','DELIDB','CANADA','CZECHDB','FRANCEDB','GCA','MACAUDB','QMDB','QRDEMO','QRPROD','SWITZDB','UKDB')
GROUP BY DB_NAME(database_id)
ORDER BY 2 DESC