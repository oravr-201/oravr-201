-- Apply GoldenGate Patch version 11.2.1.0.31 on Goldengate version 11.2.1.0.22

* Download the latest goldengate patch version and check the ReadMe file

1) Log-In to Source Primary DB (TW) GoldenGate and stop the Pump Process
	
	OGG_GGSCI> STOP PPTWRE

2) Take the backup of RBA and Sequence number of Trail files
	
	OGG_GGSCI> send extract EPTW, showtrans
	
	OGG_GGSCI> info PPTWRE, showch -- This command will have the last sequence number. check for (Current Checkpoint (current write position)) line
	
3) Log-In to Source Reporting DB (RW) GoldenGate and stop the Pump Process
	
	OGG_GGSCI> STOP PPRWRE

4) Take the backup of RBA and Sequence number of Trail files

	OGG_GGSCI> info PPRWRE, showch
	
5) Log-In Target Reporting DB (RE) where you will be applying GoldenGate patch

	sudo su -l goldengate

6) Stop all replicat, extract, jagent processes on RE DB
	
	OGG_GGSCI> stop rp*
	OGG_GGSCI> stop epre
	OGG_GGSCI> stop jagent
	
7) Take the backup of showch command from all replicat

	OGG_GGSCI> info replicat RPRERW, showch
	OGG_GGSCI> info replicat RPRETE01, showch
	OGG_GGSCI> info replicat RPRETW01, showch

8) Log-In to Target DB RE, Oracle user and stop the xag and goldengate vip resources
	sudo su -l oracle
	
	
	ORACLE> /opt/app/oracle/xag/bin/agctl status goldengate gg_wrpt
	
	ORACLE> /opt/app/oracle/xag/bin/agctl stop goldengate gg_wrpt --node wpl1trandbrpt1
	
	ORACLE> crsctl stop resource w-rpt-ggatevip.tsysacquiring.org  -n wpl1trandbrpt1
	
	ORACLE> crsctl stat res -t

 8.1) For safer side Please take the backup of GoldenGate user ggate from oracle.
 	
 	ORACLE> expdp rchaudhari directory=bkups dumpfile=expdp_ggatae_09092015.dmp logfile=expdp_ggate09092015.log schemas=ggate compression=all

9) Log-in to goldengate user on target DB RE and check if goldengate all processes are stopped
	sudo su -l goldengate
	
	OGG_GGSCI> info all

	OGG_GGSCI> exit -- from the ggsci prompt and come to shell of goldengate 
	
10) Take the backup of existing goldengate files and folder 
	
	cd /acsf/
	
	tar -cvf ogg_09sept2015.tar.gz goldengate/
	
11) unzip the latest version of goldengate patch to empty directory 
	
	mkdir ogg_112031
	
	cd ogg_112031
	
	unzip p21158243_1121031_Linux-x86-64.zip

12) Copy all files and folder from 
	
	alias cp='cp'
	cp -ar ogg_112031/* goldengate/  --*/

13)	log-in to goldengate and check the processes
	./ggsci
	
	OGG_GGSCI> info all
	
14) Update the checkpoint table of goldengate
	
	-- to update the checkpoint table you will have to loging with ggate admin user
	OGG_GGSCI> obey dirsql/dblogin.oby
	
	OGG_GGSCI> UPGRADE CHECKPOINTTABLE
	-- upgrading checkpoint might give error of column already exists, ignore it

15) Rebuild all the DDL scripts	

	OGG_GGSCI> sh sqlplus / as sysdba
	
SQL> @ddl_disable.sql
SQL> @ddl_remove
SQL> @marker_remove
SQL> @marker_setup
SQL> @ddl_setup
	-- here you will get the error if there are any sessions locked of goldengate of others. Please kill them and rerun it
SQL> @ddl_setup
SQL> @role_setup
SQL> GRANT GGS_GGSUSER_ROLE TO ggate;
SQL> EXEC DBMS_GOLDENGATE_AUTH.GRANT_ADMIN_PRIVILEGE (grantee=>'GGATE',privilege_type=>'capture',grant_select_privileges=>true, do_grants=>TRUE);
SQL> @sequence
SQL> @ddl_enable.sql
SQL>exit;
	OGG_GGSCI> info all
	OGG_GGSCI> exit;

16) log-in to oracle user and start the xag and goldengate vip services
	
		sudo su -l oracle
		
		-- start the goldengate vip on node 1
		ORACLE> crsctl start resource w-rpt-ggatevip.tsysacquiring.org -n wpl1trandbrpt1
		
		-- start the xag utility on node 1
		ORACLE> /opt/app/oracle/xag/bin/agctl start goldengate gg_erpt --node wpl1trandbrpt1
		
		ORACLE> crsctl stat res -t

17) log-in to goldengate and check the manager process is now started

	sudo su -l goldengate
	
	OGG_GGSCI> info all
	
	OGG_GGSCI> start jagent
	
	OGG_GGSCI> sh tail -f ggserr.log -- check any errors are coming while starting jagent

	OGG_GGSCI> start epre -- start the extract process of target db which should not have any data caputered as it's DR site DB
	
18) check the RMT trail file of target db and check the last file got transferd. Note-down the number
	This should be done before starting the Pump process of Source DB
	
	OGG_GGSCI> sh ls -ltrh dirdat/WS*	
		-rw-r----- 1 goldengate dba  96M Sep  7 01:02 WS000185
		-rw-r----- 1 goldengate dba  96M Sep  7 01:04 WS000186
		-rw-r----- 1 goldengate dba  96M Sep  7 03:51 WS000187
		-rw-r----- 1 goldengate dba  96M Sep  7 21:11 WS000188
		-rw-r----- 1 goldengate dba  96M Sep  8 01:03 WS000189
		-rw-r----- 1 goldengate dba  96M Sep  8 02:44 WS000190
		-rw-r----- 1 goldengate dba  96M Sep  8 07:13 WS000191
		-rw-r----- 1 goldengate dba  96M Sep  8 13:51 WS000192
		-rw-r----- 1 goldengate dba  96M Sep  8 21:05 WS000193
		-rw-r----- 1 goldengate dba  16M Sep  9 00:44 WS000194
		
19) log-in to source DB extracting DB (RW) and start the pumps
	
	-- first started the pump from RW, late the data get sync-up and do the activity on TW
	
	OGG_GGSCI> start PPRWRE
	OGG_GGSCI> info all 

20) log-in to target DB RE and check the rmt trail files are getting transfered from source extracting DB (RW)
	
	OGG_GGSCI> sh ls -ltrh dirdat/WS*	
	-rw-r----- 1 goldengate dba  96M Sep  7 01:02 WS000185
	-rw-r----- 1 goldengate dba  96M Sep  7 01:04 WS000186
	-rw-r----- 1 goldengate dba  96M Sep  7 03:51 WS000187
	-rw-r----- 1 goldengate dba  96M Sep  7 21:11 WS000188
	-rw-r----- 1 goldengate dba  96M Sep  8 01:03 WS000189
	-rw-r----- 1 goldengate dba  96M Sep  8 02:44 WS000190
	-rw-r----- 1 goldengate dba  96M Sep  8 07:13 WS000191
	-rw-r----- 1 goldengate dba  96M Sep  8 13:51 WS000192
	-rw-r----- 1 goldengate dba  96M Sep  8 21:05 WS000193
	-rw-r----- 1 goldengate dba  16M Sep  9 00:44 WS000194
	-rw-r----- 1 goldengate dba 1.5M Sep  9 00:44 WS000195
	
		
21) now start the target replicat by giving last transferred rmt trail files number
	
	OGG_GGSCI> alter replicat RPRERW, EXTSEQNO 000194
	OGG_GGSCI> start RPRERW
	OGG_GGSCI> info all
	OGG_GGSCI> sh tail -f ggserr.log -- check if there is any error while replicating the data to target database
	OGG_GGSCI> info all -- check the data is getting sync
	
22) Log-in to Toad and check if the data is getting replicated

	-- execute the same query on source db and target
	select max(transaction_id) from transnox_iox.trasnaction;

23) To start replicat process from TW to RE, Please follow similar steps #18 - #22 to get the extseqno to start the replicat process on
	target db and validate the replication data



