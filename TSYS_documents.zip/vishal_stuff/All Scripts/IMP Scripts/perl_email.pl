/*

--- The below script should be put in another file

# Setting the Mail configurational Parameter
MAIL_FROM="DCE-DB-Alerts@tsys.com"
MAIL_TO="acq-marc@tsys.com"
MAIL_CC="ifx-indsys@tsys.com"
MAIL_CC1="ifx-dbalerts@tsys.com"
SUBJECT="QARAC database Backup"


echo "Calling Email"
#$FILE_MSG is file variable to store the mail content
perl /bin/perlemail.pl -f $MAIL_FROM -t $MAIL_TO -c $MAIL_CC, $MAIL_CC1 -s "$SUBJECT" -l "$FILE_MSG"

*/

-- Below is the script perl script for sending EMail

-- save the file as perlemail.pl

#cat /bin/perlemail.pl
#!/usr/bin/perl -w
#
#Author : Angad Patil
#Version 1.0 =
#18 July 2011
use lib ".";
use Env;
use MIME::Lite;
#use Getopt::Std;
use Getopt::Long;
use Sys::Hostname;
#
my $host = hostname;
my $SMTP_SERVER = 'smtp.tsysacquiring.org';
my $SENDER = 'apatil@tsys.com';
my $RECIPIENT = 'apatil@tsys.com';
my $CCMAIL = '';
my $SUBJECT = "Test Email From $host";
my $FILENAME = "";

usage() if ( @ARGV < 1 or
! GetOptions ('help|?' => \$help,
        "f=s" => \$SENDER,
        "t=s" => \$RECIPIENT,
        "c=s" => \$CCMAIL,
        "s=s" => \$SUBJECT,
        "l=s" => \$FILENAME)
or defined $help );

sub usage
{
  print "\nUnknown option: @_\n" if ( @_ );
  print "\nusage: perlemail.pl [-f Sender Email ID] [-t Recepient Email ID] [-c CC] [-s Subject] [-l filename] [--help|-?]\n\n";
  exit;
}


if (-f ($FILENAME)){
        $yourmessage = `cat $FILENAME`;
        print "\n";
} else {
        print "\nThis is not a valid file. Please attach the appropriate mail content file.........\n\n";
        exit;
}

$msg = new MIME::Lite(
From => $SENDER,
To => $RECIPIENT,
CC => $CCMAIL,
Subject => $SUBJECT,
Type => "TEXT",
Data=> $yourmessage);


print "Sender :- $SENDER\n";
print "Recipient :-  $RECIPIENT\n";
print "CC :- $CCMAIL \n";
print "Subject :- $SUBJECT\n";
print "Email Server :- $SMTP_SERVER\n";

$msg->send('smtp', $SMTP_SERVER, Timeout=>60);
exit 0;
