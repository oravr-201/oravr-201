--------------------------------------------------------------------------------------------------------
-- How to switchover role primary to standby and vice versa in Oracle 11g R2 Part-6

-- On Primary DB

-- Steps 1) Check the open_mode and protection_mode of the primary database
SQL> select open_mode, database_role,protection_mode from v$database;

-- On StandBy DB

-- ** Check the open_mode and protection_mode of the primary database
SQL> select open_mode, database_role,protection_mode from v$database;


-- On Primary DB

-- steps 2) check the last log sequence number (archive log) details on both Primary and StandBy DB's
SQL> select sequence#, first_time,next_time,applied from v$archived_log order by sequence#;

-- On StandBy DB
SQL> select sequence#, first_time,next_time,applied from v$archived_log order by sequence#;

-- On both the database the max sequence# number should be matching

-- Now here I assiumed that all the checks are completed

-- Now convert Primary DB to StandBy database and StandBy database to Primary DB


-- On Primary DB

-- steps 3) Execute the command from (Primary database) to convert primary DB to StandBy database
SQL> alter database commit to switchover to standby;

-- open the alert log file of the primary database in new terminal of putty for more information 
-- or to check for any errors

-- steps 4) check the database open mode of Primary DB
SQL> select open_mode, database_role,protection_mode from v$database;

-- Here you will see that your Primary DB will be converted into Physical StandBy database

-- steps 5) Now shutdown the Primary DB
SQL> shutdown immediate;
SQL> exit;

-- steps 6) startup the primary DB in nomout stage
Oracle_>> sqlplus / as sysdba

SQL> startup nomount;

-- steps 7) mount your primary database 
SQL> alter database mount standby database;

-- steps 8) Now this the importent command to start the standby database for getting archived logs
SQL> alter database recover managed standby database disconnect from session;

-- this will take some time depend on your database size, you should always check for the alertlog file for 
-- any failure/errors on primary and standby database

-- steps 9) check the mode of the database
SQL> select open_mode,database_role,db_unqiue_name,protection_mode from v$database;


-- On StandBy DB

-- steps 10) convert StandBy database to Primary Database
SQL> alter database commit to switchover to primary;

-- then shutdown standby database
SQL> shutdown immediate;
SQL> exit;

-- again start the database ( the standby DB is now converted to Primary and Primary is converted to StandBy DB)
Oracle_>> sqlplus / as sysdba

SQL> startup

-- now check the role of the database of standby
select open_mode,database_role from v$database;

-- check the archive logs
SQL> select sequence#, first_time,next_time,applied from v$archived_log order by sequence#;

-- run to generate the archive log file on standby DB
SQL> alter system switch logfile;

-- now check the arvhive log sequence number on new standby machine which should be matching

--------------------------------------------------------------------------------------------------------
