

-- url for veridata installation and configuration 
http://www.atgwork.com/atgwork/2015/11/01/implement-oracle-goldengate-veridata-12c-validate-data-consistency-without-downtime/


Bidirectional Activity For GoldenGate replication

1) Make sure every table to be included in the replication has a Primary Key.
	--> Insert conflicts can be avoided and almost eliminated by implementing database specific primary keys and unique indexes and 
		is probably the easiest method of reducing the number of conflicts that can arise.
	
2) Sequences are not supported in Bi-Directional Replication. You must deploy one of the methods below to overcome it.

i. ODD/EVEN
	for e.g
		-- On DC A (Even Numbers)
		create sequence customer_sequence start with 2 increment by 2;
		
		-- On DC B (Odd Numbers)
		create sequence customer_sequence start with 1 increment by 2;
		
		-- Another Range example 
		For a 3 server environment, 
		server one starts at 1 and increments by 3 (1, 4, 7, 10, 13), 
		server two starts at 2 and increments by 3 (2, 5, 8, 11, 14), 
		and server three starts at 3 and increments by 3 (3, 6, 9, 12, 15).
		
		
		-- check_sequences.sql
		set serveroutput on format wrap
		set verify off
		spool check_seq.lst
		 
		declare
		  seq_test varchar2(4);  -- even, odd.
		  error_chk boolean := FALSE;
		begin
		 
		  seq_test := '&1';
		 
		  for c1 in
		    (select
		       SEQUENCE_NAME,
		       LAST_NUMBER,
		       INCREMENT_BY
		     from
		       user_sequences)
		  loop
		    if (upper(seq_test) = 'EVEN') then  --  check sequence is even number
		      if (mod(c1.LAST_NUMBER,2)!=0) then -- it is odd
		         error_chk := TRUE;
		      end if;
		    else                -- check sequence is odd number
		      if (mod(c1.LAST_NUMBER,2)=0) then -- it is even
		         error_chk := TRUE;
		      end if;
		    end if;
		    if error_chk then
		        dbms_output.put_line( 'ERROR: Sequence '||c1.sequence_name||' is incorrect!');
		        dbms_output.put_line( 'Last Number is '||c1.sequence_name);
		        dbms_output.put_line( 'It should be '||seq_test||'.');
		        dbms_output.put_line(' ');
		        error_chk := FALSE;
		    end if;
		 
		  end loop;
		end;
		/
		 
		spool off;
		exit


3) Consider 4 Data Centers


-- 1) Get the max count of USG_RPT_ID column data
SELECT MAX(USG_RPT_ID) FROM TRANSNOX_CPASS.REPORT_USAGE_AUDITTRAIL;

-- 2) Take the count Number and add that in bump-up sequence number
SELECT 14000001-13415603 FROM dual;
-- result of above query 584398

-- SELECT 14000002-13415603 FROM dual;
-- SELECT 14000003-13415603 FROM dual;
-- SELECT 14000004-13415603 FROM dual;

ALTER SEQUENCE transnox_cpass.REPORT_USAGE_SEQ INCREMENT BY 584398;

SELECT transnox_cpass.REPORT_USAGE_SEQ.NEXTVAL FROM dual ;

ALTER SEQUENCE transnox_cpass.REPORT_USAGE_SEQ INCREMENT BY 4;

SELECT transnox_cpass.REPORT_USAGE_SEQ.NEXTVAL FROM dual ;

SELECT transnox_cpass.REPORT_USAGE_SEQ.CURRVAL FROM dual ;

SELECT sequence_owner,sequence_name, increment_by,last_number
FROM dba_sequences
WHERE sequence_owner IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
  AND sequence_name = 'REPORT_USAGE_SEQ'
ORDER BY last_number DESC


-- Rept this on all rest of the DBs (RW, TE, RE)


/*



/* 

Below is script is in working condition

-- check any sequence is in odd number
SELECT sequence_owner,
       sequence_name,
       increment_by,
       cache_size,
       last_number
  FROM dba_sequences
 WHERE sequence_owner IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS', 'WEBFORT','KEYNOX_FX')
   AND MOD (last_number, 2) = 1;

-- even and odd scripts
  SELECT sequence_owner,
         sequence_name,
         increment_by,
         cache_size,
         last_number,
         MOD (last_number, 2) even,
         CASE
            WHEN MOD (last_number, 2) = 1 THEN last_number + 1001
            WHEN MOD (last_number, 2) = 0 THEN last_number + 1000
            ELSE last_number
         END
            final_even_no,
         CASE
            WHEN MOD (last_number, 2) = 1
            THEN
                  'alter sequence '
               || sequence_owner
               || '.'
               || sequence_name
               || ' increment by 1001 ;'
               || CHR (10)
               || 'select '
               || sequence_owner
               || '.'
               || sequence_name
               || '.nextval from dual;'
            WHEN MOD (last_number, 2) = 0
            THEN
                  'alter sequence '
               || sequence_owner
               || '.'
               || sequence_name
               || ' increment by 1000 ;'
               || CHR (10)
               || 'select '
               || sequence_owner
               || '.'
               || sequence_name
               || '.nextval from dual;'
            ELSE
               TO_CHAR (last_number)
         END
            first_even_time_increment,
         CASE
            WHEN MOD (last_number, 2) = 0
            THEN
                  'alter sequence '
               || sequence_owner
               || '.'
               || sequence_name
               || ' increment by 1000 ;'
               || CHR (10)
               || 'select '
               || sequence_owner
               || '.'
               || sequence_name
               || '.nextval from dual;'
            WHEN MOD (last_number, 2) = 1
            THEN
                  'alter sequence '
               || sequence_owner
               || '.'
               || sequence_name
               || ' increment by 1001 ;'
               || CHR (10)
               || 'select '
               || sequence_owner
               || '.'
               || sequence_name
               || '.nextval from dual;'
            ELSE
               TO_CHAR (last_number)
         END
            first_odd_time_increment,
            'alter sequence '
         || sequence_owner
         || '.'
         || sequence_name
         || ' increment by 2 ;'
         || CHR (10)
         || 'select '
         || sequence_owner
         || '.'
         || sequence_name
         || '.nextval from dual;'
            final_even_run
    FROM dba_sequences
   WHERE sequence_owner IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS', 'WEBFORT','KEYNOX_FX')
ORDER BY LAST_NUMBER DESC




-- check how many odd and even transactions happen based on given time
SELECT DECODE(MOD(transaction_id,2),1,'ODD Transaction_ID','Even Transaction_ID') "Transaction_ID Even/Odd Count",COUNT(1)
FROM transnox_cpass.TRANSACTION
WHERE 
--    time_stamp BETWEEN TO_DATE('01/21/2016 00:00:00','mm/dd/yyyy hh24:mi:ss') AND TO_DATE('01/21/2016 23:59:59','mm/dd/yyyy hh24:mi:ss')
  time_stamp >= SYSDATE -10/1440 
GROUP BY MOD(transaction_id,2)




-- script to take the difference and match them as per odd or even numbers
SELECT 'alter sequence '||sequence_owner||'.'||sequence_name|| ' INCREMENT BY '||even_incr||';' ||CHR(13)||
      'select '||sequence_owner||'.'||sequence_name||'.nextval from dual;'||CHR(13)||
       'alter sequence '||sequence_owner||'.'||sequence_name|| ' INCREMENT BY 2;' ||CHR(13)||
      'select '||sequence_owner||'.'||sequence_name||'.nextval from dual;'seq_script
FROM (
 SELECT cl.SEQUENCE_OWNER,
            cl.SEQUENCE_NAME,
            cl.LAST_NUMBER cl_LAST_NUMBER,
            tp.LAST_NUMBER tp_LAST_NUMBER,
            cl.LAST_NUMBER - tp.LAST_NUMBER diff_number,
            DECODE(MOD (cl.LAST_NUMBER - tp.LAST_NUMBER, 2),0,(cl.LAST_NUMBER - tp.LAST_NUMBER), 1, (cl.LAST_NUMBER - tp.LAST_NUMBER)+1) even_incr, 
            cl.CACHE_SIZE
       FROM dba_sequences@uatdb_51 tp, dba_sequences cl
      WHERE     cl.SEQUENCE_OWNER IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS', 'WEBFORT','KEYNOX_FX') 
            AND cl.SEQUENCE_OWNER = tp.SEQUENCE_OWNER
            AND cl.SEQUENCE_NAME = tp.SEQUENCE_NAME
--   ORDER BY 5 DESC;
) WHERE even_incr IS NOT NULL;


-- Final Script for Odd and Even Number

SELECT SEQUENCE_OWNER, SEQUENCE_NAME, INCREMENT_BY, CACHE_SIZE, 
        LAST_NUMBER, 
        FINAL_INCREMENTAL_ODD_NUM - LAST_NUMBER ODD_BUMPUP_NUM, 
        FINAL_INCREMENTAL_ODD_NUM, 
        FINAL_INCREMENTAL_EVEN_NUM - LAST_NUMBER EVEN_BUMPUP_NUMBER, 
        FINAL_INCREMENTAL_EVEN_NUM,
        'ALTER SEQUENCE ' || SEQUENCE_OWNER || '.' || SEQUENCE_NAME || ' INCREMENT BY ' || TO_NUMBER(FINAL_INCREMENTAL_ODD_NUM - Last_Number) || ' ;' || CHR (13) || 'SELECT ' || SEQUENCE_OWNER || '.' || SEQUENCE_NAME || '.NEXTVAL FROM DUAL;' || CHR(13) || 'ALTER SEQUENCE ' || SEQUENCE_OWNER || '.' || SEQUENCE_NAME || ' INCREMENT BY 2;' || CHR(13) || 'SELECT ' || SEQUENCE_OWNER || '.' || SEQUENCE_NAME || '.NEXTVAL FROM DUAL;' Odd_Num_Script,
        'ALTER SEQUENCE ' || SEQUENCE_OWNER || '.' || SEQUENCE_NAME || ' INCREMENT BY ' || TO_NUMBER(FINAL_INCREMENTAL_EVEN_NUM - Last_Number) || ' ;' || CHR (13) || 'SELECT ' || SEQUENCE_OWNER || '.' || SEQUENCE_NAME || '.NEXTVAL FROM DUAL;' || CHR(13) || 'ALTER SEQUENCE ' || SEQUENCE_OWNER || '.' || SEQUENCE_NAME || ' INCREMENT BY 2;' || CHR(13) || 'SELECT ' || SEQUENCE_OWNER || '.' || SEQUENCE_NAME || '.NEXTVAL FROM DUAL;' Even_Num_Script
FROM 
(
    SELECT SEQUENCE_OWNER, SEQUENCE_NAME, INCREMENT_BY, CACHE_SIZE, LAST_NUMBER,
         DECODE(MOD (LAST_NUMBER, 2), 1, '1', 0, '0') CHECK_NUM_EVEN_OR_ODD,
         (CASE
            WHEN MOD (LAST_NUMBER, 2) = 1 THEN LAST_NUMBER + 5000
            WHEN MOD (LAST_NUMBER, 2) = 0 THEN LAST_NUMBER + 5001
            ELSE LAST_NUMBER
         END) FINAL_INCREMENTAL_ODD_NUM,
         (CASE
            WHEN MOD (LAST_NUMBER, 2) = 1 THEN LAST_NUMBER + 5001
            WHEN MOD (LAST_NUMBER, 2) = 0 THEN LAST_NUMBER + 5000
            ELSE LAST_NUMBER
         END) FINAL_INCREMENTAL_EVEN_NUM
     FROM DBA_SEQUENCES
    WHERE SEQUENCE_OWNER IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS', 'WEBFORT','KEYNOX_CPASS') 
) 
ORDER BY Sequence_Owner ASC, Last_Number DESC


*/

ii. RANGE
		for e.g
			-- On DC A (Even Numbers)
			create sequence customer_sequence start at 1 increment by 3;
			
			-- On DC B (Odd Numbers)
			create sequence customer_sequence start at 3 increment by 3;
		
iii.CONCATENATE



3) Trigger causes uniqueness issues. You must do the following to overcome them.
i. You must disable the triggers on the target or use OGG to suppress them.
ii. Specify the DBOPTIONS SUPPRESSTRIGGERS parameter in Extract parameter file when using GoldenGate version 10.2.0.4 or 11.2.0.2 (NOT 11.1).


4) Data Looping - In a Bi-Directional replication configuration, each side processes transaction actively. For Insert transactions it can 
cause uniqueness issues and for updates it can spawn into an infinite loop. 

To avoid data looping specify the following parameters should be used in Extract process, on both databases.

TRANLOGOPTIONS EXCLUDEUSER GGUSER
OR
TRANLOGOPTIONS EXCLUDEUSERID 10

5) TRUNCATE Table - Truncate table operations are not detected by data looping. You must truncate tables only in one database. You can accomplish 
it by one of the following ways:

i. Control user access using privileges so that they can truncate tables only in one direction.
OR
ii. Specify the parameter �GETTRUNCATE� from source to target and �IGNORETRUNCATE� from target to source.

6) Limitations
� Bi-Directional Replication works only on Windows, UNIX/Linux.
� CDR works with numeric, date/timestamp colums and char/varchar2 only.
� LOB , ADT and UDT data types are NOT supported with CDR.
� BATCHSQL is not supported in Bi-Directional Replication.

URL : http://www.vitalsofttech.com/goldengate-active-active-database-replication-with-conflict-detection-and-resolution/

http://www.oracle.com/webfolder/technetwork/tutorials/obe/fmw/goldengate/11g/orcl_orcl/index.html



----------------------------------------------------------------------------------------------------------------------------------------------------

MAP TRANSNOX_IOX.*, TARGET TRANSNOX_IOX.*,
COMPARECOLS (ON UPDATE ALL, ON DELETE ALL),
RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, IGNORE)),
RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, IGNORE)),
RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, IGNORE)),
RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, DISCARD)),
RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, IGNORE));

UPDATEROWMISSING :- When it is "OVERWRITE" 
		1) If there is update statement on table which do not have a Primary key, the whole record will be considered in where condition. if the record is not
		   matching then it will try to insert the new record.


-- In replicat process
MAP sh.inventory, TARGET sh.inventory,
COMPARECOLS (ON UPDATE ALL, ON DELETE ALL),
RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, USEMIN (last_dml))),
RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, USEMAX (last_dml))),
RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, OVERWRITE)),
RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, DISCARD));


MAP sh.inventory, TARGET sh.inventory,
COMPARECOLS (ON UPDATE ALL, ON DELETE ALL),
RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, USEMIN (last_dml))) ,
RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, OVERWRITE)),
RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, DISCARD));

-- The DELETEROWMISSING keyword indicates that we use a DISCARD resolution if the row does not exist during a DELETE operation � we discard the trail record.
-- The DELETEROWEXOSTS keyword means that if a row exists during a DELETE operation, use OVERWRITE to resolve the conflict situation � apply the delete in the trail record.

-- Let us now look a conflict involving an INSERT statement being issued from two sites at the same time � in this case both sites 
-- are trying to insert a row with the same PROD_ID but with different values for the column QTY_IN_STOCK.
-- This is the parameter file which will exist on both Site A and Site B and basically comtinuing from the above example involving the DELETE condition CDR.

MAP sh.inventory, TARGET sh.inventory,
COMPARECOLS (ON UPDATE ALL, ON DELETE ALL),
RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, USEMIN (last_dml))),
RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, USEMAX (last_dml))),
RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, OVERWRITE)),
RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, DISCARD));


----------------------------------------------------------------------------------------------------------------------------------------------------


lw-txn-transit.rac.db


The REPERROR (1403, Discard) parameter is used to identify a condition when the row the REPLICAT is looking for, is not present in the destination database (Used in CDR). 
The REPERROR (0001, Discard) is raised when a duplicate INSERT is attempted but it violates a PK or unique value key as the row is already present in the table.


The parameter RESOLVECONFLICT takes any of the arguments listed in Table 5-5. Depending on the business rules for data conflict resolution handling, associate the argument with a resolution method.

INSERTROWEXISTS -- Handles unique constraint violation. The target database has primary key or unique key constraint enabled.
UPDATEROWEXISTS -- Handles update data conflict when the before image value for one or more columns differ from the current database value.
UPDATEROWMISSING -- Handles data conflict when the row does not exist on the target database.
DELETEROWEXISTS -- Handles delete data conflict when before image value for one or more columns differ from the current database value.
DELETEROWMISSING -- Handles data conflict when the row deleted on source does not exist on the target database.


Each conflict type is associated with one resolution method. The following is the list of methods applied to a DEFAULT or named resolution:

�  OVERWRITE
�  IGNORE
�  DISCARD
�  USEMIN
�  USEMAX
�  USEDELTA 


----------------------------------------------------------------------------------------------------------------------------------------------------
-- Considerations for an Active-Active Configuration


-- Changed for Bidirectional, Date 02-Jun-2015
ADD TRACETABLE GGATE.GGS_TRACE_TBL

-- Endless Loop Detection in Bi-Directional Replication
-- When the Replicat applies transactions to the target database, it writes to a trace table which the Extract
-- on the same system uses for loop detection by eliminating the Replicat transactions. When the Replicat starts,
-- if the parameter tracetable is configured then it uses the specified trace table. If the parameter tracetable
-- is not configured, it tries the default trace table name ggs_table owned by the Oracle GoldenGate user of the dblogin parameter.
TRACETABLE GGATE.GGS_TRACE_TBL



-- Changed for Bidirectional, Date 02-Jun-2015
-- Valid for all Extract only. Controls whether or not DDL operations produced by Replicat
-- are included in the content that Extract writes to a trail or file
-- DDLOPTIONS GETREPLICATES, GETAPPLOPS, REPORT
DDLOPTIONS GETREPLICATES


-- Changed for Bidirectional, Date 02-Jun-2015
-- Valid for all Replicat (Oracle only). Use in an active-active bi-directional configuration. 
-- This parameter notifies Replicat on the system where DDL originated that this DDL was propagated to 
-- the other system, and that Replicat should now update its object metadata cache to match the new metadata. 
-- This keeps Replicat's metadata cache synchronized with the current metadata of the local database.
DDLOPTIONS UPDATEMETADATA



-- Disable Sequences for Bidirectional replication

-- Testing Schema (Add in Extract and Pumps)
TABLE TNOX_CPASS.*;

-- Testing Schema Replication (Add in Replicat)
MAP TNOX_CPASS.*, TARGET TNOX_CPASS.*;
----------------------------------------------------------------------------------------------------------------------------------------------------

-- Extract Process

-- Table Name without CLOB and BLOB Data Typies
SELECT 'TABLE '||OWNER||'.'||TABLE_NAME ||', GETBEFORECOLS(ON UPDATE ALL, ON DELETE ALL);' TABLE_NAME
FROM
(
    SELECT UNIQUE owner, table_name
      FROM dba_tab_columns
     WHERE owner = 'SNOX4TRANSNOX_CPASS'
     MINUS
    SELECT UNIQUE owner, table_name FROM dba_tab_columns WHERE  owner = 'SNOX4TRANSNOX_CPASS' AND DATA_TYPE  IN ('CLOB','BLOB','LONG','RAW')
)
WHERE NOT (REGEXP_LIKE (table_name,'s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
  AND TABLE_NAME IN (SELECT OBJECT_NAME FROM dba_objects doj WHERE OWNER='SNOX4TRANSNOX_CPASS' AND OBJECT_TYPE='TABLE')
ORDER BY table_name ASC

-- Table Name with CLOB and BLOB Data Typies
SELECT UNIQUE 'TABLE '||OWNER||'.'||TABLE_NAME ||';' TABLE_NAME
FROM DBA_TAB_COLUMNS
WHERE OWNER='SNOX4TRANSNOX_CPASS'
   AND DATA_TYPE IN ('CLOB','BLOB')
   AND NOT (REGEXP_LIKE (table_name,'s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
   AND TABLE_NAME IN (SELECT OBJECT_NAME FROM dba_objects doj WHERE OWNER='SNOX4TRANSNOX_CPASS' AND OBJECT_TYPE='TABLE')
ORDER BY TABLE_NAME ASC;

-- Replicat Process

-- Queries for Replicat process
-- Table Name without CLOB and BLOB Data Typies
SELECT 'MAP '||OWNER||'.'||TABLE_NAME ||', TARGET '||OWNER||'.'||TABLE_NAME ||', COMPARECOLS (ON UPDATE ALL, ON DELETE ALL), '||CHR(13)||
       ' RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, IGNORE)), '||CHR(13)||
       ' RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, IGNORE)), RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, OVERWRITE)), '||CHR(13)||
       ' RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, IGNORE)), RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, DISCARD));' TABLE_NAME
FROM
(
    SELECT UNIQUE owner, table_name
      FROM dba_tab_columns
     WHERE owner = 'SNOX4TRANSNOX_CPASS'
     MINUS
    SELECT UNIQUE owner, table_name FROM dba_tab_columns WHERE  owner = 'SNOX4TRANSNOX_CPASS' AND DATA_TYPE  IN ('CLOB','BLOB','LONG','RAW')
)
WHERE NOT (REGEXP_LIKE (table_name,'s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
  AND TABLE_NAME IN (SELECT OBJECT_NAME FROM dba_objects doj WHERE OWNER='SNOX4TRANSNOX_CPASS' AND OBJECT_TYPE='TABLE')
ORDER BY table_name ASC;

-- Table Name with CLOB and BLOB Data Typies
SELECT UNIQUE 'MAP '||OWNER||'.'||TABLE_NAME ||', TARGET '||OWNER||'.'||TABLE_NAME ||';' TABLE_NAME
FROM DBA_TAB_COLUMNS
WHERE OWNER='SNOX4TRANSNOX_CPASS'
   AND DATA_TYPE IN ('CLOB','BLOB')
   AND NOT (REGEXP_LIKE (TABLE_NAME,'s._temp[[:digit:]]|^MV_|^PURGE|^d_|^TEMP_*|bin\$|[[:digit:]]|Z_TRIGGER*|TOAD_PLAN_TABLE','i'))
   AND TABLE_NAME IN (SELECT OBJECT_NAME FROM dba_objects doj WHERE OWNER='SNOX4TRANSNOX_CPASS' AND OBJECT_TYPE='TABLE')
ORDER BY TABLE_NAME ASC;

----------------------------------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------------------------------------------------------------------------------------------------
-- Skipping a transaction in GoldenGate

-- URL
-- http://appcrawler.com/wordpress/2012/03/08/skipping-a-transaction-in-goldengate/

/*
	We are the midst of a mission critical implementation that involves an active-active setup. We have chosen GoldenGate to manage 
	the distribution of data between the two sites (soon to be three).

	This is the first of a series of articles and tips on our findings as we use the software.

	We have spent a lot of time understanding the conflict detection and resolution capabilities of the software, and wanted to �break it� 
	so we could document how to fix it. In our case, we simply inserted the exact same row on each database at the same time. Each failed 
	with an ORA-0001 error, otherwise known as �unique constraint violated�.

	Since this was a contrived test case, the fix was fairly simple. We simply wanted to skip the transaction on each database and continue 
	with replicat processing. In real life, it will rarely if ever be this simple in terms of a �real� problem.

	There are two ways to do this, the first of which is much easier. We show the second method for the sake of completeness, as well as 
	shedding some light on another GoldenGate utility.

	FIRST METHOD:

	In this method, we run the replicat executable at the command line, rather than ussing ggsci to run it internally. We pass our replicat 
	parameter file to it, as well as the skiptransaction argument. We could also skip several transactions if we knew the CSN (commit sequence number) 
	at which we wanted to start.

	After we wait a few seconds and are confident it has gotten past the transaction to be skipped, we issue a kill against our replicat process, 
	and then restart it. Finally, we show the tail of our ggserr.log file to show the transaction was skipped and that our replicat has been 
	successfully restarted.

*/

goldengate> replicat paramfile dirprm/cmhrep.prm skiptransaction
 

 
Opened trail file /u01/app/oracle/acfsdata/ggate001/oracle/dirdat/r1000005 at 2012-03-11 15:42:13
 
2012-03-11 15:42:13  INFO    OGG-01370  User requested START SKIPTRANSACTION. The current transaction will be skipped. Transaction ID 44.16.324, position Seqno 5, RBA 377497.
 
MAP resolved (entry ATL.TEST):
  map ATL.TEST, target cmh.test, sqlexec (id check_conflict, on update, beforefilter, query "select d from cmh.test where c = :p1", params (p1 = c)), filter (on update, before.d <> check_conflict.d, raiseerror 9999);
Using following columns in default map by name:
  C, D
 
Using the following key columns for target table CMH.TEST: C.
 
 
Wildcard MAP resolved (entry ATL.*):
  map ATL.TEST, target cmh.TEST;
Detected duplicate MAP entry.  Using prior MAP specification.
 
Quit

goldengate> ggsci
 
Oracle GoldenGate Command Interpreter for Oracle
Version 11.1.1.1.2 OGGCORE_11.1.1.1.2_PLATFORMS_111004.2100
Linux, x86, 32bit (optimized), Oracle 11g on Oct  4 2011 23:53:33
 
Copyright (C) 1995, 2011, Oracle and/or its affiliates. All rights reserved.
 
GGSCI (expressdb1) 1> start cmhrep
 
Sending START request to MANAGER ...
REPLICAT CMHREP starting
 
 
GGSCI (expressdb1) 2> exit

goldengate> tail -f ggserr.log

2012-03-11 15:42:12  INFO    OGG-00995  Oracle GoldenGate Delivery for Oracle, cmhrep.prm:  REPLICAT starting.
2012-03-11 15:42:13  INFO    OGG-00996  Oracle GoldenGate Delivery for Oracle, cmhrep.prm:  REPLICAT started.
2012-03-11 15:42:13  INFO    OGG-01370  Oracle GoldenGate Delivery for Oracle, cmhrep.prm:  User requested START SKIPTRANSACTION. The current transaction will be skipped. Transaction ID 44.16.324, position Seqno 5, RBA 377497.
2012-03-11 15:42:39  INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (oracle): start cmhrep.
2012-03-11 15:42:39  INFO    OGG-00963  Oracle GoldenGate Manager for Oracle, mgr.prm:  Command received from GGSCI on host 192.168.1.50 (START REPLICAT CMHREP ).
2012-03-11 15:42:39  INFO    OGG-00975  Oracle GoldenGate Manager for Oracle, mgr.prm:  REPLICAT CMHREP starting.
2012-03-11 15:42:39  INFO    OGG-00995  Oracle GoldenGate Delivery for Oracle, cmhrep.prm:  REPLICAT CMHREP starting.
2012-03-11 15:42:40  INFO    OGG-00996  Oracle GoldenGate Delivery for Oracle, cmhrep.prm:  REPLICAT CMHREP started.

SECOND METHOD:

-- We start by showing the error at the bottom of our ggserr.log file.

2012-03-07 20:42:44  WARNING OGG-00869  Oracle GoldenGate Delivery for Oracle, rep1.prm:  OCI Error ORA-00001: unique constraint (CMH.ORDER_PK) violated (status = 1), SQL <INSERT INTO "CMH"."ORDERS" ("ID","CUSTOMER_ID","ORDER_DATE") VALUES (:a0,:a1,:a2)>.
2012-03-07 20:42:44  WARNING OGG-01004  Oracle GoldenGate Delivery for Oracle, rep1.prm:  Aborted grouped transaction on 'CMH.ORDERS', Database error 1 (OCI Error ORA-00001: unique constraint (CMH.ORDER_PK) violated (status = 1), SQL <INSERT INTO "CMH"."ORDERS" ("ID","CUSTOMER_ID","ORDER_DATE") VALUES (:a0,:a1,:a2)>).
2012-03-07 20:42:44  WARNING OGG-01003  Oracle GoldenGate Delivery for Oracle, rep1.prm:  Repositioning to rba 6343157 in seqno 0.
2012-03-07 20:42:44  WARNING OGG-01154  Oracle GoldenGate Delivery for Oracle, rep1.prm:  SQL error 1 mapping ATL.ORDERS to CMH.ORDERS OCI Error ORA-00001: unique constraint (CMH.ORDER_PK) violated (status = 1), SQL <INSERT INTO "CMH"."ORDERS" ("ID","CUSTOMER_ID","ORDER_DATE") VALUES (:a0,:a1,:a2)>.
2012-03-07 20:42:44  WARNING OGG-01003  Oracle GoldenGate Delivery for Oracle, rep1.prm:  Repositioning to rba 6343157 in seqno 0.
2012-03-07 20:42:44  ERROR   OGG-01296  Oracle GoldenGate Delivery for Oracle, rep1.prm:  Error mapping from ATL.ORDERS to CMH.ORDERS.
2012-03-07 20:42:44  ERROR   OGG-01668  Oracle GoldenGate Delivery for Oracle, rep1.prm:  PROCESS ABENDING.

-- We then get the current RBA in use by the replicat. This is the actual byte position in the trail file at which the replicat process will issue 
-- an fseek() call and begin processing when started.

 
goldengate>./ggsci
 
Oracle GoldenGate Command Interpreter for Oracle
Version 11.1.1.1.2 OGGCORE_11.1.1.1.2_PLATFORMS_111004.2100
Linux, x86, 32bit (optimized), Oracle 11g on Oct  4 2011 23:53:33
 
Copyright (C) 1995, 2011, Oracle and/or its affiliates. All rights reserved.
 
 
 
GGSCI (expressdb1) 1> info rep1
 
REPLICAT   REP1      Last Started 2012-03-07 19:32   Status ABENDED
Checkpoint Lag       00:06:26 (updated 00:24:59 ago)
Log Read Checkpoint  File /u01/app/oracle/acfsdata/ggate001/oracle/dirdat/r1000000
                     2012-03-07 20:36:18.000204  RBA 6343157
/*
	From the information above, we need the name of the current trail file (/u01/app/oracle/acfsdata/ggate001/oracle/dirdat/r1000000) and the RBA.

	We need to start the replicat process at the next record after the RBA above (6343157), since this one has the problem. Please note 
	that we can�t simply increment the RBA by 1, as the RBA is an address in the file that must start with a format that GoldenGate recognizes 
	as valid. If we change the replicat to start from an invalid address, it will throw an exception similar to the following in the ggserr.log file.

	Incompatible record in /u01/app/oracle/acfsdata/ggate001/oracle/dirdat/r1000004, rba 3926317 (getting header).

	To get the �real� address of the next record at which we would like to start processing, we use the logdump executable provided as part 
	of the stock GoldenGate installation.
*/

goldengate> logdump
 
Oracle GoldenGate Log File Dump Utility
Version 11.1.1.1.2 OGGCORE_11.1.1.1.2_PLATFORMS_111004.2100
 
Copyright (C) 1995, 2011, Oracle and/or its affiliates. All rights reserved.
 
 
 
Logdump 422 >open /u01/app/oracle/acfsdata/ggate001/oracle/dirdat/r1000000
Current LogTrail is /u01/app/oracle/acfsdata/ggate001/oracle/dirdat/r1000000
Logdump 423 >position 6343157
Reading forward from RBA 6343157

Logdump 424 >next
2012/03/07 20:36:18.000.204 Insert               Len    78 RBA 6343157
Name: ATL.ORDERS
After  Image:                                             Partition 4   G  s
 0000 0005 0000 0001 3100 0100 2800 0000 2437 3032 | ........1...(...$702
 6631 3463 642d 6233 3032 2d34 6261 632d 3863 6161 | f14cd-b302-4bac-8caa
 2d65 3565 6130 6336 6464 3939 3400 0200 1500 0032 | -e5ea0c6dd994......2
 3031 322d 3033 2d30 373a 3230 3a33 363a 3138      | 012-03-07:20:36:18
 
Logdump 425 >next
 
2012/03/07 20:54:29.001.164 Insert               Len   113 RBA 6343347
Name: ATL.ORDERS
After  Image:                                             Partition 4   G  b
 0000 0028 0000 0024 6563 3831 3331 3965 2d66 3234 | ...(...$ec81319e-f24
 372d 3438 6337 2d39 3831 662d 6266 3138 3637 3735 | 7-48c7-981f-bf186775
 3938 3366 0001 0028 0000 0024 3462 3462 6565 6330 | 983f...(...$4b4beec0
 2d63 6138 392d 3436 6639 2d38 6262 332d 6333 3665 | -ca89-46f9-8bb3-c36e
 3266 6537 6432 3736 0002 0015 0000 3230 3132 2d30 | 2fe7d276......2012-0
 332d 3037 3a32 303a 3534 3a32 39                  | 3-07:20:54:29
 
Logdump 426 >

/*
	Because we looked at the discard file we specified in the replicat parameter file, we knew the offending record had 1 for the primary key 
	value�yeah, as I noted, the test case is contrived :)

	In logdump, we first open the trail file obtained above. We then typed position RBA, where RBA is the RBA we obtained in the �info replicat� 
	command above, and then �next�. This takes us to the position in trail file from which GoldenGate would start processing. As noted, we want 
	to move to the next record and obtain its RBA. We simply type next, and see the RBA from which we would like to start processing is 6343347. 
	We then exit from logdump, and alter our replicat to start from this RBA. Please note if your replicat is already running 
	(it couldn�t be in our test case), you will have to stop it before issuing the alter command below.
*/

goldengate> ggsci
 
Oracle GoldenGate Command Interpreter for Oracle
Version 11.1.1.1.2 OGGCORE_11.1.1.1.2_PLATFORMS_111004.2100
Linux, x86, 32bit (optimized), Oracle 11g on Oct  4 2011 23:53:33
 
Copyright (C) 1995, 2011, Oracle and/or its affiliates. All rights reserved.
 
 
 
GGSCI (expressdb1) 1> alter replicat rep1, extrba 6343347
REPLICAT altered.
 
 
GGSCI (expressdb1) 2> start rep1
 
Sending START request to MANAGER ...
REPLICAT REP1 starting
 
 
GGSCI (expressdb1) 3> exit

-- Using either method above, if you issue a �stats replicat yourrepname� you should see transactions being processed by the replicat.
----------------------------------------------------------------------------------------------------------------------------------------------------
   

-- CREATE TABLESPACE IN PDB1 DB
CREATE TABLESPACE oggmgmt_tbls DATAFILE   SIZE 5G AUTOEXTEND OFF

CREATE USER oggmgmt IDENTIFIED BY ispl_201 DEFAULT TABLESPACE oggmgmt_tbls TEMPORARY TABLESPACE temp

GRANT CREATE SESSION,RESOURCE TO oggmgmt


-- \\10.132.13.30:/oradata2/oracle/ogg_vdt/GoldenGate_Veridata_redhatAS40_x64.zip
download veridata server software

-- unzip the file
unzip /oradata2/oracle/ogg_vdt/GoldenGate_Veridata_redhatAS40_x64.zip

-- loging to vnc server 10.132.13.30
open terminal
cd /oradata2/oracle/ogg_vdt/

./GoldenGate_Veridata_redhatAS40_x64.sh

which will open GUI installation
   
----------------------------------------------------------------------------------------------------------------------------------------------------
/*
	
CDR replicat fails with OGG-01921 Missing GETBEFORECOLS With Conflict Detection Enabled In Target Table (Doc ID 1543436.1)

--> APPLIES TO:

Oracle GoldenGate - Version 11.2.0.0.0 and later
Information in this document applies to any platform.

--> SYMPTOMS

Replicate fails with error "ERROR   OGG-01921  Missing GETBEFORECOLS with conflict detection enabled in target table xxx.table"

You may also see a warning like below

WARNING OGG-01923  Conflict resolution failed with SQL error 1 on original conflict with SQL error 1,403

Replicate hangs at resolveconflict, unable to find the before image to process

--> CAUSE

Replicate mapping shows resolve conflict like  RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, OVERWRITE)
The CDR becomes active for UPDATEROWMISSING, (DEFAULT, OVERWRITE) option. The replicate must have hit a ORA 1403 and CDR for UPDATEROWMISSING has become active. While trying to overwrite the row with the before image, replicat hits a ORA 0001, row already exists or it is not able to find the before image in the trails.
The sql error -1 is caused by unique constraint on a non key column

--> SOLUTION

1) Check for suspicious triggers on table
2) Check for all constraints for all columns for the problem table and decide the relevance of the constraint that causes the issue.

SQL> select CONSTRAINT_NAME, CONSTRAINT_TYPE, INDEX_NAME from dba_constraints where TABLE_NAME='<table name>' and owner='<schema>' and owner=''SYS;

OR can be resolve with 

-- ERROR   OGG-01920 Missing COMPARECOLS column TERMINALID in before image, while mapping to target table

-- Replicat Is Abending With OGG-01921 (Doc ID 1557251.1)

-- Suggested to re-position the replicat to the RBA of the BEFORE IMAGE and restart the replicat
ALTER REPLICAT <replicat group name>, EXTSEQNO <trail sequence number> EXTRBA <trail record RBA>


*/
----------------------------------------------------------------------------------------------------------------------------------------------------

-- Discussion Points
1) Conflict Detection and Resolution (CDR)
2) Understanding Conflicts and Complex Resolutions
3) Using Trusted Source Resolution (Which DB Will be considered as a Trusted Source ?)
4) Quantitative Conflict Resolution
5) Conflict Notification and Tracking -- (Exception Table Conifguration) Optional for all tables
6) Determine the method of replications to handle Replication lagging
	i) Module wise Replicator Configuration (Should be Consider Foreign Key constraint and Logical data Referencing)
   ii) Single Replicator file with Range replication
  iii) Should we Separate Arcot Replicator?
   iV) Should we Separate Non-Transactional Flow Tables like Infonox_Service_Usage, Request_Audit_Trail, Event, Institution_Routing_Num_Temp, Institution_Routing_Num_Hist 

----------------------------------------------------------------------------------------------------------------------------------------------------
-- Check List of Bi-Directional Replication

1) Truncate Table operation
* Truncate Table operations cannot be detected for loops
* Make sure that GETTRUNCATES is ON for only one direction
* Use IGNORETRUNCATES (default) for the other direction
* Change database security so truncates can only be issued on one system


TRUNCATE Table - Truncate table operations are not detected by data looping. To resolve the issue of truncate loopping truncate 
tables should only be executed from one DC DB







SQLEXEC "alter session set commit_wait = 'NOWAIT'";


SQLEXEC "alter session set commit_wait = 'NOWAIT'";


CREATE_API_RETURN_TRANSACTION
UPDATE_API_TRANSACTION 


# What: oracle database: increase application socket buffers
net.core.rmem_max = 4194304
					8388608
					
net.core.wmem_max = 1048576
					8388608

/*

-- APPLIES TO:
Oracle GoldenGate - Version: 11.1.1.0.0 and later   [Release: 11.1.1 and later ]
Information in this document applies to any platform.

-- GOAL
A parent and a child table are like following:
Parent table P1: col1 primary key, col2
Child table C1: col3 primary key, col4, col1 not null (col1 is FK on P1(col1)).

There is no update to change the values of P1.col1, and C1.col1.

When configuring replicats with RANGE function as following, they abend:

replicat1:
map p1, target p1, filter (@range (1,2));
map c1, target c1, filter (@range (1,2));

replicat2:
map p1, target p1, filter (@range (2,2));
map c1, target c1, filter (@range (2,2));

Is there a solution for this?

-- Solution
By default, the key column will be used for RANGE function. In above parent-child table scenario, P1(col1) and C1(col3) 
will be used, which will cause problem. Instead, following configuration may be used:

replicat1:
map p1, target p1, filter (@range (1,2, col1));
map c1, target c1, filter (@range (1,2, col1));

replicat2:
map p1, target p1, filter (@range (2,2, col1));
map c1, target c1, filter (@range (2,2, col1));

Limitations:
1. column col1 in both tables are not null ;
2. column col1 in both tables may not changed by update;
3. column col1 in child table has to be included in supplemental log group, even it is not a key column.

*/