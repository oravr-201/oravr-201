
-- You can specify which tables that you don't want to replicate, remember the redo will be transported across but the SQL apply will not happen
-- ## Syntax

-- skip replication of tables
dbms_logstdby.skip (
  stmt in varchar2,
  schema_name in varchar2 default null,
  object_name in varchar2 default null,
  proc_name in varchar2 default null,
  use_like in boolean default true,
  esc in char1 default null
);

## Examples
execute dbms_logstdby.skip(stmt => 'DML', schema_name => 'HR', object_name => 'EMPLOYEE');
execute dbms_logstdby.skip(stmt => 'SCHEMA_DDL', schema_name => 'HR', object_name => 'EMPLOYEE');

# skip all DML operations 
execute dbms_logstdby.skip(stmt => 'DML', schema_name => 'HR', object_name => '%');



-- display what tables are being skipped
select owner, name, use_like, esc from dba_logstdby_skip where statement_opt = 'DML';


-- URL for Data Gaurd ...
http://www.datadisk.co.uk/html_docs/oracle_dg/logical_setup.htm