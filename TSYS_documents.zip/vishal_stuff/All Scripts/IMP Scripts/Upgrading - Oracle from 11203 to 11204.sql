
-- Database Patch Set Update 11.2.0.4.6 (Includes CPUApr2015)
-- Released: April 14, 2015
Patch 20299013



p18139609_112040_Linux-x86-64.zip
p13390677_112040_Linux-x86-64_2of7.zip
p13390677_112040_Linux-x86-64_1of7.zip
p13390677_112040_Linux-x86-64_3of7.zip
p13390677_112040_Linux-x86-64_4of7.zip
p6880880_121010_Linux-x86-64.zip
p6880880_112000_Linux-x86-64.zip




-- URL
https://support.oracle.com/epmos/faces/SearchDocDisplay?_adf.ctrl-state=c4fvu3bi1_334&_afrLoop=431334237768766#aref_section221

-- If you are performing any Oracle database upgrades, for example CPU / PSU patch upgrade, and you are currently capturing 
-- Oracle DDL operations with GoldenGate, disable the GoldenGate DDL trigger before the upgrade and then enable it after the 
-- upgrade. Use the ddl_disable and ddl_enable scripts in the GoldenGate installation directory for this purpose. 

Before applying the Oracle Upgradation

1. Log into SQL*Plus as sysdba and execute the ddl_disable script, if using goldengate software for replication. 
2. Apply the Oracle patch. 
3. Disable the DDL_Trigger of GoldenGate replication and once upgradation is done enable the trigger again by executing the ddl_enable script as sysdba.


1. Log on to SQL*PLUS as sysdba

sqlplus / as sysdba

SQL> create pfile='?/dbs/init<DB_Instance_Name>.ora' from spfile;

SQL> @<GOLDENGATE_HOME>/ddl_disable

GGS_DDL_TRIGGER_BEFORE -- Enter the name of the DDL replication trigger


SQL> alter system set cluster_database=false scope=spfile SID='*';

-- Black Out the Host/Database/Cluster services on which you are working


-- Check the Running Services on Cluster Node
crsctl stat res -t


-- Stop the running cluster services 
srvctl stop database -d rptDCE
srvctl stop database -d txnDCE



-- Unzip 11.2.0.4 installation software on Primary Node1

-- As sysasm, adjust sga_max_size and sga_target to a value of 2G. The values will become active with a next start of the ASM instances.
-- Connect to +ASM1

. oraenv
+ASM1

sqlplus / as sysasm

alter system set sga_max_size = 2G scope=spfile sid='*';
alter system set sga_target=2G scope=spfile sid='*';

-- Verify values for memory_target, memory_max_target and use_large_pages
col value format a30
col name format a30
col sid format a5

select sid, name, value from v$spparameter where name in ('memory_target','memory_max_target','use_large_pages');


-- When the values are not as expected, change them as follows:
alter system set memory_target=0 sid='*' scope=spfile;
alter system set memory_max_target=0 sid='*' scope=spfile /* required workaround */;
alter system reset memory_max_target sid='*' scope=spfile;


-- unset the envrionment variables
unset GI_HOME ORACLE_BASE ORACLE_HOME
 
-- Create the new Grid Infrastructure (GI_HOME) directory where 11.2.0.4 will be installed
-- Execute in all the Nodes
-- Using root account
mkdir /opt/app/11.2.0/grid4
chown oracle /opt/app/11.2.0/grid4
chgrp -R oinstall /opt/app/11.2.0/grid4

-- Create the new RDBMS (Oracle) directory where 11.2.0.4 wil 
mkdir /opt/app/oracle/product/11.2.0/db_4/
chgrp -R oinstall /opt/app/oracle/product/11.2.0/db_4/
chown oracle /opt/app/oracle/product/11.2.0/db_4
 
-- For GRID Software
http://asanga-pradeep.blogspot.com/2013/09/upgrading-rac-from-11203-to-11204-grid.html
 
-- For RDBMS Software
http://asanga-pradeep.blogspot.com/2013/09/upgrading-rac-from-11203-to-11204.html
  
/*

You have upgraded 11.2.0.3 Oracle Restart Grid Infrastructure to 11.2.0.4 (non-RAC) and now ASM will not start. You are receiving 
an ORA-1031 insufficient privileges error:

$ srvctl start asm
PRCR-1079 : Failed to start resource ora.asm
ORA-01031: insufficient privileges
CRS-5017: The resource action "ora.asm start" encountered the following error:
ORA-01031: insufficient privileges
. For details refer to "(:CLSN00107:)" in "/u01/app/grid/11.2.0.4/log/lux335/agent/ohasd/oraagent_oracle/oraagent_oracle.log".

CRS-2674: Start of 'ora.asm' on 'lux335' failed
ORA-01031: insufficient privileges
 
CAUSE

During the upgrade by accident you chose a wrong group for Oracle ASM Administrator (OSASM).


SOLUTION

You do not have to rerun upgrade or downgrade. All you need to do is this:
1. Rename the file config.o
2. Then update the config.c with the correct groups.
3. Then relink the GI Oracle Home and you will be able to start asm under 11.2.0.4.
How To Relink The Oracle Grid Infrastructure Standalone (Restart) Installation (Non-RAC). (Doc ID 1536057.1)
 
*/

export ORACLE_SID=rptDCE1

-- copy old init.ora file for instance
cp $ORACLE_HOME/dbs/initrptDCE1.ora /opt/app/oracle/product/11.2.0/db_4/dbs

sqlplus / as sysdba

-- disable the cluster mode
SQL> startup mount
SQL> alter system set cluster_database=false scope=spfile SID='*';
SQL> shutdown immediate
SQL> exit

sqlplus / as sysdba

-- Start database instance in upgrade mode
SQL> startup upgrade
SQL> @?/rdbms/admin/catupgrd.sql
SQL> exit

sqlplus / as sysdba

-- startup normal database
SQL> startup 
-- Recomplie all the invalid objects
SQL> @?/rdbms/admin/utlrp.sql

-- Check the GoldenGate Parameter ENABLE_GOLDENGATE_REPLICATION, if flase then enable it
SQL> ALTER SYSTEM SET ENABLE_GOLDENGATE_REPLICATION=TRUE SCOPE=BOTH;


-- Enable the cluster mode
SQL> alter system set cluster_database=true scope=spfile SID='*';
SQL> shutdown immediate

-- before starting services, upgrade the new ORACLE_HOME
srvctl upgrade database -d uatracdb -o /opt/app/oracle/product/11.2.0/db_4

-- start the database
srvctl start database -d rptDCE 

sqlplus / as sysdba




Once upgradation is done enable the DDL Trigger again by executing the ddl_enable script as sysdba


log on to SQL*PLUS as sysdba

sqlplus / as sysdba

SQL> @$GOLDENGATE_HOME/ddl_enable


/*

SQL> @marker_setup
SQL> @ddl_setup
SQL> @role_setup
SQL> @ddl_enable
SQL> @ddl_pin ggate
SQL> @sequence


*/



Once all the Upgradation is done execute the below from sysdba

-- Recompile all the invalid objects 
sqlplus / as sysdba

SQL> @?/rdbms/admin/utlrp.sql


























-- ** PATCH INSTALLATION INSTRUCTIONS

-- The worked example below will use the following settings:
CRS_HOME = /u01/crs/oracle/product/10/crs
RDBMS_HOME = /u01/app/oracle/product/db10.2.0


1. Make sure all instances running under the ORACLE_HOME being patched are cleanly shutdown before installing 
   this patch. Also ensure that the tool used to terminate the instance(s) has exited cleanly.

2. Ensure that the directory containing the opatch script appears in your $PATH. Execute which opatch to confirm.

oracle:> which opatch

-- set the env variable for opatch [OPATIONAL]
oracle:> export PATH=$PATH:$ORACLE_HOME/OPatch

oracle:> which opatch

3. Each node of the cluster has its own CRS Home, the patch should be applied as a rolling upgrade. All of the following
steps should be followed for each node.

	. Do not patch two nodes at once.

4. As the Oracle Clusterware (CRS) software owner check CRS_HOME.

oracle:> opatch lsinventory -detail -oh /u01/crs/oracle/product/10/crs

5. As the RDBMS server owner check ORACLE_HOME.

oracle:> opatch lsinventory -detail -oh /u01/app/oracle/product/db10.2.0/


-- Starts From Here
6. Unzip the patch set container file, this will create one or more sub-directories.

unzip p123456.zip

7. Shut down the RDBMS and ASM instances, listeners and nodeapps followed by CRS daemons on the local node.

-- To shutdown RDBMS instance on the local node run the following command:
% $ORACLE_HOME/bin/srvctl stop instance -d dbname -i instance_name

-- To shutdown ASM instances run the following command on each node:
% $ORACLE_HOME/bin/srvctl stop asm -n <node_name>

-- To shutdown nodeapps run the following comand on each node:
% $ORACLE_HOME/bin/srvctl stop nodeapps -n <node_name>


8. Now shutdown CRS daemons on each node by running as root:

root # $CRS_HOME/bin/crsctl stop crs


9. Prior to applying this part of the fix, invoke the unlock script as root to unlock protected files.

-- su -
root # cd <patch directory>/123456
root # custom/scripts/prerootpatch.sh -crshome /u01/crs/oracle/product/10/crs -crsuser oracle
root # exit




opatch lsinventory -bugs_fixed | egrep -i 'PSU|DATABASE PATCH SET UPDATE'



 --- Apply Oracle CPU Patches on RAC DBs
 
 
  -- on note 1
1) unzip the patch
  unzip p19380115_112040_Linux-x86-64.zip
  
2) as oracle user, run the below command to generate ocm file
$ORACLE_HOME/OPatch/ocm/bin/emocmrsp -no_banner -output /recovery/oracle/software/oct2014_GIpatche/ocm.rsp
  
3) as root user, run the below command to patch GRID_HOME and ORACLE_HOME
/opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/oct2014_GIpatche/19380115 -ocmrf /recovery/oracle/software/oct2014_GIpatche/ocm.rsp

 -- RDBMS patching is not yet clear...
 --/opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/oct2014_GIpatche/19380115  -oh /opt/app/oracle/product/11.2.0/db_4 -ocmrf /recovery/oracle/software/oct2014_GIpatche/ocm.rsp
  
4) start the instance on node 1
srvctl start instance -d rptDCE -i rptDCE1  
srvctl start instance -d txnDCE -i txnDCE1

 
-- on note 2
 1) copy the patch and .rsp files
 2) as a root user, run the below command to patch GRID_HOME
/opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/oct2014/19380115  -oh /opt/app/11.2.0/grid4 -ocmrf /recovery/oracle/software/oct2014/ocm.rsp

-- oh is DATABASE_HOME, so modifying the below command for -oh
-- /opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/oct2014_GIpatche/19380115  -oh /opt/app/oracle/product/11.2.0/db_4 -ocmrf /recovery/oracle/software/oct2014_GIpatche/ocm.rsp

-- Oracle will automatically start instances on node 2, once the patch is installed successfully



-- on note 3
 1) copy the patch and .rsp files
 2) as a root user, run the below command to patch GRID_HOME
/opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/oct2014_GIpatche/19380115  -oh /opt/app/11.2.0/grid4 -ocmrf /recovery/oracle/software/oct2014_GIpatche/ocm.rsp

-- oh is DATABASE_HOME, so modifying the below command for -oh
-- /opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/oct2014_GIpatche/19380115  -oh /opt/app/oracle/product/11.2.0/db_4 -ocmrf /recovery/oracle/software/oct2014_GIpatche/ocm.rsp

-- Oracle will automatically start instances on node 3, once the patch is installed successfully



-- Once patche is applied on all the nodes, On node1 login as sysdba and execute the below commnad 

[oracle@loadrpdbnode1 oct2014_GIpatche]$ CONNECT / AS SYSDBA
SQL> STARTUP
SQL> @?/rdbms/admin/catbundle.sql psu apply

SQL> select * from dba_registry_history;

-- it's not required to execute catbundle.sql command on all other nodes...


-- Check latested Patch Installed
opatch lsinventory|grep "Patch description"

-- Check detail about installed patches
opatch lsinventory -details




-------------------------------------------------------------------------------------------------------

-- Note the steps below should be run before running any patching commands
[oracle@loadrpdbnode1 ~]$ olsnodes -n -i -s -t
--> Unpin any pinned Node ! 

-- Checking database and Service Status 
[oracle@loadrpdbnode1 ~]$ crs | egrep 'NAME|---|db|svc'

OR

[oracle@loadrpdbnode1 ~]$ crsctl stat res -t
--> All cluster nodes/dbs should be up and running 

-- Verify OUI repository on all nodes
[oracle@loadrpdbnode1 ~]$ $GRID_HOME/OPatch/opatch lsinventory

[oracle@loadrpdbnode1 ~]$ $ORACLE_HOME/OPatch/opatch lsinventory


-- Opatch auto logfiles will be stored at
[oracle@loadrpdbnode1 ~]$ $GRID_HOME/cfgtoollogs/
[oracle@loadrpdbnode1 ~]$ $ORACLE_HOME/cfgtoollogs/


-- Running Opatch auto and patching both GRID and RAC HOME *

-- As root account run the below command 
-- on location mentioned the ocm.rsp file generated
-- [root@loadrpdbnode1 ~]$ cd  /recovery/oracle/software/oct2014/19121551
-- [root@loadrpdbnode1 ~]$ /opt/app/11.2.0/grid4/OPatch/ocm/bin/emocmrsp


-- run as a root
/recovery/oracle/software/OPatch/OPatch/ocm/bin/emocmrsp -no_banner -output /recovery/oracle/software/oct2014/ocm.rsp


-- Stop all database running out of the to be patched OH
[oracle@loadrpdbnode1 ~]$ srvctl stop database -d rptDCE
[oracle@loadrpdbnode1 ~]$ srvctl stop database -d txnDCE
 

-- as a root Run opatch auto
[root@loadrpdbnode1 ~]$ /opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/oct2014/19121551 -ocmrf  /recovery/oracle/software/oct2014/ocm.rsp


-- Applying patches individually for RDBMS_HOME and GRID_HOME for node 1,2,3,*

-- Install RDBMS patch 
[root@loadrpdbnode1 ~]$ /opt/app/11.2.0/grid4/OPatch/opatch auto  19380115 -oh /opt/app/oracle/product/11.2.0/db_4 -ocmrf  /recovery/oracle/software/oct2014/ocm.rsp

	-- Verify patch installation 
	-- As a Oracle account 
	[oracle@loadrpdbnode1 ~]$ $ORACLE_HOME/OPatch/opatch lsinventory


--Install GRID patch 
[root@loadrpdbnode1 ~]$ /opt/app/11.2.0/grid4/OPatch/opatch auto 19380115 -oh  /opt/app/11.2.0/grid4/ -ocmrf  /tmp/ocm.rsp

	-- Verify Patch installation
	-- as a Oracle account
	[oracle@loadrpdbnode1 ~]$ $GRID_HOME/OPatch/opatch lsinventory


-- Run post patch procedure and verify patch installation *
[oracle@loadrpdbnode1 ~]$ connect / as sysdba


SQL> @catbundle.sql psu apply

*/

-- final procedure to apply the patch (CPU)

-- 1) Check the patch version. if that is not latest one then download the same from support.oracle.com
-- 2) Download the Patch Set and copy to all the working/online nodes
-- 3) Unzip the file on all the nodes, first patching will be started on 1st Node of RAC DB
cd /recovery/oracle/software/oct2014/
unzip p19380115_112040_Linux-x86-64.zip

-- 4) check the prereq of the patch you want to apply
opatch prereq CheckConflictAgainstOHWithDetail -phBaseDir /recovery/oracle/software/oct2014/19380115

-- 5) Create response "ocm.rsp" (will created on Node 1)  file and copy to the remaining RAC nodes, as oracle user
/opt/app/oracle/product/11.2.0/db_4/OPatch/ocm/bin/emocmrsp -no_banner -output /recovery/oracle/software/oct2014/ocm.rsp

-- Copy ocm.rsp to all the nodes

-- 6) As root user, run the auto patch on Node 1 and on remaining Nodes
/opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/oct2014/19380115 -ocmrf /recovery/oracle/software/oct2014/ocm.rsp

-- 7) As oracle user, run the below scripts on Node 1 only (Not required to run on other nodes).

sqlplus as / as sysdba

SQL> @?/rdbms/admin/catbundle.sql psu apply

-- 8) Verify the installation of patchs

crsctl query crs softwareversion -all
 
crsctl query crs releaseversion
crsctl query crs  activeversion
 
$GI_HOME/OPatch/opatch lsinventory
  
  
olsnodes -s -t



/opt/app/oracle/product/11.2.0/db_4/OPatch/ocm/bin/emocmrsp -no_banner -output /recovery/oracle/software/jan2015/ocm.rsp

/opt/app/11.2.0/grid4/OPatch/opatch auto /recovery/oracle/software/jan2015/19769489 -ocmrf /recovery/oracle/software/jan2015/ocm.rsp


/recovery/oracle/software/jan2015

-------------------------------------------------------------------------------------------------------


opatch lsinventory -bugs_fixed | egrep -i 'PSU|DATABASE PATCH SET UPDATE'