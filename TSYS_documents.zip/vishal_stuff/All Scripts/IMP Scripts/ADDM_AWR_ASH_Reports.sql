-- AWR / ADDM / ASH Reports



-- You can get the test based reports 

@?/rdbms/admin/ashrpt.sql
	-- will ask for the report format, sepecify text
	-- will ask for the timestamp
	-- will ask for the duration, if entered 10, it means 10 mins after the above given date time
	-- will ask for the report name.
	

@?/rdbms/admin/awrrpt.sql
@?/rdbms/admin/awrsqlrpt.sql


-- To generate the reports over the RAC DBs
@?/rdbms/admin/awrgrpt.sql

-------------------------------------------------------------------------------------------------------------------------



-- get the explan plan for th top SQL_ID
SELECT * FROM TABLE (DBMS_XPLAN.DISPLAY_AWR ('6mtbknc8a6x59'));

-- get the information of the SANP_ID with event name
  SELECT INSTANCE_NUMBER, SQL_ID, COUNT (EVENT)
    FROM DBA_HIST_ACTIVE_SESS_HISTORY
   WHERE SNAP_ID > 16322 AND SNAP_ID <= 16324 AND EVENT LIKE '%busy acquire%'
GROUP BY sql_id, INSTANCE_NUMBER
ORDER BY 3 DESC;

-- get the count of the SNAP_ID for SQL_ID and for perticular time frame
SELECT snap_id,COUNT(*) 
FROM dba_hist_active_sess_history 
WHERE sql_id='6mtbknc8a6x59'
 AND  sql_exec_start BETWEEN TO_DATE('12/16/2015 13:30:48','mm/dd/yyyy hh24:mi:ss')
                         AND TO_DATE('12/16/2015 13:40:06','mm/dd/yyyy hh24:mi:ss')
GROUP BY snap_id


SELECT SQL_ID, COUNT(*), COUNT(*)*100/SUM(COUNT(*)) OVER() PCTLOAD
  FROM V$ACTIVE_SESSION_HISTORY
 WHERE SAMPLE_TIME BETWEEN TO_DATE('02/14/2016 08:19:00','mm/dd/yyyy hh24:mi:ss')
                       AND TO_DATE('02/14/2016 08:23:59','mm/dd/yyyy hh24:mi:ss')
--   AND SESSION_ID = :B1
 GROUP BY SQL_ID 
 ORDER BY  COUNT(*)  DESC ;


-- What resource is currently in high demand?
-- This query will give you for the last 30 minutes those resources that are in high demand on your system.

-- TIME-TO-LIVE (TTL) - how much time the data will be present in cache
-- This specifies how long (in seconds) this data will be cached in the database before it is 
-- disregarded and new information is requested from a server. By leaving this field blank, the ttl defaults to 
-- the minimum time specified in the Start-Of-Authority (SOA) resource record. 

select active_session_history.event,
        sum(active_session_history.wait_time +
            active_session_history.time_waited) ttl_wait_time
   from v$active_session_history active_session_history
  where active_session_history.sample_time between sysdate - 60/2880 and sysdate
 group by active_session_history.event
 order by 2;

-- What user is waiting the most?
-- who is waiting the most for resources at a point in time. If a user calls you up on the phone and says 
-- they are experiencing delays, you can use this query to verify that they are actually waiting in the database 
-- for a result set for a given time period. This SQL is written for a 30-minute interval from current system 
-- time so you may need to change.
  SELECT sesion.SID,
         sesion.username,
         SUM (
              ash.wait_time
            + ash.time_waited)
            ttl_wait_time
    FROM v$active_session_history ash, v$session sesion
   WHERE     ash.sample_time BETWEEN SYSDATE - 60 / 2880 AND SYSDATE
         AND ash.session_id = sesion.SID
GROUP BY sesion.SID, sesion.username
ORDER BY 3 DESC; 

-- What SQL is currently using the most resources?
-- This query will get you started in the proper direction of zeroing in on what SQL statement is consuming the most resource 
-- wait times on your system. No longer do you have to go to the V$SQLAREA and try to pick out the top 10 or 20 SQL hogs on 
-- your system by disk reads or executions. Now you really know what SQL statements are consuming resources and waiting the most. 
-- These are the SQL that you really need to tune because the fact that a SQL statement performs 20,000 reads does not mean 
-- that it is a bottleneck in your system.
SELECT active_session_history.user_id,
         dba_users.username,
         sqlarea.sql_text,
         SUM (
              active_session_history.wait_time
            + active_session_history.time_waited)
            ttl_wait_time
    FROM v$active_session_history active_session_history,
         v$sqlarea sqlarea,
         dba_users
   WHERE     active_session_history.sample_time BETWEEN SYSDATE - 60 / 2880 AND SYSDATE
         AND active_session_history.sql_id = sqlarea.sql_id
         AND active_session_history.user_id = dba_users.user_id
GROUP BY active_session_history.user_id, sqlarea.sql_text, dba_users.username
ORDER BY 4 DESC;


-- What object is currently causing the highest resource waits?
-- This is a great query. Now we can actually see which objects a SQL statement is hitting. Moreover, if you take a further look at 
-- the V$ACTIVE_SESSION_HISTORY view you will see that you can tailor this query to report on the actual blocks that are being accessed 
-- within the objects for the SQL statement. This is great help in determining if you may need to reorg your object or redistribute to 
-- reduce the contention on that object.

  SELECT dba_objects.object_name,
         dba_objects.object_type,
         active_session_history.event,
         SUM (
              active_session_history.wait_time
            + active_session_history.time_waited)
            ttl_wait_time
    FROM v$active_session_history active_session_history, dba_objects
   WHERE     active_session_history.sample_time BETWEEN SYSDATE - 60 / 2880 AND SYSDATE
         AND active_session_history.current_obj# = dba_objects.object_id
GROUP BY dba_objects.object_name,
         dba_objects.object_type,
         active_session_history.event
ORDER BY 4 DESC;
-------------------------------------------------------------------------------------------------------------------------

-- What is a GC buffer busy wait? 
-- Best URL http://www.oaktable.net/category/tags/gc-buffer-busy

-- gc buffer busy acquire and gc buffer busy release
Event �gc buffer busy� event means that a session is trying to access a buffer,but there is an open request for Global cache lock 
for that block already, and so, the session must wait for the GC lock request to complete before proceeding. This wait is 
instrumented as �gc buffer busy� event. 

In a simple sense, GC buffer busy means that the buffer in the buffer cache, that the session is trying to access is already 
involved in another ongoing global cache operation. Until that global cache operation completes, session must wait.

I will explain this with an example: Let�s say that session #1 is trying to access a block of file #7 block ID 420. That 
block is in the remote cache and so, session #1 opened a BL lock on that block, requested the remote LMS process to send the block, 
and waiting for the block shipping to complete. Session #2 comes along shortly thereafter and tries to access the same buffer. But, 
the block is already involved in a global cache operation and so, session #2 must wait for the session #1 to complete GC (Global Cache) 
activity before proceeding. In this case, Session #2 will wait for �gc buffer busy� wait event with a time-out and repeatedly tries to 
access that buffer in a loop.

Consider the scenario if the block is a hot block such as segment header, index branch block or transaction table header block etc. 
In this case, you can see that many such sessions waiting for the �Gc buffer busy� wait event. This can lead to complex wait scenario 
quickly as few background processes also can wait for �gc buffer busy� event leading to an eventual database hang situation. If you 
kill the processes, then pmon might need to access that block to do a rollback, which means that pmon can get stuck waiting 
for �gc buffer busy� waits too. 

-- Increase the Freelist and Freelist Group of Table/Index
freelist advice would definitely apply if you are using manual segement space management, otherwise, we use bitmap freelists in the segment 
itself - there are no separate freelist/freelist groups. If you use ASSM (automatic segment space management) there are no freelist/freelist group 
settings for you to consider or make. 

/*

I might suggest that you adopt an iterative process to determine the optimum number of freelists:

 1)   Add freelists one at a time, during low usage times:
    alter table mytable storage (freelists 2);

 2)   Measure the buffer wait changes during peak processing (statspack)

 3)   Repeat until buffer waits disappear

*/
