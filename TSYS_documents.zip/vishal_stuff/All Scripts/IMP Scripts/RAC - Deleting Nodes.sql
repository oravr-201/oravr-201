* Steps to delete a Node from Cluster configuration
====================================================

-- Remove the Database Instance

-- To remove the database instance, run the DBCA utility from node rac1 as oracle user.
$ dbca

+ Oracle RAC Database
+ Instance Management
+ Delete an Instance
+ Enter SYS user details and proceed with Instance deletion.


-- Check if the redo log thread for the deleted instance is removed by querying the v$log view.
SQL> select GROUP#, THREAD#, MEMBERS, STATUS from v$log;

--If not then remove it by using the below query.
SQL> alter database disable thread 2;

 
-- Check if instance is removed from the cluster

--Execute the below query from rac1 node.
$ srvctl config database -d dbname

============================================================

-- Detach the Oracle Home

--On the remaining one node, run the following to update the inventory with the remaining nodes of the cluster.
$ cd $ORACLE_HOME/oui/bin
$ ./runInstaller -updateNodeList ORACLE_HOME=$ORACLE_HOME "CLUSTER_NODES={rac1}"

============================================================

-- Detach the Grid Home

-- Check whether the node to be removed is pinned or unpinned as grid user.
$ olsnodes -t -s

rac1    Active  Unpinned
rac2    Active  Unpinned
 

-- If the node is pinned then remove it using the following command.
$ crsctl unpin css -n nodename

--If they are already unpinned then no need to run the above unpin command.


-- From a node that�s not being deleted run the following command as root specifying the node being deleted.
# /u01/crs/products/11.2.0/crs/bin/crsctl delete node -n rac2


-- On the remaining node run the following to update the inventory.
$ cd $GRID_HOME/oui/bin
$ ./runInstaller -updateNodeList ORACLE_HOME=$GRID_HOME "CLUSTER_NODES={rac1}" CRS=TRUE

 
-- Use cluvfy to check whether the node was removed successfully.
$ cluvfy stage -post nodedel -n rac2

--This concludes the final step of removing the node from the RAC Cluster.


#######################################################################################################################

* Steps to add a Node in the Cluster configuration
===================================================

--Make sure all the prechecks are completed before proceeding.

$ cluvfy stage -pre crsinst -n rac1,rac2 -verbose

============================================================

-- Extend Clusterware

-- From an existing node, run "addNode.sh" as grid user to extend the clusterware.

$ export IGNORE_PREADDNODE_CHECKS=Y
$ cd $ORACLE_HOME/oui/bin
$ ./addNode.sh "CLUSTER_NEW_NODES={rac2}" "CLUSTER_NEW_VIRTUAL_HOSTNAMES={rac2-vip}" "CLUSTER_NEW_PRIVATE_NODE_NAMES={rac2-priv}"


-- At the end, if Cluster Node Addition is successful, you will be prompted to run the below scripts on new node.
/u01/app/oraInventory/orainstRoot.sh
/u01/app/11.2.0/grid/root.sh

--Run both the scripts as root user on new node.


-- If successful, clusterware daemons, the listener, the ASM instance, etc. should be started by the "root.sh" script

# crs_stat -t -v
# crsctl check crs
# crsctl stat res -t

============================================================

-- Extend Oracle Database Software

-- From an existing node � as the database software owner � run the following command to extend the Oracle database software to the new node.

$ cd $ORACLE_HOME/oui/bin
$ ./addNode.sh -silent "CLUSTER_NEW_NODES={node2}"

-- Error - "SEVERE:The new nodes 'rac2' are already part of the cluster".

-- Analysis - It was picking up same hostname racp2 twice, instead of picking both the hostnames (rac1,rac2).

--Solution - Oracle Home was not detached from existing node. Run the below command as oracle user on node1.
$ cd $ORACLE_HOME/oui/bin
$ ./runInstaller -updateNodeList ORACLE_HOME=$ORACLE_HOME "CLUSTER_NODES={rac1}"

--Run the command again and it should proceed ahead.


-- At the end, if Oracle Software Extension is successful, you will be prompted to run the root.sh script on new node.
/u01/app/oracle/products/11.2.0/db/root.sh

--Run the script as root user on new node.

============================================================

-- Add Instance to Clustered Database

-- From an existing node � as the database software owner � run the following command to add the instance,

$ dbca

+ Oracle RAC Database
+ Instance Management
+ Add an Instance
+ Enter SYS user details and proceed with Instance addition.

============================================================


