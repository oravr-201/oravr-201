

-- ASM Installation Dcoument
http://jpmrd.wordpress.com/2012/08/25/oracle-asm-step-by-step/

http://www.oracle-wiki.net/startdocshowtoinstalloracle11glinuxasm



Creating ASM instance on Linux (Single Instance) using DBCA
1. Add disk to Linux server
2. Configure UDEV for the device. 
 	E.g /dev/sdb -> /dev/asm_disk1 //check Oracle documentation for configure UDEV on RHEL/OEL 5. You can directly use /dev/sdc for testing purpose.
3. Change the owner of the disk. e.g. chown oracle:oinstall /dev/asm_disk1
4. As root user, run Oracle CSS script. The Cluster Synchronization Services (CSS) daemon provides cluster services for ASM, 
   communication between the ASM and database instances, and other essential services
# $ORACLE_HOME/bin/localconfig add

5. As oracle user, run DBCA (X11 needed)
$ dbca

6. Select the "Configure Automatic Storage Management" option, then click the "Next" Button.
7. Enter a password for the ASM instance, then click the "Next" button.
8. On the confirmation screen, click the "OK" button to create the ASM instance
9. Once the ASM instance is created, you are presented with the "ASM Disk Groups" screen. Click the "Create New" button.
10. On the "Create Disk Group" screen, enter Disk Group Name of e.g. "DATA" and select the required level of redundancy.
	�     External - ASM does not mirror the files. This option should only be used if your disks are already protected by some form of redundancy, like RAID.
	�     Normal - ASM performs two-way mirroring of all files.
	�     High - ASM performs three-way mirroring of all files.
11. If you didnot find any disk, click "Change Disk Discovery Path..." and enter "/dev/asm_disk1"
12. Select "External" for redundancy, tick the disk (/dev/asm_disk1) and click "OK" button.
13. On the "ASM Disk Groups" screen. Click the "Finish" button.


To access the ASM instance :
1. As oracle user, export the ORACLE_SID
$ export ORACLE_SID=+ASM
2. sqlplus "/as sysdba"
3. SQL> select name, total_mb, free_mb from v$asm_diskgroup;
SQL> select name, path, header_status from v$asm_disk;

To access the ASM command line utility:
1. As oracle user, export the ORACLE_SID
$ export ORACLE_SID=+ASM
2. Enter the asmcmd command
$ asmcmd




https://10.50.4.134/7799/em


-- OLD OEM Production
https://oem.ifxga.com:7799/em/

-- Prod OEM 12c
https://10.150.50.100:7802/em













--------------------------------------------------------------------------------------------------------------------------
UAT :

tnoxpass_tfe_2018 : TnoxpaSS_tfe$2018 :
Encrypted Password : 309A7FE77579E16482355E366BC7F54956708AD1182DB205

Key = 8592867031E64597
Password = 69D4F23742F4A064855A4537CAFB0FB6CA73CE1227F02794

snoxpass_tfe_2018 : SnoxpaSS_tfe$2018 : 
Encrypted Password : 7723A93C1A60DD6F82355E366BC7F54956708AD1182DB205

Key = C2D5B92AD3573231
Password = 5F793803FB2482AF1403EA97424901D5CCAA82B0B545CB3C


production :

tnoxpass_tfe_2018 : tNoXpaSSt$fe$2018 : 
Encrypted Password : 5FA9C1A02518FD25D85B2D51B246496F56708AD1182DB205
Key = 57D570894658B640
Password = B06DC52C09EEC4DAC39BAD951EFD82745306CD35C7426FF4

snoxpass_tfe_2018 : sNoXpaSSt$fe$2018 : 
Encrypted Password : C4865EAE8321E806D85B2D51B246496F56708AD1182DB205
Key = A27A6415F4522ADC
Password = 05026BB34C11EB5FBB80B87DD7846E30E9234D367BAFCFC7




UAT
TNOXPASS_GWAY_014: Tnoxpass_GWay$014 TnoXPass_GwAy$014
SNOXPASS_GWAY_014: Snoxpass_GWay$014 SnoXPass_GwAy$014

SNOXPASS_GWAY_014 - 707896D3324422798DA1C0EA036065298DD4A5BE11CE4A67
TNOXPASS_GWAY_014 - 30591E26D6E5C5298DA1C0EA036065298DD4A5BE11CE4A67   

Production
TNOXPASS_GWAY_014: Tnoxpass$GWay$014
SNOXPASS_GWAY_014: Snoxpass$GWay$014
-------------------------------------------------------------------------------------------------------------------------- 



Q444955 -- drop sc* and sn* temporary tables

Q446203 -- Enable the replication on table DATABASE_EXEC_LOG

For Point #1 Opening change control.. To represent the change control, CC (Change Control) Team will require Implementation Plan (Release Notes) and SM/IM ticket information. if this is not on place they will not consider the cc. You will have to provide the information so that I can open the change control for making the UAT database releases.

STOP EXTRACT 

ALTER TABLE TRANSNOX_IOX.DATABASE_EXEC_LOG DROP PRIMARY KEY;

ALTER TABLE TRANSNOX_IOX.DATABASE_EXEC_LOG MOVE NOCOMPRESS;

ALTER TABLE TRANSNOX_IOX.DATABASE_EXEC_LOG ADD (
 CONSTRAINT PK_DATABASE_EXEC_LOG PRIMARY KEY (EXECUTION_ID)
  USING INDEX  TABLESPACE TNOX_DATA_CPASS  ENABLE VALIDATE);

START EXTRACT;



cqID00059859 
cqID00059860 

DECLARE
  X NUMBER;
  user_name varchar2(30);
BEGIN
  select user into user_name from dual;
  execute immediate 'alter session set current_schema = MERGECUSTCODE';
  BEGIN
    SYS.DBMS_JOB.SUBMIT
    ( job       => X 
     ,what      => 'DECLARE 
       a NUMBER; 
       b VARCHAR2(1000); 
BEGIN 
    Remindermail_Custcode_Merging(); 
END;   '
     ,next_date => to_date('16/07/2014 03:00:00','dd/mm/yyyy hh24:mi:ss')
     ,interval  => 'trunc(sysdate + 1) + 3/24'
     ,no_parse  => FALSE
    );
    SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
    execute immediate 'alter session set current_schema = ' || user_name ;
  EXCEPTION
    WHEN OTHERS THEN 
      execute immediate 'alter session set current_schema = ' || user_name ;
      RAISE;
  END;
  COMMIT;
END;
/


DECLARE
  X NUMBER;
  user_name varchar2(30);
BEGIN
  select user into user_name from dual;
  execute immediate 'alter session set current_schema = MERGECUSTCODE';
  BEGIN
    SYS.DBMS_JOB.SUBMIT
    ( job       => X 
     ,what      => 'DECLARE 
       a NUMBER; 
       b VARCHAR2(1000); 
BEGIN 
    P0(a,b); 
END;   '
     ,next_date => to_date('16/07/2014 04:00:00','dd/mm/yyyy hh24:mi:ss')
     ,interval  => 'trunc(sysdate + 1) + 4/24'
     ,no_parse  => FALSE
    );
    SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
    execute immediate 'alter session set current_schema = ' || user_name ;
  EXCEPTION
    WHEN OTHERS THEN 
      execute immediate 'alter session set current_schema = ' || user_name ;
      RAISE;
  END;
  COMMIT;
END;
/




select count(*) 
from MERGECUSTCODE.MERGING_CUSTOMERCODE 
where status='N'








sqlplus -s / as sysdba << eof
spool /home/oracle/mergecustcode_logs_16Jul2014.log
alter session set current_schema=MERGECUSTCODE;
DECLARE 
  O_OUTPUTSTATUS NUMBER;
  O_OUTPUTMESSAGE VARCHAR2(32767);
BEGIN 
  O_OUTPUTSTATUS := NULL;
  O_OUTPUTMESSAGE := NULL;
  MERGECUSTCODE.P0 ( O_OUTPUTSTATUS, O_OUTPUTMESSAGE );
  DBMS_OUTPUT.PUT_LINE('O_OUTPUTSTATUS = ' || TO_CHAR(O_OUTPUTSTATUS));
  DBMS_OUTPUT.PUT_LINE('O_OUTPUTMESSAGE = ' || O_OUTPUTMESSAGE);
  DBMS_OUTPUT.PUT_LINE('');
  COMMIT; 
END;
/
commit;
show errors;
spool off
eof



GRANT SELECT ANY TABLE, SELECT ANY DICTIONARY, DROP ANY TABLE, CREATE JOB TO MIS;

CREATE OR REPLACE PROCEDURE drop_sc_sn_temp_tables
AS
BEGIN 
    FOR i IN (SELECT owner, object_name FROM dba_objects
              WHERE REGEXP_LIKE(object_name,'S._TEMP[[:digit:]]','i')
                AND object_type='TABLE' AND created < SYSDATE-50/1440)
    LOOP
        DBMS_UTILITY.EXEC_DDL_STATEMENT('drop table '||i.owner||'.'||i.object_name||' purge');
    END LOOP;
END;
/

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( JOB       => X 
   ,what      => 'DECLARE 
                    A NUMBER;
                    B VARCHAR2(100);
                  BEGIN
                      DROP_SC_SN_TEMP_TABLES();
                      COMMIT; 
                  END; '
   ,next_date => TO_DATE('07/16/2014 11:00:00','mm/dd/yyyy hh24:mi:ss')
   ,INTERVAL  => 'TRUNC(SYSDATE+1) + 11/24'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(x));
COMMIT;
END;
/

BEGIN
sys.DBMS_IJOB.CHANGE_ENV
  ( 
     JOB => X, 
     LUSER => 'MIS', 
     PUSER => 'MIS',
    CUSER => 'MIS',
    NLSENV => 'NLS_LANGUAGE=''AMERICAN''
               NLS_TERRITORY=''AMERICA''
               NLS_CURRENCY=''$''
               NLS_ISO_CURRENCY=''AMERICA''
               NLS_NUMERIC_CHARACTERS=''.,''
               NLS_DATE_FORMAT=''DD-MON-RR''
               NLS_DATE_LANGUAGE=''AMERICAN''
               NLS_SORT=''BINARY''
              '); COMMIT;
END;
/




CREATE OR REPLACE PACKAGE TRANSITHA.Data_Center_Parameters AS
-- DCE Data Center Parameter  
  PROCEDURE DCE_CURRENT_PARAMS ;
  PROCEDURE DCE_upd_parameters ;

-- DCW Data Center Parameter  
  PROCEDURE DCw_CURRENT_PARAMS ;
  PROCEDURE DCW_upd_parameters ;
END Data_Center_Parameters;
/
 
CREATE OR REPLACE PACKAGE BODY TRANSITHA.Data_Center_Parameters AS

--  Current Parameters in DCE Data Center 
    PROCEDURE DCE_CURRENT_PARAMS
    AS
        o_OutPut_Message             VARCHAR2(32000) := NULL;
        v_Error_Flag                 NUMBER := 0;
        v_Max_Len_Table_Name_val     NUMBER := 0;
        v_Max_Len_Parameter_Name_val NUMBER := 0;
        v_Len_Table_Name             NUMBER := 0;
        v_Len_Param_Name             NUMBER := 0;
    BEGIN     
        o_OutPut_Message:=NULL;
        SELECT MAX(LENGTH(table_name))+4,
               MAX(LENGTH(UPPER(PARAMETER_NAME)))+4 
        INTO 
               v_Max_Len_Table_Name_val,
               v_Max_Len_Parameter_Name_val
        FROM TRANSITHA.APP_SERVER_PARAMETERS;
            
        FOR i IN (SELECT LENGTH(Table_Name) Len_Table_Name, Table_Name, UPPER(PARAMETER_NAME) PARAMETER_NAME, LENGTH(UPPER(PARAMETER_NAME)) Len_Param_Name, DCE_VALUES
                  FROM TRANSITHA.APP_SERVER_PARAMETERS)
        LOOP
            v_Len_Table_Name := v_Max_Len_Table_Name_val - i.Len_Table_Name ;
            v_Len_Param_Name := v_Max_Len_Parameter_Name_val - i.Len_Param_Name; 
            
            o_OutPut_Message := o_OutPut_Message || i.Table_Name||LPAD(CHR(32),v_Len_Table_Name)||i.PARAMETER_NAME||LPAD(CHR(32),v_Len_Param_Name)||i.DCE_VALUES ||CHR(13) ;
            v_Len_Table_Name:=NULL;
            v_Len_Param_Name:=NULL;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
    END DCE_CURRENT_PARAMS;        

--  Procedure call for DCE Data Center
    PROCEDURE DCE_upd_parameters
    AS
        o_OutPut_Message                VARCHAR2(500) := NULL;
        v_Error_Flag                    NUMBER :=0; -- initialize variable as 0 
        v_UPD_Sql_Query                 VARCHAR2(32000) := NULL; -- initialize variable as empty

        v_UPD_Sql_Query_Display         VARCHAR2(32000) := NULL; -- initialize variable as empty
    BEGIN 

        v_Error_Flag :=1;

--      loop the complete record list
        FOR i IN (SELECT SCHEMA_NAME, TABLE_NAME, SEARCH_COL_NAME1, SEARCH_COL_NAME2, 
                         UPD_COL_NAME, PARAMETER_NAME, DCE_VALUES 
                    FROM TRANSITHA.APP_SERVER_PARAMETERS)
        LOOP
            v_Error_Flag :=2;
--          update query for those records which are having single where conditions
            IF i.SEARCH_COL_NAME1 IS NOT NULL AND i.SEARCH_COL_NAME2 IS NULL AND i.TABLE_NAME <> 'PROCESSOR_CONFIGURATION'
                AND NOT (i.SCHEMA_NAME = 'TRANSTSYSPAYMENTGW' AND i.TABLE_NAME = 'DEPARTMENT_PARAMETERS') THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCE_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.DCE_VALUES ||'''' || CHR(13) ;
            END IF;

            v_Error_Flag :=3;
--          Parameter_name is different in search condition      
            IF (i.SCHEMA_NAME = 'TRANSTSYSPAYMENTGW' AND i.TABLE_NAME = 'DEPARTMENT_PARAMETERS') 
                OR ( i.SCHEMA_NAME = 'SNOX4TRANSNOX' AND i.TABLE_NAME = 'PROCESSOR_CONFIGURATION') THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCE_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.PARAMETER_NAME ||'''' || CHR(13) ;
            END IF;

            v_Error_Flag :=4;
--          Multiple Search condition columns
            IF i.SEARCH_COL_NAME1 IS NOT NULL AND i.SEARCH_COL_NAME2 IS NOT NULL THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCE_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.PARAMETER_NAME ||'''' || CHR(13) ||
                                   '   AND ' || i.SEARCH_COL_NAME2 || ' = ''' || i.DCE_VALUES ||'''' || CHR(13);            
            END IF;

            v_UPD_Sql_Query_Display:= v_UPD_Sql_Query;
            DBMS_OUTPUT.PUT_LINE( v_UPD_Sql_Query_Display );
--          EXECUTE IMMEDIATE v_UPD_Sql_Query_Display ;

            v_UPD_Sql_Query := NULL;
            COMMIT;
        END LOOP;

        v_UPD_Sql_Query_Display:=NULL;
        COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        o_OutPut_Message := 'PROCEDURE FAILED ON Step :'||v_Error_Flag||' FOR SQL '||SUBSTR(SQLERRM,1,100);
        DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
    END DCE_upd_parameters;


--  Current Parameters in DCW Data Center
    PROCEDURE DCW_CURRENT_PARAMS
    AS
        o_OutPut_Message             VARCHAR2(32000) := NULL;
        v_Error_Flag                 NUMBER := 0;
        v_Max_Len_Table_Name_val     NUMBER := 0;
        v_Max_Len_Parameter_Name_val NUMBER := 0;
        v_Len_Table_Name             NUMBER := 0;
        v_Len_Param_Name             NUMBER := 0;
    BEGIN     
        o_OutPut_Message:=NULL;
        SELECT MAX(LENGTH(table_name))+4,
               MAX(LENGTH(UPPER(PARAMETER_NAME)))+4 
        INTO 
               v_Max_Len_Table_Name_val,
               v_Max_Len_Parameter_Name_val
        FROM TRANSITHA.APP_SERVER_PARAMETERS;
            
        FOR i IN (SELECT LENGTH(Table_Name) Len_Table_Name, Table_Name, UPPER(PARAMETER_NAME) PARAMETER_NAME, LENGTH(UPPER(PARAMETER_NAME)) Len_Param_Name, DCW_VALUES
                  FROM TRANSITHA.APP_SERVER_PARAMETERS)
        LOOP
            v_Len_Table_Name := v_Max_Len_Table_Name_val - i.Len_Table_Name ;
            v_Len_Param_Name := v_Max_Len_Parameter_Name_val - i.Len_Param_Name; 
            
            o_OutPut_Message := o_OutPut_Message || i.Table_Name||LPAD(CHR(32),v_Len_Table_Name)||i.PARAMETER_NAME||LPAD(CHR(32),v_Len_Param_Name)||i.DCW_VALUES ||CHR(13) ;
            v_Len_Table_Name:=NULL;
            v_Len_Param_Name:=NULL;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
    END DCW_CURRENT_PARAMS; 
    
--  Procedure call for DCW Data Center
    PROCEDURE DCW_upd_parameters
    AS
        o_OutPut_Message                VARCHAR2(500) := NULL;
        v_Error_Flag                    NUMBER :=0; -- initialize variable as 0 
        v_UPD_Sql_Query                 VARCHAR2(32000) := NULL; -- initialize variable as empty

        v_UPD_Sql_Query_Display         VARCHAR2(32000) := NULL; -- initialize variable as empty
    BEGIN 

        v_Error_Flag :=1;

--      loop the complete record list
        FOR i IN (SELECT SCHEMA_NAME, TABLE_NAME, SEARCH_COL_NAME1, SEARCH_COL_NAME2, 
                         UPD_COL_NAME, PARAMETER_NAME, DCW_VALUES 
                    FROM TRANSITHA.APP_SERVER_PARAMETERS)
        LOOP
            v_Error_Flag :=2;
--          update query for those records which are having single where conditions
            IF i.SEARCH_COL_NAME1 IS NOT NULL AND i.SEARCH_COL_NAME2 IS NULL AND i.TABLE_NAME <> 'PROCESSOR_CONFIGURATION'
                -- AND i.TABLE_NAME <> 'PROCESSOR_SYNC_STATUS'
                AND NOT (i.SCHEMA_NAME = 'TRANSTSYSPAYMENTGW' AND i.TABLE_NAME = 'DEPARTMENT_PARAMETERS') THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.DCW_VALUES ||'''' || CHR(13) ;
            END IF;

            v_Error_Flag :=3;
--          Parameter_name is different in search condition      
            IF (i.SCHEMA_NAME = 'TRANSTSYSPAYMENTGW' AND i.TABLE_NAME = 'DEPARTMENT_PARAMETERS') 
                OR ( i.SCHEMA_NAME = 'SNOX4TRANSNOX' AND i.TABLE_NAME = 'PROCESSOR_CONFIGURATION') THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.PARAMETER_NAME ||'''' || CHR(13) ;
            END IF;

            v_Error_Flag :=4;
--          Multiple Search condition columns
            IF i.SEARCH_COL_NAME1 IS NOT NULL AND i.SEARCH_COL_NAME2 IS NOT NULL THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.PARAMETER_NAME ||'''' || CHR(13) ||
                                   '   AND ' || i.SEARCH_COL_NAME2 || ' = ''' || i.DCW_VALUES ||'''' || CHR(13);            
            END IF;

            v_UPD_Sql_Query_Display:= v_UPD_Sql_Query;
            DBMS_OUTPUT.PUT_LINE( v_UPD_Sql_Query_Display );
--          EXECUTE IMMEDIATE v_UPD_Sql_Query_Display ;

            v_UPD_Sql_Query := NULL;
            COMMIT;
        END LOOP;

        v_UPD_Sql_Query_Display:=NULL;
        COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        o_OutPut_Message := 'PROCEDURE FAILED ON Step :'||v_Error_Flag||' FOR SQL '||SUBSTR(SQLERRM,1,100);
        DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
    END DCW_upd_parameters;
 
END Data_Center_Parameters;
/


PROCEDURE DCW_CURRENT_PARAMS
    o_OutPut_Message             VARCHAR2(32000);
    v_Error_Flag                 NUMBER;
    v_Max_Len_Table_Name_val     NUMBER;
    v_Max_Len_Parameter_Name_val NUMBER;
    v_Len_Table_Name             NUMBER;
    v_Len_Param_Name             NUMBER;
BEGIN     
    
    o_OutPut_Message:=NULL;
    SELECT MAX(LENGTH(table_name))+4,
           MAX(LENGTH(UPPER(PARAMETER_NAME)))+4 
    INTO 
           v_Max_Len_Table_Name_val,
           v_Max_Len_Parameter_Name_val
    FROM TRANSITHA.APP_SERVER_PARAMETERS;
        
    FOR i IN (SELECT LENGTH(Table_Name) Len_Table_Name, Table_Name, UPPER(PARAMETER_NAME) PARAMETER_NAME, LENGTH(UPPER(PARAMETER_NAME)) Len_Param_Name, DCW_VALUES
              FROM TRANSITHA.APP_SERVER_PARAMETERS)
    LOOP
        v_Len_Table_Name := v_Max_Len_Table_Name_val - i.Len_Table_Name ;
        v_Len_Param_Name := v_Max_Len_Parameter_Name_val - i.Len_Param_Name; 
        
        o_OutPut_Message := o_OutPut_Message || i.Table_Name||LPAD(CHR(32),v_Len_Table_Name)||i.PARAMETER_NAME||LPAD(CHR(32),v_Len_Param_Name)||i.DCW_VALUES ||CHR(13) ;
        v_Len_Table_Name:=NULL;
        v_Len_Param_Name:=NULL;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
END DCW_CURRENT_PARAMS;




DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( JOB       => X 
   ,what      => 'DECLARE 
					  P_OUTPUTSTATUS VARCHAR2(5);
					  P_OUTPUTMSG VARCHAR2(32767);
					  v_Last_Process_Status NUMBER;
					BEGIN 
						v_Last_Process_Status := NULL;
						P_OUTPUTSTATUS := NULL;
						P_OUTPUTMSG := NULL;
						BEGIN 
							SELECT  COUNT(1)  INTO v_Last_Process_Status
							FROM purgedata.purge_logs 
							WHERE table_name=''TRANSIT_PURGING_PKG-END''
							  AND executedon >= (SELECT MAX(executedon) 
												 FROM purgedata.purge_logs 
												 WHERE table_name=''TRANSIT_PURGING_PKG-BEGIN'');
							IF v_Last_Process_Status <> 0                    
							  PURGEDATA.TRANSIT_PURGING_PKG.PURGE_TAB_PROCS ( P_OUTPUTSTATUS, P_OUTPUTMSG );
							  COMMIT;
							END IF;
						EXCEPTION
						   WHEN OTHERS THEN
							  NULL;
							  EXIT;
						END; 
					END;'
   ,next_date => TO_DATE('05/08/2013 01:06:06','dd/mm/yyyy hh24:mi:ss')
   ,INTERVAL  => 'SYSDATE+15/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(x));
COMMIT;
END;
/

SELECT * FROM dba_jobs WHERE JOB=66;


BEGIN
sys.DBMS_IJOB.CHANGE_ENV
  ( 
     JOB => 66, 
     LUSER => 'TRANSCAPITALONEAPP', 
     PUSER => 'TRANSCAPITALONEAPP',
    CUSER => 'TRANSCAPITALONEAPP',
    NLSENV => 'NLS_LANGUAGE=''AMERICAN''
               NLS_TERRITORY=''AMERICA''
               NLS_CURRENCY=''$''
               NLS_ISO_CURRENCY=''AMERICA''
               NLS_NUMERIC_CHARACTERS=''.,''
               NLS_DATE_FORMAT=''DD-MON-RR''
               NLS_DATE_LANGUAGE=''AMERICAN''
               NLS_SORT=''BINARY''
              '); COMMIT;
END;
/



declare
  my_job number;
begin
  dbms_job.submit(job => my_job, 
    what => 'DECLARE 
					  P_OUTPUTSTATUS VARCHAR2(5);
					  P_OUTPUTMSG VARCHAR2(32767);
					  v_Last_Process_Status NUMBER;
					BEGIN 
						v_Last_Process_Status := NULL;
						P_OUTPUTSTATUS := NULL;
						P_OUTPUTMSG := NULL;
						BEGIN 
							SELECT  COUNT(1)  INTO v_Last_Process_Status
							FROM purgedata.purge_logs 
							WHERE table_name=''TRANSIT_PURGING_PKG-END''
							  AND executedon >= (SELECT MAX(executedon) 
												 FROM purgedata.purge_logs 
												 WHERE table_name=''TRANSIT_PURGING_PKG-BEGIN'');
							IF v_Last_Process_Status <> 0                    
							  PURGEDATA.TRANSIT_PURGING_PKG.PURGE_TAB_PROCS ( P_OUTPUTSTATUS, P_OUTPUTMSG );
							  COMMIT;
							END IF;
						EXCEPTION
						   WHEN OTHERS THEN
							  NULL;
							  EXIT;
						END; 
					END; ',
    next_date => trunc(sysdate)+1,
    interval => 'sysdate+1'
    ,no_parse  => FALSE
    );
    DBMS_OUTPUT.PUT_LINE(my_job);
    commit;
	sys.DBMS_IJOB.CHANGE_ENV
    ( 
     JOB => my_job , 
     LUSER => 'PURGEDATA', 
     PUSER => 'PURGEDATA',
    CUSER => 'PURGEDATA',
    NLSENV => 'NLS_LANGUAGE=''AMERICAN''
               NLS_TERRITORY=''AMERICA''
               NLS_CURRENCY=''$''
               NLS_ISO_CURRENCY=''AMERICA''
               NLS_NUMERIC_CHARACTERS=''.,''
               NLS_DATE_FORMAT=''DD-MON-RR''
               NLS_DATE_LANGUAGE=''AMERICAN''
               NLS_SORT=''BINARY'''); COMMIT;
END;
/ 

expdp rchaudhari directory=arc dumpfile=expdp_New_VBS_JuneRelease.dmp logfile=expdp_New_VBS_JuneRelease.log schemas=SNOXPASS_TFE_2016,TNOXPASS_TFE_2016,SNOXPASS_GWAY_012,TNOXPASS_GWAY_012 exclude=statistics,table:\"like\'SC_TEM%\'\",table:\"like\'SN_TEMP%\'\"

impdp rchaudhari directory=arc dumpfile=expdp_New_VBS_JuneRelease.dmp logfile=impdp_expdp_New_VBS_JuneRelease.log remap_schema=SNOXPASS_TFE_2016:SNOXPASS_TFE_2017 remap_schema=TNOXPASS_TFE_2016:TNOXPASS_TFE_2017 remap_schema=SNOXPASS_GWAY_012:SNOXPASS_GWAY_013 remap_schema=TNOXPASS_GWAY_012:TNOXPASS_GWAY_013



SNOXPASS_TFE_2017,TNOXPASS_TFE_2017,SNOXPASS_GWAY_013,TNOXPASS_GWAY_013



-- List of Mother schemas
MAP KEYNOX_CPASS.*, TARGET KEYNOX_CPASS.*;
MAP WEBFORT_CPASS.*, TARGET WEBFORT_CPASS.*;

MAPEXCLUDE TRANSNOX_CAT.SN_TEMP*
MAPEXCLUDE TRANSNOX_CAT.SC_TEMP*
MAP TRANSNOX_CAT.*, TARGET TRANSNOX_CAT.*;

MAPEXCLUDE TRANSNOX_IOX.SN_TEMP*
MAPEXCLUDE TRANSNOX_IOX.SC_TEMP*
MAP TRANSNOX_IOX.*, TARGET TRANSNOX_IOX.*;

MAPEXCLUDE SNOX4TRANSNOX.SN_TEMP*
MAPEXCLUDE SNOX4TRANSNOX.SC_TEMP*
MAP SNOX4TRANSNOX.*, TARGET SNOX4TRANSNOX.*;
MAP TRANSTSYSPAYMENTGW.*, TARGET TRANSTSYSPAYMENTGW.*;

-- List of APP Schemas
-- NOTE: SC_TEMP and SN_TEMP s are not created in *SMSNOX* VBS
MAP ETLUPDATE.*, TARGET ETLUPDATE.*;

MAPEXCLUDE TRANSNOX_IOX_APP.SN_TEMP*
MAPEXCLUDE TRANSNOX_IOX_APP.SC_TEMP*
MAP TRANSNOX_IOX_APP.*, TARGET TRANSNOX_IOX_APP.*;

MAPEXCLUDE SNOX4TRANSNOX_APP.SN_TEMP*
MAPEXCLUDE SNOX4TRANSNOX_APP.SC_TEMP*
MAP SNOX4TRANSNOX_APP.*, TARGET SNOX4TRANSNOX_APP.*;

MAP TRANSTSYSPAYMENTGWAPP.*, TARGET TRANSTSYSPAYMENTGWAPP.*;

-- Current VBS
MAPEXCLUDE TNOXPASS_GWAY_012.SN_TEMP*
MAPEXCLUDE TNOXPASS_GWAY_012.SC_TEMP*
MAP TNOXPASS_GWAY_012.*, TARGET TNOXPASS_GWAY_012.*;

MAPEXCLUDE SNOXPASS_GWAY_012.SN_TEMP*
MAPEXCLUDE SNOXPASS_GWAY_012.SC_TEMP*
MAP SNOXPASS_GWAY_012.*, TARGET SNOXPASS_GWAY_012.*;

MAPEXCLUDE SNOXPASS_SMSNOX_307.SN_TEMP*
MAPEXCLUDE SNOXPASS_SMSNOX_307.SC_TEMP*
MAP SNOXPASS_SMSNOX_307.*, TARGET SNOXPASS_SMSNOX_307.*;

MAPEXCLUDE TNOXPASS_SMSNOX_307.SN_TEMP*
MAPEXCLUDE TNOXPASS_SMSNOX_307.SC_TEMP*
MAP TNOXPASS_SMSNOX_307.*, TARGET TNOXPASS_SMSNOX_307.*;

MAPEXCLUDE SNOXPASS_TFE_2016.SN_TEMP*
MAPEXCLUDE SNOXPASS_TFE_2016.SC_TEMP*
MAP SNOXPASS_TFE_2016.*, TARGET SNOXPASS_TFE_2016.*;

MAPEXCLUDE TNOXPASS_TFE_2016.SN_TEMP*
MAPEXCLUDE TNOXPASS_TFE_2016.SC_TEMP*
MAP TNOXPASS_TFE_2016.*, TARGET TNOXPASS_TFE_2016.*;

-- Previous VBS
MAPEXCLUDE TNOXPASS_GWAY_011.SN_TEMP*
MAPEXCLUDE TNOXPASS_GWAY_011.SC_TEMP*
MAP TNOXPASS_GWAY_011.*, TARGET TNOXPASS_GWAY_011.*;

MAPEXCLUDE TNOXPASS_GWAY_011.SN_TEMP*
MAPEXCLUDE TNOXPASS_GWAY_011.SC_TEMP*
MAP SNOXPASS_GWAY_011.*, TARGET SNOXPASS_GWAY_011.*;

MAPEXCLUDE SNOXPASS_SMSNOX_306.SN_TEMP*
MAPEXCLUDE SNOXPASS_SMSNOX_306.SC_TEMP*
MAP SNOXPASS_SMSNOX_306.*, TARGET SNOXPASS_SMSNOX_306.*;

MAPEXCLUDE TNOXPASS_SMSNOX_306.SN_TEMP*
MAPEXCLUDE TNOXPASS_SMSNOX_306.SC_TEMP*
MAP TNOXPASS_SMSNOX_306.*, TARGET TNOXPASS_SMSNOX_306.*;

MAPEXCLUDE TNOXPASS_TFE_2015.SN_TEMP*
MAPEXCLUDE TNOXPASS_TFE_2015.SC_TEMP*
MAP TNOXPASS_TFE_2015.*, TARGET TNOXPASS_TFE_2015.*;

MAPEXCLUDE SNOXPASS_TFE_2015.SN_TEMP*
MAPEXCLUDE SNOXPASS_TFE_2015.SC_TEMP*
MAP SNOXPASS_TFE_2015.*, TARGET SNOXPASS_TFE_2015.*;

-- VBS Used for Socket Getway
MAPEXCLUDE SNOXPASS_SMSNOX_20195.SN_TEMP*
MAPEXCLUDE SNOXPASS_SMSNOX_20195.SC_TEMP*
MAP SNOXPASS_SMSNOX_20195.*, TARGET SNOXPASS_SMSNOX_20195.*;

MAPEXCLUDE TNOXPASS_SMSNOX_20195.SN_TEMP*
MAPEXCLUDE TNOXPASS_SMSNOX_20195.SC_TEMP*
MAP TNOXPASS_SMSNOX_20195.*, TARGET TNOXPASS_SMSNOX_20195.*;

MAPEXCLUDE SNOXPASS_GWAY_00526.SN_TEMP*
MAPEXCLUDE SNOXPASS_GWAY_00526.SC_TEMP*
MAP SNOXPASS_GWAY_00526.*, TARGET SNOXPASS_GWAY_00526.*;

MAPEXCLUDE TNOXPASS_GWAY_00526.SN_TEMP*
MAPEXCLUDE TNOXPASS_GWAY_00526.SC_TEMP*
MAP TNOXPASS_GWAY_00526.*, TARGET TNOXPASS_GWAY_00526.*;




SELECT 'alter table '||owner||'.'||table_name|| ' nocompress;'
FROM dba_tables
WHERE owner IN ('ETLUPDATE','KEYNOX_CPASS','WEBFORT_CPASS','TRANSNOX_CAT','TRANSNOX_IOX','SNOX4TRANSNOX','TRANSNOX_IOX_APP','SNOX4TRANSNOX_APP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TNOXPASS_GWAY_012','SNOXPASS_GWAY_012','SNOXPASS_SMSNOX_307','TNOXPASS_SMSNOX_307','SNOXPASS_TFE_2016','TNOXPASS_TFE_2016','TNOXPASS_GWAY_011','SNOXPASS_GWAY_011','SNOXPASS_SMSNOX_306','TNOXPASS_SMSNOX_306','TNOXPASS_TFE_2015','SNOXPASS_TFE_2015','SNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20195','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526')
 AND COMPRESSION='ENABLED' 
 AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
--ORDER BY owner,table_name ASC 
UNION ALL
SELECT 'alter table '||owner||'.'||table_name||' logging;'
FROM dba_tables
WHERE owner IN ('ETLUPDATE','KEYNOX_CPASS','WEBFORT_CPASS','TRANSNOX_CAT','TRANSNOX_IOX','SNOX4TRANSNOX','TRANSNOX_IOX_APP','SNOX4TRANSNOX_APP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TNOXPASS_GWAY_012','SNOXPASS_GWAY_012','SNOXPASS_SMSNOX_307','TNOXPASS_SMSNOX_307','SNOXPASS_TFE_2016','TNOXPASS_TFE_2016','TNOXPASS_GWAY_011','SNOXPASS_GWAY_011','SNOXPASS_SMSNOX_306','TNOXPASS_SMSNOX_306','TNOXPASS_TFE_2015','SNOXPASS_TFE_2015','SNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20195','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526')
 AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
 AND LOGGING='NO'
 
 
SELECT ROUND(FREE_MB/TOTAL_MB*100) PERCENTAGE 
FROM V$ASM_DISKGROUP
WHERE NAME='ASMTXNARCHIVE'


alter user SNOXPASS_TFE_2017 identified by "SnoxPass_Tfe$2017";
alter user TNOXPASS_TFE_2017 identified by "TnoxPass_Tfe$2017";
alter user SNOXPASS_GWAY_013 identified by "SnoxPass_Gway$013";
alter user TNOXPASS_GWAY_013 identified by "TnoxPass_Gway$013";
ALTER USER SNOXPASS_TFE_2017 DEFAULT TABLESPACE ALL_TEMP_TABLES ;
ALTER USER TNOXPASS_TFE_2017 DEFAULT TABLESPACE ALL_TEMP_TABLES;
ALTER USER SNOXPASS_GWAY_013 DEFAULT TABLESPACE ALL_TEMP_TABLES;
ALTER USER TNOXPASS_GWAY_013 DEFAULT TABLESPACE ALL_TEMP_TABLES;




--------------------------------------------------------------------------------------------------
-- Jun TransIT DB release VBS details

SNOXPASS_TFE_2017	59EA217B91375581EF2AFAA28AD9129940429A937078BA09  -->> SnoxPass_Tfe$2017 
TNOXPASS_TFE_2017	2ECCF4EC7CFF2A8EEF2AFAA28AD9129940429A937078BA09  -->> TnoxPass_Tfe$2017 

SNOXPASS_GWAY_013	59EA217B91375581F89A2876C7F9CD96E30AE00E0F1AF8CA  -->> SnoxPass_Gway$013
TNOXPASS_GWAY_013	2ECCF4EC7CFF2A8EF89A2876C7F9CD96E30AE00E0F1AF8CA  -->> TnoxPass_Gway$013


-- for SNOXPASS_TFE_2017 schema
Key = AD2554378CE5FB13
Password = B573FE912F1DA39F54E5C642213560F1D8FB72D258A1713C

-- for TNOXPASS_TFE_2017 schema
Key = 2C8CA4A883C2CE83
Password = F54A8977A943D37279705731EB6744267803069801BA4138
--------------------------------------------------------------------------------------------------




rman script test

18662875993 755264

-- SQL Server
20140426 -- for SQL Server
20140427
20140428
20140429
20140430
20140501
20140502
20140503
20140504
20140505
20140506
20140507
20140508
20140509
20140510
20140511
20140512


cqID00059272 -- [Create the dbaudit user on production databases]

cqID00059273 -- [Apply latest patch on Goldengate Software]


xi
# checking the /archivelogs disk partition space where archive files are getting created
VAL=`df -h | grep "/archivelogs" | awk '{print $4}'|sed 's/%//g'`

if [ $VAL '>' 70 ]
then
    echo  $VAL > log_no_ds.log
    echo "/archivelogs Disk space above 70%"

	 -- cd /archivelogs/oracle/oradata/tsnd/archive

	--- find 1_*.arc -type f -mtime +0 -exec ls -l {} \; > temp_file.sh
	echo "RMAN script to remove the archive files more then 3 days"
	
else
    echo "$VAL"
    echo "/archivelogs Disk space is below 70%"
fi






UPDATE SNOX4TRANSNOX.PROCESSOR_CONFIGURATION
SET PROPERTY_VALUE = 'http://e-hmytadapter.tsysacquiring.org:6008/servlets/TransNox_Adapter_Interface' (http://e-hmytadapter.tsysacquiring.org:6008/servlets/TransNox_Adapter_Interface%27) 
WHERE PROCESSOR_ID='MQ';  



1. RMAN Backup Setup
	(Baidhar, Rahul): 9th May 2014 Friday PST

2. Install Golden Gate Software
    a. Golden Gate Software is already is present in RAC DBs
    b. goldengate user will be in DB "cpgate"
    c. 
    
    
    
obey cpdb


/archivelog/goldengate

-- Steps on 19th May 2014
1) Application out of service

2) Disable DataGuard 

3) stop listener and kill sessions in OS
	lsnrctl stop
	ps -ewf |grep "LOCAL=NO"|awk '{print $2}' | xargs kill -9
	
4) run the sql command in DB
	ALTER SYSTEM SET RECYCLEBIN=OFF SCOPE=SPFILE;
	
5) Stop In-House Replication

6) shutdown the DB

7) Disable oracle database Vault os command
	chopt disable dv
	
8) Start the Database
	startup

9) start listener
	lsnrctl start
	
10) i) Enable standby
   ii) Start the In-House Replication

11) Put Applications in in-service

12) Verify the replication and data is replicated

   
   


--1) RMAN Level 1 Cumulative backup 
--2) Create all Processes obey files..
--3) Create expdp script for current cpdb with flashback_scn option
--4) Spider commissions




1 modify the extract for testing
2 start extract 


/home/oracle/scripts/trans_settlement_stats.sql


tion INC_METER_PK_IMPTS
Log messages written to /opt/app/oracle/diag/tnslsnr/qadbnode1/listener_scan1/alert/log.xml
Trace information written to /opt/app/oracle/diag/tnslsnr/qadbnode1/listener_scan1/trace/ora_9938_140062157436672.trc
Trace level is currently 0


expdp / directory="BKUPS" dumpfile="expdp_qaracdb2_bkups_$bkupDate.dmp" logfile="logs_expdp_qaracdb2_bkups.log" exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\",table:\"like \'SC_TEMP%\'\",schema:\"in \(\'XS$NULL\',\'XDB\',\'WMSYS\',\'TOAD\',\'SYSTEM\',\'SYSMAN\',\'SYS\',\'SPATIAL_WFS_ADMIN_USR\',\'SPATIAL_CSW_ADMIN_USR\',\'SI_INFORMTN_SCHEMA\',\'RMAN\',\'OWBSYS_AUDIT\',\'OWBSYS\',\'OUTLN\',\'ORDSYS\',\'ORDPLUGINS\',\'ORDDATA\',\'ORACLE_OCM\',\'OPS$ORACLE\',\'OLAPSYS\',\'MGMT_VIEW\',\'MDSYS\',\'FLOWS_FILES\',\'EXFSYS\',\'DIP\',\'DBSNMP\',\'CTXSYS\',\'APPQOSSYS\',\'APEX_PUBLIC_USER\',\'APEX_030200\',\'ANONYMOUS\'\)\"  full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y
  

expdp / directory=DPUMP dumpfile="expdp_qaracdb2_bkups_13May2014.dmp" logfile="logs_expdp_qaracdb2_bkups.log" exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\",table:\"like \'SC_TEMP%\'\",schema:\"in \(\'XS$NULL\',\'XDB\',\'WMSYS\',\'TOAD\',\'SYSTEM\',\'SYSMAN\',\'SYS\',\'SPATIAL_WFS_ADMIN_USR\',\'SPATIAL_CSW_ADMIN_USR\',\'SI_INFORMTN_SCHEMA\',\'RMAN\',\'OWBSYS_AUDIT\',\'OWBSYS\',\'OUTLN\',\'ORDSYS\',\'ORDPLUGINS\',\'ORDDATA\',\'ORACLE_OCM\',\'OPS$ORACLE\',\'OLAPSYS\',\'MGMT_VIEW\',\'MDSYS\',\'FLOWS_FILES\',\'EXFSYS\',\'DIP\',\'DBSNMP\',\'CTXSYS\',\'APPQOSSYS\',\'APEX_PUBLIC_USER\',\'APEX_030200\',\'ANONYMOUS\'\)\"  full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y &


CREATE TABLE GGATE.EXCEPTIONS
(
  REP_NAME         VARCHAR2(8 BYTE),
  TABLE_NAME       VARCHAR2(61 BYTE),
  ERRNO            NUMBER,
  DBERRMSG         VARCHAR2(4000 BYTE),
  OPTYPE           VARCHAR2(20 BYTE),
  ERRTYPE          VARCHAR2(20 BYTE),
  LOGRBA           NUMBER,
  LOGPOSITION      NUMBER,
  COMMITTIMESTAMP  TIMESTAMP(6),
  SUPPLEMENTAL LOG GROUP GGS_231755 (LOGRBA,LOGPOSITION,COMMITTIMESTAMP) ALWAYS
)
TABLESPACE GGS_DATA
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS ;


CREATE UNIQUE INDEX GGATE.PK_CTS1 ON GGATE.EXCEPTIONS
(LOGRBA, LOGPOSITION, COMMITTIMESTAMP)
LOGGING TABLESPACE GGS_DATA;

ALTER TABLE GGATE.EXCEPTIONS ADD (
  CONSTRAINT PK_CTS1 PRIMARY KEY (LOGRBA, LOGPOSITION, COMMITTIMESTAMP)
  USING INDEX GGATE.PK_CTS1 ENABLE VALIDATE);



EXCLUDE OBJNAME SNOX4TRANSNOX_APP.SN_TEMP*, EXCLUDE OBJNAME TRANSNOX_IOX_APP.SN_TEMP*, &


TABLEEXCLUDE SNOX4TRANSNOX_APP.SN_TEMP*

TABLEEXCLUDE TRANSNOX_IOX_APP.SN_TEMP*



014-04-01 11:38:57   INFO    OGG-00987  Oracle GoldenGate Command Interpreter for Oracle:  GGSCI command (goldengate): stop extract pp*.
2014-04-01 11:38:57  INFO    OGG-01021  Oracle GoldenGate Capture for Oracle, pptere.prm:  Command received from GGSCI: STOP.
2014-04-01 11:38:57  INFO    OGG-00991  Oracle GoldenGate Capture for Oracle, pptere.prm:  EXTRACT PPTERE stopped normally.
2014-04-01 11:38:58  INFO    OGG-01021  Oracle GoldenGate Capture for Oracle, ppterw.prm:  Command received from GGSCI: STOP.
2014-04-01 11:38:58  INFO    OGG-01021  Oracle GoldenGate Capture for Oracle, pptetw.prm:  Command received from GGSCI: STOP.
2014-04-01 11:38:58  INFO    OGG-00991  Oracle GoldenGate Capture for Oracle, ppterw.prm:  EXTRACT PPTERW stopped normally.
2014-04-01 11:38:58  INFO    OGG-00991  Oracle GoldenGate Capture for Oracle, pptetw.prm:  EXTRACT PPTETW stopped normally.
2014-04-01 11:39:04  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:04  WARNING OGG-01931  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore 'dirbdb' cannot be opened. Error -30973 (BDB0087 DB_RUNRECOVERY: Fatal error, run database recovery).
2014-04-01 11:39:05  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:06  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:07  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:08  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:09  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:10  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:11  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:12  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:13  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:14  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:15  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:16  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:17  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:18  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:19  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:20  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:21  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:22  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:23  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:24  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:25  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:26  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:27  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:28  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:29  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:30  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.
2014-04-01 11:39:31  WARNING OGG-01930  Oracle GoldenGate Delivery for Oracle, rptetw.prm:  Datastore error in 'dirbdb': BDB0113 Thread/process 11661/140144917083904 failed: BDB1507 Thread died in Berkeley DB library.



--------------------------------------

2014-04-01 12:26:49  INFO    OGG-01026  Oracle GoldenGate Capture for Oracle, eptw.prm:  Rolling over remote file /acfs/goldengate/dirdat/LC002285.
2014-04-01 12:26:49  INFO    OGG-01053  Oracle GoldenGate Capture for Oracle, eptw.prm:  Recovery completed for target file /acfs/goldengate/dirdat/LC002286, at RBA 1149.
2014-04-01 12:26:49  INFO    OGG-01057  Oracle GoldenGate Capture for Oracle, eptw.prm:  Recovery completed for all targets.
2014-04-01 12:26:49  INFO    OGG-01517  Oracle GoldenGate Capture for Oracle, eptw.prm:  Position of first record processed for Thread 3, Sequence 4546, RBA 33050128, SCN 0.458731788, Apr 1, 2014 12:26:30 PM.
2014-04-01 12:29:57  INFO    OGG-01487  Oracle GoldenGate Capture for Oracle, eptw.prm:  DDL found, operation [CREATE TABLE transnox_iox.count21 AS
SELECT TO_CHAR(time_stamp, 'mm/dd/yyyy hh24:mi') TIMESTAMP, COUNT(*) cnt
FROM transnox_iox.TRANSACTION
WHERE time_stamp >= SYSDATE - 10/1440
GROUP BY TO_CHAR(time_stamp, 'mm/dd/yyyy hh24:mi')
ORDER BY TO_DATE(TO_CHAR(time_stamp, 'mm/dd/yyyy hh24:mi'), 'mm/dd/yyyy hh24:mi') DESC  (size 317)], start SCN [458733222], commit SCN [458733245] instance [transitt1 (1)], DDL seqno [879837], marker seqno [879837].
2014-04-01 12:29:57  INFO    OGG-00487  Oracle GoldenGate Capture for Oracle, eptw.prm:  DDL operation included [INCLUDE ALL], optype [CREATE], objtype [TABLE], objowner [TRANSNOX_IOX], objname [COUNT21].
2014-04-01 12:29:57  INFO    OGG-00497  Oracle GoldenGate Capture for Oracle, eptw.prm:  Writing DDL operation to extract trail file.
2014-04-01 12:29:59  INFO    OGG-00477  Oracle GoldenGate Capture for Oracle, eptw.prm:  Successfully added TRAN DATA for table [TRANSNOX_IOX.COUNT21], operation [ALTER TABLE "TRANSNOX_IOX"."COUNT21" ADD SUPPLEMENTAL LOG DATA (ALL) COLUMNS  /* GOLDENGATE_DDL_REPLICATION */ (size 110)].


------------------------------------------

-- Don't allow deletes from the below mentioned tables list to be replicate
IGNOREDELETES

-- On Below mention Tables We have to Ignore Deletes and Get Deletes on rest of the schemas tables

-- SnoxTransnox schema
MAP SNOX4TRANSNOX.USER_AUDIT_DETAIL, TARGET SNOX4TRANSNOX.USER_AUDIT_DETAIL;
MAP SNOX4TRANSNOX.USER_AUDIT, TARGET SNOX4TRANSNOX.USER_AUDIT;
MAP SNOX4TRANSNOX.EVENT, TARGET SNOX4TRANSNOX.EVENT;

-- Transno_IOX schema
MAP TRANSNOX_IOX.TRANS_SETTLEMENT, TARGET TRANSNOX_IOX.TRANS_SETTLEMENT;
MAP TRANSNOX_IOX.TRANSACTION, TARGET TRANSNOX_IOX.TRANSACTION;
MAP TRANSNOX_IOX.TRANS_STATUS_HISTORY, TARGET TRANSNOX_IOX.TRANS_STATUS_HISTORY;
MAP TRANSNOX_IOX.TRANS_SIGNATURE_HISTORY, TARGET TRANSNOX_IOX.TRANS_SIGNATURE_HISTORY;
MAP TRANSNOX_IOX.TRANS_SIGNATURE, TARGET TRANSNOX_IOX.TRANS_SIGNATURE;
MAP TRANSNOX_IOX.TRANS_SHIPPING_ADDRESS, TARGET TRANSNOX_IOX.TRANS_SHIPPING_ADDRESS;
MAP TRANSNOX_IOX.TRANS_PAYROLL, TARGET TRANSNOX_IOX.TRANS_PAYROLL;
MAP TRANSNOX_IOX.TRANS_MONEY_TRANSFER, TARGET TRANSNOX_IOX.TRANS_MONEY_TRANSFER;
MAP TRANSNOX_IOX.TRANS_MONEY_ORDER, TARGET TRANSNOX_IOX.TRANS_MONEY_ORDER;
MAP TRANSNOX_IOX.TRANS_COMPLIANCE_INFO, TARGET TRANSNOX_IOX.TRANS_COMPLIANCE_INFO;
MAP TRANSNOX_IOX.TRANS_CHECK_DEPOSITE, TARGET TRANSNOX_IOX.TRANS_CHECK_DEPOSITE;
MAP TRANSNOX_IOX.TRANS_CHECK_CLEAR_AMOUNT, TARGET TRANSNOX_IOX.TRANS_CHECK_CLEAR_AMOUNT;
MAP TRANSNOX_IOX.TRANS_CHECK, TARGET TRANSNOX_IOX.TRANS_CHECK;
MAP TRANSNOX_IOX.TRANS_CASH, TARGET TRANSNOX_IOX.TRANS_CASH;
MAP TRANSNOX_IOX.TRANS_ADDITIONAL_AMOUNT_TYPE, TARGET TRANSNOX_IOX.TRANS_ADDITIONAL_AMOUNT_TYPE;
MAP TRANSNOX_IOX.RECURRING_PAYMENT, TARGET TRANSNOX_IOX.RECURRING_PAYMENT;
MAP TRANSNOX_IOX.MO_DT3_TRANSACTION_SUMMARY, TARGET TRANSNOX_IOX.MO_DT3_TRANSACTION_SUMMARY;
MAP TRANSNOX_IOX.MO_DT3_TRANSACTION_DETAILS, TARGET TRANSNOX_IOX.MO_DT3_TRANSACTION_DETAILS;
MAP TRANSNOX_IOX.TRANS_CARD, TARGET TRANSNOX_IOX.TRANS_CARD;
MAP TRANSNOX_IOX.TRANS_RESPONSE_INFO, TARGET TRANSNOX_IOX.TRANS_RESPONSE_INFO;
MAP TRANSNOX_IOX.TRANS_DETAIL, TARGET TRANSNOX_IOX.TRANS_DETAIL;
MAP TRANSNOX_IOX.TRANS_ADDITIONAL_INFO, TARGET TRANSNOX_IOX.TRANS_ADDITIONAL_INFO;
MAP TRANSNOX_IOX.TRANS_BANK_DETAIL, TARGET TRANSNOX_IOX.TRANS_BANK_DETAIL;
MAP TRANSNOX_IOX.TRANS_RETURN, TARGET TRANSNOX_IOX.TRANS_RETURN;
MAP TRANSNOX_IOX.REQUEST_AUDIT_TRAIL, TARGET TRANSNOX_IOX.REQUEST_AUDIT_TRAIL;
MAP TRANSNOX_IOX.REPORT_USAGE_AUDITTRAIL, TARGET TRANSNOX_IOX.REPORT_USAGE_AUDITTRAIL;
MAP TRANSNOX_IOX.TRANS_BILLING_ADDRESS, TARGET TRANSNOX_IOX.TRANS_BILLING_ADDRESS;
MAP TRANSNOX_IOX.DATABASE_EXEC_LOG, TARGET TRANSNOX_IOX.DATABASE_EXEC_LOG;

--- Allow delete operation from below mentioned tables list
GETDELETES





UPDATE SNOX4TRANSNOX.PROCESSOR_CONFIGURATION
SET PROPERTY_VALUE = 'http://e-hmytadapter.tsysacquiring.org:6008/servlets/TransNox_Adapter_Interface'
WHERE PROCESSOR_ID='MQ'; 

COMMIT;

UPDATE SNOX4TRANSNOX.PROCESSOR_CONFIGURATION
SET property_value='http://10.123.210.215:6008/servlets/TransNox_Adapter_Interface'
WHERE processor_id='MQ'

SELECT * FROM SNOX4TRANSNOX.PROCESSOR_CONFIGURATION

-- For Election Card
2 Pass Size Photos
Lic copy
Index2 Copy
Elec. Bill
PAN Card
Adhar Card



10.100.226.221--- old dev database

10.132.12.170 mapqadb	--- MAP QA DB
10.132.13.130 arcdb -- dev archive DB
10.132.13.208 Pridb -- OGG1
10.132.13.209 reptdb -- OGG1

loadtxdbnode1.tsysacquiring.org -- txnDCW txnDCE
loadrpdbnode1.tsysacquiring.org -- rptDCW rptDCE
regracdb.tsysacquiring.org
devracdb.tsysacquiring.org
qaracdb.tsysacquiring.org


Reliance Accounts Customer AC:-100117644177
Bill AC:-100000118637734
RahulKC201

204440288 16Jun2013 -- compl.

211119945 26oct2013


-- Cycles
Hero Octane Recra 26T
Hero Octane Estes



https://tsys.taleo.net/careersection/tsys.careersection.internal.001/jobsearch.ftl?lang=en




-- local 
seven$Thousand201

-- col
Donkey.2012014


Teeth DR. 9921496415 Manoj Kulthe



---------------------------------------------------------------------------
-- 27-Mar-2014

SELECT owner, table_name
FROM dba_tables
WHERE LOGGING ='NO'
  AND owner NOT IN ('APEX_030200','APPQOSSYS','CTXSYS','DBSNMP','EXFSYS','FLOWS_FILES','JMURUGAN','MBADHE',
                    'MDSYS','MIS','OLAPSYS','ORDDATA','ORDSYS','OUTLN','OWBSYS','RCHAUDHARI','SCOTT','SMALIK',
                    'SRC_C_REPL','SYS','SYSMAN','SYSTEM','WMSYS','XDB','DBHOSALE')
ORDER BY 1, 2 ASC


SELECT owner, table_name
FROM dba_tables
WHERE owner NOT IN ('APEX_030200','APPQOSSYS','CTXSYS','DBSNMP','EXFSYS','FLOWS_FILES','JMURUGAN','MBADHE',
                    'MDSYS','MIS','OLAPSYS','ORDDATA','ORDSYS','OUTLN','OWBSYS','RCHAUDHARI','SCOTT','SMALIK',
                    'SRC_C_REPL','SYS','SYSMAN','SYSTEM','WMSYS','XDB','DBHOSALE')
  AND compression='ENABLED'
  AND table_name NOT LIKE 'SN_TEMP%' AND table_name NOT LIKE 'SC_TEMP%'
ORDER BY 1,2 ASC  

COMPRESSION, LOGGING


snox4transnox.MER_PROCESSOR_INFO
----------------------------------------------------------------------------





---- refreshing the rptDCW, txnDCE,rptDCE databases...


DROP USER TRANSNOX_CAT CASCADE;
DROP USER TRANSNOX_CPASS CASCADE;
DROP USER SNOX4TRANSNOX_CPASS CASCADE;
DROP USER SNOXPASS_GWAY_011 CASCADE;
DROP USER SNOXPASS_GWAY_012 CASCADE;
DROP USER SNOXPASS_SMSNOX_305 CASCADE;
DROP USER SNOXPASS_SMSNOX_306 CASCADE;
DROP USER SNOXPASS_TFE_2015 CASCADE;
DROP USER SNOXPASS_TFE_2016 CASCADE;
DROP USER TNOXPASS_GWAY_011 CASCADE;
DROP USER TNOXPASS_GWAY_012 CASCADE;
DROP USER TNOXPASS_SMSNOX_305 CASCADE;
DROP USER TNOXPASS_SMSNOX_306 CASCADE;
DROP USER TNOXPASS_TFE_2015 CASCADE;
DROP USER TNOXPASS_TFE_2016 CASCADE;



expdp rchaudhari directory=bkup dumpfile=exp_DCW1_sync_27Mar2014.dmp logfile=exp_DCW1_sync_27Mar2014.log flashback_scn= exclude=statistics,TABLE:" like 'SN_TEMP%'",TABLE:" like 'SC_TEMP%'" schemas=TRANSNOX_CAT,TRANSNOX_CPASS,SNOX4TRANSNOX_CPASS,SNOXPASS_GWAY_011,SNOXPASS_GWAY_012,SNOXPASS_SMSNOX_305,SNOXPASS_SMSNOX_306,SNOXPASS_TFE_2015,SNOXPASS_TFE_2016,TNOXPASS_GWAY_011,TNOXPASS_GWAY_012,TNOXPASS_SMSNOX_305,TNOXPASS_SMSNOX_306,TNOXPASS_TFE_2015,TNOXPASS_TFE_2016 compression=Y 


impdp rchaudhari directory=bkup dumpfile=exp_DCW1_sync_27Mar2014_2.dmp logfile=impdp_exp_DCW1_sync_27Mar2014_2.log




('TRANSNOX_CAT','TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','SNOXPASS_GWAY_011','SNOXPASS_GWAY_012','SNOXPASS_SMSNOX_305','SNOXPASS_SMSNOX_306','SNOXPASS_TFE_2015','SNOXPASS_TFE_2016','TNOXPASS_GWAY_011','TNOXPASS_GWAY_012','TNOXPASS_SMSNOX_305','TNOXPASS_SMSNOX_306','TNOXPASS_TFE_2015','TNOXPASS_TFE_2016')






Dhiraj Bhosale: key 			5-09640-15125-27442-05305
site messgae 					INFONOX-106-468-537  



Key : DR4GSL7F01MZA0YP380NV4G1A6H2G8VGGJVXN-111-414-023-3D
Site message : TOTAL SYSTEM SERVICES INC 





DECLARE
    v_Error_Flag                    NUMBER :=0; -- initialize variable as 0 
    v_UPD_Sql_Query                 VARCHAR2(32000) := NULL; -- initialize variable as empty
    
    v_UPD_Sql_Query_Display         VARCHAR2(32000) := NULL; -- initialize variable as empty
BEGIN 

    FOR i IN (SELECT SCHEMA_NAME, TABLE_NAME, SEARCH_COL_NAME1, SEARCH_COL_VALUE1, SEARCH_COL_NAME2, SEARCH_COL_VALUE2, UPD_COL_NAME, DCW_VALUES, DCE_VALUES
              FROM TRANSITHA.APP_SERVER_PARAMETERS)
    LOOP
        v_Error_Flag :=1;
--      direct updating tables
        IF i.SEARCH_COL_VALUE1 = '###' THEN 
            EXECUTE IMMEDIATE 'SELECT UNIQUE ' || i.UPD_COL_NAME || 
                              '  FROM ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME ||  
                              ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.DCE_VALUES ||'''' 
                         INTO v_UPD_Sql_Query;   
                                                
        END IF;    
    
--        v_Error_Flag :=2;
----      Tables which are having extra AND condition in search criteria        
--        IF i.SEARCH_COL_VALUE1 <> '###' AND i.SEARCH_COL_NAME2 IS NOT NULL THEN
--            v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
--                               '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
--                               ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.SEARCH_COL_VALUE1 ||'''' || CHR(13) ||
--                               '   AND ' || i.SEARCH_COL_NAME2 || ' = ''' || i.SEARCH_COL_VALUE2 ||'''' || CHR(13) ;
--        END IF;
--
--        v_Error_Flag :=3;
----      Tables which are not having AND condition in search criteria        
--        IF i.SEARCH_COL_VALUE1 <> '###' AND i.SEARCH_COL_NAME2 IS NOT NULL THEN
--            v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
--                               '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
--                               ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.SEARCH_COL_VALUE1 ||'''' || CHR(13) ;
--        END IF;

        v_Error_Flag :=4;        
        v_UPD_Sql_Query_Display:= v_UPD_Sql_Query;
        DBMS_OUTPUT.PUT_LINE( v_UPD_Sql_Query_Display );
--      EXECUTE IMMEDIATE v_UPD_Sql_Query_Display ;

        v_UPD_Sql_Query := NULL;
        COMMIT;
    END LOOP;
END;
/    