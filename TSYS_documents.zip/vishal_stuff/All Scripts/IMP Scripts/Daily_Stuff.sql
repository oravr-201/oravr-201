<Auth>
<deviceID>32434398980001</deviceID>
<transactionKey>DF3CTH5G7V0BAOXNS69VR4INO1SRR8M2</transactionKey>
<cardDataSource>MANUAL</cardDataSource>
<transactionAmount>901</transactionAmount>
<tip>222</tip>
<currencyCode>USD</currencyCode>
<cardNumber>4111111111111111</cardNumber>
<expirationDate>1220</expirationDate>
<cvv2>999</cvv2>
<developerID>123456</developerID>
</Auth>



TRANSIT_FE_SNOX_3113
TRANSIT_FE_TNOX_3113
TRANSIT_GATEWAY_SNOX_3113
TRANSIT_GATEWAY_TNOX_3113
TRANSIT_SMSNOX_SNOX_3113
TRANSIT_SMSNOX_TNOX_3113




('TRANSIT_FE_SNOX_3113','TRANSIT_FE_TNOX_3113','TRANSIT_GATEWAY_SNOX_3113','TRANSIT_GATEWAY_TNOX_3113','TRANSIT_SMSNOX_SNOX_3113','TRANSIT_SMSNOX_TNOX_3113')



('TRANSIT_FE_SNOX_3112','TRANSIT_FE_TNOX_3112','TRANSIT_GATEWAY_SNOX_3112','TRANSIT_GATEWAY_TNOX_3112','TRANSIT_SMSNOX_SNOX_3112','TRANSIT_SMSNOX_TNOX_3112')



TRANSIT_FE_SNOX_3112,TRANSIT_FE_TNOX_3112,TRANSIT_GATEWAY_SNOX_3112,TRANSIT_GATEWAY_TNOX_3112,TRANSIT_SMSNOX_SNOX_3112,TRANSIT_SMSNOX_TNOX_3112

---------------------------------------------------------------------------------------------------------------------------------------------------------------



---------------------------------------------------------------------------------------------------------------------------------------------------------------
-- get the list of table name in below format

ALTER TABLE SNOX4TRANSNOX_CPASS.ACCESS_PROFILE_COMPANY_MAP ADD (
  CONSTRAINT PK_ACCESS_PROFILE_COMPANY_MAP
  PRIMARY KEY
  (ACCESS_PROFILE, COMPANY_ID)
  USING INDEX SNOX4TRANSNOX_CPASS.PK_ACCESS_PROFILE_COMPANY_MAP
  ENABLE VALIDATE);


ALTER TABLE SNOX4TRANSNOX_CPASS.ACCESS_PROFILE_COMPANY_MAP ADD (
  CONSTRAINT FK_ACCESS_PROFILE 
  FOREIGN KEY (ACCESS_PROFILE) 
  REFERENCES SNOX4TRANSNOX_CPASS.CC_ACCESS_PROFILE_MASTER (CODE)
  ENABLE VALIDATE);

ALTER TABLE SNOX4TRANSNOX_CPASS.ACCESS_PROFILE_COMPANY_MAP ADD (
  CONSTRAINT FK_COMPANY_ID_ACCESS_PROFILE 
  FOREIGN KEY (COMPANY_ID) 
  REFERENCES SNOX4TRANSNOX_CPASS.COMPANY_MASTER (CODE)
  ENABLE VALIDATE);
  
  
  owner					 TABLE_NAME					 PK_COLUMN_NAME		REFERENCE_OWNER 	 REFERENCE_TABLE_NAME    REFERENCE_COLUMN_NAME
  -----------------------------------------------------------------------------------------------------------------------------------------------
  SNOX4TRANSNOX_CPASS	ACCESS_PROFILE_COMPANY_MAP	 COMPANY_ID			SNOX4TRANSNOX_CPASS   COMPANY_MASTER		 CODE


---------------------------------------------------------------------------------------------------------------------------------------------------------------  

DECLARE
  EXPORT_VBS_JOB NUMBER;
  JOB_status VARCHAR2(32000);
BEGIN
  EXPORT_VBS_JOB := DBMS_DATAPUMP.OPEN (OPERATION => 'EXPORT', JOB_MODE => 'SCHEMA', VERSION => 'LATEST', COMPRESSION => 1);
  DBMS_DATAPUMP.ADD_FILE (HANDLE => EXPORT_VBS_JOB, FILENAME => 'expdp_vbs_3113.dmp', DIRECTORY => 'DBRELEASE_VBS', REUSEFILE => 1);
  DBMS_DATAPUMP.ADD_FILE(HANDLE => EXPORT_VBS_JOB, FILENAME => 'expdp_log_vbs_3113.log', DIRECTORY => 'DBRELEASE_VBS', FILETYPE => DBMS_DATAPUMP.KU$_FILE_TYPE_LOG_FILE);
  DBMS_DATAPUMP.METADATA_FILTER (EXPORT_VBS_JOB, 'SCHEMA_EXPR', 'IN (''TRANSIT_FE_SNOX_3112'',''TRANSIT_FE_TNOX_3112'')'); -- ,''TRANSIT_GATEWAY_SNOX_3112'',''TRANSIT_GATEWAY_TNOX_3112'',''TRANSIT_SMSNOX_SNOX_3112'',''TRANSIT_SMSNOX_TNOX_3112''
--  DBMS_DATAPUMP.METADATA_FILTER (EXPORT_VBS_JOB, NAME=>'NAME_EXPR', VALUE=>'NOT IN (SELECT listagg('''' || TABLE_NAME || '''',',') WITHIN GROUP (ORDER BY table_name) FROM DBA_TABLES  WHERE OWNER IN (''TRANSIT_FE_SNOX_3112'',''TRANSIT_FE_TNOX_3112'',''TRANSIT_GATEWAY_SNOX_3112'', ''TRANSIT_GATEWAY_TNOX_3112'',''TRANSIT_SMSNOX_SNOX_3112'',''TRANSIT_SMSNOX_TNOX_3112'') AND REGEXP_LIKE(TABLE_NAME,''s._temp[[:digit:]]'',''i''))';

   DBMS_DATAPUMP.START_JOB (EXPORT_VBS_JOB);
   DBMS_DATAPUMP.WAIT_FOR_JOB (EXPORT_VBS_JOB, JOB_status);
   DBMS_DATAPUMP.DETACH (handle => EXPORT_VBS_JOB);
END;
/


DECLARE
  EXPORT_VBS_JOB NUMBER;
  JOB_status VARCHAR2(32000);
BEGIN
    EXPORT_VBS_JOB := DBMS_DATAPUMP.OPEN (OPERATION => 'IMPORT', JOB_MODE => 'SCHEMA', VERSION => 'LATEST', COMPRESSION => 1);
    DBMS_DATAPUMP.ADD_FILE (HANDLE => EXPORT_VBS_JOB, FILENAME => 'expdp_vbs_3113.dmp', DIRECTORY => 'DBRELEASE_VBS', REUSEFILE => 1);
    DBMS_DATAPUMP.ADD_FILE(HANDLE => EXPORT_VBS_JOB, FILENAME => 'impdp_expdp_log_vbs_3113.log', DIRECTORY => 'DBRELEASE_VBS', FILETYPE => DBMS_DATAPUMP.KU$_FILE_TYPE_LOG_FILE);

    DBMS_DATAPUMP.metadata_remap (HANDLE => EXPORT_VBS_JOB, NAME => 'REMAP_SCHEMA', OLD_VALUE => 'TRANSIT_FE_SNOX_3112', VALUE=> 'TRANSIT_FE_SNOX_0003');
    DBMS_DATAPUMP.metadata_remap (HANDLE => EXPORT_VBS_JOB, NAME => 'REMAP_SCHEMA', OLD_VALUE => 'TRANSIT_FE_TNOX_3112', VALUE=> 'TRANSIT_FE_TNOX_0003');

    DBMS_DATAPUMP.START_JOB (EXPORT_VBS_JOB);
    DBMS_DATAPUMP.WAIT_FOR_JOB (EXPORT_VBS_JOB, JOB_status);
    DBMS_DATAPUMP.DETACH (HANDLE => EXPORT_VBS_JOB);
END;
/

CREATE OR REPLACE TYPE TRANSIT_GATEWAY_TNOX_3113."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_TNOX_3113."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_SNOX_3113."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_SNOX_3113."VARCHAR_LIST"  AS TABLE OF VARCHAR2(4000);

DECLARE 
    v_Create_Privs_Script   VARCHAR2(32000);
    v_Create_Synonym_Script VARCHAR2(32000);
--    v_counter   NUMBER:=0;
BEGIN 
    FOR i IN (SELECT 'GRANT ' || WM_CONCAT(PRIVILEGE) || ' on ' || OWNER || '.' || table_name || ' to ' || DECODE(GRANTEE,
                                                                                                                         'TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_TNOX_3113',
                                                                                                                         'TRANSIT_GATEWAY_SNOX_3112','TRANSIT_GATEWAY_SNOX_3113',
                                                                                                                         'TRANSIT_SMSNOX_TNOX_3112','TRANSIT_SMSNOX_TNOX_3113',
                                                                                                                         'TRANSIT_SMSNOX_SNOX_3112','TRANSIT_SMSNOX_SNOX_3113',
                                                                                                                         'TRANSIT_FE_SNOX_3112','TRANSIT_FE_SNOX_3113',
                                                                                                                         'TRANSIT_FE_TNOX_3112','TRANSIT_FE_TNOX_3113') Grant_Privs
             FROM DBA_TAB_PRIVS 
            WHERE GRANTEE IN ('TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_SNOX_3112',
                               'TRANSIT_FE_SNOX_3112','TRANSIT_FE_TNOX_3112',
                               'TRANSIT_SMSNOX_TNOX_3112','TRANSIT_SMSNOX_SNOX_3112')
              AND owner <>'TRANSNOX_CAT'
            GROUP BY GRANTOR, TABLE_NAME, OWNER, GRANTEE
            ORDER BY owner, table_name ASC)
    LOOP
        v_Create_Privs_Script:= i.Grant_Privs;-- ||';';
        
--        IF SQL%ROWCOUNT = 10 THEN
--            dbms_output.put_line('# of rows selected: '|| SQL%ROWCOUNT);
--        END IF;
        
        dbms_output.put_line(v_Create_Privs_Script);
        
        EXECUTE IMMEDIATE v_Create_Privs_Script;    
    
    END LOOP;

    FOR i IN (SELECT 'CREATE OR REPLACE SYNONYM '||DECODE(OWNER,
                                                               'TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_TNOX_3113',
                                                               'TRANSIT_GATEWAY_SNOX_3112','TRANSIT_GATEWAY_SNOX_3113',
                                                               'TRANSIT_SMSNOX_TNOX_3112','TRANSIT_SMSNOX_TNOX_3113',
                                                               'TRANSIT_SMSNOX_SNOX_3112','TRANSIT_SMSNOX_SNOX_3113',
                                                               'TRANSIT_FE_SNOX_3112','TRANSIT_FE_SNOX_3113',
                                                               'TRANSIT_FE_TNOX_3112','TRANSIT_FE_TNOX_3113') ||'.'||SYNONYM_NAME||' FOR '||TABLE_OWNER||'.'||TABLE_NAME  create_synonyms
              FROM dba_synonyms
              WHERE owner IN  ('TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_SNOX_3112',
                               'TRANSIT_FE_SNOX_3112','TRANSIT_FE_TNOX_3112',
                               'TRANSIT_SMSNOX_TNOX_3112','TRANSIT_SMSNOX_SNOX_3112')
                AND NOT REGEXP_LIKE(synonym_name,'\/')
              ORDER BY table_owner, table_name ASC)
    LOOP
        v_Create_Synonym_Script:= i.create_synonyms;

        dbms_output.put_line(v_Create_Synonym_Script);
        
        EXECUTE IMMEDIATE v_Create_Synonym_Script;
        
    END LOOP;
    
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_TNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_SNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_TNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_SNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_FE_TNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_FE_SNOX_3113');    
    
    COMMIT;
    
EXCEPTION 
    WHEN OTHERS THEN
        dbms_output.put_line(SUBSTR(SQLERRM,1,100));
END;
/
----------------------------------------------------------------------------------------------------------------------------------



10.150.50.121 wpl1gcaxdbs01.tsysacquiring.org 	DCW GCA Reporting DB
10.150.50.122 wpl1gcaxdbs02.tsysacquiring.org 	DCW TNOX GCA DB
10.150.4.123  wpl1gcaxdbs03.tsysacquiring.org 	DCW TransGCA Transending GCA DB
10.150.50.128 wpl1gcaxdbs04.tsysacquiring.org 	DCW QCPWDB
-- 10.150.4.129  wpl1tsnddbs01.tsysacquiring.org   DCW Transending DB  
 

10.50.4.121 ga-snox4transnoxdb.ifxga.com       DCE Reporting GCA
10.50.4.122 ga-tnoxdbgca.ifxga.com			   DCE Tnox GCA	
10.50.4.123 epl1gcaxdbs03.tsysacquiring.org	   DCE TransGCA Transending GCA DB
10.50.4.125 ga-qcpwdb.ifxga.com				   DCE QCPW DB

10.50.4.135 epl1tsnddbs01.tsysacquiring.org	   DCE Data Guard of TSND Transending DB
10.50.4.126	ga-transendingdb.ifxga.com		   Was a StandBy of Transending CapitalOne, Sigue, Moneris


-- 
1) lookups
2) merchant+device+product
3) transaction+customer+settlement
4) non-key tables -- without cdr
5) rest-tables 


Hi,

We have discussed the below categories with Database Team here,
1) lookup
2) merchant+device+product
3) transaction+customer+settlement
4) non-key tables -- without cdr
5) rest-tables 

We found that out main purpose of replication lagging will not be solved as transactional module covers sub modules like Recurring Engine, File 
Processing which includes most of the tables causing lagging today (Infonox Service Usage, Request Audit Trail etc.) considering table 
usage and foreign relationship and considering loggical relationship (which do not have foregin key). Also if future product development requires 
some more foreign keys to be introduced which is not there today lead us to every time revisit these categories before every release.

1) Transaction Module (above category 2 and 3)
	a) Transaction Processing
	b) Recurring Eng
	c) File Processing
	d) Settlement 
	e) Configuration
2) Lookup Tables
3) Rest Tables (Which are not coming in any Modules like Infonox_Service_Usgae, Event, Supportnox related tables etc ...)

Hence after considering above limitations, we came up with the solution that we will have some stats information related to lagging happening 
today like tables causing lagging, lagging frequency, lagging time etc. Using this information we can have table priorities based on frequency of 
occurance and lagging time. We will target those top priority tables first and do analysis and development for them if not done before.

Let us know your views on the same.




Thank You for your request.

Your reference number is SFA273454315.

Our executive will contact you shortly.
For status, please call our 24 hour Customer Care.


058101517964		9401157398788806	2367	Redeem Now
5241931114211000	9401162185152000	3090	Redeem Now
 	Total Accumulated Points:	5457	 
My Savings Rewards:img



LINK 9212146468 




1) re-org indexes
2) and then do the parging 





1) stop seque
2) start replicator
3) 

cqID00064555

-- 2007	50267 --
-- 2008	100735 --
-- 2009	93993 --
-- 2010	146886 --
-- 2011	143344 --
-- 2012	150519 --
-- 2013	134382 
-- 2014	156221 
-- 2015	117493
2016	6852







I will clean this up shortly. Till then please ignore the alerts

-- to delete the dump files
find *.xml -type f -mtime +1 -exec rm -f {} \;

cat ggserr.log | grep "`date +%Y-%m-%d`" | grep "ORA-"

http://blog.mclaughlinsoftware.com/2014/04/13/using-utl_file/
http://stackoverflow.com/questions/13724160/oracle-utl-file-multiple-rows-in-excel-for-a-single-cell

tsysproxy1.tsys.com 4438
tsysproxy1.tsyseurope.com 80
---------------------------------------------------------------------------------------------------------------------------------------------
-- Start of Work 12/May/2015
-- End of Work 12/May/2015
---------------------------------------------------------------------------------------------------------------------------------------------


-- even and odd scripts
  SELECT sequence_owner,
         sequence_name,
         increment_by,
         cache_size,
         last_number,
         DECODE(MOD (last_number, 2),0,'Even',1,'Odd') Even_Or_Odd,
         CASE
            WHEN MOD (last_number, 2) = 1 THEN last_number + 10001
            WHEN MOD (last_number, 2) = 0 THEN last_number + 10000
            ELSE last_number
         END
            final_even_or_odd_no,
         CASE
            WHEN MOD (last_number, 2) = 1 THEN 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 5001 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' || chr(10) 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;'
            WHEN MOD (last_number, 2) = 0 THEN 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 5000 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' || chr(10) 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;'
            ELSE TO_CHAR (last_number)
         END first_even_time_increment,
         CASE
            WHEN MOD (last_number, 2) = 1 THEN 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 5000 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' || chr(10) 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;'
            WHEN MOD (last_number, 2) = 0 THEN 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 5001 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' || chr(10) 'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;'
            ELSE TO_CHAR (last_number)
         END first_odd_time_increment,
            'alter sequence ' || sequence_owner || '.' || sequence_name || ' increment by 2 ;' || CHR (10) || 'select ' || sequence_owner || '.' || sequence_name || '.nextval from dual;' final_even_run
    FROM dba_sequences
   WHERE sequence_owner IN  ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS', 'WEBFORT','KEYNOX_FX')
   AND MOD (last_number, 2) =0
ORDER BY sequence_owner ASC

---------------------------------------------------------------------------------------------------------------------------------------------

TRANSIT_FE_SNOX_3112,
TRANSIT_GATEWAY_TNOX_3112,
TRANSIT_SMSNOX_TNOX_3112,
TRANSIT_FE_TNOX_3112,
TRANSIT_GATEWAY_SNOX_3112,
TRANSIT_SMSNOX_SNOX_3112,
TRANSIT_SMSNOX_SNOX_3111,
TRANSIT_FE_SNOX_3111,
TRANSIT_FE_TNOX_3111,
TRANSIT_SMSNOX_TNOX_3111,
TRANSIT_GATEWAY_SNOX_3111,
TRANSIT_GATEWAY_TNOX_3111,


exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_TNOX_3112');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_SNOX_3112');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_TNOX_3112');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_SNOX_3112');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_FE_TNOX_3112');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_FE_SNOX_3112');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_TNOX_3111');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_SNOX_3111');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_TNOX_3111');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_SNOX_3111');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_FE_TNOX_3111');
exec DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_FE_SNOX_3111');

---------------------------------------------------------------------------------------------------------------------------------------------
-- 01/06/2016

TRANSIT_SMSNOX_SNOX_3111,TRANSIT_SMSNOX_TNOX_3111,TRANSIT_FE_TNOX_3111,TRANSIT_FE_SNOX_3111,TRANSIT_GATEWAY_SNOX_3111,TRANSIT_GATEWAY_TNOX_3111

expdp / directory=BACKUP dumpfile=expdp_vbs_20160106.dmp logfile=expdp_vbs_20160106.log schemas=TRANSIT_SMSNOX_SNOX_3111,TRANSIT_SMSNOX_TNOX_3111,TRANSIT_FE_TNOX_3111,TRANSIT_FE_SNOX_3111,TRANSIT_GATEWAY_SNOX_3111,TRANSIT_GATEWAY_TNOX_3111 exclude=statistics,table:\" like \'SC_TEMP%\'\",table:\" like \'SN_TEMP%\'\"

impdp / directory=BKUPS dumpfile=expdp_vbs_20160106.dmp logfile=impdp_expdp_vbs_20160106.log remap_schema=TRANSIT_SMSNOX_SNOX_3111:TRANSIT_SMSNOX_SNOX_3112 remap_schema=TRANSIT_SMSNOX_TNOX_3111:TRANSIT_SMSNOX_TNOX_3112 remap_schema=TRANSIT_FE_TNOX_3111:TRANSIT_FE_TNOX_3112 remap_schema=TRANSIT_FE_SNOX_3111:TRANSIT_FE_SNOX_3112 remap_schema=TRANSIT_GATEWAY_SNOX_3111:TRANSIT_GATEWAY_SNOX_3112 remap_schema=TRANSIT_GATEWAY_TNOX_3111:TRANSIT_GATEWAY_TNOX_3112

TRANSIT_SMSNOX_SNOX_3112
TRANSIT_SMSNOX_TNOX_3112
TRANSIT_FE_TNOX_3112
TRANSIT_FE_SNOX_3112
TRANSIT_GATEWAY_SNOX_3112
TRANSIT_GATEWAY_TNOX_3112


CREATE OR REPLACE TYPE TRANSIT_GATEWAY_TNOX_3112."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_TNOX_3112."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_SNOX_3112."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_SNOX_3112."VARCHAR_LIST"  AS TABLE OF VARCHAR2(4000);

GRANT CREATE ANY TABLE TO TRANSIT_GATEWAY_SNOX_3112;
GRANT CREATE ANY TABLE TO TRANSIT_GATEWAY_TNOX_3112;
GRANT CREATE ANY TABLE TO TRANSIT_SMSNOX_SNOX_3112;
GRANT CREATE ANY TABLE TO TRANSIT_SMSNOX_TNOX_3112;
GRANT CREATE ANY TABLE TO TRANSIT_FE_SNOX_3112 ;
GRANT CREATE ANY TABLE TO TRANSIT_FE_TNOX_3112;


alter user TRANSIT_SMSNOX_SNOX_3112 default tablespace ALL_TEMP_TABLES;
alter user TRANSIT_SMSNOX_TNOX_3112 default tablespace ALL_TEMP_TABLES;
alter user TRANSIT_FE_TNOX_3112 default tablespace ALL_TEMP_TABLES;
alter user TRANSIT_FE_SNOX_3112 default tablespace ALL_TEMP_TABLES;
alter user TRANSIT_GATEWAY_SNOX_3112 default tablespace ALL_TEMP_TABLES;
alter user TRANSIT_GATEWAY_TNOX_3112 default tablespace ALL_TEMP_TABLES;




'TRANSIT_SMSNOX_SNOX_3112','TRANSIT_SMSNOX_TNOX_3112','TRANSIT_FE_TNOX_3112','TRANSIT_FE_SNOX_3112','TRANSIT_GATEWAY_SNOX_3112','TRANSIT_GATEWAY_TNOX_3112'


SELECT COUNT(DISTINCT session_id)
FROM v$active_session_history
WHERE SAMPLE_TIME BETWEEN TO_DATE('01/03/2016 18:00:00','mm/dd/yyyy hh24:mi:ss')
                      AND TO_DATE('01/03/2016 21:00:00','mm/dd/yyyy hh24:mi:ss')

SELECT TO_DATE(11249198005/1000/60/60/24, 'hh24:mi:ss' ) AS HMS FROM dual;


SELECT
  h.event "Wait Event",
  SUM(h.wait_time + h.time_waited) "Total Wait Time"
FROM
  v$active_session_history h,
  v$event_name E
WHERE
      h.sample_time BETWEEN TO_DATE('01/03/2016 18:00:00','mm/dd/yyyy hh24:mi:ss')
                      AND TO_DATE('01/03/2016 21:00:00','mm/dd/yyyy hh24:mi:ss')
  AND h.event_id = E.event_id
  AND E.wait_class <> 'Idle'
GROUP BY h.event
ORDER BY 2 DESC

SELECT username, COUNT(*)
FROM (
SELECT sample_time, session_id, session_type,sql_id, sql_opname, wait_time, time_waited,session_state,blocking_session_status,machine,du.username username
FROM v$active_session_history ash, dba_users du
WHERE ash.user_id = du.user_id
  AND sample_time BETWEEN TO_DATE('01/03/2016 18:00:00','mm/dd/yyyy hh24:mi:ss')
                      AND TO_DATE('01/03/2016 21:00:00','mm/dd/yyyy hh24:mi:ss')
)
GROUP BY username
ORDER BY 2 DESC

                      
SELECT *
FROM dba_users WHERE user_id=400                      




SELECT * FROM snox4transnox.dynamic_daemon_rulesets
---------------------------------------------------------------------------------------------------------------------------------------------



GC buffer busy means that the buffer in the buffer cache, that the session is trying to access is already involved in another 
ongoing global cache operation. Until that global cache operation completes, session must wait.

example: Let�s say that session #1 is trying to access a block of file #7 block ID 420. That block is in the remote cache and so, 
		 session #1 opened a BL lock on that block, requested the remote LMS process to send the block, and waiting for the block 
		 shipping to complete. Session #2 comes along shortly thereafter and tries to access the same buffer. But, the block is 
		 already involved in a global cache operation and so, session #2 must wait for the session #1 to complete GC 
		 (Global Cache) activity before proceeding. In this case, Session #2 will wait for �gc buffer busy� wait event 
		 with a time-out and repeatedly tries to access that buffer in a loop.





select inst_id,  session_id, sql_id,event, count(*) CNT 
  from gv$active_session_history
    where user_id = ( select USER_ID from dba_users where USERNAME = 'TRANSIT_GATEWAY_TNOX_3110' ) and sql_id is  not null
      and sample_time between to_date('12/16/2015 13:33:00','mm/dd/yyyy hh24:mi:ss') and to_date('12/16/2015 13:35:00','mm/dd/yyyy hh24:mi:ss')
   group by inst_id,  session_id,sql_id, event having count(*) > &wait_threshold 
   order by inst_id,  session_id, sql_id, CNT;
   
   
with ash_gc as 
(select * from (
select /*+ materialize */ inst_id, event, current_obj#, count(*) cnt 
from gv$active_session_history where event=lower('&event')
group by inst_id,event, current_obj# having count(*) > &obj_cnt 
))
select * from (
select inst_id,owner, object_name,object_type, cnt 
from ash_gc a, dba_objects o
where (a.current_obj#=o.data_object_id or a.current_obj#=o.object_id)
and a.current_obj#>=1
union 
select inst_id, '','','Undo Header/Undo block' , cnt 
from ash_gc a
where a.current_obj#=0
union
select inst_id, '','','Undo Block' , cnt 
from ash_gc a
where a.current_obj#=-1
) order by 5
/   

16311
16312


Parameter	Value
SQL_ID	6mtbknc8a6x59
6mtbknc8a6x59








SQL_ID 6mtbknc8a6x59
--------------------
INSERT INTO TASK (TASK_ID, TASK_TYPE, TASK_STATE, CUSTOMER_CODE, 
SERVICE_CODE, TIME_STAMP, LANGUAGE, SERVER_IP) VALUES (:B7 , :B6 , :B5 
, :B4 , :B3 , SYSDATE, :B2 , :B1 )
 
 
-------------------------------------------------
| Id  | Operation                | Name | Cost  |
-------------------------------------------------
|   0 | INSERT STATEMENT         |      |     1 |
|   1 |  LOAD TABLE CONVENTIONAL |      |       |
-------------------------------------------------
 
Note
-----
   - cpu costing is off (consider enabling it)
 
 
 
 
 
SQL_ID 3ba3vgb3y5g45
--------------------
UPDATE TRANSACTION SET TRANS_STATUS = DECODE (:B16 , 'Y', TRANS_STATUS, 
:B12 ), AMOUNT = DECODE (:B12 , 'VOID', AMOUNT, :B15 ), REASON_CODE = 
(CASE WHEN :B12 = 'VOID' THEN CASE WHEN :B14 = 'Y' AND REASON_CODE IS 
NULL THEN '0000' ELSE DECODE ( REASON_CODE, NULL, DECODE (:B13 , NULL, 
'0000', :B13 ), REASON_CODE) END WHEN REASON_CODE = '0002' THEN 
REASON_CODE ELSE :B13 END), FEE_CHARGED = DECODE (:B12 , 'VOID', 
FEE_CHARGED, :B11 ), REFERENCE_NUMBER = DECODE (REFERENCE_NUMBER, '', 
:B10 , REFERENCE_NUMBER), USER_ID = NVL (:B9 , USER_ID), 
LAST_MODIFIED_TIME_STAMP = SYSTIMESTAMP, SEQUENCE_NUMBER = DECODE 
(SEQUENCE_NUMBER, '', :B8 , SEQUENCE_NUMBER), TRANS_TYPE = (CASE WHEN 
:B7 = 'MODIFY' AND :B6 IS NOT NULL THEN :B4 WHEN :B5 = 'PRE_AUTH' THEN 
:B4 ELSE TRANS_TYPE END), TIME_STAMP = NVL (:B3 , TIME_STAMP), 
CLIENT_TIMESTAMP = NVL (:B2 , CLIENT_TIMESTAMP) WHERE TRANSACTION_ID = 
:B1
 
Plan hash value: 3811273888
 
-----------------------------------------------------------------------------------------------
| Id  | Operation                    | Name           | Rows  | Bytes | Cost (%CPU)| Time     |
-----------------------------------------------------------------------------------------------
|   0 | UPDATE STATEMENT             |                |       |       |     4 (100)|          |
|   1 |  UPDATE                      | TRANSACTION    |       |       |            |          |
|   2 |   TABLE ACCESS BY INDEX ROWID| TRANSACTION    |     1 |   117 |     4   (0)| 00:00:01 |
|   3 |    INDEX UNIQUE SCAN         | PK_TRANSACTION |     1 |       |     3   (0)| 00:00:01 |
-----------------------------------------------------------------------------------------------
  



SELECT INSTANCE_NAME,
       SETTLE_DATE_1 SETTLE_DATE,
       THREAD_ID,
       BATCH_SELECTED_DATE,
       CNT THREAD_PROCESSED_BATCH_COUNT,
       THREAD_STATUS
  FROM (  SELECT INSTANCE_NAME,
                 SSB.SETTLE_DATE SETTLE_DATE_1,
                 THREAD_ID,
                 MAX (BATCH_SELECTED_DATE) BATCH_SELECTED_DATE,
                 COUNT (1) CNT,
                 (CASE
                     WHEN BATCH_SELECTED_DATE <= SYSDATE - 1 / 1440
                     THEN
                        'INACTIVE'
                     ELSE
                        'ACTIVE'
                  END)
                    THREAD_STATUS
            FROM TRANSNOX_IOX.HARMONY_BATCH_SELECTION_INFO HBSI,
                 TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH SSB
           WHERE     HBSI.BATCH_SEQ_ID = SSB.BATCH_SEQ_ID
                 AND SSB.SETTLE_DATE > SYSDATE - 59 / 1440
        GROUP BY INSTANCE_NAME,
                 SETTLE_DATE,
                 THREAD_ID,
                 (CASE
                     WHEN BATCH_SELECTED_DATE <= SYSDATE - 1 / 1440
                     THEN
                        'INACTIVE'
                     ELSE
                        'ACTIVE'
                  END)) A,
       (  SELECT 'TOTAL_BATCHES_PENDING' Job_Running,
                 SETTLE_DATE,
                 COUNT (1) PENDING_BATCH_COUNT
            FROM TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH
           WHERE     SETTLE_DATE > SYSDATE - 59 / 1440
                 AND BATCH_STATUS = 'INPROCESS'
        GROUP BY SETTLE_DATE) B
 WHERE     A.SETTLE_DATE_1 = B.SETTLE_DATE(+)
       AND PENDING_BATCH_COUNT > 0
       AND THREAD_STATUS = 'INACTIVE';
       
       
       
       
---------------------------------------------------------------------------------------------------------------------------------------------
ALTER SESSION SET CURRENT_SCHEMA=TRANSNOX_IOX;


ALTER SEQUENCE REPORT_USAGE_SEQ INCREMENT BY 5844938;
SELECT TRANSNOX_IOX.REPORT_USAGE_SEQ.NEXTVAL FROM DUAL;

ALTER SEQUENCE REPORT_USAGE_SEQ INCREMENT BY 4;
SELECT TRANSNOX_IOX.REPORT_USAGE_SEQ.NEXTVAL FROM DUAL;



-- Settlement check query.
SELECT thread_id,COUNT(1),MAX(batch_selected_date) FROM TRANSIT_SMSNOX_TNOX_3110.HARMONY_BATCH_SELECTION_INFO WHERE batch_seq_id IN
(SELECT DISTINCT batch_seq_id FROM transnox_iox.snox_settlement_batch WHERE settle_date = TO_DATE('11/19/2015 21:45:00','MM/DD/YYYY HH24:MI:SS'))
GROUP BY thread_id;

------------------------------------------------------------------------------------------

Due to GoldenGate bug issues of not replicating newly added columns on the oracle tables.

08, AUG 2015 we add columns Date_Cretaed in trans_details and trans_responce_info table.
As we have to have to create partition on Date_Created column on RE DB, have to convert this column as to populate with sysdate (which was done from TW itself)

After populating Date_Created column with matching Transaction table Time_Stamp, then we have created partition on trans_detail and trans_responce_info tables based on date_created column.

From 08-13-2015 04:26 PST till 08-15-2015 03:59 PST data got mismatched, due to goldengate related issues (unknown issues). as it was populating default sysdate in both tables, After 08-15-2015 04 
onwards the replication also started populating exact data from TW to RE for Date_Created column and hence there was no issues there after.

------------------------------------------------------------------------------------------

--REPORT_USAGE_AUDITTRAIL
--REQUEST_AUDIT_TRAIL
--TASK
--TRANSACTION
--TRANS_ADDITIONAL_INFO
--TRANS_BANK_DETAIL
--TRANS_CARD
-- TRANS_DETAIL
TRANS_RESPONSE_INFO
--TRANS_RETURN
--TRANS_SCORE
--TRANS_SETTLEMENT
--TRANS_VOID


TNOX_DATA_PARTI_1
TNOX_DATA_PARTI_2
TNOX_DATA_PARTI_3

TNOX_INDX_PARTI_1
TNOX_INDX_PARTI_2
TNOX_INDX_PARTI_3



--create table rchaudhari.TRANS_SETTLE_MISS_0511 as
select transaction_id,settlement_status
from transnox_iox.trans_settlement 
where timestamp between to_date('09/01/2015 00:00:00','MM/DD/YYYY HH24:MI:SS') and to_date('09/30/2015 23:59:59','MM/DD/YYYY HH24:MI:SS')
minus
select transaction_id,settlement_status
from transnox_iox.trans_settlement@te_cpass 
where timestamp between to_date('09/01/2015 00:00:00','MM/DD/YYYY HH24:MI:SS') and to_date('09/30/2015 23:59:59','MM/DD/YYYY HH24:MI:SS') ;

create table rchaudhari.TRANS_SETTLEMENT_05NOV2015_1
select TRANSACTION_ID, SETTLEMENT_STATUS, BATCH_SEQ_ID, SETTLEMENT_TYPE, AMOUNT, BATCH_NUMBER, EFFECTIVE_DATE, DEVICE_ID
from transnox_iox.trans_settlement@te_cpass 
where timestamp between to_date('08/29/2015 00:00:00','MM/DD/YYYY HH24:MI:SS') and to_date('11/07/2015 23:59:59','MM/DD/YYYY HH24:MI:SS') ; 




---------------------------------------------------------------------------------------------------------------------------------
-- Trans_Settlement issue 05Nov2015
DECLARE
    CURSOR Cur_transaction
    IS
       SELECT ts.Transaction_id,its.SETTLEMENT_STATUS, its.BATCH_SEQ_ID, its.SETTLEMENT_TYPE, its.AMOUNT, its.BATCH_NUMBER, its.EFFECTIVE_DATE, its.DEVICE_ID
		FROM rchaudhari.trans_settle_miss_0511 ts, rchaudhari.trans_settlement_05nov2015_1 its
		WHERE ts.transaction_id = ITS.TRANSACTION_ID
		   and its.SETTLEMENT_STATUS='SUCCESS';
 
    TYPE Cur_transaction_array IS TABLE OF Cur_transaction%ROWTYPE;
 
    Cur_transaction_fetch_array   Cur_transaction_array;
    V_numerrors                   NUMBER := 0;
    V_error_code                  NUMBER;
    V_error_msg                   VARCHAR2 (4000);
    V_error_idx                   NUMBER;
 BEGIN
    OPEN Cur_transaction;
 
    LOOP
       FETCH Cur_transaction
       BULK COLLECT INTO Cur_transaction_fetch_array
       LIMIT 2000;
 
       BEGIN
          FORALL I IN 1 .. Cur_transaction_fetch_array.COUNT SAVE EXCEPTIONS
             UPDATE TRANSNOX_IOX.TRANS_SETTLEMENT Ts1
                SET Ts1.SETTLEMENT_STATUS = Cur_transaction_fetch_array (I).SETTLEMENT_STATUS,
                    Ts1.BATCH_SEQ_ID = Cur_transaction_fetch_array (I).BATCH_SEQ_ID,
                    Ts1.SETTLEMENT_TYPE = Cur_transaction_fetch_array (I).SETTLEMENT_TYPE,
                    Ts1.AMOUNT = Cur_transaction_fetch_array (I).AMOUNT,
                    Ts1.BATCH_NUMBER = Cur_transaction_fetch_array (I).BATCH_NUMBER,
                    Ts1.EFFECTIVE_DATE = Cur_transaction_fetch_array (I).EFFECTIVE_DATE,
                    Ts1.DEVICE_ID = Cur_transaction_fetch_array (I).DEVICE_ID
              WHERE Ts1.Transaction_id =
                       Cur_transaction_fetch_array (I).Transaction_id
       EXCEPTION
          WHEN OTHERS THEN
             V_numerrors := SQL%BULK_EXCEPTIONS.COUNT;
 
             FOR V_count IN 1 .. V_numerrors
             LOOP
                V_error_code := SQL%BULK_EXCEPTIONS (V_count).ERROR_CODE;
                V_error_msg := SQLERRM (-V_error_code);
                V_error_idx := SQL%BULK_EXCEPTIONS (V_count).ERROR_INDEX;
                DBMS_OUTPUT.Put_line ( ' Error Code : ' || V_error_code || ' Error Message : ' || V_error_msg);
             END LOOP;
       END;
 
       COMMIT;
       EXIT WHEN Cur_transaction%NOTFOUND;
    END LOOP;
 
    CLOSE Cur_transaction;
 
    COMMIT;
 EXCEPTION
    WHEN OTHERS THEN
       DBMS_OUTPUT.Put_line ( ' Error Code : ' || SQLCODE || ' Error Message : ' || SUBSTR (SQLERRM, 1, 200));
 END;
/  

commit;
---------------------------------------------------------------------------------------------------------------------------------



-- Drop partition procedure
DECLARE
  l_sql_stmt VARCHAR2(1000);
  l_date     DATE;
BEGIN
  FOR x IN (SELECT * 
              FROM user_tab_partitions
             WHERE table_name = 'LOG')
  LOOP
    l_date := to_date( substr( x.partition_name, 5 ), 'YYYYMMDD' );
    IF( l_date < add_months( trunc(sysdate), -12 ) )
    THEN
      l_sql_stmt := 'ALTER TABLE log ' ||
                    ' DROP PARTITION ' || x.partition_name;
      dbms_output.put_line( l_sql_stmt );
      EXECUTE IMMEDIATE l_sql_stmt;
    END IF;
  END LOOP;
END;



BEGIN
   FOR cc IN (SELECT PARTITION_NAME, HIGH_VALUE
                FROM ALL_TAB_PARTITIONS
               WHERE TABLE_NAME = 'INFONOX_SERVICE_USAGE'
               	 AND TABLE_OWNER='SNOX4TRANSNOX_CPASS') LOOP
      EXECUTE IMMEDIATE
          'BEGIN
             IF sysdate >= ADD_MONTHS(' || cc.HIGH_VALUE || ', 2) THEN
                EXECUTE IMMEDIATE ''ALTER TABLE TEST_TABLE DROP PARTITION '|| cc.partition_name || ''';
             END IF;
          END;';
   END LOOP;
END;
/



create or replace function get_high_value_as_date(
  p_table_name     in varchar2,
  p_partition_name in varchar2
) return date as
  v_high_value varchar2(1024);
  v_date        date;
begin
  select high_value into v_high_value from user_tab_partitions
    where table_name = upper(p_table_name)
      and partition_name = upper(p_partition_name);
  execute immediate 'select ' || v_high_value || ' from dual' into v_date;
  return v_date;
end;


declare
  c_days_to_keep constant integer := 31;
  x_last_partition exception;
  pragma exception_init(x_last_partition, -14758);
begin
  for rec in (select table_name, partition_name
    from user_tab_partitions
      where table_name = 'TEST_TAB'
        and get_high_value_as_date(table_name, partition_name) <
        sysdate - c_days_to_keep) loop
    begin
      execute immediate 'alter table ' || rec.table_name || 
        ' drop partition ' || rec.partition_name;
    exception
      when x_last_partition then
        null;
    end;
  end loop;
end;

------------------------------------------------------------------------------------------

DROP VIEW RCHAUDHARI.TNOX_RP;

/* Formatted on 10/16/2015 1:43:03 AM (QP5 v5.256.13226.35538) */
CREATE OR REPLACE FORCE VIEW RCHAUDHARI.TNOX_RP
(
   PAYMENT_ID,
   SCHEDULE_ID,
   AMOUNT,
   PAYMENT_DATE,
   TRANSACTION_DATE,
   TRANSACTION_ID,
   TRANSACTION_RESPONSE_CODE,
   PAYMENT_STATUS,
   DATE_CREATED,
   DATE_MODIFIED,
   PAYMENT_NUMBER,
   FIN_ACCOUNT_ID,
   OPERATOR_ID,
   ORG_PAYMENT_DATE,
   TASK_ID,
   SALES_TAX,
   PAY_PROCESS_THREAD_ID
)
AS
   SELECT "PAYMENT_ID",
          "SCHEDULE_ID",
          "AMOUNT",
          "PAYMENT_DATE",
          "TRANSACTION_DATE",
          "TRANSACTION_ID",
          "TRANSACTION_RESPONSE_CODE",
          "PAYMENT_STATUS",
          "DATE_CREATED",
          "DATE_MODIFIED",
          "PAYMENT_NUMBER",
          "FIN_ACCOUNT_ID",
          "OPERATOR_ID",
          "ORG_PAYMENT_DATE",
          "TASK_ID",
          "SALES_TAX",
          "PAY_PROCESS_THREAD_ID"
     FROM TRANSNOX_IOX.RECURRING_PAYMENT
    WHERE transaction_id IN (51438741,
                             51439473,
                             51440399,
                             51438446,
                             51438771,
                             52055927,
                             52055265,
                             52055782,
                             52055769)        /* GOLDENGATE_DDL_REPLICATION */
;



-- 06Oct2015
-- UAT Migration schema list
KEYNOX_FX
WEBFORT
TRANSNOX_CPASS
SNOX4TRANSNOX_CPASS
TRANSTSYSPAYMENTGW
TRANSTSYSPAYMENTGWAPP
TRANSIT_FE_SNOX_3110
TRANSIT_FE_TNOX_3110
TRANSIT_GATEWAY_SNOX_3110
TRANSIT_GATEWAY_TNOX_3110
TRANSIT_SMSNOX_SNOX_3110
TRANSIT_SMSNOX_TNOX_3110

ALTER TABLE WEBFORT_CPASS.ARADMINAUDITTRAIL NOCOMPRESS;
ALTER TABLE WEBFORT_CPASS.ARADMINAUDITTRAIL MOVE NOCOMPRESS;

ALTER INDEX SNOX4TRANSNOX.PK_BOARDING_ACQUIRER_CONFIG REBUILD NOCOMPRESS ;


expdp rchaudhari directory=bkup dumpfile=expdp_uat_migration_11oct2015.dmp logfile=expdp_uat_migration_11oct2015.log schemas=KEYNOX_FX,WEBFORT,TRANSNOX_CPASS,SNOX4TRANSNOX_CPASS,TRANSTSYSPAYMENTGW,TRANSTSYSPAYMENTGWAPP,TRANSIT_FE_SNOX_3110,TRANSIT_FE_TNOX_3110,TRANSIT_GATEWAY_SNOX_3110,TRANSIT_GATEWAY_TNOX_3110,TRANSIT_SMSNOX_SNOX_3110,TRANSIT_SMSNOX_TNOX_3110 exclude=TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\" compression=all CONTENT=all reuse_dumpfile=y

file transfer from 64.51 of 126.61

imp_dpump

('KEYNOX_FX','WEBFORT','TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TRANSIT_FE_SNOX_3110','TRANSIT_FE_TNOX_3110','TRANSIT_GATEWAY_SNOX_3110','TRANSIT_GATEWAY_TNOX_3110','TRANSIT_SMSNOX_SNOX_3110','TRANSIT_SMSNOX_TNOX_3110')
----------------------------------------------------------------------------------------------------------------------------------------------





SELECT PropName,
	cardtype,
	sumtrans,
	sumcredit,
	sumvoid,
	sumface,
	sumsurcharge,
	sumamt,
	sumcomm,
	Property
FROM (SELECT *
  FROM (SELECT 'CORPORATION' Property,
			   corporationname PropName,
			   cardtype,
			   sumtrans,
			   sumcredit,
			   sumvoid,
			   sumface,
			   sumsurcharge,
			   sumamt,
			   sumcomm
		  FROM (  SELECT corporationcode,
						 CASE cardtype
							WHEN 1 THEN 'Debit'
							WHEN 2 THEN 'Visa'
							WHEN 3 THEN 'MasterCard'
							WHEN 4 THEN 'Amex'
							WHEN 5 THEN 'Diner'
							WHEN 6 THEN 'JCB'
							WHEN 7 THEN 'Discover'
							WHEN 8 THEN 'Unknown'
						 END
							AS cardtype,
						 SUM (trans_count) sumtrans,
						 SUM (credit_amount) sumcredit,
						 SUM (void_amount) sumvoid,
						 SUM (face) sumface,
						 SUM (surcharge) sumsurcharge,
						 SUM (amount) sumamt,
						 SUM (Commission) sumcomm
					FROM commission_card CC
				   WHERE     CONVERT ( DATETIME, (  RTRIM (LTRIM (STR (report_year))) + CASE WHEN LEN ( RTRIM ( LTRIM ( STR (report_month)))) < 2 THEN STUFF ( RTRIM ( LTRIM ( STR (report_month))), 1, 0, '0') ELSE RTRIM ( LTRIM (STR (report_month))) END + '01'), 120) BETWEEN CONVERT (DATETIME, '2015-08-01', 120) AND CONVERT (DATETIME, '2015-08-31', 120)
						 AND CC.corporationcode = '132300'
				GROUP BY corporationcode, cardtype
				UNION ALL

				  SELECT corporationcode,
						 'ZGTotal',
						 SUM (trans_count) sumtrans,
						 SUM (credit_amount) sumcredit,
						 SUM (void_amount) sumvoid,
						 SUM (face) sumface,
						 SUM (surcharge) sumsurcharge,
						 SUM (amount) sumamt,
						 SUM (Commission) sumcomm
					FROM commission_card CC
				   WHERE   CONVERT ( DATETIME, (  RTRIM (LTRIM (STR (report_year))) + CASE WHEN LEN ( RTRIM ( LTRIM ( STR (report_month)))) < 2 THEN STUFF ( RTRIM ( LTRIM ( STR (report_month))), 1, 0, '0') ELSE RTRIM ( LTRIM (STR (report_month))) END + '01'), 120) BETWEEN CONVERT (DATETIME, '2015-08-01', 120) AND CONVERT (DATETIME, '2015-08-31', 120)
						 AND CC.corporationcode = '132300'
				GROUP BY corporationcode)
				  AS corp_results, corporations                  
WHERE  Corp_results.corporationcode = corporations.corporationcode      ) AS corptab
UNION
SELECT *
FROM (SELECT 'CASINO' Property,
	   casinoname PropName,
	   cardtype,
	   sumtrans,
	   sumcredit,
	   sumvoid,
	   sumface,
	   sumsurcharge,
	   sumamt,
	   sumcomm
  FROM (  SELECT casinocode,
				 CASE cardtype
					WHEN 1 THEN 'Debit'
					WHEN 2 THEN 'Visa'
					WHEN 3 THEN 'MasterCard'
					WHEN 4 THEN 'Amex'
					WHEN 5 THEN 'Diner'
					WHEN 6 THEN 'JCB'
					WHEN 7 THEN 'Discover'
					WHEN 8 THEN 'Unknown'
				 END
					AS cardtype,
				 SUM (trans_count) sumtrans,
				 SUM (credit_amount) sumcredit,
				 SUM (void_amount) sumvoid,
				 SUM (face) sumface,
				 SUM (surcharge) sumsurcharge,
				 SUM (amount) sumamt,
				 SUM (Commission) sumcomm
			FROM commission_card CC
		   WHERE     CONVERT ( DATETIME, (  RTRIM (LTRIM (STR (report_year))) + CASE WHEN LEN ( RTRIM ( LTRIM ( STR (report_month)))) < 2 THEN STUFF ( RTRIM (LTRIM (STR (report_month))), 1, 0, '0') ELSE RTRIM (LTRIM (STR (report_month))) END + '01'), 120) BETWEEN CONVERT (DATETIME, '2015-08-01', 120) AND CONVERT (DATETIME, '2015-08-31', 120)
				 AND CC.corporationcode = '132300'
		GROUP BY casinocode, cardtype
		UNION ALL
		  SELECT casinocode,
				 'ZTotal' cardtype,
				 SUM (trans_count) sumtrans,
				 SUM (credit_amount) sumcredit,
				 SUM (void_amount) sumvoid,
				 SUM (face) sumface,
				 SUM (surcharge) sumsurcharge,
				 SUM (amount) sumamt,
				 SUM (Commission) sumcomm
			FROM commission_card CC
		   WHERE     CONVERT ( DATETIME, (  RTRIM (LTRIM (STR (report_year))) + CASE WHEN LEN ( RTRIM ( LTRIM ( STR (report_month)))) < 2 THEN STUFF ( RTRIM (LTRIM (STR (report_month))), 1, 0, '0') ELSE RTRIM (LTRIM (STR (report_month))) END + '01'), 120) BETWEEN CONVERT (DATETIME, '2015-08-01', 120) AND CONVERT (DATETIME, '2015-08-31', 120)
				 AND CC.corporationcode = '132300'
		GROUP BY casinocode) results1,
	   casinos
 WHERE results1.casinocode = casinos.casinocode)
  AS casttab    ) AS finaltab   ORDER BY property DESC, propname, cardtype;
  


-----------------------------------------------------------------------------------------------------------------------------------------------
-- 22Sept2015

-- Automation DB Release schema
DBRELEASE

-- PayFuse Schemas
PAYFUSE

-- Socket Gateway Schemas
SNOXPASS_GWAY_00526
SNOXPASS_SMSNOX_20195
TNOXPASS_GWAY_00526
TNOXPASS_SMSNOX_20195

-- Current applications are pointed to below VBS Schemas
TRANSIT_FE_SNOX_3110
TRANSIT_FE_TNOX_3110
TRANSIT_GATEWAY_SNOX_3110
TRANSIT_GATEWAY_TNOX_3110
TRANSIT_SMSNOX_SNOX_3110
TRANSIT_SMSNOX_TNOX_3110

-- Privious schemas
TRANSIT_FE_SNOX_320
TRANSIT_FE_TNOX_320
TRANSIT_GATEWAY_SNOX_320
TRANSIT_GATEWAY_TNOX_320
TRANSIT_SMSNOX_SNOX_320
TRANSIT_SMSNOX_TNOX_320

-- Privious schemas
TRANSIT_FE_SNOX_319
TRANSIT_FE_TNOX_319
TRANSIT_GATEWAY_SNOX_319
TRANSIT_GATEWAY_TNOX_319
TRANSIT_SMSNOX_SNOX_319
TRANSIT_SMSNOX_TNOX_319

-- Mother Schemas
SNOX4TRANSNOX_CPASS
TRANSNOX_CPASS
WEBFORT
KEYNOX_FX

-- Optional schemas (But required in New UAT)
TRANSITHA
TRANSNOX_CAT -- not fully imported, as it is not required for testing purpose
TRANSTSYSPAYMENTGW
TRANSTSYSPAYMENTGWAPP
PURGEDATA
SCHEMADIFF

-- Need to confirm from Amir
VERIZON_QA

-- Transending required schemas
ETLUPDATEGW
OFAC_ADAPTER
TRANSBASIC
TRANSBASICAPP
TRANSCAPITALONE
TRANSCAPITALONEAPP
TRANSDEMOACQ
TRANSDEMOACQAPP
TRANSDEMOACQ_NEW
TRANSDEMOACQ_NEWAPP
TRANSDEMOBASIC
TRANSDEMOBASICAPP
TRANSSIGUE
TRANSSIGUEAPP





impdp rchaudhari directory=IMP_DPUMP dumpfile=rbld_new_uat_18092015_095223.dmp logfile=impdp_Transnox_Cpass_22sept2015.log schemas=TRANSNOX_CPASS exclude=TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\"

impdp rchaudhari directory=IMP_DPUMP dumpfile=rbld_new_uat_18092015_095223.dmp logfile=impdp_vbs_schemas_22sept2015.log schemas=TRANSIT_FE_SNOX_3110,TRANSIT_FE_SNOX_319,TRANSIT_FE_SNOX_320,TRANSIT_FE_TNOX_3110,TRANSIT_FE_TNOX_319,TRANSIT_FE_TNOX_320,TRANSIT_GATEWAY_SNOX_3110,TRANSIT_GATEWAY_SNOX_319,TRANSIT_GATEWAY_SNOX_320,TRANSIT_GATEWAY_TNOX_3110,TRANSIT_GATEWAY_TNOX_319,TRANSIT_GATEWAY_TNOX_320,TRANSIT_SMSNOX_SNOX_3110,TRANSIT_SMSNOX_SNOX_319,TRANSIT_SMSNOX_SNOX_320,TRANSIT_SMSNOX_TNOX_3110,TRANSIT_SMSNOX_TNOX_319,TRANSIT_SMSNOX_TNOX_320 exclude=TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\"

impdp rchaudhari directory=IMP_DPUMP dumpfile=rbld_new_uat_18092015_095223.dmp logfile=impdp_other_schemas_22sept2015.log schemas=TRANSITHA,TRANSTSYSPAYMENTGW,TRANSTSYSPAYMENTGWAPP,WEBFORT exclude=TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\"
-----------------------------------------------------------------------------------------------------------------------------------------------

New_UAT_TXN=
  (DESCRIPTION=
  	(LOAD_BALANCE = ON)
    (ADDRESS= (PROTOCOL=TCP)(HOST=192.168.64.51)(PORT=1521))
    (ADDRESS= (PROTOCOL=TCP)(HOST=192.168.64.52)(PORT=1521))
    (CONNECT_DATA=
      (SERVICE_NAME=utxndb)
    )
  )
  
New_UAT_RPT=
  (DESCRIPTION=
  	(LOAD_BALANCE = ON)
    (ADDRESS= (PROTOCOL=TCP)(HOST=192.168.64.61)(PORT=1521))
    (ADDRESS= (PROTOCOL=TCP)(HOST=192.168.64.62)(PORT=1521))
    (CONNECT_DATA=
      (SERVICE_NAME=urptdb)
    )
  )


SELECT *
FROM 
(
    SELECT tw.owner, tw.synonym_name, tw.table_owner, tw.table_name,
        NVL2((SELECT UNIQUE te.table_name 
                FROM dba_synonyms te 
               WHERE te.owner = tw.owner 
                 AND te.synonym_name = tw.synonym_name
                 AND te.table_owner = tw.table_owner 
                 AND te.table_name = tw.table_name
                 ),'Y','N') missing_synonyms 
    FROM 
    (
        SELECT owner, synonym_name, table_owner, table_name
        FROM dba_synonyms@tw
        WHERE owner IN 
        ('RCHAUDHARI', 'TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 
         'TRANSTSYSPAYMENTGW', 'TRANSIT_GATEWAY_TNOX_319', 'TRANSIT_GATEWAY_SNOX_319', 
         'TRANSIT_FE_TNOX_319', 'TRANSIT_FE_SNOX_319', 'TRANSIT_SMSNOX_SNOX_318', 
         'TRANSIT_SMSNOX_TNOX_318')
    ) tw
)
WHERE missing_synonyms = 'N'



SELECT *
FROM dba_tab_privs@tw
WHERE grantee IN 
        ('RCHAUDHARI', 'TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 
         'TRANSTSYSPAYMENTGW', 'TRANSIT_GATEWAY_TNOX_319', 'TRANSIT_GATEWAY_SNOX_319', 
         'TRANSIT_FE_TNOX_319', 'TRANSIT_FE_SNOX_319', 'TRANSIT_SMSNOX_SNOX_318', 
         'TRANSIT_SMSNOX_TNOX_318')
MINUS
SELECT *
FROM dba_tab_privs
WHERE grantee IN 
        ('RCHAUDHARI', 'TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 
         'TRANSTSYSPAYMENTGW', 'TRANSIT_GATEWAY_TNOX_319', 'TRANSIT_GATEWAY_SNOX_319', 
         'TRANSIT_FE_TNOX_319', 'TRANSIT_FE_SNOX_319', 'TRANSIT_SMSNOX_SNOX_318', 
         'TRANSIT_SMSNOX_TNOX_318')




SELECT owner, synonym_name, table_owner, table_name
        FROM dba_synonyms
        WHERE owner IN 
        ('RCHAUDHARI', 'TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 
         'TRANSTSYSPAYMENTGW', 'TRANSIT_GATEWAY_TNOX_319', 'TRANSIT_GATEWAY_SNOX_319', 
         'TRANSIT_FE_TNOX_319', 'TRANSIT_FE_SNOX_319', 'TRANSIT_SMSNOX_SNOX_318', 
         'TRANSIT_SMSNOX_TNOX_318')
MINUS
SELECT owner, synonym_name, table_owner, table_name
        FROM dba_synonyms@tw
        WHERE owner IN 
        ('RCHAUDHARI', 'TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 
         'TRANSTSYSPAYMENTGW', 'TRANSIT_GATEWAY_TNOX_319', 'TRANSIT_GATEWAY_SNOX_319', 
         'TRANSIT_FE_TNOX_319', 'TRANSIT_FE_SNOX_319', 'TRANSIT_SMSNOX_SNOX_318', 
         'TRANSIT_SMSNOX_TNOX_318')
         
         
         



SELECT *
from v$session
      


SELECT *
FROM sys.aud$
ORDER BY ntimestamp# DESC

---------------------------------------------------------------------------------------------------------------------------------------------

-- 07Sept2015

CREATE  DATABASE LINK TW
 CONNECT TO RCHAUDHARI
 IDENTIFIED BY "Jingalbel$2015"
 USING '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP) (HOST=w-transitdb-txn.tsysacquiring.org) (PORT=1521))(CONNECT_DATA=(INSTANCE_NAME=transitt1)(SERVICE_NAME=transittxn)))';
 
 
 CREATE OR REPLACE FORCE VIEW RCHAUDHARI.CHK_SEQUENCES
(
   SEQUENCE_NAME,
   TW_Seq_LastNumber,
   TE_SEQ_LastNumber,
   DIFF_NUMBER,
   CACHE_SIZE
)
AS
     SELECT TW.SEQUENCE_NAME,
            TW.LAST_NUMBER TW_Seq_LastNumber,
            TE.LAST_NUMBER TE_SEQ_LastNumber,
            TE.LAST_NUMBER - TW.LAST_NUMBER diff_number,
            TW.CACHE_SIZE
       FROM ALL_sequences@TW TW, ALL_sequences TE
      WHERE     TW.SEQUENCE_OWNER IN ('TRANSNOX_IOX',
                                        'SNOX4TRANSNOX',
                                        'WEBFORT_CPASS',
                                        'TRANSNOX_CAT',
                                        'TRANSTSYSPAYMENTGW')
            AND TW.SEQUENCE_OWNER = TE.SEQUENCE_OWNER
            AND TW.SEQUENCE_NAME = TE.SEQUENCE_NAME
            AND TE.LAST_NUMBER > TW.LAST_NUMBER
   ORDER BY 5 DESC;
   
   
SELECT owner, table_name, column_name, data_type, data_length
FROM dba_tab_columns te, 
WHERE owner IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 
                'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319',
                'TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318',
                'TRANSIT_SMSNOX_TNOX_318')  


CREATE OR REPLACE FORCE VIEW RCHAUDHARI.CHK_Columns_DataTypes
(
   owner,
   table_name,
   column_name,
   data_type,
   data_length,
   TE_miss_Match
)
AS
SELECT UNIQUE owner, table_name, column_name, data_type, data_length, TE_miss_Match
FROM
(
    SELECT tw.owner, tw.table_name, tw.column_name, tw.data_type, tw.data_length,
        NVL2((SELECT UNIQUE te.table_name 
                FROM all_tab_columns te 
               WHERE te.owner=tw.owner 
                 AND te.table_name = tw.table_name 
                 AND te.column_name = tw.column_name 
                 AND te.DATA_TYPE = tw.data_type 
                 AND te.DATA_LENGTH = tw.data_length
                 AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
                 AND te.table_name NOT LIKE '%ORG'),'Y','N') TE_miss_Match
    FROM
    (
        SELECT owner, table_name, column_name, data_type, data_length
        FROM all_tab_columns@tw
        WHERE owner IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
          AND table_name NOT LIKE '%ORG' 
          AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
        ORDER BY owner, table_name, column_name ASC
    )tw
)
WHERE TE_miss_Match='N'
  AND REGEXP_LIKE(table_name,'[^0-9]$','i')
ORDER BY 1,2,3,4 ASC




snox4transnox.LOOKUP_KEY_TYPE


SELECT * FROM CHK_indexes


CREATE OR REPLACE FORCE VIEW RCHAUDHARI.CHK_indexes
(
   table_owner,
   table_name,
   column_name,
   index_name,
   te_miss_indexes
)
AS
SELECT UNIQUE table_owner, table_name, column_name, index_name, te_miss_indexes
FROM 
(
    SELECT tw.table_owner, tw.table_name, tw.column_name, tw.index_name,
      NVL2((SELECT UNIQUE te.table_name 
              FROM all_ind_columns te 
             WHERE te.TABLE_NAME = tw.table_name 
               AND te.table_owner = tw.table_owner 
               AND te.column_name = tw.column_name 
               AND te.table_owner = tw.table_owner),'Y','N') te_miss_indexes 
    FROM     
    (
        SELECT index_owner, index_name, table_owner, table_name, column_name
        FROM all_ind_columns@tw
        WHERE index_owner IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
          AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
        ORDER BY index_owner,table_owner,table_name ASC
    )tw
)
WHERE te_miss_indexes='N'
ORDER BY 1,2,3 ASC  




SELECT owner, object_name, object_type, mis_tables, mis_view, mis_proc, mis_func, mis_tri, mis_pac, mis_pac_body, mis_seq 
FROM 
(    
    SELECT UNIQUE doj.owner, doj.object_name, doj.object_type,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TABLE' AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i') AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tables,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_view,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_proc,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_func,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tri,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac_body,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_seq
    FROM 
    (
        SELECT owner, object_name, object_type  
        FROM dba_objects@tw
        WHERE owner IN ('RCHAUDHARI','TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
          AND object_name NOT LIKE '%ORG' 
          AND object_name NOT LIKE 'BIN$%'
          AND object_name NOT LIKE '%REPL'
          AND OBJECT_TYPE IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
        ORDER BY owner, object_name, object_type ASC
    ) doj
)
WHERE mis_tables='N'
  AND mis_view='N'
  AND mis_proc='N'
  AND mis_func='N'
  AND mis_tri='N'
  AND mis_pac='N'
  AND mis_pac_body='N'
  AND mis_seq='N'
  AND REGEXP_LIKE(object_name,'[^0-9]$','i')
ORDER BY 1,2,3 ASC

SELECT 'TW' DBName
 FROM dual 


SELECT owner, object_name, object_type, db_name, tw_dbname, te_dbname
FROM (
SELECT UNIQUE owner,
    object_name,
    object_type,
    DB_Name,
    NVL2((SELECT UNIQUE OBJECT_NAME 
            FROM DBA_OBJECTS@TW TW 
           WHERE tw.object_type = iner.OBJECT_TYPE 
             AND tw.owner = iner.owner 
             AND tw.object_name = iner.object_name),'Y','N') tw_dbname,
    NVL2((SELECT UNIQUE OBJECT_NAME 
            FROM DBA_OBJECTS te 
           WHERE te.object_type=iner.OBJECT_TYPE 
             AND te.owner = iner.owner 
             AND te.object_name = iner.object_name),'Y','N') te_dbname
FROM         
(
    SELECT 'TW' DB_Name, owner, object_name, object_type, status
    FROM all_objects@tw
    WHERE owner IN ('RCHAUDHARI','TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
     AND OBJECT_TYPE = 'FUNCTION' --IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
    UNION ALL
    SELECT 'TE' DB_Name, owner, object_name, object_type, status
    FROM all_objects
    WHERE owner IN ('RCHAUDHARI','TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
      AND OBJECT_TYPE  = 'FUNCTION' -- IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
)iner)
WHERE (tw_dbname = 'N' OR te_dbname = 'N')
  AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
---------------------------------------------------------------------------------------------------------------------------------------------  

--27-Jul-2015
[chaitanyakorde@epl1trandbtxn1 ~]$ uptime
 01:59:54 up 1 day, 43 min,  3 users,  load average: 0.26, 0.23, 0.23

[chaitanyakorde@epl1trandbtxn2 ~]$ uptime
 02:02:00 up 157 days, 18:53,  1 user,  load average: 1.44, 0.77, 0.66

[chaitanyakorde@epl1trandbtxn3 ~]$ uptime
 02:00:32 up 157 days, 18:30,  1 user,  load average: 0.83, 0.29, 0.23
 ---------------------------------------------------------------------------------------------------------------------------------------------

take the invalid object snapshot
take the script of grant and synonyms
stop replication
take export all table data_only options
rename original tables appending _1
create partition all tables by original names
import data into original partition tables
create indexes and constraints
start replication
give grant and create synonyms
compare the invalid object snapshot
compile schema

function2
(
-- code
)

Day=`date +"%A"`
case ${Day} in
        Sunday) Call function3  ;;
        Monday) Call function2  ;;
        Tuesday) Call function1  ;;
        Wednesday) Call function1  ;;
        Thursday) Call function3  ;;
        Friday) Call function2  ;;
        Saturday) Call function1  ;;
           *) echo "Error"   ;;
esac

Monday
Tuesday
Wednesday
Thursday
Friday
Saturday
Sunday
---------------------------------------------------------------------------------------------------------------------------------------------

 -- 17Aug2015

EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_319');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_319');
EXEC dbms_utility.compile_schema('TRANSIT_FE_SNOX_319');
EXEC dbms_utility.compile_schema('TRANSIT_FE_TNOX_319');
EXEC dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_318');
EXEC dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_318');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_318');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_318');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_317');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_317');
EXEC dbms_utility.compile_schema('TRANSIT_FE_SNOX_317');
EXEC dbms_utility.compile_schema('TRANSIT_FE_TNOX_317');
EXEC dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_317');
EXEC dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_317');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_316');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_316');
EXEC dbms_utility.compile_schema('TRANSIT_FE_SNOX_316');
EXEC dbms_utility.compile_schema('TRANSIT_FE_TNOX_316');
EXEC dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_315');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_315');
EXEC dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_315');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_315');
EXEC dbms_utility.compile_schema('SEQUENCE_REPL');
EXEC dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_314');
EXEC dbms_utility.compile_schema('TRANSIT_FE_TNOX_314');
EXEC dbms_utility.compile_schema('TRANSIT_FE_SNOX_314');
EXEC dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_314');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_314');
EXEC dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_314');
EXEC dbms_utility.compile_schema('TRANSNOX_IOX');
EXEC dbms_utility.compile_schema('SNOX4TRANSNOX');


 transnox_iox.TRANS_ADDITIONAL_INFO
 
 
 
 SELECT OWNER, OBJECT_TYPE, STATUS, COUNT(*)
 FROM DBA_OBJECTS
 WHERE OBJECT_NAME IN
   (
     SELECT NAME
     FROM DBA_DEPENDENCIES
     WHERE REFERENCED_NAME ='TRANSACTION'
      AND REFERENCED_OWNER IN ('TRANSNOX_IOX','SNOX4TRANSNOX','TRANSIT_SMSNOX_TNOX_318','TRANSIT_SMSNOX_SNOX_318','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319')
   )
  AND OWNER IN ('TRANSNOX_IOX','SNOX4TRANSNOX','TRANSIT_SMSNOX_TNOX_318','TRANSIT_SMSNOX_SNOX_318','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319')
 GROUP BY OWNER, OBJECT_TYPE, STATUS
 ORDER BY 1,2 ASC
 
 
 SELECT MAX(TIMESTAMP) FROM transnox_iox.TRANS_BANK_DETAIL
 
 
 SELECT MAX(time_stamp) FROM transnox_iox.TRANSACTION
 
 ALTER TABLE transnox_iox.MO_DT3_TRANSACTION_DETAILS DISABLE CONSTRAINT FK_MO_DT3_TRANSACTION_DETAILS  
 
 
 SELECT MIN(TIMESTAMP) FROM transnox_iox.TRANS_RETURN
 
 
 SELECT MIN(TIMESTAMP) FROM transnox_iox.TRANS_RETURN_2             
 
 
 SELECT username, created 
 FROM dba_users
 ORDER BY created DESC
 
 
 
 SELECT *
 FROM transnox_iox.TRANS_DETAIL
 WHERE date_created IS NOT NULL
 
 
 SELECT tri.transaction_id, xtn.time_stamp, tri.date_created
 FROM transnox_iox.TRANS_RESPONSE_INFO tri, transnox_iox.TRANSACTION xtn
 WHERE xtn.transaction_id = tri.transaction_id
 AND  xtn.time_stamp > SYSDATE -2/1440 --TO_DATE('08/09/2015 00:00:00','mm/dd/yyyy hh24:mi:ss')
 AND tri.date_created IS NOT NULL;
 
 SELECT COUNT(*) 
 FROM transnox_iox.TRANS_DETAIL td, transnox_iox.TRANSACTION xtn
 WHERE xtn.transaction_id = td.transaction_id
 AND  xtn.time_stamp > SYSDATE - 1/1440
 AND td.date_created IS NOT NULL;
 
 SELECT transaction_id,date_created
 FROM transnox_iox.TRANS_DETAIL
 WHERE transaction_id IN (144185837,144185838,144185839,144185840,144185841)
 
 
 SELECT *
 FROM DBA_SEGMENTS
 WHERE SEGMENT_name='TRANS_DETAIL' 
   AND OWNER='TRANSNOX_IOX'
 
 
 SELECT MIN(TIME_STAMP) FROM transnox_iox.TRANS_VOID WHERE TIME_STAMP IS NULL
 
 
 SELECT MAX(time_stamp) FROM transnox_iox.TRANSACTION
 
 SELECT TO_CHAR(Time_stamp,'yyyy')TIMESTAMP,COUNT(*)
 FROM transnox_iox.TRANSACTION xtn
 --WHERE xtn.Time_stamp BETWEEN TO_DATE ('01/01/2010 00:00:00', 'mm/dd/yyyy hh24:mi:ss') 
 --                         AND TO_DATE ('12/31/2010 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
 GROUP BY TO_CHAR(Time_stamp,'yyyy')
 ORDER BY TO_CHAR(Time_stamp,'yyyy') ASC
 
 
 SELECT COUNT(*) 
 FROM transnox_iox.TRANSACTION xtn
 WHERE xtn.Time_stamp BETWEEN TO_DATE ('01/01/2015 00:00:00', 'mm/dd/yyyy hh24:mi:ss') 
                          AND TO_DATE ('03/31/2015 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
 
 
 SELECT * 
 FROM transnox_iox.TRANS_RESPONSE_INFO td
 WHERE date_created < SYSDATE -1/1440
 
   
 SELECT COUNT(td.transaction_id) 
 FROM transnox_iox.TRANS_DETAIL td, transnox_iox.TRANSACTION xtn
 WHERE td.TRANSACTION_ID = xtn.TRANSACTION_ID
   AND xtn.Time_stamp BETWEEN TO_DATE ('01/01/2015 00:00:00', 'mm/dd/yyyy hh24:mi:ss') 
                          AND TO_DATE ('05/31/2015 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
 --AND td.Date_created IS NOT NULL  
 
 
 
 SELECT COUNT(td.transaction_id) 
 FROM transnox_iox.TRANS_RESPONSE_INFO td, transnox_iox.TRANSACTION xtn
 WHERE td.TRANSACTION_ID = xtn.TRANSACTION_ID
 AND td.Date_created IS NOT NULL  
 
 
 ALTER TABLESPACE TNOX_DATA_PARTI_2 ADD DATAFILE '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF
 
 ALTER TABLESPACE TNOX_DATA_PARTI_2 ADD DATAFILE '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF
 
 ALTER SESSION SET CURRENT_SCHEMA=transnox_iox
 
   
 SELECT *
 FROM transnox_iox.TRANS_SCORE
 WHERE Date_created IS  NULL
 
 EDIT transnox_iox.TRANS_RESPONSE_INFO WHERE transaction_id IN (48416267,48416267)
 
 '06/08/2014 4:33:10 AM
06/08/2014 4:33:13 AM'
---------------------------------------------------------------------------------------------------------------------------------------------
 
 -- 30Jul2015
 SELECT TO_CHAR(date_created,'mm/yyyy'),COUNT(*)
 FROM PARTITION_RANGE.TRANS_RESPONSE_INFO
 WHERE date_created IS NOT NULL
   AND date_created BETWEEN TO_DATE ('01/01/2013 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE ('12/31/2013 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
 GROUP BY TO_CHAR(date_created,'mm/yyyy');
 
 
 SELECT TO_CHAR(date_created,'mm/yyyy'),COUNT(*)
 FROM PARTITION_RANGE.TRANS_Detail
 WHERE date_created IS NOT NULL
 GROUP BY TO_CHAR(date_created,'mm/yyyy');
 
 TO_DATE ('05/01/2014 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE ('09/30/2014 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
 
 
 SELECT COUNT(*) FROM transnox_iox.TRANSACTION xtn
 WHERE xtn.time_stamp BETWEEN  TO_DATE ('01/01/2013 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE ('12/31/2013 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
                                 
 
 
 ALTER SESSION SET CURRENT_SCHEMA = PARTITION_RANGE;
 
 -- Trans_Response_Info
 DECLARE
    CURSOR Cur_transaction
    IS
       SELECT Time_stamp, Xtn.Transaction_id
         FROM transnox_iox.TRANSACTION Xtn
        WHERE Xtn.Time_stamp BETWEEN
                 TO_DATE ('01/01/2013 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE ('12/31/2013 23:59:59', 'mm/dd/yyyy hh24:mi:ss');
 
    TYPE Cur_transaction_array IS TABLE OF Cur_transaction%ROWTYPE;
 
    Cur_transaction_fetch_array   Cur_transaction_array;
    V_numerrors                   NUMBER := 0;
    V_error_code                  NUMBER;
    V_error_msg                   VARCHAR2 (4000);
    V_error_idx                   NUMBER;
 BEGIN
    OPEN Cur_transaction;
 
    LOOP
       FETCH Cur_transaction
       BULK COLLECT INTO Cur_transaction_fetch_array
       LIMIT 2000;
 
       BEGIN
          FORALL I IN 1 .. Cur_transaction_fetch_array.COUNT SAVE EXCEPTIONS
             UPDATE PARTITION_RANGE.TRANS_RESPONSE_INFO Td
                SET Td.Date_created =
                       Cur_transaction_fetch_array (I).Time_stamp
              WHERE Td.Transaction_id =
                       Cur_transaction_fetch_array (I).Transaction_id;
       EXCEPTION
          WHEN OTHERS
          THEN
             V_numerrors := SQL%BULK_EXCEPTIONS.COUNT;
 
             FOR V_count IN 1 .. V_numerrors
             LOOP
                V_error_code := SQL%BULK_EXCEPTIONS (V_count).ERROR_CODE;
                V_error_msg := SQLERRM (-V_error_code);
                V_error_idx := SQL%BULK_EXCEPTIONS (V_count).ERROR_INDEX;
                DBMS_OUTPUT.Put_line (
                      ' Error Code : '
                   || V_error_code
                   || ' Error Message : '
                   || V_error_msg);
             END LOOP;
       END;
 
       COMMIT;
       EXIT WHEN Cur_transaction%NOTFOUND;
    END LOOP;
 
    CLOSE Cur_transaction;
 
    COMMIT;
 EXCEPTION
    WHEN OTHERS
    THEN
       DBMS_OUTPUT.Put_line (
             ' Error Code : '
          || SQLCODE
          || ' Error Message : '
          || SUBSTR (SQLERRM, 1, 200));
 END;
 /  
 
 
 
 
 ALTER SESSION SET CURRENT_SCHEMA=PARTITION_RANGE;
 
 
 SELECT TO_CHAR(date_created,'mm/yyyy'),COUNT(*)
 FROM PARTITION_RANGE.trans_detail
 WHERE date_created IS NOT NULL
   AND date_created BETWEEN  TO_DATE ('05/01/2014 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE ('07/31/2014 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
 GROUP BY TO_CHAR(date_created,'mm/yyyy')
 
 
 CREATE INDEX PARTITION_RANGE.idx_TRANS_DETAIL ON PARTITION_RANGE.TRANS_DETAIL(TRANSACTION_ID)NOLOGGING
 TABLESPACE TNOX_INDX_RNG_PRTI_2;
 
 
 
 CREATE TABLE PARTITION_RANGE.trans_detail TABLESPACE TNOX_DATA_RNG_PRTI_2 NOLOGGING
 AS
 SELECT * FROM transnox_iox.trans_detail
 
 
 
 ALTER TABLE PARTITION_RANGE.trans_detail ADD date_created DATE 
 
 
 
 SELECT COUNT(*) FROM transnox_iox.TRANSACTION xtn
 WHERE xtn.time_stamp BETWEEN  TO_DATE ('05/01/2014 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE ('07/31/2014 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
                                 
 TO_DATE ('01/01/2014 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE ('04/30/2014 23:59:59', 'mm/dd/yyyy hh24:mi:ss')
 
 UPDATE PARTITION_RANGE.trans_detail td
 SET td.date_created = (SELECT time_stamp FROM transnox_iox.TRANSACTION xtn
                                 WHERE xtn.transaction_id = td.transaction_id
                                 AND xtn.time_stamp > TO_DATE('07/01/2015 00:00:00', 'mm/dd/yyyy hh24:mi:ss'))
 WHERE EXISTS (SELECT 1 FROM transnox_iox.TRANSACTION xtn
                                 WHERE xtn.transaction_id = td.transaction_id
                                 AND xtn.time_stamp > TO_DATE('07/01/2015 00:00:00', 'mm/dd/yyyy hh24:mi:ss'))      
 
 
 
 COMMIT
 
 UPDATE PARTITION_RANGE.trans_detail td
 SET td.date_created = (SELECT time_stamp FROM transnox_iox.TRANSACTION xtn
                                 WHERE xtn.transaction_id = td.transaction_id
                                 AND xtn.time_stamp BETWEEN TO_DATE('02/01/2015 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE('03/31/2015 23:59:59', 'mm/dd/yyyy hh24:mi:ss'))
 WHERE EXISTS (SELECT 1 FROM transnox_iox.TRANSACTION xtn
                                 WHERE xtn.transaction_id = td.transaction_id
                                 AND xtn.time_stamp BETWEEN TO_DATE('02/01/2015 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE('03/31/2015 23:59:59', 'mm/dd/yyyy hh24:mi:ss'))          
 
 
 
 ALTER SESSION SET CURRENT_SCHEMA = PARTITION_RANGE;
 
 -- Trans_Details
 DECLARE
    CURSOR Cur_transaction
    IS
       SELECT Time_stamp, Xtn.Transaction_id
         FROM transnox_iox.TRANSACTION Xtn
        WHERE Xtn.Time_stamp BETWEEN
                 TO_DATE ('01/01/2013 00:00:00', 'mm/dd/yyyy hh24:mi:ss') AND TO_DATE ('12/31/2013 23:59:59', 'mm/dd/yyyy hh24:mi:ss');
 
    TYPE Cur_transaction_array IS TABLE OF Cur_transaction%ROWTYPE;
 
    Cur_transaction_fetch_array   Cur_transaction_array;
    V_numerrors                   NUMBER := 0;
    V_error_code                  NUMBER;
    V_error_msg                   VARCHAR2 (4000);
    V_error_idx                   NUMBER;
 BEGIN
    OPEN Cur_transaction;
 
    LOOP
       FETCH Cur_transaction
       BULK COLLECT INTO Cur_transaction_fetch_array
       LIMIT 2000;
 
       BEGIN
          FORALL I IN 1 .. Cur_transaction_fetch_array.COUNT SAVE EXCEPTIONS
             UPDATE PARTITION_RANGE.Trans_detail Td
                SET Td.Date_created =
                       Cur_transaction_fetch_array (I).Time_stamp
              WHERE Td.Transaction_id =
                       Cur_transaction_fetch_array (I).Transaction_id;
       EXCEPTION
          WHEN OTHERS
          THEN
             V_numerrors := SQL%BULK_EXCEPTIONS.COUNT;
 
             FOR V_count IN 1 .. V_numerrors
             LOOP
                V_error_code := SQL%BULK_EXCEPTIONS (V_count).ERROR_CODE;
                V_error_msg := SQLERRM (-V_error_code);
                V_error_idx := SQL%BULK_EXCEPTIONS (V_count).ERROR_INDEX;
                DBMS_OUTPUT.Put_line (
                      ' Error Code : '
                   || V_error_code
                   || ' Error Message : '
                   || V_error_msg);
             END LOOP;
       END;
 
       COMMIT;
       EXIT WHEN Cur_transaction%NOTFOUND;
    END LOOP;
 
    CLOSE Cur_transaction;
 
    COMMIT;
 EXCEPTION
    WHEN OTHERS
    THEN
       DBMS_OUTPUT.Put_line (
             ' Error Code : '
          || SQLCODE
          || ' Error Message : '
          || SUBSTR (SQLERRM, 1, 200));
 END;
 /  
---------------------------------------------------------------------------------------------------------------------------------------------


-- 29July2015
CREATE TABLESPACE TNOX_DATA_RNG_PRTI_1 DATAFILE 
  '+ASMRPTDATA' SIZE 10G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 10G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 10G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 10G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND ON NEXT 5M MAXSIZE UNLIMITED,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;


CREATE TABLESPACE TNOX_DATA_RNG_PRTI_2 DATAFILE 
  '+ASMRPTDATA' SIZE 8G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 8G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED,
  '+ASMRPTDATA' SIZE 8G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 6G AUTOEXTEND OFF
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;


CREATE TABLESPACE TNOX_INDX_RNG_PRTI_1 DATAFILE 
  '+ASMRPTDATA' SIZE 8G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 10G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 1G AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED,
  '+ASMRPTDATA' SIZE 5G AUTOEXTEND OFF
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;


CREATE TABLESPACE TNOX_INDX_RNG_PRTI_2 DATAFILE 
  '+ASMRPTDATA' SIZE 3G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 4G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 1G AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;



TNOX_DATA_RNG_PRTI_1
TNOX_DATA_RNG_PRTI_2


TNOX_INDX_RNG_PRTI_1
TNOX_INDX_RNG_PRTI_2


TRANSNOX_IOX.TRANS_CARD_HISTORY      19  -- partition can be done on timestamp(9)

TRANSNOX_IOX.TRANS_RESPONSE_INFO     19  -- Date_Created  15 
TRANSNOX_IOX.TRANS_DETAIL            17  -- Date_Created  15 Mins
TRANSNOX_IOX.TRANSACTION             16  -- TIME_STAMP	  25 Mins
TRANSNOX_IOX.TRANS_CARD              16  -- TIMESTAMP	  15 Mins
TRANSNOX_IOX.REQUEST_AUDIT_TRAIL     13  -- SERVER_TIMESTAMP 15 minis
TRANSNOX_IOX.TASK                    12  -- TIME_STAMP		20 Mins
TRANSNOX_IOX.REPORT_USAGE_AUDITTRAIL 9 GB  -- START_DATE	15 mins
TRANSNOX_IOX.TRANS_SETTLEMENT        6 GB  -- timestamp   	10 mins
TRANSNOX_IOX.TRANS_ADDITIONAL_INFO	 207MB -- timestamp 	5 mins
TRANSNOX_IOX.TRANS_BANK_DETAIL       183MB -- timestamp  	5 mins
TRANSNOX_IOX.TRANS_RETURN			 12 MB -- timestamp	    5 mins
TRANSNOX_IOX.TRANS_VOID				 60 MB -- time_stamp	5 mins
TRANSNOX_IOX.TRANS_SCORE             16 GB -- TIME_STAMP	20 mins

TRANSNOX_IOX.TRANS_CHECK            		-- Not used in reporting quires            
TRANSNOX_IOX.TRANS_EMV_DATA         		-- No Date Column
TRANSNOX_IOX.TRANS_MONEY_ORDER      		-- Not used in reporting quires
TRANSNOX_IOX.TRANS_MONEY_TRANSFER   		-- Not used in reporting quires
TRANSNOX_IOX.TRANS_COUPONS          		-- Used in reporting quires, But Table size 1 MB (Less data)
TRANSNOX_IOX.TRANS_ADDITIONAL_AMOUNT_TYPE 	-- Not used in reporting quires
TRANSNOX_IOX.TRANS_LODGING_INFO     		-- Not used in reporting quires
TRANSNOX_IOX.TRANS_ENHANCED_DATA  			-- order_date
TRANSNOX_IOX.TRANS_FEE_DETAIL 				-- No Date Column
TRANSNOX_IOX.TRANS_SHIPPING_INFO 			-- No Date Column 
TRANSNOX_IOX.TRANS_PROMOTIONS   			-- No Date Column
TRANSNOX_IOX.TRANS_TAX_DETAIL 				-- No Date Column
TRANSNOX_IOX.TRANS_DENOMINATION_DETAILS 	-- No Date Column



---------------------------------------------------------------------------------------------------------------------------------------------


-- 24Jul2015



SELECT *
FROM PURGEDATA.PURGE_LOGS
ORDER BY 1 DESC

SELECT COUNT(*)
FROM transnox_iox.TASK otr
WHERE EXISTS (SELECT 1 FROM PURGEDATA.PURGE_XTN_RECORDS_23072015 inr WHERE inr.task_id = otr.task_id)

transnox_iox.TASK




SELECT * FROM PURGEDATA.PURGE_XTN_RECORDS_24072015;

ALTER TABLE PURGEDATA.PURGE_LOGS DROP COLUMN REMAINING_RECORDS;

SELECT *
FROM PURGEDATA.PURGE_LOGS
ORDER BY 1 DESC



SELECT COUNT(*)
FROM transnox_iox.TASK otr
WHERE EXISTS (SELECT 1 FROM PURGEDATA.PURGE_XTN_RECORDS_23072015 inr WHERE inr.task_id = otr.task_id)

transnox_iox.TASK



CREATE INDEX transnox_iox.idx_task_time_log1 ON transnox_iox.TASK_TIME_LOG(task_id) TABLESPACE indx ONLINE


2182161

transnox_iox.TASK


SELECT COUNT(*)
FROM transnox_iox.TASK 
WHERE TIME_STAMP <= TRUNC(SYSDATE)-1095

SELECT * FROM transnox_iox.TASK_TIME_LOG WHERE task_id 
NOT IN (SELECT task_id FROM transnox_iox.TASK WHERE time_stamp < ADD_MONTHS(SYSDATE  ,-36)) 

SELECT SUM(processing_time_insec)
FROM PURGEDATA.PURGE_LOGS
ORDER BY 1 DESC

SELECT *
FROM PURGEDATA.PURGE_XTN_RECORDS_23072015

DROP INDEX idx_taskid_purgedata

CREATE INDEX purgedata.idx_taskid_purgedata ON purgedata.PURGE_XTN_RECORDS_23072015(task_id) TABLESPACE PURGE_DATA_TBLS ONLINE

ALTER TABLESPACE INDX ADD DATAFILE  '+ASMTXNDATA' SIZE 2G AUTOEXTEND OFF 

CREATE INDEX purgedata.idx_taskid_purgedata ON purgedata.PURGE_XTN_RECORDS_23072015(task_id) TABLESPACE PURGE_DATA_TBLS ONLINE

CREATE INDEX transnox_iox.idx_time_stamp_tsk ON transnox_iox.TASK(time_stamp) TABLESPACE indx ONLINE





 SELECT table_name,
                         schema_name,
                         SEARCH_COLUMN,
                         RETENTION_PERIODINMONTH
                    FROM PURGE_TABLE_INFO
                   WHERE IS_PURGED = 'N'
                ORDER BY sequence_id
                
SELECT transaction_id,COUNT(tsk.task_id) FROM transnox_iox.TRANSACTION xtn, TASK tsk 
WHERE xtn.task_id = tsk.task_id AND  xtn.time_stamp> SYSDATE-2/24
GROUP BY transaction_id
HAVING COUNT(tsk.task_id)>1                 



ALTER TABLE PURGEDATA.PURGE_LOGS RENAME COLUMN ROWS_DELETED TO ROWS_TOBE_DELETE;

ALTER TABLE PURGEDATA.PURGE_LOGS ADD REMAINING_RECORDS NUMBER; 

INSERT INTO PURGEDATA.PURGE_TABLE_INFO
   (TABLE_NAME, SCHEMA_NAME, SEQUENCE_ID, SEARCH_COLUMN, RETENTION_PERIODINMONTH, 
    IS_PURGED, COLUMN_VALUE)
 VALUES
   ('TASK_TIME_LOG', 'TRANSNOX_CPASS', 0, 'TASK_ID', 36, 
    'Y', NULL);
    
COMMIT; 

INSERT INTO PURGEDATA.PURGE_TABLE_INFO
   (TABLE_NAME, SCHEMA_NAME, SEQUENCE_ID, SEARCH_COLUMN, RETENTION_PERIODINMONTH, 
    IS_PURGED, COLUMN_VALUE)
 VALUES
   ('TASK', 'TRANSNOX_IOX', 1, 'TASK_ID', 36, 
    'N', NULL);
    
COMMIT;    

UPDATE PURGEDATA.PURGE_TABLE_INFO PTI
SET PTI.IS_PURGED='Y'; 


TRUNCATE TABLE purgedata.PURGE_LOGS

CREATE TABLE rchaudhari.PURGE_LOGS AS SELECT * FROM purgedata.PURGE_LOGS

COMMIT;





-----------------------------------------------------------------------------------------------------------------------------------------------------------------------


-- 22Jul2015

TNOX_DATA_PARTI
TNOX_DATA_PARTI_2


TNOX_INDX_PARTI
TNOX_INDX_PARTI_2




TRANSACTION
-- TRANS_DETAIL
-- TRANS_SETTLEMENT
-- TRANS_CARD
TRANS_RESPONSE_INFO
TRANS_ADDITIONAL_INFO
TRANS_BANK_DETAIL
TRANS_RETURN
TRANS_STATUS_HISTORY
TRANS_SIGNATURE_HISTORY
TRANS_SIGNATURE
TRANS_CHECK
TRANS_CHECK_CLEAR_AMOUNT
TRANS_CHECK_DEPOSITE
TRANS_COMPLIANCE_INFO
TRANS_EMV_DATA
TRANS_MONEY_ORDER
TRANS_MONEY_TRANSFER
TRANS_PAYROLL 


INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_DETAIL NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_DETAIL otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_SETTLEMENT NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_SETTLEMENT otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_CARD NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_CARD otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_RESPONSE_INFO NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_RESPONSE_INFO otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_ADDITIONAL_INFO NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_ADDITIONAL_INFO otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_BANK_DETAIL NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_BANK_DETAIL otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_RETURN NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_RETURN otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_STATUS_HISTORY NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_STATUS_HISTORY otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_SIGNATURE_HISTORY NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_SIGNATURE_HISTORY otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_SIGNATURE NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_SIGNATURE otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_CHECK NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_CHECK otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_CHECK_CLEAR_AMOUNT NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_CHECK_CLEAR_AMOUNT otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_CHECK_DEPOSITE NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_CHECK_DEPOSITE otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_COMPLIANCE_INFO NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_COMPLIANCE_INFO otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_EMV_DATA NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_EMV_DATA otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_MONEY_ORDER NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_MONEY_ORDER otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_MONEY_TRANSFER NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_MONEY_TRANSFER otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_PAYROLL NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_PAYROLL otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- 17July2015

TNOX_DATA_PARTI
TNOX_DATA_PARTI_2


TNOX_INDX_PARTI
TNOX_INDX_PARTI_2




TRANSACTION
TRANS_DETAIL
TRANS_SETTLEMENT
TRANS_CARD
TRANS_RESPONSE_INFO
TRANS_ADDITIONAL_INFO
TRANS_BANK_DETAIL
TRANS_RETURN
TRANS_STATUS_HISTORY
TRANS_SIGNATURE_HISTORY
TRANS_SIGNATURE
TRANS_CHECK
TRANS_CHECK_CLEAR_AMOUNT
TRANS_CHECK_DEPOSITE
TRANS_COMPLIANCE_INFO
TRANS_EMV_DATA
TRANS_MONEY_ORDER
TRANS_MONEY_TRANSFER
TRANS_PAYROLL 


INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_DETAIL NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_DETAIL otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_SETTLEMENT NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_SETTLEMENT otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_CARD NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_CARD otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_RESPONSE_INFO NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_RESPONSE_INFO otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_ADDITIONAL_INFO NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_ADDITIONAL_INFO otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_BANK_DETAIL NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_BANK_DETAIL otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_RETURN NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_RETURN otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_STATUS_HISTORY NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_STATUS_HISTORY otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_SIGNATURE_HISTORY NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_SIGNATURE_HISTORY otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_SIGNATURE NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_SIGNATURE otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_CHECK NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_CHECK otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_CHECK_CLEAR_AMOUNT NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_CHECK_CLEAR_AMOUNT otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_CHECK_DEPOSITE NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_CHECK_DEPOSITE otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_COMPLIANCE_INFO NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_COMPLIANCE_INFO otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_EMV_DATA NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_EMV_DATA otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_MONEY_ORDER NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_MONEY_ORDER otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_MONEY_TRANSFER NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_MONEY_TRANSFER otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;

INSERT /*+ APPEND */  INTO PARTITION_TEST.TRANS_PAYROLL NOLOGGING
SELECT * FROM TRANSNOX_IOX.TRANS_PAYROLL otr WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.transaction inr WHERE inr.transaction_id = otr.transaction_id);

COMMIT;



TransIT is a platform for interfacing, processing and supporting multiple payment forms, payment services and systems management services.

The suite of Payment Acceptance product under TransIT platform includes
�CounterPASS
�WebPASS�Mobile Payment Acceptance
�MultiPASS (VAR) 
�TSYS Hosted Payment (THP)
�Mobile Payment Acceptance (MPA)

TransIT as a Payment Acceptance solution has various implementation across multiple industries.
TransIT solution implementation includes:
�Payment processing in Gaming industry - Casinos
�Customized Payment processing and Biometric authentication solution 
�VAR client for Payment Processing through MPA and PASS Products

TransIT Database Activities:
1. Oracle RAC implementation
2. Oracle Golden Gate implementation and maintenance
3. TransIT Release process automation through shell scripting
4. Performance tuning, AWR analysis and suggestions to development team
5. Responsibility of all the DBA activities from Dev, NR, QA, UAT, Perf and Production DBs in TransIT. 

-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- 16July2015

CREATE ROLE awr_user;

GRANT SELECT ON SYS.V_$DATABASE TO awr_user;
GRANT SELECT ON SYS.V_$INSTANCE TO awr_user;
GRANT EXECUTE ON SYS.DBMS_WORKLOAD_REPOSITORY TO awr_user;
GRANT SELECT ON SYS.DBA_HIST_DATABASE_INSTANCE TO awr_user;
GRANT SELECT ON SYS.DBA_HIST_SNAPSHOT TO awr_user;
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------


-- 15July2015

TRANSACTION
TRANS_SETTLEMENT
TRANS_CARD
TRANS_RESPONSE_INFO
TRANS_DETAIL
TRANS_ADDITIONAL_INFO
TRANS_BANK_DETAIL
TRANS_RETURN
TRANS_STATUS_HISTORY
TRANS_SIGNATURE_HISTORY
TRANS_SIGNATURE
TRANS_CHECK
TRANS_BILLING_ADDRESS
TRANS_CHECK_CLEAR_AMOUNT
TRANS_CHECK_DEPOSITE
TRANS_COMPLIANCE_INFO
TRANS_EMV_DATA
TRANS_MONEY_ORDER
TRANS_MONEY_TRANSFER
TRANS_PAYROLL 

REQUEST_AUDIT_TRAIL
REPORT_USAGE_AUDITTRAIL
TASK
DATABASE_EXEC_LOG_HSP


1) stop rpretw



INSERT /*+ APPEND */  INTO transnox_cpass.TRANSACTION1 NOLOGGING
SELECT * FROM transnox_cpass.TRANSACTION;

COMMIT;

INSERT /*+ APPEND */  INTO TRANSNOX_CPASS.TRANS_DETAIL1 NOLOGGING
SELECT * FROM TRANSNOX_CPASS.TRANS_DETAIL;

COMMIT;

INSERT /*+ APPEND */  INTO TRANSNOX_CPASS.TRANS_SETTLEMENT1 NOLOGGING
SELECT * FROM TRANSNOX_CPASS.TRANS_SETTLEMENT;


COMMIT;

INSERT /*+ APPEND */  INTO TRANSNOX_CPASS.TRANS_CARD1 NOLOGGING
SELECT * FROM TRANSNOX_CPASS.TRANS_CARD;

COMMIT;

INSERT /*+ APPEND */  INTO TRANSNOX_CPASS.TRANS_RESPONSE_INFO1 NOLOGGING
SELECT * FROM TRANSNOX_CPASS.TRANS_RESPONSE_INFO;

COMMIT;

INSERT /*+ APPEND */  INTO TRANSNOX_CPASS.TRANS_ADDITIONAL_INFO1 NOLOGGING
SELECT * FROM TRANSNOX_CPASS.TRANS_ADDITIONAL_INFO;

COMMIT;

INSERT /*+ APPEND */  INTO TRANSNOX_CPASS.Trans_Bank_Detail1 NOLOGGING
SELECT * FROM TRANSNOX_CPASS.Trans_Bank_Detail1;

COMMIT;

INSERT /*+ APPEND */  INTO TRANSNOX_CPASS.TRANS_RETURN1 NOLOGGING
SELECT * FROM TRANSNOX_CPASS.TRANS_RETURN;

COMMIT;

INSERT /*+ APPEND */  INTO TRANSNOX_CPASS.Trans_Emv_Data1 NOLOGGING
SELECT * FROM TRANSNOX_CPASS.Trans_Emv_Data1;

COMMIT;

ALTER TABLE TRANSACTION1 RENAME TO TRANSACTION;
ALTER TABLE TRANS_DETAIL1 RENAME TO TRANS_DETAIL;
ALTER TABLE TRANS_SETTLEMENT1 RENAME TO TRANS_SETTLEMENT;
ALTER TABLE TRANS_CARD1 RENAME TO TRANS_CARD;
ALTER TABLE TRANS_RESPONSE_INFO1 RENAME TO TRANS_RESPONSE_INFO;
ALTER TABLE TRANS_ADDITIONAL_INFO1 RENAME TO TRANS_ADDITIONAL_INFO;
ALTER TABLE Trans_Bank_Detail1 RENAME TO Trans_Bank_Detail;
ALTER TABLE TRANS_RETURN1 RENAME TO TRANS_RETURN;
ALTER TABLE Trans_Emv_Data1 RENAME TO Trans_Emv_Data;

EXEC DBMS_UTILITY.COMPILE_SCHEMA ('TRANSNOX_CPASS');
EXEC DBMS_UTILITY.COMPILE_SCHEMA ('SNOX4TRANSNOX_CPASS');
--EXEC DBMS_UTILITY.COMPILE_SCHEMA ('TRANSNOX_CPASS');
--EXEC DBMS_UTILITY.COMPILE_SCHEMA ('SNOX4TRANSNOX_CPASS');


-----------------------------------------------------------------------------------------------------------------------------------------------------------------------


-- 30Jun2015


--CREATE VIEW sequence_management AS


CREATE TABLE db_link (dblink_name VARCHAR2(30))


SELECT  'SELECT dce.sequence_owner, dcw.sequence_name,  dcw.increment_by dcw_increment_by, dce.increment_by dce_increment_by,
                        dcw.cache_size dcw_cache_size, dce.cache_size dce_cache_size, dcw.last_number  dcw_last_number, dce.last_number  dce_last_number, 
                        (dcw.last_number - dce.last_number) diff_sequences
                   FROM all_sequences@txnDCE  DCE, all_sequences DCW  
                  WHERE dce.sequence_owner = dcw.sequence_owner
                    AND dcw.sequence_name = dce.sequence_name
                    AND dce.sequence_owner IN (''TRANSNOX_CPASS'',''SNOX4TRANSNOX_CPASS'',''TRANSNOX_CAT'','')
                    AND dcw.sequence_name <> ''REQUEST_AUDIT_TRAIL_SEQ''
                  ORDER BY  diff_sequences DESC
                ' 
FROM dual 



SELECT  dce.sequence_owner, dcw.sequence_name,  dcw.increment_by dcw_increment_by, dce.increment_by dce_increment_by,
        dcw.cache_size dcw_cache_size, dce.cache_size dce_cache_size, dcw.last_number  dcw_last_number, dce.last_number  dce_last_number, 
        (dcw.last_number - dce.last_number) diff_sequences
FROM all_sequences@rptDCW  DCE, all_sequences DCW  
WHERE dce.sequence_owner = dcw.sequence_owner
  AND dcw.sequence_name = dce.sequence_name
  AND dce.sequence_owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS')
  AND dcw.sequence_name <> 'REQUEST_AUDIT_TRAIL_SEQ'
ORDER BY  diff_sequences DESC





  
SELECT *
FROM dba_sequences
WHERE sequence_name='REQUEST_AUDIT_TRAIL_SEQ'   
  

SELECT * 
FROM sequence_management 
WHERE SEQUENCE_NAME='SEQ_TASK_ID';
  

SELECT 'ALTER SEQUENCE '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||' INCREMENT BY '||DIFF_SEQUENCES||';' first_Step
FROM sequence_management 
WHERE diff_sequences<>0


SELECT 'SELECT '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||'.NEXTVAL FROM dual;' Second_step
FROM sequence_management 
WHERE diff_sequences<>0


SELECT 'ALTER SEQUENCE '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||' INCREMENT BY 2;' third_step
FROM sequence_management 
WHERE diff_sequences<>0



SELECT (SELECT last_number
        FROM dba_sequences@rptdcw
        WHERE sequence_owner='TRANSNOX_CPASS'
          AND UPPER(sequence_name) = UPPER('REQUEST_AUDIT_TRAIL_SEQ')) - (SELECT last_number
                                                                FROM dba_sequences
                                                                WHERE sequence_owner='TRANSNOX_CPASS' AND UPPER(sequence_name) = UPPER('REQUEST_AUDIT_TRAIL_SEQ')) increment_by
FROM dual;    




-- 29Jun2015
SELECT * FROM TRANSNOX_IOX.REPORT_INFORMATION WHERE REPORT_Id = 'API_CONCISE_XTN_RPT' 

/*+ no_index(xtn IDX_DEVICE_ID)*/


-- 25June2015

--CREATE  DATABASE LINK txnDCE
-- CONNECT TO RCHAUDHARI
-- IDENTIFIED BY "df"
-- USING '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.100.224.69)(PORT = 1521))  (CONNECT_DATA = (SERVER = DEDICATED)(INSTANCE_NAME=txnDCE1)(SERVICE_NAME=txnDCE)))';

SELECT * FROM transnox_cpass.TRANSACTION WHERE time_stamp >=SYSDATE -1
ORDER BY time_Stamp DESC


CREATE VIEW sequence_management AS
SELECT  dce.sequence_owner, dcw.sequence_name,  dcw.increment_by dcw_increment_by, dce.increment_by dce_increment_by,
        dcw.cache_size dcw_cache_size, dce.cache_size dce_cache_size, dcw.last_number  dcw_last_number, dce.last_number  dce_last_number, (dcw.last_number - dce.last_number) diff_sequences
FROM all_sequences@txnDCE  DCE, all_sequences DCW  
WHERE dce.sequence_owner = dcw.sequence_owner
  AND dcw.sequence_name = dce.sequence_name
  AND dce.sequence_owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS') 
  

SELECT * 
FROM sequence_management 
WHERE SEQUENCE_NAME='SEQ_TASK_ID';

SELECT 'ALTER SEQUENCE '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||' INCREMENT BY '||DIFF_SEQUENCES||';'
FROM sequence_management 
WHERE diff_sequences<>0

SELECT 'SELECT '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||'.NEXTVAL FROM dual;'
FROM sequence_management 
WHERE diff_sequences<>0

SELECT 'ALTER SEQUENCE '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||' INCREMENT BY 2;'
FROM sequence_management 
WHERE diff_sequences<>0

SELECT * FROM dba_users ORDER BY created DESC

SELECT  *
FROM dba_sequences@txnDCE DCE  
WHERE dce.sequence_owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS')   

ALTER SEQUENCE SEQ_TABLE_NUMBER START WITH 2204536 INCREMENT BY 2

0) Stop all Application Instances
1) Increment the txnDCW sequence to 1000 in all
2) Check the differences in txnDCW and txnDCE (all 4 for REPORT_USAGE_SEQ Sequence)
3) Make the same sequence number in txnDCW and txnDCE
4) Make the sequences of DCW as EVEN Number -- Inrement by 2
	 --- So in txnDCW increment the sequence number to even number and then alter the sequence to increment by 2;
	 --- 	
5) Make the sequences of DCE as ODD Number  -- Inrement by 2
	 --- So in txnDCE increment the sequence number to odd number and then alter the sequence to increment by 2;
	 --- for e.g create sequence customer_sequence start with 1 increment by 2;
	 
6) Increment REPORT_USAGE_SEQ Sequence in all dbs, Sequeunce should be all same numbers
		-- txnDCW - 1
		-- rptDCW - 2
		-- txnDCE - 3
		-- rptDCE - 4


-- 24Jun2015 

mkdir 2015
mkdir 2014
mkdir 2013
mkdir 2012
mkdir 2011
mkdir 2010
mkdir 2009
mkdir 2008
mkdir 2007
mkdir 2006


create or replace directory CAPONE_DOCS as '/ora11/oracle/capone_docs/2006';

grant read,write on directory CAPONE_DOCS to public;

2015	13167
2014	30027
2013	51893
2012	48814
2011	43622
2010	39048
2009	40169
2008	38137
2007	38620
2006	4487


DECLARE
  I_YEAR VARCHAR2(32767);
  O_OUTPUTMESSAGE VARCHAR2(32767);
BEGIN 
  I_YEAR := '2015';
  O_OUTPUTMESSAGE := NULL;
  RCHAUDHARI.CAPONE_DOWNLOAD_DOCS ( I_YEAR, O_OUTPUTMESSAGE );
  DBMS_OUTPUT.Put_Line('O_OUTPUTMESSAGE = ' || O_OUTPUTMESSAGE);
  DBMS_OUTPUT.Put_Line('');
  COMMIT; 
END;
/

SELECT  AMM.application_id||'-'||TO_CHAR(added_on_date,'mmddyyyyhh24miss')||'-'||sr_nr||'-'||AMD.FILE_NAME  NEW_FILE_NAME, COUNT(*) 
FROM TRANSCAPITALONE.APP_MER_DOCUMENTS AMD,
   TRANSCAPITALONE.APP_MERCHANT_MASTER AMM
WHERE AMD.APPLICATION_ID = AMM.APPLICATION_ID
  AND added_on_date BETWEEN TO_DATE('01/01/2015 00:00:00','mm/dd/yyyy hh24:mi:ss') AND TO_DATE('06/24/2015 00:00:00','mm/dd/yyyy hh24:mi:ss')
--  AND amm.mid IS  NULL
GROUP BY AMM.application_id||'-'||TO_CHAR(added_on_date,'mmddyyyyhh24miss')||'-'||sr_nr||'-'||AMD.FILE_NAME   
--ORDER BY TO_DATE(TO_CHAR(added_on_date,'MONYYYY'),'MONYYYY');
ORDER BY 2 DESC

SELECT SYSDATE FROM dual 

SELECT TO_CHAR(added_on_date,'yyyy'), COUNT(*) 
FROM TRANSCAPITALONE.APP_MER_DOCUMENTS 
--WHERE TO_CHAR(added_on_date,'yyyy') = '2006'
WHERE  added_on_date BETWEEN TO_DATE('01/01/2015 00:00:00','mm/dd/yyyy hh24:mi:ss') AND TO_DATE('06/24/2015 00:00:00','mm/dd/yyyy hh24:mi:ss')
GROUP BY TO_CHAR(added_on_date,'yyyy')
ORDER BY TO_DATE(TO_CHAR(added_on_date,'yyyy'),'yyyy') DESC





-- 22June2015

day_of_month=`date +"%e"`      # 1 thru 31
day_of_week=`date +"%u"`       #monday=1, Sunday=7
if [ $day_of_month -eq 1 ]
then
   do_monthly
   exit
fi

if [ $day_of_week -eq 7 ]
then
  do_weekly
  exit
fi
do_daily






-- 19/June/2015
 SELECT OBJECT_TYPE,STATUS,
         MAX(DECODE(VBS_NAME,'TRANSIT_GATEWAY_SNOX_317',CNT)) TRANSIT_GATEWAY_SNOX_317,
         MAX(DECODE(VBS_NAME,'TRANSIT_GATEWAY_SNOX_318',CNT)) TRANSIT_GATEWAY_SNOX_318
 FROM (        
     SELECT 'TRANSIT_GATEWAY_SNOX_318' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
     FROM DBA_OBJECTS 
     WHERE OWNER=UPPER('TRANSIT_GATEWAY_SNOX_318')
       AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
     GROUP BY OBJECT_TYPE,STATUS
        UNION ALL
     SELECT 'TRANSIT_GATEWAY_SNOX_317' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
     FROM DBA_OBJECTS 
     WHERE OWNER=UPPER('TRANSIT_GATEWAY_SNOX_317')
       AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
     GROUP BY OBJECT_TYPE,STATUS
      )
 GROUP BY OBJECT_TYPE,STATUS
 ORDER BY 1;
 
  
 SELECT OBJECT_TYPE,STATUS,
         MAX(DECODE(VBS_NAME,'TRANSIT_GATEWAY_TNOX_317',CNT)) TRANSIT_GATEWAY_TNOX_317,
         MAX(DECODE(VBS_NAME,'TRANSIT_GATEWAY_TNOX_318',CNT)) TRANSIT_GATEWAY_TNOX_318
 FROM (        
     SELECT 'TRANSIT_GATEWAY_TNOX_318' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
     FROM DBA_OBJECTS 
     WHERE OWNER=UPPER('TRANSIT_GATEWAY_TNOX_318')
       AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
     GROUP BY OBJECT_TYPE,STATUS
        UNION ALL
     SELECT 'TRANSIT_GATEWAY_TNOX_317' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
     FROM DBA_OBJECTS 
     WHERE OWNER=UPPER('TRANSIT_GATEWAY_TNOX_317')
       AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
     GROUP BY OBJECT_TYPE,STATUS
      )
 GROUP BY OBJECT_TYPE,STATUS
 ORDER BY 1;
 
 
 SELECT OBJECT_TYPE,STATUS,
         MAX(DECODE(VBS_NAME,'TRANSIT_SMSNOX_SNOX_317',CNT)) TRANSIT_SMSNOX_SNOX_317,
         MAX(DECODE(VBS_NAME,'TRANSIT_SMSNOX_SNOX_318',CNT)) TRANSIT_SMSNOX_SNOX_318
 FROM (        
     SELECT 'TRANSIT_SMSNOX_SNOX_318' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
     FROM DBA_OBJECTS 
     WHERE OWNER=UPPER('TRANSIT_SMSNOX_SNOX_318')
       AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
     GROUP BY OBJECT_TYPE,STATUS
        UNION ALL
     SELECT 'TRANSIT_SMSNOX_SNOX_317' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
     FROM DBA_OBJECTS 
     WHERE OWNER=UPPER('TRANSIT_SMSNOX_SNOX_317')
       AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
     GROUP BY OBJECT_TYPE,STATUS
      )
 GROUP BY OBJECT_TYPE,STATUS
 ORDER BY 1;
 
  
 SELECT OBJECT_TYPE,STATUS,
         MAX(DECODE(VBS_NAME,'TRANSIT_SMSNOX_TNOX_317',CNT)) TRANSIT_SMSNOX_TNOX_317,
         MAX(DECODE(VBS_NAME,'TRANSIT_SMSNOX_TNOX_318',CNT)) TRANSIT_SMSNOX_TNOX_318
 FROM (        
     SELECT 'TRANSIT_SMSNOX_TNOX_318' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
     FROM DBA_OBJECTS 
     WHERE OWNER=UPPER('TRANSIT_SMSNOX_TNOX_318')
       AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
     GROUP BY OBJECT_TYPE,STATUS
        UNION ALL
     SELECT 'TRANSIT_SMSNOX_TNOX_317' VBS_NAME,OBJECT_TYPE,STATUS,COUNT(1) CNT
     FROM DBA_OBJECTS 
     WHERE OWNER=UPPER('TRANSIT_SMSNOX_TNOX_317')
       AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
     GROUP BY OBJECT_TYPE,STATUS
      )
 GROUP BY OBJECT_TYPE,STATUS
 ORDER BY 1;



 impdp rchaudhari directory=bkup dumpfile=expdp_ddltables_new_vbs_18June2015.dmp logfile=impdp100_expdp_ddl_for_new_vbs_18June2015.log remap_schema=TRANSIT_GATEWAY_SNOX_317:TRANSIT_GATEWAY_SNOX_318

, &
-- VBS Used in Release Date 21June2015
                 EXCLUDE OBJNAME TRANSIT_GATEWAY_TNOX_318.SN_TEMP*, EXCLUDE OBJNAME TRANSIT_GATEWAY_TNOX_318.SC_TEMP*, &
                 EXCLUDE OBJNAME TRANSIT_GATEWAY_SNOX_318.SN_TEMP*, EXCLUDE OBJNAME TRANSIT_GATEWAY_SNOX_318.SC_TEMP*, &
                 EXCLUDE OBJNAME TRANSIT_SMSNOX_TNOX_318.SN_TEMP*, EXCLUDE OBJNAME TRANSIT_SMSNOX_TNOX_318.SC_TEMP*, &
                 EXCLUDE OBJNAME TRANSIT_SMSNOX_SNOX_318.SN_TEMP*, EXCLUDE OBJNAME TRANSIT_SMSNOX_SNOX_318.SC_TEMP*






-- VBS Schemas for Released Date 21June2015
TABLEEXCLUDE TRANSIT_SMSNOX_TNOX_318.MV*
TABLE TRANSIT_SMSNOX_TNOX_318.*;
TABLEEXCLUDE TRANSIT_SMSNOX_SNOX_318.MV*
TABLE TRANSIT_SMSNOX_SNOX_318.*;
TABLEEXCLUDE TRANSIT_GATEWAY_SNOX_318.MV*
TABLEEXCLUDE TRANSIT_GATEWAY_SNOX_318.SN_TEMP*
TABLEEXCLUDE TRANSIT_GATEWAY_SNOX_318.SC_TEMP*
TABLE TRANSIT_GATEWAY_SNOX_318.*;
TABLEEXCLUDE TRANSIT_GATEWAY_TNOX_318.MV*
TABLEEXCLUDE TRANSIT_GATEWAY_TNOX_318.SN_TEMP*
TABLEEXCLUDE TRANSIT_GATEWAY_TNOX_318.SC_TEMP*
TABLE TRANSIT_GATEWAY_TNOX_318.*;






-- VBS for Release Date 21June2015
TABLE TRANSIT_SMSNOX_TNOX_318.*;
TABLE TRANSIT_SMSNOX_SNOX_318.*;
TABLE TRANSIT_GATEWAY_SNOX_318.*;
TABLE TRANSIT_GATEWAY_TNOX_318.*;


-- VBS for Release Date 21June2015
MAP TRANSIT_SMSNOX_TNOX_318.*, TARGET TRANSIT_SMSNOX_TNOX_318.*;
MAP TRANSIT_SMSNOX_SNOX_318.*, TARGET TRANSIT_SMSNOX_SNOX_318.*;
MAPEXCLUDE TRANSIT_GATEWAY_SNOX_318.SN_TEMP*
MAPEXCLUDE TRANSIT_GATEWAY_SNOX_318.SC_TEMP*
MAP TRANSIT_GATEWAY_SNOX_318.*, TARGET TRANSIT_GATEWAY_SNOX_318.*;
MAPEXCLUDE TRANSIT_GATEWAY_TNOX_318.SN_TEMP*
MAPEXCLUDE TRANSIT_GATEWAY_TNOX_318.SC_TEMP*
MAP TRANSIT_GATEWAY_TNOX_318.*, TARGET TRANSIT_GATEWAY_TNOX_318.*;






---------------------------------------------------------------------------------------------------------------------------------------------
-- Start of Work 18/Jun/2015


TRANS_CARD_HISTORY			18.5517578125
TRANS_RESPONSE_INFO			18.0341796875
TRANS_DETAIL				16.9365234375
TRANSACTION					15.966796875
TRANS_SCORE					15.904296875
TRANS_CARD					15.5830078125
REQUEST_AUDIT_TRAIL			12.7705078125
TASK						11.01171875
REPORT_USAGE_AUDITTRAIL		8.4775390625
TRANS_SETTLEMENT			5.1162109375
TRANS_STATUS_HISTORY		4.13671875
TAS_SETTLEMENT_HISTORY		1.66796875
TRANS_ENHANCED_DATA			1.54296875
SNOX_SETTLEMENT_BATCH		1.1376953125 


SELECT * FROM TRANS_ENHANCED_DATA WHERE ORDER_DATE IS NULL

select * from transaction where transaction_id=12771


CREATE TABLESPACE TNOX_DATA_PARTI_2 DATAFILE 
  '+ASMRPTDATA' SIZE 5G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 5G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;



CREATE TABLESPACE TNOX_INDX_PARTI DATAFILE 
  '+ASMRPTDATA' SIZE 5G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF,
  '+ASMRPTDATA' SIZE 2G AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1M
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;


drop user part_tbls



create user partition_test identified by "ispl$2015" default tablespace TNOX_DATA_PARTI temporary tablespace temp


GRANT CREATE SESSION,RESOURCE TO partition_test


select min(time_stamp) from transnox_iox.transaction

alter session set current_Schema=partition_test




CREATE TABLE PARTITION_TEST.TRANSACTION
TABLESPACE TNOX_DATA_PARTI
PARTITION BY RANGE (TIME_STAMP)
(
    PARTITION FRIST_PART VALUES LESS THAN (TO_DATE('01-FEB-2009', 'DD-MON-YYYY'))
)
AS
SELECT * FROM TRANSNOX_IOX.TRANSACTION


alter tablespace TNOX_DATA_PARTI rename to TNOX_DATA_PART 


CREATE TABLE PARTITION_TEST.TRANSACTION
tablespace TNOX_DATA_PARTI
PARTITION BY RANGE (TIME_STAMP)
(
    PARTITION Part_200902 VALUES LESS THAN (TO_DATE('01-FEB-2009', 'DD-MON-YYYY')),
    PARTITION Part_200903 VALUES LESS THAN (TO_DATE('01-MAR-2009', 'DD-MON-YYYY')),
    PARTITION Part_200904 VALUES LESS THAN (TO_DATE('01-APR-2009', 'DD-MON-YYYY')),
    PARTITION Part_200905 VALUES LESS THAN (TO_DATE('01-MAY-2009', 'DD-MON-YYYY')),
    PARTITION Part_200906 VALUES LESS THAN (TO_DATE('01-JUN-2009', 'DD-MON-YYYY')),
    PARTITION Part_200907 VALUES LESS THAN (TO_DATE('01-JUL-2009', 'DD-MON-YYYY')),
    PARTITION Part_200908 VALUES LESS THAN (TO_DATE('01-AUG-2009', 'DD-MON-YYYY')),
    PARTITION Part_200909 VALUES LESS THAN (TO_DATE('01-SEP-2009', 'DD-MON-YYYY')),
    PARTITION Part_200910 VALUES LESS THAN (TO_DATE('01-OCT-2009', 'DD-MON-YYYY')),
    PARTITION Part_200911 VALUES LESS THAN (TO_DATE('01-NOV-2009', 'DD-MON-YYYY')),
    PARTITION Part_200912 VALUES LESS THAN (TO_DATE('01-DEC-2009', 'DD-MON-YYYY')),
    PARTITION Part_201001 VALUES LESS THAN (TO_DATE('01-JAN-2010', 'DD-MON-YYYY')),
    PARTITION Part_201002 VALUES LESS THAN (TO_DATE('01-FEB-2010', 'DD-MON-YYYY')),
    PARTITION Part_201003 VALUES LESS THAN (TO_DATE('01-MAR-2010', 'DD-MON-YYYY')),
    PARTITION Part_201004 VALUES LESS THAN (TO_DATE('01-APR-2010', 'DD-MON-YYYY')),
    PARTITION Part_201005 VALUES LESS THAN (TO_DATE('01-MAY-2010', 'DD-MON-YYYY')),
    PARTITION Part_201006 VALUES LESS THAN (TO_DATE('01-JUN-2010', 'DD-MON-YYYY')),
    PARTITION Part_201007 VALUES LESS THAN (TO_DATE('01-JUL-2010', 'DD-MON-YYYY')),
    PARTITION Part_201008 VALUES LESS THAN (TO_DATE('01-AUG-2010', 'DD-MON-YYYY')),
    PARTITION Part_201009 VALUES LESS THAN (TO_DATE('01-SEP-2010', 'DD-MON-YYYY')),
    PARTITION Part_201010 VALUES LESS THAN (TO_DATE('01-OCT-2010', 'DD-MON-YYYY')),
    PARTITION Part_201011 VALUES LESS THAN (TO_DATE('01-NOV-2010', 'DD-MON-YYYY')),
    PARTITION Part_201012 VALUES LESS THAN (TO_DATE('01-DEC-2010', 'DD-MON-YYYY')),
    PARTITION Part_201101 VALUES LESS THAN (TO_DATE('01-JAN-2011', 'DD-MON-YYYY')),
    PARTITION Part_201102 VALUES LESS THAN (TO_DATE('01-FEB-2011', 'DD-MON-YYYY')),
    PARTITION Part_201103 VALUES LESS THAN (TO_DATE('01-MAR-2011', 'DD-MON-YYYY')),
    PARTITION Part_201104 VALUES LESS THAN (TO_DATE('01-APR-2011', 'DD-MON-YYYY')),
    PARTITION Part_201105 VALUES LESS THAN (TO_DATE('01-MAY-2011', 'DD-MON-YYYY')),
    PARTITION Part_201106 VALUES LESS THAN (TO_DATE('01-JUN-2011', 'DD-MON-YYYY')),
    PARTITION Part_201107 VALUES LESS THAN (TO_DATE('01-JUL-2011', 'DD-MON-YYYY')),
    PARTITION Part_201108 VALUES LESS THAN (TO_DATE('01-AUG-2011', 'DD-MON-YYYY')),
    PARTITION Part_201109 VALUES LESS THAN (TO_DATE('01-SEP-2011', 'DD-MON-YYYY')),
    PARTITION Part_201110 VALUES LESS THAN (TO_DATE('01-OCT-2011', 'DD-MON-YYYY')),
    PARTITION Part_201111 VALUES LESS THAN (TO_DATE('01-NOV-2011', 'DD-MON-YYYY')),
    PARTITION Part_201112 VALUES LESS THAN (TO_DATE('01-DEC-2011', 'DD-MON-YYYY')),
    PARTITION Part_201201 VALUES LESS THAN (TO_DATE('01-JAN-2012', 'DD-MON-YYYY')),
    PARTITION Part_201202 VALUES LESS THAN (TO_DATE('01-FEB-2012', 'DD-MON-YYYY')),
    PARTITION Part_201203 VALUES LESS THAN (TO_DATE('01-MAR-2012', 'DD-MON-YYYY')),
    PARTITION Part_201204 VALUES LESS THAN (TO_DATE('01-APR-2012', 'DD-MON-YYYY')),
    PARTITION Part_201205 VALUES LESS THAN (TO_DATE('01-MAY-2012', 'DD-MON-YYYY')),
    PARTITION Part_201206 VALUES LESS THAN (TO_DATE('01-JUN-2012', 'DD-MON-YYYY')),
    PARTITION Part_201207 VALUES LESS THAN (TO_DATE('01-JUL-2012', 'DD-MON-YYYY')),
    PARTITION Part_201208 VALUES LESS THAN (TO_DATE('01-AUG-2012', 'DD-MON-YYYY')),
    PARTITION Part_201209 VALUES LESS THAN (TO_DATE('01-SEP-2012', 'DD-MON-YYYY')),
    PARTITION Part_201210 VALUES LESS THAN (TO_DATE('01-OCT-2012', 'DD-MON-YYYY')),
    PARTITION Part_201211 VALUES LESS THAN (TO_DATE('01-NOV-2012', 'DD-MON-YYYY')),
    PARTITION Part_201212 VALUES LESS THAN (TO_DATE('01-DEC-2012', 'DD-MON-YYYY')),
    PARTITION Part_201301 VALUES LESS THAN (TO_DATE('01-JAN-2013', 'DD-MON-YYYY')),
    PARTITION Part_201302 VALUES LESS THAN (TO_DATE('01-FEB-2013', 'DD-MON-YYYY')),
    PARTITION Part_201303 VALUES LESS THAN (TO_DATE('01-MAR-2013', 'DD-MON-YYYY')),
    PARTITION Part_201304 VALUES LESS THAN (TO_DATE('01-APR-2013', 'DD-MON-YYYY')),
    PARTITION Part_201305 VALUES LESS THAN (TO_DATE('01-MAY-2013', 'DD-MON-YYYY')),
    PARTITION Part_201306 VALUES LESS THAN (TO_DATE('01-JUN-2013', 'DD-MON-YYYY')),
    PARTITION Part_201307 VALUES LESS THAN (TO_DATE('01-JUL-2013', 'DD-MON-YYYY')),
    PARTITION Part_201308 VALUES LESS THAN (TO_DATE('01-AUG-2013', 'DD-MON-YYYY')),
    PARTITION Part_201309 VALUES LESS THAN (TO_DATE('01-SEP-2013', 'DD-MON-YYYY')),
    PARTITION Part_201310 VALUES LESS THAN (TO_DATE('01-OCT-2013', 'DD-MON-YYYY')),
    PARTITION Part_201311 VALUES LESS THAN (TO_DATE('01-NOV-2013', 'DD-MON-YYYY')),
    PARTITION Part_201312 VALUES LESS THAN (TO_DATE('01-DEC-2013', 'DD-MON-YYYY')),
    PARTITION Part_201401 VALUES LESS THAN (TO_DATE('01-JAN-2014', 'DD-MON-YYYY')),
    PARTITION Part_201402 VALUES LESS THAN (TO_DATE('01-FEB-2014', 'DD-MON-YYYY')),
    PARTITION Part_201403 VALUES LESS THAN (TO_DATE('01-MAR-2014', 'DD-MON-YYYY')),
    PARTITION Part_201404 VALUES LESS THAN (TO_DATE('01-APR-2014', 'DD-MON-YYYY')),
    PARTITION Part_201405 VALUES LESS THAN (TO_DATE('01-MAY-2014', 'DD-MON-YYYY')),
    PARTITION Part_201406 VALUES LESS THAN (TO_DATE('01-JUN-2014', 'DD-MON-YYYY')),
    PARTITION Part_201407 VALUES LESS THAN (TO_DATE('01-JUL-2014', 'DD-MON-YYYY')),
    PARTITION Part_201408 VALUES LESS THAN (TO_DATE('01-AUG-2014', 'DD-MON-YYYY')),
    PARTITION Part_201409 VALUES LESS THAN (TO_DATE('01-SEP-2014', 'DD-MON-YYYY')),
    PARTITION Part_201410 VALUES LESS THAN (TO_DATE('01-OCT-2014', 'DD-MON-YYYY')),
    PARTITION Part_201411 VALUES LESS THAN (TO_DATE('01-NOV-2014', 'DD-MON-YYYY')),
    PARTITION Part_201412 VALUES LESS THAN (TO_DATE('01-DEC-2014', 'DD-MON-YYYY')),
    PARTITION Part_201501 VALUES LESS THAN (TO_DATE('01-JAN-2015', 'DD-MON-YYYY')),
    PARTITION Part_201502 VALUES LESS THAN (TO_DATE('01-FEB-2015', 'DD-MON-YYYY')),
    PARTITION Part_201503 VALUES LESS THAN (TO_DATE('01-MAR-2015', 'DD-MON-YYYY')),
    PARTITION Part_201504 VALUES LESS THAN (TO_DATE('01-APR-2015', 'DD-MON-YYYY')),
    PARTITION Part_201505 VALUES LESS THAN (TO_DATE('01-MAY-2015', 'DD-MON-YYYY')),
    PARTITION Part_201506 VALUES LESS THAN (TO_DATE('01-JUN-2015', 'DD-MON-YYYY')),
    PARTITION Part_201507 VALUES LESS THAN (TO_DATE('01-JUL-2015', 'DD-MON-YYYY')),
    PARTITION Part_201508 VALUES LESS THAN (TO_DATE('01-AUG-2015', 'DD-MON-YYYY')),
    PARTITION Part_201509 VALUES LESS THAN (TO_DATE('01-SEP-2015', 'DD-MON-YYYY')),
    PARTITION Part_201510 VALUES LESS THAN (TO_DATE('01-OCT-2015', 'DD-MON-YYYY')),
    PARTITION Part_201511 VALUES LESS THAN (TO_DATE('01-NOV-2015', 'DD-MON-YYYY')),
    PARTITION Part_201512 VALUES LESS THAN (TO_DATE('01-DEC-2015', 'DD-MON-YYYY'))
)
AS
SELECT * FROM transnox_iox.TRANSACTION;


CREATE INDEX PARTITION_TEST.IDX_DEVICE_ID19 ON PARTITION_TEST.TRANSACTION
(DEVICE_ID)
LOGGING
TABLESPACE TNOX_INDX_PARTI;
fk_trans_response_info_xtns

CREATE INDEX PARTITION_TEST.IDX_TRANSACTION_TIME_STAMP ON PARTITION_TEST.TRANSACTION
(TIME_STAMP)
  TABLESPACE TNOX_INDX_PARTI
LOGGING
LOCAL;

CREATE INDEX PARTITION_TEST.IDX_TXN_MTS_DEVID12 ON PARTITION_TEST.TRANSACTION
(LAST_MODIFIED_TIME_STAMP, DEVICE_ID, TRANSACTION_ID)
LOGGING
TABLESPACE TNOX_INDX_PARTI;


CREATE INDEX PARTITION_TEST.IDX_XTN_LMTS ON PARTITION_TEST.TRANSACTION
(LAST_MODIFIED_TIME_STAMP)
NOLOGGING
TABLESPACE INDX;


CREATE INDEX PARTITION_TEST.IDX_XTN_TYP_STAT ON PARTITION_TEST.TRANSACTION
(TRANS_TYPE, TRANS_STATUS)
LOGGING
TABLESPACE TNOX_INDX_PARTI;


CREATE UNIQUE INDEX PARTITION_TEST.PK_TRANSACTION12 ON PARTITION_TEST.TRANSACTION
(TRANSACTION_ID)
NOLOGGING
TABLESPACE TNOX_INDX_PARTI;


ALTER TABLE PARTITION_TEST.TRANSACTION ADD (
  CONSTRAINT PK_TRANSACTION12
  PRIMARY KEY
  (TRANSACTION_ID)
  USING INDEX PARTITION_TEST.PK_TRANSACTION12
  ENABLE VALIDATE);





select  TO_char(time_stamp, 'DD-MON-YYYY'), count(*) from transnox_iox.transaction group by TO_char(time_stamp, 'DD-MON-YYYY')



PARTITION_TEST.TRANSACTION


ALTER SESSION SET CURRENT_SCHEMA=partition_test

DROP  TABLE PARTITION_TEST.TRANS_DETAIL121

CREATE TABLE PARTITION_TEST.TRANS_DETAIL121
(
  TRANSACTION_ID                NUMBER          NOT NULL,
  POST_TYPE                     VARCHAR2(20 BYTE) DEFAULT NULL,
  SERVICE_CODE                  VARCHAR2(20 BYTE) DEFAULT NULL,
  SUBSERVICE_CODE               VARCHAR2(20 BYTE) DEFAULT NULL,
  REQUESTED_AMOUNT              NUMBER,
  PROMO_CODE                    VARCHAR2(50 BYTE),
  PROMO_MESSAGE                 VARCHAR2(200 BYTE),
  CLIENT_REF_NUMBER             VARCHAR2(100 BYTE),
  ACCEPT_FLAG                   VARCHAR2(10 BYTE),
  TAXES                         VARCHAR2(20 BYTE),
  TIP                           NUMBER,
  CASHBACK_AMOUNT               NUMBER,
  AUTH_AMOUNT                   NUMBER,
  AUTHORIZED_TIP                NUMBER,
  TRANSACTION_SOURCE            VARCHAR2(50 BYTE),
  APP_DEVELOPER_ID              VARCHAR2(50 BYTE),
  APP_VERSION_ID                VARCHAR2(50 BYTE),
  ORIG_AUTH_TIP                 NUMBER,
  INVOICE_NUMBER                VARCHAR2(50 BYTE),
  ACTION_REASON                 VARCHAR2(50 BYTE),
  ACTION_REASON_TYPE            VARCHAR2(50 BYTE),
  ENCRYPTION_TYPE               VARCHAR2(20 BYTE),
  OTP                           VARCHAR2(50 BYTE),
  FCS_ID                        VARCHAR2(7 BYTE),
  EBT_VOUCHER_NUMBER            VARCHAR2(15 BYTE),
  EBT_VOUCHER_APPROVAL_CODE     VARCHAR2(6 BYTE),
  COMBINED_REFUND_POLICY        VARCHAR2(400 BYTE),
  LOCATION_DETAIL_NAME          VARCHAR2(100 BYTE),
  LOCATION_DETAIL_ADDRESS       VARCHAR2(38 BYTE),
  LOCATION_DETAIL_REGION_CODE   VARCHAR2(3 BYTE),
  LOCATION_DETAIL_COUNTRY_CODE  VARCHAR2(3 BYTE),
  LOCATION_DETAIL_CITY          VARCHAR2(21 BYTE),
  LOCATION_DETAIL_POSTAL_CODE   VARCHAR2(15 BYTE),
  ORIGINAL_TRANSACTION_ID       NUMBER,
  CONSENT_VALUE                 VARCHAR2(5 BYTE),
  NOTIFYEMAILID                 VARCHAR2(550 BYTE),
  TOTAL_DISCOUNT_AMOUNT         NUMBER,
  CHECKOUT_ID                   VARCHAR2(100 BYTE),
  SOFT_DESCRIPTOR               VARCHAR2(25 BYTE),
  RETURN_REASON                 VARCHAR2(50 BYTE),
  PAYMENT_FACILITATOR_ID        VARCHAR2(12 BYTE),
  PAYMENT_FACILITATOR_NAME      VARCHAR2(3 BYTE),
  SUB_MERCHANT_ID               VARCHAR2(15 BYTE),
  ISO_ID                        VARCHAR2(11 BYTE),
  PAYMENT_APP_VERSION           VARCHAR2(15 BYTE),
  EMV_FALLBACK_CONDITION        VARCHAR2(30 BYTE),
  LAST_CHIP_READ                VARCHAR2(30 BYTE),
  SUB_MERCHANT_NAME             VARCHAR2(25 BYTE),
  SUB_MERCHANT_COUNTRY_CODE     VARCHAR2(3 BYTE),
  SUB_MERCHANT_STATE_CODE       VARCHAR2(2 BYTE),
  SUB_MERCHANT_CITY             VARCHAR2(50 BYTE),
  SUB_MERCHANT_POSTAL_CODE      VARCHAR2(15 BYTE),
  CONSTRAINT fk_xtns_id_xtns121 FOREIGN KEY (Transaction_ID) REFERENCES TRANSACTION(Transaction_id)
)
TABLESPACE TNOX_DATA_PARTI
LOGGING 
NOCOMPRESS
PARTITION BY REFERENCE(fk_xtns_id_xtns121);

ALTER SESSION SET CURRENT_SCHEMA=partition_test


CREATE TABLE PARTITION_TEST.TRANS_RESPONSE_INFO
(
  TRANSACTION_ID              NUMBER  NOT NULL,
  EXTERNAL_TRANSACTION_ID     VARCHAR2(40 BYTE),
  APPROVAL_CODE               VARCHAR2(15 BYTE),
  ADDR_VRFY_CODE              VARCHAR2(10 BYTE),
  CVV2_VRFY_CODE              VARCHAR2(10 BYTE),
  ACI                         VARCHAR2(10 BYTE),
  MARKET_SPEC_DATA            VARCHAR2(10 BYTE),
  VALIDATION_CODE             VARCHAR2(10 BYTE),
  COMMERCIAL_CARD             VARCHAR2(10 BYTE),
  VISA_CARD_LEVEL             VARCHAR2(10 BYTE),
  PROCESSOR_CODE              VARCHAR2(20 BYTE),
  SETTLEMENT_DATE             DATE,
  SYS_TRACE_AUDIT_NUMBER      VARCHAR2(16 BYTE),
  NETWORK_ID_CODE             VARCHAR2(8 BYTE),
  HOST_MSG_ID                 VARCHAR2(16 BYTE),
  TRAN_TIMESTAMP              DATE,
  LOCAL_TRAN_TIMESTAMP        DATE,
  HOST_SEQUENCE_NUMBER        VARCHAR2(12 BYTE),
  AUTH_SRC_CODE               VARCHAR2(8 BYTE),
  SUB_SERVICE_CODE            VARCHAR2(30 BYTE),
  ACCT_DATA_SOURCE            VARCHAR2(50 BYTE),
  HARMONY_TRAN_ID             VARCHAR2(25 BYTE),
  HOST_RESPONSE_CODE          VARCHAR2(30 BYTE),
  PORC_MERCHANT_ID            VARCHAR2(20 BYTE),
  PROCESSOR_TERM              VARCHAR2(20 BYTE),
  TRANSACTION_CODE            VARCHAR2(10 BYTE),
  FE_TERMINAL_ID              VARCHAR2(20 BYTE),
  CARD_PRODUCT_TYPE           VARCHAR2(50 BYTE),
  CARD_PRODUCT_DESC           VARCHAR2(200 BYTE),
  BILLINGZIP_VRFY_CODE        VARCHAR2(2 BYTE),
  BILLINGSTREET_MATCH_CODE    VARCHAR2(2 BYTE),
  BILLINGNAME_MATCH_CODE      VARCHAR2(2 BYTE),
  TELEPHONENUMBER_MATCH_CODE  VARCHAR2(2 BYTE),
  EMAILADDR_MATCH_CODE        VARCHAR2(2 BYTE),
  SIC_CODE                    VARCHAR2(12 BYTE),
  REIMBURSE_ATTR              VARCHAR2(15 BYTE),
  POS_DATA_CODE               VARCHAR2(15 BYTE),
  SPEND_QUALIFIED_INDICATOR   VARCHAR2(10 BYTE),
  CARDHOLDER_VRFY_CODE        VARCHAR2(10 BYTE),
  CONSTRAINT fk_trans_response_info_xtns FOREIGN KEY (TRANSACTION_ID) REFERENCES TRANSACTION(TRANSACTION_ID)
)
TABLESPACE TNOX_DATA_PARTI_2
LOGGING 
NOCOMPRESS
PARTITION BY REFERENCE(fk_trans_response_info_xtns)


INSERT /*+ APPEND */ INTO PARTITION_TEST.TRANS_RESPONSE_INFO NOLOGGING
SELECT  *
FROM transnox_iox.TRANS_RESPONSE_INFO td
WHERE EXISTS (SELECT 1 FROM PARTITION_TEST.TRANSACTION xtn WHERE xtn.transaction_id = td.transaction_id 
                                                             AND xtn.TIME_STAMP <= TO_DATE('7/02/2015 04:59:59','mm/dd/yyyy hh24:mi:ss'))



SELECT MAX(time_stamp) FROM PARTITION_TEST.TRANSACTION



ALTER TABLESPACE TNOX_DATA_PARTI ADD DATAFILE '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF

ALTER TABLESPACE TNOX_DATA_PARTI_2 ADD DATAFILE '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF

ALTER TABLESPACE TNOX_INDX_PARTI ADD DATAFILE '+ASMRPTDATA' SIZE 2G AUTOEXTEND OFF




CREATE TABLE PARTITION_TEST.TRANS_SETTLEMENT
TABLESPACE TNOX_DATA_PARTI_2
PARTITION BY RANGE (TIMESTAMP)
INTERVAL( NUMTOYMINTERVAL(1,'MONTH'))
(  
  PARTITION First_Partition VALUES LESS THAN (TO_DATE('02-01-2009 00:00:00', 'MM-DD-YYYY HH24:mi:ss'))
    TABLESPACE TNOX_DATA_PARTI_2
)
AS
SELECT * FROM  transnox_iox.TRANS_SETTLEMENT


SELECT MIN (TIMESTAMP) FROM transnox_iox.TRANS_SETTLEMENT



SELECT SYSDATE, MAX(time_stamp) FROM transnox_iox.TRANSACTION

SELECT SYSDATE FROM dual


SELECT * FROM partition_test.TRANSACTION WHERE time_stamp > TO_DATE('6/18/2015 2:40:15','mm/dd/yyyy hh24:mi:ss')


SELECT SYSDATE FROM dual 



INSERT /*+ APPEND */ INTO PARTITION_TEST.TRANS_DETAIL NOLOGGING
SELECT  *
FROM transnox_iox.TRANS_DETAIL td
WHERE EXISTS (SELECT 1 FROM transnox_iox.TRANSACTION xtn
              WHERE xtn.transaction_id = td.transaction_id 
                AND xtn.time_stamp > TO_DATE('6/18/2015 2:40:15','mm/dd/yyyy hh24:mi:ss')
                AND xtn.time_stamp <= TO_DATE('7/02/2015 04:59:59','mm/dd/yyyy hh24:mi:ss'))



INSERT  /*+ APPEND */ INTO PARTITION_TEST.TRANSACTION NOLOGGING
SELECT *
FROM transnox_iox.TRANSACTION xtns
WHERE xtns.time_stamp > TO_DATE('6/18/2015 2:40:15','mm/dd/yyyy hh24:mi:ss')
  AND xtns.time_stamp <= TO_DATE('7/02/2015 04:59:59','mm/dd/yyyy hh24:mi:ss')

COMMIT
  



TRANSNOX_IOX.TRANS_CARD_HISTORY       19 -- partition can be done on timestamp(9)
TRANSNOX_IOX.TRANS_RESPONSE_INFO      19 -- no partition as all three date columns are nullable columns and present null data
TRANSNOX_IOX.TRANS_DETAIL             17 -- no date column, so reference partition is created based on transaction table

TRANSNOX_IOX.TRANSACTION              16 -- partition can be done on TIME_STAMP
TRANSNOX_IOX.TRANS_SCORE              16 -- partition can be done on TIME_STAMP
TRANSNOX_IOX.TRANS_CARD               16 -- partition can be done on TIMESTAMP
TRANSNOX_IOX.REQUEST_AUDIT_TRAIL      13 -- partition can be done on SERVER_TIMESTAMP
TRANSNOX_IOX.TASK                     12 -- partition can be done on TIME_STAMP
TRANSNOX_IOX.REPORT_USAGE_AUDITTRAIL  9  -- partition can be done on START_DATE
TRANSNOX_IOX.TRANS_SETTLEMENT         6  -- partition can be done on TIMESTAMP
TRANSNOX_IOX.TRANS_STATUS_HISTORY     4  -- partition can be done on DATE_UPDATED
 



-- End of Work 18/Jun/2015
---------------------------------------------------------------------------------------------------------------------------------------------
  
-- 319 pass from performance db
TRANSIT_FE_SNOX_319 "TRANSIT_FE_SNOX_319_prfrmnc"
TRANSIT_FE_TNOX_319 "TRANSIT_FE_TNOX_319_prfrmnc"
TRANSIT_GATEWAY_SNOX_319 "TRANSIT_GATEWAY_SNOX_319_prfr"
TRANSIT_GATEWAY_TNOX_319 "TRANSIT_GATEWAY_TNOX_319_prfr"
TRANSIT_SMSNOX_SNOX_319 "TRANSIT_SMSNOX_SNOX_319_prfr"
TRANSIT_SMSNOX_TNOX_319 "TRANSIT_SMSNOX_TNOX_319_prfr"


SYS_P2531709	TO_DATE(' 2015-04-29 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	2446257	3175115	0	4/29/2015 2:26:34 AM	0	0
SYS_P2531529	TO_DATE(' 2015-04-22 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	2424850	3148262	0	4/24/2015 2:50:19 AM	0	0
SYS_P2531349	TO_DATE(' 2015-04-15 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	2380341	3051462	0	4/15/2015 2:30:33 AM	0	0
SYS_P2531189	TO_DATE(' 2015-04-08 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	2074543	2610300	0	4/8/2015 2:24:33 AM	0	0
SYS_P2531029	TO_DATE(' 2015-04-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	2045277	2483323	0	4/1/2015 2:22:53 AM	0	0
SYS_P2530889	TO_DATE(' 2015-03-25 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1933580	2311974	0	3/25/2015 2:17:43 AM	0	0
SYS_P2530709	TO_DATE(' 2015-03-18 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	2127074	2505957	0	3/18/2015 2:34:01 AM	0	0
SYS_P2530529	TO_DATE(' 2015-03-11 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1887113	2209547	0	3/11/2015 4:00:29 AM	0	0
SYS_P2530349	TO_DATE(' 2015-03-04 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1944248	2255325	0	3/4/2015 2:25:35 AM	0	0


ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2531709 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2531529 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2531349 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2531189 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2531029 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2530889 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2530709 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2530529 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P2530349 UPDATE INDEXES;

ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2531709 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2531529 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2531349 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2531189 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2531029 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2530889 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2530709 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2530529 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P2530349 UPDATE INDEXES;




ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P10486 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P10366 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P10246 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P10126 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P10006 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P9846 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P9706 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P9514 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P9426 UPDATE INDEXES;

ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P10486 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P10366 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P10246 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P10126 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P10006 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P9846 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P9706 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P9514 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P9426 UPDATE INDEXES;





ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P10183 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P10003 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P9843 UPDATE INDEXES;






('ETLUPDATE','KEYNOX_CPASS','KEYNOX_FX','PURGEDATA','SEQUENCE_REPL','TRANSITHA','SNOX4TRANSNOX_APP','SNOX4TRANSNOX_CPASS','SNOXPASS_GWAY_00526',
 'SNOXPASS_GWAY_00531','SNOXPASS_GWAY_008','SNOXPASS_GWAY_013','SNOXPASS_GWAY_014','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_306','SNOXPASS_SMSNOX_307',
 'SNOXPASS_TFE_2017','SNOXPASS_TFE_2018','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_013','TNOXPASS_GWAY_014','TNOXPASS_SMSNOX_305','TNOXPASS_SMSNOX_306',
 'TNOXPASS_SMSNOX_307','TNOXPASS_TFE_2015','TNOXPASS_TFE_2016','TNOXPASS_TFE_2017','TNOXPASS_TFE_2018','TRANSIT_FE_SNOX_314','TRANSIT_FE_SNOX_315',
 'TRANSIT_FE_SNOX_316','TRANSIT_FE_SNOX_317','TRANSIT_FE_SNOX_318','TRANSIT_FE_SNOX_319','TRANSIT_FE_TNOX_314','TRANSIT_FE_TNOX_315','TRANSIT_FE_TNOX_316',
 'TRANSIT_FE_TNOX_317','TRANSIT_FE_TNOX_318','TRANSIT_FE_TNOX_319','TRANSIT_GATEWAY_SNOX_314','TRANSIT_GATEWAY_SNOX_315','TRANSIT_GATEWAY_SNOX_316',
 'TRANSIT_GATEWAY_SNOX_317','TRANSIT_GATEWAY_SNOX_318','TRANSIT_GATEWAY_SNOX_319','TRANSIT_GATEWAY_TNOX_314','TRANSIT_GATEWAY_TNOX_315','TRANSIT_GATEWAY_TNOX_316',
 'TRANSIT_GATEWAY_TNOX_317','TRANSIT_GATEWAY_TNOX_318','TRANSIT_GATEWAY_TNOX_319','TRANSIT_SMSNOX_SNOX_314','TRANSIT_SMSNOX_SNOX_315','TRANSIT_SMSNOX_SNOX_317',
 'TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_SNOX_319','TRANSIT_SMSNOX_TNOX_314','TRANSIT_SMSNOX_TNOX_315','TRANSIT_SMSNOX_TNOX_317','TRANSIT_SMSNOX_TNOX_318',
 'TRANSIT_SMSNOX_TNOX_319','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_IOX_APP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','WEBFORT')
 
select 'GRANT '||WM_CONCAT(PRIVILEGE)||' ON '||grantor||'.'||table_name||' TO '||grantee||';'
 from dba_tab_privs
 where grantee in ('ETLUPDATE','KEYNOX_CPASS','KEYNOX_FX','PURGEDATA','SEQUENCE_REPL','TRANSITHA','SNOX4TRANSNOX_APP','SNOX4TRANSNOX_CPASS','SNOXPASS_GWAY_00526',
 'SNOXPASS_GWAY_00531','SNOXPASS_GWAY_008','SNOXPASS_GWAY_013','SNOXPASS_GWAY_014','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_306','SNOXPASS_SMSNOX_307',
 'SNOXPASS_TFE_2017','SNOXPASS_TFE_2018','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_013','TNOXPASS_GWAY_014','TNOXPASS_SMSNOX_305','TNOXPASS_SMSNOX_306',
 'TNOXPASS_SMSNOX_307','TNOXPASS_TFE_2015','TNOXPASS_TFE_2016','TNOXPASS_TFE_2017','TNOXPASS_TFE_2018','TRANSIT_FE_SNOX_314','TRANSIT_FE_SNOX_315',
 'TRANSIT_FE_SNOX_316','TRANSIT_FE_SNOX_317','TRANSIT_FE_SNOX_318','TRANSIT_FE_SNOX_319','TRANSIT_FE_TNOX_314','TRANSIT_FE_TNOX_315','TRANSIT_FE_TNOX_316',
 'TRANSIT_FE_TNOX_317','TRANSIT_FE_TNOX_318','TRANSIT_FE_TNOX_319','TRANSIT_GATEWAY_SNOX_314','TRANSIT_GATEWAY_SNOX_315','TRANSIT_GATEWAY_SNOX_316',
 'TRANSIT_GATEWAY_SNOX_317','TRANSIT_GATEWAY_SNOX_318','TRANSIT_GATEWAY_SNOX_319','TRANSIT_GATEWAY_TNOX_314','TRANSIT_GATEWAY_TNOX_315','TRANSIT_GATEWAY_TNOX_316',
 'TRANSIT_GATEWAY_TNOX_317','TRANSIT_GATEWAY_TNOX_318','TRANSIT_GATEWAY_TNOX_319','TRANSIT_SMSNOX_SNOX_314','TRANSIT_SMSNOX_SNOX_315','TRANSIT_SMSNOX_SNOX_317',
 'TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_SNOX_319','TRANSIT_SMSNOX_TNOX_314','TRANSIT_SMSNOX_TNOX_315','TRANSIT_SMSNOX_TNOX_317','TRANSIT_SMSNOX_TNOX_318',
 'TRANSIT_SMSNOX_TNOX_319','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_IOX_APP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','WEBFORT') 
 GROUP BY grantor,table_name,grantee;
 
 
 
  
 exec dbms_utility.compile_schema('SNOXPASS_GWAY_00531');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_317');
 exec dbms_utility.compile_schema('TRANSTSYSPAYMENTGW');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_315');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_315');
 exec dbms_utility.compile_schema('ETLUPDATE');
 exec dbms_utility.compile_schema('SNOXPASS_SMSNOX_20195');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_315');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_319');
 exec dbms_utility.compile_schema('TRANSIT_FE_TNOX_314');
 exec dbms_utility.compile_schema('TRANSIT_FE_TNOX_317');
 exec dbms_utility.compile_schema('TRANSIT_FE_TNOX_316');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_319');
 exec dbms_utility.compile_schema('TNOXPASS_TFE_2015');
 exec dbms_utility.compile_schema('TNOXPASS_TFE_2018');
 exec dbms_utility.compile_schema('SNOXPASS_GWAY_008');
 exec dbms_utility.compile_schema('TNOXPASS_GWAY_014');
 exec dbms_utility.compile_schema('SNOXPASS_GWAY_013');
 exec dbms_utility.compile_schema('TNOXPASS_GWAY_013');
 exec dbms_utility.compile_schema('SNOXPASS_SMSNOX_306');
 exec dbms_utility.compile_schema('TNOXPASS_TFE_2017');
 exec dbms_utility.compile_schema('TNOXPASS_TFE_2016');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_314');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_317');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_317');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_314');
 exec dbms_utility.compile_schema('SNOXPASS_GWAY_00526');
 exec dbms_utility.compile_schema('TRANSIT_FE_SNOX_315');
 exec dbms_utility.compile_schema('TRANSNOX_CPASS');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_318');
 exec dbms_utility.compile_schema('PURGEDATA');
 exec dbms_utility.compile_schema('TNOXPASS_SMSNOX_307');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_318');
 exec dbms_utility.compile_schema('SNOXPASS_TFE_2018');
 exec dbms_utility.compile_schema('WEBFORT');
 exec dbms_utility.compile_schema('TRANSITHA');
 exec dbms_utility.compile_schema('SNOXPASS_SMSNOX_307');
 exec dbms_utility.compile_schema('TRANSIT_FE_TNOX_319');
 exec dbms_utility.compile_schema('TRANSTSYSPAYMENTGWAPP');
 exec dbms_utility.compile_schema('TRANSIT_FE_SNOX_318');
 exec dbms_utility.compile_schema('TNOXPASS_SMSNOX_305');
 exec dbms_utility.compile_schema('TRANSIT_FE_SNOX_317');
 exec dbms_utility.compile_schema('TRANSNOX_CAT');
 exec dbms_utility.compile_schema('TNOXPASS_SMSNOX_306');
 exec dbms_utility.compile_schema('TRANSNOX_IOX_APP');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_317');
 exec dbms_utility.compile_schema('SNOX4TRANSNOX_CPASS');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_318');
 exec dbms_utility.compile_schema('SNOX4TRANSNOX_APP');
 exec dbms_utility.compile_schema('SNOXPASS_TFE_2017');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_315');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_316');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_SNOX_314');
 exec dbms_utility.compile_schema('TRANSIT_FE_TNOX_318');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_314');
 exec dbms_utility.compile_schema('SEQUENCE_REPL');
 exec dbms_utility.compile_schema('TRANSIT_SMSNOX_TNOX_319');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_SNOX_318');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_319');
 exec dbms_utility.compile_schema('TNOXPASS_GWAY_00526');
 exec dbms_utility.compile_schema('TRANSIT_FE_SNOX_316');
 exec dbms_utility.compile_schema('TRANSIT_FE_TNOX_315');
 exec dbms_utility.compile_schema('TRANSIT_FE_SNOX_319');
 exec dbms_utility.compile_schema('TRANSIT_GATEWAY_TNOX_316');
 exec dbms_utility.compile_schema('KEYNOX_CPASS');
 exec dbms_utility.compile_schema('SNOXPASS_GWAY_014');
 exec dbms_utility.compile_schema('KEYNOX_FX');
exec dbms_utility.compile_schema('TRANSIT_FE_SNOX_314');



SELECT owner, object_name, object_type, mis_tables, mis_view, mis_proc, mis_func, mis_tri, mis_pac, mis_pac_body, mis_seq 
FROM 
(    
    SELECT UNIQUE doj.owner, doj.object_name, doj.object_type,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TABLE' AND OBJECT_name NOT LIKE 'SN_TEMP%' AND OBJECT_name NOT LIKE 'SC_TEMP%' AND oj.owner = doj.owner AND oj.object_name = doj.object_name ),'Y','N') mis_tables,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_view,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_proc,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_func,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tri,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name ),'Y','N') mis_pac,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name ),'Y','N') mis_pac_body,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_seq
    FROM 
    (
        SELECT owner, object_name, object_type  
        FROM dba_objects@txnDCW
        WHERE owner IN ('ETLUPDATE','KEYNOX_CPASS','KEYNOX_FX','PURGEDATA','SEQUENCE_REPL','TRANSITHA','SNOX4TRANSNOX_APP','SNOX4TRANSNOX_CPASS','SNOXPASS_GWAY_00526',
 'SNOXPASS_GWAY_00531','SNOXPASS_GWAY_008','SNOXPASS_GWAY_013','SNOXPASS_GWAY_014','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_306','SNOXPASS_SMSNOX_307',
 'SNOXPASS_TFE_2017','SNOXPASS_TFE_2018','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_013','TNOXPASS_GWAY_014','TNOXPASS_SMSNOX_305','TNOXPASS_SMSNOX_306',
 'TNOXPASS_SMSNOX_307','TNOXPASS_TFE_2015','TNOXPASS_TFE_2016','TNOXPASS_TFE_2017','TNOXPASS_TFE_2018','TRANSIT_FE_SNOX_314','TRANSIT_FE_SNOX_315',
 'TRANSIT_FE_SNOX_316','TRANSIT_FE_SNOX_317','TRANSIT_FE_SNOX_318','TRANSIT_FE_SNOX_319','TRANSIT_FE_TNOX_314','TRANSIT_FE_TNOX_315','TRANSIT_FE_TNOX_316',
 'TRANSIT_FE_TNOX_317','TRANSIT_FE_TNOX_318','TRANSIT_FE_TNOX_319','TRANSIT_GATEWAY_SNOX_314','TRANSIT_GATEWAY_SNOX_315','TRANSIT_GATEWAY_SNOX_316',
 'TRANSIT_GATEWAY_SNOX_317','TRANSIT_GATEWAY_SNOX_318','TRANSIT_GATEWAY_SNOX_319','TRANSIT_GATEWAY_TNOX_314','TRANSIT_GATEWAY_TNOX_315','TRANSIT_GATEWAY_TNOX_316',
 'TRANSIT_GATEWAY_TNOX_317','TRANSIT_GATEWAY_TNOX_318','TRANSIT_GATEWAY_TNOX_319','TRANSIT_SMSNOX_SNOX_314','TRANSIT_SMSNOX_SNOX_315','TRANSIT_SMSNOX_SNOX_317',
 'TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_SNOX_319','TRANSIT_SMSNOX_TNOX_314','TRANSIT_SMSNOX_TNOX_315','TRANSIT_SMSNOX_TNOX_317','TRANSIT_SMSNOX_TNOX_318',
 'TRANSIT_SMSNOX_TNOX_319','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_IOX_APP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','WEBFORT') 
          AND object_name NOT LIKE '%ORG' AND object_name NOT LIKE 'BIN$%'
          AND object_name NOT LIKE '%REPL'
          AND object_type IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
        ORDER BY owner, object_name, object_type ASC
    ) doj
)
WHERE mis_tables='N'
  AND mis_view='N'
  AND mis_proc='N'
  AND mis_func='N'
  AND mis_tri='N'
  AND mis_pac='N'
  AND mis_pac_body='N'
  AND mis_seq='N'
  AND REGEXP_LIKE(object_name,'[^0-9]$','i')
ORDER BY 1,2,3 ASC

 
expdp rchaudhari@txnDCW directory=dpump dumpfile=expdp_allAPPschemas_10Jun2015.dmp logfile=expdp_allAPPschemas_10Jun2015.log schemas=ETLUPDATE,KEYNOX_CPASS,KEYNOX_FX,PURGEDATA,SEQUENCE_REPL,TRANSITHA,SNOX4TRANSNOX_APP,SNOX4TRANSNOX_CPASS,SNOXPASS_GWAY_00526,SNOXPASS_GWAY_00531,SNOXPASS_GWAY_008,SNOXPASS_GWAY_013,SNOXPASS_GWAY_014,SNOXPASS_SMSNOX_20195,SNOXPASS_SMSNOX_306,SNOXPASS_SMSNOX_307,SNOXPASS_TFE_2017,SNOXPASS_TFE_2018,TNOXPASS_GWAY_00526,TNOXPASS_GWAY_013,TNOXPASS_GWAY_014,TNOXPASS_SMSNOX_305,TNOXPASS_SMSNOX_306,TNOXPASS_SMSNOX_307,TNOXPASS_TFE_2015,TNOXPASS_TFE_2016,TNOXPASS_TFE_2017,TNOXPASS_TFE_2018,TRANSIT_FE_SNOX_314,TRANSIT_FE_SNOX_315,TRANSIT_FE_SNOX_316,TRANSIT_FE_SNOX_317,TRANSIT_FE_SNOX_318,TRANSIT_FE_SNOX_319,TRANSIT_FE_TNOX_314,TRANSIT_FE_TNOX_315,TRANSIT_FE_TNOX_316,TRANSIT_FE_TNOX_317,TRANSIT_FE_TNOX_318,TRANSIT_FE_TNOX_319,TRANSIT_GATEWAY_SNOX_314,TRANSIT_GATEWAY_SNOX_315,TRANSIT_GATEWAY_SNOX_316,TRANSIT_GATEWAY_SNOX_317,TRANSIT_GATEWAY_SNOX_318,TRANSIT_GATEWAY_SNOX_319,TRANSIT_GATEWAY_TNOX_314,TRANSIT_GATEWAY_TNOX_315,TRANSIT_GATEWAY_TNOX_316,TRANSIT_GATEWAY_TNOX_317,TRANSIT_GATEWAY_TNOX_318,TRANSIT_GATEWAY_TNOX_319,TRANSIT_SMSNOX_SNOX_314,TRANSIT_SMSNOX_SNOX_315,TRANSIT_SMSNOX_SNOX_317,TRANSIT_SMSNOX_SNOX_318,TRANSIT_SMSNOX_SNOX_319,TRANSIT_SMSNOX_TNOX_314,TRANSIT_SMSNOX_TNOX_315,TRANSIT_SMSNOX_TNOX_317,TRANSIT_SMSNOX_TNOX_318,TRANSIT_SMSNOX_TNOX_319,TRANSNOX_CPASS,TRANSNOX_IOX_APP,TRANSTSYSPAYMENTGW,TRANSTSYSPAYMENTGWAPP,WEBFORT exclude=TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\" compression=all 


impdp rchaudhari/isplN01805@txnDCW directory=bkups dumpfile=expdp_all_VBS_schemas_10Jun2015.dmp logfile=expdp_all_VBS_schemas_10Jun2015.log remap_tablespace=USERS:CPASS_DATA_TBLS
															
															expdp_allAPPschemas_10Jun2015.dmp

MACRO #exception_handler
BEGIN
, TARGET ggate.exceptions
, COLMAP
   (
      rep_name = "RPTWTE",
      table_name = @GETENV ("GGHEADER", "TABLENAME"),
      errno = @GETENV ("LASTERR", "DBERRNUM"),
      dberrmsg = @GETENV ("LASTERR", "DBERRMSG"),
      optype = @GETENV ("LASTERR", "OPTYPE"),
      errtype = @GETENV ("LASTERR", "ERRTYPE"),
      logrba = @GETENV ("GGHEADER", "LOGRBA"),
      logposition = @GETENV ("GGHEADER", "LOGPOSITION"),
      committimestamp = @GETENV ("GGHEADER", "COMMITTIMESTAMP")
   )
, INSERTALLRECORDS
, EXCEPTIONSONLY;
END;












Does your phone take a few seconds before it starts to ring? Eliminate that delay by adding these lines:

    ro.telephony.call_ring.delay=0
    ring.delay=0

    

declare
  v_FileHandle            UTL_FILE.FILE_TYPE;
  v_File_LineNumber		  VARCHAR2(32767);
  v_data1 				  VARCHAR2(200);  -- assume this file has 2 columns of data
  v_data2 				  VARCHAR2(200);
begin
  UTL_FILE.FOPEN('GGDISCARD','RPTWTE.dsc','R', 32767);
--  <<file_read_lines>>
  LOOP
    BEGIN
      utl_file.get_line(v_FileHandle, v_File_LineNumber);
--      v_data1 := ltrim(rtrim(regexp_substr(v_line, '[^,]+', 1, 1),'"'),'"');
--      v_data2 := ltrim(rtrim(regexp_substr(v_line, '[^,]+', 1, 2),'"'),'"');
      -- do what you want with the data...
      dbms_output.put_line('Col1 : '||v_data1||', Col2 : '||v_data2);
    exception
      when no_data_found then
        exit file_read_lines;
    end;
  end loop;
  utl_file.fclose(v_FileHandle);
end;
/


UPDATE  TRANSNOX_IOX.TRANSACTION
SET device_type='124'
WHERE TRANSACTION_ID=2;

COMMIT;


--UPDATE TRANSNOX_IOX.BATCH_INFO
--SET BATCH_MSGE='VDS', batch_date=SYSDATE-1
--WHERE batch_id=23;
--
--COMMIT;


--UPDATE TRANSNOX_IOX.payment_method
--SET payment_details=' cc'
--WHERE payment_id=2;
--
--COMMIT;




SELECT SUBSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',1,INSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',' ',2,2)-1) FROM dual



SELECT 
SUBSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',INSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',' ',1,2)+1,INSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',':')-(INSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',' ',1,2)+1))
FROM dual

SELECT 
TO_NUMBER(SUBSTR('ORA-01403',INSTR('ORA-01403','-')+1))
FROM dual

SELECT 
SUBSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',INSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',':')+2,INSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',',')-(INSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',':')+2))
FROM dual


SELECT 
SUBSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>',INSTR('OCI Error ORA-01403: no data found, SQL <UPDATE "SNOX4TRANSNOX_CPASS"."BACKEND_CONNECTIONS" SET "VC_ID_COUNT" = :a1,"CONNECTION_STATUS" = :a2,"DATE_MODIFIED" = :a3,"LAST_SUCCESS_TIME" = :a4,"LAST_ERROR_TIME" = :a5,"LAST_TIMEOUT_TIME" = :a6,"ERROR_COUNT" = :a7,"TIMEOUT_COUNT" = :a8,"TOTAL_ERROR_COUNT" = :a9,"TOTAL_TIMEOUT_COUNT" = :a10,"TOTAL_SUCCESS_COUNT" = :a11 WHERE "PU_ID" = :b0>','SQL '))
FROM dual  






SELECT
SUBSTR( 'Discarding record on action DISCARD on error 1403',INSTR('Discarding record on action DISCARD on error 1403',' ',1,4)+1 ,INSTR('Discarding record on action DISCARD on error 1403',' ',1,5)-(INSTR('Discarding record on action DISCARD on error 1403',' ',1,4)+1))
FROM dual 


SELECT 
TO_NUMBER(SUBSTR('Discarding record on action DISCARD on error 1403',INSTR('Discarding record on action DISCARD on error 1403',' ',-1)))
FROM dual 


SELECT 
'ORA-'||TO_CHAR('1403','FM09999')
FROM dual 


SELECT 
 SUBSTR('Oracle GoldenGate Delivery for Oracle process started, group RPRWTW discard file opened: 2014-05-30 01:52:39',19,INSTR('Oracle GoldenGate Delivery for Oracle process started, group RPRWTW discard file opened: 2014-05-30 01:52:39',' ',19,1)-19)
                                           ||' Process '
                                           ||SUBSTR( 'Oracle GoldenGate Delivery for Oracle process started, group RPRWTW discard file opened: 2014-05-30 01:52:39'
                                                    ,INSTR('Oracle GoldenGate Delivery for Oracle process started, group RPRWTW discard file opened: 2014-05-30 01:52:39','for Oracle process')+19
                                                    ,INSTR('Oracle GoldenGate Delivery for Oracle process started, group RPRWTW discard file opened: 2014-05-30 01:52:39',',')-(INSTR('Oracle GoldenGate Delivery for Oracle process started, group RPRWTW discard file opened: 2014-05-30 01:52:39','for Oracle process')+19))
FROM dual 



SELECT 
'Current time: 2015-06-05 04:15:51',
SUBSTR('Current time: 2015-06-05 04:15:51',1,INSTR('Current time: 2015-06-05 04:15:51',' ',2,2)-2),
SUBSTR('Current time: 2015-06-05 04:15:51',INSTR('Current time: 2015-06-05 04:15:51',' ',2,2)-1,LENGTH('Current time: 2015-06-05 04:15:51'))
FROM dual


SELECT 
TO_DATE(SUBSTR('Current time: 2015-06-05 04:15:51',INSTR('Current time: 2015-06-05 04:15:51',':')+2),'YYYY-MM-DD HH24:MI:SS');
FROM 


SELECT
TO_NUMBER(SUBSTR('Discarding record on action DISCARD',INSTR('Discarding record on action DISCARD',' ',-1)))
FROM dual

SELECT * FROM TRANSNOX_IOX.TRANSACTION ORDER BY 2 DESC



TRUNCATE TABLE TRANSNOX_IOX.TRANSACTION

DROP  SEQUENCE TRANSNOX_IOX.SEQ_TRANSACTION_ID

INSERT INTO TRANSNOX_IOX.TRANSACTION
VALUES (transnox_iox.SEQ_TRANSACTION_ID.NEXTVAL, SYSDATE,'yy','88393')


COMMIT

CREATE SEQUENCE TRANSNOX_IOX.SEQ_TRANSACTION_ID
  START WITH 1
  INCREMENT BY 2
  CACHE 20


CREATE SEQUENCE TRANSNOX_IOX.SEQ_batch_ID
  START WITH 1
  INCREMENT BY 2
  CACHE 20
  
CREATE TABLE TRANSNOX_IOX.batch_info (batch_id NUMBER, batch_date DATE, batch_msge VARCHAR2(100))

INSERT INTO TRANSNOX_IOX.BATCH_INFO 
VALUES(TRANSNOX_IOX.SEQ_batch_ID.NEXTVAL, SYSDATE, 'Good Batch')

COMMIT

ALTER TABLE TRANSNOX_IOX.BATCH_INFO ADD CONSTRAINT pk_batch_id PRIMARY KEY(batch_id)

TRUNCATE TABLE TRANSNOX_IOX.BATCH_INFO 

SELECT * FROM TRANSNOX_IOX.batch_info


CREATE TABLE TRANSNOX_IOX.payment_method (payment_id NUMBER, payment_date DATE, payment_details VARCHAR2(100))

INSERT INTO TRANSNOX_IOX.payment_method
VALUES(1,SYSDATE-2/1440,'Cash-500')

COMMIT;

TRUNCATE TABLE TRANSNOX_IOX.payment_method

SELECT * FROM TRANSNOX_IOX.payment_method

ALTER TABLE TRANSNOX_IOX.payment_method ADD CONSTRAINT pk_pay_method PRIMARY KEY (payment_id)


TRANSNOX_IOX.payment_method




CREATE TABLE ggate.EXCEPTIONS
( rep_name VARCHAR2(8)
, table_name VARCHAR2(61)
, errno NUMBER
, dberrmsg VARCHAR2(4000)
, optype VARCHAR2(20)
, errtype VARCHAR2(20)
, logrba NUMBER
, logposition NUMBER
, committimestamp TIMESTAMP
);




SELECT * FROM  ggate.EXCEPTIONS ORDER BY committimestamp DESC






TRUNCATE TABLE ggate.EXCEPTIONS

DROP TABLE Discard_Records

CREATE TABLE Discard_Records
(
    DF_LINENUMBER         Number,
    MESSAGE_TYPE          VARCHAR2(10),
    message               VARCHAR2(200),
    message_date          DATE,
    operation_seqno       NUMBER,
    operation_rba         NUMBER,
    description           VARCHAR2(500),
    oracle_error          VARCHAR2(100),
    error_number          VARCHAR2(50),
    source_object_owner   VARCHAR2(30),
    source_object_name    VARCHAR2(30),
    target_object_owner   VARCHAR2(30),
    target_object_name    VARCHAR2(30),
    error_operation       VARCHAR2(20),
    error_object_owner    VARCHAR2(30),
    error_object_name     VARCHAR2(30),
    error_action          VARCHAR2(30),
    error_column          VARCHAR2(200),
    error_value           VARCHAR2(200),
    pk_table_name         VARCHAR2(30),
    TIMESTAMP             date
)  


DROP TYPE DiscardRecord

DROP TYPE DiscardTable

CREATE OR REPLACE TYPE DiscardRecord
AS OBJECT
(
    message_type          VARCHAR2(7)
  , message               VARCHAR2(120)
  , message_date          DATE
  , description           VARCHAR2(500)
  , line_number           NUMBER
  , oracle_error          VARCHAR2(100)
  , error_number          VARCHAR2(50)
  , source_object_owner   VARCHAR2(30)
  , source_object_name    VARCHAR2(30)
  , target_object_owner   VARCHAR2(30)
  , target_object_name    VARCHAR2(30)
  , error_operation       VARCHAR2(20)
  , error_object_owner    VARCHAR2(30)
  , error_object_name     VARCHAR2(30)
  , error_action          VARCHAR2(30)
  , error_column          VARCHAR2(120)
  , error_value           VARCHAR2(200)
  , pk_table_name         VARCHAR2(30)
  , operation_seqno       NUMBER
  , operation_rba         NUMBER
)
/
 
CREATE OR REPLACE TYPE DiscardTable
   AS TABLE OF DiscardRecord
/


CREATE OR REPLACE DIRECTORY GGDiscard AS '/ora3/goldengate/discard';

GRANT READ,WRITE ON DIRECTORY ggdiscard TO PUBLIC;

SELECT * FROM ggate.EXCEPTIONS

SELECT *
FROM TABLE(read_discard126('RPTWTE'))
--WHERE message_type='ERROR';


SELECT * FROM TRANSNOX_IOX.TRANSACTION ORDER BY 2 DESC


INSERT INTO TRANSNOX_IOX.TRANSACTION
VALUES (transnox_iox.SEQ_TRANSACTION_ID.NEXTVAL, SYSDATE,'yy','88393')


COMMIT;


DROP  SEQUENCE TRANSNOX_IOX.SEQ_TRANSACTION_ID

CREATE SEQUENCE TRANSNOX_IOX.SEQ_TRANSACTION_ID
  START WITH 2
  INCREMENT BY 2
  CACHE 20

DROP SEQUENCE TRANSNOX_IOX.SEQ_batch_ID

CREATE SEQUENCE TRANSNOX_IOX.SEQ_batch_ID
  START WITH 2
  INCREMENT BY 2
  CACHE 20


INSERT INTO TRANSNOX_IOX.BATCH_INFO 
VALUES(TRANSNOX_IOX.SEQ_batch_ID.NEXTVAL, SYSDATE-1, 'Good Batch')

SELECT * FROM TRANSNOX_IOX.batch_info

COMMIT;


CREATE TABLE TRANSNOX_IOX.payment_method (payment_id NUMBER, payment_date DATE, payment_details VARCHAR2(100))

--DROP TABLE TRANSNOX_IOX.payment_method

SELECT * FROM TRANSNOX_IOX.payment_method

SELECT * FROM ggate.EXCEPTIONS






SELECT SUBSTR('Operation: 15',1,INSTR('Operation: 15 ',' ',2,2)-1) FROM dual 




'Aborted compressed update from TRANSNOX_IOX.TRANSACTION to TRANSNOX_IOX.TRANSACTION (target format)...'

SELECT * FROM alert_log

CREATE TABLE alert_log (
  line  VARCHAR2(4000)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY GGDiscard
  ACCESS PARAMETERS
  (
    RECORDS DELIMITED BY NEWLINE
--    BADFILE bdump:'read_alert_%a_%p.bad'
--    LOGFILE bdump:'read_alert_%a_%p.log'
    FIELDS TERMINATED BY '*'
    MISSING FIELD VALUES ARE NULL
    (
      line  CHAR(4000)
    )
  )
  LOCATION ('RPTWTE.dsc')
)
PARALLEL 1
REJECT LIMIT UNLIMITED



---------------------------------------------------------------------------------------------------------------------------------------------
-- Start of Work 14/May/2015


-- Purging Infonox_Service_Usage table from TE Prod DB

-- Partition Names are
SYS_P8823	TO_DATE(' 2015-02-25 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1675108	1935899	0	3/10/2015 2:31:23 AM	0	0
SYS_P8683	TO_DATE(' 2015-02-18 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1691901	1945489	0	2/19/2015 2:31:48 AM	0	0
SYS_P8503	TO_DATE(' 2015-02-11 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1659524	1895235	0	2/12/2015 2:27:42 AM	0	0
SYS_P8323	TO_DATE(' 2015-02-04 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1583933	1770431	0	2/4/2015 2:28:37 AM	0	0
SYS_P8163	TO_DATE(' 2015-01-28 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1480190	1617878	0	1/28/2015 3:26:33 AM	0	0
SYS_P7983	TO_DATE(' 2015-01-21 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1427299	1601510	0	1/20/2015 10:36:01 PM	0	0
SYS_P7703	TO_DATE(' 2015-01-14 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1417471	1556500	0	1/13/2015 10:35:55 PM	0	0
SYS_P7483	TO_DATE(' 2015-01-07 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1263924	1421466	0	1/6/2015 10:36:56 PM	0	0
SYS_P7223	TO_DATE(' 2014-12-31 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1092372	1195899	0	12/30/2014 10:35:50 PM	0	0
SYS_P6963	TO_DATE(' 2014-12-24 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1533768	1685907	0	12/23/2014 11:33:43 PM	0	0
SYS_P6703	TO_DATE(' 2014-12-17 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1506858	1662635	0	12/16/2014 10:27:47 PM	0	0
SYS_P6463	TO_DATE(' 2014-12-10 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1552779	1710459	0	12/9/2014 11:19:50 PM	0	0
SYS_P6243	TO_DATE(' 2014-12-03 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	1199541	1336048	0	12/2/2014 10:33:57 PM	0	0
P_FIRST	TO_DATE(' 2013-01-30 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	IFX_SER_USAGE_DATA	DISABLED	424889	108531	0	11/12/2014 10:23:00 PM	0	0



ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P8823 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P8683 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P8503 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P8323 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P8163 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P7983 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P7703 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P7483 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P7223 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P6963 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P6703 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P6463 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION SYS_P6243 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage TRUNCATE PARTITION P_FIRST UPDATE INDEXES;



ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P8823 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P8683 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P8503 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P8323 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P8163 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P7983 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P7703 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P7483 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P7223 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P6963 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P6703 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P6463 UPDATE INDEXES;
ALTER TABLE SNOX4TRANSNOX.Infonox_Service_Usage DROP PARTITION SYS_P6243 UPDATE INDEXES;



-- EVENT Table purging activity

SYS_P9423	TO_DATE(' 2015-03-27 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN')	83	SNOX_EVENT_DATA	DISABLED	187069	2392	0	3/27/2015 2:16:26 AM	0	0

ALTER TABLE SNOX4TRANSNOX.EVENT DROP PARTITION SYS_P9423 UPDATE INDEXES;





-- End of Work 14/May/2015
---------------------------------------------------------------------------------------------------------------------------------------------





---------------------------------------------------------------------------------------------------------------------------------------------
-- Start of Work 12/May/2015

-- Oracle Parameter used for GoldenGate Replication..

-- Below parameter define the goldengate replication should be enable (True) or disable (False).
ENABLE_GOLDENGATE_REPLICATION = TRUE


-- Below are main the parameter used for Active - Active GoldenGate Replication in Oracle

In an active - active configuration, each Replicat must be configured to update its object metadata cache whenever the remote Extract sends over a captured Replicat DDL statement. To satisfy this requirement, use the UPDATEMETADATA 
option in the DDLOPTIONS  statement in the Replicat  parameter files on both systems. The extract parameter file on both systems should also include the  GETREPLICATES option in the DDLOPTIONS  statement .
-- Extract (primary and secondary)
DDLOPTIONS GETREPLICATES

-- Replicat (primary and secondary)
DDLOPTIONS UPDATEMETADATA

-- Parameters for DML CDR 
Both Extract and Replicat will require parameters for CDR. For Extract, the before image information being extracted needs to be defined.  
For Replicat, the conflict rules and resolution rules need to be defined

-- In Extract, GETUPDATEBEFORES is required to collect the before image for Conflict Detec tion.  
-- Using the ALL option for GETBEFORECOLS will capture only the columns that are supplementally logged.
-- should be present in all extract params and for all replicating schemas.
GETBEFORECOLS (ON UPDATE ALL, ON DELETE ALL);



-- Should be present in all replicat params and for all replicating schemas to handle the CDR
,
COMPARECOLS (ON UPDATE ALL, ON DELETE ALL),
RESOLVECONFLICT (INSERTROWEXISTS, (DEFAULT, DISCARD)),
RESOLVECONFLICT (UPDATEROWEXISTS, (DEFAULT, DISCARD)),
RESOLVECONFLICT (DELETEROWEXISTS, (DEFAULT, OVERWRITE)),
RESOLVECONFLICT (UPDATEROWMISSING, (DEFAULT, OVERWRITE)),
RESOLVECONFLICT (DELETEROWMISSING, (DEFAULT, IGNORE));

-- End of Work 12/May/2015
---------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------------------------------
BEGIN 
  CHECKCASH.CON_CHKC_SETTLE_ECAPAPER_APR15;
  DBMS_OUTPUT.Put_Line('');
  COMMIT; 
END; 
/
---------------------------------------------------------------------------------------------------------------------------------------------



---------------------------------------------------------------------------------------------------------------------------------------------
 insert into TRANSNOX_CPASS.TRANSACTION1 
 	(
 		TRANSACTION_ID, TRANS_TYPE, TRANS_STATUS, REASON_CODE, TASK_ID, TIME_STAMP, 
 		DEVICE_ID, CLIENT_TIMESTAMP, AMOUNT, FEE_CHARGED, FEE_WAIVED, CURRENCY, 
 		REFERENCE_NUMBER, USER_ID, SEQUENCE_NUMBER, LAST_MODIFIED_TIME_STAMP, COUNTRY_CODE
 	)
 	
 	
insert into TRANSNOX_CPASS.TRANSACTION1 	
 select TRANSNOX_CPASS.SEQ_TRANSACTION_ID1.NEXTVAL, TRANS_TYPE, TRANS_STATUS, 
 		REASON_CODE, TASK_ID, Time_Stamp, DEVICE_ID, 
 		CLIENT_TIMESTAMP, AMOUNT, FEE_CHARGED, FEE_WAIVED, 
 		CURRENCY, REFERENCE_NUMBER, USER_ID, SEQUENCE_NUMBER, 
 		LAST_MODIFIED_TIME_STAMP, COUNTRY_CODE
from transnox_cpass.transaction1 where rownum < 2000000





insert into TRANSNOX_CPASS.TRANSACTION1 	
 select TRANSNOX_CPASS.SEQ_TRANSACTION_ID1.NEXTVAL, TRANS_TYPE, TRANS_STATUS, 
 		REASON_CODE, TASK_ID, SYSDATE-dbms_random.value-dbms_random.value(1,1000) Time_Stamp, DEVICE_ID, 
 		CLIENT_TIMESTAMP, AMOUNT, FEE_CHARGED, FEE_WAIVED, 
 		CURRENCY, REFERENCE_NUMBER, USER_ID, SEQUENCE_NUMBER, 
 		LAST_MODIFIED_TIME_STAMP, COUNTRY_CODE
from transnox_cpass.transaction1 where rownum < 2000000




 PARTITION XTNS_APR2013 VALUES LESS THAN (TO_DATE(' 2013-05-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    NOLOGGING
    NOCOMPRESS ,  
  PARTITION XTNS_MAR2013 VALUES LESS THAN (TO_DATE(' 2013-06-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    NOLOGGING
    NOCOMPRESS ,  
  PARTITION VALUES LESS THAN (TO_DATE(' 2013-07-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    NOLOGGING
    NOCOMPRESS ,  
  PARTITION VALUES LESS THAN (TO_DATE(' 2013-08-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    NOLOGGING
    NOCOMPRESS ,  
  PARTITION VALUES LESS THAN (TO_DATE(' 2013-09-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    NOLOGGING
    NOCOMPRESS ,  
  PARTITION VALUES LESS THAN (TO_DATE(' 2013-10-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    NOLOGGING
    NOCOMPRESS ,  
  PARTITION VALUES LESS THAN (TO_DATE(' 2013-11-01 00:00:00', 'SYYYY-MM-DD HH24:MI:SS', 'NLS_CALENDAR=GREGORIAN'))
    NOLOGGING
    NOCOMPRESS ,  
  
---------------------------------------------------------------------------------------------------------------------------------------------




---------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLESPACE CPASS_DATA_ENCRYPT DATAFILE '+ASMTXNDATA'
   SIZE 2g AUTOEXTEND OFF,
   SIZE 1g AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED,
   SIZE 2g AUTOEXTEND OFF
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;


CREATE TABLESPACE CPASS_INDX_ENCRYPT DATAFILE '+ASMTXNDATA'
   SIZE 2g AUTOEXTEND OFF,
   SIZE 1g AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;
---------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE TRANSNOX_CPASS.TRANSACTION1
TABLESPACE CPASS_DATA_TBLS
PARTITION BY RANGE (TIME_STAMP)
INTERVAL( NUMTOYMINTERVAL(1,'MONTH'))
(  
  PARTITION xtns_Apr2013 VALUES LESS THAN (TO_DATE('01-05-2013', 'DD-MM-YYYY'))
    TABLESPACE CPASS_PART1_DATA,  
  PARTITION xtns_Mar2013 VALUES LESS THAN (TO_DATE('01-06-2013', 'DD-MM-YYYY'))
    TABLESPACE CPASS_PART1_DATA
) NOLOGGING AS 
SELECT * FROM transnox_cpass.TRANSACTION;

CREATE INDEX TRANSNOX_CPASS.IDX_TRANSACTION1_TIME_STAMP ON TRANSNOX_CPASS.TRANSACTION1
(TIME_STAMP)
NoLOGGING TABLESPACE CPASS_INDX_TBLS
LOCAL
(
  PARTITION xtns_Apr2013_1
    LOGGING
    NOCOMPRESS 
    TABLESPACE CPASS_PART1_INDX,  
  PARTITION xtns_Mar2013_2
    LOGGING
    NOCOMPRESS 
	TABLESPACE CPASS_PART1_INDX,
  PARTITION
	LOGGING
    NOCOMPRESS 
);


CREATE INDEX TRANSNOX_CPASS.IDX_XTN_LMTS ON TRANSNOX_CPASS.TRANSACTION1
(LAST_MODIFIED_TIME_STAMP)
NOLOGGING
TABLESPACE CPASS_INDX_TBLS
NOPARALLEL;


CREATE INDEX TRANSNOX_CPASS.IDX_XTN_TYP_STAT ON TRANSNOX_CPASS.TRANSACTION1
(TRANS_TYPE, TRANS_STATUS)
LOGGING
TABLESPACE CPASS_INDX_TBLS
NOPARALLEL;


CREATE UNIQUE INDEX TRANSNOX_CPASS.PK_TRANSACTION1 ON TRANSNOX_CPASS.TRANSACTION1
(TRANSACTION1_ID)
NOLOGGING
TABLESPACE CPASS_INDX_TBLS
NOPARALLEL;



ALTER TABLE TRANSNOX_CPASS.TRANSACTION1 ADD (
  CONSTRAINT PK_TRANSACTION1
  PRIMARY KEY
  (TRANSACTION1_ID)
  USING INDEX TRANSNOX_CPASS.PK_TRANSACTION1
  ENABLE VALIDATE);


ORA-14039: partitioning columns must form a subset of key columns of a UNIQUE index



BEGIN
  CHECKCASH.CON_CHKC_SETTLE_ECAPAPER_APR15;
  DBMS_OUTPUT.Put_Line('');
  COMMIT;
END;
/



classic and integrated capture modes
---------------------------------------------------------------------------------------------------------------------------------------------




---------------------------------------------------------------------------------------------------------------------------------------------
Settlement (Last 3 hours ) - AZ


ifx-dbalerts@tsys.com

acq-marc@tsys.com,
rchaudhari@tsys.com,
dbhosale@tsys.com,
mbadhe@tsys.com


Apr 28, 2015 12:15:00 AM PDT


start time : 10 :15 AM


Settlement execution in last 3 hrs  
 

SELECT EXECUTION_ID,
	  executedon,
		 TO_CHAR (TRUNC (execution_time / 3600), 'FM9900')
	  || ':'
	  || TO_CHAR (TRUNC (MOD (execution_time, 3600) / 60), 'FM00')
	  || ':'
	  || TO_CHAR (MOD (execution_time, 60), 'FM00')
		 execution_time,
	  CASE WHEN execution_time > 1440 THEN 'Failed' ELSE 'Passed' END
		 Timedout,
	  REC_COUNT,
	  output_msg
 FROM TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP
WHERE executedon > SYSDATE - 3/ 24
  AND flow_type='Settlement flow'
ORDER BY executedon DESC


vital123


SMALIK

10.150.50.100


 alter user smalik identified by "ispl$2015";
 
 
 GeneratePublishedReport
 
 target_user_table_from_sql
 
 
 oracle.sysman.eml.ip.render.elem.SQLStatementParamController
 
 
 
 SYSMAN.MGMT_IP_ELEM_PARAM_CLASSES
 
 
 
 
/* Formatted on 7/26/2014 1:12:03 PM (QP5 v5.265.14096.38000) */
  SELECT EXECUTION_ID,
         executedon,
            TO_CHAR (TRUNC (execution_time / 3600), 'FM9900')
         || ':'
         || TO_CHAR (TRUNC (MOD (execution_time, 3600) / 60), 'FM00')
         || ':'
         || TO_CHAR (MOD (execution_time, 60), 'FM00')
            execution_time,
         CASE WHEN execution_time > 1440 THEN 'Failed' ELSE 'Passed' END
            Timedout,
         REC_COUNT,
         output_msg
    FROM TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP
   WHERE executedon > SYSDATE - 3/ 24
        AND flow_type='Settlement flow'
ORDER BY executedon DESC




/* Formatted on 7/26/2014 1:12:03 PM (QP5 v5.265.14096.38000) */
   SELECT EXECUTION_ID,
          executedon,
             TO_CHAR (TRUNC (execution_time / 3600), 'FM9900')
          || ':'
          || TO_CHAR (TRUNC (MOD (execution_time, 3600) / 60), 'FM00')
          || ':'
          || TO_CHAR (MOD (execution_time, 60), 'FM00')
             execution_time,
          CASE WHEN execution_time > 1440 THEN 'Failed' ELSE 'Passed' END
             Timedout,
          REC_COUNT,
          output_msg
     FROM TRANSNOX_IOX.DATABASE_EXEC_LOG_HSP
    WHERE executedon > SYSDATE - 3/ 24
      AND flow_type='Settlement flow'
ORDER BY executedon DESC
---------------------------------------------------------------------------------------------------------------------------------------------


send extract EPTW, showtrans
SR 3-10314427151 

CPASS_Data_Encrypt
CPASS_Indx_Encrypt

---------------------------------------------------------------------------------------------------------------------------------------------
-- Grants and Synonyms - Revoke Cross References from VBS
SELECT *
FROM DBA_TAB_PRIVS
WHERE GRANTEE  IN ('TRANSIT_GATEWAY_TNOX_318','TRANSIT_GATEWAY_SNOX_318','TRANSIT_FE_TNOX_318','TRANSIT_FE_SNOX_318','TRANSIT_SMSNOX_TNOX_318','TRANSIT_SMSNOX_SNOX_318')
  AND GRANTOR NOT IN ('TRANSNOX_CPASS','TRANSNOX_CPASS_DEV','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_DEV','TRANSNOX_CAT_QA','TRANSNOX_CAT','TRANSTSYSPAYMENTGW',
                      'TRANSIT_GATEWAY_TNOX_318','TRANSIT_GATEWAY_SNOX_318','TRANSIT_FE_TNOX_318','TRANSIT_FE_SNOX_318','TRANSIT_SMSNOX_TNOX_318','TRANSIT_SMSNOX_SNOX_318')

SELECT  'REVOKE '|| WM_CONCAT(PRIVILEGE) ||' ON '|| OWNER ||'.'|| TABLE_NAME ||' FROM '|| GRANTEE||';' PRIVS
FROM DBA_TAB_PRIVS
WHERE GRANTEE  IN ('TRANSIT_GATEWAY_TNOX_318','TRANSIT_GATEWAY_SNOX_318','TRANSIT_FE_TNOX_318','TRANSIT_FE_SNOX_318','TRANSIT_SMSNOX_TNOX_318','TRANSIT_SMSNOX_SNOX_318')
  AND GRANTOR NOT IN ('TRANSNOX_CPASS','TRANSNOX_CPASS_DEV','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_DEV','TRANSNOX_CAT_QA','TRANSNOX_CAT','TRANSTSYSPAYMENTGW',
                        'TRANSIT_GATEWAY_TNOX_318','TRANSIT_GATEWAY_SNOX_318','TRANSIT_FE_TNOX_318','TRANSIT_FE_SNOX_318','TRANSIT_SMSNOX_TNOX_318','TRANSIT_SMSNOX_SNOX_318')
GROUP BY OWNER,TABLE_NAME,GRANTEE



SELECT unique grantor
FROM DBA_TAB_PRIVS
WHERE GRANTEE  IN ('TRANSIT_GATEWAY_TNOX_317','TRANSIT_GATEWAY_SNOX_317','TRANSIT_FE_TNOX_317','TRANSIT_FE_SNOX_317','TRANSIT_SMSNOX_TNOX_317','TRANSIT_SMSNOX_SNOX_317')
--  AND GRANTOR NOT IN ('TRANSNOX_CPASS','TRANSNOX_CPASS_DEV','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_DEV','TRANSNOX_CAT_QA','TRANSNOX_CAT','TRANSTSYSPAYMENTGW',
--                      'TRANSIT_GATEWAY_TNOX_317','TRANSIT_GATEWAY_SNOX_317','TRANSIT_FE_TNOX_317','TRANSIT_FE_SNOX_317','TRANSIT_SMSNOX_TNOX_317','TRANSIT_SMSNOX_SNOX_317')



SELECT  'REVOKE '|| WM_CONCAT(PRIVILEGE) ||' ON '|| OWNER ||'.'|| TABLE_NAME ||' FROM '|| GRANTEE||';' PRIVS
FROM DBA_TAB_PRIVS
WHERE GRANTEE  IN ('TRANSIT_GATEWAY_TNOX_317','TRANSIT_GATEWAY_SNOX_317','TRANSIT_FE_TNOX_317','TRANSIT_FE_SNOX_317','TRANSIT_SMSNOX_TNOX_317','TRANSIT_SMSNOX_SNOX_317')
  AND GRANTOR NOT IN ('TRANSNOX_CPASS','TRANSNOX_CPASS_DEV','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_DEV','TRANSNOX_CAT_QA','TRANSNOX_CAT','TRANSTSYSPAYMENTGW',
                        'TRANSIT_GATEWAY_TNOX_317','TRANSIT_GATEWAY_SNOX_317','TRANSIT_FE_TNOX_317','TRANSIT_FE_SNOX_317','TRANSIT_SMSNOX_TNOX_317','TRANSIT_SMSNOX_SNOX_317')
GROUP BY OWNER,TABLE_NAME,GRANTEE


---------------------------------------------------------------------------------------------------------------------------------------------

SELECT 'ALTER INDEX ' || OWNER || '.' || INDEX_NAME || ' REBUILD TABLESPACE CPASS_INDX_ENCRYPT;' 
FROM DBA_INDEXES 
WHERE OWNER IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
  AND TABLE_NAME IN ('KEY_VALIDATION_INFO','OPERATOR','ACCOUNT_NUMBER_MASTER','ATNT_RESPONSE_DTL','ATNT_RESPONSE_DTL_AUDIT','CARD_NUM_MASTER_DUPDEL','CARD_NUMBER_MASTER','CLIENT_VALIDATION_INFO','FILE_PROCESS_CUSTOMER','FILE_PROCESS_DETAILS','FILE_PROCESS_SCRATCHPAD','HARMONY_SETTLEMENT_TRANS_DET','ID_NUMBER_MASTER','KYC_INFO','RECURRING_CONSUMER_STAG','RECURRING_PAYMENT_STAG','SSN_MASTER','TMS_HISTORICAL_DATA','TMS_RESPONSE_DTL','TMS_RESPONSE_DTL_AUDIT','TMS_CLR_CARDNO','TRANS_CHECK','DATA_MIG_PARSED_DATA','EFUNDS_RECON')


SELECT 'ALTER TABLE ' || OWNER || '.' || TABLE_NAME || ' MOVE TABLESPACE CPASS_DATA_ENCRYPT;' 
FROM DBA_TABLES 
WHERE OWNER IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS')
  AND TABLE_NAME IN ('KEY_VALIDATION_INFO','OPERATOR','ACCOUNT_NUMBER_MASTER','ATNT_RESPONSE_DTL','ATNT_RESPONSE_DTL_AUDIT','CARD_NUM_MASTER_DUPDEL','CARD_NUMBER_MASTER','CLIENT_VALIDATION_INFO','FILE_PROCESS_CUSTOMER','FILE_PROCESS_DETAILS','FILE_PROCESS_SCRATCHPAD','HARMONY_SETTLEMENT_TRANS_DET','ID_NUMBER_MASTER','KYC_INFO','RECURRING_CONSUMER_STAG','RECURRING_PAYMENT_STAG','SSN_MASTER','TMS_HISTORICAL_DATA','TMS_RESPONSE_DTL','TMS_RESPONSE_DTL_AUDIT','TMS_CLR_CARDNO','TRANS_CHECK','DATA_MIG_PARSED_DATA','EFUNDS_RECON')
  

SELECT 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' MOVE LOB ('||COLUMN_NAME||') STORE AS (TABLESPACE CPASS_INDX_ENCRYPT);' indx 
FROM DBA_TAB_COLUMNS 
WHERE OWNER IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS') 
 AND DATA_TYPE IN ('BOLB','CLOB')
 AND TABLE_NAME IN ('KEY_VALIDATION_INFO','OPERATOR','ACCOUNT_NUMBER_MASTER','ATNT_RESPONSE_DTL','ATNT_RESPONSE_DTL_AUDIT','CARD_NUM_MASTER_DUPDEL','CARD_NUMBER_MASTER','CLIENT_VALIDATION_INFO','FILE_PROCESS_CUSTOMER','FILE_PROCESS_DETAILS','FILE_PROCESS_SCRATCHPAD','HARMONY_SETTLEMENT_TRANS_DET','ID_NUMBER_MASTER','KYC_INFO','RECURRING_CONSUMER_STAG','RECURRING_PAYMENT_STAG','SSN_MASTER','TMS_HISTORICAL_DATA','TMS_RESPONSE_DTL','TMS_RESPONSE_DTL_AUDIT','TMS_CLR_CARDNO','TRANS_CHECK','DATA_MIG_PARSED_DATA','EFUNDS_RECON')
   

CREATE OR REPLACE TRIGGER block_tools_from_prod
  AFTER LOGON ON DATABASE
DECLARE
  v_prog sys.v_$session.program%TYPE;
  v_count number;
BEGIN
	-- Check 
	SELECT count(*) -- SCHEMANAME, OSUSER, MACHINE, MODULE, PROGRAM, SERVICE_NAME
	  INTO v_count
	  FROM v$SESSION
	 WHERE TYPE <>'BACKGROUND'
--	   AND REGEXP_LIKE(schemaname,'transit*|qcp|*transnox*','i') 
	   AND REGEXP_LIKE(username,'transit*|qcp|*transnox*','i') 	   
	   AND REGEXP_LIKE(module,'sql.dev*|toad*|sql.plus','i');

  IF v_count > 0 THEN
     RAISE_APPLICATION_ERROR(-20000, 'Development tools are not allowed to access Application Schemas.');
  END IF;
END;
/

drop trigger block_tools_from_prod;

This will be including ...
1) Installing and Configuring Active-Active Replication
2) Including new parameters in goldengate for Active-Active replication and their testing.
3) DML/DDL Testing and R&D 
4) Conflict Resolution Handling

Once all the testing is done, all the stuffs will be included on 

------------------------------------------------------------------------------------------------
-- Triggers enabled
alter trigger SNOX4TRANSNOX.MERCHAN_STATE_PROVI_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_EVENT_MAC_RULE_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MERCHANT_WUTL_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_KIOSK_DATA_TRIGGER enable;
alter trigger SNOX4TRANSNOX.DEV_FEE_RATE_CODE_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.EMP_MENU_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.FEE_RATE_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.ADD_COMPANY_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.CC_CSR_QUEUE_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MERCHANT_WUMT_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MERCHANT_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SNOX_FAVORITES_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.PROFILE_DETAIL_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SN_PRODUCT_DEPENDENCY_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SN_PRODUCT_DEPLOYMENT_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SN_PRODUCT_RELEASE_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SN_PRODUCT_TESTING_TRIGGER enable;
alter trigger SNOX4TRANSNOX.PARAMETER_MASTER_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.OPERATOR_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.DEVICE_PERIPHERAL_TRIG enable;
alter trigger SNOX4TRANSNOX.DEVICE_MENU_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.DEVICE_PERIPHERAL_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.DEVICE_SUBMENU_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.DEVICE_TERMINAL_MAP_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_TICKET_CONFIG_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_TICKET_FLOW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SS_RULE_HISTORY_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SN_PROD_DB_RELEASE_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SS_RULE_SER_RULE_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.SUB_CORPORATION_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.LOOKUP_CATEGORY_TRIG enable;
alter trigger SNOX4TRANSNOX.KIOSK_INFO_MASTER_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.LOOKUP_PROPERTY_TRIG enable;
alter trigger TRANSNOX_CAT.API_PAYEE_CPAY_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.DEVICE_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.OPERATOR_VW_4_WU_TRIGGER enable;
alter trigger TRANSNOX_CAT.CPK_PAYEE_CPAY_VW_TRIGGER enable;
alter trigger TRANSNOX_CAT.INS_UPD_CUST_COMPL_INFO_TRIG enable;
alter trigger SNOX4TRANSNOX.OPERATOR_GROUP_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.OPERATOR_GROUP_TRIGGER enable;
alter trigger SNOX4TRANSNOX.OPERATOR_MENU_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.CORPORATION_CONFIG_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.CORPORATION_PP_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.DEVICE_CONNECTIVITY_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.ACCESS_PROFILE_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.LOOKUP_TEXT_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MERCHANT_MESS_DETAI_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MERCHANT_PP_VW_TRIGGER enable;
alter trigger TRANSNOX_CAT.MNOX_TIMERBUCKET_DETAIL_VW_TRG enable;
alter trigger TRANSNOX_CAT.MER_FILE_PROCESS_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_SERVER_DETAIL_VW_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_SERVER_SNMP_THRES_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_SNMP_OID_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_SERVER_DATA_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_PROPERTY_DATA_TRIGGER enable;
alter trigger SNOX4TRANSNOX.MNOX_ROUTER_DETAILS_VW_TRIGGER enable;

------------------------------------------------------------------------------------------------

Load test servers are using recovery area for goldengate files. Goldengate will need 500 G on each RAC (accessable by all three nodes same as /recovery). New mount point can be called as /goldengate

RAC1
         loadtxdbnode1.tsysacquiring.org - 10.100.226.75
         loadtxdbnode1.tsysacquiring.org - 10.100.226.76
         loadtxdbnode1.tsysacquiring.org - 10.100.226.77
RAC2
         loadrpdbnode1.tsysacquiring.org - 10.100.224.193
         loadrpdbnode2.tsysacquiring.org - 10.100.224.194
         loadrpdbnode3.tsysacquiring.org - 10.100.224.195

Also We need two VIP address (one for each RAC) same as we have in production.

------------------------------------------------------------------------------------------------

-- On Site A (Capture Site)
ADD EXTRACT EPDCW, TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /ora3/goldengate/dirdat/DW, EXTRACT EPDCW, MEGABYTES 100

-- Pump Process for replicating data in DCE reporting database
ADD EXTRACT PPTWTE, EXTTRAILSOURCE /ora3/goldengate/dirdat/DW
ADD RMTTRAIL /ora3/goldengate/dirdat/WA, EXTRACT PPTWTE, MEGABYTES 100

-- on site B (Receiver Site)
ADD REPLICAT RPTETW, EXTTRAIL /ora3/goldengate/dirdat/WA
-- If you get error : ERROR: No checkpoint table specified for ADD REPLICAT.
-- Then execute below statement with checkpointtable
-- ADD REPLICAT RPTETW, EXTTRAIL /ora3/goldengate/dirdat/WA, CHECKPOINTTABLE ggate.CHKPTAB


-- On Site B (Capture Site)
ADD EXTRACT EPDCE, TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /ora3/goldengate/dirdat/DE, EXTRACT EPDCE, MEGABYTES 100

-- Pump Process for replicating data in DCE reporting database
ADD EXTRACT PPTETW, EXTTRAILSOURCE /ora3/goldengate/dirdat/DE
ADD RMTTRAIL /ora3/goldengate/dirdat/EA, EXTRACT PPTETW, MEGABYTES 100

-- on site A (Receiver Site)
ADD REPLICAT RPTWTE, EXTTRAIL /ora3/goldengate/dirdat/EA

------------------------------------------------------------------------------

1) Take the opnion of other DBAs on Patitioning tables
2) Bulid the env. for purging on performance 
3) Build the Partition on Transnox_cpass purging related tables
4) Ask Application team to increase the data, increase the load

-------------------------------------------------------------------------------

Oracle Database Administrator Specialist (DBA - Oracle, UNIX, Linux) - Location: Tempe, Arizona OR Milpitas, California-92742

Description
 
Hiring Manager: Ed Leblanc

 

Summary 
Plans computerized databases, including base definition, structure, documentation, long-range requirements, operational guidelines and protection. Ensures accuracy and completeness of data in master files and various support tools, such as base dictionaries. Establishes and maintains security and integrity controls. Formulates and monitors policies, procedures and standards relating to database management. Proposes and implements enhancements that will improve the performance and reliability of the system. 

Job Requirements 
Coordinates and preforms testing of database software, utilities and patches, such as Oracle Real Application Clusters (RAC), Oracle Enterprise Manager (OEM), Data Guard, within a test environment prior to production roll out and review testing results to make a Go/No-Go recommendation. Assists less experienced Database Administrators (DBAs) with issue resolution during testing. Coordinates the migration of tested/approved software, utilities, and patches to the production environment. Develops database configurations of various complexities by creating database objects per specified business requirements and the necessary test environments and interpret business requirements and advise less experienced DBAs. Works in close liaison with application developers, identifying potential impacts and provide insightful guidance/issues resolution to ensure best practices are applied to mitigate potential impacts to the various user groups and/or other database configurations. Coaches/mentors less experienced DBAs as they begin to perform routine/basic database administration tasks.
Completes authentication and authorization requests by creating/purging/maintaining user accounts, adding/deleting/modifying table and data permissions. Performs and/or sets up a scheduled database audit procedure to track the who/when changes are made or new items are created. Recommends and performs appropriate corrective actions based on audit results.
Ensures the proper scheduling of database back-up tasks and the completion of scheduled tasks. Coordinates database recovery tasks during a disaster recovery and/or disaster recovery exercise to maintain compliance with Service Level Agreements (SLAs) recovery requirements. Leverages a detailed knowledge of Oracle Recovery Manager, Data Guard and Golden Gate to assist less experienced DBAs.
Monitors current usage levels of database storage, identify and analyze growth trends and forecast future storage requirements based on analysis results. Develops recommendations for long-term capacity plans taking into account hardware lifecycles, current and scheduled project requirements. Oversees and performs routine maintenance such as data compression and defragmentation.
Actively monitors database performance to identify bottlenecks, such as inefficient queries, inconsistent and/or corrupt indexes, database design, and provides comprehensive recommendations for corrective actions. Applies routine and non-routine database tuning and optimization techniques, such as rebuilding indexes, determines when and creates additional indexes and perform in-depth reviews of queries to maintain database performance. Performs and reviews database statistic reporting on a regularly scheduled basis and provides recommendations to improve performance. Ensures the high availability of the supported database(s). Assists less experienced DBAs with developing the required knowledge and proficiency with Automatic workload Repository (AWR) reports, Auto service Request (ASR) and OEM.
Liaises with the Applications Team while performing troubleshooting to determine the source of application failures. Acts as a point of escalation for unresolved or complex failures. Recommends and develops solutions to minimize the potential of future application failures and assist in the implementation. Actively leads troubleshooting tasks when engaged by business units.
Produces and reviews operational database documentation, such as Oracle Standard Operating Procedures documents, Disaster Recovery Plans, Recovery Presentation, Naming Standards, Performance and Tuning, to ensure database configurations are well documented in preparation for disaster recovery.
Provides training and familiarization to less experienced DBAs regarding company policies and procedures, techniques and current server/database configurations.



Qualifications
 
Minimum Qualifications 
Bachelor's Degree - No degree specified
Typically Minimum 6 Years Relevant Exp - With the Installation, Customization, Testing and Maintenance of database systems within a production environment.

10.150.50.123 -- DCW GIT DB
10.150.50.130 -- DCW Parallel DB
10.150.4.129 -- DCW TSND DB
10.150.4.161 -- DCW TransIT txnNode1
10.150.4.162 -- DCW TransIT txnNode2
10.150.4.163 -- DCW TransIT txnNode3
10.150.4.171 -- DCW TransIT RPTNode1
10.150.4.172 -- DCW TransIT RPTNode2
10.150.4.173 -- DCW TransIT RPTNode3
10.150.50.110 -- DCW MAP DB
10.150.50.121 -- DCW GCA RPT
10.150.50.122 -- DCW GCA TNOX
10.150.50.132 -- DCW Archive DB
10.150.50.25 -- DCW PayFuse DB

10.50.4.110 -- DCE MAP DB
10.50.4.121 -- DCE GCA RPT
10.50.4.122 -- DCE GCA TNox
10.50.4.123 -- DCE GIT DB
10.50.4.125 -- DCE GCA QCPW DB
10.50.4.132 -- DCE Archive DB
10.50.4.135 -- DCE TSND StdBy DB
10.50.4.161 -- DCE TransIT txnNode1
10.50.4.162 -- DCE TransIT txnNode2
10.50.4.163 -- DCE TransIT txnNode3
10.50.4.171 -- DCE TransIT rptNode1
10.50.4.172 -- DCE TransIT rptNode2
10.50.4.173 -- DCE TransIT rptNode3
10.50.50.113 -- DCE MAP StdBy

10.175.157.195 -- QR Application log

10.100.126.61 -- UAT Node1
10.100.126.62 -- UAT Node2
10.100.126.63 -- UAT Node3
10.100.126.170 -- MAP UAT DB
10.100.126.20 -- PayFuse UAT DB

10.100.224.193 -- PF DCE txn-rpt Node1
10.100.224.194 -- PF DCE txn-rpt Node2
10.100.224.195 -- PF DCE txn-rpt Node3
10.100.226.75 -- PF DCW txn-rpt Node1
10.100.226.76 -- PF DCW txn-rpt Node2
10.100.226.77 -- PF DCW txn-rpt Node3
10.100.224.172 -- QA Node1
10.100.224.173 -- QA Node2
10.100.224.94 -- REG Node1
10.100.224.95 -- REG Node2
10.100.226.130 -- Dev Archive DB
10.100.226.222 -- Dev OEM DB
10.100.226.231 -- Dev Node1
10.100.226.232 -- Dev Node2

10.100.226.170 -- MAP Dev DB
10.100.224.170 -- MAP QA DB

ln -s /acfs/goldengate/ /opt/app/goldengate_new


BEGIN 
  SYS.DBMS_JOB.REMOVE(4005);
COMMIT;
END;
/

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( job       => X 
   ,what      => 'DECLARE 
      OUTMESSAGE VARCHAR2(100)    ;
      BEGIN
        PROC_REPLICATION_CHECK
        (''LoadTW'' /* VARCHAR2 */ ,''10'' /* NUMBER */ ,OUTMESSAGE /* VARCHAR2 */  );
     END; '
   ,next_date => to_date('22/02/2015 09:03:01','dd/mm/yyyy hh24:mi:ss')
   ,interval  => 'SYSDATE + 2/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
COMMIT;
END;
/




BEGIN 
  SYS.DBMS_JOB.REMOVE(4004);
COMMIT;
END;
/

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( job       => X 
   ,what      => 'DECLARE 
      OUTMESSAGE VARCHAR2(100)    ;
      BEGIN
        PROC_REPLICATION_CHECK
        (''LoadRE'' /* VARCHAR2 */ ,''10'' /* NUMBER */ ,OUTMESSAGE /* VARCHAR2 */  );
     END; '
   ,next_date => to_date('22/02/2015 09:05:38','dd/mm/yyyy hh24:mi:ss')
   ,interval  => 'SYSDATE + 2/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
COMMIT;
END;
/


BEGIN 
  SYS.DBMS_JOB.REMOVE(4005);
COMMIT;
END;
/

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( job       => X 
   ,what      => 'DECLARE 
      OUTMESSAGE VARCHAR2(100)    ;
      BEGIN
        PROC_REPLICATION_CHECK
        (''LoadTW'' /* VARCHAR2 */ ,''10'' /* NUMBER */ ,OUTMESSAGE /* VARCHAR2 */  );
     END; '
   ,next_date => to_date('22/02/2015 09:35:03','dd/mm/yyyy hh24:mi:ss')
   ,interval  => 'SYSDATE + 2/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
COMMIT;
END;
/


BEGIN 
  SYS.DBMS_JOB.REMOVE(64);
COMMIT;
END;
/

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( job       => X 
   ,what      => 'DECLARE
      OUTMESSAGE VARCHAR2(100)    ;
      BEGIN
        PROC_REPLICATION_CHECK
        (''LoadRW'' /* VARCHAR2 */ ,''10'' /* NUMBER */ ,OUTMESSAGE /* VARCHAR2 */  );
     END; '
   ,next_date => to_date('22/02/2015 09:36:27','dd/mm/yyyy hh24:mi:ss')
   ,interval  => 'SYSDATE + 2/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
COMMIT;
END;
/


p20206756_1121028_Linux-x86-64.zip



		Host-Name						  IP Address			Comments
-----------------------------------------------------------------------------------------------------
epl1mltidbs01.tsysacquiring.org			10.50.4.132				Columbus Archiving DB

wpl1tsnddbs01.tsysacquiring.org 		10.150.4.129			Transending New Server
epl1tsnddbs01.tsysacquiring.org  		10.50.4.135				StdBy DB

wpl1tsnddbs02.tsysacquiring.org 		10.150.4.130			Transending Parallel

wpl1gcaxdbs03.tsysacquiring.org 		10.150.4.123			GIT DB DCW
epl1gcaxdbs03.tsysacquiring.org 		10.50.4.123				StdBy DB

transitdb.ifxga.com						10.50.50.124			PayFuse DCE Parimary
transitdb.ifxtempe.com 					10.150.50.25			DCW StdBy DB

epl1mapxdbs01.tsysacquiring.org 		10.50.50.110			MAP Prod DCE Primary
epl1mapxdbs02.tsysacquiring.org 		10.50.50.113			MAP Prod DCE StdBy 
wpl1mapxdbs01.tsysacquiring.org 		10.150.50.110			MAP Prod DCW StdBy

wul2mapxdbs01.tsysacquiring.org  		10.100.126.170			MAP UAT	DCW

wdl2mapxdbs01.tsysacquiring.org 		10.100.226.170			MAP Dev	DB
wql2mapxdbs01.tsysacquiring.org 		10.100.224.170			MAP QA DB

---------------------------------------------------------------------------------------------

DECLARE
  user_name varchar2(30);
BEGIN
  select user into user_name from dual;
  execute immediate 'alter session set current_schema = SNOX';
  BEGIN
    SYS.DBMS_JOB.REMOVE(111);
    execute immediate 'alter session set current_schema = ' || user_name ;
  EXCEPTION
    WHEN OTHERS THEN
      execute immediate 'alter session set current_schema = ' || user_name ;
      RAISE;
  END;
  COMMIT;
END;
/


DECLARE
  X NUMBER;
  user_name varchar2(30);
BEGIN
  select user into user_name from dual;
  execute immediate 'alter session set current_schema = SNOX';
  BEGIN
    SYS.DBMS_JOB.SUBMIT
    ( job       => X 
     ,what      => 'SNOX.REPLICATOR_TIME_LAG;'
     ,next_date => to_date('12/02/2015 21:24:42','dd/mm/yyyy hh24:mi:ss')
     ,interval  => 'SYSDATE+10/1440 '
     ,no_parse  => FALSE
    );
    SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
    execute immediate 'alter session set current_schema = ' || user_name ;
  EXCEPTION
    WHEN OTHERS THEN 
      execute immediate 'alter session set current_schema = ' || user_name ;
      RAISE;
  END;
  COMMIT;
END;
/
---------------------------------------------------------------------------------------------

BEGIN 
  SYS.DBMS_JOB.REMOVE(4004);
COMMIT;
END;
/

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( JOB       => X 
   ,what      => 'DECLARE 
      OUTMESSAGE VARCHAR2(100)    ;
      BEGIN
        PROC_REPLICATION_CHECK
        (''LoadRE'' /* VARCHAR2 */ ,''10'' /* NUMBER */ ,OUTMESSAGE /* VARCHAR2 */  );
     END; '
   ,next_date => TO_DATE('10/02/2015 22:30:36','dd/mm/yyyy hh24:mi:ss')
   ,INTERVAL  => 'SYSDATE + 2/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(x));
COMMIT;
END;
/


BEGIN 
  SYS.DBMS_JOB.REMOVE(4004);
COMMIT;
END;
/

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( job       => X 
   ,what      => 'DECLARE 
      OUTMESSAGE VARCHAR2(100)    ;
      BEGIN
        PROC_REPLICATION_CHECK
        (''LoadTE'' /* VARCHAR2 */ ,''10'' /* NUMBER */ ,OUTMESSAGE /* VARCHAR2 */  );
     END; '
   ,next_date => to_date('01/01/4000 00:00:00','dd/mm/yyyy hh24:mi:ss')
   ,interval  => 'SYSDATE + 2/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
  SYS.DBMS_JOB.BROKEN
   (job    => X,
    broken => TRUE);
COMMIT;
END;
/


grant execute on transitha.sendmail_oracle to snox4transnox_cpass;


CREATE OR REPLACE PROCEDURE SNOX4TRANSNOX_CPASS."PROC_REPLICATION_CHECK" (
   inDatabase            IN     VARCHAR2,
   inLagAlertThreshold   IN     NUMBER,
   outMessage               OUT VARCHAR2)
IS
   tmpVar          NUMBER;
   vDatabaseRole   database_info.DB_ROLE%TYPE;
   vLag            NUMBER;
   vDC             database_info.DC%TYPE;
/******************************************************************************
   NAME:       Proc_Replication_check
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        11/6/2014   smalik       1. Created this procedure.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     Proc_Replication_check
      Sysdate:         11/6/2014
      Date and Time:   11/6/2014, 12:51:07 PM, and 11/6/2014 12:51:07 PM
      Username:        smalik (set in TOAD Options, Procedure Editor)
      Table Name:       (set in the "New PL/SQL Object" dialog)

******************************************************************************/
BEGIN
   tmpVar := 0;

   ----Check Database Role
   BEGIN
      SELECT db_role, DC
        INTO vDatabaseRole, vDC
        FROM database_info
       WHERE db_name = inDatabase;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         outMessage :=
               'No Data Found  Exception for Database '
            || inDatabase
            || ' from database_info Table';
         RETURN;
      WHEN TOO_MANY_ROWS
      THEN
         outMessage :=
               'Too Many Rows Exception for Database '
            || inDatabase
            || ' from database_info Table';
         RETURN;
      WHEN OTHERS
      THEN
         outMessage :=
               'Other Exception for Database '
            || inDatabase
            || ' from database_info Table';
         RETURN;
   END;

   IF vDatabaseRole = 'Primary'
   THEN
      BEGIN
         UPDATE Replication_status
            SET CURRENT_DATE1 = SYSDATE
          WHERE first_row = 1;

         IF SQL%ROWCOUNT = 0
         THEN
            INSERT INTO Replication_status
                 VALUES (1, SYSDATE);
         END IF;
      END;
   ELSE
      --Check Lag
      SELECT ROUND ( (SYSDATE - CURRENT_DATE1) * 1440)
        INTO vLag
        FROM Replication_status
       WHERE first_row = 1;

      IF vLag > inLagAlertThreshold
      THEN
         NULL;
         --Send Mail
         transitha.sendmail_oracle (
            'ifx-dbalerts@tsys.com',
            'ACQ-TransITProd3@tsys.com',
               'Alert : Lag on '
            || vDatabaseRole
            || ' Database '
            || inDatabase
            || ' - '
            || vDC
            || '.',
               'Current Lag is '
            || vLag
            || ' minutes at '
            || TO_CHAR (SYSDATE, 'MM/DD/YYYY HH24MISS'),
            25);
         transitha.sendmail_oracle (
            'ifx-dbalerts@tsys.com',
            'ifx-dbalerts@tsys.com',
               'Alert : Lag on '
            || vDatabaseRole
            || ' Database '
            || inDatabase
            || ' - '
            || vDC
            || '.',
               'Current Lag is '
            || vLag
            || ' minutes at '
            || TO_CHAR (SYSDATE, 'MM/DD/YYYY HH24MISS'),
            25);
      END IF;
   END IF;
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      NULL;
   WHEN OTHERS
   THEN
      -- Consider logging the error and then re-raise
      RAISE;
END Proc_Replication_check;  /* GOLDENGATE_DDL_REPLICATION */
/



# .bash_profile

ORACLE_HOSTNAME=$HOST; export ORACLE_HOSTNAME
ORACLE_UNQNAME=aqprod; export ORACLE_UNQNAME
ORACLE_BASE=/opt/oracle; export ORACLE_BASE
DB_HOME=$ORACLE_BASE/product/11.2.0/dbhome_1; export DB_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
ORACLE_SID=aqprod; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH; export PATH
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib; export LD_LIBRARY_PATH
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH


rman target / <<EOF
DELETE NOPROMPT ARCHIVELOG UNTIL TIME "SYSDATE-1";
DELETE EXPIRED ARCHIVELOG ALL;
CROSSCHECK ARCHIVELOG ALL;
EOF
exit




SYSDATE-10/1440






  


1) StandBy Database Info (using command dgmgrl)
2) Transending DR activities
3) TransIT DB KT
4) VIP used for GoldenGate Replication (How to stop/start and reload from node1 to node2)
5) HOw to check what/why is lagging in GoldenGate Replication
6) 




2015-01-30 02:20:13  INFO    OGG-00487  Oracle GoldenGate Capture for Oracle, epte.prm:  DDL operation included [INCLUDE ALL], optype [CREATE], objtype [TABLE], objowner [TRANSNOX_CAT], objname [CMP3$329423].
2015-01-30 02:20:13  INFO    OGG-00497  Oracle GoldenGate Capture for Oracle, epte.prm:  Writing DDL operation to extract trail file.
2015-01-30 02:20:13  ERROR   OGG-01433  Oracle GoldenGate Capture for Oracle, epte.prm:  Failed to validate table TRANSNOX_CAT.CMP4$329423. The table is compressed and extract will not be able to extract data from Oracle logs.
2015-01-30 02:20:14  ERROR   OGG-01668  Oracle GoldenGate Capture for Oracle, epte.prm:  PROCESS ABENDING.
2015-01-30 02:22:00  INFO    OGG-00953  Oracle GoldenGate Manager for Oracle, mgr.prm:  Purging log history from ggate.GGS_MARKER older than 2015-01-25 01:21:58.729268: 1664 rows deleted from ggate.GGS_MARKER.
2015-01-30 02:22:09  INFO    OGG-00953  Oracle GoldenGate Manager for Oracle, mgr.prm:  Purging log history from ggate.GGS_DDL_HIST older than 2015-01-25 01:22:00.972883: 6310 rows deleted from ggate.GGS_DDL_HIST.
2015-01-30 02:22:10  INFO    OGG-00953  Oracle GoldenGate Manager for Oracle, mgr.prm:  Purging log history from ggate.GGS_DDL_HIST_ALT older than 2015-01-25 01:22:09.751672: 810 rows deleted from ggate.GGS_DDL_HIST_ALT.
2015-01-30 02:22:31  INFO    OGG-00975  Oracle GoldenGate Manager for Oracle, mgr.prm:  EXTRACT EPTE starting.
2015-01-30 02:22:31  INFO    OGG-00965  Oracle GoldenGate Manager for Oracle, mgr.prm:  EXTRACT EPTE restarted automatically.
2015-01-30 02:22:31  INFO    OGG-00992  Oracle GoldenGate Capture for Oracle, epte.prm:  EXTRACT EPTE starting.
2015-01-30 02:22:31  INFO    OGG-03035  Oracle GoldenGate Capture for Oracle, epte.prm:  Operating system character set identified as UTF-8. Locale: en_US, LC_ALL:.
2015-01-30 02:22:31  INFO    OGG-02696  Oracle GoldenGate Capture for Oracle, epte.prm:  NON-ANSI SQL parameter syntax is used for parameter parsing.
2015-01-30 02:22:31  INFO    OGG-02095  Oracle GoldenGate Capture for Oracle, epte.prm:  Successfully set environment variable ORACLE_HOME=/opt/app/oracle/product/11.2.0/dbhome_2.





/oradata8/oracle/dpump


expdp rchaudhari directory=bkup dumpfile=exp_trans_27Jan2015.dmp logfile=exp_trans_28Jan2015.log schemas=transnox_gca include=table:\"like \'TRANS%\'\" query=\"where transaction_id \>\= 2113189461\" content=data_only compression=all reuse_dumpfiles=y

expdp rchaudhari directory=bkup dumpfile=expdpTnox_task_28Jan2015.dmp logfile=expdpTnox_task_28Jan2015.log schemas=transnox_gca include=table:\"like \'TASK%\'\" query=\"where task_id \>\= 1048417748\"  content=data_only compression=all reuse_dumpfiles=y data_options=xml_clobs

-- started
expdp rchaudhari directory=bkup dumpfile=expdpTnox_NotLike_Trans_n_Task_28Jan2015.dmp logfile=expdpTnox_NotLike_Trans_n_Task_28Jan2015.log schemas=transnox_gca exclude=statistics,table:\" like \'TRANS%\'\",table:\" like \'TASK%\'\",table:\" like \'SN_TEMP%\'\",table:\" like \'SC_TEMP%\'\" content=data_only compression=all reuse_dumpfiles=y data_options=xml_clobs

-- expdp rchaudhari directory=bkup dumpfile=expdpSnox_GCA_27Jan2015.dmp logfile=expdpSnox_GCA_27Jan2015.log schemas=snox4transnox_gca exclude=statistics,table:\" like \'EVENT%\'\",table:\" like \'INFONOX%\'\",table:\" like \'SN_TEMP%\'\",table:\" like \'SC_TEMP%\'\"  content=data_only compression=all reuse_dumpfiles=y data_options=xml_clobs

-- expdp rchaudhari directory=bkup dumpfile=expdpSNOX_GWM_MetaData_27Jan2015.dmp logfile=expdpSNOX_GWM_MetaData_27Jan2015.log schemas=snox4transnox,transnox_wm,transnox_glory exclude=statistics,table:\" like \'SN_TEMP%\'\",table:\" like \'SC_TEMP%\'\" content=metadata_only compression=all reuse_dumpfiles=y 
-- impdp rchaudhari directory=bkup dumpfile=expdpSNOX_GWM_MetaData_27Jan2015.dmp logfile=impdp_expdpSNOX_GWM_MetaData_27Jan2015.log remap_tablespace=TRANS_DATA1:WM_GLORY_DATA remap_tablespace=TRANS_DATA2:WM_GLORY_DATA remap_tablespace=USERS:WM_GLORY_DATA remap_tablespace=USERS1:WM_GLORY_DATA remap_tablespace=USERS2:WM_GLORY_DATA remap_tablespace=TRANS_DATA3:WM_GLORY_DATA remap_tablespace=TS_TRANS_DATA1:WM_GLORY_DATA remap_tablespace=INDX:WM_GLORY_CUST_INDX remap_tablespace=INDEX_1:WM_GLORY_CUST_INDX


-- expdp rchaudhari directory=bkup dumpfile=expdpTnox_snox4transnox_27Jan2015.dmp logfile=expdpTnox_snox4transnox_27Jan2015.log schemas=snox4transnox exclude=statistics,table:\" like \'EVENT%\'\",table:\" like \'INFONOX%\'\",table:\" like \'SN_TEMP%\'\",table:\" like \'SC_TEMP%\'\"  content=data_only compression=all reuse_dumpfiles=y data_options=xml_clobs
-- expdp rchaudhari directory=bkup dumpfile=expdpTnox_glory_27Jan2015.dmp logfile=expdpTnox_glory_27Jan2015.log schemas=transnox_glory exclude=statistics,table:\" like \'SN_TEMP%\'\",table:\" like \'SC_TEMP%\'\"  content=data_only compression=all reuse_dumpfiles=y data_options=xml_clobs
-- expdp rchaudhari directory=bkup dumpfile=expdpTnox_wm_27Jan2015.dmp logfile=expdpTnox_wm_27Jan2015.log schemas=transnox_wm exclude=statistics,table:\" like \'SN_TEMP%\'\",table:\" like \'SC_TEMP%\'\" content=data_only compression=all reuse_dumpfiles=y data_options=xml_clobs




/*
transaction_id >= 2282915447 
task_id >= 1160973017 


expdp rchaudhari directory=bkup dumpfile=expdpTnox_trans_13m.dmp logfile=expdpTnox_trans_13m.log schemas=transnox_gca include=table:\"like \'TRANS%\'\" query=\"where transaction_id \>\= 2111429013\" content=data_only compression=all reuse_dumpfiles=y

expdp rchaudhari directory=bkup dumpfile=expdpTnox_other_tables_bkup.dmp logfile=expdpTnox_other_tables_bkup.log schemas=transnox_gca exclude=statistics,table:\" like \'TRANS%\'\",table:\" like \'EVENT%\'\",table:\" like \'INFONOX%\'\" content=data_only compression=all reuse_dumpfiles=y data_options=xml_clobs


table:\" like \'EVENT%\'\",table:\" like \'INFONOX%\'\"
*/


select tablespace_name,count(*) from dba_segments where owner in ('TRANSNOX_GCA','SNOX4TRANSNOX_GCA','TNOXGCA518','SNOXGCA518','TNOXGCA_91X_20109','SNOXGCA_91X_20109') group by tablespace_name


impdp rchaudhari directory=bkup dumpfile=expdpSNOX_GCA_MetaData_27Jan2015.dmp logfile=impdp_expdpSNOX_GCA_MetaData_27Jan2015.log remap_tablespace=INDEX_1:tnox_indx remap_tablespace=INDEX_3:tnox_indx remap_tablespace=INDX:tnox_indx remap_tablespace=TINDEX1:tnox_indx remap_tablespace=TINDEX3:tnox_indx remap_tablespace=TINDEX4:tnox_indx remap_tablespace=TS_INDEX_1:tnox_indx remap_tablespace=TRANSINDEX:tnox_indx remap_tablespace=TDATA2:tnox_data remap_tablespace=TDATA3:tnox_data remap_tablespace=TDATA4:tnox_data remap_tablespace=TDATA5:tnox_data remap_tablespace=TRANSDATA:tnox_data remap_tablespace=TRANS_DATA2:tnox_data remap_tablespace=TRANS_DATA3:tnox_data remap_tablespace=TSDATA1:tnox_data remap_tablespace=TSDATA2:tnox_data remap_tablespace=TSDATA3:tnox_data remap_tablespace=TS_TRANS_DATA1:tnox_data remap_tablespace=TS_TRANS_DATA2:tnox_data remap_tablespace=TS_TRANS_DATA3:tnox_data remap_tablespace=USERS:tnox_data remap_tablespace=USERS1:tnox_data remap_tablespace=USERS2:tnox_data

expdp rchaudhari directory=bkup dumpfile=expdpSNOX_GCA_MetaData_27Jan2015.dmp logfile=expdpSNOX_GCA_MetaData_27Jan2015.log schemas=snox4transnox_GCA, exclude=statistics,table:\" like \'SN_TEMP%\'\",table:\" like \'SC_TEMP%\'\" content=metadata_only compression=all reuse_dumpfiles=y





TRANS_DATA1
TS_INDEX_3
TXN_TRANS_DATA5
TS_TRANS_DATA3
TS_TRANS_DATA4
TS_INDEX_6
INDEX_3
TRANS_DATA2
TS_TRANS_DATA5
TXN_TRANS_DATA1
TXN_INDEX_1
USERS
USERS2
INDEX_2
USERS1
TRANSINDEX
TS_INDEX_4
TXN_TRANS_DATA3
TXN_TRANS_DATA6
TS_INDEX_1
INDX
TS_TRANS_DATA2
TS_INDEX_5
TXN_TRANS_DATA4
ARC_DATA
TS_TRANS_DATA1
INDEX_1
TRANSDATA
TXN_TRANS_DATA2



impdp rchaudhari directory=bkup dumpfile=expdpSNOX_GCA_MetaData_27Jan2015.dmp logfile=impdp_expdpSNOX_GCA_MetaData_27Jan2015.log remap_tablespace=INDEX_1:tnox_indx remap_tablespace=INDEX_3:tnox_indx remap_tablespace=INDX:tnox_indx remap_tablespace=TINDEX1:tnox_indx remap_tablespace=TINDEX3:tnox_indx remap_tablespace=TINDEX4:tnox_indx remap_tablespace=TS_INDEX_1:tnox_indx remap_tablespace=TRANSINDEX:tnox_indx remap_tablespace=TDATA2:tnox_data remap_tablespace=TDATA3:tnox_data remap_tablespace=TDATA4:tnox_data remap_tablespace=TDATA5:tnox_data remap_tablespace=TRANSDATA:tnox_data remap_tablespace=TRANS_DATA2:tnox_data remap_tablespace=TRANS_DATA3:tnox_data remap_tablespace=TSDATA1:tnox_data remap_tablespace=TSDATA2:tnox_data remap_tablespace=TSDATA3:tnox_data remap_tablespace=TS_TRANS_DATA1:tnox_data remap_tablespace=TS_TRANS_DATA2:tnox_data remap_tablespace=TS_TRANS_DATA3:tnox_data remap_tablespace=USERS:tnox_data remap_tablespace=USERS1:tnox_data remap_tablespace=USERS2:tnox_data




TRANSIT_FE_TNOX_317
TRANSIT_FE_SNOX_317



transaction_id >= 2113189461

task_id >= 1048417748 

oracle composite PRIMARY KEY nullable

SESSION locks
SESSION dead locks


-- entity
* is for not null
0 is for option
# is for unique 



1) single values and unique values
2) functionally dependent -- will come in picture where compsite primary is present
3) transitivlly dependent -- will come in pic. where 


-- data type guid column as char and not varchar
select sys_guid() from dual


do not create primary key on varchar2 data types, either create it on char

logincal read and physical read

unique index scan and normal index scan

calculation on column in where condition will not use index


deterministict function and non-deterministic function


-- index will be used
enmae like 'abc%'

-- index will be not used
enmae like '%abc'

domain indexes


index skip scan

reverse index








cluvfy stage -post hwos -n loadrpdbnode2,loadrpdbnode3,loadrpdbnode1 -verbose



cluvfy comp peer -refnode racnode1 -n loadrpdbnode1 -orainv oinstall -osdba dba -verbose

 
 
 -- RAC utility
 ./tfactl diagcollect
https://support.oracle.com/epmos/faces/DocumentDisplay?_afrLoop=374923723435124&id=1513912.1&_afrWindowMode=0&_adf.ctrl-state=abf5azwgf_4


-- Philips SBT30GRN/00 Bluetooth Portable Speaker
http://www.amazon.in/Philips-SBT30GRN-00-Bluetooth-Portable/dp/B008OQLJN4/ref=pd_sim_sbs_e_3?ie=UTF8&refRID=1FJ98HVCKX6AMDWSM8GB

-----------------------------------------------------------
-- Stop and Start Shalre Flex Replication


create spfile before shutingdown

10.175.16.22



 sudo su -l spadmin
 
 sp_ctrl
 
 show
 
 shutdown
 
 exit
 
 stop database
 
 reboot db server
 
 spadmin
 
 sp_cop -u 2100 &
 
 sp_ctrl
 
 show
 
 -- all should be running 
 
 --there should not be any stopped deu to error
 
 
exit

 ps -ef|grep sp_


-----------------------------------------------------------

-- Start 20Oct2014

GRANT SELECT ON TRANSNOX_IOX.MV_DASHBOARD_CUSTOMER TO TRANSIT_GATEWAY_TNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_DASHBOARD_CUSTOMER TO TRANSIT_GATEWAY_SNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_DASHBOARD_DISCOUNT TO TRANSIT_GATEWAY_TNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_DASHBOARD_DISCOUNT TO TRANSIT_GATEWAY_SNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_DASHBOARD_PRODUCT TO TRANSIT_GATEWAY_TNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_DASHBOARD_PRODUCT TO TRANSIT_GATEWAY_SNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_DASHBOARD_SALES TO TRANSIT_GATEWAY_TNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_DASHBOARD_SALES TO TRANSIT_GATEWAY_SNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_MER_XTN_MINMAX_AMT TO TRANSIT_GATEWAY_TNOX_316 ;
GRANT SELECT ON TRANSNOX_IOX.MV_MER_XTN_MINMAX_AMT TO TRANSIT_GATEWAY_SNOX_316 ;


CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_SNOX_316.MV_DASHBOARD_PRODUCT FOR TRANSNOX_IOX.MV_DASHBOARD_PRODUCT;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_SNOX_316.MV_DASHBOARD_CUSTOMER FOR TRANSNOX_IOX.MV_DASHBOARD_CUSTOMER;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_SNOX_316.MV_DASHBOARD_DISCOUNT FOR TRANSNOX_IOX.MV_DASHBOARD_DISCOUNT;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_SNOX_316.MV_DASHBOARD_SALES FOR TRANSNOX_IOX.MV_DASHBOARD_SALES;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_SNOX_316.MV_MER_XTN_MINMAX_AMT FOR TRANSNOX_IOX.MV_MER_XTN_MINMAX_AMT;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_TNOX_316.MV_DASHBOARD_CUSTOMER FOR TRANSNOX_IOX.MV_DASHBOARD_CUSTOMER;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_TNOX_316.MV_DASHBOARD_DISCOUNT FOR TRANSNOX_IOX.MV_DASHBOARD_DISCOUNT;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_TNOX_316.MV_DASHBOARD_PRODUCT FOR TRANSNOX_IOX.MV_DASHBOARD_PRODUCT;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_TNOX_316.MV_DASHBOARD_SALES FOR TRANSNOX_IOX.MV_DASHBOARD_SALES;
CREATE OR REPLACE SYNONYM TRANSIT_GATEWAY_TNOX_316.MV_MER_XTN_MINMAX_AMT FOR TRANSNOX_IOX.MV_MER_XTN_MINMAX_AMT;



EXEC DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_TNOX_315');
EXEC DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_SNOX_315');
EXEC DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_TNOX_315');
EXEC DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_SNOX_315');

TRANSIT_GATEWAY_sNOX_315.PRC_ASSOCIATE_CUSTOMER_GROUP


alter user TRANSIT_GATEWAY_TNOX_315 profile appusers;
alter user TRANSIT_GATEWAY_SNOX_315 profile appusers;
alter user TRANSIT_SMSNOX_TNOX_315 profile appusers;
alter user TRANSIT_SMSNOX_SNOX_315 profile appusers;


alter user TRANSIT_GATEWAY_TNOX_315 identified by "TransITgwaY$TNox315";
alter user TRANSIT_GATEWAY_SNOX_315 identified by "TransITgwaY$sNox315";
alter user TRANSIT_SMSNOX_TNOX_315 identified by "Transit_SMSnox$TNOX315";
alter user TRANSIT_SMSNOX_SNOX_315 identified by "Transit_SMSnox$SNOX315";

CREATE OR REPLACE TYPE TRANSIT_GATEWAY_TNOX_315."MYARRAY" AS TABLE OF VARCHAR2(1000);



-- Ends Here


-- Start Date 06-OCT-2014

ALTER SESSION SET CURRENT_SCHEMA=webfort_cpass;

UPDATE ARADMINBASICAUTHUSER SET 
PASSWORD='ng5q9WLrfcDAhFubls3WtZCtA5c=' 
WHERE USERID='MASTERADMIN'; 

UPDATE ARADMINBASICAUTHUSER SET STRIKECOUNT='0' 
WHERE USERID='MASTERADMIN'; 

COMMIT;

-- Ends Here


---------------------------------------------------------------------------------------
-- Start Date 01-OCT-2014

-- Transending TransCapitalOne Schema's tables
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'TRANSACTIONS');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'TRANSACTION_DETAILS');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'TRANSACTIONS_MERCHANTSCOUT_DET');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'PRE_SET_TRANSACTION_STATE_LOG');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'XTN_UPLOAD_STATS');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'MERCHANTSCOUT_SCORES');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'SETTLEMENT_BATCH_HISTORY');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'FILE_UPLOAD_DATA_HIST');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'VITAL_TRANSACTIONS_HIST');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'VITAL_DAILY_DT_HIST');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'VITAL_DT_EXTENTION_HIST');

EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'PRE_SET_TRANSACTION_STATE_LOG');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'MASTER_MERCHANTSCOUT');
EXECUTE DBMS_STATS.gather_table_stats ('TRANSCAPITALONE', 'APP_MERCHANT_MASTER');



UPDATE transgca.MERCHANT_BACKEND_STATUS  set BACKEND_STATUS='E' where APPLICATION_ID =2363 and BACKEND_PROCESSOR='VITAL';








-- Ends Here


---------------------------------------------------------------------------------------
-- CC# changes for 05-Feb-2014
UPDATE SNOX4TRANSNOX.OPERATOR SET BUSINESS_ENTITY_TYPE_ID = 3 
WHERE OPERATOR_ID IN ('TA43443','TA42965','TA42567','TA49494','TA200561')
AND BUSINESS_ENTITY_TYPE_ID IS NULL; 

UPDATE SNOX4TRANSNOX.MERCHANT_ACTIVATION_URL 
SET STATUS='ACTIVATED'
WHERE MERCHANT_ID='WL6LRWL2';
AND UNIQUE_ID='VVF3B91D193JF70LS3V8V0ONE7LO6DT9'; 

------------------------------------------------------------------------------------------


activate config config_col_tempe_012214.cfg 

SET echo ON
SELECT TO_CHAR(SYSDATE,'mm/dd/yyyy hh24:mi:ss')Start_time FROM dual;

UPDATE TRANSSIGUE.APP_MERCHANT_MASTER SET FLG_STATUS='I' WHERE APPLICATION_ID = 64997;

COMMIT;
SELECT TO_CHAR(SYSDATE,'mm/dd/yyyy hh24:mi:ss')End_time FROM dual;




--- Columbus
SELECT * FROM SNOX4TRANSNOX_GCA.PROCESSOR_CONFIGURATION WHERE PROCESSOR_ID='SMM';

CREATE TABLE rchaudhari.PROCESSOR_CONFIGURATION AS SELECT * FROM snox4transnox_gca.PROCESSOR_CONFIGURATION;

UPDATE SNOX4TRANSNOX_GCA.PROCESSOR_CONFIGURATION
SET PROCESSOR_ID='SAM', PROPERTY_VALUE='http://gcatadapter.ifxga.com:9511/servlets/TransNox_Adapter_Interface'
WHERE PROCESSOR_ID='SMM';

COMMIT;



-- Tempe
SELECT * FROM SNOX4TRANSNOX_GCA.PROCESSOR_CONFIGURATION WHERE PROCESSOR_ID='SMM';

CREATE TABLE rchaudhari.PROCESSOR_CONFIGURATION AS SELECT * FROM snox4transnox_gca.PROCESSOR_CONFIGURATION;

UPDATE SNOX4TRANSNOX_GCA.PROCESSOR_CONFIGURATION
SET PROCESSOR_ID='SAM', PROPERTY_VALUE='http://gcatadapter.ifxtempe.com:9511/servlets/TransNox_Adapter_Interface'
WHERE PROCESSOR_ID='SMM';

COMMIT;




install rsync copy script on 10.100.224.170 mapqa and 10.100.226.170 mapdev this is for moving weekly export data.

Details of the server where rsync script will be install
10.100.224.170,
10.100.226.170




 --- Sony Smartwatch
 
bkupDate=`date +%d%b%Y`
cd /backup/oracle/bkups/dpump

expdp / directory=backup dumpfile=expdp_regracdb1_bkups_$bkupDate.dmp logfile=expdp_regracdb1_bkupslogs_$bkupDate.log exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\" exclude=SCHEMA:\"IN \(\'ANONYMOUS\',\'APEX_030200\',\'APEX_PUBLIC_USER\',\'APPQOSSYS\',\'CTXSYS\',\'DBSNMP\',\'DIP\',\'EXFSYS\',\'FLOWS_FILES\',\'MDDATA\',\'MDSYS\',\'MGMT_VIEW\',\'OLAPSYS\',\'OPS$ORACLE\',\'ORACLE_OCM\',\'ORDDATA\',\'ORDPLUGINS\',\'ORDSYS\',\'OUTLN\',\'OWBSYS\',\'OWBSYS_AUDIT\',\'RMAN\',\'SI_INFORMTN_SCHEMA\',\'SPATIAL_CSW_ADMIN_USR\',\'SPATIAL_WFS_ADMIN_USR\',\'SYS\',\'SYSMAN\',\'SYSTEM\',\'XDB\',\'XS$NULL\'\)\" full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y

tar -cvzf expdp_regracdb1_bkups_$bkupDate.tar.gz expdp_regracdb1_bkups_$bkupDate.dmp expdp_regracdb1_bkupslogs_$bkupDate.log

rm -f expdp_regracdb1_bkups_$bkupDate.dmp

rsync -uvrpogtlz /backup/oracle/bkups/dpump/expdp_regracdb1_bkups_$bkupDate.tar.gz  10.100.226.130::qadbnode2


rsync -uvrpogtlz /backup/oracle/bkups/dumpfiles/testing.log  10.100.226.130::regdbnode1



bkupDate=`date +%d%b%Y`
cd /recovery/oracle/bkups/dumpfiles

expdp / directory="BKUPS" dumpfile="expdp_devracdb2_bkups_$bkupDate.dmp" logfile="logs_expdp_devracdb2_bkups.log" exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\",schema:\"in \(\'XS$NULL\',\'XDB\',\'WMSYS\',\'TOAD\',\'SYSTEM\',\'SYSMAN\',\'SYS\',\'SPATIAL_WFS_ADMIN_USR\',\'SPATIAL_CSW_ADMIN_USR\',\'SI_INFORMTN_SCHEMA\',\'RMAN\',\'OWBSYS_AUDIT\',\'OWBSYS\',\'OUTLN\',\'ORDSYS\',\'ORDPLUGINS\',\'ORDDATA\',\'ORACLE_OCM\',\'OPS$ORACLE\',\'OLAPSYS\',\'MGMT_VIEW\',\'MDSYS\',\'FLOWS_FILES\',\'EXFSYS\',\'DIP\',\'DBSNMP\',\'CTXSYS\',\'APPQOSSYS\',\'APEX_PUBLIC_USER\',\'APEX_030200\',\'ANONYMOUS\'\)\"  full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y

tar -cvzf expdp_devracdb2_bkups_$bkupDate.tar.gz expdp_devracdb2_bkups_$bkupDate.dmp logs_expdp_devracdb2_bkups.log

rm -f expdp_devracdb2_bkups_$bkupDate.dmp

rsync -uvrpogtlz /recovery/oracle/bkups/dumpfiles/logs_expdp_devracdb2_bkups_17Oct2013.log 10.100.226.130::devdbnode2



Rcomnodalofficer.MH@relianceada.com



bkupDate=`date +%d%b%Y`
cd /backup/oracle/bkups/dpump

expdp / directory="BKUP_DPUMP" dumpfile="expdp_qaracdb2_bkups_$bkupDate.dmp" logfile="expdp_qaracdb2_bkupslogs_$bkupDate.log" exclude=statistics,table:"like 'SN_TEMP%'",table:"like 'SC_TEMP%'" exclude=SCHEMA:"IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDSYS','MGMT_VIEW','OLAPSYS','OPS$ORACLE','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','OWBSYS_AUDIT','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','WMSYS','XDB','XS$NULL')" full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y

tar -cvzf expdp_qaracdb2_bkups_$bkupDate.tar.gz	expdp_qaracdb2_bkups_$bkupDate.dmp expdp_qaracdb2_bkupslogs_$bkupDate.log

rm -f expdp_qaracdb2_bkups_$bkupDate.dmp

rsync -uvrpogtlz /backup/oracle/bkups/dpump/expdp_qaracdb2_bkups_$bkupDate.tar.gz  10.100.226.130::qadbnode2


expdp / directory=BKUP_DPUMP dumpfile=expdp_qaracdb2_bkups_$bkupDate.dmp logfile=expdp_qaracdb2_bkupslogs_$bkupDate.log exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\" exclude=SCHEMA:\"IN \(\'ANONYMOUS\',\'APEX_030200\',\'APEX_PUBLIC_USER\',\'APPQOSSYS\',\'CTXSYS\',\'DBSNMP\',\'DIP\',\'EXFSYS\',\'FLOWS_FILES\',\'MDSYS\',\'MGMT_VIEW\',\'OLAPSYS\',\'OPS$ORACLE\',\'ORACLE_OCM\',\'ORDDATA\',\'ORDPLUGINS\',\'ORDSYS\',\'OUTLN\',\'OWBSYS\',\'OWBSYS_AUDIT\',\'SCOTT\',\'SI_INFORMTN_SCHEMA\',\'SPATIAL_CSW_ADMIN_USR\',\'SPATIAL_WFS_ADMIN_USR\',\'SYS\',\'SYSMAN\',\'SYSTEM\',\'WMSYS\',\'XDB\',\'XS$NULL\'\)\" full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y


rsync -uvrpogtlz /recovery/oracle/bkups/dumpfiles/logs_expdp_devracdb2_bkups_17Oct2013.log 10.100.226.130::devdbnode2


Please set customer profile to VIP status.

Primary account: 15951812
			
customerstatus -- change should be made to casino or for all casino of the customercode
customerstatuslist




Page 
58
60
	 
	 
Img	User	Status	Def Tablespace	Temp Tablespace	Date Created
		OPEN	USERS	TEMP	10/29/2013 12:10:51 AM
		OPEN	USERS	TEMP	10/29/2013 12:10:51 AM
		LOCKED	USERS	TEMP	2/7/2012 9:31:08 PM
		LOCKED	USERS	TEMP	2/7/2012 9:31:07 PM


DCC_BIN_EXCLUSION_LOOKUP
DCC_REQUEST
DCC_RESPONSE
transnox_recon.DCC_TRANSACTION_LINK
transnox_gca.BOARDING_OF_TERMINALS 



CREATE VIEW missing_index AS
SELECT UNIQUE table_owner, table_name, column_name, index_name, mixs
FROM 
(
    SELECT i.table_owner, i.table_name, i.column_name, i.index_name,
      NVL2((SELECT UNIQUE dic.table_name FROM all_ind_columns dic WHERE DIC.TABLE_NAME = i.table_name AND dic.table_owner = i.table_owner AND dic.column_name = i.column_name AND dic.table_owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mixs 
    FROM     
    (
        SELECT index_owner, index_name, table_owner, table_name, column_name
        FROM all_ind_columns@tp62
        WHERE index_owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')
          AND table_name NOT LIKE '%ORG'
        ORDER BY index_owner,table_owner,table_name ASC
    )i
)
WHERE mixs='N'
ORDER BY 1,2,3 ASC 

CREATE INDEX TRANSNOX_GCA.IDX_TCASH_TIMESTAMP ON TRANSNOX_GCA.TRANS_CASH
(TIMESTAMP)
TABLESPACE INDX;


CREATE INDEX TRANSNOX_GCA.IDX_ADMIN_TYPE ON TRANSNOX_GCA.ADMIN_TRANSACTION
(ADMIN_TRANS_TYPE)
TABLESPACE INDEX_1;

CREATE INDEX TRANSNOX_GCA.IDX_CUSTCODE ON TRANSNOX_GCA.TASK
(CUSTOMER_CODE)
TABLESPACE INDEX_3;

CREATE INDEX TRANSNOX_GCA.IDX_TRANS_TASK_ID ON TRANSNOX_GCA.TRANSACTION
(TASK_ID)
TABLESPACE INDX;


CREATE INDEX TRANSNOX_GCA.IDX_FILED_CODE_TIMESTAMP ON TRANSNOX_GCA.TRANS_ADDITIONAL_INFO
(FIELD_CODE, TIMESTAMP)
TABLESPACE USERS;

EXEC DBMS_UTILITY.COMPILE_SCHEMA('TRANSNOX_RECON');
EXEC DBMS_UTILITY.COMPILE_SCHEMA('TRANSNOX_GCA');


SELECT UNIQUE owner, table_name, column_name, mis_conts
FROM 
(
    SELECT dcc.owner, dcc.table_name, dcc.column_name, 
        NVL2((SELECT UNIQUE dc.table_name FROM dba_cons_columns dc WHERE dc.owner=dcc.owner AND dc.table_name = dcc.table_name AND dc.column_name = dcc.column_name AND  dc.table_name NOT LIKE 'BIN$%' AND dc.owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP') AND dc.table_name NOT LIKE '%ORG'),'Y','N') mis_conts
    FROM
    (
        SELECT owner, constraint_name, table_name, column_name 
        FROM dba_cons_columns@tp62
        WHERE owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')
          AND table_name NOT LIKE '%ORG' AND table_name NOT LIKE 'BIN$%'
        ORDER BY owner, constraint_name, table_name, column_name ASC
    )dcc
)
WHERE mis_conts='N'
  AND REGEXP_LIKE(table_name,'[^0-9]$','i')
ORDER BY 1,2,3 ASC 

SELECT * 
FROM dba_constraints
WHERE owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')
  AND table_name NOT LIKE '%ORG' AND table_name NOT LIKE 'BIN$%'
  AND CONSTRAINT_TYPE IN ('C','O')
  AND TO_CHAR(SEARCH_CONDITION) LIKE '%IS NOT NULL'

SNOX4TRANSNOX_GCA.DCCCURRENCY




CREATE VIEW missing_obj AS
SELECT owner, object_name, object_type, mis_tables, mis_view, mis_proc, mis_func, mis_tri, mis_pac, mis_pac_body, mis_seq 
FROM 
(    
    SELECT UNIQUE doj.owner, doj.object_name, doj.object_type,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='TABLE' AND OBJECT_name NOT LIKE 'SN_TEMP%' AND OBJECT_name NOT LIKE 'SC_TEMP%' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mis_tables,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mis_view,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mis_proc,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mis_func,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mis_tri,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name AND owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mis_pac,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mis_pac_body,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')),'Y','N') mis_seq
    FROM 
    (
        SELECT owner, object_name, object_type  
        FROM all_objects@tp62
        WHERE owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')
          AND object_name NOT LIKE '%ORG' AND object_name NOT LIKE 'BIN$%'
          AND object_name NOT LIKE '%REPL'
          AND object_type IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
        ORDER BY owner, object_name, object_type ASC
    ) doj
)
WHERE mis_tables='N'
  AND mis_view='N'
  AND mis_proc='N'
  AND mis_func='N'
  AND mis_tri='N'
  AND mis_pac='N'
  AND mis_pac_body='N'
  AND mis_seq='N'
  AND REGEXP_LIKE(object_name,'[^0-9]$','i')
ORDER BY 1,2,3 ASC


SELECT * FROM missing_obj




SELECT owner, object_name, object_type, mis_tables, mis_view, mis_proc, mis_func, mis_tri, mis_pac, mis_pac_body, mis_seq 
FROM 
(    
    SELECT UNIQUE doj.owner, doj.object_name, doj.object_type,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TABLE' AND OBJECT_name NOT LIKE 'SN_TEMP%' AND OBJECT_name NOT LIKE 'SC_TEMP%' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mis_tables,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mis_view,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mis_proc,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mis_func,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mis_tri,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name AND owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mis_pac,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mis_pac_body,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name  AND owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mis_seq
    FROM 
    (
        SELECT owner, object_name, object_type  
        FROM dba_objects@t2
        WHERE owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')
          AND object_name NOT LIKE '%ORG' AND object_name NOT LIKE 'BIN$%'
          AND object_name NOT LIKE '%REPL'
          AND object_type IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
        ORDER BY owner, object_name, object_type ASC
    ) doj
)
WHERE mis_tables='N'
  AND mis_view='N'
  AND mis_proc='N'
  AND mis_func='N'
  AND mis_tri='N'
  AND mis_pac='N'
  AND mis_pac_body='N'
  AND mis_seq='N'
  AND REGEXP_LIKE(object_name,'[^0-9]$','i')
ORDER BY 1,2,3 ASC



Index
constraint
objects


QCP.CUSTOMER_SIGNATURE,CHECKCASH.LIMIT_ENROLLMENT_RESPONSE



1. Lock application Schemas -- Tempe 62, 22, 

2. Kill LOCAL+NO pid from server -- Tempe 62, 22
ps -ewf |grep "LOCAL=NO"|awk '{print $2}' | xargs kill -9

3. update qcp.user_login_data --- Columbus 62
Update QCP.USER_LOGIN_DATA
SET LOGOUTTIME = SYSDATE
WHERE LOGOUTTIME IS NULL 	



'KEYNOX_FX','TRANSNOX_GLORY','SNOXGCA_91X_20109','TRANSNOX_WM','TNOXGCA518','SNOX4TRANSNOX','SNOXGCA518','TNOXGCA_91X_20109','TRANSNOX_GCA','SNOX4TRANSNOX_GCA'
SPLEX2100
SYS




WITH aeiou AS (select xtn.TASK_ID "Task_ID",xtn.TRANSACTION_ID "Transaction_ID",tsk.CUSTOMER_CODE "Customer_Code&quorbeer@damnit ~NAME||' '||cust.LAST_NAME "Customer_Name",ltt.DESCRIPTION "Transaction_Type",lts.DESCRIPTION "Transaction_Status",NVL(tv.STATUS,'NA') &q$� ssh -o ServerAliveInterval=30 172.24.130.20MP "Server_Timestamp",xtn.CLIENT_TIMESTAMP "Client_Timestamp",xtn.AMOUNT/100 "Transaction_Amount",xtn.FEE_CHARGED/100 "Transaction_Fee",xtn.FEE_WAIVED/100 "Fee_Waived",(SELECT tf.VALUE FROM TRANS_FEE_DETAIL tf WHERE tf.FEE_NAME=' PROMO_DISCOUNT' AND xtn.TRANSACTION_ID = tf.TRANSACTION_ID )/100 "Discount",(CASE WHEN dcclink.accepted = 'T' THEN to_char(dcc.dispensed_amount/power(10, cur.decimalplaces)) ELSE to_char((NVL(xtn.AMOUNT,0) + NVL(xtn.fee_charged, 0))/100, '999,999,990.00') END) "Authorization_Amount",(CASE WHEN dcclink.accepted = 'T' THEN cur.alphacode ELSE NVL(xtn.CURRENCY,'NA') END) "Authorization_Currency",dev.LOCATION "Device_Location",dev.ALIAS "Device_Name",xtn.DEVICE_ID "Device_ID",mer.MERCHANT_ID "Merchant_ID",mer.CORPORATION_ID "Corporation_ID",xtn.TRANS_TYPE "Trans_Type",ltt.TASK_TYPE "Code",corp.COMPANY_CODE "Company_ID",to_char(xtn.TIME_STAMP,'MM-DD-YYYY') "Date",xtn.TRANS_STATUS "Status"� from TRANSACTION xtn,TASK tsk,LOOKUP_TRANS_TYPE ltt,LOOKUP_TRANS_STATUS lts,DEVICE dev,MERCHANT mer,CORPORATION corp,CUSTOMER cust,TRANS_VOID tv,dcc_response dcc,dcc_transaction_link dcclink,dcccurrency cur� where� xtn.TRANS_TYPE=ltt.CODE� and� xtn.TRANS_STATUS=lts.CODE� and� xtn.DEVICE_ID=dev.DEVICE_ID� and� dev.MERCHANT_ID=mer.MERCHANT_ID� and� mer.CORPORATION_ID = corp.CORPORATION_ID� and� xtn.TASK_ID = tsk.TASK_ID� and� cust.CUSTOMER_CODE(+) = tsk.CUSTOMER_CODE� and� xtn.TRANSACTION_ID = tv.TRANSACTION_ID(+)� and� xtn.TRANSACTION_ID = dcclink.TRANSACTION_ID(+)� and� dcc.reference_number(+) = dcclink.reference_number� and� dcc.dcc_transaction_currency = cur.code(+)� and� xtn.TIME_STAMP� between to_date('11-12-2013 00:00:00', 'mm-dd-yyyy hh24:mi:ss')� and to_date('11-12-2013 23:59:59', 'mm-dd-yyyy hh24:mi:ss')�� and� corp.COMPANY_CODE = 'GCA'�� order by xtn.TIME_STAMP desc 

http://shreemahavircourier.in/SingleTracking.aspx?Doc_No=1031101003740

1031101003740

02226558313

022 26558313

022 24224501


02065118088

-- Vilash 
9604801680
7798393036

020-24332266

8149162228


-- transnox_gca schema
/oradata3/dpump/expdp_dpump_tnox_gca_30Oct2013.dmp
/oradata3/dpump/log_expdp_dpump_tnox_gca_30Oct2013.log

-- transnox_gca_121 and transnox_gca_21 schema
/oradata5/dpump/expdp_dpump_tnox_gca_121_N_21_30Oct2013.dmp
/oradata5/dpump/log_expdp_dpump_tnox_gca_121_N_21_30Oct2013.log

--ACM_63,CHECKCASH,QCP,QCP_21,QCP_63,TRANSNOX_GLORY,TRANSNOX_WM schemas
/oradata6/dpump/expdp_arcdb_schemas_30Oct2013.dmp
/oradata6/dpump/logs_exdpdp_arcdb_schemas_30oct2013.log
/oradata6/dpump/export_schemas_30Oct2013.par

-----------------------------------------------------------------------------------------------------------------------

Reliance Accounts Customer AC:-100117644177
Bill AC:-100000118637734

204440288 16Jun2013 -- compline.

211119945 26oct2013

boardband@relianceada.com
  Phone Numbers : 99182903770
  Bill AC : 100000118637734
  Name: Rahul Chaudhari
  Issues explanations:
Hi Reliance,

	I was facing connection related issues from Jan2013 till June2013 I had raised so many complaints, I just noted/remember last ID "204440288" on 16Jun2013. The Issues which I had faced related to internet connection it was not resolved and I did not had internet connection for full June Month, I was doing advance payment, when i checked with call center they said our engineer had fix the issues and the ticket/compliant ID is closed and your connection is having no issues....but the connection was not working for the month... My Question here  is "How come you can close the ticket/compliant ID's without taking feedback of the customer who had/is facing the issues" No one call me for the feedback and the compliant ID was Closed. And connection issues I was facing still going on. 

From the next month I was getting a calls for late payments reminder from call center, all the time I was updating the same story to resolve the compliant ID first.. and then they started harassing me for the payment by calling each day....

I was paying advance payment of Rs 700 each month for the Reliance plain. Since from Jun2013 I had stop all the payments. Now I'm been getting harassed by your call-center. And also got one SMS about Pune court case on 23 Nov2013 to be present... If you want to take legal action, then I'll also have to take legal action through consumer forums... 


MAHARASHTRA & GOA 
Mrs.Varsha Kothawle 
Reliance Communications Ltd , 
7th Floor, Kumar Cerebrum IT Park , 
S.No - 13B, 1+2+3 & 14 Part, 
Vadgaonsheri, Pune - 411014 
Email : rcomappellateauthority.mh@relianceada.com 
18602002011

'
-----------------------------------------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------------------------
-- 24OCT2013

-- Transending Parallel Rebuild


-- create all below tablespace on parallel DB.. 
-- dropping all existing tablespace from parallel DB
TRANS_COMS_DATA
TRANS_COMS_INDEX

TRANS_DATA_COMS_32
TRANS_INDEX_COMS_32

COMS_DATA_PARTIN
COMS_INDEX_PARTIN

TRANS_COMS_BLOB
TRAN_COMS_SMALL_LOB

COMS_TRANSACTIONS_2_32K
COMS_TRANSACTIONS_32_K

COMS_TRANS_DETAIL_32K
COMS_TRANS_DETAIL_2_32K

COMS_TRANS_INDEX_32
-- 13 Tablespace Transcapitalone and Transcapitaloneapp schema were using..

20130724144652_updated_Update_Api_Transaction_sproc_for_BGTT_and_AGTS




------------------------------------------------------------------------------------------------------------------------



/*

13 NOV 2013 Production TransIT Release
GATEWAY :
	SNOXPASS_GWAY_010    ---- 59EA217B9137558166DE24926452902D754A3D2137211C92
	TNOXPASS_GWAY_010	 ---- 2ECCF4EC7CFF2A8E66DE24926452902D754A3D2137211C92
SMSNOX :
	SNOXPASS_SMSNOX_305  ---- 59EA217B913755812EF02CFDC24C68C82613E60A19F4BF82
	TNOXPASS_SMSNOX_305	 ---- 2ECCF4EC7CFF2A8E2EF02CFDC24C68C82613E60A19F4BF82
TFE :
	SNOXPASS_TFE_2015	 ---- 59EA217B9137558198B4F937D8C13D7D4537B0F570889F23
	TNOXPASS_TFE_2015	 ---- 2ECCF4EC7CFF2A8E98B4F937D8C13D7D4537B0F570889F23



alter user SNOXPASS_GWAY_010 identified by "SnoxPass_GWAY-010";
alter user TNOXPASS_GWAY_010 identified by "TnoxPass_GWAY-010";

alter user SNOXPASS_SMSNOX_305 identified by "SnoxPass_SMSNOX-305";
alter user TNOXPASS_SMSNOX_305 identified by "TnoxPass_SMSNOX-305";

alter user SNOXPASS_TFE_2015 identified by "SnoxPass_TFE-2015";
alter user TNOXPASS_TFE_2015 identified by "TnoxPass_TFE-2015";

*/

SD


('OFAC_ADAPTER','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSDEMO','TRANSDEMO_NEW','TRANSDEMO2','TRANSDEMOACQ','TRANSDEMOACQ_NEW','TRANSDEMOACQ_NEWAPP','TRANSDEMOACQAPP','TRANSDEMOBASIC','TRANSDEMOBASICAPP','TRANSDEMOMA','TRANSDEMOMAQ','TRANSDEMOMT','TRANSFASTCAP','TRANSFASTCAPAPP','TRANSGCA','TRANSGCAAPP','TRANSMONERIS','TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSSIGUE','TRANSSIGUEAPP','TRANSSUPER','TRANSTSYSBPO','TRANSTSYSBPOAPP','TRANSTSYSINTL')
2ECCF4EC7CFF2A8EA2DD86B05378B50C2613E60A19F4BF82





--- Capitalone Partition Table -- Archiving
TRANSACTIONS
MERCHANTSCOUT_SCORES
PRE_SET_TRANSACTION_STATE_LOG
SETTLEMENT_BATCH_HISTORY
VITAL_DAILY_DT_HIST
VITAL_DT_EXTENTION_HIST
VITAL_TRANSACTIONS_HIST

--- Create Partition and Archive
XTN_UPLOAD_STATS  --- Partition will be done on UPLOAD_START_DATE column. Tablespace COMS_DATA_PARTIN and COMS_INDEX_PARTIN will be used.

-- Non Partition Table Archiving
TRANSACTION_DETAILS  --- based on Transaction's (13 Month Upload_Start_Date) Detail_Trans_ID

TRANSACTIONS_MERCHANTSCOUT_DET  --- based on Transaction's (13 Month Upload_Start_Date) Transaction_ID

/*


Create table xtn_TransID_13Mons nologging as
select TRANSACTIONS_ID
from TRANSCAPITALONE.TRANSACTIONS
where UPLOAD_START_DATE >=ADD_MONTHS(SYSDATE,-13);

create index idx_xtn_TransID_13Mons on xtn_TransID_13Mons(TRANSACTIONS_ID) Tablespace TRANS_COMS_INDEX; 

SELECT *
FROM transcapitalone.TRANSACTIONS_MERCHANTSCOUT_DET tm
WHERE EXISTS (SELECT 1 FROM xtn_TransID_13Mons i
              WHERE I.TRANSACTIONS_ID = TM.TRANSACTIONS_ID);



*/


SELECT owner, object_name, object_type, mis_tables, mis_view, mis_proc, mis_func, mis_tri, mis_pac, mis_pac_body, mis_seq 
FROM 
(    
    SELECT UNIQUE doj.owner, doj.object_name, doj.object_type,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TABLE' AND OBJECT_name NOT LIKE 'SN_TEMP%' AND OBJECT_name NOT LIKE 'SC_TEMP%' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tables,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_view,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_proc,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_func,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tri,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac_body,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_seq
    FROM 
    (
        SELECT owner, object_name, object_type  
        FROM dba_objects@uatdb
        WHERE owner IN ('SNOXPASS_GWAY_009','TNOXPASS_GWAY_009','SNOXPASS_TFE_2015','TNOXPASS_TFE_2015','SNOXPASS_SMSNOX_304','TNOXPASS_SMSNOX_304','SNOXPASS_GWAY_008','TNOXPASS_GWAY_008','SNOXPASS_TFE_2014','TNOXPASS_TFE_2014','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20195','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','TRANSNOX_CAT','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526','SNOXPASS_TFE_20111','TNOXPASS_TFE_20111','SNOXPASS_GWAY_00523','TNOXPASS_GWAY_00523')
          AND object_name NOT LIKE '%ORG' AND object_name NOT LIKE 'BIN$%'
          AND object_name NOT LIKE '%REPL'
          AND object_type IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
        ORDER BY owner, object_name, object_type ASC
    ) doj
)
WHERE mis_tables='N'
  AND mis_view='N'
  AND mis_proc='N'
  AND mis_func='N'
  AND mis_tri='N'
  AND mis_pac='N'
  AND mis_pac_body='N'
  AND mis_seq='N'
  AND NOT REGEXP_LIKE(object_name,'TEMPSRI*|[[:digit:]]','i')
ORDER BY 3,2 ASC


SELECT UNIQUE OWNER, CONSTRAINT_NAME, TABLE_NAME, COLUMN_NAME, position, DECODE(CONSTRAINT_TYPE,'V','Check View','R','Foreign Key','U','Unique Key','P','Primary Key','C','Check','O','Read Only View','Others')Constraint_Type, MISSING_CONS
FROM 
  (
    SELECT
        remo.owner, remo.constraint_name, remo.table_name, remo.column_name, remo.position, remo.constraint_type,
        NVL2((SELECT UNIQUE table_name FROM dba_cons_columns dcc1 WHERE dcc1.table_name=remo.table_name AND dcc1.owner=remo.owner),'Y','N')MISSING_CONS 
    FROM 
      (
        SELECT dcc.owner, dcc.constraint_name, dcc.table_name, dcc.column_name, dcc.position, dc.constraint_type
        FROM dba_cons_columns@uatdb dcc, dba_constraints@col122 dc
        WHERE 
           dc.owner IN ('SNOXPASS_GWAY_009','TNOXPASS_GWAY_009','SNOXPASS_TFE_2015','TNOXPASS_TFE_2015','SNOXPASS_SMSNOX_304','TNOXPASS_SMSNOX_304','SNOXPASS_GWAY_008','TNOXPASS_GWAY_008','SNOXPASS_TFE_2014','TNOXPASS_TFE_2014','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20195','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','TRANSNOX_CAT','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526','SNOXPASS_TFE_20111','TNOXPASS_TFE_20111','SNOXPASS_GWAY_00523','TNOXPASS_GWAY_00523')
--           dc.owner IN ('QCP','CHECKCASH')
          AND DC.CONSTRAINT_NAME = DCC.CONSTRAINT_NAME 
          AND DC.OWNER=DCC.OWNER
        ORDER BY TABLE_NAME,POSITION ASC
      ) remo  
  ) i
WHERE i.MISSING_CONS='N'    
--  AND EXISTS (SELECT 1 FROM dba_tables dt WHERE dt.table_name=i.table_name AND i.owner=i.owner)
  AND NOT REGEXP_LIKE(i.table_name,'ORG|*[[:digit:]]','i')
ORDER BY table_name, position ASC

--Veryfy the current log mode using below mentioned query
SELECT log_mode FROM gv$database;

LOG_MODE
------------
ARCHIVELOG
ARCHIVELOG

OR

SQL> archive log list;

--Check the Cluster status
$ srvctl status database -d testdb1

--Stop the database
$ srvctl stop database -d testdb1

--Check the status again
$ srvctl status database -d testdb1

Connect to sqlplus / as sysdba
SQL> Shutdown immediate;
SQL> startup mount exclusive;
SQL> alter database noarchivelog;

--Verify the archive status
SQL>  archive log list;

--Open the database and verify
SQL> alter database open;

SQL> SELECT log_mode FROM gv$database; 

--Shutdown the database and startup with SRVCTL utility
SQL> shut immediate;

srvctl start database -d testdb1


directory="BKUP_DPUMP"
dumpfile="expdp_qaracdb2_bkups.dmp"
logfile="expdp_qaracdb2_bkupslogs.log"
exclude=statistics,table:"like 'SN_TEMP%'",table:"like 'SC_TEMP%'"
exclude=SCHEMAS:"IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDSYS','MGMT_VIEW','OLAPSYS','OPS$ORACLE','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','OWBSYS_AUDIT','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','WMSYS','XDB','XS$NULL')"
compression=all
content=all
data_options=xml_clobs
REUSE_DUMPFILES=y


SELECT UNIQUE grantor 
FROM DBA_TAB_PRIVS 
WHERE grantee IN ('SNOXPASS_GWAY_009','TNOXPASS_GWAY_009','SNOXPASS_TFE_2015','TNOXPASS_TFE_2015','SNOXPASS_SMSNOX_304','TNOXPASS_SMSNOX_304',
                  'SNOXPASS_GWAY_008','TNOXPASS_GWAY_008','SNOXPASS_TFE_2014','TNOXPASS_TFE_2014','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303')


SELECT * --'revoke '||PRIVILEGE||' on '||grantor||'.'||table_name||' from '||grantee||';' oops
FROM dba_tab_privs
WHERE grantor='SNOX4TRANSNOX_GCA'
  AND GRANTEE IN ('SNOXPASS_GWAY_009','TNOXPASS_GWAY_009','SNOXPASS_TFE_2015','TNOXPASS_TFE_2015','SNOXPASS_SMSNOX_304','TNOXPASS_SMSNOX_304',
                  'SNOXPASS_GWAY_008','TNOXPASS_GWAY_008','SNOXPASS_TFE_2014','TNOXPASS_TFE_2014','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303',
                  'TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','TRANSNOX_CAT')




SELECT 'GRANT ' || WM_CONCAT(PRIVILEGE) || ' on ' || GRANTOR || '.' || TABLE_NAME || ' to ' || GRANTEE || ' ;' 
FROM DBA_TAB_PRIVS
WHERE GRANTEE IN ('SNOXPASS_GWAY_009','TNOXPASS_GWAY_009','SNOXPASS_TFE_2015','TNOXPASS_TFE_2015','SNOXPASS_SMSNOX_304','TNOXPASS_SMSNOX_304',
				  'SNOXPASS_GWAY_008','TNOXPASS_GWAY_008','SNOXPASS_TFE_2014','TNOXPASS_TFE_2014','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303',
				  'TNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20195','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TRANSNOX_CPASS',
				  'SNOX4TRANSNOX_CPASS','TRANSNOX_CAT')
GROUP BY GRANTOR, TABLE_NAME, GRANTEE
ORDER BY grantor,grantee ASC


directory="dpump"
dumpfile="expdp_TransIT_schemas_23Sep2013.dmp"
logfile="expdp_TransIT_schemas_23Sep2013_logs.log"
exclude=statistics,table:"like 'SC_TEMP%'",table:"like 'SN_TEMP%'"
schemas=('SNOXPASS_GWAY_009','TNOXPASS_GWAY_009','SNOXPASS_TFE_2015','TNOXPASS_TFE_2015','SNOXPASS_SMSNOX_304','TNOXPASS_SMSNOX_304','SNOXPASS_GWAY_008','TNOXPASS_GWAY_008','SNOXPASS_TFE_2014','TNOXPASS_TFE_2014','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20195','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','TRANSNOX_CAT')
compression=all
content=all
data_options=xml_clobs
reuse_dumpfiles=y


 
 SELECT  distinct phone_desc from phone



SELECT * FROM v$lock WHERE TYPE='TM' 



SELECT * FROM dba_objects WHERE object_id='375'



SELECT SUBSTR(TO_CHAR(w.session_id),1,5) WSID, p1.spid WPID,
	SUBSTR(s1.username,1,12) "WAITING User",
	SUBSTR(s1.osuser,1,8) "OS User",
	SUBSTR(s1.PROGRAM,1,20) "WAITING Program",
	s1.client_info "WAITING Client",
	SUBSTR(TO_CHAR(h.session_id),1,5) HSID, p2.spid HPID,
	SUBSTR(s2.username,1,12) "HOLDING User",
	SUBSTR(s2.osuser,1,8) "OS User",
	SUBSTR(s2.PROGRAM,1,20) "HOLDING Program",
	s2.client_info "HOLDING Client",
	o.object_name "HOLDING Object"
FROM gv$process p1, gv$process p2, gv$session s1, 
	gv$session s2, dba_locks w, dba_locks h, dba_objects o
WHERE w.last_convert > 60
  AND h.mode_held != 'None'
  AND h.mode_held != 'Null'
  AND w.mode_requested != 'None'
  AND s1.row_wait_obj# = o.object_id
  AND w.lock_type(+) = h.lock_type
  AND w.lock_id1(+) = h.lock_id1
  AND w.lock_id2 (+) = h.lock_id2
  AND w.session_id = s1.SID (+)
  AND h.session_id = s2.SID (+)
  AND s1.paddr = p1.addr (+)
  AND s2.paddr = p2.addr (+)
ORDER BY w.last_convert DESC;



history 31AUG2013 archive
use dotproject;

create table ARCH_31AUG2013_History
select * from history
where task_id in (select task_id from tasks
                 where task_dynamic = 0
                   and task_percent_complete=100
                   and task_end_date <= '2013-08-31 23:59:59');


delete from task_departments
where task_id in (select task_id from tasks
                 where task_dynamic = 0
                   and task_percent_complete=100
                   and task_end_date <= '2013-03-31 23:59:59');

SELECT DISTINCT tasks.task_id,
                task_parent,
                task_name,
                task_start_date,
                task_end_date,
                task_dynamic,
                task_pinned,
                pin.user_id AS pin_user,
                task_priority,
                task_percent_complete,
                task_duration,
                task_duration_type,
                task_project,
                task_description,
                task_owner,
                task_status,
                usernames.user_username,
                cust.dept_name AS dept_Name,
                usernames.user_id,
                task_milestone,
                assignees.user_username AS assignee_username,
                count(DISTINCT assignees.user_id) AS assignee_count,
                co.contact_first_name,
                co.contact_last_name,
                count(DISTINCT files.file_task) AS file_count,
                tlog.task_log_problem,
                MAX(history_date) AS last_update
  FROM tasks
       LEFT JOIN history
          ON history_item = tasks.task_id AND history_table = 'tasks'
       LEFT JOIN projects
          ON project_id = task_project
       LEFT JOIN users AS usernames
          ON task_owner = usernames.user_id
       LEFT JOIN user_tasks AS ut
          ON ut.task_id = tasks.task_id
       LEFT JOIN departments AS cust
          ON tasks.task_departments = cust.dept_id
       LEFT JOIN users AS assignees
          ON assignees.user_id = ut.user_id
       LEFT JOIN contacts AS co
          ON co.contact_id = usernames.user_contact
       LEFT JOIN task_log AS tlog
          ON tlog.task_log_task = tasks.task_id
             AND tlog.task_log_problem > '0'
       LEFT JOIN files
          ON tasks.task_id = files.file_task
       LEFT JOIN user_task_pin AS pin
          ON tasks.task_id = pin.task_id AND pin.user_id = 27
 WHERE task_project = 64
GROUP BY task_id
ORDER BY project_id, task_start_date

TNOXUID_GWAY_00515
SNOXUID_GWAY_00515

SNOX_UID_PROD
TNOX_UID_PROD


--------------------------------------------------------------------------------------------------------------

INSERT INTO CUST_CARD_ACCOUNT_HIST
( CARD_NUMBER, CUSTOMER_CODE, CARD_TYPE, EXPIRATION_DATE, DATE_CREATED, DATE_MODIFIED, ACCOUNT_STATUS,
BILLING_STREET1, BILLING_STREET2, BILLING_CITY, BILLING_STATE, BILLING_ZIP, BILLING_COUNTRY, BILLING_EMAIL,
FIN_ACCOUNT_ID, COMMERCIAL_CARD_INDICATOR, BILLING_NUMERIC_STATE_CODE, BILLING_MOBILEPHONE,
BILLING_WORKPHONE, BILLING_FAX, BILLING_PHONE, DATE_DELETED
)
( SELECT CARD_NUMBER, CUSTOMER_CODE, CARD_TYPE, EXPIRATION_DATE, DATE_CREATED, DATE_MODIFIED, ACCOUNT_STATUS,
BILLING_STREET1, BILLING_STREET2, BILLING_CITY, BILLING_STATE, BILLING_ZIP, BILLING_COUNTRY, BILLING_EMAIL,
FIN_ACCOUNT_ID, COMMERCIAL_CARD_INDICATOR, BILLING_NUMERIC_STATE_CODE, BILLING_MOBILEPHONE,
BILLING_WORKPHONE, BILLING_FAX, BILLING_PHONE,SYSDATE
FROM CUST_CARD_ACCOUNT
WHERE ACCOUNT_STATUS = 'DELETED' );



DELETE FROM CUST_CARD_ACCOUNT
WHERE ACCOUNT_STATUS = 'DELETED';  




GRANT INSERT,UPDATE,DELETE,SELECT ON TRANSNOX_CPASS.SOURCE_MER_FILE_CONFIG  TO snoxpass_gway_008

CREATE OR REPLACE SYNONYM snoxpass_gway_008.SOURCE_MER_FILE_CONFIG FOR TRANSNOX_CPASS.SOURCE_MER_FILE_CONFIG


SELECT * FROM tnoxpass_gway_008.SOURCE_MER_FILE_CONFIG

direcotry="bkup_dpump"
dumpfile="expdp_qaracdb2_$bkup_date.dmp"
logfile="expdp_qaracdb2_$bkup_date.log"
exclude=statistics,table:"like 'SN_TEMP%'",table:"like 'SC_TEMP%'"

SNOX4TRANSNOX_WMGLY

#!/bin/sh
export ORACLE_SID=arccatdb
bkup_date="`date +%m%d%Y`"
expdp / 
sqlplus / as sysdba<< EOF

exit;
EOF


Install goldengate software on old uatdb (non-rac db) server
Install goldengate software on rac uatracdb on node1 server
Configure capture process on non-rac db to replicate on uatracdb
Configure replicat process on uatracdb on node1 and do not start it
Start capture process on non-rac uatdb
Take export using current scn
Transfer the export backup on uatracdb node1
Start import, check and verify all objects on uatracdb once the import is completed.
Start replicat process on uatracdb node1


TNOX_DATA_CPASS
SNOX_DATA_CPASS

TNOX_INDX_CPASS
SNOX_INDX_CPASS

CREATE OR REPLACE PROCEDURE DB_Count_Connections
(
    o_outputStatus  OUT NUMBER,
    o_outputMessage OUT NUMBER
)
AS
    v_ErrorFlag         NUMBER;
BEGIN


SELECT schemaname, machine, COUNT(*) 
FROM v$session --WHERE machine='tempe5-22.ifxtempe.com'
GROUP BY machine, schemaname 
ORDER BY 3 DESC


EXCEPTION
 WHEN OTHERS THEN
    o_outputStatus := '-1';
    o_outputMessage:= 'Procedure failed on step :'||v_ErrorFlag||' with SQLError :'||SUBSTR(SQLERRM,1,100));
END;
/    



directory="dpump"
dumpfile="expdp_archiving_testing_29Aug2013.dmp"
logfile="expdp_archiving_testing_29Aug2013.log"
exclude=STATISTICS,SCHEMA:"IN ('ANONYMOUS','APEX_030200','APEX_PUBLIC_USER','APPQOSSYS','CTXSYS','DBSNMP','DIP','EXFSYS','FLOWS_FILES','MDDATA','MDSYS','MGMT_VIEW','OLAPSYS','ORACLE_OCM','ORDDATA','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','OWBSYS_AUDIT','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYSMAN','WMSYS','XDB','XS$NULL','SYS','SYSTEM','SNOXPASS_GWAY_00511','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_0059','TNOXPASS_TFE_201124','SNOXPASS_SMSNOX_20174','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20192','SNOXPASS_TFE_20111','SNOXPASS_TFE_20112','SNOXPASS_TFE_201124','TNOXPASS_GWAY_00511','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00525','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00531_P13','TNOXPASS_GWAY_00531_P14','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_0059','TNOXPASS_SMSNOX_20174','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20192','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20197_P10','TNOXPASS_TFE_20111','TNOXPASS_TFE_201116','TNOXPASS_TFE_20112','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00525','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00531_P13','SNOXPASS_GWAY_00531_P14','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_TFE_201116','SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','TNOXPASS_SMSNOX_20197_P9','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20197_P10','SNOXPASS_SMSNOX_20197_P9','NMOHANTY')"
exclude=TABLE:"LIKE 'SN_TEMP%'",TABLE:"LIKE 'SC_TEMP%'"
QUERY=TRANSNOX_CPASS.TRANS_STATUS_HISTORY:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_SIGNATURE_HISTORY:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_SIGNATURE:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_SHIPPING_ADDRESS:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_PAYROLL:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_MONEY_TRANSFER:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_MONEY_ORDER:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_COMPLIANCE_INFO:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_CHECK_DEPOSITE:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_CHECK_CLEAR_AMOUNT:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_CHECK:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_CASH:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_ADDITIONAL_AMOUNT_TYPE:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.RECURRING_PAYMENT:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.MO_DT3_TRANSACTION_SUMMARY:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.MO_DT3_TRANSACTION_DETAILS:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_CARD:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_RESPONSE_INFO:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_ADDITIONAL_INFO:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_BANK_DETAIL:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_RETURN:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_DETAIL:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANS_BILLING_ADDRESS:"WHERE TRANSACTION_ID IN (SELECT TRANSACTION_ID FROM TRANSNOX_CPASS.TRANSACTION WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24))"
QUERY=TRANSNOX_CPASS.TRANSACTION:"WHERE TIME_STAMP >= ADD_MONTHS( SYSDATE,-24)"
QUERY=TRANSNOX_CPASS.REQUEST_AUDIT_TRAIL:"WHERE SERVER_TIMESTAMP >= ADD_MONTHS(SYSDATE,-24)"
QUERY=TRANSNOX_CPASS.REPORT_USAGE_AUDITTRAIL:"WHERE END_DATE >= ADD_MONTHS(SYSDATE,-24)"
QUERY=TRANSNOX_CPASS.CUSTOM_REPORT:"WHERE DATE_CREATED >= ADD_MONTHS(SYSDATE,-24)"
QUERY=SNOX4TRANSNOX_CPASS.USER_AUDIT_DETAIL:"WHERE EVENT_ID IN (SELECT EVENT_ID FROM SNOX4TRANSNOX_CPASS_CPASS_DEV.USER_AUDIT WHERE EVENT_TIMESTAMP>= ADD_MONTHS(SYSDATE,-24))"
QUERY=SNOX4TRANSNOX_CPASS.USER_AUDIT:"WHERE EVENT_TIMESTAMP  >= ADD_MONTHS(SYSDATE,-24)"
data_options=xml_clobs
content=all
compression=all








For TNOXPASS_TFE_2014 :-
Key = 46ADBC01800BA894
Password = 8786AF813E6F672E9462F3639FB293E130E5072709FAE38C

For SNOXPASS_TFE_2014
Key = 0D83FE8FA11AC897
Password = C34C2F2324BFFFD009FC5D4FD08D06CDC91FCA5F1E085D72


---------------------------------------------------------------------
-- Start of script of Date 26Aug2013

1 Step:
update transnox_gca.TRANS_SETTLEMENT ts 
set timestamp = to_date('08-25-2013 14:00','mm-dd-yyyy hh24:mi') 
WHERE TIMESTAMP > trunc(sysdate-1) 
  and settlement_status = 'RESEND' 
  and ts.transaction_id in ( select transaction_id 
  							 from transnox_gca.transaction t 
  							 where T.TIME_STAMP between to_date('08-24-2013 14:00','mm-dd-yyyy hh24:mi') 
  							 						and to_date('08-25-2013 15:00','mm-dd-yyyy hh24:mi') 
  							   and T.TRANS_TYPE like '%SETTLE%')
  							   
step 2: snox_settlement_batch, keep only 10days of data , there were 12 days data in it.

step 3: check trans_settlement table for STatus = RESEND , count should be 30,000 + for 3pm yesterday to 3PM today

step 4: Ask Marc Team to reschedule the recon

-- End of script of Date 26Aug2013
------------------------------------------------------------------

oem 12 c

--put entry in oratab 
OEM:/opt/app/oracle/Middleware/oms:N


. oraenv
OEM




emcli login -username=bdas

emcli sync

emcli import_update_catalog -file="/home/oracle/p9348489_112000_Generic.zip" -omslocal


once it done goto oem12c 

setup> extensiblity> SelfUpdate> Plug-in


/recovery/oracle/rman_bkups/archlogs


Please mount the path of wdl1mltidbs01.tsysacquiring.org (Archive Server) to regdbnode1



Please mount the path of wdl1mltidbs01.tsysacquiring.org (Archive Server) to regdbnode1.tsysacquiring.org

on wdl1mltidbs01 path is "/oradata1/oracle/regdb_rmanbkups/bkup_files"
to regdbnode1.tsysacquiring.org

This is for RMAN/DataPump backups, the script will be taking backups which will be created on regdbnode1.tsysacquiring.org DB Server, once the backup is done all the backup files will be sifted to mounted folder of dev archive server.



----------------------------------------------------------
To change the status of this batch form RESEND to FAILED , need to update status in TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH table.

Need to Modify the status of Failed Bad TAS Batch form RESEND to FAILED

Hence please ask  Db team to change the required status in TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH table.


UPDATE TRANSNOX_IOX.SNOX_SETTLEMENT_BATCH 
SET batch_status='FAILED'
WHERE terminalid='00000051504601' 
  AND mid='000000515046' 
  AND batch_seq_id='1754586'
  
----------------------------------------------------------  



SELECT
TO_CHAR(RTR.TRANSDATE, 'dd-mon-yy hh24.mi.ss')||'|'||
RTR.OPERATOR||'|'||
RTR.WORKSTATION||'|'||
RTR.TERMINAL||'|'||
RTR.TRANSACTIONTYPE||'|'||
CTR.FIRSTNAME||'|'||
CTR.LASTNAME||'|'||
CTR.MIDDLEINITIAL||'|'||
RTR.RTRIDTYPECODE||'|'||
RTR.RTRIDNO||'|'||
RTR.RTRUSSTATECODE||'|'||
RTR.RTRCOUNTRY||'|'||
RTR.RTRADDRESS||'|'||
RTR.RTRSUITENO||'|'||
RTR.RTRCITY||'|'||
RTR.RTRUSSTATECODE||'|'||
RTR.RTRCOUNTRY||'|'||
RTR.RTRZIPCODE||'|'||
RTR.RTRPHONE||'|'||
RTR.RTRDOB||'|'||
RTR.CHECKNO||'|'||
RTR.AUTHCODE||'|'||
RTR.PAYTYPE||'|'||
RTR.STATUS||'|'||
RTR.AMOUNT||'|'||
RTR.FEES||'|'||
RTR.GCACHECKNUMBER||'|'||
RTR.TRACEID||'|'||
RTR.CLUBCARD||'|'||
RTR.REFERENCENO||'|'||
RTR.EMAILID
FROM REALTIMERPT.RTR_TEMP_CAGEBALANCE RTR,REALTIMERPT.CTRREPORT CTR
WHERE CTR.TRANSACTIONDATE BETWEEN TO_DATE('01-dec-2012 00:00:00', 'dd-mon-yyyy hh24:mi:ss') AND TO_DATE('28-feb-2013 23:59:59', 'dd-mon-yyyy hh24:mi:ss')
AND ctr.casinocode=443817;

SELECT * FROM REALTIMERPT.CTRREPORT WHERE casinocode=443817

SELECT * FROM QCP.TERMINALS C WHERE C.MACHINEID ='817091'

REALTIMERPT.RTR_TEMP_CAGEBALANCE

SELECT * FROM QCP.USER_LOGIN_DATA  

SELECT
    TO_CHAR(TRANSACTIONDATE, 'dd-mon-yy hh24.mi.ss'),
    'OPERATOR',
    'WORKSTATION',
    TERMINALID,
    TRANSTYPEDESC,
    FIRSTNAME,
    LASTNAME,
    MIDDLEINITIAL,
    ADD_IDTYPE IDTYPECODE,
    IDTYPE,
    IDNO,
    USSTATECODE,
    COUNTRYCODE,
    ADDRESS,
    SUITENO,
    CITY,
    ZIPCODE,
    PHONENO,
    DOB,
    CHECKNO,
    'AUTHCODE',
    PAYMETHOD "PAYTYPE",
    STATUSCODE,
    AMOUNT,
    'FEES',
    'GCACHECKNUMBER',
    'TRACEID',
    'CLUBCARD',
    'REFERENCENO',
    'EMAILID'
FROM REALTIMERPT.CTRREPORT CTR
WHERE -- TRANSACTIONDATE BETWEEN TO_DATE('01-feb-2013 00:00:00', 'dd-mon-yyyy hh24:mi:ss') 
        --                    AND TO_DATE('28-feb-2013 23:59:59', 'dd-mon-yyyy hh24:mi:ss')
ctr.casinocode=443817;


SELECT TO_CHAR(TRANSACTIONDATE,'yyyy')TIMESTAMP, COUNT(*)
FROM  REALTIMERPT.CTRREPORT
WHERE TRANSACTIONDATE BETWEEN TO_DATE('12/01/2012 00:00:00','MM/DD/YYYY HH24:MI:SS')
                          AND TO_DATE('02/28/2013 23:59:59','MM/DD/YYYY HH24:MI:SS')
GROUP BY TO_CHAR(TRANSACTIONDATE,'yyyy')

SELECT *
FROM dba_tab_columns
WHERE column_name LIKE 'AUTHCO%'
 AND owner IN ('QCP','REALTIMERPT')


-----------------------------------------------------

* Oracle Golden Gate Replication testing on all DMLs with all Data Types
* Worked on Cash dispense summary timeout issues.
* Provided Metadata of classic GCA schemas to ICP Team
* Provided Metadata of Transnox GCA schemas to ICP Team
* Worked and Support on Missing DCC Transaction Issues to ICP Team
* Worked on OEM12c issues for dev and QA RAC DBs



--11July2013 Start Date

directory="expdp_dir"
dumpfile="expdp_recon_tables_11July2013.dmp"
logfile="expdp_recon_tables_11July2013.log"
tables=snox4transnox_gca.recon_config,snox4transnox_gca.recon_constants,snox4transnox_gca.recon_file_config,snox4transnox_gca.recon_file_status,snox4transnox_gca.recon_holidays,snox4transnox_gca.recon_manual_config,snox4transnox_gca.recon_status
compression=all





--11July2013 End Date

-------------------------------------------------------------------------------------
--10July2013 Start Date

('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','IDNOX','OFAC_ADAPTER','QCMGR','QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','REALTIMERPT','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')


---- backup of change control implementation cqID00056001 deleting SAM line
SET DEFINE OFF;
Insert into TRANSNOX_GCA.DEVICE_PROCESSOR_INFO
   (DEVICE_ID, PROCESSOR_TERM, SEQUENCE_NUMBER, PROCESSOR_CODE, TERMINAL_NUMBER)
 Values
   ('R001FLSC', '75222326', '114', 'SAM', '0032');
Insert into TRANSNOX_GCA.DEVICE_PROCESSOR_INFO
   (DEVICE_ID, PROCESSOR_TERM, SEQUENCE_NUMBER, PROCESSOR_CODE, TERMINAL_NUMBER)
 Values
   ('R001FLSC', '75222326', '7237', 'SAR', '0032');
Insert into TRANSNOX_GCA.DEVICE_PROCESSOR_INFO
   (DEVICE_ID, PROCESSOR_TERM, SEQUENCE_NUMBER, PROCESSOR_CODE, TERMINAL_NUMBER, PIN_TRANSLATION_TYPE)
 Values
   ('R001FLSC', '75222326', '7912', 'VAL', '0032', 
    'MTD');
COMMIT;


--10July2013 End Date
---------------------------------------------------------------------------------------



'TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE','TRANSSIGUEAPP','TRANSSIGUE_PROD_PARALLEL','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','VERICENTRE_OLD','VERIZON_QA','VZODGE','WEBFORT','WUMT','WUMTAPP'

directory="dpump"
dumpfile="expdp_qadb_to_racdb.dmp"
logfile="impdp_expdp_qadb_to_racdb.log"
schemas=('ACH','ACM','ACM6000','CASHCARD','CHECKCASH','CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC','ETLUPDATECAPONE','ETLUPDATEGW','FHO','FNB_DBA','GOPAY_PORTAL','IDNOX','INVENTORY','INVENTORY2','JLAYANI','KEYNOX_FX','MERGECUSTCODE','OFAC_ADAPTER','PAYFUSEQA','PAYFUSEUAT','QCAPP','QCMGR','QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','REALTIMERPT','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103','SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_GWAY_007_UAT','SNOXPASS_PART','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SNOXPASS_TFE_2013_UAT','TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_GWAY_007_UAT','TNOXPASS_PART','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TNOXPASS_TFE_2013_UAT','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ','TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL','TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE','TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT','TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','USAP_ADAPTER','VCTP_FIRE','VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','WEBFORT','WUMT','WUMTAPP','DCURRIER','PKOIPARA','STUJARE','VBOROLE','VZODGE')
~
directory="dpump"
dumpfile="expdp_qadb_to_racdb_4.dmp"
logfile="impdp_log_metadata_only_1_4.log"
schemas=('TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE','TRANSSIGUEAPP','TRANSSIGUE_PROD_PARALLEL','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','VERICENTRE_OLD','VERIZON_QA','VZODGE','WEBFORT','WUMT','WUMTAPP')
content=metadata_only
include=grant,index,ref_constraint,constraint,procedure,function,trigger,view,package_spec,package_body,materialized_view,synonym,sequence



JOB_NAME=SYS_IMPORT_SCHEMA_01

directory="qadb_bkups" 
dumpfile="expdp_qadb_to_racdb.dmp" 
logfile="expdp_qadb_to_racdb.log"
exclude=statistics,table:" like 'SN_TEMP%'",table:" like 'SC_TEMP%'" 
schemas=('SNOX4TRANSNOX_API','SNOX4TRANSNOX_UID_00530','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_0059','SNOXPASS_SMSNOX_20170','SNOXPASS_TFE_20113','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_0059','TNOXPASS_SMSNOX_20170','TNOXPASS_TFE_20113','TRANSNOX_IOX','TRANSNOX_UID_00530','TRANSTSYSBPO','ACH','ACM','ACM6000','CASHCARD','CHECKCASH','CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC','ETLUPDATECAPONE','ETLUPDATEGW','FHO','FNB_DBA','GOPAY_PORTAL','IDNOX','INVENTORY','INVENTORY2','JLAYANI','KEYNOX_FX','MERGECUSTCODE','OFAC_ADAPTER','PAYFUSEQA','PAYFUSEUAT','QCAPP','QCMGR','QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','REALTIMERPT','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103','SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_GWAY_007_UAT','SNOXPASS_PART','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SNOXPASS_TFE_2013_UAT','TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_GWAY_007_UAT','TNOXPASS_PART','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TNOXPASS_TFE_2013_UAT','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ','TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL','TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE','TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT','TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','USAP_ADAPTER','VCTP_FIRE','VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','WEBFORT','WUMT','WUMTAPP','DCURRIER','PKOIPARA','STUJARE','VBOROLE','VZODGE')
content=all
compression=all



directory="dpump" 
dumpfile="expdp_qadb_to_racdb.dmp" 
logfile="impdp_expdp_qadb_to_racdb.log"
schemas=('ACH','ACM','ACM6000','CASHCARD','CHECKCASH','CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC','ETLUPDATECAPONE','ETLUPDATEGW','FHO','FNB_DBA','GOPAY_PORTAL','IDNOX','INVENTORY','INVENTORY2','JLAYANI','KEYNOX_FX','MERGECUSTCODE','OFAC_ADAPTER','PAYFUSEQA','PAYFUSEUAT','QCAPP','QCMGR','QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','REALTIMERPT','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103','SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_GWAY_007_UAT','SNOXPASS_PART','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SNOXPASS_TFE_2013_UAT','TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_GWAY_007_UAT','TNOXPASS_PART','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TNOXPASS_TFE_2013_UAT','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ','TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL','TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE','TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT','TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','USAP_ADAPTER','VCTP_FIRE','VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','WEBFORT','WUMT','WUMTAPP','DCURRIER','PKOIPARA','STUJARE','VBOROLE','VZODGE')


('CPASS_DATA_TBLS','CPASS_INDX_TBLS','FAST_GROWTH_INDX','FAST_GROWTH_TBLS','PAYFUSE_DATA_TBLS','PAYFUSE_INDX_TBLS','SLOW_GROWTH_TBLS','TSENDING_DATA_TBLS','TSENDING_INDX_TBLS','TSYS_EMPL_TBS','USERS','VERICENTRE_DATA_TBLS','VERICENTRE_INDX_TBLS','WEBFORT_DATA_TBLS')


+ORADATA/qaracdb/datafiles/TGCA_INDX_TBLS_01.dbf



CREATE TABLESPACE CPASS_PART3_DATA 
DATAFILE 
  '+ORADATA' SIZE 1G AUTOEXTEND OFF,
  '+ORADATA' SIZE 2G AUTOEXTEND ON NEXT 5M MAXSIZE UNLIMITED
LOGGING
PERMANENT
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;





('CPASS_DATA_TBLS','CPASS_INDX_TBLS','CPASS_PART1_DATA','CPASS_PART1_INDX','CPASS_PART2_DATA','CPASS_PART2_INDX','CPASS_PART3_INDX','CPASS_PART4_DATA','CPASS_PART4_INDX','FAST_GROWTH_INDX','FAST_GROWTH_TBLS','PAYFUSE_DATA_TBLS','PAYFUSE_INDX_TBLS','SLOW_GROWTH_TBLS','TGCA_DATA_TBLS','TGCA_INDX_TBLS','TSENDING_DATA_TBLS','TSENDING_INDX_TBLS','TSYS_EMPL_TBS','USERS','VERICENTRE_DATA_TBLS','VERICENTRE_INDX_TBLS','WEBFORT_DATA_TBLS')



('SNOX4TRANSNOX_API','SNOX4TRANSNOX_UID_00530','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_0059','SNOXPASS_SMSNOX_20170','SNOXPASS_TFE_20113','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_0059','TNOXPASS_SMSNOX_20170','TNOXPASS_TFE_20113','TRANSNOX_IOX','TRANSNOX_UID_00530','TRANSTSYSBPO')





snox4transnox_api,snox4transnox_uid_00530,snoxpass_gway_00513,snoxpass_gway_0059,snoxpass_smsnox_20170,snoxpass_tfe_20113,tnoxpass_gway_00513,tnoxpass_gway_0059,tnoxpass_smsnox_20170,tnoxpass_tfe_20113,transnox_iox,transnox_uid_00530,transtsysbpo,ach,acm,acm6000,cashcard,checkcash,checkcashapp,data_generator,data_upload,dbhosale,etlmoneris,etlupdate,etlupdatebasic,etlupdatecapone,etlupdategw,fho,fnb_dba,gopay_portal,idnox,inventory,inventory2,jlayani,keynox_fx,mergecustcode,ofac_adapter,payfuseqa,payfuseuat,qcapp,qcmgr,qcmgr_app,qcp,qcpapp,qcpmgr,qcredit,qfapp,qfcs,qfund,qkadvanceapp,qplay,qracm,qrqcp,quikadvance,quikadvance_app,realtimerpt,snox,snox_gca_00510,snox_gca_0058,snox_gca_0059,snox_usbank,snox4transnox,snox4transnox_cpass,snox4transnox_cpass_partition,snox4transnox_cpass_uat,snox4transnox_gca,snox4transnox_uid,snox4transnox_uid_00523,snox4transnox_uid_00532,snox4transnox_uid_00535,snox4transnox_wucc,snoxdevices,snoxgca_91x_20101,snoxgca_91x_20101p,snoxgca_91x_20102,snoxgca_91x_20103,snoxgca_91x_20104,snoxpass_gway_00515,snoxpass_gway_00516,snoxpass_gway_00520,snoxpass_gway_00521,snoxpass_gway_00522,snoxpass_gway_00523,snoxpass_gway_00524,snoxpass_gway_00526,snoxpass_gway_00527,snoxpass_gway_00528,snoxpass_gway_00529,snoxpass_gway_00531,snoxpass_gway_00532,snoxpass_gway_00533,snoxpass_gway_00534,snoxpass_gway_00534_uat,snoxpass_gway_006,snoxpass_gway_006_uat,snoxpass_gway_007,snoxpass_gway_007_uat,snoxpass_part,snoxpass_smsnox_20176,snoxpass_smsnox_20179,snoxpass_smsnox_20189,snoxpass_smsnox_20191,snoxpass_smsnox_20193,snoxpass_smsnox_20194,snoxpass_smsnox_20195,snoxpass_smsnox_20197,snoxpass_smsnox_20198,snoxpass_smsnox_20199,snoxpass_smsnox_30001,snoxpass_smsnox_30001_uat,snoxpass_smsnox_301,snoxpass_smsnox_301_uat,snoxpass_tfe_201116,snoxpass_tfe_201124,snoxpass_tfe_201124_uat,snoxpass_tfe_20115,snoxpass_tfe_20116,snoxpass_tfe_2012,snoxpass_tfe_2012_uat,snoxpass_tfe_2013,snoxpass_tfe_2013_uat,tnox_gca_00510,tnox_gca_0058,tnox_gca_0059,tnoxgca_91x_20101,tnoxgca_91x_20101p,tnoxgca_91x_20102,tnoxgca_91x_20103,tnoxgca_91x_20104,tnoxpass_gway_00515,tnoxpass_gway_00516,tnoxpass_gway_00520,tnoxpass_gway_00521,tnoxpass_gway_00522,tnoxpass_gway_00523,tnoxpass_gway_00524,tnoxpass_gway_00526,tnoxpass_gway_00527,tnoxpass_gway_00528,tnoxpass_gway_00529,tnoxpass_gway_00531,tnoxpass_gway_00532,tnoxpass_gway_00533,tnoxpass_gway_00534,tnoxpass_gway_00534_uat,tnoxpass_gway_006,tnoxpass_gway_006_uat,tnoxpass_gway_007,tnoxpass_gway_007_uat,tnoxpass_part,tnoxpass_smsnox_20176,tnoxpass_smsnox_20179,tnoxpass_smsnox_20189,tnoxpass_smsnox_20191,tnoxpass_smsnox_20193,tnoxpass_smsnox_20194,tnoxpass_smsnox_20195,tnoxpass_smsnox_20197,tnoxpass_smsnox_20198,tnoxpass_smsnox_20199,tnoxpass_smsnox_30001,tnoxpass_smsnox_30001_uat,tnoxpass_smsnox_301,tnoxpass_smsnox_301_uat,tnoxpass_tfe_201116,tnoxpass_tfe_201124,tnoxpass_tfe_201124_uat,tnoxpass_tfe_20115,tnoxpass_tfe_20116,tnoxpass_tfe_2012,tnoxpass_tfe_2012_uat,tnoxpass_tfe_2013,tnoxpass_tfe_2013_uat,transbasic,transbasicapp,transcapitalone,transcapitaloneapp,transcapone_prod_parallel,transdemoacq,transdemoacqapp,transgca,transgca_prod_parallel,transgcaapp,transgcauploader,transhms,transhmsapp,transmoneris,transmoneris_prod_parallel,transmonerisapp,transmsn,transmsnapp,transnox_cat,transnox_cpass,transnox_cpass_partition,transnox_cpass_uat,transnox_gca,transnox_glory,transnox_recon,transnox_ssa,transnox_uid,transnox_uid_00523,transnox_uid_00532,transnox_uid_00535,transnox_wm,transnox_wu,transsigue,transsigue_prod_parallel,transsigueapp,transsuper,transsuperapp,transtsysbpoapp,transtsyspaymentgw,transtsyspaymentgw_uat,transtsyspaymentgwapp,transtsyspgw_prod_parallel,tsnox_usbank,usap_adapter,vctp_fire,vctp_rpt,vctpbak,veribiometrics,vericentre,vericentre_new,vericentre_old,verizon_qa,webfort,wumt,wumtapp,dcurrier,pkoipara,stujare,vborole,vzodge



SELECT SUM(bytes/1024/1024/1024)
FROM dba_Segments
WHERE owner IN ('ACH','ACM','ACM6000','CASHCARD','CHECKCASH','CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC','ETLUPDATECAPONE','ETLUPDATEGW','FHO','FNB_DBA','GOPAY_PORTAL','IDNOX','INVENTORY','INVENTORY2','JLAYANI','KEYNOX_FX','MERGECUSTCODE','OFAC_ADAPTER','PAYFUSEQA','PAYFUSEUAT','QCAPP','QCMGR','QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','REALTIMERPT','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103','SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_GWAY_007_UAT','SNOXPASS_PART','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SNOXPASS_TFE_2013_UAT','TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_GWAY_007_UAT','TNOXPASS_PART','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TNOXPASS_TFE_2013_UAT','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ','TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL','TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE','TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT','TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','USAP_ADAPTER','VCTP_FIRE','VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','WEBFORT','WUMT','WUMTAPP','DCURRIER','PKOIPARA','STUJARE','VBOROLE','VZODGE')


SELECT *
FROM dba_Segments
WHERE owner IN ('ACH','ACM','ACM6000','CASHCARD','CHECKCASH','CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC','ETLUPDATECAPONE','ETLUPDATEGW','FHO','FNB_DBA','GOPAY_PORTAL','IDNOX','INVENTORY','INVENTORY2','JLAYANI','KEYNOX_FX','MERGECUSTCODE','OFAC_ADAPTER','PAYFUSEQA','PAYFUSEUAT','QCAPP','QCMGR','QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','REALTIMERPT','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103','SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_GWAY_007_UAT','SNOXPASS_PART','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SNOXPASS_TFE_2013_UAT','TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_GWAY_007_UAT','TNOXPASS_PART','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TNOXPASS_TFE_2013_UAT','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ','TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL','TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE','TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT','TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','USAP_ADAPTER','VCTP_FIRE','VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','WEBFORT','WUMT','WUMTAPP','DCURRIER','PKOIPARA','STUJARE','VBOROLE','VZODGE')
 AND tablespace_name='USERS'


SELECT UNIQUE GRANTEE
FROM dba_tab_privs
WHERE grantor='TRANSTSYSPAYMENTGW'




SELECT *
FROM dba_tablespaces
WHERE tablespace_name NOT IN ('CPASS_PART3_DATA','CPASS_DATA_TBLS','CPASS_INDX_TBLS','CPASS_PART1_DATA','CPASS_PART1_INDX','CPASS_PART2_DATA','CPASS_PART2_INDX','CPASS_PART3_INDX','CPASS_PART4_DATA','CPASS_PART4_INDX','FAST_GROWTH_INDX','FAST_GROWTH_TBLS','PAYFUSE_DATA_TBLS','PAYFUSE_INDX_TBLS','SLOW_GROWTH_TBLS','TGCA_DATA_TBLS','TGCA_INDX_TBLS','TSENDING_DATA_TBLS','TSENDING_INDX_TBLS','TSYS_EMPL_TBS','USERS','VERICENTRE_DATA_TBLS','VERICENTRE_INDX_TBLS','WEBFORT_DATA_TBLS')



SELECT * FROM dba_segments WHERE tablespace_name ='SLOW_GROWTH_INDX'



---------------------

CREATE TABLESPACE CPASS_PART3_DATA 
DATAFILE 
  '+ORADATA' SIZE 1G AUTOEXTEND OFF,
  '+ORADATA' SIZE 2G AUTOEXTEND ON NEXT 5M MAXSIZE UNLIMITED
LOGGING
PERMANENT
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
BLOCKSIZE 8K
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;


CREATE ROLE DML_ROLE NOT IDENTIFIED;

CREATE ROLE ETL_MONERIS NOT IDENTIFIED;

SELECT *
FROM v$asm_disk

GRANT ETL_MONERIS TO ETLMONERIS

SELECT NAME, ROUND(SUM(TOTAL_MB/1024)) TOTAL_DISK_SPACE, ROUND(SUM(FREE_MB/1024)) FREE_DISK_SPACE, STATE 
FROM V$ASM_DISKGROUP
GROUP BY NAME,TOTAL_MB,STATE

GRANT WRITE,READ ON DIRECTORY dpump TO PUBLIC

SELECT *
FROM dba_data_files
WHERE tablespace_name ='WEBFORT_DATA_TBLS'


SELECT * FROM dba_directories 

CREATE OR REPLACE DIRECTORY dpump AS '/recovery/oracle/dumpfiles'



expdp / 

directory="bkups"
dumpfile="expdp_regdev2_to_rac_27Jun2013.dmp"
logfile="expdp_regdev2_to_rac_27Jun2013.log"
schemas=('AINAMDAR','ANKIT','DBHOSALE','DMULEY','HTTPUNIT','HYADAV','JMURUGAN','MBADHE','MDESALE','MONIDEEPAROY','MVAIDYA','NKUMAR','PPARANJAPE','ROMANWAR','RSHIWALKAR','SKHANDAGLE','SKUMBHARE','SMALIK','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','VBOROLE','VZODGE')
exclude=statistics,table:" like 'SN_TEMP%'",table:" like 'SC_TEMP%'"
content=all
compression=all





('AINAMDAR','ANKIT','DBHOSALE','DMULEY','HTTPUNIT','HYADAV','JMURUGAN','MBADHE','MDESALE','MONIDEEPAROY','MVAIDYA','NKUMAR','PPARANJAPE','ROMANWAR','RSHIWALKAR','SKHANDAGLE','SKUMBHARE','SMALIK','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','VBOROLE','VZODGE')

directory="dpump"
dumpfile="expdp_regdev2_to_rac_27Jun2013.dmp"
logfile="impdp_expdp_regdev2_to_rac_27Jun2013.log"
schemas=('SNOX4TRANSNOX_UID','TRANSNOX_UID')
remap_tablespace=TRANS_DATA:TNOX_CPASS_DATA 
remap_tablespace=USERS:TNOX_CPASS_DATA 
remap_tablespace=SYSTEM:TNOX_CPASS_DATA 
remap_tablespace=INDX:TNOX_CPASS_INDEX


'TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP'

directory="dpump"
dumpfile="expdp_regdev2_to_rac_27Jun2013.dmp"
logfile="impdp_expdp_regdev2_to_rac_27Jun2013_1.log"
schemas=('TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP')
remap_tablespace=TNOX_CPASS_INDEX:TSND_INDX_TBLS
remap_tablespace=TRANS_DATA:TSND_DATA_TBLS
remap_tablespace=TNOX_CPASS_DATA:TSND_DATA_TBLS
remap_tablespace=USERS:TSND_DATA_TBLS
remap_tablespace=INDX:TSND_INDX_TBLS

('SNOX4TRANSNOX_UID','TRANSNOX_UID')


directory="dpump"
dumpfile="expdp_regdev2_to_rac_27Jun2013.dmp"
logfile="impdp_expdp_regdev2_to_rac_27Jun2013_2.log"
schemas=('AINAMDAR','ANKIT','DBHOSALE','DMULEY','HTTPUNIT','HYADAV','JMURUGAN','MBADHE','MDESALE','MONIDEEPAROY','MVAIDYA','NKUMAR','PPARANJAPE','ROMANWAR','RSHIWALKAR','SKHANDAGLE','SKUMBHARE','SMALIK','VBOROLE','VZODGE')



remap_tablespace=TRANS_DATA:TNOX_CPASS_DATA
remap_tablespace=USERS:TNOX_CPASS_DATA
remap_tablespace=SYSTEM:TNOX_CPASS_DATA
remap_tablespace=INDX:TSND_INDX_TBLS





ainamdar,ankit,dbhosale,dmuley,httpunit,hyadav,jmurugan,mbadhe,mdesale,monideeparoy,mvaidya,nkumar,pparanjape,romanwar,rshiwalkar,skhandagle,skumbhare,smalik,vborole,vzodge,transtsyspaymentgw,transtsyspaymentgwapp,snox4transnox_uid,transnox_uid,keynox,keynox_fx,snox4transnox_api,snox4transnox_cpass,snox4transnox_uid_00523,snoxpass_gway_00516,snoxpass_gway_00534,snoxpass_gway_006,snoxpass_gway_007,snoxpass_gway_008,snoxpass_smsnox_20179,snoxpass_smsnox_20189,snoxpass_smsnox_30001,snoxpass_smsnox_301,snoxpass_tfe_201124,snoxpass_tfe_20116,snoxpass_tfe_2012,snoxpass_tfe_2013,snoxpass_tfe_2014,tnoxpass_gway_00516,tnoxpass_gway_00534,tnoxpass_gway_006,tnoxpass_gway_007,tnoxpass_gway_008,tnoxpass_smsnox_20179,tnoxpass_smsnox_20189,tnoxpass_smsnox_30001,tnoxpass_smsnox_301,tnoxpass_tfe_201124,tnoxpass_tfe_20116,tnoxpass_tfe_2012,tnoxpass_tfe_20121,tnoxpass_tfe_2013,tnoxpass_tfe_2014,transnox_cpass,transnox_iox,transnox_uid_00523



'AINAMDAR','ANKIT','DBHOSALE','DMULEY','HTTPUNIT','HYADAV','JMURUGAN','MBADHE','MDESALE','MONIDEEPAROY','MVAIDYA','NKUMAR','PPARANJAPE','ROMANWAR','RSHIWALKAR','SKHANDAGLE','SKUMBHARE','SMALIK','VBOROLE','VZODGE','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','SNOX4TRANSNOX_UID','TRANSNOX_UID','KEYNOX','KEYNOX_FX','SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_UID_00523','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_006','SNOXPASS_GWAY_007','SNOXPASS_GWAY_008','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_301','SNOXPASS_TFE_201124','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2013','SNOXPASS_TFE_2014','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_006','TNOXPASS_GWAY_007','TNOXPASS_GWAY_008','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_301','TNOXPASS_TFE_201124','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_20121','TNOXPASS_TFE_2013','TNOXPASS_TFE_2014','TRANSNOX_CPASS','TRANSNOX_IOX','TRANSNOX_UID_00523'
-- Regression Database
--------------------------------------

expdp rchaudhari directory=ora2 dumpfile=expdp_cpass_pridb.dmp logfile=expdp_cpass_pridb.log schemas=transnox_cpass,snox4transnox_cpass,tnoxpass_gway_007,snoxpass_gway_007,tnoxpass_tfe_2013,snoxpass_tfe_2013 compression=all

 expdp rchaudhari directory=qadb_bkups dumpfile=expdp_cpass_schemas.dmp logfile=expdp_cpass_schemas.log schemas=transnox_cpass,snox4transnox_cpass,tnoxpass_gway_007,snoxpass_gway_007,tnoxpass_tfe_2013,snoxpass_tfe_2013 exclude=statistics,table:\" like \'SN_TEMP%\'\",table:\" like \'SC_TEMP%\'\" content=all compression=all
 
 
 ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','TNOXPASS_GWAY_007','SNOXPASS_GWAY_007','TNOXPASS_TFE_2013','SNOXPASS_TFE_2013')

 
 
 rchaudhari directory=dpump dumpfile=expdp_cpass_schemas.dmp logfile=impdp_expdp_cpass_schemas.log remap_tablespace=USERS:CPASS_DATA_TBLS
 
 
 
 BEGIN
     DBMS_NETWORK_ACL_ADMIN.CREATE_ACL (
     ACL => 'dba.xml', -- case sensitive
     DESCRIPTION=> 'Network Access Control for the DBAs',
     PRINCIPAL => 'TNOXPASS_GWAY_007', -- user or role the privilege is granted or denied (upper case)
     IS_GRANT => TRUE, -- privilege is granted or denied
     PRIVILEGE => 'connect', -- or 'resolve' (case sensitive)
     START_DATE => NULL, -- when the access control entity ACE will be valid
     END_DATE => NULL); -- ACE expiration date (TIMESTAMP WITH TIMEZONE format)
 END;
 /
  
 BEGIN
   DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL (
     acl         => 'dba.xml',
     HOST        => 'SMTP.TSYSACQUIRING.ORG', 
     lower_port  => 25,
     upper_port  => 25); 
     COMMIT;
 END;
 /
  
 BEGIN
  DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE 
   (
     ACL => 'dba.xml',
     PRINCIPAL => 'TNOXPASS_GWAY_007',
     IS_GRANT => TRUE,
     PRIVILEGE => 'connect',
     START_DATE => NULL, -- if the time interval is defined,
     END_DATE => NULL
  ); -- the ACE will expire after the specified date range
 END;
/

----*******************************************-------
--08May2013

ORA-12520: TNS:listener could not find available handler for requested type of server

# event table Automation scripts
sqlplus -s / as sysdba << EOF
spool /oradata4/arc_cronjob/event_arching_glory_wm.log
SELECT TO_CHAR(sysdate,'dd/mm/yyyy hh24:mi:ss') Start_Timestamp from dual;
PROMPT ""
ALTER SESSION SET CURRENT_SCHEMA=snox4transnox;
--- create new table and include last 7 day's data only
CREATE TABLE event_1 NOLOGGING TABLESPACE SNOX_INDX
AS
SELECT *
FROM event
WHERE server_timestamp > SYSDATE-7;
--- rename the current event table name to current date format DDMONYYYY for e.g. 30Jan2013
begin
  execute immediate 'alter table event rename to event_'||TO_CHAR(SYSDATE,'DDMONYYYY');
end;
/
-- replace newly created table event_1 to original event table...
ALTER TABLE event_1 RENAME TO event;
ALTER TABLE event LOGGING;
-- before creating required index, drop them first
DROP INDEX IDX_COMP_CTIME_STAMP;
DROP INDEX IDX_EV_CASCODE;
-- create required index
CREATE INDEX SNOX4TRANSNOX.IDX_COMP_CTIME_STAMP ON SNOX4TRANSNOX.EVENT (SERVICE, WORKSTATIONCODE, SERVER_TIMESTAMP) TABLESPACE SNOX_DATA;
-- commit
COMMIT;
-- grant required privileges of event table to related schemas
GRANT SELECT,UPDATE,INSERT,DELETE ON snox4transnox.event TO transnox_wm;
GRANT SELECT,UPDATE,INSERT,DELETE ON snox4transnox.event TO transnox_glory;
-- create synonym of event table in related schemas
CREATE OR REPLACE SYNONYM TRANSNOX_WM.EVENT FOR SNOX4TRANSNOX.EVENT;
CREATE OR REPLACE SYNONYM TRANSNOX_GLORY.EVENT FOR SNOX4TRANSNOX.EVENT;
-- create required index
CREATE INDEX SNOX4TRANSNOX.IDX_EV_CASCODE ON SNOX4TRANSNOX.EVENT(CASINOCODE) TABLESPACE SNOX_INDX;
-- recompile all related schemas
EXEC DBMS_UTILITY.COMPILE_SCHEMA(SCHEMA=>'SNOX4TRANSNOX');
--EXEC DBMS_UTILITY.COMPILE_SCHEMA(SCHEMA=>'TRANSNOX_WM');
--EXEC DBMS_UTILITY.COMPILE_SCHEMA(SCHEMA=>'TRANSNOX_GLORY');
SELECT TO_CHAR(sysdate,'dd/mm/yyyy hh24:mi:ss') End_Timestamp from dual;
spool off
EOF


--Re: Realignment of ICP uat and GCA Production.. Ticket :- Q295327  
An Oracle Data Pump export (CONTENT=METADATA_ONLY) of the Transnox 
Schemas:- keynox_FX, transnox_GCA, TRANSNOX_RECON, transnox_GLORY, TRANSNOX_WM, and VBS schemas

An Oracle Data Pump export (CONTENT=ALL) of the Snox4Transnox schemas 
Schemas:- SNOX, SNOX4TRANSNOX, SNOX4TRANSNOX_GCA, and VBS schemas

An Oracle Data Pump export (CONTENT=ALL EXCLUDE=TABLE:\"LIKE \'TRANS%\'\" ) of the Transnox objects  
Schemas:- keynox_FX, transnox_GCA, Transnox_RECON, transnox_GLORY, TRANSNOX_WM and VBS
(All data in all tables except any table that starts with 'TRANS%')

---10.175.16.22
-- METADATA_ONLY /archive/oracle/backup/expdp_metadata_GCA_Schemas_08May2013.tar.gz
expdp rahulc directory=bkup dumpfile=expdp_metadata_GCA_Schemas_08May2013.dmp logfile=expdp_metadata_GCA_Schemas_08May2013.log exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\" schemas=keynox_fx,transnox_gca,transnox_recon,transnox_glory,transnox_wm,tnoxgca517,snoxgca517,snoxgca_91x_20109,tnoxgca_91x_20109 content=metadata_only compression=metadata_only



--10.175.16.21
--With - Data /ora11/oracle/bkups/expdp_withdata_snox_schema_08May2013.tar.gz
 expdp rahulc directory=ora11 dumpfile=expdp_withdata_snox_schema_08May2013.dmp logfile=expdp_withdata_snox_schema_08May2013.log exclude=statistics schemas=snox compression=all

--10.175.16.22
--With - Data /archive/oracle/backup/expdp_withdata_snoxGCA_schema_08May2013.tar.gz
expdp rahulc directory=bkup dumpfile=expdp_withdata_snoxGCA_schema_08May2013.dmp logfile=expdp_withdata_snoxGCA_schema_08May2013.log exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\" schemas=snox4transnox,snox4transnox_gca,snoxgca517,snoxgca_91x_20109 compression=all


--10.175.16.22
--With - Data /archive/oracle/backup/expdp_data_GCA_Schemas_08May2013.tar.gz
expdp rahulc directory=bkup dumpfile=expdp_data_GCA_Schemas_08May2013.dmp logfile=expdp_data_GCA_Schemas_08May2013.log exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\",table:\"like \'TRANS%\'\",table:\"like \'TASK%\'\" schemas=KEYNOX_FX,TRANSNOX_GCA,TRANSNOX_RECON,TRANSNOX_GLORY,TRANSNOX_WM,TNOXGCA517,SNOXGCA517,SNOXGCA_91X_20109,TNOXGCA_91X_20109 compression=all

--08May2013
----*******************************************-------


----*******************************************-------
--30APR2013 -- Start

-- run this on transnox_gca schema tempe-22 primary db in between 0800 PM till 1100 PM PST (0830 AM till 1130 AM IST)
set serveroutput on
DECLARE
  I_SETTLE_DATE DATE;
  O_OUTPUTSTATUS NUMBER;
  O_OUTPUTMESSAGE VARCHAR2(200);
BEGIN
    I_SETTLE_DATE := '02-may-2013'; -- enter the date parameter here
    TRANSNOX_GCA.SHAZAM_DET
    (
        I_SETTLE_DATE => I_SETTLE_DATE,
        O_OUTPUTSTATUS => O_OUTPUTSTATUS,
        O_OUTPUTMESSAGE => O_OUTPUTMESSAGE
    );
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('O_OUTPUTSTATUS = ' || O_OUTPUTSTATUS);
    DBMS_OUTPUT.PUT_LINE('O_OUTPUTMESSAGE = ' || O_OUTPUTMESSAGE);
END;
/

SELECT * FROM TRANSNOX_GCA.EOD_SHAZAM_FILE;

"\\cvs.infonox.com\dblogs\RahulC_Stuff\Shazam Data - 30Apr2013.zip"


#!/bin/sh
# .bash_profile

# User specific environment and startup programs
PATH=$PATH:$HOME/bin

export PATH

# Oracle Settings
ORACLE_HOSTNAME=$HOST; export ORACLE_HOSTNAME
ORACLE_BASE=/opt/app/oracle; export ORACLE_BASE
GI_HOME=$ORACLE_BASE/product/11.2.0/grid; export GI_HOME
DB_HOME=$ORACLE_BASE/product/11.2.0/dbhome_1; export DB_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
ORACLE_SID=qadb    ; export ORACLE_SID
BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH; export PATH
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

sqlplus -s / as sysdba << eof
set pagesize 0;
set head off
set echo off
set feedback off
set serveroutput on
spool /opt/app/cronjobs/drop_tbls_srpt.log
PROMPT
PROMPT "*****************************************************"
PROMPT
SELECT owner, COUNT(*)
FROM dba_objects
WHERE REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
  AND object_type='TABLE'
  AND created < SYSDATE-50/1440
GROUP BY owner
ORDER BY 1,2 ASC;
PROMPT
PROMPT "*****************************************************"
PROMPT
BEGIN
    FOR i IN (SELECT owner, object_name FROM dba_objects
              WHERE REGEXP_LIKE(object_name,'S._TEMP[[:digit:]]','i')
                AND object_type='TABLE' AND created < SYSDATE-50/1440)
    LOOP
        dbms_utility.exec_ddl_statement('drop table '||i.owner||'.'||i.object_name||' purge');
    END LOOP;
END;
/
show errors;
spool off
eof




SHELL=/bin/sh
PATH=/bin:/sbin:/usr/bin:/usr/sbin
HOME=/var/log







--- export/import on new qa database server 10.100.224.100 
expdp / directory=ORADATA1 dumpfiles=expdp_tsysemplo_schemas_29apr2013.dmp logfile=expdp_tsysemplo_schemas_29apr2013.log excludes=statistics schemas=aansari,adutta,ainamdar,akathwate,asatyamurti,avohra,bpatil,bsager,buchhold,cbutzke,dbhosale,dchanez,dcurrier,dgangam,dgote,djoshi,dshah,fansari,halversr,hollandr,hyadav,jbethi,jdecker,jlayani,jmurugan,kdigrase,kly,kmahajan,krishna,ksingh,leblance,mbadhe,mbiradar,mdesale,mduval,merlev,monideeparoy,mwittke,nchavda,ndoshi,nitesha,nkumar,nmohanty,nrane,ppandey,psridhar,qyin,rchaudhari,rhalverson,rkanti,romanwar,rraghav,rshiwalkar,rtuscher,sagrawal,saqib,sgadewar,sgayam,skhandagle,skumbhare,smacha,smakineni,smalik,smegeri,ssaxena,ssuryavanshi,stujare,terryw,thigel,uachanta,umahajan,vbannela,vborole,vchanda,vngo,vzodge,zhongchy,zyan,pkoipara compression=all


impdp / directory=qadb_bkups dumpfiles=expdp_tsysemplo_schemas_29apr2013.dmp logfile=impdp_expdp_tsysemplo_schemas_29apr2013.log remap_tablespace=PARTN_1:TSYS_EMPL_TBS remap_tablespace=PARTN_2:TSYS_EMPL_TBS remap_tablespace=TRANS_DATA:TSYS_EMPL_TBS remap_tablespace=TRANS_INDEX:TSYS_EMPL_TBS remap_tablespace=USERS:TSYS_EMPL_TBS exclude=dblink


CPASS_DATA_TBLS
CPASS_INDX_TBLS
TGCA_DATA_TBLS
TGCA_INDX_TBLS
TSENDING_DATA_TBLS
TSENDING_INDX_TBLS
TSYS_EMPL_TBS



/ directory=qadb_bkups


remap_tablespace=data01:vericentre_data_tbls
remap_tablespace=indx01:vericentre_indx_tbls


expdp / directory=ORADATA1 dumpfiles=expdp_tgca_schemas_29apr2013.dmp logfile=expdp_tgca_schemas_29apr2013.log excludes=statistics,db_link schemas=ach,acm,acm6000,cashcard,checkcash,checkcashapp,data_generator,data_upload,etlmoneris,etlupdate,etlupdatebasic,etlupdategw,fho,gopay_portal,idnox,inventory,inventory2,keynox_fx,mergecustcode,ofac_adapter,payfuseqa,payfuseuat,qcapp,qcmgr,qcmgr_app,qcp,qcpapp,qcpmgr,qcredit,qfapp,qfcs,qfund,qkadvanceapp,qplay,qracm,qrqcp,quikadvance,quikadvance_app,realtimerpt,snox,snox4transnox,snox4transnox_gca,snox4transnox_wucc,snoxdevices,snoxgca_91x_20101,snoxgca_91x_20101p,snoxgca_91x_20102,snoxgca_91x_20103,snoxgca_91x_20104,snox_gca_00510,snox_gca_0058,snox_gca_0059,snox_usbank,tnoxgca_91x_20101,tnoxgca_91x_20101p,tnoxgca_91x_20102,tnoxgca_91x_20103,tnoxgca_91x_20104,tnox_gca_00510,tnox_gca_0058,tnox_gca_0059,transnox_gca,transnox_glory,transnox_recon,transnox_ssa,transnox_wm,transnox_wu,tsnox_usbank,usap_adapter,vcep,vctpbak,vctp_fire,vctp_rpt,veribiometrics,vericentre,vericentre_new,vericentre_old,verizon_qa,webfort,wumt,wumtapp compression=all

('ACH','ACM','ACM6000','CASHCARD','CHECKCASH','CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC','ETLUPDATEGW','FHO','GOPAY_PORTAL','IDNOX','INVENTORY','INVENTORY2','KEYNOX_FX','MERGECUSTCODE','OFAC_ADAPTER','PAYFUSEQA','PAYFUSEUAT','QCAPP','QCMGR','QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','REALTIMERPT','SNOX','SNOX4TRANSNOX','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103','SNOXGCA_91X_20104','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104','TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_WM','TRANSNOX_WU','TSNOX_USBANK','USAP_ADAPTER','VCEP','VCTPBAK','VCTP_FIRE','VCTP_RPT','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','WEBFORT','WUMT','WUMTAPP')

impdp / directory=qadb_bkups dumpfiles=expdp_tgca_schemas_29apr2013.dmp logfile=impdp_expdp_tgca_schemas_29apr2013.log exclude=db_link remap_tablespace=FAST_GROWTH_TAB:FAST_GROWTH_TBLS remap_tablespace=FAST_GROWTH_IDX:FAST_GROWTH_INDX remap_tablespace=SLOW_GROWTH_TAB:SLOW_GROWTH_TBLS remap_tablespace=SLOW_GROWTH_IDX:SLOW_GROWTH_INDX remap_tablespace=USERS:TGCA_DATA_TBLS remap_tablespace=INDX:TGCA_INDX_TBLS remap_tablespace=ARCHIVE_TAB:PAYFUSE_DATA_TBLS remap_tablespace=DATA01:VERICENTRE_DATA_TBLS remap_tablespace=INDX01:VERICENTRE_INDX_TBLS remap_tablespace=WEBFORT:WEBFORT_DATA_TBLS

-- TransIT schemas
expdp / directory=ORADATA1 dumpfile=expdp_cpass_schemas_30apr2013.dmp logfile=expdp_cpass_schemas_30apr2013.log exclude=statistics,db_link,TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\" schemas=snox4transnox_api,snox4transnox_cpass,snox4transnox_cpass_uat,snox4transnox_uid,snox4transnox_uid_00523,snox4transnox_uid_00530,snox4transnox_uid_00532,snox4transnox_uid_00535,snoxpass_gway_00513,snoxpass_gway_00515,snoxpass_gway_00516,snoxpass_gway_00520,snoxpass_gway_00521,snoxpass_gway_00522,snoxpass_gway_00523,snoxpass_gway_00524,snoxpass_gway_00526,snoxpass_gway_00527,snoxpass_gway_00528,snoxpass_gway_00529,snoxpass_gway_00531,snoxpass_gway_00532,snoxpass_gway_00533,snoxpass_gway_00534,snoxpass_gway_00534_uat,snoxpass_gway_0059,snoxpass_gway_006,snoxpass_gway_006_uat,snoxpass_gway_007,snoxpass_part,snoxpass_smsnox_20170,snoxpass_smsnox_20176,snoxpass_smsnox_20179,snoxpass_smsnox_20189,snoxpass_smsnox_20191,snoxpass_smsnox_20193,snoxpass_smsnox_20194,snoxpass_smsnox_20195,snoxpass_smsnox_20197,snoxpass_smsnox_20198,snoxpass_smsnox_20199,snoxpass_smsnox_30001,snoxpass_smsnox_30001_uat,snoxpass_smsnox_301,snoxpass_smsnox_301_uat,snoxpass_tfe_201116,snoxpass_tfe_201124,snoxpass_tfe_201124_uat,snoxpass_tfe_20113,snoxpass_tfe_20115,snoxpass_tfe_20116,snoxpass_tfe_2012,snoxpass_tfe_2012_uat,snoxpass_tfe_2013,tnoxpass_gway_00513,tnoxpass_gway_00515,tnoxpass_gway_00516,tnoxpass_gway_00520,tnoxpass_gway_00521,tnoxpass_gway_00522,tnoxpass_gway_00523,tnoxpass_gway_00524,tnoxpass_gway_00526,tnoxpass_gway_00527,tnoxpass_gway_00528,tnoxpass_gway_00529,tnoxpass_gway_00531,tnoxpass_gway_00532,tnoxpass_gway_00533,tnoxpass_gway_00534,tnoxpass_gway_00534_uat,tnoxpass_gway_0059,tnoxpass_gway_006,tnoxpass_gway_006_uat,tnoxpass_gway_007,tnoxpass_part,tnoxpass_smsnox_20170,tnoxpass_smsnox_20176,tnoxpass_smsnox_20179,tnoxpass_smsnox_20189,tnoxpass_smsnox_20191,tnoxpass_smsnox_20193,tnoxpass_smsnox_20194,tnoxpass_smsnox_20195,tnoxpass_smsnox_20197,tnoxpass_smsnox_20198,tnoxpass_smsnox_20199,tnoxpass_smsnox_30001,tnoxpass_smsnox_30001_uat,tnoxpass_smsnox_301,tnoxpass_smsnox_301_uat,tnoxpass_tfe_201116,tnoxpass_tfe_201124,tnoxpass_tfe_201124_uat,tnoxpass_tfe_20113,tnoxpass_tfe_20115,tnoxpass_tfe_20116,tnoxpass_tfe_2012,tnoxpass_tfe_2012_uat,tnoxpass_tfe_2013,transnox_cat,transnox_cpass,transnox_cpass_uat,transnox_iox,transnox_uid,transnox_uid_00523,transnox_uid_00530,transnox_uid_00532,transnox_uid_00535 compression=all

snox4transnox_api,snox4transnox_cpass,snox4transnox_cpass_uat,snox4transnox_uid,snox4transnox_uid_00523,snox4transnox_uid_00530,snox4transnox_uid_00532,snox4transnox_uid_00535,snoxpass_gway_00513,snoxpass_gway_00515,snoxpass_gway_00516,snoxpass_gway_00520,snoxpass_gway_00521,snoxpass_gway_00522,snoxpass_gway_00523,snoxpass_gway_00524,snoxpass_gway_00526,snoxpass_gway_00527,snoxpass_gway_00528,snoxpass_gway_00529,snoxpass_gway_00531,snoxpass_gway_00532,snoxpass_gway_00533,snoxpass_gway_00534,snoxpass_gway_00534_uat,snoxpass_gway_0059,snoxpass_gway_006,snoxpass_gway_006_uat,snoxpass_gway_007,snoxpass_smsnox_20170,snoxpass_smsnox_20176,snoxpass_smsnox_20179,snoxpass_smsnox_20189,snoxpass_smsnox_20191,snoxpass_smsnox_20193,snoxpass_smsnox_20194,snoxpass_smsnox_20195,snoxpass_smsnox_20197,snoxpass_smsnox_20198,snoxpass_smsnox_20199,snoxpass_smsnox_30001,snoxpass_smsnox_30001_uat,snoxpass_smsnox_301,snoxpass_smsnox_301_uat,snoxpass_tfe_201116,snoxpass_tfe_201124,snoxpass_tfe_201124_uat,snoxpass_tfe_20113,snoxpass_tfe_20115,snoxpass_tfe_20116,snoxpass_tfe_2012,snoxpass_tfe_2012_uat,snoxpass_tfe_2013,tnoxpass_gway_00513,tnoxpass_gway_00515,tnoxpass_gway_00516,tnoxpass_gway_00520,tnoxpass_gway_00521,tnoxpass_gway_00522,tnoxpass_gway_00523,tnoxpass_gway_00524,tnoxpass_gway_00526,tnoxpass_gway_00527,tnoxpass_gway_00528,tnoxpass_gway_00529,tnoxpass_gway_00531,tnoxpass_gway_00532,tnoxpass_gway_00533,tnoxpass_gway_00534,tnoxpass_gway_00534_uat,tnoxpass_gway_0059,tnoxpass_gway_006,tnoxpass_gway_006_uat,tnoxpass_gway_007,tnoxpass_smsnox_20170,tnoxpass_smsnox_20176,tnoxpass_smsnox_20179,tnoxpass_smsnox_20189,tnoxpass_smsnox_20191,tnoxpass_smsnox_20193,tnoxpass_smsnox_20194,tnoxpass_smsnox_20195,tnoxpass_smsnox_20197,tnoxpass_smsnox_20198,tnoxpass_smsnox_20199,tnoxpass_smsnox_30001,tnoxpass_smsnox_30001_uat,tnoxpass_smsnox_301,tnoxpass_smsnox_301_uat,tnoxpass_tfe_201116,tnoxpass_tfe_201124,tnoxpass_tfe_201124_uat,tnoxpass_tfe_20113,tnoxpass_tfe_20115,tnoxpass_tfe_20116,tnoxpass_tfe_2012,tnoxpass_tfe_2012_uat,tnoxpass_tfe_2013,transnox_cat,transnox_cpass,transnox_cpass_uat,transnox_iox,transnox_uid,transnox_uid_00523,transnox_uid_00530,transnox_uid_00532,transnox_uid_00535

('SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00530','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_0059','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_SMSNOX_20170','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_0059','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_SMSNOX_20170','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_UAT','TRANSNOX_IOX','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00530','TRANSNOX_UID_00532','TRANSNOX_UID_00535')


-- export was taken including partition related schemas which has to be excluded will importing and can created after wards
----('SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00530','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_0059','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_PART','SNOXPASS_SMSNOX_20170','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_0059','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_PART','TNOXPASS_SMSNOX_20170','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_UAT','TRANSNOX_IOX','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00530','TRANSNOX_UID_00532','TRANSNOX_UID_00535')

--- final import script exclding partition related schemas
impdp / directory=qadb_bkups dumpfile=expdp_cpass_schemas_30apr2013.dmp logfile=impdp_expdp_cpass_schemas_30apr2013.log schemas=snox4transnox_api,snox4transnox_cpass,snox4transnox_cpass_uat,snox4transnox_uid,snox4transnox_uid_00523,snox4transnox_uid_00530,snox4transnox_uid_00532,snox4transnox_uid_00535,snoxpass_gway_00513,snoxpass_gway_00515,snoxpass_gway_00516,snoxpass_gway_00520,snoxpass_gway_00521,snoxpass_gway_00522,snoxpass_gway_00523,snoxpass_gway_00524,snoxpass_gway_00526,snoxpass_gway_00527,snoxpass_gway_00528,snoxpass_gway_00529,snoxpass_gway_00531,snoxpass_gway_00532,snoxpass_gway_00533,snoxpass_gway_00534,snoxpass_gway_00534_uat,snoxpass_gway_0059,snoxpass_gway_006,snoxpass_gway_006_uat,snoxpass_gway_007,snoxpass_smsnox_20170,snoxpass_smsnox_20176,snoxpass_smsnox_20179,snoxpass_smsnox_20189,snoxpass_smsnox_20191,snoxpass_smsnox_20193,snoxpass_smsnox_20194,snoxpass_smsnox_20195,snoxpass_smsnox_20197,snoxpass_smsnox_20198,snoxpass_smsnox_20199,snoxpass_smsnox_30001,snoxpass_smsnox_30001_uat,snoxpass_smsnox_301,snoxpass_smsnox_301_uat,snoxpass_tfe_201116,snoxpass_tfe_201124,snoxpass_tfe_201124_uat,snoxpass_tfe_20113,snoxpass_tfe_20115,snoxpass_tfe_20116,snoxpass_tfe_2012,snoxpass_tfe_2012_uat,snoxpass_tfe_2013,tnoxpass_gway_00513,tnoxpass_gway_00515,tnoxpass_gway_00516,tnoxpass_gway_00520,tnoxpass_gway_00521,tnoxpass_gway_00522,tnoxpass_gway_00523,tnoxpass_gway_00524,tnoxpass_gway_00526,tnoxpass_gway_00527,tnoxpass_gway_00528,tnoxpass_gway_00529,tnoxpass_gway_00531,tnoxpass_gway_00532,tnoxpass_gway_00533,tnoxpass_gway_00534,tnoxpass_gway_00534_uat,tnoxpass_gway_0059,tnoxpass_gway_006,tnoxpass_gway_006_uat,tnoxpass_gway_007,tnoxpass_smsnox_20170,tnoxpass_smsnox_20176,tnoxpass_smsnox_20179,tnoxpass_smsnox_20189,tnoxpass_smsnox_20191,tnoxpass_smsnox_20193,tnoxpass_smsnox_20194,tnoxpass_smsnox_20195,tnoxpass_smsnox_20197,tnoxpass_smsnox_20198,tnoxpass_smsnox_20199,tnoxpass_smsnox_30001,tnoxpass_smsnox_30001_uat,tnoxpass_smsnox_301,tnoxpass_smsnox_301_uat,tnoxpass_tfe_201116,tnoxpass_tfe_201124,tnoxpass_tfe_201124_uat,tnoxpass_tfe_20113,tnoxpass_tfe_20115,tnoxpass_tfe_20116,tnoxpass_tfe_2012,tnoxpass_tfe_2012_uat,tnoxpass_tfe_2013,transnox_cat,transnox_cpass,transnox_cpass_uat,transnox_iox,transnox_uid,transnox_uid_00523,transnox_uid_00530,transnox_uid_00532,transnox_uid_00535 remap_tablespace=TRANS_DATA:CPASS_DATA_TBLS remap_tablespace=USERS:CPASS_DATA_TBLS remap_tablespace=TRANS_INDEX:CPASS_INDX_TBLS remap_tablespace=SYSTEM:CPASS_INDX_TBLS remap_tablespace=INDX:CPASS_INDX_TBLS



'SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00530','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_0059','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_SMSNOX_20170','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_0059','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_SMSNOX_20170','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_UAT','TRANSNOX_IOX','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00530','TRANSNOX_UID_00532','TRANSNOX_UID_00535'
'TRANSGCA_PROD_PARALLEL','TRANSSIGUE_PROD_PARALLEL','TRANSCAPITALONE','TRANSDEMOACQ','TRANSBASIC','TRANSSUPER','TRANSTSYSBPO','TRANSSIGUE','TRANSGCA','TRANSMSN','TRANSGCAAPP','TRANSBASICAPP'

--- Transcending schemas
expdp / directory=ORADATA1 dumpfile=expdp_tsending_unused_schemas_30apr2013.dmp logfile=expdp_tsending_unused_schemas_30apr2013.log excludes=statistics,db_link schemas=transgca_prod_parallel,transsigue_prod_parallel,transcapitalone,transdemoacq,transbasic,transsuper,transtsysbpo,transsigue,transgca,transmsn,transgcaapp,transbasicapp compression=all

('TRANSGCA_PROD_PARALLEL','TRANSSIGUE_PROD_PARALLEL','TRANSCAPITALONE','TRANSDEMOACQ','TRANSBASIC','TRANSSUPER','TRANSTSYSBPO','TRANSSIGUE','TRANSGCA','TRANSMSN','TRANSGCAAPP','TRANSBASICAPP')

impdp / directory=qadb_bkups dumpfile=expdp_tsending_unused_schemas_30apr2013.dmp logfile=impdp_expdp_tsending_unused_schemas_30apr2013.log remap_tablespace=trans_data:tsending_data_tbls remap_tablespace=trans_index:tsending_indx_tbls remap_tablespace=users:tsending_data_tbls remap_tablespace=indx:tsending_indx_tbls


expdp / directory=ORADATA1 dumpfile=expdp_tsending_used_schemas_30apr2013.dmp logfile=expdp_tsending_used_schemas_30apr2013.log excludes=statistics,db_link schemas=transhms,transmoneris,transmoneris_prod_parallel,transcapone_prod_parallel

impdp / directory=qadb_bkups dumpfile=expdp_tsending_used_schemas_30apr2013.dmp logfile=impdp_expdp_tsending_used_schemas_30apr2013.log remap_tablespace=trans_data:tsending_data_tbls remap_tablespace=trans_index:tsending_indx_tbls remap_tablespace=users:tsending_data_tbls remap_tablespace=indx:tsending_indx_tbls

-- tsyspaymentgw schemas
expdp / directory=ORADATA1 dumpfile=expdp_tsending_tsyspwg_schemas_30apr2013.dmp logfile=expdp_tsending_tsyspwg_schemas_30apr2013.log excludes=statistics,db_link schemas=transtsyspaymentgw,transtsyspaymentgw_uat,transtsyspgw_prod_parallel

impdp / directory=qadb_bkups dumpfile=expdp_tsending_tsyspwg_schemas_30apr2013.dmp logfile=impdp_expdp_tsending_tsyspwg_schemas_30apr2013.log remap_tablespace=trans_data:tsending_data_tbls remap_tablespace=trans_index:tsending_indx_tbls remap_tablespace=users:tsending_data_tbls remap_tablespace=indx:tsending_indx_tbls


--- remaining schemas

('FNB_DBA','SNOX4TRANSNOX_CPASS_PARTITION','SNOXPASS_PART','TNOXPASS_PART','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERISAPP','TRANSMONERIS_PROD_PARALLEL','TRANSMSNAPP','TRANSNOX_CPASS_PARTITION','TRANSSIGUEAPP','TRANSSUPERAPP','TRANSTSYSBPOAPP')

expdp / directory=ORADATA1 dumpfile=expdp_remaining_schemas_30apr2013.dmp logfile=expdp_remaining_schemas_30apr2013.log excludes=statistics,db_link schemas=fnb_dba,snox4transnox_cpass_partition,snoxpass_part,tnoxpass_part,transcapitaloneapp,transcapone_prod_parallel,transdemoacqapp,transgcauploader,transhms,transhmsapp,transmoneris,transmonerisapp,transmoneris_prod_parallel,transmsnapp,transnox_cpass_partition,transsigueapp,transsuperapp,transtsysbpoapp compression=all

expdp_remaining_schemas_30apr2013.dmp


CPASS_PART1_DATA
CPASS_PART2_DATA
CPASS_PART3_DATA
CPASS_PART4_DATA
CPASS_PART1_INDX
CPASS_PART2_INDX
CPASS_PART3_INDX
CPASS_PART4_INDX


impdp / directory=qadb_bkups dumpfile=expdp_remaining_schemas_30apr2013.dmp logfile=impdp_expdp_remaining_schemas_30apr2013.log remap_tablespace=INDX:CPASS_INDX_TBLS remap_tablespace=PARTN_1:CPASS_PART1_DATA remap_tablespace=PARTN_2:CPASS_PART2_DATA remap_tablespace=SYSTEM:CPASS_INDX_TBLS remap_tablespace=TRANS_DATA:CPASS_DATA_TBLS remap_tablespace=TRANS_INDEX:TSENDING_INDX_TBLS remap_tablespace=USERS:CPASS_DATA_TBLS

---- grants and synonyms export and import for all qa db schemas

expdp / directory=ORADATA1 dumpfile=expdp_grant_n_synonyms_allschema.dmp logfile=expdp_grant_n_synonyms_allschema.log content=metadata_only include=object_grant,synonym schemas=aansari,ach,acm,acm6000,adutta,ainamdar,akathwate,asatyamurti,avohra,bpatil,bsager,buchhold,cashcard,cbutzke,checkcash,checkcashapp,data_generator,data_upload,dbhosale,dchanez,dcurrier,dgangam,dgote,djoshi,dshah,etlmoneris,etlupdate,etlupdatebasic,etlupdategw,fansari,fho,gopay_portal,halversr,hollandr,hyadav,idnox,inventory,inventory2,jbethi,jdecker,jlayani,jmurugan,kdigrase,keynox_fx,kly,kmahajan,krishna,ksingh,leblance,mbadhe,mbiradar,mdesale,mduval,mergecustcode,merlev,monideeparoy,mwittke,nchavda,ndoshi,nitesha,nkumar,nmohanty,nrane,ofac_adapter,ops$oracle,payfuseqa,payfuseuat,ppandey,psridhar,qcapp,qcmgr,qcmgr_app,qcp,qcpapp,qcpmgr,qcredit,qfapp,qfcs,qfund,qkadvanceapp,qplay,qracm,qrqcp,quikadvance,quikadvance_app,qyin,rchaudhari,realtimerpt,rhalverson,rkanti,romanwar,rraghav,rshiwalkar,rtuscher,sagrawal,saqib,sgadewar,sgayam,skhandagle,skumbhare,smacha,smakineni,smalik,smegeri,snox,snox_gca_00510,snox_gca_0058,snox_gca_0059,snox_usbank,snox4transnox,snox4transnox_cpass,snox4transnox_cpass_uat,snox4transnox_gca,snox4transnox_uid,snox4transnox_uid_00523,snox4transnox_uid_00532,snox4transnox_uid_00535,snox4transnox_wucc,snoxdevices,snoxgca_91x_20101,snoxgca_91x_20101p,snoxgca_91x_20102,snoxgca_91x_20103,snoxgca_91x_20104,snoxpass_gway_00515,snoxpass_gway_00516,snoxpass_gway_00520,snoxpass_gway_00521,snoxpass_gway_00522,snoxpass_gway_00523,snoxpass_gway_00524,snoxpass_gway_00526,snoxpass_gway_00527,snoxpass_gway_00528,snoxpass_gway_00529,snoxpass_gway_00531,snoxpass_gway_00532,snoxpass_gway_00533,snoxpass_gway_00534,snoxpass_gway_00534_uat,snoxpass_gway_006,snoxpass_gway_006_uat,snoxpass_gway_007,snoxpass_smsnox_20176,snoxpass_smsnox_20179,snoxpass_smsnox_20189,snoxpass_smsnox_20191,snoxpass_smsnox_20193,snoxpass_smsnox_20194,snoxpass_smsnox_20195,snoxpass_smsnox_20197,snoxpass_smsnox_20198,snoxpass_smsnox_20199,snoxpass_smsnox_30001,snoxpass_smsnox_30001_uat,snoxpass_smsnox_301,snoxpass_smsnox_301_uat,snoxpass_tfe_201116,snoxpass_tfe_201124,snoxpass_tfe_201124_uat,snoxpass_tfe_20115,snoxpass_tfe_20116,snoxpass_tfe_2012,snoxpass_tfe_2012_uat,snoxpass_tfe_2013,ssaxena,ssuryavanshi,stujare,terryw,thigel,tnox_gca_00510,tnox_gca_0058,tnox_gca_0059,tnoxgca_91x_20101,tnoxgca_91x_20101p,tnoxgca_91x_20102,tnoxgca_91x_20103,tnoxgca_91x_20104,tnoxpass_gway_00515,tnoxpass_gway_00516,tnoxpass_gway_00520,tnoxpass_gway_00521,tnoxpass_gway_00522,tnoxpass_gway_00523,tnoxpass_gway_00524,tnoxpass_gway_00526,tnoxpass_gway_00527,tnoxpass_gway_00528,tnoxpass_gway_00529,tnoxpass_gway_00531,tnoxpass_gway_00532,tnoxpass_gway_00533,tnoxpass_gway_00534,tnoxpass_gway_00534_uat,tnoxpass_gway_006,tnoxpass_gway_006_uat,tnoxpass_gway_007,tnoxpass_smsnox_20176,tnoxpass_smsnox_20179,tnoxpass_smsnox_20189,tnoxpass_smsnox_20191,tnoxpass_smsnox_20193,tnoxpass_smsnox_20194,tnoxpass_smsnox_20195,tnoxpass_smsnox_20197,tnoxpass_smsnox_20198,tnoxpass_smsnox_20199,tnoxpass_smsnox_30001,tnoxpass_smsnox_30001_uat,tnoxpass_smsnox_301,tnoxpass_smsnox_301_uat,tnoxpass_tfe_201116,tnoxpass_tfe_201124,tnoxpass_tfe_201124_uat,tnoxpass_tfe_20115,tnoxpass_tfe_20116,tnoxpass_tfe_2012,tnoxpass_tfe_2012_uat,tnoxpass_tfe_2013,transbasic,transbasicapp,transcapitalone,transdemoacq,transgca,transgca_prod_parallel,transgcaapp,transmsn,transnox_cat,transnox_cpass,transnox_cpass_uat,transnox_gca,transnox_glory,transnox_recon,transnox_ssa,transnox_uid,transnox_uid_00523,transnox_uid_00532,transnox_uid_00535,transnox_wm,transnox_wu,transsigue,transsigue_prod_parallel,transsuper,transtsyspaymentgw,transtsyspaymentgw_uat,transtsyspaymentgwapp,transtsyspgw_prod_parallel,tsnox_usbank,uachanta,umahajan,usap_adapter,vbannela,vborole,vcep,vchanda,vctp_fire,vctp_rpt,vctpbak,veribiometrics,vericentre,vericentre_new,vericentre_old,verizon_qa,vngo,vzodge,webfort,wumt,wumtapp,zhongchy,zyan,pkoipara compression=all


impdp / directory=qadb_bkups dumpfile=expdp_grant_n_synonyms_allschema.dmp logfile=impdp_expdp_grant_n_synonyms_allschema.log 


SELECT username
FROM dba_users@qadb_old i
WHERE NOT EXISTS (SELECT 1 FROM dba_users o WHERE o.username = i.username)
ORDER BY 1 ASC


SELECT username
FROM dba_users@qadb_old
WHERE username NOT IN ('AANSARI','ADUTTA','AINAMDAR','AKATHWATE','ASATYAMURTI','AVOHRA','BPATIL','BSAGER','BUCHHOLD','CBUTZKE','DBHOSALE','DCHANEZ','DCURRIER','DGANGAM','DGOTE','DJOSHI','DSHAH','FANSARI','HALVERSR','HOLLANDR','HYADAV','JBETHI','JDECKER','JLAYANI','JMURUGAN','KDIGRASE','KLY','KMAHAJAN','KRISHNA','KSINGH','LEBLANCE','MBADHE','MBIRADAR','MDESALE','MDUVAL','MERLEV','MONIDEEPAROY','MWITTKE','NCHAVDA','NDOSHI','NITESHA','NKUMAR','NMOHANTY','NRANE','PPANDEY','PSRIDHAR','QYIN','RCHAUDHARI','RHALVERSON','RKANTI','ROMANWAR','RRAGHAV','RSHIWALKAR','RTUSCHER','SAGRAWAL','SAQIB','SGADEWAR','SGAYAM','SKHANDAGLE','SKUMBHARE','SMACHA','SMAKINENI','SMALIK','SMEGERI','SSAXENA','SSURYAVANSHI','STUJARE','TERRYW','THIGEL','UACHANTA','UMAHAJAN','VBANNELA','VBOROLE','VCHANDA','VNGO','VZODGE','ZHONGCHY','ZYAN','PKOIPARA',
                       'ANONYMOUS','APEX_PUBLIC_USER','CTXSYS','DBSNMP','DIP','EXFSYS','EXPBKUPS','FLOWS_030000','FLOWS_FILES','MDDATA','MDSYS','MGMT_VIEW','OLAPSYS','OPS$ORACLE','ORACLE_OCM','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','RMAN','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY','WKSYS','WK_TEST','WMSYS','XDB','XS$NULL',
                       'ACH','ACM','ACM6000','CASHCARD','CHECKCASH','CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC','ETLUPDATEGW','FHO','GOPAY_PORTAL','IDNOX','INVENTORY','INVENTORY2','KEYNOX_FX','MERGECUSTCODE','OFAC_ADAPTER','PAYFUSEQA','PAYFUSEUAT','QCAPP','QCMGR','QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','REALTIMERPT','SNOX','SNOX4TRANSNOX','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103','SNOXGCA_91X_20104','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104','TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TRANSNOX_GCA','TRANSNOX_GLORY','TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_WM','TRANSNOX_WU','TSNOX_USBANK','USAP_ADAPTER','VCEP','VCTPBAK','VCTP_FIRE','VCTP_RPT','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','WEBFORT','WUMT','WUMTAPP',
                       'SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00530','SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_0059','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_SMSNOX_20170','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_0059','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_SMSNOX_20170','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_UAT','TRANSNOX_IOX','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00530','TRANSNOX_UID_00532','TRANSNOX_UID_00535',
                       'TRANSGCA_PROD_PARALLEL','TRANSSIGUE_PROD_PARALLEL','TRANSCAPITALONE','TRANSDEMOACQ','TRANSBASIC','TRANSSUPER','TRANSTSYSBPO','TRANSSIGUE','TRANSGCA','TRANSMSN','TRANSGCAAPP','TRANSBASICAPP',
                       'TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TRANSTSYSPAYMENTGW_UAT','TRANSTSYSPGW_PROD_PARALLEL'
                      )
ORDER BY 1 ASC

ALTER TABLE PAYFUSEQA.ADDRESS_LIST_VALUE ADD (
  CONSTRAINT ADDRESS_LIST_VALUE_PK
  PRIMARY KEY
  (LIST_ID, CC_CLIENT_ID, LOCATION, POSTAL_CODE));


ALTER INDEX payfuseqa.ADDRESS_LIST_VALUE_PK REBUILD TABLESPACE PAYFUSE_INDX_TBLS


SELECT 'ALTER INDEX '||OWNER||'.'||segment_name||' REBUILD TABLESPACE PAYFUSE_INDX_TBLS;'
FROM dba_segments
WHERE tablespace_name='SLOW_GROWTH_INDX'


SELECT owner, object_name 
FROM dba_objects@qadb_old
WHERE owner IN ('AANSARI','ACH','ACM','ACM6000','ADUTTA','AINAMDAR','AKATHWATE','ASATYAMURTI','AVOHRA','BPATIL','BSAGER','BUCHHOLD','CASHCARD','CBUTZKE','CHECKCASH',
                 'CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','DCHANEZ','DCURRIER','DGANGAM','DGOTE','DJOSHI','DSHAH','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC',
                 'ETLUPDATEGW','FANSARI','FHO','FNB_DBA','GOPAY_PORTAL','HALVERSR','HOLLANDR','HYADAV','IDNOX','INVENTORY','INVENTORY2','JBETHI','JDECKER','JLAYANI','JMURUGAN',
                 'KDIGRASE','KEYNOX_FX','KLY','KMAHAJAN','KRISHNA','KSINGH','LEBLANCE','MBADHE','MBIRADAR','MDESALE','MDUVAL','MERGECUSTCODE','MERLEV','MONIDEEPAROY',
                 'MWITTKE','NCHAVDA','NDOSHI','NITESHA','NKUMAR','NMOHANTY','NRANE','OFAC_ADAPTER','OPS$ORACLE','PAYFUSEQA','PAYFUSEUAT','PPANDEY','PSRIDHAR','QCAPP','QCMGR',
                 'QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','QYIN',
                 'RCHAUDHARI','REALTIMERPT','RHALVERSON','RKANTI','ROMANWAR','RRAGHAV','RSHIWALKAR','RTUSCHER','SAGRAWAL','SAQIB','SGADEWAR','SGAYAM','SKHANDAGLE','SKUMBHARE',
                 'SMACHA','SMAKINENI','SMALIK','SMEGERI','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS',
                 'SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532',
                 'SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103',
                 'SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523',
                 'SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532',
                 'SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_PART',
                 'SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194',
                 'SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT',
                 'SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115',
                 'SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SSAXENA','SSURYAVANSHI','STUJARE','SYS','SYSTEM','TERRYW','THIGEL',
                 'TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104',
                 'TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524',
                 'TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533',
                 'TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_PART','TNOXPASS_SMSNOX_20176',
                 'TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195',
                 'TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301',
                 'TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012',
                 'TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ',
                 'TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL',
                 'TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY',
                 'TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE',
                 'TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT',
                 'TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','UACHANTA','UMAHAJAN','USAP_ADAPTER','VBANNELA','VBOROLE','VCEP','VCHANDA','VCTP_FIRE',
                 'VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','VNGO','VZODGE','WEBFORT','WUMT','WUMTAPP','ZHONGCHY','ZYAN',
                 'PKOIPARA')
 AND object_type='TABLE' AND owner NOT IN ('ANONYMOUS','APEX_PUBLIC_USER','CTXSYS','DBSNMP','DIP','EXFSYS','EXPBKUPS','FLOWS_030000','FLOWS_FILES','MDDATA','MDSYS','MGMT_VIEW','OLAPSYS','OPS$ORACLE','ORACLE_OCM','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','RMAN','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY','WKSYS','WK_TEST','WMSYS','XDB','XS$NULL')           
 AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
MINUS 
SELECT owner, object_name 
FROM dba_objects
WHERE owner IN ('AANSARI','ACH','ACM','ACM6000','ADUTTA','AINAMDAR','AKATHWATE','ASATYAMURTI','AVOHRA','BPATIL','BSAGER','BUCHHOLD','CASHCARD','CBUTZKE','CHECKCASH',
                 'CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','DCHANEZ','DCURRIER','DGANGAM','DGOTE','DJOSHI','DSHAH','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC',
                 'ETLUPDATEGW','FANSARI','FHO','FNB_DBA','GOPAY_PORTAL','HALVERSR','HOLLANDR','HYADAV','IDNOX','INVENTORY','INVENTORY2','JBETHI','JDECKER','JLAYANI','JMURUGAN',
                 'KDIGRASE','KEYNOX_FX','KLY','KMAHAJAN','KRISHNA','KSINGH','LEBLANCE','MBADHE','MBIRADAR','MDESALE','MDUVAL','MERGECUSTCODE','MERLEV','MONIDEEPAROY',
                 'MWITTKE','NCHAVDA','NDOSHI','NITESHA','NKUMAR','NMOHANTY','NRANE','OFAC_ADAPTER','OPS$ORACLE','PAYFUSEQA','PAYFUSEUAT','PPANDEY','PSRIDHAR','QCAPP','QCMGR',
                 'QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','QYIN',
                 'RCHAUDHARI','REALTIMERPT','RHALVERSON','RKANTI','ROMANWAR','RRAGHAV','RSHIWALKAR','RTUSCHER','SAGRAWAL','SAQIB','SGADEWAR','SGAYAM','SKHANDAGLE','SKUMBHARE',
                 'SMACHA','SMAKINENI','SMALIK','SMEGERI','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS',
                 'SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532',
                 'SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103',
                 'SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523',
                 'SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532',
                 'SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_PART',
                 'SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194',
                 'SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT',
                 'SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115',
                 'SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SSAXENA','SSURYAVANSHI','STUJARE','SYS','SYSTEM','TERRYW','THIGEL',
                 'TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104',
                 'TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524',
                 'TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533',
                 'TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_PART','TNOXPASS_SMSNOX_20176',
                 'TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195',
                 'TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301',
                 'TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012',
                 'TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ',
                 'TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL',
                 'TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY',
                 'TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE',
                 'TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT',
                 'TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','UACHANTA','UMAHAJAN','USAP_ADAPTER','VBANNELA','VBOROLE','VCEP','VCHANDA','VCTP_FIRE',
                 'VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','VNGO','VZODGE','WEBFORT','WUMT','WUMTAPP','ZHONGCHY','ZYAN',
                 'PKOIPARA')
 AND object_type='TABLE' AND owner NOT IN ('ANONYMOUS','APEX_PUBLIC_USER','CTXSYS','DBSNMP','DIP','EXFSYS','EXPBKUPS','FLOWS_030000','FLOWS_FILES','MDDATA','MDSYS','MGMT_VIEW','OLAPSYS','OPS$ORACLE','ORACLE_OCM','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','RMAN','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY','WKSYS','WK_TEST','WMSYS','XDB','XS$NULL')               
 AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')


SELECT owner, object_name 
FROM dba_objects@qadb_old
WHERE owner IN ('AANSARI','ACH','ACM','ACM6000','ADUTTA','AINAMDAR','AKATHWATE','ASATYAMURTI','AVOHRA','BPATIL','BSAGER','BUCHHOLD','CASHCARD','CBUTZKE','CHECKCASH',
                 'CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','DCHANEZ','DCURRIER','DGANGAM','DGOTE','DJOSHI','DSHAH','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC',
                 'ETLUPDATEGW','FANSARI','FHO','FNB_DBA','GOPAY_PORTAL','HALVERSR','HOLLANDR','HYADAV','IDNOX','INVENTORY','INVENTORY2','JBETHI','JDECKER','JLAYANI','JMURUGAN',
                 'KDIGRASE','KEYNOX_FX','KLY','KMAHAJAN','KRISHNA','KSINGH','LEBLANCE','MBADHE','MBIRADAR','MDESALE','MDUVAL','MERGECUSTCODE','MERLEV','MONIDEEPAROY',
                 'MWITTKE','NCHAVDA','NDOSHI','NITESHA','NKUMAR','NMOHANTY','NRANE','OFAC_ADAPTER','OPS$ORACLE','PAYFUSEQA','PAYFUSEUAT','PPANDEY','PSRIDHAR','QCAPP','QCMGR',
                 'QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','QYIN',
                 'RCHAUDHARI','REALTIMERPT','RHALVERSON','RKANTI','ROMANWAR','RRAGHAV','RSHIWALKAR','RTUSCHER','SAGRAWAL','SAQIB','SGADEWAR','SGAYAM','SKHANDAGLE','SKUMBHARE',
                 'SMACHA','SMAKINENI','SMALIK','SMEGERI','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS',
                 'SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532',
                 'SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103',
                 'SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523',
                 'SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532',
                 'SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_PART',
                 'SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194',
                 'SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT',
                 'SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115',
                 'SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SSAXENA','SSURYAVANSHI','STUJARE','SYS','SYSTEM','TERRYW','THIGEL',
                 'TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104',
                 'TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524',
                 'TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533',
                 'TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_PART','TNOXPASS_SMSNOX_20176',
                 'TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195',
                 'TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301',
                 'TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012',
                 'TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ',
                 'TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL',
                 'TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY',
                 'TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE',
                 'TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT',
                 'TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','UACHANTA','UMAHAJAN','USAP_ADAPTER','VBANNELA','VBOROLE','VCEP','VCHANDA','VCTP_FIRE',
                 'VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','VNGO','VZODGE','WEBFORT','WUMT','WUMTAPP','ZHONGCHY','ZYAN',
                 'PKOIPARA')
 AND object_type='SYNONYM' AND owner NOT IN ('ANONYMOUS','APEX_PUBLIC_USER','CTXSYS','DBSNMP','DIP','EXFSYS','EXPBKUPS','FLOWS_030000','FLOWS_FILES','MDDATA','MDSYS','MGMT_VIEW','OLAPSYS','OPS$ORACLE','ORACLE_OCM','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','RMAN','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY','WKSYS','WK_TEST','WMSYS','XDB','XS$NULL')           
 AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
MINUS 
SELECT owner, object_name 
FROM dba_objects
WHERE owner IN ('AANSARI','ACH','ACM','ACM6000','ADUTTA','AINAMDAR','AKATHWATE','ASATYAMURTI','AVOHRA','BPATIL','BSAGER','BUCHHOLD','CASHCARD','CBUTZKE','CHECKCASH',
                 'CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','DCHANEZ','DCURRIER','DGANGAM','DGOTE','DJOSHI','DSHAH','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC',
                 'ETLUPDATEGW','FANSARI','FHO','FNB_DBA','GOPAY_PORTAL','HALVERSR','HOLLANDR','HYADAV','IDNOX','INVENTORY','INVENTORY2','JBETHI','JDECKER','JLAYANI','JMURUGAN',
                 'KDIGRASE','KEYNOX_FX','KLY','KMAHAJAN','KRISHNA','KSINGH','LEBLANCE','MBADHE','MBIRADAR','MDESALE','MDUVAL','MERGECUSTCODE','MERLEV','MONIDEEPAROY',
                 'MWITTKE','NCHAVDA','NDOSHI','NITESHA','NKUMAR','NMOHANTY','NRANE','OFAC_ADAPTER','OPS$ORACLE','PAYFUSEQA','PAYFUSEUAT','PPANDEY','PSRIDHAR','QCAPP','QCMGR',
                 'QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','QYIN',
                 'RCHAUDHARI','REALTIMERPT','RHALVERSON','RKANTI','ROMANWAR','RRAGHAV','RSHIWALKAR','RTUSCHER','SAGRAWAL','SAQIB','SGADEWAR','SGAYAM','SKHANDAGLE','SKUMBHARE',
                 'SMACHA','SMAKINENI','SMALIK','SMEGERI','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS',
                 'SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532',
                 'SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103',
                 'SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523',
                 'SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532',
                 'SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_PART',
                 'SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194',
                 'SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT',
                 'SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115',
                 'SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SSAXENA','SSURYAVANSHI','STUJARE','SYS','SYSTEM','TERRYW','THIGEL',
                 'TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104',
                 'TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524',
                 'TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533',
                 'TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_PART','TNOXPASS_SMSNOX_20176',
                 'TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195',
                 'TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301',
                 'TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012',
                 'TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ',
                 'TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL',
                 'TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY',
                 'TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE',
                 'TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT',
                 'TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','UACHANTA','UMAHAJAN','USAP_ADAPTER','VBANNELA','VBOROLE','VCEP','VCHANDA','VCTP_FIRE',
                 'VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','VNGO','VZODGE','WEBFORT','WUMT','WUMTAPP','ZHONGCHY','ZYAN',
                 'PKOIPARA')
 AND object_type='SYNONYM' AND owner NOT IN ('ANONYMOUS','APEX_PUBLIC_USER','CTXSYS','DBSNMP','DIP','EXFSYS','EXPBKUPS','FLOWS_030000','FLOWS_FILES','MDDATA','MDSYS','MGMT_VIEW','OLAPSYS','OPS$ORACLE','ORACLE_OCM','ORDPLUGINS','ORDSYS','OUTLN','OWBSYS','RMAN','SCOTT','SI_INFORMTN_SCHEMA','SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYS','SYSMAN','SYSTEM','TSMSYS','WKPROXY','WKSYS','WK_TEST','WMSYS','XDB','XS$NULL')               
 AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')


('AANSARI','ACH','ACM','ACM6000','ADUTTA','AINAMDAR','AKATHWATE','ASATYAMURTI','AVOHRA','BPATIL','BSAGER','BUCHHOLD','CASHCARD','CBUTZKE','CHECKCASH',
 'CHECKCASHAPP','DATA_GENERATOR','DATA_UPLOAD','DBHOSALE','DCHANEZ','DCURRIER','DGANGAM','DGOTE','DJOSHI','DSHAH','ETLMONERIS','ETLUPDATE','ETLUPDATEBASIC',
 'ETLUPDATEGW','FANSARI','FHO','FNB_DBA','GOPAY_PORTAL','HALVERSR','HOLLANDR','HYADAV','IDNOX','INVENTORY','INVENTORY2','JBETHI','JDECKER','JLAYANI','JMURUGAN',
 'KDIGRASE','KEYNOX_FX','KLY','KMAHAJAN','KRISHNA','KSINGH','LEBLANCE','MBADHE','MBIRADAR','MDESALE','MDUVAL','MERGECUSTCODE','MERLEV','MONIDEEPAROY',
 'MWITTKE','NCHAVDA','NDOSHI','NITESHA','NKUMAR','NMOHANTY','NRANE','OFAC_ADAPTER','OPS$ORACLE','PAYFUSEQA','PAYFUSEUAT','PPANDEY','PSRIDHAR','QCAPP','QCMGR',
 'QCMGR_APP','QCP','QCPAPP','QCPMGR','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCEAPP','QPLAY','QRACM','QRQCP','QUIKADVANCE','QUIKADVANCE_APP','QYIN',
 'RCHAUDHARI','REALTIMERPT','RHALVERSON','RKANTI','ROMANWAR','RRAGHAV','RSHIWALKAR','RTUSCHER','SAGRAWAL','SAQIB','SGADEWAR','SGAYAM','SKHANDAGLE','SKUMBHARE',
 'SMACHA','SMAKINENI','SMALIK','SMEGERI','SNOX','SNOX_GCA_00510','SNOX_GCA_0058','SNOX_GCA_0059','SNOX_USBANK','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS',
 'SNOX4TRANSNOX_CPASS_PARTITION','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00532',
 'SNOX4TRANSNOX_UID_00535','SNOX4TRANSNOX_WUCC','SNOXDEVICES','SNOXGCA_91X_20101','SNOXGCA_91X_20101P','SNOXGCA_91X_20102','SNOXGCA_91X_20103',
 'SNOXGCA_91X_20104','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520','SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523',
 'SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528','SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532',
 'SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_PART',
 'SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189','SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194',
 'SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199','SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT',
 'SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT','SNOXPASS_TFE_20115',
 'SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','SSAXENA','SSURYAVANSHI','STUJARE','SYS','SYSTEM','TERRYW','THIGEL',
 'TNOX_GCA_00510','TNOX_GCA_0058','TNOX_GCA_0059','TNOXGCA_91X_20101','TNOXGCA_91X_20101P','TNOXGCA_91X_20102','TNOXGCA_91X_20103','TNOXGCA_91X_20104',
 'TNOXPASS_GWAY_00515','TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524',
 'TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532','TNOXPASS_GWAY_00533',
 'TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_PART','TNOXPASS_SMSNOX_20176',
 'TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195',
 'TNOXPASS_SMSNOX_20197','TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301',
 'TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012',
 'TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSBASIC','TRANSBASICAPP','TRANSCAPITALONE','TRANSCAPITALONEAPP','TRANSCAPONE_PROD_PARALLEL','TRANSDEMOACQ',
 'TRANSDEMOACQAPP','TRANSGCA','TRANSGCA_PROD_PARALLEL','TRANSGCAAPP','TRANSGCAUPLOADER','TRANSHMS','TRANSHMSAPP','TRANSMONERIS','TRANSMONERIS_PROD_PARALLEL',
 'TRANSMONERISAPP','TRANSMSN','TRANSMSNAPP','TRANSNOX_CAT','TRANSNOX_CPASS','TRANSNOX_CPASS_PARTITION','TRANSNOX_CPASS_UAT','TRANSNOX_GCA','TRANSNOX_GLORY',
 'TRANSNOX_RECON','TRANSNOX_SSA','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00532','TRANSNOX_UID_00535','TRANSNOX_WM','TRANSNOX_WU','TRANSSIGUE',
 'TRANSSIGUE_PROD_PARALLEL','TRANSSIGUEAPP','TRANSSUPER','TRANSSUPERAPP','TRANSTSYSBPOAPP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGW_UAT',
 'TRANSTSYSPAYMENTGWAPP','TRANSTSYSPGW_PROD_PARALLEL','TSNOX_USBANK','UACHANTA','UMAHAJAN','USAP_ADAPTER','VBANNELA','VBOROLE','VCEP','VCHANDA','VCTP_FIRE',
 'VCTP_RPT','VCTPBAK','VERIBIOMETRICS','VERICENTRE','VERICENTRE_NEW','VERICENTRE_OLD','VERIZON_QA','VNGO','VZODGE','WEBFORT','WUMT','WUMTAPP','ZHONGCHY','ZYAN',
 'PKOIPARA')




create table rchaudhari.grand_n_synonym as
SELECT 'GRANT '||WM_CONCAT(PRIVILEGE)||' ON '||grantor||'.'||table_name||' TO '||grantee||';' grant_n_synonym
FROM dba_tab_privs
WHERE owner  IN('SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00530',
                'SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520',
                'SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528',
                'SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_0059',
                'SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_SMSNOX_20170','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189',
                'SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199',
                'SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT',
                'SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515',
                'TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532',
                'TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_0059','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_SMSNOX_20170','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197',
                'TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSNOX_CAT','TRANSNOX_CPASS',
                'TRANSNOX_CPASS_UAT','TRANSNOX_IOX','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00530','TRANSNOX_UID_00532','TRANSNOX_UID_00535')
GROUP BY grantor,table_name,grantee
UNION ALL
SELECT 'create or replace synonym '||owner||'.'||synonym_name||' for '||table_owner||'.'||table_name||';' grant_n_synonym
FROM dba_synonyms
WHERE table_owner IN ('SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00530',
                'SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520',
                'SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528',
                'SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_0059',
                'SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_SMSNOX_20170','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189',
                'SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199',
                'SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT',
                'SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515',
                'TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532',
                'TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_0059','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_SMSNOX_20170','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197',
                'TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSNOX_CAT','TRANSNOX_CPASS',
                'TRANSNOX_CPASS_UAT','TRANSNOX_IOX','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00530','TRANSNOX_UID_00532','TRANSNOX_UID_00535')
AND owner<>'PUBLIC'; 



--30APR2013 ---END
----*******************************************-------



----*******************************************-------


mysqlcheck --repair --all-databases

SELECT TABLE_SCHEMA, TABLE_NAME, CONCAT(ROUND(data_length / ( 1024 * 1024 ), 2), 'MB') DATA, CONCAT(ROUND(data_free  / ( 1024 * 1024 ), 2), 'MB')FREE 
from information_schema.TABLES 
where TABLE_SCHEMA IN ('dotproject') and Data_free < 0;
----*******************************************-------
-- 05Apr2013 -- Start



SELECT TXNTYPE, MAX(LAST_UPDATE), COUNT(*) FROM QCP.COMPLETED_TRANSACTIONS
GROUP BY TXNTYPE



SELECT TO_CHAR(LAST_UPDATE,'mm/dd/yyyy'), COUNT(*)
FROM QCP.COMPLETED_TRANSACTIONS
WHERE LAST_UPDATE >= TO_DATE('04/02/2013 02:09:29','mm/dd/yyyy hh24:mi:ss')
  AND TXNTYPE='CHKC'
GROUP BY TO_CHAR(LAST_UPDATE,'mm/dd/yyyy')
ORDER BY TO_DATE(TO_CHAR(LAST_UPDATE,'mm/dd/yyyy'),'mm/dd/yyyy') DESC

-- 05Apr2013 -- Start
----*******************************************-------





----*******************************************-------
-- 04Apr2013 -- Start



IP Address:10.100.226.221
Host Name: wdl2tsysdbs02.tsysacquiring.org
SID: devdb.tsysacquiring.org

10.132.13.221 wdl2tsysdbs02.tsysacquiring.org
10.132.13.222 wdl2tsysdbs03.tsysacquiring.org


devreportdb


expdp rchaudhari@devdb directory=dpump dumpfile=expdp_snoxcpass.dmp logfile=expdp_snoxcpass.log schemas=snox4transnox_cpass,transnox_cpass,snoxpass_gway_007,tnoxpass_gway_007 exclude=statistics content=metadata_only compression=all
 
 impdp rchaudhari@devreportdb directory=dpump dumpfile=expdp_snoxcpass_dataonly.dmp logfile=impdp_expdp_snoxcpass_dataonly.log remap_schema=snox4transnox_cpass:snox4transnox_cpass remap_schema=transnox_cpass:transnox_cpass remap_schema=snoxpass_gway_007:snoxpass_gway_007 remap_schema=tnoxpass_gway_007:tnoxpass_gway_007 remap_tablespace=cpass_data_tbls:cpass_data_tbls_rpt remap_tablespace=cpass_indx_tbls:cpass_indx_tbls_rpt
 
 
 
'CALLNOX_DATA_LOB','CALLNOX_DATA_TEXT','CALLNOX_PROCESS_ATTEMPTS','CALLNOX_RESPONSE','DAILY_SETTLEMENT_FILE','EAN_SETTLEMENT_BILLC','EAN_SETTLEMENT_CHECK','EAN_SETTLEMENT_CHECK_TOCARD','EAN_SETTLEMENT_CPK_MTT','EAN_SETTLEMENT_ENROLL','EAN_SETTLEMENT_GIFT','HARMONY_SETTLEMENT_LINE_DET','HARMONY_SETTLEMENT_TAD_DET','HARMONY_SETTLEMENT_TRANS_DET','ICL_SETTLEMENT','ICL_SETTLEMENT_FILE','LOOKUP_SETTLEMENT_STATUS','SETTLEMENT_BATCH_INFO','SETTLEMENT_DEVICE_INFO','SNOX_SETTLEMENT_BATCH','TASK','TASK_TIME_LOG','TAS_SETTLEMENT_HISTORY','TRANSACTION','TRANSACTION_FEE_DETAIL','TRANSACTION_MESSAGE','TRANSACTION_OVERRIDE','TRANS_ADDITIONAL_AMOUNT_TYPE','TRANS_ADDITIONAL_INFO','TRANS_ATM','TRANS_BANK_DETAIL','TRANS_BANK_DETAIL_HISTORY','TRANS_BILLING_ADDRESS','TRANS_BILL_PAY','TRANS_BILL_PAY_HISTORY','TRANS_BILL_PAY_PARAMS','TRANS_BIOMETRIC_VECTOR','TRANS_CARD','TRANS_CARD_HISTORY','TRANS_CASH','TRANS_CASH_DETAILS','TRANS_CCCA','TRANS_CHECK','TRANS_CHECK_CASHING','TRANS_CHECK_CLEAR_AMOUNT','TRANS_CHECK_DEPOSITE','TRANS_CHECK_HISTORY','TRANS_CHECK_IMAGE','TRANS_CHECK_IMAGES','TRANS_CHECK_RETURN','TRANS_CLOSEBATCH','TRANS_COMPLIANCE_INFO','TRANS_COUPONS','TRANS_CREDIT_CLEAR_CHECK','TRANS_CUST_FINGERPRINT','TRANS_CUST_ID_IMAGES','TRANS_CUST_IMAGE','TRANS_CUST_PICTURE','TRANS_DEPOSIT','TRANS_DETAIL','TRANS_ENHANCED_DATA','TRANS_EXCEPTION_CHECK','TRANS_FEE_DETAIL','TRANS_IMAGE','TRANS_LODGING_INFO','TRANS_MONEY_ORDER','TRANS_MONEY_TRANSFER','TRANS_MONEY_TRANSFER_HISTORY','TRANS_OFFICIAL_CHECK','TRANS_PAYEE','TRANS_PAYEE_HISTORY','TRANS_PAYEE_IMAGE','TRANS_PAYMODE','TRANS_PAYROLL','TRANS_PAYROLL_HISTORY','TRANS_PERIPHERAL_STATUS','TRANS_PRODUCT_INFO','TRANS_PRODUCT_INFO_BKP','TRANS_PRODUCT_INFO_HIST','TRANS_PROMOTIONS','TRANS_REPRINT','TRANS_RESPONSE_INFO','TRANS_RETRIEVE','TRANS_RETURN','TRANS_SCORE','TRANS_SETTLEMENT','TRANS_SETTLT','TRANS_SHIPPING_ADDRESS','TRANS_SHIPPING_INFO','TRANS_SIGNATURE','TRANS_SIGNATURE_HISTORY','TRANS_STATUS_HISTORY','TRANS_SUPERVISOR_OVERRIDE','TRANS_TAX_DETAIL','TRANS_TRANSFER','TRANS_VOID'



cpass_data_tbls_rpt
cpass_indx_tbls_rpt


-- 04Apr2013 -- End
----*******************************************-------


----*******************************************-------
-- 03Apr2013

Insert into SNOX4TRANSNOX.FEE_RATE
   (RATE_CODE, DATE_CREATED, DATE_MODIFIED, BIN_FROM, PERCENT_FEE, FIXED_AMOUNT, MINIMUM_AMOUNT, DEVICE_ID)
 Values
   ('ATM_101', TO_DATE('03/28/2013 16:29:07', 'MM/DD/YYYY HH24:MI:SS'), TO_DATE('03/28/2013 16:29:07', 'MM/DD/YYYY HH24:MI:SS'), 10000, 0, 550, 0, 'R002FLGE');

COMMIT;



edus_in@oracle.com


/dev/asmdisk1
/dev/asmdisk2


CREATE DISKGROUP DATA NORMAL REDUNDANCY FAILGROUP controller1 DISK '/dev/asmdisk1', '/dev/asmdisk2'

-- Transaction by Summary
'WITH aeiou AS (select /*+ Ordered */ ltt.DESCRIPTION "Transaction_Type",COUNT(DISTINCT xtn.DEVICE_ID) "Transacting_Device",adev.ACTIVE_DEVICES "Active_Device",TRUNC(SUM(CASE WHEN xtn.TRANS_STATUS = ''APPROVED'' THEN 1 ELSE 0 END)/COUNT(DISTINCT xtn.device_ID ),2) "Avg_App_Transaction_Per_Device",SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN 1 ELSE 0 END) "Approved_Count",(SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN xtn.AMOUNT ELSE 0 END))/100 "Approved_Amount",(SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN xtn.FEE_CHARGED ELSE 0 END))/100 "Approved_Fee",(ROUND (SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN xtn.AMOUNT ELSE 0 END) / DECODE (SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN 1 ELSE 0 END), 0, 1, SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN 1 ELSE 0 END)) ))/100 "Approved_Average_Amount",SUM(CASE WHEN xtn.TRANS_STATUS = ''VOID'' THEN 1 ELSE 0 END) "Void_Count",SUM(case when xtn.TRANS_STATUS = ''CANCEL'' THEN 1 ELSE 0 END) "Cancel_Count",SUM(case when xtn.TRANS_STATUS = ''DECLINE'' THEN 1 ELSE 0 END) "Declined_Count",SUM(case when xtn.TRANS_STATUS IN (''INCOMPLETE'',''NEW'') THEN 1 ELSE 0 END) "Incomplete_Count",SUM(case when xtn.TRANS_STATUS = ''DEVICE_ERROR'' THEN 1 ELSE 0 END) "Device_Error_Count",SUM(CASE WHEN xtn.TRANS_STATUS IN (''SCREEN_TIME_OUT'' ,''SCREEN_TIMEOUT'' ) THEN 1 ELSE 0 END) "Screen_TimeOut_Count",SUM(case when xtn.TRANS_STATUS = ''HOST_TIME_OUT'' THEN 1 ELSE 0 END) "Host_TimeOut_Count",SUM(case when xtn.TRANS_STATUS IN (''APPROVED'',''DECLINE'',''VOID'',''CANCEL'',''INCOMPLETE'',''HOST_TIME_OUT'',''SCREEN_TIME_OUT'',''SCREEN_TIMEOUT'',''DEVICE_ERROR'',''NEW'') THEN 1 ELSE 0 END) "Total_Count",xtn.TRANS_TYPE "Trans_Type",ltt.TASK_TYPE "Code"  from TRANSACTION xtn,LOOKUP_TRANS_TYPE ltt,DEVICE dev,MERCHANT mer,CORPORATION corp,(SELECT company_code, COUNT(DEVICE_ID) Active_Devices FROM DEVICE d,MERCHANT m, CORPORATION c WHERE d.MERCHANT_ID=m.MERCHANT_ID AND m.CORPORATION_ID = c.CORPORATION_ID AND c.COMPANY_CODE = ''GCA'' AND d.DEVICE_STATUS=''E'' group by company_code) adev  where  xtn.TRANS_TYPE=ltt.CODE  and  xtn.DEVICE_ID=dev.DEVICE_ID  and  dev.MERCHANT_ID=mer.MERCHANT_ID  and  xtn.TIME_STAMP  between to_date(''02-28-2013 00:00:00'', ''mm-dd-yyyy hh24:mi:ss'')  and to_date(''03-31-2013 23:59:59'', ''mm-dd-yyyy hh24:mi:ss'')   and  mer.CORPORATION_ID = corp.CORPORATION_ID  and  ltt.TASK_TYPE <> ''ADM''  and  ltt.TRANS_OP_TYPE=''F''  and  trim(mer.MERCHANT_ID) like ''%''  and  mer.CORPORATION_ID = ''100800''  and corp.COMPANY_CODE = ''GCA''   group by ltt.DESCRIPTION, xtn.TRANS_TYPE, ltt.TASK_TYPE,corp.COMPANY_CODE,adev.ACTIVE_DEVICES order by ltt.DESCRIPTION ) SELECT ROWNUM SR_NR, aeiou.* from dual, aeiou'




DECLARE 
  P_QUERYSTRING VARCHAR2(32767);
  P_MAXNOOFTRANS NUMBER;
  P_TABLENAME VARCHAR2(32767);
  P_ATUALNOOFRECORDS NUMBER;
  P_OUTPUTSTATUS NUMBER;
  P_OUTPUTMESSAGE VARCHAR2(32767);
BEGIN 
  P_QUERYSTRING := 'WITH aeiou AS (select /*+ Ordered */ ltt.DESCRIPTION "Transaction_Type",COUNT(DISTINCT xtn.DEVICE_ID) "Transacting_Device",adev.ACTIVE_DEVICES "Active_Device",TRUNC(SUM(CASE WHEN xtn.TRANS_STATUS = ''APPROVED'' THEN 1 ELSE 0 END)/COUNT(DISTINCT xtn.device_ID ),2) "Avg_App_Transaction_Per_Device",SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN 1 ELSE 0 END) "Approved_Count",(SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN xtn.AMOUNT ELSE 0 END))/100 "Approved_Amount",(SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN xtn.FEE_CHARGED ELSE 0 END))/100 "Approved_Fee",(ROUND (SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN xtn.AMOUNT ELSE 0 END) / DECODE (SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN 1 ELSE 0 END), 0, 1, SUM(case when xtn.TRANS_STATUS = ''APPROVED'' THEN 1 ELSE 0 END)) ))/100 "Approved_Average_Amount",SUM(CASE WHEN xtn.TRANS_STATUS = ''VOID'' THEN 1 ELSE 0 END) "Void_Count",SUM(case when xtn.TRANS_STATUS = ''CANCEL'' THEN 1 ELSE 0 END) "Cancel_Count",SUM(case when xtn.TRANS_STATUS = ''DECLINE'' THEN 1 ELSE 0 END) "Declined_Count",SUM(case when xtn.TRANS_STATUS IN (''INCOMPLETE'',''NEW'') THEN 1 ELSE 0 END) "Incomplete_Count",SUM(case when xtn.TRANS_STATUS = ''DEVICE_ERROR'' THEN 1 ELSE 0 END) "Device_Error_Count",SUM(CASE WHEN xtn.TRANS_STATUS IN (''SCREEN_TIME_OUT'' ,''SCREEN_TIMEOUT'' ) THEN 1 ELSE 0 END) "Screen_TimeOut_Count",SUM(case when xtn.TRANS_STATUS = ''HOST_TIME_OUT'' THEN 1 ELSE 0 END) "Host_TimeOut_Count",SUM(case when xtn.TRANS_STATUS IN (''APPROVED'',''DECLINE'',''VOID'',''CANCEL'',''INCOMPLETE'',''HOST_TIME_OUT'',''SCREEN_TIME_OUT'',''SCREEN_TIMEOUT'',''DEVICE_ERROR'',''NEW'') THEN 1 ELSE 0 END) "Total_Count",xtn.TRANS_TYPE "Trans_Type",ltt.TASK_TYPE "Code"  from TRANSACTION xtn,LOOKUP_TRANS_TYPE ltt,DEVICE dev,MERCHANT mer,CORPORATION corp,(SELECT company_code, COUNT(DEVICE_ID) Active_Devices FROM DEVICE d,MERCHANT m, CORPORATION c WHERE d.MERCHANT_ID=m.MERCHANT_ID AND m.CORPORATION_ID = c.CORPORATION_ID AND c.COMPANY_CODE = ''GCA'' AND d.DEVICE_STATUS=''E'' group by company_code) adev  where  xtn.TRANS_TYPE=ltt.CODE  and  xtn.DEVICE_ID=dev.DEVICE_ID  and  dev.MERCHANT_ID=mer.MERCHANT_ID  and  xtn.TIME_STAMP  between to_date(''02-28-2013 00:00:00'', ''mm-dd-yyyy hh24:mi:ss'')  and to_date(''03-31-2013 23:59:59'', ''mm-dd-yyyy hh24:mi:ss'')   and  mer.CORPORATION_ID = corp.CORPORATION_ID  and  ltt.TASK_TYPE <> ''ADM''  and  ltt.TRANS_OP_TYPE=''F''  and  trim(mer.MERCHANT_ID) like ''%''  and  mer.CORPORATION_ID = ''100800''  and corp.COMPANY_CODE = ''GCA''   group by ltt.DESCRIPTION, xtn.TRANS_TYPE, ltt.TASK_TYPE,corp.COMPANY_CODE,adev.ACTIVE_DEVICES order by ltt.DESCRIPTION ) SELECT ROWNUM SR_NR, aeiou.* from dual, aeiou';
  P_MAXNOOFTRANS := NULL;
  P_TABLENAME := NULL;
  P_ATUALNOOFRECORDS := NULL;
  P_OUTPUTSTATUS := NULL;
  P_OUTPUTMESSAGE := NULL;
  TRANSNOX_GCA.GENERATE_TABLE ( P_QUERYSTRING, P_MAXNOOFTRANS, P_TABLENAME, P_ATUALNOOFRECORDS, P_OUTPUTSTATUS, P_OUTPUTMESSAGE );
  COMMIT; 
END; 
/


----*******************************************-------




ALTER TABLE SNOX4TRANSNOX_GCA.MERCHANT ADD (
  CONSTRAINT FK_MERCHANT_REFERENCE_LOOKUP_C 
  FOREIGN KEY (COUNTRY_CODE) 
  REFERENCES SNOX4TRANSNOX_GCA.LOOKUP_COUNTRY (CODE));

ALTER TABLE SNOX4TRANSNOX_GCA.MERCHANT ADD (
  CONSTRAINT FK_MERCHANT_REF_LOOKUP_M 
  FOREIGN KEY (MERCHANT_STATUS) 
  REFERENCES SNOX4TRANSNOX_GCA.LOOKUP_MERCHANT_STATUS (CODE)  DISABLE);

ALTER TABLE SNOX4TRANSNOX_GCA.MERCHANT ADD (
  CONSTRAINT FK_MERCHANT_REF_LOOKUP_S 
  FOREIGN KEY (STATE_CODE, COUNTRY_CODE) 
  REFERENCES SNOX4TRANSNOX_GCA.LOOKUP_STATE_PROVINCE (CODE,COUNTRY_CODE)  DISABLE);

ALTER TABLE SNOX4TRANSNOX_GCA.MERCHANT ADD (
  CONSTRAINT FK_MERCHANT_REF_LOOK_M1 
  FOREIGN KEY (BUSINESS_TYPE) 
  REFERENCES SNOX4TRANSNOX_GCA.LOOKUP_MER_BUSINESS_TYPE (CODE)  DISABLE);




--
expdp rchaudhari@devdb directory=dpump dumpfile=expdp_gca_n_tsysuser_data.dmp logfile=expdp_gca_n_tsysuser_data.log schemas=acm,acm6000,ainamdar,akathwate,apatil,asatyamurti,atulj,bm_snox_vbs,bm_tnox_vbs,checkcash,checkcashapp,dbhosale,dcurrier,dmuley,expbkups,histevent_obj,idnox,inventory2,jmurugan,keynox,keynox_fx,mbadhe,merge_customer,monideeparoy,mtujare,nbajwa,nitesha,ofac,ofac_adapter,payusea,qcp,qcpmgr,qcredit,qfcs,qfund,qplay,qracm,qrqcp,quikadvance,rchaudhari,realtimerpt,repl,repl_tri,rman,romanwar,rshiwalkar,schauhan,shuvrod,skhandagale,skumbhare,smalik,snox,snoxdevices,src_c_repl,ssuryavanshi,stujare,usap_adapter,veerab,veribiometrics,verizon,wumt exclude=statistics exclude=statistics,TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\"  data_options=xml_clobs reuse_dumpfiles=y compression=all parallel=4


USER
SYSTEM_GRANT
ROLE_GRANT
DEFAULT_ROLE


impdp rchaudhari@devdb directory=dpump dumpfile=expdp_gca_n_tsysuser_data.dmp logfile=impdp_expdp_gca_n_tsysuser_data.log exclude=schema:\"=\'RCHAUDHARI\'\" remap_tablespace=indx:gca_indx_tbls remap_tablespace=transit_data_part:gca_data_tbls remap_tablespace=trans_data:gca_data_tbls remap_tablespace=trans_index:gca_indx_tbls remap_tablespace=tsys_empl_tbs:tsys_empl_tbls remap_tablespace=users:gca_data_tbls

impdp rchaudhari@devdb directory=dpump dumpfile=expdp_gca_n_tsysuser_data.dmp logfile=impdp_expdp_gca_n_tsysuser_data.log remap_schema=acm:acm remap_schema=acm6000:acm6000 remap_schema=ainamdar:ainamdar remap_schema=akathwate:akathwate remap_schema=apatil:apatil remap_schema=asatyamurti:asatyamurti remap_schema=atulj:atulj remap_schema=bm_snox_vbs:bm_snox_vbs remap_schema=bm_tnox_vbs:bm_tnox_vbs remap_schema=checkcash:checkcash remap_schema=checkcashapp:checkcashapp remap_schema=dbhosale:dbhosale remap_schema=dcurrier:dcurrier remap_schema=dmuley:dmuley remap_schema=expbkups:expbkups remap_schema=histevent_obj:histevent_obj remap_schema=idnox:idnox remap_schema=inventory2:inventory2 remap_schema=jmurugan:jmurugan remap_schema=keynox:keynox remap_schema=keynox_fx:keynox_fx remap_schema=mbadhe:mbadhe remap_schema=merge_customer:merge_customer remap_schema=monideeparoy:monideeparoy remap_schema=mtujare:mtujare remap_schema=nbajwa:nbajwa remap_schema=nitesha:nitesha remap_schema=ofac:ofac remap_schema=ofac_adapter:ofac_adapter remap_schema=payusea:payusea remap_schema=qcp:qcp remap_schema=qcpmgr:qcpmgr remap_schema=qcredit:qcredit remap_schema=qfcs:qfcs remap_schema=qfund:qfund remap_schema=qplay:qplay remap_schema=qracm:qracm remap_schema=qrqcp:qrqcp remap_schema=quikadvance:quikadvance remap_schema=realtimerpt:realtimerpt remap_schema=repl:repl remap_schema=repl_tri:repl_tri remap_schema=rman:rman remap_schema=romanwar:romanwar remap_schema=rshiwalkar:rshiwalkar remap_schema=schauhan:schauhan remap_schema=shuvrod:shuvrod remap_schema=skhandagale:skhandagale remap_schema=skumbhare:skumbhare remap_schema=smalik:smalik remap_schema=snox:snox remap_schema=snoxdevices:snoxdevices remap_schema=src_c_repl:src_c_repl remap_schema=ssuryavanshi:ssuryavanshi remap_schema=stujare:stujare remap_schema=usap_adapter:usap_adapter remap_schema=veerab:veerab remap_schema=veribiometrics:veribiometrics remap_schema=verizon:verizon remap_schema=wumt:wumt remap_tablespace=indx:gca_indx_tbls remap_tablespace=transit_data_part:gca_data_tbls remap_tablespace=trans_data:gca_data_tbls remap_tablespace=trans_index:gca_indx_tbls remap_tablespace=tsys_empl_tbs:tsys_empl_tbls remap_tablespace=users:gca_data_tbls



DEVDB_ASM=
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.100.226.221)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=devdb.tsysacquiring.org)
    )
  )




---
13 30 * * * sh /oradata1/oracle/dumpfiles/devdb_bkup_scripts.sql

-- Take export on devdb.infonox.com devdb 
expdp rchaudhari@devdb directory=dpump dumpfile=expdp_gca_n_tsysuser_data.dmp logfile=expdp_gca_n_tsysuser_data.log network_link=devdb tables=snox4transnox.recon_file_config exclude=statistics data_options=xml_clobs reuse_dumpfiles=y

-- Transfer the export dumpfile to Oracle 11g R2

-- Once export dumpfile is transfered to Oracle 11G R2 DB server, Start importing....
impdp rchaudhari directory=bkup dumpfile=expdp_clob_data.dmp logfile=expdp_clob_data.log remap_schema=snox4transnox:rchaudhari exclude=index,constraint




expdp / directory=bkups dumpfile=expdp_devdb_bkups.dmp logfile=expdp_devdb_bkupslog.log network_link=devdb exclude=statistics,schema:\" in \(\'SYS\',\'SYSMAN\',\'SYSTEM\',\'ANONYMOUS\',\'APEX_PUBLIC_USER\',\'CTXSYS\',\'DIP\',\'EXFSYS\',\'FLOWS_030000\',\'FLOWS_FILES\',\'MDDATA\',\'MDSYS\',\'OLAPSYS\',\'ORACLE_OCM\',\'ORDPLUGINS\',\'ORDSYS\',\'OUTLN\',\'OWBSYS\',\'SCOTT\',\'SI_INFORMTN_SCHEMA\',\'SPATIAL_CSW_ADMIN_USR\',\'SPATIAL_WFS_ADMIN_USR\',\'TSMSYS\',\'WK_TEST\',\'WKPROXY\',\'WKSYS\',\'WMSYS\',\'XDB\',\'XS\$NULL\'\)\",TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\", TABLE:\"LIKE\'%PLAN_TABLE\'\"  content=all compression=all reuse_dumpfiles=y full=y

Assumptions : 

1. ASM Instance is already Created and Ready to Use. 

2. DB Instance was Started using �spfile� 

3. Disk Group Name : �+DGDATA�  

- Set the Parameter �db_create_file_dest� to �+DGDATA�  

alter system set db_create_file_dest=�+DGDATA� scope=spfile;

- Set the Parameter �control_file� to the destination in ASM

alter system set control_files=� scope=spfile;

 - Bounce/Open the Database with �NoMount� Clause
startup nomount

- Restore Control File from the Previous Destination
restore controlfile from �/u001/oracle/data/control001.ctl�;

- Mount the Database
alter database mount;

-Do the following :

backup as copy database format �+DGDATA�;

switch database to copy;

recover database;

alter database open;

alter tablespace TEMP add TEMPFILE;

alter database tempfile '/u001/oracle/data/temp001.dbf' drop; 


---- gives list which Index should be rebuild or not....
set serveroutput on size 100000

DECLARE
  vOwner   dba_indexes.owner%TYPE;            /* Index Owner            */
  vIdxName dba_indexes.index_name%TYPE;       /* Index Name             */
  vAnalyze VARCHAR2(100);                     /* String of Analyze Stmt */
  vCursor  NUMBER;                            /* DBMS_SQL cursor        */
  vNumRows INTEGER;                           /* DBMS_SQL return rows   */
  vHeight  index_stats.height%TYPE;           /* Height of index tree   */
  vLfRows  index_stats.lf_rows%TYPE;          /* Index Leaf Rows        */
  vDLfRows index_stats.del_lf_rows%TYPE;      /* Deleted Leaf Rows      */
  vDLfPerc   NUMBER;                          /* Del lf Percentage      */
  vMaxHeight NUMBER;                          /* Max tree height        */
  vMaxDel    NUMBER;                          /* Max del lf percentage  */
  CURSOR cGetIdx IS SELECT owner,index_name
     FROM dba_indexes WHERE OWNER NOT LIKE 'SYS%';
BEGIN
  /* Define maximums. This section can be customized. */
  vMaxHeight := 3;
  vMaxDel    := 20;

  /* For every index, validate structure */
  OPEN cGetIdx;
  LOOP
     FETCH cGetIdx INTO vOwner,vIdxName;
     EXIT WHEN cGetIdx%NOTFOUND;
     /* Open DBMS_SQL cursor */
     vCursor := DBMS_SQL.OPEN_CURSOR;
     /* Set up dynamic string to validate structure */
     vAnalyze := 'ANALYZE INDEX ' || vOwner || '.' || vIdxName || ' VALIDATE STRUCTURE';
     DBMS_SQL.PARSE(vCursor,vAnalyze,DBMS_SQL.V7);
     vNumRows := DBMS_SQL.EXECUTE(vCursor);
     /* Close DBMS_SQL cursor */
     DBMS_SQL.CLOSE_CURSOR(vCursor);
     /* Does index need rebuilding?  */
     /* If so, then generate command */
     SELECT height,lf_rows,del_lf_rows INTO vHeight,vLfRows,vDLfRows
        FROM INDEX_STATS;
     IF vDLfRows = 0 THEN         /* handle case where div by zero */
        vDLfPerc := 0;
     ELSE
        vDLfPerc := (vDLfRows / vLfRows) * 100;
     END IF;
     IF (vHeight > vMaxHeight) OR (vDLfPerc > vMaxDel) THEN
        DBMS_OUTPUT.PUT_LINE('ALTER INDEX ' || vOwner || '.' || vIdxName || ' REBUILD;');
     END IF;

  END LOOP;
  CLOSE cGetIdx;
END;
/



-- 25-JAN-2013 The export/expdp dump was passed to ICP Team--------------------------------------------------------------
transnox_gca.trans_card
transnox_gca.trans_check
transnox_gca.trans_bank_detail
transnox_gca.task
transnox_gca.trans_retrieve
transnox_gca.transaction
transnox_gca.trans_bank_detail
transnox_gca.trans_response_info
qcp.telechecktransactions
qcp.wsconfigurations


20SEP2012_31DEC2012

--expdp rchaudhari directory=ORADATA12 dumpfile=expdp_trans_card_20SEP2012_31DEC2012.dmp logfile=expdp_trans_card_20SEP2012_31DEC2012.log tables=transnox_gca.trans_card query=\"where timestamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all
--expdp rchaudhari directory=ORADATA12 dumpfile=expdp_trans_check_20SEP2012_31DEC2012.dmp logfile=expdp_trans_check_20SEP2012_31DEC2012.log tables=transnox_gca.trans_check query=\"where timestamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all
--expdp rchaudhari directory=ORADATA12 dumpfile=expdp_trans_bank_det_20SEP2012_31DEC2012.dmp logfile=expdp_trans_bank_det_20SEP2012_31DEC2012.log tables=transnox_gca.trans_bank_detail query=\"where timestamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all
--expdp rchaudhari directory=ORADATA12 dumpfile=expdp_task_20SEP2012_31DEC2012.dmp logfile=expdp_task_20SEP2012_31DEC2012.log tables=transnox_gca.task query=\"where time_stamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all
--expdp rchaudhari directory=ORADATA12 dumpfile=expdp_trans_retrieve_20SEP2012_31DEC2012.dmp logfile=expdp_trans_retrieve_20SEP2012_31DEC2012.log tables=transnox_gca.trans_retrieve query=\"where timestamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all
--expdp rchaudhari directory=ORADATA12 dumpfile=expdp_transaction_20SEP2012_31DEC2012.dmp logfile=expdp_transaction_20SEP2012_31DEC2012.log tables=transnox_gca.transaction query=\"where time_stamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all
expdp rchaudhari directory=ORADATA12 dumpfile=expdp_trans_response_info_20SEP2012_31DEC2012.dmp logfile=expdp_trans_response_info_20SEP2012_31DEC2012.log tables=transnox_gca.trans_response_info query=\"where tran_timestamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all

--qcp col_125
expdp rchaudhari directory=ORADATA2 dumpfile=expdp_telechecktransactions_20SEP2012_31DEC2012.dmp logfile=expdp_telechecktransactions_20SEP2012_31DEC2012.log tables=qcp.telechecktransactions query=\"where timestamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all

expdp rchaudhari directory=ORADATA2 dumpfile=expdp_wsconfigurations.dmp logfile=expdp_wsconfigurations.log tables=qcp.wsconfigurations exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all




expdp rchaudhari directory=ORADATA12 dumpfile=expdp_Device_N_Cust_tbls.dmp logfile=expdp_Device_N_Cust_tbls.log tables=transnox_gca.cust_address,transnox_gca.customer,transnox_gca.device_processor_info exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all

expdp rchaudhari directory=ORADATA12 dumpfile=expdp_Device_tbls.dmp logfile=expdp_Device_tbls.log tables=snox4transnox_gca.device exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all




expdp rchaudhari directory=ORADATA12 dumpfile=expdp_trans_detail_20SEP2012_31DEC2012.dmp logfile=expdp_trans_detail_20SEP2012_31DEC2012.log tables=transnox_gca.trans_detail query=\"where time_stamp between TO_DATE\(\'09\/20\/2012 00:00:00\',\'mm\/dd\/yyyy hh24:mi:ss\'\) AND TO_DATE\(\'12\/31\/2012 23:59:59\',\'mm\/dd\/yyyy hh24:mi:ss\'\)\" exclude=statistics,commnet,index,constraint,ref_constraint,grant,synonym,trigger compression=all


transnox_gca.trans_detail
transnox_gca.trans_paymode 




 expdp rchaudhari@col122 directory=oradata12 dumpfile=expdp_trans_detail_25092011_19092012.dmp logfile=expdp_trans_detail_25092011_19092012.log tables=transnox_gca.trans_detail_25092011_01082012,transnox_gca.trans_detail_02082012_19092012 exclude=statistics compression=all



expdp rchaudhari@col122 directory=oradata12 dumpfile=expdp_trans_paymode_25092011_19092012.dmp logfile=expdp_trans_paymode_25092011_19092012.log tables=transnox_gca.trans_paymode25092011_01082012,transnox_gca.trans_paymode02082012_19092012 exclude=statistics compression=all


expdp rchaudhari directory=ORADATA12 dumpfile=expdp_trans_paymode_20Sep12_31Dec12.dmp logfile=expdp_trans_paymode_20Sep12_31Dec12.log tables=rchaudhari.trans_paymode_20Sep12_31Dec12 compression=all


-- ASM Installation Dcoument
http://jpmrd.wordpress.com/2012/08/25/oracle-asm-step-by-step/

http://www.oracle-wiki.net/startdocshowtoinstalloracle11glinuxasm

https://10.50.4.134/7799/em


-- OLD OEM Production
https://oem.ifxga.com:7799/em/

-- Prod OEM 12c
https://10.150.50.100:7802/em


DECLARE
  X NUMBER;
  user_name varchar2(30);
BEGIN
  select user into user_name from dual;
  execute immediate 'alter session set current_schema = MERGECUSTCODE';
  BEGIN
    SYS.DBMS_JOB.SUBMIT
    ( job       => X 
     ,what      => 'DECLARE 
       a NUMBER; 
       b VARCHAR2(1000); 
BEGIN 
    Remindermail_Custcode_Merging(); 
END;   '
     ,next_date => to_date('16/07/2014 03:00:00','dd/mm/yyyy hh24:mi:ss')
     ,interval  => 'trunc(sysdate + 1) + 3/24'
     ,no_parse  => FALSE
    );
    SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
    execute immediate 'alter session set current_schema = ' || user_name ;
  EXCEPTION
    WHEN OTHERS THEN 
      execute immediate 'alter session set current_schema = ' || user_name ;
      RAISE;
  END;
  COMMIT;
END;
/


DECLARE
  X NUMBER;
  user_name varchar2(30);
BEGIN
  select user into user_name from dual;
  execute immediate 'alter session set current_schema = MERGECUSTCODE';
  BEGIN
    SYS.DBMS_JOB.SUBMIT
    ( job       => X 
     ,what      => 'DECLARE 
       a NUMBER; 
       b VARCHAR2(1000); 
BEGIN 
    P0(a,b); 
END;   '
     ,next_date => to_date('16/07/2014 04:00:00','dd/mm/yyyy hh24:mi:ss')
     ,interval  => 'trunc(sysdate + 1) + 4/24'
     ,no_parse  => FALSE
    );
    SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
    execute immediate 'alter session set current_schema = ' || user_name ;
  EXCEPTION
    WHEN OTHERS THEN 
      execute immediate 'alter session set current_schema = ' || user_name ;
      RAISE;
  END;
  COMMIT;
END;
/




select count(*) 
from MERGECUSTCODE.MERGING_CUSTOMERCODE 
where status='N'








sqlplus -s / as sysdba << eof
spool /home/oracle/mergecustcode_logs_16Jul2014.log
alter session set current_schema=MERGECUSTCODE;
DECLARE 
  O_OUTPUTSTATUS NUMBER;
  O_OUTPUTMESSAGE VARCHAR2(32767);
BEGIN 
  O_OUTPUTSTATUS := NULL;
  O_OUTPUTMESSAGE := NULL;
  MERGECUSTCODE.P0 ( O_OUTPUTSTATUS, O_OUTPUTMESSAGE );
  DBMS_OUTPUT.PUT_LINE('O_OUTPUTSTATUS = ' || TO_CHAR(O_OUTPUTSTATUS));
  DBMS_OUTPUT.PUT_LINE('O_OUTPUTMESSAGE = ' || O_OUTPUTMESSAGE);
  DBMS_OUTPUT.PUT_LINE('');
  COMMIT; 
END;
/
commit;
show errors;
spool off
eof



GRANT SELECT ANY TABLE, SELECT ANY DICTIONARY, DROP ANY TABLE, CREATE JOB TO MIS;

CREATE OR REPLACE PROCEDURE drop_sc_sn_temp_tables
AS
BEGIN 
    FOR i IN (SELECT owner, object_name FROM dba_objects
              WHERE REGEXP_LIKE(object_name,'S._TEMP[[:digit:]]','i')
                AND object_type='TABLE' AND created < SYSDATE-50/1440)
    LOOP
        DBMS_UTILITY.EXEC_DDL_STATEMENT('drop table '||i.owner||'.'||i.object_name||' purge');
    END LOOP;
END;
/

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( JOB       => X 
   ,what      => 'DECLARE 
                    A NUMBER;
                    B VARCHAR2(100);
                  BEGIN
                      DROP_SC_SN_TEMP_TABLES();
                      COMMIT; 
                  END; '
   ,next_date => TO_DATE('07/16/2014 11:00:00','mm/dd/yyyy hh24:mi:ss')
   ,INTERVAL  => 'TRUNC(SYSDATE+1) + 11/24'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(x));
COMMIT;
END;
/

BEGIN
sys.DBMS_IJOB.CHANGE_ENV
  ( 
     JOB => X, 
     LUSER => 'MIS', 
     PUSER => 'MIS',
    CUSER => 'MIS',
    NLSENV => 'NLS_LANGUAGE=''AMERICAN''
               NLS_TERRITORY=''AMERICA''
               NLS_CURRENCY=''$''
               NLS_ISO_CURRENCY=''AMERICA''
               NLS_NUMERIC_CHARACTERS=''.,''
               NLS_DATE_FORMAT=''DD-MON-RR''
               NLS_DATE_LANGUAGE=''AMERICAN''
               NLS_SORT=''BINARY''
              '); COMMIT;
END;
/




CREATE OR REPLACE PACKAGE TRANSITHA.Data_Center_Parameters AS
-- DCE Data Center Parameter  
  PROCEDURE DCE_CURRENT_PARAMS ;
  PROCEDURE DCE_upd_parameters ;

-- DCW Data Center Parameter  
  PROCEDURE DCw_CURRENT_PARAMS ;
  PROCEDURE DCW_upd_parameters ;
END Data_Center_Parameters;
/
 
CREATE OR REPLACE PACKAGE BODY TRANSITHA.Data_Center_Parameters AS

--  Current Parameters in DCE Data Center 
    PROCEDURE DCE_CURRENT_PARAMS
    AS
        o_OutPut_Message             VARCHAR2(32000) := NULL;
        v_Error_Flag                 NUMBER := 0;
        v_Max_Len_Table_Name_val     NUMBER := 0;
        v_Max_Len_Parameter_Name_val NUMBER := 0;
        v_Len_Table_Name             NUMBER := 0;
        v_Len_Param_Name             NUMBER := 0;
    BEGIN     
        o_OutPut_Message:=NULL;
        SELECT MAX(LENGTH(table_name))+4,
               MAX(LENGTH(UPPER(PARAMETER_NAME)))+4 
        INTO 
               v_Max_Len_Table_Name_val,
               v_Max_Len_Parameter_Name_val
        FROM TRANSITHA.APP_SERVER_PARAMETERS;
            
        FOR i IN (SELECT LENGTH(Table_Name) Len_Table_Name, Table_Name, UPPER(PARAMETER_NAME) PARAMETER_NAME, LENGTH(UPPER(PARAMETER_NAME)) Len_Param_Name, DCE_VALUES
                  FROM TRANSITHA.APP_SERVER_PARAMETERS)
        LOOP
            v_Len_Table_Name := v_Max_Len_Table_Name_val - i.Len_Table_Name ;
            v_Len_Param_Name := v_Max_Len_Parameter_Name_val - i.Len_Param_Name; 
            
            o_OutPut_Message := o_OutPut_Message || i.Table_Name||LPAD(CHR(32),v_Len_Table_Name)||i.PARAMETER_NAME||LPAD(CHR(32),v_Len_Param_Name)||i.DCE_VALUES ||CHR(13) ;
            v_Len_Table_Name:=NULL;
            v_Len_Param_Name:=NULL;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
    END DCE_CURRENT_PARAMS;        

--  Procedure call for DCE Data Center
    PROCEDURE DCE_upd_parameters
    AS
        o_OutPut_Message                VARCHAR2(500) := NULL;
        v_Error_Flag                    NUMBER :=0; -- initialize variable as 0 
        v_UPD_Sql_Query                 VARCHAR2(32000) := NULL; -- initialize variable as empty

        v_UPD_Sql_Query_Display         VARCHAR2(32000) := NULL; -- initialize variable as empty
    BEGIN 

        v_Error_Flag :=1;

--      loop the complete record list
        FOR i IN (SELECT SCHEMA_NAME, TABLE_NAME, SEARCH_COL_NAME1, SEARCH_COL_NAME2, 
                         UPD_COL_NAME, PARAMETER_NAME, DCE_VALUES 
                    FROM TRANSITHA.APP_SERVER_PARAMETERS)
        LOOP
            v_Error_Flag :=2;
--          update query for those records which are having single where conditions
            IF i.SEARCH_COL_NAME1 IS NOT NULL AND i.SEARCH_COL_NAME2 IS NULL AND i.TABLE_NAME <> 'PROCESSOR_CONFIGURATION'
                AND NOT (i.SCHEMA_NAME = 'TRANSTSYSPAYMENTGW' AND i.TABLE_NAME = 'DEPARTMENT_PARAMETERS') THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCE_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.DCE_VALUES ||'''' || CHR(13) ;
            END IF;

            v_Error_Flag :=3;
--          Parameter_name is different in search condition      
            IF (i.SCHEMA_NAME = 'TRANSTSYSPAYMENTGW' AND i.TABLE_NAME = 'DEPARTMENT_PARAMETERS') 
                OR ( i.SCHEMA_NAME = 'SNOX4TRANSNOX' AND i.TABLE_NAME = 'PROCESSOR_CONFIGURATION') THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCE_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.PARAMETER_NAME ||'''' || CHR(13) ;
            END IF;

            v_Error_Flag :=4;
--          Multiple Search condition columns
            IF i.SEARCH_COL_NAME1 IS NOT NULL AND i.SEARCH_COL_NAME2 IS NOT NULL THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCE_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.PARAMETER_NAME ||'''' || CHR(13) ||
                                   '   AND ' || i.SEARCH_COL_NAME2 || ' = ''' || i.DCE_VALUES ||'''' || CHR(13);            
            END IF;

            v_UPD_Sql_Query_Display:= v_UPD_Sql_Query;
            DBMS_OUTPUT.PUT_LINE( v_UPD_Sql_Query_Display );
--          EXECUTE IMMEDIATE v_UPD_Sql_Query_Display ;

            v_UPD_Sql_Query := NULL;
            COMMIT;
        END LOOP;

        v_UPD_Sql_Query_Display:=NULL;
        COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        o_OutPut_Message := 'PROCEDURE FAILED ON Step :'||v_Error_Flag||' FOR SQL '||SUBSTR(SQLERRM,1,100);
        DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
    END DCE_upd_parameters;


--  Current Parameters in DCW Data Center
    PROCEDURE DCW_CURRENT_PARAMS
    AS
        o_OutPut_Message             VARCHAR2(32000) := NULL;
        v_Error_Flag                 NUMBER := 0;
        v_Max_Len_Table_Name_val     NUMBER := 0;
        v_Max_Len_Parameter_Name_val NUMBER := 0;
        v_Len_Table_Name             NUMBER := 0;
        v_Len_Param_Name             NUMBER := 0;
    BEGIN     
        o_OutPut_Message:=NULL;
        SELECT MAX(LENGTH(table_name))+4,
               MAX(LENGTH(UPPER(PARAMETER_NAME)))+4 
        INTO 
               v_Max_Len_Table_Name_val,
               v_Max_Len_Parameter_Name_val
        FROM TRANSITHA.APP_SERVER_PARAMETERS;
            
        FOR i IN (SELECT LENGTH(Table_Name) Len_Table_Name, Table_Name, UPPER(PARAMETER_NAME) PARAMETER_NAME, LENGTH(UPPER(PARAMETER_NAME)) Len_Param_Name, DCW_VALUES
                  FROM TRANSITHA.APP_SERVER_PARAMETERS)
        LOOP
            v_Len_Table_Name := v_Max_Len_Table_Name_val - i.Len_Table_Name ;
            v_Len_Param_Name := v_Max_Len_Parameter_Name_val - i.Len_Param_Name; 
            
            o_OutPut_Message := o_OutPut_Message || i.Table_Name||LPAD(CHR(32),v_Len_Table_Name)||i.PARAMETER_NAME||LPAD(CHR(32),v_Len_Param_Name)||i.DCW_VALUES ||CHR(13) ;
            v_Len_Table_Name:=NULL;
            v_Len_Param_Name:=NULL;
        END LOOP;
        DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
    END DCW_CURRENT_PARAMS; 
    
--  Procedure call for DCW Data Center
    PROCEDURE DCW_upd_parameters
    AS
        o_OutPut_Message                VARCHAR2(500) := NULL;
        v_Error_Flag                    NUMBER :=0; -- initialize variable as 0 
        v_UPD_Sql_Query                 VARCHAR2(32000) := NULL; -- initialize variable as empty

        v_UPD_Sql_Query_Display         VARCHAR2(32000) := NULL; -- initialize variable as empty
    BEGIN 

        v_Error_Flag :=1;

--      loop the complete record list
        FOR i IN (SELECT SCHEMA_NAME, TABLE_NAME, SEARCH_COL_NAME1, SEARCH_COL_NAME2, 
                         UPD_COL_NAME, PARAMETER_NAME, DCW_VALUES 
                    FROM TRANSITHA.APP_SERVER_PARAMETERS)
        LOOP
            v_Error_Flag :=2;
--          update query for those records which are having single where conditions
            IF i.SEARCH_COL_NAME1 IS NOT NULL AND i.SEARCH_COL_NAME2 IS NULL AND i.TABLE_NAME <> 'PROCESSOR_CONFIGURATION'
                -- AND i.TABLE_NAME <> 'PROCESSOR_SYNC_STATUS'
                AND NOT (i.SCHEMA_NAME = 'TRANSTSYSPAYMENTGW' AND i.TABLE_NAME = 'DEPARTMENT_PARAMETERS') THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.DCW_VALUES ||'''' || CHR(13) ;
            END IF;

            v_Error_Flag :=3;
--          Parameter_name is different in search condition      
            IF (i.SCHEMA_NAME = 'TRANSTSYSPAYMENTGW' AND i.TABLE_NAME = 'DEPARTMENT_PARAMETERS') 
                OR ( i.SCHEMA_NAME = 'SNOX4TRANSNOX' AND i.TABLE_NAME = 'PROCESSOR_CONFIGURATION') THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.PARAMETER_NAME ||'''' || CHR(13) ;
            END IF;

            v_Error_Flag :=4;
--          Multiple Search condition columns
            IF i.SEARCH_COL_NAME1 IS NOT NULL AND i.SEARCH_COL_NAME2 IS NOT NULL THEN
                v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
                                   '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
                                   ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.PARAMETER_NAME ||'''' || CHR(13) ||
                                   '   AND ' || i.SEARCH_COL_NAME2 || ' = ''' || i.DCW_VALUES ||'''' || CHR(13);            
            END IF;

            v_UPD_Sql_Query_Display:= v_UPD_Sql_Query;
            DBMS_OUTPUT.PUT_LINE( v_UPD_Sql_Query_Display );
--          EXECUTE IMMEDIATE v_UPD_Sql_Query_Display ;

            v_UPD_Sql_Query := NULL;
            COMMIT;
        END LOOP;

        v_UPD_Sql_Query_Display:=NULL;
        COMMIT;
    EXCEPTION
      WHEN OTHERS THEN
        o_OutPut_Message := 'PROCEDURE FAILED ON Step :'||v_Error_Flag||' FOR SQL '||SUBSTR(SQLERRM,1,100);
        DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
    END DCW_upd_parameters;
 
END Data_Center_Parameters;
/


PROCEDURE DCW_CURRENT_PARAMS
    o_OutPut_Message             VARCHAR2(32000);
    v_Error_Flag                 NUMBER;
    v_Max_Len_Table_Name_val     NUMBER;
    v_Max_Len_Parameter_Name_val NUMBER;
    v_Len_Table_Name             NUMBER;
    v_Len_Param_Name             NUMBER;
BEGIN     
    
    o_OutPut_Message:=NULL;
    SELECT MAX(LENGTH(table_name))+4,
           MAX(LENGTH(UPPER(PARAMETER_NAME)))+4 
    INTO 
           v_Max_Len_Table_Name_val,
           v_Max_Len_Parameter_Name_val
    FROM TRANSITHA.APP_SERVER_PARAMETERS;
        
    FOR i IN (SELECT LENGTH(Table_Name) Len_Table_Name, Table_Name, UPPER(PARAMETER_NAME) PARAMETER_NAME, LENGTH(UPPER(PARAMETER_NAME)) Len_Param_Name, DCW_VALUES
              FROM TRANSITHA.APP_SERVER_PARAMETERS)
    LOOP
        v_Len_Table_Name := v_Max_Len_Table_Name_val - i.Len_Table_Name ;
        v_Len_Param_Name := v_Max_Len_Parameter_Name_val - i.Len_Param_Name; 
        
        o_OutPut_Message := o_OutPut_Message || i.Table_Name||LPAD(CHR(32),v_Len_Table_Name)||i.PARAMETER_NAME||LPAD(CHR(32),v_Len_Param_Name)||i.DCW_VALUES ||CHR(13) ;
        v_Len_Table_Name:=NULL;
        v_Len_Param_Name:=NULL;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE(o_OutPut_Message);
END DCW_CURRENT_PARAMS;




DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( JOB       => X 
   ,what      => 'DECLARE 
					  P_OUTPUTSTATUS VARCHAR2(5);
					  P_OUTPUTMSG VARCHAR2(32767);
					  v_Last_Process_Status NUMBER;
					BEGIN 
						v_Last_Process_Status := NULL;
						P_OUTPUTSTATUS := NULL;
						P_OUTPUTMSG := NULL;
						BEGIN 
							SELECT  COUNT(1)  INTO v_Last_Process_Status
							FROM purgedata.purge_logs 
							WHERE table_name=''TRANSIT_PURGING_PKG-END''
							  AND executedon >= (SELECT MAX(executedon) 
												 FROM purgedata.purge_logs 
												 WHERE table_name=''TRANSIT_PURGING_PKG-BEGIN'');
							IF v_Last_Process_Status <> 0                    
							  PURGEDATA.TRANSIT_PURGING_PKG.PURGE_TAB_PROCS ( P_OUTPUTSTATUS, P_OUTPUTMSG );
							  COMMIT;
							END IF;
						EXCEPTION
						   WHEN OTHERS THEN
							  NULL;
							  EXIT;
						END; 
					END;'
   ,next_date => TO_DATE('05/08/2013 01:06:06','dd/mm/yyyy hh24:mi:ss')
   ,INTERVAL  => 'SYSDATE+15/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(x));
COMMIT;
END;
/

SELECT * FROM dba_jobs WHERE JOB=66;


BEGIN
sys.DBMS_IJOB.CHANGE_ENV
  ( 
     JOB => 66, 
     LUSER => 'TRANSCAPITALONEAPP', 
     PUSER => 'TRANSCAPITALONEAPP',
    CUSER => 'TRANSCAPITALONEAPP',
    NLSENV => 'NLS_LANGUAGE=''AMERICAN''
               NLS_TERRITORY=''AMERICA''
               NLS_CURRENCY=''$''
               NLS_ISO_CURRENCY=''AMERICA''
               NLS_NUMERIC_CHARACTERS=''.,''
               NLS_DATE_FORMAT=''DD-MON-RR''
               NLS_DATE_LANGUAGE=''AMERICAN''
               NLS_SORT=''BINARY''
              '); COMMIT;
END;
/



declare
  my_job number;
begin
  dbms_job.submit(job => my_job, 
    what => 'DECLARE 
					  P_OUTPUTSTATUS VARCHAR2(5);
					  P_OUTPUTMSG VARCHAR2(32767);
					  v_Last_Process_Status NUMBER;
					BEGIN 
						v_Last_Process_Status := NULL;
						P_OUTPUTSTATUS := NULL;
						P_OUTPUTMSG := NULL;
						BEGIN 
							SELECT  COUNT(1)  INTO v_Last_Process_Status
							FROM purgedata.purge_logs 
							WHERE table_name=''TRANSIT_PURGING_PKG-END''
							  AND executedon >= (SELECT MAX(executedon) 
												 FROM purgedata.purge_logs 
												 WHERE table_name=''TRANSIT_PURGING_PKG-BEGIN'');
							IF v_Last_Process_Status <> 0                    
							  PURGEDATA.TRANSIT_PURGING_PKG.PURGE_TAB_PROCS ( P_OUTPUTSTATUS, P_OUTPUTMSG );
							  COMMIT;
							END IF;
						EXCEPTION
						   WHEN OTHERS THEN
							  NULL;
							  EXIT;
						END; 
					END; ',
    next_date => trunc(sysdate)+1,
    interval => 'sysdate+1'
    ,no_parse  => FALSE
    );
    DBMS_OUTPUT.PUT_LINE(my_job);
    commit;
	sys.DBMS_IJOB.CHANGE_ENV
    ( 
     JOB => my_job , 
     LUSER => 'PURGEDATA', 
     PUSER => 'PURGEDATA',
    CUSER => 'PURGEDATA',
    NLSENV => 'NLS_LANGUAGE=''AMERICAN''
               NLS_TERRITORY=''AMERICA''
               NLS_CURRENCY=''$''
               NLS_ISO_CURRENCY=''AMERICA''
               NLS_NUMERIC_CHARACTERS=''.,''
               NLS_DATE_FORMAT=''DD-MON-RR''
               NLS_DATE_LANGUAGE=''AMERICAN''
               NLS_SORT=''BINARY'''); COMMIT;
END;
/ 

expdp rchaudhari directory=arc dumpfile=expdp_New_VBS_JuneRelease.dmp logfile=expdp_New_VBS_JuneRelease.log schemas=SNOXPASS_TFE_2016,TNOXPASS_TFE_2016,SNOXPASS_GWAY_012,TNOXPASS_GWAY_012 exclude=statistics,table:\"like\'SC_TEM%\'\",table:\"like\'SN_TEMP%\'\"

impdp rchaudhari directory=arc dumpfile=expdp_New_VBS_JuneRelease.dmp logfile=impdp_expdp_New_VBS_JuneRelease.log remap_schema=SNOXPASS_TFE_2016:SNOXPASS_TFE_2017 remap_schema=TNOXPASS_TFE_2016:TNOXPASS_TFE_2017 remap_schema=SNOXPASS_GWAY_012:SNOXPASS_GWAY_013 remap_schema=TNOXPASS_GWAY_012:TNOXPASS_GWAY_013



SNOXPASS_TFE_2017,TNOXPASS_TFE_2017,SNOXPASS_GWAY_013,TNOXPASS_GWAY_013





SELECT 'alter table '||owner||'.'||table_name|| ' nocompress;'
FROM dba_tables
WHERE owner IN ('ETLUPDATE','KEYNOX_CPASS','WEBFORT_CPASS','TRANSNOX_CAT','TRANSNOX_IOX','SNOX4TRANSNOX','TRANSNOX_IOX_APP','SNOX4TRANSNOX_APP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TNOXPASS_GWAY_012','SNOXPASS_GWAY_012','SNOXPASS_SMSNOX_307','TNOXPASS_SMSNOX_307','SNOXPASS_TFE_2016','TNOXPASS_TFE_2016','TNOXPASS_GWAY_011','SNOXPASS_GWAY_011','SNOXPASS_SMSNOX_306','TNOXPASS_SMSNOX_306','TNOXPASS_TFE_2015','SNOXPASS_TFE_2015','SNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20195','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526')
 AND COMPRESSION='ENABLED' 
 AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
--ORDER BY owner,table_name ASC 
UNION ALL
SELECT 'alter table '||owner||'.'||table_name||' logging;'
FROM dba_tables
WHERE owner IN ('ETLUPDATE','KEYNOX_CPASS','WEBFORT_CPASS','TRANSNOX_CAT','TRANSNOX_IOX','SNOX4TRANSNOX','TRANSNOX_IOX_APP','SNOX4TRANSNOX_APP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TNOXPASS_GWAY_012','SNOXPASS_GWAY_012','SNOXPASS_SMSNOX_307','TNOXPASS_SMSNOX_307','SNOXPASS_TFE_2016','TNOXPASS_TFE_2016','TNOXPASS_GWAY_011','SNOXPASS_GWAY_011','SNOXPASS_SMSNOX_306','TNOXPASS_SMSNOX_306','TNOXPASS_TFE_2015','SNOXPASS_TFE_2015','SNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20195','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526')
 AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
 AND LOGGING='NO'
 
 
SELECT ROUND(FREE_MB/TOTAL_MB*100) PERCENTAGE 
FROM V$ASM_DISKGROUP
WHERE NAME='ASMTXNARCHIVE'


alter user SNOXPASS_TFE_2017 identified by "SnoxPass_Tfe$2017";
alter user TNOXPASS_TFE_2017 identified by "TnoxPass_Tfe$2017";
alter user SNOXPASS_GWAY_013 identified by "SnoxPass_Gway$013";
alter user TNOXPASS_GWAY_013 identified by "TnoxPass_Gway$013";
ALTER USER SNOXPASS_TFE_2017 DEFAULT TABLESPACE ALL_TEMP_TABLES ;
ALTER USER TNOXPASS_TFE_2017 DEFAULT TABLESPACE ALL_TEMP_TABLES;
ALTER USER SNOXPASS_GWAY_013 DEFAULT TABLESPACE ALL_TEMP_TABLES;
ALTER USER TNOXPASS_GWAY_013 DEFAULT TABLESPACE ALL_TEMP_TABLES;



# checking the /archivelogs disk partition space where archive files are getting created
VAL=`df -h | grep "/archivelogs" | awk '{print $4}'|sed 's/%//g'`

if [ $VAL '>' 70 ]
then
    echo  $VAL > log_no_ds.log
    echo "/archivelogs Disk space above 70%"

	 -- cd /archivelogs/oracle/oradata/tsnd/archive

	--- find 1_*.arc -type f -mtime +0 -exec ls -l {} \; > temp_file.sh
	echo "RMAN script to remove the archive files more then 3 days"
	
else
    echo "$VAL"
    echo "/archivelogs Disk space is below 70%"
fi






UPDATE SNOX4TRANSNOX.PROCESSOR_CONFIGURATION
SET PROPERTY_VALUE = 'http://e-hmytadapter.tsysacquiring.org:6008/servlets/TransNox_Adapter_Interface' (http://e-hmytadapter.tsysacquiring.org:6008/servlets/TransNox_Adapter_Interface%27) 
WHERE PROCESSOR_ID='MQ';  



expdp / directory="BKUPS" dumpfile="expdp_qaracdb2_bkups_$bkupDate.dmp" logfile="logs_expdp_qaracdb2_bkups.log" exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\",table:\"like \'SC_TEMP%\'\",schema:\"in \(\'XS$NULL\',\'XDB\',\'WMSYS\',\'TOAD\',\'SYSTEM\',\'SYSMAN\',\'SYS\',\'SPATIAL_WFS_ADMIN_USR\',\'SPATIAL_CSW_ADMIN_USR\',\'SI_INFORMTN_SCHEMA\',\'RMAN\',\'OWBSYS_AUDIT\',\'OWBSYS\',\'OUTLN\',\'ORDSYS\',\'ORDPLUGINS\',\'ORDDATA\',\'ORACLE_OCM\',\'OPS$ORACLE\',\'OLAPSYS\',\'MGMT_VIEW\',\'MDSYS\',\'FLOWS_FILES\',\'EXFSYS\',\'DIP\',\'DBSNMP\',\'CTXSYS\',\'APPQOSSYS\',\'APEX_PUBLIC_USER\',\'APEX_030200\',\'ANONYMOUS\'\)\"  full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y
  

expdp / directory=DPUMP dumpfile="expdp_qaracdb2_bkups_13May2014.dmp" logfile="logs_expdp_qaracdb2_bkups.log" exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\",table:\"like \'SC_TEMP%\'\",schema:\"in \(\'XS$NULL\',\'XDB\',\'WMSYS\',\'TOAD\',\'SYSTEM\',\'SYSMAN\',\'SYS\',\'SPATIAL_WFS_ADMIN_USR\',\'SPATIAL_CSW_ADMIN_USR\',\'SI_INFORMTN_SCHEMA\',\'RMAN\',\'OWBSYS_AUDIT\',\'OWBSYS\',\'OUTLN\',\'ORDSYS\',\'ORDPLUGINS\',\'ORDDATA\',\'ORACLE_OCM\',\'OPS$ORACLE\',\'OLAPSYS\',\'MGMT_VIEW\',\'MDSYS\',\'FLOWS_FILES\',\'EXFSYS\',\'DIP\',\'DBSNMP\',\'CTXSYS\',\'APPQOSSYS\',\'APEX_PUBLIC_USER\',\'APEX_030200\',\'ANONYMOUS\'\)\"  full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y &


CREATE TABLE GGATE.EXCEPTIONS
(
  REP_NAME         VARCHAR2(8 BYTE),
  TABLE_NAME       VARCHAR2(61 BYTE),
  ERRNO            NUMBER,
  DBERRMSG         VARCHAR2(4000 BYTE),
  OPTYPE           VARCHAR2(20 BYTE),
  ERRTYPE          VARCHAR2(20 BYTE),
  LOGRBA           NUMBER,
  LOGPOSITION      NUMBER,
  COMMITTIMESTAMP  TIMESTAMP(6),
  SUPPLEMENTAL LOG GROUP GGS_231755 (LOGRBA,LOGPOSITION,COMMITTIMESTAMP) ALWAYS
)
TABLESPACE GGS_DATA
RESULT_CACHE (MODE DEFAULT)
LOGGING 
NOCOMPRESS ;


CREATE UNIQUE INDEX GGATE.PK_CTS1 ON GGATE.EXCEPTIONS
(LOGRBA, LOGPOSITION, COMMITTIMESTAMP)
LOGGING TABLESPACE GGS_DATA;

ALTER TABLE GGATE.EXCEPTIONS ADD (
  CONSTRAINT PK_CTS1 PRIMARY KEY (LOGRBA, LOGPOSITION, COMMITTIMESTAMP)
  USING INDEX GGATE.PK_CTS1 ENABLE VALIDATE);




UPDATE SNOX4TRANSNOX.PROCESSOR_CONFIGURATION
SET PROPERTY_VALUE = 'http://e-hmytadapter.tsysacquiring.org:6008/servlets/TransNox_Adapter_Interface'
WHERE PROCESSOR_ID='MQ'; 

COMMIT;

UPDATE SNOX4TRANSNOX.PROCESSOR_CONFIGURATION
SET property_value='http://10.123.210.215:6008/servlets/TransNox_Adapter_Interface'
WHERE processor_id='MQ'

SELECT * FROM SNOX4TRANSNOX.PROCESSOR_CONFIGURATION

-- For Election Card
2 Pass Size Photos
Lic copy
Index2 Copy
Elec. Bill
PAN Card
Adhar Card



10.100.226.221--- old dev database

10.132.12.170 mapqadb	--- MAP QA DB
10.132.13.130 arcdb -- dev archive DB
10.132.13.208 Pridb -- OGG1
10.132.13.209 reptdb -- OGG1

loadtxdbnode1.tsysacquiring.org -- txnDCW txnDCE
loadrpdbnode1.tsysacquiring.org -- rptDCW rptDCE
regracdb.tsysacquiring.org
devracdb.tsysacquiring.org
qaracdb.tsysacquiring.org


Reliance Accounts Customer AC:-100117644177
Bill AC:-100000118637734
RahulKC201

204440288 16Jun2013 -- compl.

211119945 26oct2013


-- Cycles
Hero Octane Recra 26T
Hero Octane Estes



https://tsys.taleo.net/careersection/tsys.careersection.internal.001/jobsearch.ftl?lang=en




-- local 
seven$Thousand201

-- col
Donkey.2012014


Teeth DR. 9921496415 Manoj Kulthe



---------------------------------------------------------------------------
-- 27-Mar-2014

SELECT owner, table_name
FROM dba_tables
WHERE LOGGING ='NO'
  AND owner NOT IN ('APEX_030200','APPQOSSYS','CTXSYS','DBSNMP','EXFSYS','FLOWS_FILES','JMURUGAN','MBADHE',
                    'MDSYS','MIS','OLAPSYS','ORDDATA','ORDSYS','OUTLN','OWBSYS','RCHAUDHARI','SCOTT','SMALIK',
                    'SRC_C_REPL','SYS','SYSMAN','SYSTEM','WMSYS','XDB','DBHOSALE')
ORDER BY 1, 2 ASC


SELECT owner, table_name
FROM dba_tables
WHERE owner NOT IN ('APEX_030200','APPQOSSYS','CTXSYS','DBSNMP','EXFSYS','FLOWS_FILES','JMURUGAN','MBADHE',
                    'MDSYS','MIS','OLAPSYS','ORDDATA','ORDSYS','OUTLN','OWBSYS','RCHAUDHARI','SCOTT','SMALIK',
                    'SRC_C_REPL','SYS','SYSMAN','SYSTEM','WMSYS','XDB','DBHOSALE')
  AND compression='ENABLED'
  AND table_name NOT LIKE 'SN_TEMP%' AND table_name NOT LIKE 'SC_TEMP%'
ORDER BY 1,2 ASC  

COMPRESSION, LOGGING


snox4transnox.MER_PROCESSOR_INFO
----------------------------------------------------------------------------





---- refreshing the rptDCW, txnDCE,rptDCE databases...


DROP USER TRANSNOX_CAT CASCADE;
DROP USER TRANSNOX_CPASS CASCADE;
DROP USER SNOX4TRANSNOX_CPASS CASCADE;
DROP USER SNOXPASS_GWAY_011 CASCADE;
DROP USER SNOXPASS_GWAY_012 CASCADE;
DROP USER SNOXPASS_SMSNOX_305 CASCADE;
DROP USER SNOXPASS_SMSNOX_306 CASCADE;
DROP USER SNOXPASS_TFE_2015 CASCADE;
DROP USER SNOXPASS_TFE_2016 CASCADE;
DROP USER TNOXPASS_GWAY_011 CASCADE;
DROP USER TNOXPASS_GWAY_012 CASCADE;
DROP USER TNOXPASS_SMSNOX_305 CASCADE;
DROP USER TNOXPASS_SMSNOX_306 CASCADE;
DROP USER TNOXPASS_TFE_2015 CASCADE;
DROP USER TNOXPASS_TFE_2016 CASCADE;



expdp rchaudhari directory=bkup dumpfile=exp_DCW1_sync_27Mar2014.dmp logfile=exp_DCW1_sync_27Mar2014.log flashback_scn= exclude=statistics,TABLE:" like 'SN_TEMP%'",TABLE:" like 'SC_TEMP%'" schemas=TRANSNOX_CAT,TRANSNOX_CPASS,SNOX4TRANSNOX_CPASS,SNOXPASS_GWAY_011,SNOXPASS_GWAY_012,SNOXPASS_SMSNOX_305,SNOXPASS_SMSNOX_306,SNOXPASS_TFE_2015,SNOXPASS_TFE_2016,TNOXPASS_GWAY_011,TNOXPASS_GWAY_012,TNOXPASS_SMSNOX_305,TNOXPASS_SMSNOX_306,TNOXPASS_TFE_2015,TNOXPASS_TFE_2016 compression=Y 


impdp rchaudhari directory=bkup dumpfile=exp_DCW1_sync_27Mar2014_2.dmp logfile=impdp_exp_DCW1_sync_27Mar2014_2.log




('TRANSNOX_CAT','TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS','SNOXPASS_GWAY_011','SNOXPASS_GWAY_012','SNOXPASS_SMSNOX_305','SNOXPASS_SMSNOX_306','SNOXPASS_TFE_2015','SNOXPASS_TFE_2016','TNOXPASS_GWAY_011','TNOXPASS_GWAY_012','TNOXPASS_SMSNOX_305','TNOXPASS_SMSNOX_306','TNOXPASS_TFE_2015','TNOXPASS_TFE_2016')






Dhiraj Bhosale: key 			5-09640-15125-27442-05305
site messgae 					INFONOX-106-468-537  



Key : DR4GSL7F01MZA0YP380NV4G1A6H2G8VGGJVXN-111-414-023-3D
Site message : TOTAL SYSTEM SERVICES INC 





DECLARE
    v_Error_Flag                    NUMBER :=0; -- initialize variable as 0 
    v_UPD_Sql_Query                 VARCHAR2(32000) := NULL; -- initialize variable as empty
    
    v_UPD_Sql_Query_Display         VARCHAR2(32000) := NULL; -- initialize variable as empty
BEGIN 

    FOR i IN (SELECT SCHEMA_NAME, TABLE_NAME, SEARCH_COL_NAME1, SEARCH_COL_VALUE1, SEARCH_COL_NAME2, SEARCH_COL_VALUE2, UPD_COL_NAME, DCW_VALUES, DCE_VALUES
              FROM TRANSITHA.APP_SERVER_PARAMETERS)
    LOOP
        v_Error_Flag :=1;
--      direct updating tables
        IF i.SEARCH_COL_VALUE1 = '###' THEN 
            EXECUTE IMMEDIATE 'SELECT UNIQUE ' || i.UPD_COL_NAME || 
                              '  FROM ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME ||  
                              ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.DCE_VALUES ||'''' 
                         INTO v_UPD_Sql_Query;   
                                                
        END IF;    
    
--        v_Error_Flag :=2;
----      Tables which are having extra AND condition in search criteria        
--        IF i.SEARCH_COL_VALUE1 <> '###' AND i.SEARCH_COL_NAME2 IS NOT NULL THEN
--            v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
--                               '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
--                               ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.SEARCH_COL_VALUE1 ||'''' || CHR(13) ||
--                               '   AND ' || i.SEARCH_COL_NAME2 || ' = ''' || i.SEARCH_COL_VALUE2 ||'''' || CHR(13) ;
--        END IF;
--
--        v_Error_Flag :=3;
----      Tables which are not having AND condition in search criteria        
--        IF i.SEARCH_COL_VALUE1 <> '###' AND i.SEARCH_COL_NAME2 IS NOT NULL THEN
--            v_UPD_Sql_Query := 'UPDATE ' || i.SCHEMA_NAME || '.' || i.TABLE_NAME || CHR(13) ||
--                               '   SET ' || i.UPD_COL_NAME || ' = ''' || i.DCW_VALUES || '''' || CHR(13) ||
--                               ' WHERE ' || i.SEARCH_COL_NAME1 || ' = ''' || i.SEARCH_COL_VALUE1 ||'''' || CHR(13) ;
--        END IF;

        v_Error_Flag :=4;        
        v_UPD_Sql_Query_Display:= v_UPD_Sql_Query;
        DBMS_OUTPUT.PUT_LINE( v_UPD_Sql_Query_Display );
--      EXECUTE IMMEDIATE v_UPD_Sql_Query_Display ;

        v_UPD_Sql_Query := NULL;
        COMMIT;
    END LOOP;
END;
/    










DECLARE
    xtn_id  NUMBER;
    amt     NUMBER;
BEGIN

    FOR i IN 1..400000
    LOOP
        IF (i >=1 AND i <=100000) THEN

            SELECT TRANSNOX_CPASS.SEQ_TRANSACTION_ID.NEXTVAL INTO xtn_id FROM dual; 

            SELECT TRUNC(dbms_random.value(100,1000)) INTO amt FROM dual;

            INSERT INTO TRANSNOX_CPASS.TRANSACTION1
                (TRANSACTION_ID, TRANS_TYPE, TRANS_STATUS, REASON_CODE, TASK_ID, 
                    TIME_STAMP, DEVICE_ID, CLIENT_TIMESTAMP, AMOUNT, FEE_WAIVED, 
                    CURRENCY, REFERENCE_NUMBER, SEQUENCE_NUMBER, LAST_MODIFIED_TIME_STAMP, COUNTRY_CODE)
            VALUES
                (xtn_id, 'CREDIT_RECURRING', 'APPROVED', '0000', 4529276, 
                    SYSDATE, '11050666655501', SYSDATE, amt, 0, 
                    'USD', '430912503213', 5471, SYSTIMESTAMP, 'USA');

            COMMIT;

--            INSERT INTO TRANSNOX_CPASS.TRANS_SETTLEMENT
--                (TRANSACTION_ID, SETTLEMENT_STATUS, TIMESTAMP, SETTLEMENT_TYPE, AMOUNT)
--            VALUES
--                (xtn_id, 'SUCCESS', SYSDATE, 'IMMEDIATE', amt);
--
--             COMMIT;

        ELSIF (i >=100001 AND i <=200000) THEN

            SELECT TRANSNOX_CPASS.SEQ_TRANSACTION_ID.NEXTVAL INTO xtn_id FROM dual; 

            SELECT  TRUNC(dbms_random.value(200,2000)) INTO amt FROM dual;

            INSERT INTO TRANSNOX_CPASS.TRANSACTION1
                (TRANSACTION_ID, TRANS_TYPE, TRANS_STATUS, REASON_CODE, TASK_ID, 
                    TIME_STAMP, DEVICE_ID, CLIENT_TIMESTAMP, AMOUNT, FEE_WAIVED, 
                    CURRENCY, REFERENCE_NUMBER, SEQUENCE_NUMBER, LAST_MODIFIED_TIME_STAMP, COUNTRY_CODE)
            VALUES
                (xtn_id, 'CREDIT', 'APPROVED', '0000', 4529276, 
                    ADD_MONTHS(SYSDATE,-1), '11050666655501', ADD_MONTHS(SYSDATE,-1), amt, 0, 
                    'USD', '430912503213', 5471, ADD_MONTHS(SYSTIMESTAMP,-1) , 'USA');

            COMMIT;

--            INSERT INTO TRANSNOX_CPASS.TRANS_SETTLEMENT
--                (TRANSACTION_ID, SETTLEMENT_STATUS, TIMESTAMP, SETTLEMENT_TYPE, AMOUNT)
--            VALUES
--                (xtn_id, 'SUCCESS', ADD_MONTHS(SYSDATE,-1), 'IMMEDIATE', amt);
--
--             COMMIT;            

        ELSIF (i >=200001 AND i <=300000) THEN

            SELECT TRANSNOX_CPASS.SEQ_TRANSACTION_ID.NEXTVAL INTO xtn_id FROM dual; 

            SELECT  TRUNC(dbms_random.value(300,3000)) INTO amt FROM dual;

            INSERT INTO TRANSNOX_CPASS.TRANSACTION1
                (TRANSACTION_ID, TRANS_TYPE, TRANS_STATUS, REASON_CODE, TASK_ID, 
                    TIME_STAMP, DEVICE_ID, CLIENT_TIMESTAMP, AMOUNT, FEE_WAIVED, 
                    CURRENCY, REFERENCE_NUMBER, SEQUENCE_NUMBER, LAST_MODIFIED_TIME_STAMP, COUNTRY_CODE)
            VALUES
                (xtn_id, 'DEBIT_SETTLE', 'APPROVED', '0000', 4529276, 
                    ADD_MONTHS(SYSDATE,-4), '11050666655501', ADD_MONTHS(SYSDATE,-4), amt, 0, 
                    'USD', '430912503213', 5471, ADD_MONTHS(SYSTIMESTAMP,-4) , 'USA');

            COMMIT;

--            INSERT INTO TRANSNOX_CPASS.TRANS_SETTLEMENT
--                (TRANSACTION_ID, SETTLEMENT_STATUS, TIMESTAMP, SETTLEMENT_TYPE, AMOUNT)
--            VALUES
--                (xtn_id, 'SUCCESS', ADD_MONTHS(SYSDATE,-4), 'IMMEDIATE', amt);
--
--             COMMIT;            

        ELSIF (i >=300001 AND i <=400000) THEN

            SELECT TRANSNOX_CPASS.SEQ_TRANSACTION_ID.NEXTVAL INTO xtn_id FROM dual; 

            SELECT  TRUNC(dbms_random.value(400,4000)) INTO amt FROM dual;

            INSERT INTO TRANSNOX_CPASS.TRANSACTION1
                (TRANSACTION_ID, TRANS_TYPE, TRANS_STATUS, REASON_CODE, TASK_ID, 
                    TIME_STAMP, DEVICE_ID, CLIENT_TIMESTAMP, AMOUNT, FEE_WAIVED, 
                    CURRENCY, REFERENCE_NUMBER, SEQUENCE_NUMBER, LAST_MODIFIED_TIME_STAMP, COUNTRY_CODE)
            VALUES
                (xtn_id, 'ACH_RECURRING', 'APPROVED', '0000', 4529276, 
                    ADD_MONTHS(SYSDATE,-14), '11050666655501', ADD_MONTHS(SYSDATE,-14), amt, 0, 
                    'USD', '430912503213', 5471, ADD_MONTHS(SYSTIMESTAMP,-14) , 'USA');

            COMMIT;

--            INSERT INTO TRANSNOX_CPASS.TRANS_SETTLEMENT
--                (TRANSACTION_ID, SETTLEMENT_STATUS, TIMESTAMP, SETTLEMENT_TYPE, AMOUNT)
--            VALUES
--                (xtn_id, 'SUCCESS', ADD_MONTHS(SYSDATE,-14), 'IMMEDIATE', amt);
--             COMMIT;            
        END IF; 
    END LOOP;
END; 
/



-------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE RCHAUDHARI.NEW_VBS_CREATION (
   i_FE_VBS_Name       IN     VARCHAR2,
   i_GWAY_VBS_Name     IN     VARCHAR2,
   i_SMSNOX_VBS_Name   IN     VARCHAR2,
   
   o_OutputMessage        OUT VARCHAR2,
   o_OutputStatus         OUT NUMBER)
AS
   v_ErrorFlag             NUMBER := 0;
   v_VBS_Schema_List       VARCHAR2 (5000);

   v_string                VARCHAR2 (10000);
   V_NUMBER                NUMBER;

   v_Old_VBS_Name       VARCHAR2(5000);
   v_New_VBS_Name       VARCHAR2(5000);
      
    
   
BEGIN

  
  IF i_FE_VBS_Name IS NOT NULL THEN
--      v_string := v_string 
--                    || 'TRANSIT_FE_TNOX_' 
--                    || i_FE_VBS_Name 
--                    || ',TRANSIT_FE_SNOX_' 
--                    || i_FE_VBS_Name 
--                    || ',';
       v_Old_VBS_Name:= v_Old_VBS_Name
                         || 'TRANSIT_FE_TNOX_'
                         || REGEXP_SUBSTR ('3112~3113~FE','[^~]+' ,1,1) 
                         || ','
                         || 'TRANSIT_FE_SNOX_'
                         || REGEXP_SUBSTR ('3112~3113~FE','[^~]+' ,1,1);
       
       v_New_VBS_Name:= v_New_VBS_Name 
                         || 'TRANSIT_FE_TNOX_'
                         || REGEXP_SUBSTR ('3112~3113~FE','[^~]+' ,1,2) 
                         || ','
                         || 'TRANSIT_FE_SNOX_'
                         || REGEXP_SUBSTR ('3112~3113~FE','[^~]+' ,1,2); 

                    
   END IF;
   
   IF i_GWAY_VBS_Name IS NOT NULL THEN
--      v_string := v_string 
--                    || 'TRANSIT_GATEWAY_TNOX_' 
--                    || i_GWAY_VBS_Name 
--                    || ',TRANSIT_GATEWAY_SNOX_' 
--                    || i_GWAY_VBS_Name 
--                    || ',';
   END IF;
   
   IF i_SMSNOX_VBS_Name IS NOT NULL THEN
--      v_string := v_string
--                    || 'TRANSIT_SMSNOX_TNOX_'
--                    || i_SMSNOX_VBS_Name
--                    || ',TRANSIT_SMSNOX_SNOX_'
--                    || i_SMSNOX_VBS_Name
--                    || ',';
   END IF;
   
   v_string := REGEXP_REPLACE(v_string,',$');
   

   SELECT COUNT(1)  
     INTO V_NUMBER
     FROM all_USERS 
    WHERE USERNAME IN (v_string);

   DBMS_OUTPUT.PUT_LINE ('STRING IS ' || V_NUMBER);
   DBMS_OUTPUT.PUT_LINE ('STRING IS ' || v_string);

   COMMIT;
   o_OutputStatus := 0;
   o_OutputMessage := 'SUCCESS';
EXCEPTION
   WHEN OTHERS THEN
      ROLLBACK;
      o_OutputStatus := -101;
      o_OutputMessage :=
            'PROCEDURE NEW_VBS_CREATION FAILED AT  '
         || v_ErrorFlag
         || ':'
         || SUBSTR (SQLERRM, 1, 100);
END NEW_VBS_CREATION;
/



---------------------------------------------
Old VBS String 6
Old VBS String 'TRANSIT_FE_TNOX_3112','TRANSIT_FE_SNOX_3112','TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_SNOX_3112','TRANSIT_SMSNOX_TNOX_3111','TRANSIT_SMSNOX_SNOX_3111'
New VBS String TRANSIT_FE_TNOX_3113,TRANSIT_FE_SNOX_3113,TRANSIT_GATEWAY_TNOX_3113,TRANSIT_GATEWAY_SNOX_3113,TRANSIT_SMSNOX_TNOX_3113,TRANSIT_SMSNOX_SNOX_3113
O_OUTPUTMESSAGE =
O_OUTPUTSTATUS =


'IN (''TRANSIT_FE_TNOX_3112'',''TRANSIT_FE_SNOX_3112'',''TRANSIT_GATEWAY_TNOX_3112'',''TRANSIT_GATEWAY_SNOX_3112'',''TRANSIT_SMSNOX_TNOX_3111'',''TRANSIT_SMSNOX_SNOX_3111'')'
' IN (''TRANSIT_FE_TNOX_3112'',''TRANSIT_FE_SNOX_3112'',''TRANSIT_GATEWAY_TNOX_3112'',''TRANSIT_GATEWAY_SNOX_3112'',''TRANSIT_SMSNOX_TNOX_3111'',''TRANSIT_SMSNOX_SNOX_3111'')'

''' IN ('||''''||''''||REGEXP_REPLACE(,',',''''',''''')||''''||''''||')'''

DECLARE
  EXPORT_VBS_JOB NUMBER;
  JOB_status VARCHAR2(32000);
BEGIN
  EXPORT_VBS_JOB := DBMS_DATAPUMP.OPEN (OPERATION => 'EXPORT', JOB_MODE => 'SCHEMA', VERSION => 'LATEST', COMPRESSION => 1);
  DBMS_DATAPUMP.ADD_FILE (HANDLE => EXPORT_VBS_JOB, FILENAME => 'expdp_vbs_3113.dmp', DIRECTORY => 'DBRELEASE_VBS', REUSEFILE => 1);
  DBMS_DATAPUMP.ADD_FILE(HANDLE => EXPORT_VBS_JOB, FILENAME => 'expdp_log_vbs_3113.log', DIRECTORY => 'DBRELEASE_VBS', FILETYPE => DBMS_DATAPUMP.KU$_FILE_TYPE_LOG_FILE);
  DBMS_DATAPUMP.METADATA_FILTER (EXPORT_VBS_JOB, NAME => 'SCHEMA_EXPR', VALUE => 'IN (''TRANSIT_FE_SNOX_3112'',''TRANSIT_FE_TNOX_3112'',''TRANSIT_GATEWAY_SNOX_3112'',''TRANSIT_GATEWAY_TNOX_3112'',''TRANSIT_SMSNOX_SNOX_3112'',''TRANSIT_SMSNOX_TNOX_3112'')'); 
--  DBMS_DATAPUMP.METADATA_FILTER (EXPORT_VBS_JOB, NAME=>'NAME_EXPR', VALUE=>'NOT IN (SELECT listagg('''' || TABLE_NAME || '''',',') WITHIN GROUP (ORDER BY table_name) FROM DBA_TABLES  WHERE OWNER IN (''TRANSIT_FE_SNOX_3112'',''TRANSIT_FE_TNOX_3112'',''TRANSIT_GATEWAY_SNOX_3112'', ''TRANSIT_GATEWAY_TNOX_3112'',''TRANSIT_SMSNOX_SNOX_3112'',''TRANSIT_SMSNOX_TNOX_3112'') AND REGEXP_LIKE(TABLE_NAME,''s._temp[[:digit:]]'',''i''))';

   DBMS_DATAPUMP.START_JOB (EXPORT_VBS_JOB);
   DBMS_DATAPUMP.WAIT_FOR_JOB (EXPORT_VBS_JOB, JOB_status);
   DBMS_DATAPUMP.DETACH (handle => EXPORT_VBS_JOB);
END;
/

expdp rchaudhari directory=DBRELEASE_VBS dumpfile=expdp_vbs_3113.dmp logfile=expdp_log_vbs_3113.log schema=3111_gway,3112_fe,3112_smsnox

remap =3111_gway:3113_gway



DECLARE
  EXPORT_VBS_JOB NUMBER;
  JOB_status VARCHAR2(32000);
BEGIN
    EXPORT_VBS_JOB := DBMS_DATAPUMP.OPEN (OPERATION => 'IMPORT', JOB_MODE => 'SCHEMA', VERSION => 'LATEST', COMPRESSION => 1);
    DBMS_DATAPUMP.ADD_FILE (HANDLE => EXPORT_VBS_JOB, FILENAME => 'expdp_vbs_3113.dmp', DIRECTORY => 'DBRELEASE_VBS', REUSEFILE => 1);
    DBMS_DATAPUMP.ADD_FILE(HANDLE => EXPORT_VBS_JOB, FILENAME => 'impdp_expdp_log_vbs_3113_12.log', DIRECTORY => 'DBRELEASE_VBS', FILETYPE => DBMS_DATAPUMP.KU$_FILE_TYPE_LOG_FILE);

--  Below dbms datapump is not required actually, but in case where you have to import only sepecific schema's then you can issue it    
--    DBMS_DATAPUMP.METADATA_FILTER (EXPORT_VBS_JOB, NAME => 'SCHEMA_EXPR', VALUE => 'IN (''TRANSIT_FE_SNOX_3112'',''TRANSIT_FE_TNOX_3112'',''TRANSIT_GATEWAY_SNOX_3112'',''TRANSIT_GATEWAY_TNOX_3112'',''TRANSIT_SMSNOX_SNOX_3112'',''TRANSIT_SMSNOX_TNOX_3112'')');
    
    DBMS_DATAPUMP.metadata_remap (HANDLE => EXPORT_VBS_JOB, NAME => 'REMAP_SCHEMA', OLD_VALUE => 'TRANSIT_FE_SNOX_3112', VALUE=> 'TRANSIT_FE_SNOX_3113');
    DBMS_DATAPUMP.metadata_remap (HANDLE => EXPORT_VBS_JOB, NAME => 'REMAP_SCHEMA', OLD_VALUE => 'TRANSIT_FE_TNOX_3112', VALUE=> 'TRANSIT_FE_TNOX_3113');
    
    DBMS_DATAPUMP.metadata_remap (HANDLE => EXPORT_VBS_JOB, NAME => 'REMAP_SCHEMA', OLD_VALUE => 'TRANSIT_GATEWAY_SNOX_3112', VALUE=> 'TRANSIT_GATEWAY_SNOX_3113');
    DBMS_DATAPUMP.metadata_remap (HANDLE => EXPORT_VBS_JOB, NAME => 'REMAP_SCHEMA', OLD_VALUE => 'TRANSIT_GATEWAY_TNOX_3112', VALUE=> 'TRANSIT_GATEWAY_TNOX_3113');

    DBMS_DATAPUMP.metadata_remap (HANDLE => EXPORT_VBS_JOB, NAME => 'REMAP_SCHEMA', OLD_VALUE => 'TRANSIT_SMSNOX_SNOX_3112', VALUE=> 'TRANSIT_SMSNOX_SNOX_3113');
    DBMS_DATAPUMP.metadata_remap (HANDLE => EXPORT_VBS_JOB, NAME => 'REMAP_SCHEMA', OLD_VALUE => 'TRANSIT_SMSNOX_TNOX_3112', VALUE=> 'TRANSIT_SMSNOX_TNOX_3113');

    DBMS_DATAPUMP.START_JOB (EXPORT_VBS_JOB);
    DBMS_DATAPUMP.WAIT_FOR_JOB (EXPORT_VBS_JOB, JOB_status);
    DBMS_DATAPUMP.DETACH (HANDLE => EXPORT_VBS_JOB);
END;
/

CREATE OR REPLACE TYPE TRANSIT_GATEWAY_TNOX_3113."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_TNOX_3113."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_SNOX_3113."MYARRAY" AS TABLE OF VARCHAR2(1000);
CREATE OR REPLACE TYPE TRANSIT_FE_SNOX_3113."VARCHAR_LIST"  AS TABLE OF VARCHAR2(4000);

DECLARE 
    v_Create_Privs_Script   VARCHAR2(32000);
    v_Create_Synonym_Script VARCHAR2(32000);
--    v_counter   NUMBER:=0;
BEGIN 
    FOR i IN (SELECT 'GRANT ' || WM_CONCAT(PRIVILEGE) || ' on ' || OWNER || '.' || table_name || ' to ' || DECODE(GRANTEE,
                                                                                                                         'TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_TNOX_3113',
                                                                                                                         'TRANSIT_GATEWAY_SNOX_3112','TRANSIT_GATEWAY_SNOX_3113',
                                                                                                                         'TRANSIT_SMSNOX_TNOX_3112','TRANSIT_SMSNOX_TNOX_3113',
                                                                                                                         'TRANSIT_SMSNOX_SNOX_3112','TRANSIT_SMSNOX_SNOX_3113',
                                                                                                                         'TRANSIT_FE_SNOX_3112','TRANSIT_FE_SNOX_3113',
                                                                                                                         'TRANSIT_FE_TNOX_3112','TRANSIT_FE_TNOX_3113') Grant_Privs
             FROM DBA_TAB_PRIVS 
            WHERE GRANTEE IN ('TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_SNOX_3112',
                               'TRANSIT_FE_SNOX_3112','TRANSIT_FE_TNOX_3112',
                               'TRANSIT_SMSNOX_TNOX_3112','TRANSIT_SMSNOX_SNOX_3112')
              AND owner <>'TRANSNOX_CAT'
            GROUP BY GRANTOR, TABLE_NAME, OWNER, GRANTEE
            ORDER BY owner, table_name ASC)
    LOOP
        v_Create_Privs_Script:= i.Grant_Privs;-- ||';';
        
--        IF SQL%ROWCOUNT = 10 THEN
--            dbms_output.put_line('# of rows selected: '|| SQL%ROWCOUNT);
--        END IF;
        
        dbms_output.put_line(v_Create_Privs_Script);
        
        EXECUTE IMMEDIATE v_Create_Privs_Script;    
    
    END LOOP;

    FOR i IN (SELECT 'CREATE OR REPLACE SYNONYM '||DECODE(OWNER,
                                                               'TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_TNOX_3113',
                                                               'TRANSIT_GATEWAY_SNOX_3112','TRANSIT_GATEWAY_SNOX_3113',
                                                               'TRANSIT_SMSNOX_TNOX_3112','TRANSIT_SMSNOX_TNOX_3113',
                                                               'TRANSIT_SMSNOX_SNOX_3112','TRANSIT_SMSNOX_SNOX_3113',
                                                               'TRANSIT_FE_SNOX_3112','TRANSIT_FE_SNOX_3113',
                                                               'TRANSIT_FE_TNOX_3112','TRANSIT_FE_TNOX_3113') ||'.'||SYNONYM_NAME||' FOR '||TABLE_OWNER||'.'||TABLE_NAME  create_synonyms
              FROM dba_synonyms
              WHERE owner IN  ('TRANSIT_GATEWAY_TNOX_3112','TRANSIT_GATEWAY_SNOX_3112',
                               'TRANSIT_FE_SNOX_3112','TRANSIT_FE_TNOX_3112',
                               'TRANSIT_SMSNOX_TNOX_3112','TRANSIT_SMSNOX_SNOX_3112')
                AND NOT REGEXP_LIKE(synonym_name,'\/')
              ORDER BY table_owner, table_name ASC)
    LOOP
        v_Create_Synonym_Script:= i.create_synonyms;

        dbms_output.put_line(v_Create_Synonym_Script);
        
        EXECUTE IMMEDIATE v_Create_Synonym_Script;
        
    END LOOP;
    
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_TNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_GATEWAY_SNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_TNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_SMSNOX_SNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_FE_TNOX_3113');
    DBMS_UTILITY.COMPILE_SCHEMA('TRANSIT_FE_SNOX_3113');    
    
    COMMIT;
    
EXCEPTION 
    WHEN OTHERS THEN
        dbms_output.put_line(SUBSTR(SQLERRM,1,100));
END;
/

SELECT DECODE(GROUPING(A.owner), 1, 'Total Objects of All Owners',A.owner) AS "Owner",
    COUNT(CASE WHEN A.object_type = 'FUNCTION' THEN 1 ELSE NULL END) "Function",
    COUNT(CASE WHEN A.object_type = 'INDEX' THEN 1 ELSE NULL END) "Indexes",
    COUNT(CASE WHEN A.object_type = 'INDEX PARTITION' THEN 1 ELSE NULL END) "Index_Partition",
    COUNT(CASE WHEN A.object_type = 'LOB' THEN 1 ELSE NULL END) "Lob",
    COUNT(CASE WHEN A.object_type = 'MATERIALIZED VIEW' THEN 1 ELSE NULL END) "MATERIALIZED_VIEW",
    COUNT(CASE WHEN A.object_type = 'PACKAGE' THEN 1 ELSE NULL END) "Packages",
    COUNT(CASE WHEN A.object_type = 'PACKAGE BODY' THEN 1 ELSE NULL END) "Packages_Body",
    COUNT(CASE WHEN A.object_type = 'PROCEDURE' THEN 1 ELSE NULL END) "Procedures",
    COUNT(CASE WHEN A.object_type = 'SEQUENCE' THEN 1 ELSE NULL END) "Sequences",
    COUNT(CASE WHEN A.object_type = 'SYNONYM' THEN 1 ELSE NULL END) "Synonym",
    COUNT(CASE WHEN A.object_type = 'TABLE' THEN 1 ELSE NULL END) "Tables",
    COUNT(CASE WHEN A.object_type = 'TABLE PARTITION' THEN 1 ELSE NULL END) "Table_Partition",   
    COUNT(CASE WHEN A.object_type = 'TRIGGER' THEN 1 ELSE NULL END) "Triggers",
    COUNT(CASE WHEN A.object_type = 'TYPE' THEN 1 ELSE NULL END) "Types",
    COUNT(CASE WHEN A.object_type = 'VIEW' THEN 1 ELSE NULL END) "Views",
    --COUNT(CASE WHEN A.object_type NOT IN ('PACKAGE','TABLE','INDEX','SEQUENCE','TRIGGER') THEN 1 ELSE NULL END) "Other",
    COUNT(CASE WHEN 1 = 1 THEN 1 ELSE NULL END) "Total"
FROM DBA_OBJECTS A
WHERE 
--   owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS')
 owner IN ('TRANSIT_GATEWAY_TNOX_3112', 'TRANSIT_GATEWAY_SNOX_3112', 'TRANSIT_SMSNOX_TNOX_3112', 'TRANSIT_SMSNOX_SNOX_3112' , 'TRANSIT_FE_TNOX_3112', 'TRANSIT_FE_SNOX_3112',
            'TRANSIT_GATEWAY_TNOX_3113', 'TRANSIT_GATEWAY_SNOX_3113', 'TRANSIT_SMSNOX_TNOX_3113', 'TRANSIT_SMSNOX_SNOX_3113' , 'TRANSIT_FE_TNOX_3113', 'TRANSIT_FE_SNOX_3113')      
GROUP BY ROLLUP(A.owner);

