
------------------------------------------------------------------------------------------------------------------------------------------------
-- Proper Resync of an Agent

-- How to Resyncronize the Agent and OMS

When an agent reports that it�s blocked and needs to be resync�d, most DBAs are going to log into the Enterprise Manager 12c console and attempt a 
resynchronization to have it fail.  A resync isn�t required very often, but if you do run into �Agent Blocked�, here are the initial steps that 
should be performed to have a resync complete successfully.

Log onto the server that is reporting it�s blocked.
If a MS Windows server, then open a command prompt �as an administrator� and go to the agent home, (this can be seen in the console under 
�home location� and has the word, �core� in the path)

So for our example:
E:\app\oracle\agent12c\core\12.1.0.2.0\bin>

If Linux/Unix, go to the $AGENT_HOME, ensuring you are in the �CORE� directory and proceed to bin.

1.  Stop the agent:
>emctl stop agent
Oracle Enterprise Manager Cloud Control 12c Release 2
Copyright (c) 1996, 2012 Oracle Corporation.  All rights reserved.
The Oracleagent12c1Agent service is stopping����.
The Oracleagent12c1Agent service was stopped successfully.
 
2.  Secure the agent:
>emctl secure agent
Oracle Enterprise Manager Cloud Control 12c Release 2
Copyright (c) 1996, 2012 Oracle Corporation.  All rights reserved.
Agent is already stopped�   Done.
Securing agent�   Started.
Enter Agent Registration Password : <� Enter the Registration Password, if unknown, create a new one in the Console.
EMD gensudoprops completed successfully
Securing agent�   Successful.
 
3.  Restart the agent:
>emctl start agent
Oracle Enterprise Manager Cloud Control 12c Release 2
Copyright (c) 1996, 2012 Oracle Corporation.  All rights reserved.
The Oracleagent12c1Agent service is starting��������
The Oracleagent12c1Agent service was started successfully.
 
4.  Verify that it�s secured by trying to upload, but still blocked, which we expect, (the unblock has to be done AFTER a resecure):
>emctl upload agent
Oracle Enterprise Manager Cloud Control 12c Release 2
Copyright (c) 1996, 2012 Oracle Corporation.  All rights reserved.

EMD upload error:full upload has failed: The agent is blocked by the OMS. Agentis out-of-sync with repository. This most likely means that the agent was reinst
alled or recovered. Please contact an EM administrator to unblock the agent by performing an agent resync from the console. (AGENT_BLOCKED)
 
5.  Now, Submit a resync from the console to complete the task:
Click on Targets, All Targets. In the search menu, type in the name of the host that is experiencing the issue.  All targets that 
are part of that host will come up.  Notice the one that says �Agent�.  Click on it and it will bring you to the Agent console.
Below the name of the host target name on the upper left, you will notice it says, �Agent�  Click on this and then in the drop down menu, 
click on �Resyncronization�. Follow through the defaults and click then click on the job that is submitted to perform the resync.  
You can monitor it till it�s complete, (sometimes it can take up to a 1/2 hour to clear out all the issues. Once it says �Succeeded�, then 
you can log in and successfully upload, as well as the status should be green for all targets connected to this agent.
------------------------------------------------------------------------------------------------------------------------------------------------


-- When your target.xml file is empty, you can re-create it bt below steps


1) check if target.xml is empty

vi /opt/app/oracle/product/agent/agent_inst/sysman/emd/targets.xml

2) open it to edit and add the below details with agent details

like here I have to re-create the target.xml for devracdb1, below are the mentioned details then

-- Help on re-creating target.xml file 365252.1 Oracle document
-- NOTE: The first time you start this agent after adding the above parameters, the AGENT_SEED parameter will 
--       convert itself to AGENT_TOKEN and the seed will become encrypted.

<Targets AGENT_SEED="123456789">
<Target TYPE="oracle_emd" NAME="devdbnode1.tsysacquiring.org:3872" DISPLAY_NAME="devdbnode1.tsysacquiring.org:3872" ON_HOST="" EMD_URL="https://devdbnode1.tsysacquiring.org:3872/emd/main/"/>
<Target TYPE="host" NAME="devdbnode1.tsysacquiring.org"/>
</Targets>


3) Save the above details to mentioned file target.xml on mentioned location 

4) start the agent
	
$AGENT_HOME/bin/./emctl start agent

$AGENT_HOME/bin/./emctl status agent

login to OEM 12c and do Agent Resynchronization 
	1) click on Target all
	2) go to Agent
	3) right click on agent devracdb1.tsysacquiring.org, select resynchronization
	
	
------------------------------------------------------------------------------------------------------------------------------------------------

agentDeploy.sh AGENT_BASE_DIR=/scratch/agent OMS_HOST=hostname.domain.com EM_UPLOAD_PORT=1000 INVENTORY_LOCATION=/scratch AGENT_REGISTRATION_PASSWORD=2Bor02B4
 
 
agentDeploy.sh AGENT_BASE_DIR=/opt/app/oracle/agent/agent_inst OMS_HOST=wdl2tsysdbs03.tsysacquiring.org EM_UPLOAD_PORT=1521 INVENTORY_LOCATION=/opt/app/ AGENT_REGISTRATION_PASSWORD=mpty%kow


























