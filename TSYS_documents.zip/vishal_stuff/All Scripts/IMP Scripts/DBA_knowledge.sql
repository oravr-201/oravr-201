DBA knowledge

CPU, PSU, SPU - Oracle Critical Patch Update Terminology Update

Critical Patch Update (CPU) now refers to the overall release of security fixes each quarter rather than the cumulative 
	database security patch for the quarter.  Think of the CPU as the overarching quarterly release and not as a single patch.

Patch Set Updates (PSU) are the same cumulative patches that include both the security fixes and priority fixes.  The key with PSUs is 
	they are minor version upgrades (e.g., 11.2.0.1.1 to 11.2.0.1.2).  Once a PSU is applied, only PSUs can be applied in future quarters 
	until the database is upgraded to a new base version.

Security Patch Update (SPU) terminology is introduced in the October 2012 Critical Patch Update as the term for the quarterly security patch.  
	SPU patches are the same as previous CPU patches, just a new name.  For the database, SPUs can not be applied once PSUs have been applied 
	until the database is upgraded to a new base version.

Bundle Patches are the quarterly patches for Windows and Exadata which include both the quarterly security patches as well as recommended fixes.


-- What is SCAN in Cluster RAC
In Oracle RAC environments it provides a single name for clients to access any Oracle Database running in a cluster.
You can think of SCAN as a cluster alias for databases in the cluster....

The benefit is that the client�s connect information does not need to change if you add or remove nodes or databases in the cluster.

SCAN VIP: SCAN NAME resolves to one or more than one IP addresses, these IP address are called as SCAN VIP or SCAN IP. 
 Each Scan VIP has a SCAN Listener generated corresponding to it. If there is one SCAN IP one SCAN Listener will be 
 generated, if there are three SCAN IPs three SCAN Listeners will be generated.

--http://www.dbas-oracle.com/2013/08/SCAN-NAME-SCAN-VIP-SCAN-Listener-Node-VIP-Local-Listener-Remote-Listener-RAC.html


-- RMAN Terminology
* Image Copy: Full copy of a single file.
* Backup Set: Oracle format for a package of Objects backed up.
* Backup Piece: Oracle format for a sub package of a backup set.
* Channel: A server process on the target database.

-------------------------------------------------------------------------------------------------------------------------
-- GoldenGate Replication

-- Manager
The Manager process must be running on both the source as well as target systems before the Extract or Replicat process 
can be started and performs a number of functions including monitoring and starting other GoldenGate processes, 
managing the trail files and also reporting.

-- Extract
The Extract process runs on the source system and is the data capture mechanism of GoldenGate. It can be configured both 
for initial loading of the source data as well as to synchronize the changed data on the source with the target. This 
can be configued to also propagate any DDL changes on those databases where DDL change support is available.

-- Replicat
The Replicat process runs on the target system and reads transactional data changes as well as DDL changes and replicates 
then to the target database. Like the Extract process, the Replicat process can also be configured for Initial Load as 
well as Change Synchronization.

-- Collector
The Collector is a background process which runs on the target system and is started automatically by the Manager 
(Dynamic Collector) or it can be configured to stsrt manually (Static Collector). It receives extracted data changes that 
are sent via TCP/IP and writes then to the trail files from where they are processed by the Replicat process.

-- Trails
Trails are series of files that GoldenGate temporarily stores on disks and these files are written to and read from by 
the Extract and Replicat processes as the case may be. Depending on the configuration chosen, these trail files can exist 
on the source as well as on the target systems. If it exists on the local system, it will be known an Extract Trail or as 
an Remote Trail if it exists on the target system.

-- Data Pumps
Data Pumps are secondary extract mechanisms which exist in the source configuration. This is optional component and if 
Data Pump is not used then Extract sends data via TCP/IP to the remote trail on the target. When Data Pump is configured, 
the the Primary Extract process will write to the Local Trail and then this trail is read by the Data Pump and data is sent 
over the network to Remote Trails on the target system.

In the absence of Data Pump, the data that the Extract process extracts resides in memory alone and there is no storage of 
this data anywhere on the source system. In case of network of target failures, there could be cases where the primary 
extract process can abort or abend. Data Pump can also be useful in those cases where we are doing complex filtering 
and transformation of data as well as when we are consolidating data from many sources to a central target.

-- Data source
When processing transactional data changes, the Extract process can obtain data directly from the database transaction 
logs (Oracle, DB2, SQL Server, MySQL etc) or from a GoldenGate Vendor Access Module (VAM) where the database vendor 
(for example Teradata) will provide the required components that will be used by Extract to extract the data changes.

-- Groups
To differentiate between the number of different Extract and Replicat groups which can potentially co-exist on a system, 
we can define processing groups. For instance, if we want to replicate different sets of data in parallel, we can create 
two Replicat groups.

A processing group consisits of a process which could be either a Extract or Replicat process, a corresponding parameter 
file, checkpoint file or checkpoint table (for Replicat) and other files which could be associated with the process.
-------------------------------------------------------------------------------------------------------------------------


-- Parsing of SQL Queryies
SQL generally goes through --
    * PARSE 
    * BIND 
    * EXECUTE 
    * FETCH

You may have multiple fetches per execution (fetch first 10 rows, next 10 rows and etc). Equally some SQLs donot have a fetch (eg an insert). 
A transaction consists of a numbers of SQLs. If you have 20-30 SQLs per transaction, then you got some reasonable complexity. 
Not every statement is an isolated transaction in its own right.

-- How Oracle processes a query
1. Parse: In this stage, the user process sends the query to the server process with a request to parse or compile the query. 
    The server process checks the validity of the command and uses the area in the SGA known as the shared pool to compile the statement. 
    At the end of this phase, the server process returns the status�that is, success or failure of the parse phase�to the user process.
2. Execute: During this phase in the processing of a query, the server process prepares to retrieve the data.
3. Fetch: The rows that are retrieved by the query are returned by the server to the user during this phase. Depending on the amount of memory 
    used for the transfer, one or more fetches are required to transfer the results of a query to the user.

-- SCN -- (Current Log Sequence Number)
The current log sequence number is stored in the control file and in the header of all data files.


--- BackGround - Processes
An Oracle instance runs two types of processes - 
  *	Server Processes
  *	Background Processes

* Server processes are created to handle requests from sessions connected to the instance. 
* Background processes, are processes running behind the scene and are meant to perform certain maintenance activities or to deal with 
  abnormal conditions arising in the lifetime of the instance.

--* System Monitor (SMON)
	Process Name: SMON
	Max Processes: 1
	**> This process is responsible for instance recovery, if necessary, at instance startup. SMON also cleans up temporary segments that are no longer in use. 
	   It also coalesces contiguous free extents in dictionary managed tablespaces that have PCTINCREASE set to a non-zero value.

	   SMON wakes up about every 5 minutes to perform housekeeping activities. SMON must always be running for an instance.

--* Process Monitor (PMON)
	Process Name: PMON
	Max Processes: 1
	**> This process is responsible for performing recovery if a user process fails. It will rollback uncommitted transactions. PMON is also responsible for 
	   cleaning up the database buffer cache and freeing resources that were allocated to a process. PMON also registers information about the instance and 
	   dispatcher processes with network listener.

	   PMON wakes up every 3 seconds to perform housekeeping activities. PMON must always be running for an instance.

--* Database Writer (DBWn)
	Process Name: DBW0 through DBW9 and DBWa through DBWj
	Max Processes: 20
	**> This process writes the dirty buffers present in the database buffer cache to datafiles. The initialization parameter, DB_WRITER_PROCESSES, 
		specifies the number of database writer processes to start.

	The DBWn process writes dirty buffer to disk under the following conditions:
	1. When a checkpoint is issued. Please see checkpoint process below.
	2. When a server process cannot find a clean reusable buffer after scanning a threshold number of buffers.
	3. Every 3 seconds.

--* Log Writer (LGWR)
	Process Name: LGWR
	Max Processes: 1
	**> The log writer process writes data from the redo log buffers to the redo log files on disk.

	The writer is activated under the following conditions:
	1. When a transaction is committed, a System Change Number (SCN) is generated and tagged to it. Log writer puts a commit 
	   record in the redo log buffer and writes it to disk immediately along with the transactions redo entries. Changes to actual data 
	   blocks are deferred until a convenient time (Fast-Commit Mechanism).
	2. Every 3 seconds.
	3. When the redo log buffer is 1/3 full.
	4. When DBWn signals the writing of redo records to disk. All redo records associated with changes in the block buffers must be 
	   written to disk first (The write-ahead protocol). While writing dirty buffers, if the DBWn process finds that some redo information has 
	   not been written, it signals the LGWR to write the information and waits until the control is returned.

--* Checkpoint Process (CKPT)
	Process Name: CKPT
	Max processes: 1
	**> Checkpoint process signals the synchronization of all database files with the checkpoint information. It ensures data consistency and faster database 
		recovery in case of a crash.

	CKPT ensures that all database changes present in the buffer cache at that point are written to the data files, the actual writing is done by the Database Writer 
	process. The datafile headers and the control files are updated with the latest SCN (when the checkpoint occurred), this is done by the log writer process.

	The CKPT process is invoked under the following conditions:
	1. When a log switch is done.
	2. When the time specified by the initialization parameter LOG_CHECKPOINT_TIMEOUT exists between the incremental checkpoint and the tail of the log; 
	   this is in seconds.
	3. When the number of blocks specified by the initialization parameter LOG_CHECKPOINT_INTERVAL exists between the incremental checkpoint and the 
	   tail of the log; these are OS blocks.
	4. The number of buffers specified by the initialization parameter FAST_START_IO_TARGET required to perform roll-forward is reached.
	5. Oracle 9i onwards, the time specified by the initialization parameter FAST_START_MTTR_TARGET is reached; this is in seconds and specifies the time 
	   required for a crash recovery. The parameter FAST_START_MTTR_TARGET replaces LOG_CHECKPOINT_INTERVAL and FAST_START_IO_TARGET, but these parameters can 
	   still be used.
	6. When the ALTER SYSTEM SWITCH LOGFILE command is issued.
	7. When the ALTER SYSTEM CHECKPOINT command is issued.


-- Transaction Rollback
When a transaction makes changes to a row in a table, the old image is saved in the rollback segment. If the transaction is rolled back, the 
value in the rollback segment is written back to the row, restoring the original value.

--When we need to rebuild indexes?
� Move an index to a different tablespace
� Improve space utilization by removing deleted entries
� When the index becomes unbalanced/skewed
� Change a reverse key index to a normal B-tree index and vice versa



--Memory allocation per session:
SELECT 
    NVL(a.username,�(oracle)�) AS username,
    a.module,a.program,Trunc(b.value/1024) AS memory_kb
FROM v$session a, v$sesstat b, v$statname c
WHERE a.sid = b.sid AND    b.statistic# = c.statistic#
  AND c.name = �session pga memory� AND    a.program IS NOT NULL
ORDER BY b.value DESC; 


--Monitor session details:
SELECT s.sid, s.status, s.process, s.schemaname,  s.osuser, a.sql_text, p.program 
  FROM v$session s, v$sqlarea a, v$process p
 WHERE s.SQL_HASH_VALUE = a.HASH_VALUE
   AND s.SQL_ADDRESS = a.ADDRESS
   AND s.PADDR = p.ADDR

 
---> Logging and NoLogging Options   
Redo generation is a vital part of the Oracle recovery mechanism. Without it, an instance
will not recover when it crashes and will not start in a consistent state. Excessive redo
generation is the result of excessive work on the database.

The main benefits of the NOLOGGING option
* Space is saved in the redo log files
* The time it takes to create the table is decreased
* Performance improves for parallel creation of large tables
   
It is even more deep then that.  For example:

Table Mode    Insert Mode     ArchiveLog mode      result
-----------   -------------   -----------------    ----------
LOGGING       APPEND          ARCHIVE LOG          redo generated
NOLOGGING     APPEND          ARCHIVE LOG          no redo
LOGGING       no append       ""                   redo generated
NOLOGGING     no append       ""                   redo generated
LOGGING       APPEND          noarchive log mode   no redo
NOLOGGING     APPEND          noarchive log mode   no redo
LOGGING       no append       noarchive log mode   redo generated
NOLOGGING     no append       noarchive log mode   redo generated
-------------------------------------------------------------------------------------------------------------------------



-- Related Temporary Tablespace

Use V$TEMPSEG_USAGE to monitor usage of the temp tablespace.

Note that as the usage grows, extents are allocated to the temporary segment. They do NOT shrink (or deallocate) when usage falls. 
The Temporary segment always remains at the highest achieved size. So the 75GB "usage" for the tablespace that you see would have been 
the peak usage. Usage would only shrink when you shutdown and restart the instance (or if you create and designate a new temporary tablespace 
and drop the existing one).

select *
from V$TEMPSEG_USAGE;

-- The following script will display all TEMP space usage for objects involved with global temporary tables (GTT);
select username, contents, segtype, extents, blocks
from v$tempseg_usage 
where segtype = 'DATA' 
  and contents = 'TEMPORARY' 
order by username;

-- This query will display all �current� SQL (still in the library cache, and the TEMP space used by the SQL: 
SELECT 
    s.sid, 
   s.username, 
   u.tablespace, 
   s.sql_hash_value||'/'||u.sqlhash hash_value, 
   u.segtype, 
   u.contents, 
   u.blocks
FROM 
    v$session s, 
   v$tempseg_usage u
WHERE 
   s.saddr=u.session_addr
order by 
   u.blocks;
   
   
select b.Total_MB,
       b.Total_MB - round(a.used_blocks*8/1024) Current_Free_MB,
       round(used_blocks*8/1024) Current_Used_MB,
       round(max_used_blocks*8/1024) Max_used_MB
from v$sort_segment a,
 (select round(sum(bytes)/1024/1024) Total_MB from dba_temp_files ) b;
 
-------------------------------------------------------------------------------------------------------------------------

-- RAM Allocation for Oracle DB Servers, to handle the Swap space

If you have 12 GB ram than you need

Between 1 GB and 2 GB -- >> Swap Space Required 1.5 times the size of the RAM
Between 2 GB and 16 GB -- >> Swap Space Required Equal to the size of the RAM
More than 16 GB -- > > Swap Space Required 16 GB 

-------------------------------------------------------------------------------------------------------------------------

-- INITRANS
The INITRANS setting controls Initial Transaction Slots (ITLs). A transaction slot is required for any session that needs to 
modify a block in an object. For tables INITRANS defaults to 1 for indexes, 2.

The MAXTRANS setting controls the maximum number of ITLs that a block can allocate (usually defaults to 255). If a block is 
sparsely populated then Oracle will dynamically increase the number of ITLs up to MAXTRANS.

However, if the block has little or no free space then transactions will serialize waiting on a free ITL
This is one cause for data base block waits. By setting INITRANS to the number of expected simultaneous DML (data manipulation language ? insert, 
update and delete) transaction for a single block, you can avoid serialization for ITL slots.

The maximum value suggested for INITRANS is 100 and settings over this size rarely improve performance. Therefore a setting of INITRANS to 
the average number of simultaneous DML users and setting MAXTRANS to 100 will most likely result in the best utilization of resources and 
performance. Remember, each ITL requires approximately 23 bytes in the block header.



------------------------------------------------------------------------------------------------------------------------- 


If we use ALTER TABLE/INDEX to change the value of INITRANS, it will affect only the NEW BLOCKS (From Oracle Documentation). So, it will not affect or change INITRANS for the existing DATA BLOCKS/INDEX BLOCKS


Generally speaking FREELIST groups are used in Oracle real application clusters where the setting should be equal to the number of nodes (instances) participating in the cluster. FREELISTS should be set to the number of simultaneous DML users for the table (not the block!), tables default to 1 FREELIST and 0 FREELIST GROUPS.

Again, settings of greater than 100 rarely result in better performance for FREELISTS. Also, tables will, by default, extend based on the minimum allowed extension times the number of FREELISTS so be aware of this when setting FREELISTS.




Freelists, Free list groups






