

--- Productio reboot activity

1) Login to goldengate of TW Node1
	-- Stop the pumps from DCW primary site which are replicating on DCE backup site
	stop PPTWRE -- replicating to RE
	stop PPTWTE	-- replicating to TE

-- When RE Cluster required to reboot
2) Login to goldengate of RW Node1
	STOP PPRWRE -- replicating to RE from RW

3) Login to goldengate TE 
	-- stop the DCE goldengate processes
	1) stop  EPTE  
	2) stop RPTETW01
  
	-- Rest TE pumps are already stopped and which should remain stopped
	1) Already stopped PPTERE  
	2) Already stopped PPTERW  
	3) Already stopped PPTETW  

4) Login to goldengate RE
	1) stop EPRE    
	2) stop RPRERW  
 	3) stop RPRETE01
 	4) stop RPRETW01
 	
 	-- Rest RE pumps are already stopped and which should remain stopped
 	1) Already stopped PPRERW  

5) Login to oracle user and stop xag utility
	/opt/app/oracle/xag/bin/agctl stop goldengate gg_erpt / gg_etxn
	
	-- Once the Node 1 is rebooted, to start xag utility on Node 1
	/opt/app/oracle/xag/bin/agctl start goldengate gg_erpt / gg_etxn
	OR
	/opt/app/oracle/xag/bin/agctl start goldengate gg_extn --node epl1trandbtxn1

6) Login to oracle user and stop vip resource of goldengate from node 1 epl1trandbtxn1
	crsctl stop resource e-txn-ggatevip.tsysacquiring.org -n epl1trandbtxn1

-- below commands can be required in case of any help
crsctl relocate resource e-txn-ggatevip.tsysacquiring.org -n epl1trandbtxn1	
crsctl status resource e-txn-ggatevip.tsysacquiring.org
crsctl stop resource e-txn-ggatevip.tsysacquiring.org
crsctl start resource e-txn-ggatevip.tsysacquiring.org -n epl1trandbtxn1


7) Login to oracle stop Instance of Node 1
	 srvctl stop instance -d transittxnga -i transitt1
	 
	 srvctl stop instance -d transittxnga -i transitt2
	 srvctl stop instance -d transittxnga -i transitt3
	 
	 -- Once the Node 1 is back online, check the instance is started or not, if not then here is command
	 srvctl start instance -d transittxnga -i transitt1
	 srvctl start instance -d transittxnga -i transitt2
	 srvctl start instance -d transittxnga -i transitt3

8) Login to root user to stop cluster crs running on node 1 (Reboot DB servers one by one)
	/opt/app/11.2.0/grid_1/bin/crsctl stop cluster -n epl1trandbtxn1
	
	/opt/app/11.2.0/grid_1/bin/crsctl stop cluster -n epl1trandbtxn2
	/opt/app/11.2.0/grid_1/bin/crsctl stop cluster -n epl1trandbtxn3

	-- When Node will reboot, it will automatically restart the crs