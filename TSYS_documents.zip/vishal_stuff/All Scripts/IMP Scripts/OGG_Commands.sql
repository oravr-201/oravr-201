--- All Commands of GoldenGate


---------------------------------------------------------------------------------
-- INFO	
INFO MANAGER -- Provides details of the Manager process
INFO MGR -- Also provides details of the Manager process

---------------------------------------------------------------------------------
-- STATUS
STATUS MANAGER -- This command also display the info of manager

--->> It is used to check whether extract process is currently running or not.
STATUS EXTRACT e_src -- To check the status for extract "E_SRC"
STATUS EXTRACT e* -- To check the status for all extracts starting with "e"

--->> It is used to find whether replicat is running or not
STATUS REPLICAT r_trg -- To check the status for replicat "r_trg"
STATUS REPLICAT r*	-- To check the status for all replicat starting with "r"

---------------------------------------------------------------------------------
-- REFRESH	Command
REFRESH MANAGER -- Reloads from the Manager Parameter file
REFRESH MGR	 -- Reloads from the Manager Parameter file

---------------------------------------------------------------------------------
-- SEND	
SEND MANAGER CHILDSTATUS -- Displays status of processes, started by Manager.
SEND MANAGER CHILDSTATUS DEBUG	-- Return the ports numbers allocated by the Manager
SEND MANAGER GETPORTINFO -- Displays the list of currently allocated ports by Manager process
SEND MANAGER GETPORTINFO DETAIL -- Provides info on ports and process assigned to them.
SEND MANAGER GETPURGEOLDEXTRACTS -- Retrieves trail purge retention info.

--->> It is used to communicate with the running extract like sending requests for report creation, stats, to force extract to rollover to next trail etc
SEND EXTRACT finance, ROLLOVER	-- To increment the extract to next file in trail
SEND EXTRACT finance, STOP -- To stop the extract process
SEND EXTRACT finance, TRANLOGOPTIONS TRANSCLEANUPFREQUENCY 20 -- For the Oracle RAC, specify the time after which the OGG scan and delete the orphan transactions
SEND EXTRACT finance, SKIPTRANS 5.17.27634 THREAD 2	-- For skipping the transaction in the Oracle RAC environment
SEND EXTRACT e_src, SHOWTRANS	-- Display the info about the open transactions like checkpoint, extract group name, SCN, Redo log and RB, status etc
SEND EXTRACT e_src, SHOWTRANS COUNT 2	-- Display the info for two transactions only

--->> It is used to communicate with the running replicat process
SEND REPLICAT r_trg, HANDLECOLLISIONS --Enable the handlecollisions option of OGG used for error handling
SEND REPLICAT r_trg, REPORT HANDLECOLLISIONS r_*	-- Generate statical report to replicat report file
SEND REPLICAT r_trg, GETLAG	-- Get the lag info in seconds

---------------------------------------------------------------------------------
-- STATS Command	
--->> It is used to display the stats for the extract process including the DDL and DML operations.
STATS e_src	
STATS EXTRACT e_src	-- stats will be displayed for the extract E_SRC""
STATS EXTRACT e_src REPORTRATE SEC	-- display the stats for the fetch opertions per sec
STATS EXTRACT e_src, TOTAL, DAILY	-- The total stats is shown since the start of the day
STATS EXTRACT e_src, TOTAL, HOURLY, REPORTRATE MIN, RESET, REPORTFETCH	-- By using comma between the keywords multiple options can be used for the stats command

--->> It is used to display the stats for the replicat process.
STATS r_trg	
STATS REPLICAT r_trg -- stats will be displayed for the REPLICAT r_trg""
STATS REPLICAT r_trg REPORTDETAIL SEC	-- display the stats for the opertaion that were not replicated due to errors
STATS REPLICAT r_trg, TOTAL, DAILY	-- The total stats is shown since the start of the day
STATS REPLICAT r_trg, TOTAL, HOURLY, REPORTRATE MIN, RESET, NOREPORTDETAIL	-- By using comma between the keywords multiple options can be used for the stats command

---------------------------------------------------------------------------------
-- START Command
--->> it is used to start manager/mgr process
START MANAGER	-- Starts the Manager Process
START MGR	-- Starts the Manager Process

--->> It is used to start the Extract process
START EXTRACT e_src	

--->> It is used to start the replicat process
START REPLICAT r_trg	
START REPLICAT r_trg, ATCSN 6454388	   -- To start the replicat process from the oracle-specific CSN number including the CSN no transaction
START REPLICAT r_trg, AFTERCSN 6454389 -- To start the replicat process from the oracle-specific CSN number, but ignoring that CSN no transaction

---------------------------------------------------------------------------------
-- STOP	
STOP MGR	Stops the Manager Process
STOP MANAGER !	-- Stops Manager without asking for user confirmation.
STOP MGR !	-- Stops Manager without asking for user confirmation.

--->> It is used to stop the running extract process
STOP EXTRACT e_src	-- To stop the extract "e_src"
STOP EXTRACT e*	-- To stop all of the running extract process whose name start with "e"
STOP EXTRACT *	-- To stop all of the running extract processes

--->> It is used to stop the running replicat process
STOP REPLICAT r_trg	-- To stop the replicat "r_trg"
STOP REPLICAT r*	-- To stop all of the running replicat process whose name start with "r"
STOP REPLICAT *	-- To stop all of the running replicat processes

---------------------------------------------------------------------------------
-- ADD Command	
--->>  It is used to Creates an Extract group.
ADD EXTRACT E_SRC, Tranlog, Begin Now	-- Used to specify transaction logs as data source for extract.
ADD EXTRACT E_SRC, Begin Now, Passive	-- Specifies the extract to be run in passive mode.
ADD EXTRACT E_SRC, Extseqno 000008 Extrba 287458, Begin Now	-- Specifies the extract process starting position
ADD EXTRACT E_SRC, SOURCEISTABLE	-- Extracts data from data tables for initial loading.

--->> It is used to create the replicat process by creating checkpoints
ADD REPLICAT INITLOAD, SPECIALRUN	-- It will create a special run replicat as task.
ADD REPLICAT r_trg, EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TT	-- Create the replicat with the trail
ADD REPLICAT r_trg, EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TT, CHECKPOINTTABLE OGG_USER.OGG_CHECKPOINT	-- Create the replicat with the trail and the checkpoint info like the DB table used to save checkpoint info.
ADD REPLICAT r_trg, EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TT, NODBCHECKPOINT	-- Create the replicat with the trail and specifying that this replicat did not write info to DB table

--->> It is used to create the local trail file for extract process on local system
ADD EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE, EXTRACT e_src, MEGABYTES 100	-- Create EXTTRAIL with the Prefix"SE", and the size of 100 mb
ADD EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE000009	-- To create the EXTTRAIL with specific sequence number
ADD RMTTRAIL	-- It is used to create the remote trail files for the extract or pump processes on remote systems
ADD RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TE, EXTRACT p_src, MEGABYTES 100	-- Create RMTTRAIL with the Prefix"TE", and the size of 100 mb
ADD RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE000009	-- To create the RMTTRAIL with specific sequence number

---------------------------------------------------------------------------------
-- ALTER Command	
ALTER EXTRACT e_src, BEGIN NOW	-- Instructs extract to start processing
ALTER EXTRACT e_src, BEGIN 2013-04-16	-- Instructs extract to start processing from specific date
ALTER EXTRACT e_src, ETROLLOVER	-- Extract rolls over to next trail file
ALTER EXTRACT e_src, EXTSEQNO 01, EXTRBA 2887	-- Alters extract to start from the specific locaton in the trail
ALTER EXTRACT e_src, THREAD 4, BEGIN 2012-03-09	-- Alters extract thread & start date for RAC
ALTER EXTRACT e_src, LSN 1234:123:1	-- Altering extract for the SQL Server

--->> It is used to change the properties of the existing replicat process
ALTER REPLICAT r_trg, BEGIN NOW	 -- Alter replicat to start processing from now
ALTER REPLICAT r_trg, BEGIN 2013-05-11	-- Alter replicat to start processing from specific date
ALTER REPLICAT r_trg, BEGIN 2013-01-07 08:00:01	-- Alter replicat to start processing from specific date and time
ALTER REPLICAT r_trg, EXTSEQNO 00007	-- Alter replicat to start from the specific trail file
ALTER REPLICAT r_trg, EXTRBA 65477	-- Alter replicat to start from the specific location in the trail

ALTER EXTTRAIL	-- It is used to change the options of the existing EXTTRAIL file for extract process on local system
ALTER EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE, EXTRACT e_src, MEGABYTES 50	

ALTER RMTTRAIL	-- It is used to change the options of the existing RMTTRAIL file of extract or pump processes on remote systems
ALTER RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TE, EXTRACT p_src, MEGABYTES 50	

---------------------------------------------------------------------------------
-- CLEANUP Command	
--->> It is used to clear the run history for the specific extract group
CLEANUP EXTRACT e_src	-- It purges all history of records except last
CLEANUP EXTRACT e_src, SAVE 10	-- It saves last 10 records and deletes all other

--->> It is used to clear the run history for the specific replicat process
CLEANUP REPLICAT r_trg	-- It purges all history of records except last
CLEANUP REPLICAT r_trg, SAVE 10	-- It saves last 10 records and deletes all other

---------------------------------------------------------------------------------
-- DELETE Command	
--->> It is used to delete the extract process, its checkpoints detail and unregister the extract group.
DELETE EXTRACT e_src --	deletes the extract process
DELETE EXTRACT e*	-- deletes all extract process whose name starts with e
DELETE EXTRACT e* !	-- deletes all extract process whose name starts with e without prompting

--->> It is used to delete the replicat process, by removing the checkpoints and freeing trail file for purging by manager. But the process must be stopped and user must be logged in using DBlogin command
DELETE REPLICAT r_trg -- deletes the replicat process

DELETE EXTRACT r* -- deletes all replicat process whose name starts with r
DELETE EXTRACT r* ! -- deletes all replicat process whose name starts with r without prompting

DELETE EXTTRAIL	 -- It is used to delete the exttrail assigned to the extract on local system by deleting its references from checkpoint file
DELETE EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE	

DELETE RMTTRAIL	 -- It is used to delete the exttrail for the extract or pump on remote system by deleting its references from checkpoint file
DELETE RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TE	

---------------------------------------------------------------------------------
-- INFO Command	
--->> It is used to display the info of the extract like its status, lag, checkpoint, run history, trail info etc
INFO EXTRACT e_src, SHOWCH	-- Display checkpoint info of extract
INFO EXTRACT e_src, DETAIL	-- Display trail info, run history
INFO EXTRACT e_src, TASKS	-- Display extract tasks

--->> It is used to display the replicat info like processing history, status, appox lag, trail info, checkpoint info and environment of replicat.
INFO REPLICAT *, TASKS	-- It is used to display replicat tasks only.
INFO REPLICAT r_trg	-- It is used to display the information of replicat.
INFO REPLICAT r_trg, DETAIL	-- It display the detailed information of replicat.
INFO REPLICAT r_trg, SHOWCH	-- It displays the checkpoint table information, from checkpoint file and checkpoint table.

--->> It is used to display the info of local trail like name, associated extract, rba and file size etc
INFO EXTTRAIL /ORACLE/GOLDENGATE/DIRDAT/SE	-- Display info for specific exttrails
INFO EXTTRAIL *	-- Display info for all exttrails

INFO RMTTRAIL	-- It is used to display the info of remote trail like name, associated extract, rba and file size etc
INFO RMTTRAIL /ORACLE/GOLDENGATE/DIRDAT/TE	-- Display info for specific rmttrails
INFO RMTTRAIL *	-- Display info for all rmttrails

---------------------------------------------------------------------------------
-- KILL Command	
--->> It is used to kill the extract that can not be stopped with STOP Command""
KILL EXTRACT e_src	

--->> It is used to kill the replicat that can not be stopped with "STOP Command", but checkpoint info remain unchanged and transactions are rolled back in DB
KILL REPLICAT r_trg	

---------------------------------------------------------------------------------
-- LAG Command	
--->> It is used to find the lag time between Extract and data source more precisely than the "INFO Command"
LAG EXTRACT e_src	-- To find lag for extract "e_src"
LAG EXTRACT *	-- To find lag for all of the extract processes

--->> It is used to find the lag time between Replicat and trail more precisely than the "INFO Command"
LAG REPLICAT r_trg	-- To find lag for replicat "r_trg"
LAG REPLICAT *	-- To find lag for all of the replicat processes

---------------------------------------------------------------------------------
-- REGISTER Command	
--->> It is used to register the extract process, so that it can retain the archive logs required for its recovery.
REGISTER EXTRACT e_src LOGRETENTION	-- To register extract "e_src"

---------------------------------------------------------------------------------
-- UNREGISTER Command	
--->> it is used to unregister the extract group by removing its registration from oracle DB.
UNREGISTER EXTRACT e_src LOGRETENTION	-- To unregister the extract e_src""

---------------------------------------------------------------------------------
-- ER Commands	
--->> They are used to control the multiple extract and replicat processes
INFO ER *	-- To info all of the process

KILL ER *	-- To kill all of the process

LAG ER *	-- To get lag info of all the process

SEND ER *	-- To use send command on all of the process

START ER *	-- To start all of the process

STATS ER *	-- To check the stats all of the process

STATUS ER *	-- To find status of all the process

STOP ER *	-- To stop all of the process

---------------------------------------------------------------------------------
-- VIEW REPORT Command
VIEW REPORT e_src -- To view the report of extract
VIEW REPORT p_src -- To view the report of extract pump process 

VIEW REPORT r_tag -- To view the report of replicat

VIEW GGSEVT -- Viewing the GoldenGate error log,similar shell tail -f ggserr.log







