-- check the configured instance for the database
select inst_id, instance_name, status, to_char(startup_time, 'DD-MON-YYYY HH24:MI:SS') as "START_TIME"
from gv$instance 
order by inst_id;

# Public IPs
10.100.224.193  loadrpdbnode1.tsysacquiring.org loadrpdbnode1
10.100.224.194  loadrpdbnode2.tsysacquiring.org loadrpdbnode2
10.100.224.195  loadrpdbnode3.tsysacquiring.org loadrpdbnode3

# Private IPs
10.100.226.91    loadrpdbnode1-priv.tsysacquiring.org loadrpdbnode1-priv
10.100.226.92    loadrpdbnode2-priv.tsysacquiring.org loadrpdbnode2-priv
10.100.226.93    loadrpdbnode3-priv.tsysacquiring.org loadrpdbnode3-priv

# Virtual IPs
10.100.224.196  loadrpdbnode1-vip.tsysacquiring.org loadrpdbnode1-vip
10.100.224.197  loadrpdbnode2-vip.tsysacquiring.org loadrpdbnode2-vip
10.100.224.198  loadrpdbnode3-vip.tsysacquiring.org loadrpdbnode3-vip




cluvfy stage -pre crsinst -n loadrpdbnode1,loadrpdbnode2,loadrpdbnode3 -fixup -verbose


-- There where no service created/configured for rptDCE instance, so delete directly
dbca -silent -deleteInstance -nodeList loadrpdbnode1 -gdbName rptDCE -instanceName rptDCE1 -sysDBAUserName sys -sysDBAPassword Tsys$1234


Step 1: -- check if any services are present for the removing Node1 or deleting database instance

-- As there where services configured for txnDCE database instance, so they were needt modify
-- below steps are taking care of it

-- Stop the service running
srvctl stop service -d txnDCE -s transittxn

-- remove the required service from required instance, the instance which needs to be deleted
srvctl remove service -d txnDCE -s transittxn -i txnDCE1

-- add the service for other instance to point
srvctl add service -d txnDCE -s transittxn -r txnDCE2,txnDCE3 -P BASIC

-- configure the service
srvctl config service -d txnDCE -s transittxn

-- modify the service
srvctl modify service -d txnDCE -s transittxn -e select -m BASIC -z 180 -w 5 -j LONG -q TRUE

-- start the service
srvctl start service -d txnDCE -s transittxn

step 2: -- start vncserver
-- on linux window
vncserver :1

login to vncserver to port :1

step 3: -- remove database instance using dbca (GUI)
on vncserver window
open the terminal window
dbca
|
|>> 
	|NEXT Button
	|
	|>> Click on "Instance Management"
	 	 |NEXT Button
	 	 |
	 	 |>> click on "Delete an Instance"
	 	 	 | NEXT Button
	 	 	 |
	 	 	 |>> select Instance that you want to delete, By specifing a sysdba provileged user name and password
	 	 	 	 |NEXT Button
	 	 	 	 |
	 	 	 	 |>> select the node and instance name you would like to delete
	 	 	 	 |NEXT Button
	 	 	 	 |>> Finish -- It will start deleting the instance from the said node

Step 4: -- check in the database, if the instance has been clearly removed

export ORACLE_SID=txnDCE2

and also on 

export ORACLE_SID=rptDCE2


sqlplus / as sysdba
-- check the configured instance by the below sql query
select inst_id, instance_name, status, to_char(startup_time, 'DD-MON-YYYY HH24:MI:SS') as "START_TIME"
from gv$instance 
order by inst_id;


step 5: -- check the configuration of database, those should not list the name of deleted Node
srvctl config database -d txnDCE -v
srvctl config database -d rptDCE -v


Step 6: -- check if the redo log thread, redolog members and undo tablespace are present for removing Node, if so then remove the records for them from database
select thread# from v$thread where upper(instance) = upper('txnDCE1');
select group# from v$log where thread# = 3;
select member from v$logfile where group# in (5,6);

alter database disable thread 3;

alter database drop logfile group 5;

alter database drop logfile group 6;

drop tablespace UNDOTBS1 including contents and datafiles;

alter system reset undo_tablespace scope=spfile sid = 'txnDCE1';

alter system reset instance_number scope=spfile sid = 'txnDCE1';


Step 7: -- Remove the listener if configured for removing Node
-- check the listener
srvctl config listener -a

-- if any listener is configured then remove it
srvctl disable listener -l listener_scan1 -n loadrpdbnode1

srvctl stop listener -n loadrpdbnode1

Step 8: -- stop vip services
srvctl stop  vip -i loadrpdbnode1

srvctl stop vip -i loadrpdbnode1-vip -f
srvctl remove vip -i loadrpdbnode1-vip -f

-- Command of Step 1 thru Step 8 are been executed on other Node which is part of Cluster. This can be execute on same node if your cluster software is not having any issues and which is up and running..

Step 9: -- Update the oracle inventory, for Node being removed
-- as the oracle software owner..

-- On a node to be removed login as oracle user and run the following command from $ORACLE_HOME/oui/bin.
cd $ORACLE_HOME/oui/bin

-- Make sure to specify the -local flag as to not update the inventory on all nodes in the cluster.
./runInstaller -updateNodeList ORACLE_HOME=$ORACLE_HOME "CLUSTER_NODES={loadrpdbnode1}" -local


Step 10: -- deinstall ORACLE_HOME and GRID_HOME software from removing Node by using -local keyword

-- Run deinstall with option -local from $ORACLE_HOME/deinstall from the node to be removed (loadrpdbnode1) in order to remove the RDBMS binaries.

-- Make sure to specify the -local flag as to not remove more than just the local node's software. 
-- If -local is not specified then deinstall would apply to the entire cluster.
/opt/app/oracle/product/11.2.0/db_4/deinstall/./deinstall -local


Step 11: -- Update Oracle Inventory on all other Remaining Nodes which are still part of cluster
-- connect to the working node of the cluster

cd $ORACLE_HOME/oui/bin

-- run the command for those remaining node
./runInstaller -updateNodeList ORACLE_HOME=$ORACLE_HOME "CLUSTER_NODES={loadrpdbnode2,loadrpdbnode3}"


Step 12: -- Remove Node from clusterware (GRID Software). Most of the commands will be execute from root access
-- login to root user
export GRID_HOME=/opt/app/11.2.0/grid4/bin

-- Run the following command as root to determine whether the node you want to delete is active and whether it is pinned.
$GRID_HOME/olsnodes -s -t

-- If the node being removed is already unpinned then you do not need to run the "crsctl unpin css" command below and can proceed to the next step.

-- If the node being removed is pinned with a fixed node number, then run the crsctl unpin css command as 
-- root from a node that is to remain a member of the Oracle RAC in order to unpin the node and expire the CSS lease on the node you are deleting.

$GRID_HOME/crsctl unpin css -n loadrpdbnode1

Step 13: -- Disable Oracle Clusterware

-- Next, disable the Oracle Clusterware applications and daemons running on the node to be deleted from the cluster. 
-- Run the rootcrs.pl script as root from the $GRID_HOME/crs/install directory on the node to be deleted.

/opt/app/11.2.0/grid4/crs/install/./rootcrs.pl -deconfig -force

Step 14: -- Delete Node from Clusterware Configuration
-- From a node that is to remain a member of the Oracle RAC Clusterware, run the following command from the $GRID_HOME/bin directory 
-- as root to update the Clusterware configuration to delete the node from the cluster.
 /opt/app/11.2.0/grid4/bin/crsctl delete node -n loadrpdbnode1
 
 /opt/app/11.2.0/grid4/bin/olsnodes -t -s
 
 Step 15: -- Update GRID Inventory from Node Being Removed
 
  -- Execute on the node being removed to update the inventory, run as the oracle GRID Infrastructure owner
  -- Make sure to specify the -local flag as to not update the inventory on all nodes in the cluster.
 /opt/app/11.2.0/grid4/oui/bin/./runInstaller -updateNodeList ORACLE_HOME=/opt/app/11.2.0/grid4 "CLUSTER_NODES={loadrpdbnode1}" CRS=TRUE -local
 
 
 Step 16: -- De-install Oracle Grid Infrastructure Software
 -- When using a non-shared Grid home, run deinstall as the Grid Infrastructure software owner (Oracle) from the node to be removed 
 -- in order to delete the Oracle Grid Infrastructure software.
  
 /opt/app/11.2.0/grid4/deinstall/./deinstall -local
 
-- NOTE: the above command will asked to run some commands so check that one..
 
 
 
 Step 17: -- Remove specified files as root:

-- This has to run on the removing Node
rm -rf /etc/oraInst.loc
rm -rf /opt/ORCLfmap
rm -rf /opt/app/11.2.0/grid4
rm -rf /opt/app/oracle/product/11.2.0/db_4

Step 18: -- Verify Cluster Configuration
-- Run the following CVU command to verify that the specified node has been successfully deleted from the cluster.
cluvfy stage -post nodedel -n loadrpdbnode1 -verbose
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 