

-- Below are the steps for Adding Node which was deleted to clear the existing Install software errors..

-- Add same Node which was deleted

-- check if nslookup is happening for the hostname and it's private, public and vip hostnames
nslookup loadrpdbnode1.tsysacquiring.org

-- Add the folder -- CRS (GRID Home)
mkdir /opt/app/11.2.0/grid4
chown oracle /opt/app/11.2.0/grid4
chgrp -R oinstall /opt/app/11.2.0/grid4

-- Create the new RDBMS (Oracle) directory  
mkdir /opt/app/oracle/product/11.2.0/db_4/
chgrp -R oinstall /opt/app/oracle/product/11.2.0/db_4/
chown oracle /opt/app/oracle/product/11.2.0/db_4

-- check if all pre and post installation are prefect for the Node
cluvfy stage -post hwos -n loadrpdbnode1

cluvfy stage -pre crsinst -n loadrpdbnode1,loadrpdbnode2,loadrpdbnode3

-- this rpm package will required to copy the software from one Node to other.. will have to install this by copy from existing Node.
-- install it from root user
/opt/app/oracle/product/11.2.0/db_4/cv/rpm/cvuqdisk-1.0.9-1.rpm

-- check the pre node add with given fixup if any
cluvfy stage -pre nodeadd -n loadrpdbnode1 -fixup -verbose

-- check the init parameter cluster database instance, if its same as current node count then insrease it
alter system set cluster_database_instances=3 scope=spfile;

-- You will execute the addNode.sh script to install the Oracle Grid Infrastructure software on the new node. 
-- The script cannot proceed unless all the pre-requisites checks are successful. In our case, since we are getting 
-- the PRVF-5449 messages, we will set the IGNORE_PREADDNODE_CHECKS variable to bypass the node addition pre-check.
export IGNORE_PREADDNODE_CHECKS=Y

-- to execute to add the node in clusterware, this is for CRS adding (GRID software)
cd $GRID_HOME/oui/bin

./addNode.sh -silent "CLUSTER_NEW_NODES={loadrpdbnode1}" "CLUSTER_NEW_VIRTUAL_HOSTNAMES={loadrpdbnode1-vip}" "CLUSTER_NEW_PRIVATE_NODE_NAMES={loadrpdbnode1-priv}"

-- If the above command is giving below error, then 
Error ocurred while retrieving node numbers of the existing nodes. Please check if clusterware home is properly configured.
SEVERE:Error ocurred while retrieving node numbers of the existing nodes. Please check if clusterware home is properly configured.

-- Then below steps are to be performed on all of the existing nodes (which is in clusterware) for safer side
cd $GRID_HOME/oui/bin
-- /opt/app/11.2.0/grid4/oui/bin
$GRID_HOME/oui/bin/./runInstaller -updateNodeList ORACLE_HOME='/opt/app/11.2.0/grid4' "CLUSTER_NODES={loadrpdbnode2,loadrpdbnode3}" CRS=TRUE

cd $ORACLE_HOME/oui/bin
-- /opt/app/oracle/product/11.2.0/db_4
$ORACLE_HOME/oui/bin/./runInstaller -updateNodeList ORACLE_HOME='/opt/app/oracle/product/11.2.0/db_4' "CLUSTER_NODES={loadrpdbnode1,loadrpdbnode2,loadrpdbnode3}" CRS=TRUE

/* If the inventroy is not removed propurly while deleting the node the you will have to apply -local option in all the nodes and execute the below command.

/opt/app/11.2.0/grid4/oui/bin/./runInstaller -updateNodeList ORACLE_HOME='/opt/app/11.2.0/grid4' "CLUSTER_NODES={loadrpdbnode2,loadrpdbnode3}" CRS=TRUE -local

/opt/app/oracle/product/11.2.0/db_4/oui/bin/./runInstaller -updateNodeList ORACLE_HOME='/opt/app/oracle/product/11.2.0/db_4' "CLUSTER_NODES={loadrpdbnode2,loadrpdbnode3}" CRS=TRUE -local

*/


-- Once the above inventroy related issues/error is resovled then execute the addNode.sh command again on existing rac node
./addNode.sh -silent "CLUSTER_NEW_NODES={loadrpdbnode1}" "CLUSTER_NEW_VIRTUAL_HOSTNAMES={loadrpdbnode1-vip}" "CLUSTER_NEW_PRIVATE_NODE_NAMES={loadrpdbnode1-priv}"

-- At the end of addNode.sh script, it will ask to execute below script on only adding Node. from root user
/opt/app/11.2.0/grid4/root.sh

-- change the write,read  permissions on oraInventory, run it from root
/opt/app/oraInventory/orainstRoot.sh


-- Below are some verification to be performed from oracle to verify the successful of Newly added Node

-- It is best to run the cluvfy command from one of the initial nodes in the RAC. To verify the cluster is integrated and that the new node has been successfully 
-- added to the clusterware
cluvfy stage -post nodeadd -n loadrpdbnode1 -verbose

cluvfy stage -post crsinst -n loadrpdbnode1,loadrpdbnode2,loadrpdbnode3 -verbose

-- check the cluster is up and running from all nodes
crsctl check crs

-- check crs is running from newly added node, this has to be executed on all Nodes, just to verify
crsctl stat res -t

-- check cluster Node added and it's number
olsnodes -n -t

-- check the listener is up-running on newly added Node
ps -ef | grep lsnr | grep -v 'grep' | grep -v 'ocfs' | awk '{print $9}'

-- check asm is up and running on new node
srvctl status asm -a

-- check OCR (Oracle Cluster Registry)
ocrcheck

-- check voting disk
crsctl query css votedisk


-- The next step is to install the Oracle software (RDBMS) on the new node 

-- from oracle home execute the addnode command to add the node
-- this has to be executed from the existing Node, which is present in RAC clusterware
cd $ORACLE_HOME/oui/bin

$ORACLE_HOME/oui/bin/./addNode.sh -silent "CLUSTER_NEW_NODES={loadrpdbnode1}"

-- Error - "SEVERE:The new nodes 'rac2' are already part of the cluster".

-- Analysis - It was picking up same hostname racp2 twice, instead of picking three hostnames (loadrpdbnode1,loadrpdbnode2 and loadrpdbnode3).
-- to clear the error run the below command
$ORACLE_HOME/oui/bin/./runInstaller -updateNodeList ORACLE_HOME="/opt/app/oracle/product/11.2.0/db_4" "CLUSTER_NODES={loadrpdbnode2,loadrpdbnode3}"

-- once the above command is successful 

-- run again addNode for RDBMS Home
export IGNORE_PREADDNODE_CHECKS=Y

$ORACLE_HOME/oui/bin/./addNode.sh -silent "CLUSTER_NEW_NODES={loadrpdbnode1}"

-- runt he root.sh scripts
/opt/app/oracle/product/11.2.0/db_4/root.sh

-- Once it successful


-- Database Configuration Assistant � GUI Method
-- To use the GUI method, log in to one of the active nodes in the existing Oracle RAC as the Oracle owner (oracle) and execute the DBCA.

