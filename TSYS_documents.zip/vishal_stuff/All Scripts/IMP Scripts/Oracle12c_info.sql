
-- What is Pluggable Databases ?
ANS:--> The PDBs are essentially virtual databases running inside a physical database (called a CDB).
	-- All the components of the physical database, the processes, the memory, etc. belong to the CDB; not the PDBs. 


-- In One CDB upto 250 Pluggable databases can be created..

-- Pluggable databases
PDBs do not have an instance (processes and memory) associated with them.


-- get the con_id of the pluggable databases
select con_name_to_id('PDB1') from dual;

-- get the sid/container/database in which you are working in currently
SELECT sys_context('userenv','con_name') MY_CONTAINER FROM dual;

SELECT NAME, CON_ID FROM v$active_services ORDER BY 1;

-- Session Variable:- You can set a session variable called container to the name of the PDB you want to operate on. 
-- First connect to the CDB as usual. 
-- Here is how I connected as the SYSDBA/DBA users: 

-- first connect with normal CDB container database and then swith to any pluggable DB
alter session set container=pdb2;

-- if you want to go back to CDB then use the below command
alter session set container=cdb$root;


-- show command
-- sho or show will work same

-- will display the list of all pluggable databases and information
sho pdbs;

-- select * from v$pdbs -- will also show the same resulte with more details

-- Will display the Current container's ID and Name
sho con_id and sho con_name


--------------------------------------------------------------
-- COMMON USER VS. LOCAL USER � 12C EDITION


-- Common User Points while creating them

-- A COMMON USER is a database user whose identity and password are known in the root (CDB) 
-- and in every (existing/future) pluggable database (PDB). 
1. A COMMON USER can perform administrative tasks that are specific to the CDB or PDB, such as plugging and unplugging a PDB.  
	COMMON USERs are the only ones that can navigate between containers that belong to a CDB.  

2. When creating a COMMON USER account there are specific rules that must be followed:

3. Must be connected to the root and have the commonly granted CREATE USER system privilege

4. The session�s current container must be CDB$ROOT

5. The user name must start with C## or c##

6. Explicitly designate a user account as a common user, specify the CONTAINER=ALL as part of the CREATE USER statement

7. Do not create objects in the schemas of common users.

8. If specifying the DEFAULT TABLESPACE, TEMPORARY TABLESPACE, QUOTA� ON, and PROFILE clauses as part of CREATE USER; then you 
   must ensure that those objects existing in all containers (PDB) below the CDB

9. User-created schema objects owned by COMMON USERS cannot be shared across PDB boundaries

10. While creating a local user, should mention CONTAINER=ALL;

11. COMMON USERS must always be created at the CDB level and start with a C## or c## prefixes

-- create a comman user
alter session set container=cdb$root;

create user c##admin identified by ispl_201 CONTAINER=ALL;

create user c##rchaudhari identified by isplN01805 CONTAINER=ALL;

grant create session to c##rchaudhari container=all;

-- Local User Points while creating them

-- LOCAL USERS are a database user that exists only in a single PDB.  LOCAL USERS can have administrative privileges, 
-- but these privileges are localized to the PDB what the account is created in.  LOCAL USERS have the following characteristics:

1. LOCAL USER accounts cannot create user accounts or commonly grant them privileges.

2. Can grant local user accounts common roles. However, the privileges associated with the common role only apply to the local user�s PDB

3. LOCAL USER account must be unique only within its PDB

4. With the appropriate privileges, a local user can access object in a common user�s schema

5. Can be editions-enable a local user account but not a common user account

6. While creating a local user, should mention CONTAINER = CURRENT;

7. PDB users with the SYSDBA, SYSOPER, SYSBACKUP, or SYSDG privilege can connect to a closed PDB. 
   All other PDB users can only connect when the PDB is open. As with regular databases, the PDB users require the CONNECT 
   SESSION privilege to enable connections.




-- create a local user for pluggable database pdb1
alter session set container=pdb1;

CREATE USER skumbhare
IDENTIFIED BY ispl_201
DEFAULT TABLESPACE pdb1_tbls
QUOTA unlimited on pdb1_tbls1
QUOTA unlimited on pdb1_tbls2
QUOTA unlimited on pdb1_tbls3
TEMPORARY TABLESPACE temp
CONTAINER = CURRENT; 


CREATE USER ggate
IDENTIFIED BY tsys123
DEFAULT TABLESPACE USERS
QUOTA unlimited on USERS
TEMPORARY TABLESPACE temp
CONTAINER = CURRENT; 
-- The local user tnox, will only work for pdb1 DB and not other pluggable DBs



-- this select statm shows the common and local user info.
SELECT CON_ID, COMMON, USERNAME FROM CDB_USERS ORDER BY USERNAME ASC;

GRANT CONNECT,CREATE SESSION,RESOURCE,CREATE VIEW TO SKUMBHARE;

-- CREATE TABLESPACE IN PDB1 DB
CREATE TABLESPACE oggmgmt_tbls DATAFILE   SIZE 5G AUTOEXTEND OFF

CREATE USER oggmgmt IDENTIFIED BY ispl_201 DEFAULT TABLESPACE oggmgmt_tbls TEMPORARY TABLESPACE temp

GRANT CREATE SESSION,RESOURCE TO oggmgmt


--------------------------------------------------------------------------------------
-- Listener (Service Name)

--*** Service Name: (For Stand-alone databases only
When you create a Pluggable Databases, Oracle automatically adds it as a service in the listener. 

lsnrctl services

lsnrctl status


-- For RAC database
-- Adding Services in PDBs
-- Remember, Oracle automatically creates service names in the same name as the PDBs. This lets you connect to 
-- the PDBs directly from the clients using the SERVICE_NAME clause in the TNS connect string. However, 
-- occasionally you may want to add services in the PDBs themselves. To do so you can use the SRVCTL command with 
-- a special parameter "-pdb" to indicate the PDB it should be created in:

srvctl add service -db CONA -s SERV1 -pdb PDB1

srvctl config service -db CONA -s SERV1

-- Remember a very important fact while defining services in PDBs: services are unique in a single CDB. Therefore you 
-- can't create a service called SERV1 in another PDB. However, this is not new rule specific to CDBs or PDBs. If you 
-- had a listener servicing multiple databases in a single server in the prior versions, the service names had to be 
-- unique across all those databases as well. Here is what happens when you try to create this service in 
-- PDB2 which is in the root CDB named CONA:  

[oracle@prosrv1 ~]$ srvctl add service -db CONA -s SERV1 -pdb PDB2

PRKO-3117 : Service SERV1 already exists in database CONA
The service you just created is not started right away. To start it, issue:

[oracle@prosrv1 ~]$ srvctl start service -db CONA -s SERV1

[oracle@prosrv1 ~]$ srvctl status service -db CONA -s SERV1
Service SERV1 is running


--------------------------------------------------------------------------------------
-- TNSNames.ora Entry 

-- You can connect the Pluggable Database by TNSNames.ora entry
sqlplus rchaudhari@pdb1


-- Entry in tnsnames.ora file
pdb1=
(DESCRIPTION=
	(ADDRESS=
		(PROTOCOL=TCP)
		(HOST=wdl1mltidbs01.tsysacquiring.org)
		(PORT=1521)
	 )
	 (CONNECT_DATA=
	 	(SERVICE_NAME=PDB1)
	 )
)

pdb2=
(DESCRIPTION=
	(ADDRESS=
		(PROTOCOL=TCP)
		(HOST=wdl1mltidbs01.tsysacquiring.org)
		(PORT=1521)
	 )
	 (CONNECT_DATA=
	 	(SERVICE_NAME=snox_cpass)
	 )
)

OR

-- direct connection
sqlplus rchaudhari@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=wdl1mltidbs01.tsysacquiring.org)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=pdb1)))"

sqlplus rchaudhari@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=wdl1mltidbs01.tsysacquiring.org)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=pdb2)))"
--------------------------------------------------------------


--------------------------------------------------------------
-- Cloning Pluggable Databases

-- A very important and useful feature of PDBs in a multitenant environment is the ability to clone the PDB quickly 
-- and easily. Let's see an example where I am cloning the PDB1 to another PDB called PDB4:

SQL> create pluggable database pdb4 from pdb1;
Pluggable database created.

-- After the PDB is created, let's check the existence of the datafiles:

SQL> alter session set container = pdb4;
Session altered.

SQL> show con_name
CON_NAME
------------------------------
PDB4

SQL> select name from v$datafile;
NAME
--------------------------------------------------------------------------------
+CONDATA/CONA/DATAFILE/undotbs1.260.807831715
+CONDATA/CONA/D784602E6E8B308FE04380A8840A2F06/DATAFILE/system.281.809621997
+CONDATA/CONA/D784602E6E8B308FE04380A8840A2F06/DATAFILE/sysaux.282.809622005
+CONDATA/CONA/D784602E6E8B308FE04380A8840A2F06/DATAFILE/users.283.809622065
4 rows selected.

-- Oracle Managed Files (OMF) that allows the Oracle Database to determine the location of the files. While it is a good practice, 
-- it's not absolutely necessary. If you use specific locations, and the locations differ on the target PDB, you can use use 
-- file_name_convert clause to let the files be copied to the desired location.

-- If you don't have OMF (Oracle Managed Files DB) then
Create pluggable database pdb4 from pdb1
     Storage ( Maxsize unlimited Max_shared_temp_size unlimited)
     File_name_convert = NONE
     Path_prefix = NONE
     Tempfile reuse;

    
CREATE PLUGGABLE DATABASE PDB4 ADMIN USER pdb5 IDENTIFIED BY ispl_201
  STORAGE (MAXSIZE unlimited MAX_SHARED_TEMP_SIZE unlimited)
  DEFAULT TABLESPACE users 
    DATAFILE '/opt/app/oracle/oradata/cdb1/tnoxsnox/pdb5_01.dbf' SIZE 500M AUTOEXTEND ON
  PATH_PREFIX = '/opt/app/oracle/oradata/cdb1/pdb5/'
  FILE_NAME_CONVERT = ('/opt/app/oracle/oradata/cdb1/pdb1/','/opt/app/oracle/oradata/cdb1/pdb5/')
  Tempfile reuse;
  

-- here you are converting/copying the same type of tablespace and data files from pdbseed which root pdb     

-- Once the pluggable database is created, open it
alter pluggable database pdb4 open;


-- open all at once, except tnoxsnox,snox,tnocpass databases
alter pluggable database all except tnoxsnox,snox,tnocpass open read write;

-- open all PDBs with force option
ALTER PLUGGABLE DATABASE ALL OPEN READ WRITE FORCE;

-- open all PDBs
ALTER PLUGGABLE DATABASE ALL OPEN READ WRITE;
----------------------------------------------------------------------------------

----------------------------------------------------------------------------------
-- STARTUP and SHUTDOWN Pluggable Databases

-- Shutdown
alter session set container=pdb1;

shutdown immediate;

OR


-- alter session set container=cdb$root; (optional -- you can open the PDBs staying within the PDB1 itself or you can change the container to CDB$ROOT and open PDB)
alter Pluggable database pdb1 close;

-- close immediate all at once, except tnoxsnox,snox,tnocpass databases
alter pluggable database all except tnoxsnox,snox,tnocpass close immediate;



-- Pluggable DBs are not shutting down, they remains in MOUNT stage, when CDB database is shutdown all the PDBs will also be shutdown completly

-- Startup
alter session set container=pdb1;

startup

OR 

--alter session set container=cdb$root;
alter Pluggable database pdb1 open;


-- Cloning Pluggable Database
-- Cloning a PDB From an Existing PDB

-- The following statement creates a PDB pdb5 by cloning PDB pdb2. PDBs pdb2 and pdb5 are in the same CDB. 
-- Because no storage limits are explicitly specified, there is no limit on the amount of storage for pdb5. 
-- The files are copied from /opt/app/oracle/oradata/cdb1/pdb2 to /opt/app/oracle/oradata/cdb1/pdb5. 
-- The location of all directory object paths associated with pdb5 are restricted to the directory /opt/app/oracle/oradata/cdb1/pdb5.

CREATE PLUGGABLE DATABASE pdb5 FROM pdb2
FILE_NAME_CONVERT = ('/opt/app/oracle/oradata/cdb1/pdb2/', '/opt/app/oracle/oradata/cdb1/pdb5/')
PATH_PREFIX = '/opt/app/oracle/oradata/cdb1/pdb5';

----------------------------------------------------------------------------------



----------------------------------------------------------------------------------
-- Query and Views

-- The V$CONTAINERS view provides information about all of the containers in a CDB, including the root and all PDBs.
SELECT NAME, CON_ID, DBID, CON_UID, GUID FROM V$CONTAINERS ORDER BY CON_ID;



----------------------------------------------------------------------------------



----------------------------------------------------------------------------------
-- Administrator

Ques--> Can I have local TEMPORARY tablespace at Pluggable Database (PDB) level?

In spite, during the PDB creation only SYSTEM and SYSAUX tablespaces created, you can create local temporary tablespace 
later for every PDB. UNDO tablespace can NOT be local and stays on the CDB level.



----------------------------------------------------------------------------------




CREATE USER skumbhare
IDENTIFIED BY ispl_201
DEFAULT TABLESPACE users
TEMPORARY TABLESPACE temp
CONTAINER = CURRENT; 


GRANT CONNECT,CREATE SESSION,RESOURCE,CREATE VIEW TO tsys;


sqlplus rchaudhari@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.100.226.130)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=pdb1)))"

 CREATE PLUGGABLE DATABASE tnox 
 ADMIN USER admin IDENTIFIED BY * ROLES=(CONNECT)  
 file_name_convert=('/opt/app/oracle/oradata/cdb1/pdbseed/system01.dbf','/opt/app/oracle/oradata/cdb1/tnox/system01.dbf',
'/opt/app/oracle/oradata/cdb1/pdbseed/pdbseed_temp012014-12-22_07-08-02-PM.dbf','/opt/app/oracle/oradata/cdb1/tnox/temp012014-12-22_07-08-02-PM.dbf',
'/opt/app/oracle/oradata/cdb1/pdbseed/sysaux01.dbf','/opt/app/oracle/oradata/cdb1/tnox/sysaux01.dbf')
alter pluggable database tnox open





----------------------------------------------------------------------------------

/*

9. Table or partition recovery in RMAN

Oracle database backups are mainly categorized into two types: logical and physical. Each backup type has its own pros and cons. 
In previous editions, it was not feasible to restore a table or partition using existing physical backups. In order to restore a particular 
object, you must have logical backup. With 12c R1, you can recover a particular table or partition to a point-in-time or SCN from RMAN backups 
in the event of a table drop or truncate.

When a table or partition recovery is initiated via RMAN, the following action is performed:

Required backup sets are identified to recover the table/partition
An auxiliary database will be configured to a point-in-time temporarily in the process of recovering the table/partition
Required table/partitions will be then exported to a dumpfile using the data pumps
Optionally, you can import the table/partitions in the source database
Rename option while recovery
An example of a table point-in-time recovery via RMAN (ensure you already have a full database backup from earlier):

*/ 

RMAN> connect target "username/password as SYSBACKUP";
RMAN> RECOVER TABLE username.tablename UNTIL TIME 'TIMESTAMP�'
		AUXILIARY DESTINATION '/u01/tablerecovery'
		DATAPUMP DESTINATION '/u01/dpump'
		DUMP FILE 'tablename.dmp'
		NOTABLEIMPORT    -- this option avoids importing the table automatically.
REMAP TABLE 'username.tablename': 'username.new_table_name';    -- can rename table with this option.

----------------------------------------------------------------------------------

-- Open pdb1 and replace the database trigger with a trigger that opens only pdb1 at CDB startup.

alter pluggable database pdb1 open;

create or replace trigger Sys.After_Startup after startup on database 
begin 
   execute immediate 'alter pluggable database pdb1 open'; 
end After_Startup;
/

----------------------------------------------------------------------------------
-- it's same as export ORACLE_SID env. 
export TWO_TASK=PDBORCL

