-----------------------------------------------------------------
-- >> START_OF_FILE

-- TSYS
--
EXTRACT DPDCW

PASSTHRU

RMTHOST 10.100.226.209, MGRPORT 7809, COMPRESS

RMTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/TR

---Sequences
--SEQUENCE KEYNOX_FX.*;
--SEQUENCE SNOX4TRANSNOX_CPASS.*;
--SEQUENCE TRANSNOX_CPASS.*;
--SEQUENCE SNOXPASS_SMSNOX_303.*;

---- Schema name for the Table Data
TABLE TRANSNOX_CPASS.* ;
TABLE SNOX4TRANSNOX_CPASS.* ;

-- >> END_OF_FILE
--------------------------------------------------------------------




--------------------------------------------------------------------
-- >> START_OF_FILE
-- TSYS

EXTRACT EDCW

SETENV (ORACLE_SID  = "pridb")
SETENV (ORACLE_HOME = "/opt/app/oracle/product/11.2.0/dbhome_1")

USERID ggate@pridb, PASSWORD ggate1

DiscardFile ./dirrpt/edcw01.dis, Append
DiscardRollover at 02:00 ON SUNDAY

BR BROFF

EXTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/PS

DDL INCLUDE ALL;

--DDL Support --
-- & is used for line breaker
--EXCLUDE OBJTYPE USER
-- DDL INCLUDE ALL, EXCLUDE OBJTYPE TABLESPACE, &
--    EXCLUDE objtype 'DATABASE LINK'
--    , EXCLUDE OBJNAME transnox_cpass.SN_TEMP*, &
--    EXCLUDE OBJNAME transnox_cpass.SN_TEMP*, EXCLUDE OBJNAME snox4transnox_cpass.SN_TEMP*, &
--    EXCLUDE OBJNAME snox4transnox_cpass.SN_TEMP*
--DDL INCLUDE MAPPED;


-- Add Trandata for DDL
DDLOPTIONS REPORT, ADDTRANDATA
-- DBOPTIONS ALLOWUNUSEDCOLUMN
-- DBOPTIONS ALLOWNOLOGGING

-- STATOPTIONS RESETREPORTSTATS

REPORT AT 11:01

REPORTROLLOVER AT 11:01

REPORTCOUNT EVERY 1 HOUR, RATE

-- End of "best practices" section


GETTRUNCATES

-- sequence mapping

--SEQUENCE KEYNOX_FX.*;
--SEQUENCE TRANSNOX_CPASS.*;
--SEQUENCE SNOX4TRANSNOX_CPASS.*;

--exclude Tables

-- List of Mother schemas
TABLEEXCLUDE TRANSNOX_CPASS.MV*
TABLEEXCLUDE TRANSNOX_CPASS.DBMS_TABCOMP_TEMP_UNCMP
TABLE TRANSNOX_CPASS.*;

TABLEEXCLUDE SNOX4TRANSNOX_CPASS.MV*
TABLE SNOX4TRANSNOX_CPASS.*;

-- Currently Used VBS Schemas


-- >> END_OF_FILE
--------------------------------------------------------------------------------------







--------
-- file stuffs



-- On site B

-------------------------------------------------------------------
-- Replicat for tnox and snox Schema                             --
-------------------------------------------------------------------
--Replicat group --
replicat reptnox
--export sid
setenv (ORACLE_SID=reptdb)
--source and target definitions--
AssumeTargetDefs
--target database login --
userid ogg, password ogg
--PERFORMANCE PARMETERS--
--Double SQL transaction in 1 operation--
GROUPTRANSOPS 2000
--group similar transactions--
--BATCHSQL--
--error handling--
DDLERROR DEFAULT IGNORE RETRYOP
--file for dicarded transaction --
discardfile ./discard/reptnox_discard.txt, purge, megabytes 50
--Reporting--
ReportCount Every 30 Minutes, Rate
Report at 01:00
ReportRollover at 01:15
DiscardRollover at 02:00 ON SUNDAY
--ddl support--
--Supress constraints, SUPRESSTRIGGERS is not available in this version--
DBOPTIONS DEFERREFCONST
DDL INCLUDE ALL
DDLOPTIONS REPORT
DDLERROR 942 DISCARD INCLUDE OPTYPE DROP
REPERROR (1403, DISCARD)
--HANDLECOLLISIONS--
--Specify table mapping ---
-- we can exclude the tables for DMLs operation in Reporting DB
-- mapexlcude parameter is used in replicat  process
mapexclude snox.Stored_Forward,tnox.stored_forward
map tnox.*, target tnox.*;
map snox.*, target snox.*;



--***** Ends here --***** 
--*******************************************************>>>


--- On Site A
edit params dptnox -- edit datapump file dptnox.prm
--------------------------------------------------------------------
-- DataPump dptnox for tnox schema                               --
--------------------------------------------------------------------
--dataPump group--
extract dptnox

PASSTHRU

--HOSTNAME/IPAddress and port for trail--
rmthost 10.100.226.209, mgrport 7809, COMPRESS

--path and name for remote destination trail--
rmttrail ./dirdat/c2

--SEQUENCES mapping
sequence tnox.*;

-- Table mapping
Table tnox.* ;
--- END of the dptnox datapump file-----------



--- loging to ogg user and execute below commands to create extract and dump processes
dblogin userid ogg, password ogg

-- The name of the check point table must be added to the GLOBALS file on the target server and same table should be create with same name
-- On site A
ADD CHECKPOINTTABLE ggate.CHKPTAB

--do not start mgr process as datapump process will be abended with error TCP/IP connection refused...
-- as replication site B is yet not started.
-- start datapump process
ADD EXTRACT dpdcw, EXTTRAILSOURCE ./dirdat/LA, begin now
ADD RMTTRAIL ./dirdat/c2, EXTRACT dpdcw, MEGABYTES 100

-- start extract process
add extract exttnox, tranlog, begin now
ADD EXTTRAIL ./dirdat/c1, EXTRACT exttnox, megabytes 100


-- On Site B
-- start replicat process
add replicat reptnox, checkpointtable ggate.CHKPTAB, exttrail ./dirdat/c2
alter replicat reptnox begin now



--Before start site A mgr, first start site B mgr and other process

-- on Site B
Start mgr

info all
-- mgr and reptnox is in running stat 

-- On site A
start mgr

info all
-- mgr and reptnox is in running stat






















----*************************************************************************************----------------
--- best URL for GOLDEN GATE 
http://database.com.mk/wordpress/category/oracle/golden-gate/

--- Once you have Install Oracle and created database you will also need to install Oracle GoldenGate software

--create a folder ogg home under app/oracle/product folder path
mkdir -p /opt/app/oracle/product/ogg

--set the os env for OGG_HOME ~/.bas_profile for 
OGG_HOME=/opt/app/oracle/product/ogg; export OGG_HOME

-- add the $OGG_HOME in PATH line and also in LD_LIBRARY_PATH

-- Once done, then install the golden software in $OGG_HOME folder
unzip 112101_fbo_ggs_Linux_x64_ora11g_64bit.zip
tar -xf fbo_ggs_Linux_x64_ora11g_64bit.tar

-- start gg command line utility for creating sub directories in $OGG_HOME folder only
./ggsci

GGSCI>create subdirs
GGSCI>exit

oracle@db1>mkdir $OGG_HOME/discard

-- The GoldenGate software has been successfully installed on both the box pridb and reptdb.

--- setting on priddb

--- execute below commands on both host pridb and reprtdb ---till eof
-- database should be in Archivelog mode if not then please convert it to ARCHIVELOG mode
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA; 

ALTER DATABASE FORCE LOGGING;

ALTER SYSTEM SWITCH LOGFILE; 

SELECT force_logging, supplemental_log_data_min FROM v$database;

FOR SUPPLEME
--- --------
YES YES

-- trun off recyclebin for handling ddl commands
alter system set recyclebin=off scope=spfile;

ALTER TABLE sys.seq$ ADD SUPPLEMENTAL LOG DATA (PRIMARY KEY) COLUMNS;

shutdown immediate

startup

--eof


-- Create connecting and Administrator user for GoldenGet Replication
CREATE USER ogg IDENTIFIED BY ogg default tablespace users temporary tablespace temp;

GRANT CONNECT, RESOURCE, UNLIMITED TABLESPACE, DBA TO ogg; 

GRANT EXECUTE ON UTL_FILE to ogg;

-- The DBA role is not sufficient for advanced scenarios; you must also run the DBMS_GOLDENGATE_AUTH package. 
-- When keying in the DBMS_GOLDENGATE_AUTH command, the entire string after EXEC is without spaces or line breaks.
EXEC DBMS_GOLDENGATE_AUTH.GRANT_ADMIN_PRIVILEGE (grantee=>'GGATE',privilege_type=>'capture',grant_select_privileges=>true, do_grants=>TRUE); 

--- Add TnsNames.ora entry for both database host pridb and reptdb
-- entry should be in tnsnames.ora file for both Host (pridb and reptdb)
pridb=
  (DESCRIPTION=
    (ADDRESS = (PROTOCOL=TCP)(HOST=wdl2mltidbs01.tsysacquiring.org)(PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=pridb.tsysacquiring.org)
    )
  )

reptdb=
  (DESCRIPTION=
    (ADDRESS= (PROTOCOL=TCP)(HOST=wdl2mltidbs02.tsysacquiring.org) (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=reptdb.tsysacquiring.org)
    )
  )


--- setting on reptdb

-- Create connecting and Administrator user for GoldenGet Replication
CREATE USER ogg IDENTIFIED BY ogg default tablespace users temporary tablespace temp; 

GRANT CONNECT, RESOURCE, UNLIMITED TABLESPACE, DBA TO ogguser2; 

GRANT EXECUTE ON UTL_FILE to ogg;

-- The DBA role is not sufficient for advanced scenarios; you must also run the DBMS_GOLDENGATE_AUTH package. 
-- When keying in the DBMS_GOLDENGATE_AUTH command, the entire string after EXEC is without spaces or line breaks.
EXEC DBMS_GOLDENGATE_AUTH.GRANT_ADMIN_PRIVILEGE (grantee=>'OGG',privilege_type=>'capture',grant_select_privileges=>true, do_grants=>TRUE); 


--- Every replicating table should be having Primary Key constraint for replicating unique values from OGG replications

--


-- Below are some script which needs to execute for ogg user (using sysdba privileges) on both primary and reporting DBs.
SQL> @marker_setup
SQL> @ddl_setup
SQL> @role_setup
SQL> @ddl_enable
SQL> @ddl_pin OGG
SQL> @sequence



---- Start Configuring Parameters


-- The name of the check point table must be added to the GLOBALS file on the target server.

-- On Site A
edit params ./GLOBALS

GGSCHEMA GGATE
CHECKPOINTTABLE GGATE.CHKPTAB
-- save it


-- On site B
edit params ./GLOBALS
GGSCHEMA OGG
CHECKPOINTTABLE OGG.CHKPTAB
-- save it 


-- on site A

edit params mgr -- edit Manager file mgr.prm

-- >> START_OF_FILE
-- TSYS

-- Manger requires the port for running. By default 
-- manager port is 7809. We can use different port 
-- for the same.
PORT 7809
USERID ggate@pridb, PASSWORD ggate1
-- It is the parameter that helps to again restart the process i.e. extract, pump, replicat after their abnormal stopping.
AUTOSTART EXTRACT exttnox
AUTOSTART EXTRACT dptnox
--RETRIES <max retries> : The maximum number of times that Manager should try to restart a process before aborting retry efforts. The default number of tries is 2.
--WAITMINUTES <wait minutes> : The amount of time, in minutes, to pause between discovering that a process has terminated abnormally and restarting the
--                             process. Use this option to delay restarting until a necessary resource becomes available or some other
--                             event occurs. The default delay is 2 minutes.
--RESETMINUTES <reset minutes> : The window of time, in minutes, during which retries are counted. The default is 120 minutes (2 hours).
--                               After the time expires, the number of retries reverts to zero.
AUTORESTART EXTRACT exttnox, RETRIES 3, WAITMINUTES 5, RESETMINUTES 20
AUTORESTART EXTRACT dptnox, RETRIES 3, WAITMINUTES 5, RESETMINUTES 20
--Specifies maximum lag time in minutes after which a warning should be logged in the error log ggserror.log
LAGCRITICALMINUTES 5
-- Specifies maximum lag time in minutes after which the error should be logged
--in the error log. Once the LAGCRITICALMINUTES time exceeds.
LAGINFOMINUTES 10
-- it is the time interval at which manager checks extract, pump or replicat process for lag.
LAGREPORTMINUTES 60
--Manages trail files to conserve space--
PURGEOLDEXTRACTS ./dirdat/*, USECHECKPOINTS, MINKEEPDAYS 10


*/
 


 
 
-- On site B
edit params mgr -- edit Manager file mgr.prm 

-------------------------------------------------------------------
-- GoldenGate Manager On Target DB for TNOX schema				--
-------------------------------------------------------------------
-- use the same port for extract and replicat in manager process
PORT 7809

-- Connect DB with goldengate user and password
USERID ggate@reptdb, PASSWORD ggate1

--It is the parameter that helps to again restart the process 
--i.e. extract, pump, replicat after their abnormal stopping.
AUTOSTART REPLICAT reptnox

--RETRIES <max retries> : The maximum number of times that Manager should try to restart a process before aborting 
--						  retry efforts. The default number of tries is 2.
--WAITMINUTES <wait minutes> : The amount of time, in minutes, to pause between discovering that a process has 
--							   terminated abnormally and restarting the process. Use this option to delay restarting 
--							   until a necessary resource becomes available or some other event occurs. The default delay is 2 minutes.
--RESETMINUTES <reset minutes> : The window of time, in minutes, during which retries are counted. The default is 120 minutes (2 hours). 
--								 After the time expires, the number of retries reverts to zero.
AUTORESTART REPLICAT reptnox, RETRIES 3, WAITMINUTES 5, RESETMINUTES 20

--Specifies maximum lag time in minutes after which a warning should be logged in the error log ggserror.log
LAGCRITICALMINUTES 5

-- Specifies maximum lag time in minutes after which the error should be logged 
--in the error log. Once the LAGCRITICALMINUTES time exceeds.
LAGINFOMINUTES 10

-- it is the time interval at which manager checks extract, pump or replicat process for lag.
LAGREPORTMINUTES 60

--Manages trail files to conserve space--
PURGEOLDEXTRACTS ./dirdat/*, USECHECKPOINTS, MINKEEPDAYS 10
 

 -- Below are the example for Single schema Replication and Mulitple schema Replications
 -- Mostly use Multiple schema replication
 
 --***************************************************************
 -- Starts from Here
--***** REPLICATION FOR SINGLE SCHEMA --***** 
 
--- Do not add Multiple schemas in extract


-- On Site A */
edit params exttnox -- edit extract file exttnox.prm

--------------------------------------------------------------------
-- Local extract exttnox for tnox schema                          --
--------------------------------------------------------------------
--extract group--
extract exttnox
--export sid
setenv (ORACLE_SID=pridb)
--connection to database--
userid ogg, password ogg
--reporting--
ReportCount Every 30 Minutes, Rate
Report at 01:00
ReportRollover at 01:15
--discard--
DiscardFile ./dirrpt/tnox.dis, Append
DiscardRollover at 02:00 ON SUNDAY
--bound recovery--
BR BROFF
--path and name for local destination trail--
exttrail ./dirdat/c1
--DDL support--
DDL INCLUDE MAPPED OBJNAME TNOX.*

DDLOPTIONS REPORT, ADDTRANDATA
--DML support--
table tnox.*;
 

-- On Site B
edit params reptnox -- edit Replicat file reptnox.prm
-------------------------------------------------------------------
-- Replicat for tnox Schema                             --
-------------------------------------------------------------------
--Replicat group --
replicat reptnox
--export sid
setenv (ORACLE_SID=REPTDB)
--source and target definitions--
AssumeTargetDefs
--target database login --
userid ogg, password ogg
--PERFORMANCE PARMETERS--
--Double SQL transaction in 1 operation--
GROUPTRANSOPS 2000
--group similar transactions--
--BATCHSQL--
--error handling--
DDLERROR DEFAULT IGNORE RETRYOP
--file for dicarded transaction --
discardfile ./discard/tnox_discard.txt, purge, megabytes 50
--Reporting--
ReportCount Every 30 Minutes, Rate
Report at 01:00
ReportRollover at 01:15
DiscardRollover at 02:00 ON SUNDAY
--ddl support--
--Supress constraints, SUPRESSTRIGGERS is not available in this version--
DBOPTIONS DEFERREFCONST
DDL INCLUDE ALL
DDLOPTIONS REPORT
DDLERROR 942 DISCARD INCLUDE OPTYPE DROP
REPERROR (1403, DISCARD)
--HANDLECOLLISIONS--
--Specify table mapping ---
map tnox.*, target tnox.*;

--***** Ends here --***** 
--*******************************************************>>>




--***************************************************************
-- Starts from Here
--***** REPLICATION FOR MULTIPLE SCHEMAS --***** 

-- on site A
--------------------------------------------------------------------
-- Local extract exttnox for tnox schema                          --
--------------------------------------------------------------------
--extract group--
extract exttnox
--export sid
setenv (ORACLE_SID=pridb)
--connection to database--
userid ogg, password ogg
--reporting--
ReportCount Every 30 Minutes, Rate
Report at 01:00
ReportRollover at 01:15
--discard--
DiscardFile ./dirrpt/exttnox_discard.dis, Append
DiscardRollover at 02:00 ON SUNDAY
--bound recovery--
BR BROFF
--path and name for local destination trail--
exttrail ./dirdat/c1
--DDL support--
DDL INCLUDE ALL, EXCLUDE OBJTYPE USER, EXCLUDE OBJTYPE TABLESPACE, &
    EXCLUDE objtype 'DATABASE LINK', EXCLUDE OBJNAME transnox_cpass.SN_TEMP*, &
    EXCLUDE OBJNAME transnox_cpass.SN_TEMP*, EXCLUDE OBJNAME snox4transnox_cpass.SN_TEMP*, &
    EXCLUDE OBJNAME snox4transnox_cpass.SN_TEMP*
--DML support--
-- tableexclde option will excludes all tables starts with sn_temp% and sc_temp%
-- TABLEEXCLUDE is for the extract/ datapump and so should be in primary DB
tableexclude snox4transnox_cpass.sn_temp*;
tableexclude snox4transnox_cpass.sc_temp*;
table transnox_cpass.*;
table snox4transnox_cpass.*;




/*
  In above script "DDL INCLUDE ALL, EXCLUDE OBJTYPE USER, EXCLUDE OBJTYPE TABLESPACE"
  
  this is excluding to create users and create tablespace commands, if you are creating user (schemas)and tablespaces on primary DB "DDL INCLUDE ALL" 
  will replicate the same to replicating DB,But if you specify "DDL INCLUDE ALL, EXCLUDE OBJTYPE USER, EXCLUDE OBJTYPE TABLESPACE" 
  it will not replicate the created users/tablespace to replicating DB. 
  
  Under --DML support-- we can put multiple schemas followed by table and semicolon is must
  table tnox.*;
  table snox.*;
  table qcp.*;
  table qcpmgr.*;  etc....
  
  On replicating site under reptnox script it should be mentioned which schema is replicating to which schema
   
  so in file reptnox on site B(replicating DB)
  
  under --Specify table mapping --- map schema to target schema name semicolon should be present 
  map tnox.*, target tnox.*;
  map snox.*, target snox.*;
  map qcp.*, target qcp.*;
  map qcpmgr.*, target qcpmgr.*;

  
*/










ADD EXTRACT EDCE,TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/SR, EXTRACT EDCE, MEGABYTES 100

ADD EXTRACT DPDCE, EXTTRAILSOURCE /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/SR
ADD RMTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/DE, EXTRACT DPDCE, MEGABYTES 100

ALTER EXTRACT EDCE TRANLOG BEGIN NOW
ALTER EXTRACT DPDCE TRANLOG BEGIN NOW

ADD REPLICAT RDCE, EXTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/DE
ALTER REPLICAT RDCE, BEGIN NOW


ADD EXTRACT DPDCE, EXTTRAILSOURCE /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/SR
ADD RMTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/DE, EXTRACT DPDCE, MEGABYTES 100

ADD EXTRACT EDCE,TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/SR, EXTRACT EDCE, MEGABYTES 100

ALTER EXTRACT DPDCE TRANLOG BEGIN NOW
ALTER EXTRACT EDCE TRANLOG BEGIN NOW



ADD REPLICAT RPRETW, EXTTRAIL /opt/app/goldengate/dirdat/WC