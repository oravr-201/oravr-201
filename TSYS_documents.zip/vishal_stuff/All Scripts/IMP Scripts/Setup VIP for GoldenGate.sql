

-- ****** GoldenGate Application as cluster service  ***----------------


In this document I user Reporting east Node1 as an example.  With this setup goldengate app will move to next available node in case of node failure and 
start already running process. For extract and replicate we are using AUTORESTART which mean it will only Auto Restart in case of abnormal termination. 
Only manager and jagent are in AUTOSTART (Automatic Start) mode.  

-- Prerequisite  

1) Goldengate installed � in this case it was installed in goldengate user. 
2) Goldengate is using common filesystem in this case ACFS (ASM Cluster File System) 
3) Goldengate vip address is already added in DNS. 

-- XAG setup  
-- From 11.2.0.4 Oracle is recommending to use XAG (Oracle Grid Infrastructure Bundled Agents).

Step 1: 
-- Download latest version from OTN website.  
http://www.oracle.com/technetwork/database/database-technologies/clusterware/downloads/index.html  

-- Please follow the installation steps given in readme file. Few things to follow 
 * It should be installed in all nodes at the same location. In Transit we used /opt/app/oracle/xag 
 * It should be instated as owner of grid home should, which is oracle in Transit.  

Step 2: 
-- unzipped XAG file
From unzipped location use following command to install xag 

<unzipped location>/xagsetup.sh --install --directory /opt/app/oracle/xag --nodes <node name> 

-- This needs to be repeated in all nodes of the RAC.   

Step 3: 
-- VIP setup 
-- Add goldengate vip address to cluster service using appcfg (oracle recommended way). 
-- This should be executed as root user.  

root> /opt/app/11.2.0/grid_1/bin/appvipcfg create -network=1 -ip=10.50.50.180 -vipname=e-rpt-ggatevip.tsysacquiring.org -user=root 

Step 4: 
-- Grant Read and execute permission on VIP to oracle user using crsctl 
-- This should be executed as root user.

root> /opt/app/11.2.0/grid_1/bin/crsctl setperm resource e-rpt-ggatevip.tsysacquiring.org -u user:oracle:r-x 

Step 5: 
-- Please check it if is not on node 1 then you may need to relocate it to node1; 
-- This can be done from oracle user. 

Step 6: 
-- Goldengate App setup 

-- Resource creation 
-- As grid user (oracle) perform following steps.  

oracle> /opt/app/oracle/xag/bin/agctl add goldengate gg_erpt gg_home /acfs/goldengate nodes epl1trandbrpt1,epl1trandbrpt2,epl1trandbrpt3 vip_name e-rpt-ggatevip.tsysacquiring.org filesystems ora.registry.acfs databases ora.transitrptga.db oracle_home /opt/app/oracle/product/11.2.0/dbhome_2 

oracle> /opt/app/oracle/xag/bin/agctl config goldengate gg_erpt 

Step 7: 
-- Goldengate setup 
-- As goldengate user (goldengate) perform following steps 

-- Modify Manager parameter mgr.prm to add autostart jagent from ggsci.  
GGSCI (epl1trandbrpt1.tsysacquiring.org) 1> edit param mgr 

-- Modify jagent.prm to add full path of java 
GGSCI (epl1trandbrpt1.tsysacquiring.org) 2> edit param jagent 

-- e.g jagent.par will look like this after adding full path  
COMMAND export JAVA_HOME=/acfs/goldengate/software/jdk1.6.0_45 
COMMAND /acfs/goldengate/software/jdk1.6.0_45/bin/java -jar -Xms64m -Xmx512m dirjar/jagent.jar 

Step 8: 
-- Stop all processes
-- GGSCI (epl1trandbrpt1.tsysacquiring.org) 3> stop * 

-- Stop jagent  
GGSCI (epl1trandbrpt1.tsysacquiring.org) 4> stop jagent 

-- Stop manager 
GGSCI (epl1trandbrpt1.tsysacquiring.org) 5> stop mgr 


-- Please ensure everything should be stopped in goldengate user  

Step 9: 
-- Resource Start 
-- From oracle user start goldengate app  

oracle> /opt/app/oracle/xag/bin/agctl start goldengate gg_erpt --node epl1trandbrpt1 

Step 10: 
-- Validation and child processes start  
-- From goldengate user view all processes.  

GGSCI (epl1trandbrpt1.tsysacquiring.org) 1> info all 

Program     Status      Group       Lag at Chkpt  Time Since Chkpt 
MANAGER     RUNNING 
JAGENT      RUNNING 
EXTRACT     STOPPED     EPRE        00:00:01      00:00:09 
EXTRACT     STOPPED     PPRERW      00:00:00      00:00:03 
REPLICAT    STOPPED     RPRECP01    00:00:00      348:50:41 
REPLICAT    STOPPED     RPRERW      00:00:00      426:37:55 
REPLICAT    STOPPED     RPRETE01    00:00:00      00:00:00 
REPLICAT    STOPPED     RPRETW01    00:00:00      426:29:15 

Step 11: 
-- Start desired process such as replicate in case of target database or extract and pump in case of source database.  In this case it will be  

* GGSCI (epl1trandbrpt1.tsysacquiring.org) 2> start EPRE 
* GGSCI (epl1trandbrpt1.tsysacquiring.org) 3> start PPRERW 
* GGSCI (epl1trandbrpt1.tsysacquiring.org) 4> start RPRETE01 
* GGSCI (epl1trandbrpt1.tsysacquiring.org) 5> info all  


Program     Status      Group       Lag at Chkpt  Time Since Chkpt 
MANAGER     RUNNING 
JAGENT      RUNNING 
EXTRACT     RUNNING     EPRE        00:00:01      00:00:09 
EXTRACT     RUNNING     PPRERW      00:00:00      00:00:03 
REPLICAT    STOPPED     RPRECP01    00:00:00      348:50:41 
REPLICAT    STOPPED     RPRERW      00:00:00      426:37:55 
REPLICAT    RUNNING     RPRETE01    00:00:00      00:00:00 
REPLICAT    STOPPED     RPRETW01    00:00:00      426:29:15 

-- We can add critical extract (pump is extract) and replicat in configuration of oracle resource if required.  
