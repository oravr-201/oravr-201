-- What we do for ourselves dies with us - what we do for others, remains and is immortal

180030000585 *8207975340#

7720032867/isplN01805$1978

find $DBA/$ORACLE_SID/bdump/*.trc -mtime +7 -exec rm {} \;
*/

New Server(s):
DCE SMTP: smtpeast.tas.corp -> 10.105.0.31
DCW SMTP: smtpwest.tas.corp -> 10.104.0.31


---------------------------------------------------------------------------------------------------------------------------

-- Why Partition the tables

    �Slow� queries that return small amounts of data
    �Slow� queries that return large amounts of data
    �Slow� loading of data
    Blocking between readers and writers (inserts or updates)
    Long-running index maintenance jobs (or an inability to run them at all because they would take so long)

-- this removes the default value - if the column is populating any default values like sysdate
alter table trans_detail modify time_stamp default null;

-----------------------------------------------------------------------
-- Gives the information about sequencetial read and session connected from how many Hrs
SELECT A.SID,
        B.SCHEMANAME,
        B.username,
        B.OSUSER,
        b.machine,
        A.event,
        A.time_waited,
        A.time_waited / c.sum_time_waited * 100 pct_wait_time,
        ROUND((SYSDATE - b.logon_time) * 24) hours_connected
FROM v$session_event A, v$session b,
    (SELECT SID, SUM(time_waited) sum_time_waited
     FROM v$session_event
     WHERE event NOT IN ('Null event',
     					 'client message',
                         'KXFX: Execution Message Dequeue - Slave',
                         'PX Deq: Execution Msg',
                         'KXFQ: kxfqdeq - normal deqeue',
                         'PX Deq: Table Q Normal',
                         'Wait for credit - send blocked',
                         'PX Deq Credit: send blkd',
                         'Wait for credit - need buffer to send',
                         'PX Deq Credit: need buffer',
                         'Wait for credit - free buffer',
                         'PX Deq Credit: free buffer',
                         'parallel query dequeue wait',
                         'PX Deque wait',
                         'Parallel Query Idle Wait - Slaves',
                         'PX Idle Wait',
                         'slave wait',
                         'dispatcher timer',
                         'virtual circuit status',
                         'pipe get',
                         'rdbms ipc message',
                         'rdbms ipc reply',
                         'pmon timer',
                         'smon timer',
                         'PL/SQL lock timer',
                         'SQL*Net message from client',
                         'WMON goes to sleep')
            HAVING SUM(time_waited) > 0
            GROUP BY SID)c
WHERE A.SID = b.SID
  AND A.SID = c.SID
  AND A.time_waited > 0
  AND A.event = 'db file sequential read' 
  AND B.osuser<>'oracle'
  and B.username<>'GGATE'
  AND B.USERNAME NOT LIKE 'TRANSIT%'
--  AND A.SID='1151'
ORDER BY hours_connected DESC, pct_wait_time;
-----------------------------------------------------------------------

-----------------------------------------------------------------------
--- Create Tablespace with just giving Disk Group name

CREATE TABLESPACE CPASS_Data_Encrypt 
DATAFILE '+ASMDATA' SIZE 2G AUTOEXTEND OFF,
  '+ASMDATA' SIZE 2G AUTOEXTEND OFF,
  '+ASMDATA' SIZE 1G AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED,
  '+ASMDATA' SIZE 1G AUTOEXTEND OFF
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;

CREATE TABLESPACE CPASS_indx_Encrypt 
DATAFILE '+ASMDATA' SIZE 2G AUTOEXTEND OFF,
  '+ASMDATA' SIZE 2G AUTOEXTEND OFF,
  '+ASMDATA' SIZE 1G AUTOEXTEND ON NEXT 1M MAXSIZE UNLIMITED,
  '+ASMDATA' SIZE 1G AUTOEXTEND OFF
LOGGING
ONLINE
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
SEGMENT SPACE MANAGEMENT AUTO
FLASHBACK ON;

ALTER TABLESPACE CPASS_indx_Encrypt ADD DATAFILE '+ASMDATA' SIZE 2G AUTOEXTEND OFF

-----------------------------------------------------------------------

 emcli logout -username=sysman -password=Tsys123$
 emcli login -username=sysman -password=Tsys123
 
 
 -- Incase you have forgotten the sysman password
 
 1. Login to Cloud Control 12c database
 
 SQL> alter user sysman identified by abc123;
 
 2. Stop OMS
 
 $OMS_HOME/bin/emctl stop oms
 
 -- (DO not use -all postfix)
 
 3. Change password in Repository
 
 $OMS_HOME/bin/emctl config oms -change_repos_pwd -use_sys_pwd -sys_pwd sys123 -new_pwd abc123
 
 changing passwords in backend � 
 Passwords changed in backend successfully.
 Updating repository password in Credential Store�
 Successfully updated Repository password in Credential Store.
 Restart all the OMSs using �emctl stop oms -all� and �emctl start oms�.
 Successfully changed repository password.
 
 4. Stop and Start OMS completely
 
 $OMS_HOME/bin/emctl stop oms -all
 
$OMS_HOME/bin/emctl start oms
 
emctl status oms -details
 
emcli sync



-- 

/opt/app/oracle/Agent/agent_inst/bin/./emctl stop agent 
/opt/app/oracle/Middleware/oms/bin/./emctl stop oms -all 

./emctl config oms -change_repos_pwd -use_sys_pwd -sys_pwd Tsys123 -new_pwd Tsys123

/opt/app/oracle/Middleware/oms/bin/./emctl start oms
/opt/app/oracle/Agent/agent_inst/bin/./emctl start agent 


#!/bin/bash

# User specific environment and startup programs
. ~/.bash_profile

#ecking the /data disk partition space where archive files are getting created
VAL=`df -h | grep "/ora4" | awk '{print $5}'|sed 's/%//g'`

if [ "$VAL" -gt "65" ]
then
    echo "Disk value $VAL"
    echo "Disk space above 60%"

    cd /ora4/oracle/aqprod/archive

    find *.dbf -type f -mtime +1 -exec ls -l {} \; > temp_file.sh

    for fn in `cat temp_file.sh |awk '{print $9}'`
     do
       echo "$fn"
       # deleting non tar files
       rm -f $fn
    done

    rm -f temp_file.sh
else
    echo "$VAL"
    echo "Disk space is below 60%"
fi
-------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------
LEAD/Request Successfully Created.Your Lead Id: MHPUN22011500032

For all future correpondence Quote this Lead Id 

Create One More NEW lead 
---------------------------------------------------------------------------


-- installing Oracle RAC
http://startoracle.com/2007/09/30/so-you-want-to-play-with-oracle-11gs-rac-heres-how/

-- URL apply patch on 11.2.0.4.* -- like Oct2014 Patches
http://www.hhutzler.de/blog/installdeinstall-psu-11-2-0-4-4/#steps-generated-from-opatch-auto-installing-psu-112044

--- steps to complete
http://www.cic.gc.ca/english/immigrate/skilled/express-entry-immigrants.asp

SA
teamaccess.tsys.com



-- Direct connection string
sqlplus rchaudhari@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=wdl1mltidbs01.tsysacquiring.org)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=tnoxsnox)))"


sqlplus rchaudhari@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.64.51)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=utxndb)))"
sqlplus rchaudhari@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.64.61)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=urptdb)))"


sqlplus arcotuser@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.132.13.231)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=devracdbtaf)))"
sqlplus rchaudhari@"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.132.12.172)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=qaracdbtaf)))"


--- to flush the shared_pool
alter system flush shared_pool


--- Encreypted URL
http://10.132.13.121:30410/jsp/IFX_CPASS/DecryptEncrypt.jsp 


-- search out top 10 largest file/directories in linux
du -a | sort -n -r | head -n 10


-- Direct DBLink
CREATE  DATABASE LINK col121
CONNECT TO RCHAUDHARI
IDENTIFIED BY "some$Thing2015"
USING '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.50.4.121)(PORT = 1521))  (CONNECT_DATA = (SERVER = DEDICATED)(SID=aqprod)))';


CREATE  DATABASE LINK TW_Cpass
CONNECT TO RCHAUDHARI
IDENTIFIED BY "One$action201"
USING '(DESCRIPTION= (ADDRESS= (PROTOCOL=TCP) (HOST=e-transitdb-txn.tsysacquiring.org) (PORT=1521) ) (CONNECT_DATA=(INSTANCE_NAME=transitt1)(SERVICE_NAME=transittxn)))'

from Maaz to Everyone:
 1602329.1
 1268927.2


For Toad download 

Key : DR4GSL7F01MZA0YP380NV4G1A6H2G8VGGJVXN-111-414-023-3D
Site Message: TOTAL SYSTEM SERVICES INC

To download the software from Quest, follow the instructions below:

1. Register for support by going to https://support.quest.com/Default.aspx
         Use the SupportLink Site ID 1-5V3XJH
         If you are a new customer, you will receive a welcome email that will include your SupportLink registration information.
         If you do not receive a Support welcome email within 48 hours of registering or experience any problems, please contact the 
         Quest Support Administrators at supportadmin@quest.com or see the Contact Support page for other contact methods available. 
         If you are already a registered SupportLink user, please skip this step. 
2. Download TOAD   


DBA means Database "Administrators" which is 
- Keeping Database up & running 24/7. 
- Fine tuning the queries. 
- Implementing new changes. 
- Applying new patches/versions 
- Helping people/developer understand the Oracle Database and make maximum use of the same for current/future objects/source code. 

Vulnerability Management across all DB Platforms 
- Review and Apply Patches when required or released by Oracle.
- Determine the applicability of the patches in our environments
- Deploy the patch in Dev, Perform impact analysis, Promote to QA and then UAT
- Maintain records of patch deployments
- Check for Security related issues
- DB Schema Password Managments
- Database Security - Audit and Protect Critical Databases

Oracle EnterPrise Monitoring
- Proactive Database Monitoring in terms of DB Health and taking preventive or corrective action as required
- OEM Performance Tuning
- Diagnosing Performance Problems




/*
--- TransIT Settlement Performance Improvement tables


# This script will be executed at every day 02 AM PST
# and will refresh the statistics of tables used in settlement Procedures
00 02 * * * sh /home/oracle/scripts/trans_settlement_stats.sql > /home/oracle/scripts/logs/log_trans_settlement_stats.lo


execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANSACTION');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_RESPONSE_INFO');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_CARD');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_DETAIL');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_VOID');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_RETURN');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_ENHANCED_DATA');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_PRODUCT_INFO');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_TAX_DETAIL');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANSACTION_FEE_DETAIL');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_SETTLEMENT');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_ADDITIONAL_INFO');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_FEE_DETAIL');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_BANK_DETAIL');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TRANS_BANK_DETAIL_HISTORY');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'TASK');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'CUSTOMER');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'CUST_ADDRESS');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'CUSTOMER_HISTORY');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'ENROLLED_CUSTOMER_DATA');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'CUST_ENROLLMNENT');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'CUST_CARD_ACCOUNT');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'CUST_FINANCIAL_ACCOUNT');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'CARD_NUMBER_MASTER');
execute DBMS_STATS.gather_table_stats ('TRANSNOX_IOX', 'RECURRING_PAYMENT');



*/

/*

IDBI Bank: ---
Home Loan:  29,794.00
Top-Up Loan: 7,013.00
----------------------------
			3,6807   == 40,000
Axis Bank: ---
Car Loan :  8,728.00 ==  10,000

02067235073 -- AxisBank Loan Center Pride




*/

-----------------------------------------------------------------------------------------------------------------------------------------------
Installation Type																				Zip File
-----------------------------------------------------------------------------------------------------------------------------------------------
Oracle Database (includes Oracle Database and Oracle RAC)										p10404530_112030_platform_1of7.zip
Note: you must download both zip files to install Oracle Database.								p10404530_112030_platform_2of7.zip

Oracle Grid Infrastructure (includes Oracle ASM, Oracle Clusterware, and Oracle Restart) 		p10404530_112030_platform_3of7.zip
Oracle Database Client																			p10404530_112030_platform_4of7.zip
Oracle Gateways																					p10404530_112030_platform_5of7.zip
Oracle Examples																					p10404530_112030_platform_6of7.zip
Deinstall																						p10404530_112030_platform_7of7.zip
-----------------------------------------------------------------------------------------------------------------------------------------------




-- open a command prompt and take a backup of task scheduler windows
-- it will generate the AllTasks.xml file in C:\ colon
schtasks /Query /XML > c:\AllTasks.xml



DCE - Data Center East, which is Columbus 
DCW - Data Center West, which is Tempe

Compensatory off on date 28Jan2016 and 29Jan2016 against working on date 04Jan2016 and 05Jan2016. I have taken holidays on 04 and 05 Jan-2016, but due to GCA Commissions issues I had to work on this dates.

Compensatory off on date 06Feb2015 (Friday) against working on date 01Feb2015 (Sunday) 0900 AM till 01Feb2015 11:59 PM for GCA Commissions and Oracle Non-Production server Patching. 

Compensatory off on date 07Aug2015 against working over weekend on Saturday 01st Aug 2015 1000 AM till 06:00 PM for running the Monthly jobs (Refresh GCA QR Commissions)of SQL Server...

https://support.oracle.com/epmos/faces/SearchDocDisplay?_adf.ctrl-state=tgj8bs17u_9&_afrLoop=75150481767959

1469108.1 -- Configuring GoldenGate Doc
1580994.1

-------------------------------------------------------------------------------------------
-- convert nummber to HH24:MI:SS
-- so it will convert 2000 number to HH24:MI:SS
SELECT 
    TO_CHAR(TRUNC(2000/3600),'FM9900') || ':' ||
    TO_CHAR(TRUNC(MOD(1800,3600)/60),'FM00') || ':' ||
    TO_CHAR(MOD(2000,60),'FM00')
FROM DUAL
-------------------------------------------------------------------------------------------


-------------------------------------------------------------------------------------------
/opt/arcot/arcot/odbc32v60wf/odbc.ini

[arcotdsn]
Driver=/opt/arcot/arcot/odbc32v60wf/lib/WFora24.so
HostName=devracdb.tsysacquiring.org
PortNumber=1521
# SID devracdb1
ServiceName=devracdb
ReportCodepageConversionErrors=2
QueryTimeout=-1


-- 10.100.224.190
/opt/arcot/arcot/ 
-------------------------------------------------------------------------------------------

-- goldengate on rac
http://xanpires.wordpress.com/2012/08/13/goldengate-com-rac-asm-grid-infrastructure/

-- Oracle Golden-Gate Installation and related information
http://www.oracle.com/webfolder/technetwork/tutorials/obe/fmw/goldengate/11g/orcl_orcl/index.html


-- Download 11.2.0.1.0 base software
http://www.oracle.com/technetwork/database/enterprise-edition/downloads/index.html


-- Overview of all Patches of Oracle softwares
https://support.oracle.com/CSP/ui/flash.html#tab=KBHome(page=KBHome&id=()),(page=KBNavigator&id=(bmDocTitle=Oracle%20Database%20Upgrade%20Path%20Reference%20List&bmDocDsrc=KB&bmDocType=HOWTO&viewingMode=1143&bmDocID=730365.1&from=BOOKMARK))


--for Oracle 9i streams
http://www.oracle-base.com/articles/9i/Streams9i.php 
 
--for Oracle 10G streams
http://www.oracle.com/technology/oramag/oracle/04-nov/o64streams.html


ps -ewf |grep "LOCAL=NO"|awk '{print $2}' | xargs kill -9


--***********************************
13 30 * * * sh /oradata1/oracle/dumpfiles/devdb_bkup_scripts.sql


-- Take export on devdb.infonox.com devdb 
expdp rchaudhari@devdb directory=dpump dumpfile=expdp_clob_data.dmp logfile=expdp_data.log tables=snox4transnox.recon_file_config exclude=statistics data_options=xml_clobs reuse_dumpfiles=y

-- Transfer the export dumpfile to Oracle 11g R2

-- Once export dumpfile is transfered to Oracle 11G R2 DB server, Start importing....
impdp rchaudhari directory=bkup dumpfile=expdp_clob_data.dmp logfile=expdp_clob_data.log remap_schema=snox4transnox:rchaudhari exclude=index,constraint

--***********************************


--****************************************  Event Table Automation  **************************************** 

--- event table Automation scripts
sqlplus -s / as sysdba << EOF
spool evenet_arching_glory_wm.log
SELECT TO_CHAR(sysdate,'dd/mm/yyyy hh24:mi:ss') Start_Timestamp from dual;
ALTER SESSION SET CURRENT_SCHEMA=snox4transnox;
--- create new table and include last 7 day's data only
CREATE TABLE event_1 NOLOGGING TABLESPACE SNOX_INDX
AS
SELECT *
FROM event
WHERE server_timestamp > SYSDATE-7;
--- rename the current event table name to current date format DDMONYYYY for e.g. 30Jan2013
begin
  execute immediate 'alter table event rename to event_'||TO_CHAR(SYSDATE,'DDMONYYYY');  
end;
/
-- replace newly created table event_1 to original event table...
ALTER TABLE event_1 RENAME TO event;
ALTER TABLE event LOGGING;
-- before creating required index, drop them first
DROP INDEX IDX_COMP_CTIME_STAMP;
DROP INDEX IDX_EV_CASCODE;
-- create required index
CREATE INDEX SNOX4TRANSNOX.IDX_COMP_CTIME_STAMP ON SNOX4TRANSNOX.EVENT (SERVICE, WORKSTATIONCODE, SERVER_TIMESTAMP) TABLESPACE SNOX_DATA;
-- commit
COMMIT;
-- create required index
CREATE INDEX SNOX4TRANSNOX.IDX_EV_CASCODE ON SNOX4TRANSNOX.EVENT(CASINOCODE) TABLESPACE SNOX_INDX;
-- grant required privileges of event table to related schemas
GRANT SELECT,UPDATE,INSERT,DELETE ON snox4transnox.event TO transnox_wm;
GRANT SELECT,UPDATE,INSERT,DELETE ON snox4transnox.event TO transnox_glory;
-- create synonym of event table in related schemas
CREATE OR REPLACE SYNONYM TRANSNOX_WM.EVENT FOR SNOX4TRANSNOX.EVENT;
CREATE OR REPLACE SYNONYM TRANSNOX_GLORY.EVENT FOR SNOX4TRANSNOX.EVENT;
-- recompile all related schemas
EXEC DBMS_UTILITY.COMPILE_SCHEMA(SCHEMA=>'SNOX4TRANSNOX');
--EXEC DBMS_UTILITY.COMPILE_SCHEMA(SCHEMA=>'TRANSNOX_WM');
--EXEC DBMS_UTILITY.COMPILE_SCHEMA(SCHEMA=>'TRANSNOX_GLORY');
SELECT TO_CHAR(sysdate,'dd/mm/yyyy hh24:mi:ss') End_Timestamp from dual;
spool off
EOF

--****************************************  Event Table Automation  **************************************** 

*********************************************
OCP - Exam ----
1Z0-051 Oracle 11G SQL or Fundamentals I 
1Z0-052 Oracle 11G Administration I 
1Z0-053 Oracle 11G Administration II 
*********************************************


-- Good Site for ORACLE DBA's
--- RAC on Oracle VM
http://gavinsoorma.com/2011/11/3366/

------------------------------------------
-- disable audit
NOAUDIT ALL;
------------------------------------------


****************************************  RSYNC Script Linux  **************************************** 

root user on database server

-- settings on archive server 
vi /etc/rsyncd.conf

use chroot = no

max connections = 20

hosts allow = 10.100.226.130, 10.100.226.124, 10.100.226.235, 10.100.224.173

uid = root

gid = root

logfile = /var/log/rsyncd.log

[backup]

path = /

[devracdb2]

path=/oradata2/oracle/bk_devracdb

readonly = false
:-- save the file

-- command to execute for resnyc
-- command is executed from arch db.. soruce DB
rsync -uvrpogtlz 10.100.226.124::backup/oracle/rman_bkup/ctrlfiles  /oradata1/oracle/regdb_rmanbkups/bkup_files





-- setting on DB server.. from the root user
-- settings on qadbnode2
[root@regdbnode1 ~]# cat /etc/rsyncd.conf
use chroot = no

max connections = 20

# first is the ip add of the source server - where the backup file will be copyied/moved after 
# comma (,) Ip is of Target server - from where the backup file be generated.
hosts allow = 10.100.226.130, 10.100.226.124, 10.100.226.242

uid = root

gid = root

logfile = /var/log/rsyncd.log

[backup]

# specify backup path
path = /backup

readonly = false

10.100.226.242


rsync -uvrpogtlz /backup/oracle/bkups/dpump/expdp_qaracdb2_bkupslogs_27Sep2013.log  10.100.226.130::oradata3/oracle/qadb_bkups/expdp_dpump


rsync -uvrpogtlz /recovery/oracle/bkups/bkscript/expdp_bkups_devracdb2.sh  10.100.226.130::devracdb2
 
 
---- Linux Date Formating
#monday
date -dmonday +%Y%m%d

#last monday
date -dlast-monday +%Y%m%d

#next monday
date -dnext-monday +%Y%m%d

#two mondays from now
date -d'monday+14 days' +%Y%m%d

#two mondays ago
date -d'monday-14 days' +%Y%m%d

#although, if you fancy yourself an Abraham Lincolin
date -d'monday-fortnight ago' +%Y%m%d #2 weeks ago
date -d'monday+fortnight' +%Y%m%d #2 weeks from now

#Monday Next Year
date -d'52+monday' +%Y%m%d

#However, Monday Last Year
date -d'52-monday' +%Y%m%d  #DOES NOT  WORK

-- you can try a day other than monday and format this differently.
-- if a range is what your after you may need to do a few things
#Tuesday to Sunday
#since today is monday, i will use Tuesday

echo `date -dtuesday +%Y%m%d-``date -dnext-sunday +%Y%m%d`

 
-- curl command 
/usr/local/bin/curl -v -O -u $USERNAME:$PASSWORD sftp://$SERVERNAME/~/prod/smsnox/$FILENAME


DEST_DIR="/home/sites/transgca/File_Transfer/zipfiles"
mkdir -p $DEST_DIR
cd $DEST_DIR

echo " " > .tmpfile
FILENAME="`date  +%Y%m%d`_TS.ZIP"
#FILENAME=20101122_TS.ZIP
FILENAME1="`date +%Y%m%d`.TS"
#FILENAME1=20100429.TS
echo $FILENAME

#username=transgca
USERNAME="ndmjobs"
#password=es0s_DpL
PASSWORD='NdmJ0b$@Tempe'
SERVERNAME="transuploader.ifxtempe.com"

FILENAME2="download_success_mail.txt"
echo "" > $FILENAME2 

curl -u ftpuser:ftppass -T myfile.txt ftp://ftp.testserver.com  




---- deleting one day older file

#!/bin/bash

# User specific environment and startup programs
ORACLE_BASE=/ora1/oracle/
ORACLE_HOME=/ora1/oracle/product/11.1.0/db_1
export ORACLE_BASE
export ORACLE_HOME
export ORACLE_SID=aqprod
PATH=$ORACLE_HOME/bin:/usr/bin:/bin:/usr/bin/X11:/usr/local/bin:/sbin:
PATH=$PATH:$HOME/bin
export PATH


# checking the /archive disk partition space where archive files are getting create
VAL=`df -h | grep "/archive" | awk '{print $5}'|sed 's/%//g'`

if [ "$VAL" -gt "65" ]
then
    echo "Disk value $VAL"
    echo "Disk space above 65%"

    cd /archive/oracle/aqprod/archive

    find *.dbf -type f -mtime +1 -exec ls -l {} \; > temp_file.sh

    for fn in `cat temp_file.sh |awk '{print $9}'`
    do
       echo "$fn"
       # deleting non tar files
       rm -f $fn
    done

    rm -f temp_file.sh
else
    echo "$VAL"
    echo "Disk space is below 65%"
fi


 
****************************************  RSYNC Script Linux  **************************************** 


****************************************  OEM CC 12c knowledge  **************************************** 

After moving to Oracle Enterprise Manager Cloud Control 12c, one of the annoyances I soon discovered was this message �The page has expired. 
Click OK to continue�.

When you�re not actively using the console, it doesn�t take long before the message appears, which is especially annoying when you have the 
performance monitoring pages running in the background!

According to Oracle it�s a new security feature within the EM12c console:

To prevent unauthorized access to the Cloud Control console, Enterprise Manager will automatically log you out of the Cloud Control console 
when there is no activity for a predefined period of time. For example, if you leave your browser open and leave your office, this default 
behavior prevents unauthorized users from using your Enterprise Manager administrator account.

�but with today�s browser behavior all that really happens is the page reloads after you click OK anyway!

So, here�s how you disable it:

export OMS_HOME=/u01/app/oracle/middleware/oms12c/oms
cd $OMS_HOME/bin
Disable the feature altogether with '-1' value (it�s null by default), or enter another value (minutes) if for some reason you want to increase it:

./emctl set property -name oracle.sysman.eml.maxInactiveTime -value -1 -sysman_pwd sysman_password
Restart your OMS(es) to reflect the changes:

./emctl stop oms
./emctl start oms

****************************************  OEM CC 12c knowledge  **************************************** 



****************************************  DBA Should Know  **************************************** 

-- Most active SQL in previous hour.
SELECT sql_id,COUNT(*),ROUND(COUNT(*)/SUM(COUNT(*)) OVER(), 2) PCTLOAD
  FROM gv$active_session_history
 WHERE sample_time > SYSDATE - 1/24
   AND session_type = 'BACKGROUND'
 GROUP BY sql_id
 ORDER BY COUNT(*) DESC;

SELECT sql_id,COUNT(*),ROUND(COUNT(*)/SUM(COUNT(*)) OVER(), 2) PCTLOAD
  FROM gv$active_session_history
 WHERE sample_time > SYSDATE - 1/24
   AND session_type = 'FOREGROUND'
 GROUP BY sql_id
 ORDER BY COUNT(*) DESC;

-- Top 10 CPU consumers in last 60 minutes
select * from
(
	select session_id, session_serial#, count(*)
	  from v$active_session_history
	 where session_state= 'ON CPU'
	   and sample_time > sysdate - interval '60' minute
	 group by session_id, session_serial#
	 order by count(*) desc
)
where rownum <= 10;

-- Top 10 waiting sessions in last 60 minutes
select * from
(
	select session_id, session_serial#,count(*)
	  from v$active_session_history
	 where session_state='WAITING'
	   and sample_time >  sysdate - interval '60' minute
	 group by session_id, session_serial#
	 order by count(*) desc
)
where rownum <= 10;


-- You can restored the explain plan in oracle by below example.

-- Check when was the explain plan was last updated
select table_name,stats_update_time from user_tab_stats_history;

-- table the above timestamp details and put here 
begin
	dbms_stats.restore_table_stats('TRANSNOX_CPASS','TASK',to_timestamp('2014-10-28:11:47:38','yyyy-mm-dd:hh24:mi:ss'));
end;
/

-- Squence Related stuff
/*

For performance efficiency, Oracle uses caching with a default cache value of 20. That means that when you enter a transaction, 20 numbers are read
into memory. The next time someone wants a number from the sequence, Oracle reads memory for the next number. It does not have to perform a disk I/O to
read the next number from the sequence.

That means that when memory is cleared after you commit a transaction and exit the form, numbers left in the cache are lost. That's why you get
gaps in the number sequence between 1 and 20.

You can avoid the problem by changing the sequences as follows:

*/

ALTER SEQUENCE XXX NOCACHE; 



---- Sequence Automation
SELECT sequence_owner, sequence_name, last_number
FROM dba_sequences
WHERE sequence_owner IN ('CHECKCASH','MERGECUSTCODE','QCP','QCPMGR','QCREDIT','QFUND','REALTIMERPT','SNOXDEVICES','SRC_C_REPL','WUMT')
ORDER BY 1,2 ASC



---> Restricting Access to an Open Database

/*
To place an instance in restricted mode, where only users with administrative privileges can access it, 
use the SQL statement ALTER SYSTEM with the ENABLE RESTRICTED SESSION clause. After placing an instance in restricted mode, 
you should consider killing all current user sessions before performing any administrative tasks.

To lift an instance from restricted mode, use ALTER SYSTEM with the DISABLE RESTRICTED SESSION clause

*/

--You can use the RESTRICT clause in combination with the MOUNT, NOMOUNT, and OPEN clauses.
STARTUP RESTRICT OPEN

ALTER SYSTEM ENABLE RESTRICTED SESSION;

ALTER SYSTEM DISABLE RESTRICTED SESSION;




-- Monitoring Data Guard log-Shipping counts
SELECT DB_NAME, HOSTNAME, LOG_ARCHIVED, LOG_APPLIED,APPLIED_TIME,
LOG_ARCHIVED-LOG_APPLIED LOG_GAP
FROM
	(
		SELECT NAME DB_NAME
		FROM V$DATABASE
	),
	(
		SELECT UPPER(SUBSTR(HOST_NAME,1,(DECODE(INSTR(HOST_NAME,'.'),0,LENGTH(HOST_NAME),
		(INSTR(HOST_NAME,'.')-1))))) HOSTNAME
		FROM V$INSTANCE
	),
	(
		SELECT MAX(SEQUENCE#) LOG_ARCHIVED
		FROM V$ARCHIVED_LOG WHERE DEST_ID=1 AND ARCHIVED='YES'
	),
	(
		SELECT MAX(SEQUENCE#) LOG_APPLIED
		FROM V$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES'
	),
	(
		SELECT TO_CHAR(MAX(COMPLETION_TIME),'DD-MON/HH24:MI') APPLIED_TIME
		FROM V$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES'
	);
	


-- If you want to drop primary key and associated index;
ALTER TABLE MY_TABLE DROP PRIMARY KEY DROP INDEX;

-- OR

ALTER TABLE MY_TABLE  DROP PRIMARY KEY CASCADE;

-- If you want to drop primary key but keep index then following
ALTER TABLE MY_TABLE DROP PRIMARY KEY KEEP INDEX;



-- Generate ODD and EVEN sequences from the existing one

-- Below is script is in working condition

-- check any sequence is in odd number
SELECT sequence_owner,
       sequence_name,
       increment_by,
       cache_size,
       last_number
  FROM dba_sequences
 WHERE sequence_owner IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS', 'WEBFORT')
   AND MOD (last_number, 2) = 1;

-- even and odd scripts
SELECT sequence_owner,
         sequence_name,
         increment_by,
         cache_size,
         last_number,
         MOD (last_number, 2) even,
         CASE
            WHEN MOD (last_number, 2) = 1 THEN last_number + 1001
            WHEN MOD (last_number, 2) = 0 THEN last_number + 1000
            ELSE last_number
         END
            final_even_no,
         CASE
            WHEN MOD (last_number, 2) = 1
            THEN
                  'alter sequence '
               || sequence_owner
               || '.'
               || sequence_name
               || ' increment by 1001 ;'
               || CHR (10)
               || 'select '
               || sequence_owner
               || '.'
               || sequence_name
               || '.nextval from dual;'
            WHEN MOD (last_number, 2) = 0
            THEN
                  'alter sequence '
               || sequence_owner
               || '.'
               || sequence_name
               || ' increment by 1000 ;'
               || CHR (10)
               || 'select '
               || sequence_owner
               || '.'
               || sequence_name
               || '.nextval from dual;'
            ELSE
               TO_CHAR (last_number)
         END
            first_even_time_increment,
         CASE
            WHEN MOD (last_number, 2) = 1
            THEN
                  'alter sequence '
               || sequence_owner
               || '.'
               || sequence_name
               || ' increment by 1000 ;'
               || CHR (10)
               || 'select '
               || sequence_owner
               || '.'
               || sequence_name
               || '.nextval from dual;'
            WHEN MOD (last_number, 2) = 0
            THEN
                  'alter sequence '
               || sequence_owner
               || '.'
               || sequence_name
               || ' increment by 1001 ;'
               || CHR (10)
               || 'select '
               || sequence_owner
               || '.'
               || sequence_name
               || '.nextval from dual;'
            ELSE
               TO_CHAR (last_number)
         END
            first_odd_time_increment,
            'alter sequence '
         || sequence_owner
         || '.'
         || sequence_name
         || ' increment by 2 ;'
         || CHR (10)
         || 'select '
         || sequence_owner
         || '.'
         || sequence_name
         || '.nextval from dual;'
            final_even_run
    FROM dba_sequences
   WHERE sequence_owner IN ('SNOX4TRANSNOX_CPASS', 'TRANSNOX_CPASS', 'WEBFORT')
ORDER BY LAST_NUMBER DESC



-- check the difference in the sequence by DBlink


SELECT 'alter sequence '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||' increment by '||diff_number||';'||CHR(10)||
       'select '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||'.nextval from dual;' ||CHR(10)||
       'alter sequence '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||' increment by 2;'||CHR(10)||
       'select '||SEQUENCE_OWNER||'.'||SEQUENCE_NAME||'.nextval from dual;' oops
FROM (
     SELECT tw.SEQUENCE_OWNER,
            TW.SEQUENCE_NAME,
            TW.LAST_NUMBER TW_Seq_LastNumber,
            TE.LAST_NUMBER TE_SEQ_LastNumber,
            TE.LAST_NUMBER - TW.LAST_NUMBER diff_number,
            TW.CACHE_SIZE            
       FROM dba_sequences TW, dba_sequences@uattxn TE
      WHERE     TW.SEQUENCE_OWNER IN ('SNOX4TRANSNOX_CPASS','TRANSNOX_CPASS','WEBFORT')
            AND TW.SEQUENCE_OWNER = TE.SEQUENCE_OWNER
            AND TW.SEQUENCE_NAME = TE.SEQUENCE_NAME
            AND TE.LAST_NUMBER > TW.LAST_NUMBER
   ORDER BY 5 DESC)
   
   
-- Best practice to Drop database using RMAN
-- As per Best practice, take full backup of the database which you will be dropping
-- DataPump export will be the good option
-- If using RMAN then move the backup files to TAPE, as we are dropping the backups also 
RMAN> CONNECT TARGET SYS@test1

target database Password: password
connected to target database: TEST1 (DBID=39525561)

RMAN> STARTUP FORCE MOUNT
RMAN> SQL 'ALTER SYSTEM ENABLE RESTRICTED SESSION';
RMAN> DROP DATABASE INCLUDING BACKUPS NOPROMPT;   



---- Get the most taking or busy events and waits information like ASH report
SELECT * 
FROM dba_hist_active_sess_history 
WHERE sample_time BETWEEN TO_DATE('10/24/2015 09:38:00','mm/dd/yyyy hh24:mi:ss') 
                      AND TO_DATE('10/24/2015 09:42:30','mm/dd/yyyy hh24:mi:ss')
ORDER BY sample_time ASC


SELECT sql_id,event_id, event, COUNT(*) cnt
FROM dba_hist_active_sess_history
WHERE snap_id BETWEEN 15046 AND 15047
  AND wait_class_id=3871361733
GROUP BY sql_id,event_id, event
ORDER BY 4 DESC;

SELECT sql_id,  COUNT(*) cnt
FROM dba_hist_active_sess_history
WHERE snap_id BETWEEN 15046 AND 15046
  AND wait_class_id=3871361733 AND event_id='105117041'
GROUP BY sql_id
ORDER BY cnt DESC;

SELECT *
FROM v$sql WHERE sql_id='6mtbknc8a6x59'

SELECT *
FROM V$SQL_BIND_CAPTURE
WHERE sql_id='6mtbknc8a6x59'

SELECT *
FROM V$SQL_BIND_METADATA
WHERE address='0000000502B59DE8'

SELECT *
FROM V$SQL_BIND_DATA
--where buf_address='0000000502B59DE8'
--



****************************************  DBA Should Know  **************************************** 


****************************************  ADRCI Command  **************************************** 

-- To set the purging policy to 7 days

-- check the settings for Short and long Policys
adrci> show control

-- Modify it for 7 days
adrci> set control (SHORTP_POLICY=72)
adrci> set control (LONGP_POLICY=72)



-- To Manually purge all trace files older than 1 day (1440 mins): Including core files: cdmp*

-- 4320 min for 4 days (1440 min in a day)
-- 24 hrs a day and 1440 mins in a day
adrci> purge -age 4320

OR
-- This example purges all incident data from the last hour:
adrci> purge -age 60 -type incident

-- command will manually purge all tracefiles older than 2 days (1440*2=2880 minutes):
adrci> purge -age 2880 -type trace

-- To purge core files older than 6 days  
adrci> purge -age 4320 -type CDUMP


-- It might be needed to also run the following additional command:  
adrci> purge -age 4320 -type UTSCDMP


-- To remove sub-folders >6 days-old having a name like "CDMP_" from TRACE.
-- Purge XML based Alert log file:
adrci> purge -age 60 -type ALERT


-- do not clean up the Text-formatted alert.log file.
-- The ADRCI interface is only supposed to modify the XML-formatted alert file, not the Text-formatted alert file,


-- This displays the last 50 entries in the alert log in your terminal session.
adcri> show alert -tail 50

-- trail the alert log file
adcri> show alert -tail -f


set control (SHORTP_POLICY = 2)
set control (LONGP_POLICY = 4)

-- delete trace older then 1 min
purge -age 1 -type trace

****************************************  ADRCI Command  ****************************************  

****************************************  SPID  **************************************** 
-- check the SPID from session process column which will be getting from below
-- active processes query
SELECT s.SCHEMANAME, s.OSUSER, P.SPID 
FROM V$SESSION s, v$process P
WHERE s.paddr = P.addr
  AND s.process='6008:3528'

-- Show the currently active processes. top CPU
SELECT SUBSTR(s.USERNAME,1,8) USERNAME, s.OSUSER OSUSER,
     DECODE(s.SERVER,'DEDICATED','D','SHARED','S','O') SERVER,
     sa.DISK_READS DISK_READS, sa.BUFFER_GETS BUFFER_GETS,
     SUBSTR(s.LOCKWAIT,1,10) LOCKWAIT, s.PROCESS PID,
     sw.EVENT EVENT, sa.SQL_TEXT SQL
FROM V$SESSION_WAIT sw, V$SQLAREA sa, V$SESSION s
WHERE s.SQL_ADDRESS = sa.ADDRESS
  and s.SQL_HASH_VALUE = sa.HASH_VALUE
  and s.SID = sw.SID (+)
  and s.STATUS = 'ACTIVE'
  and sw.EVENT != 'client message'
ORDER BY s.LOCKWAIT ASC, s.USERNAME;





-- check the top query
SELECT /*+ ordered */ 
    P.spid, s.SID, s.serial#, s.username, 
    TO_CHAR(s.logon_time, 'mm-dd-yyyy hh24:mi') logon_time, s.last_call_et, st.VALUE, 
    s.sql_hash_value, s.sql_address, sq.sql_text 
FROM v$statname sn, v$sesstat st, v$process P, v$session s, v$sql sq 
WHERE s.paddr=P.addr 
  AND s.sql_hash_value = sq.hash_value AND s.sql_Address = sq.address 
  AND s.SID = st.SID 
  AND st.STATISTIC# = sn.statistic# 
  AND sn.NAME = 'CPU used by this session' 
  AND P.spid = 20386 ---- os PID parameter to restrict for a specific PID 
  AND s.status = 'ACTIVE' 
ORDER BY st.VALUE DESC



-- Collect Extended SQL Trace Data (Event 10046)
-- How to start tracing 
SQL> SELECT p.spid, s.sid, s.serial#, s.schemaname, s.machine, s.osuser
FROM v$session s, v$process p 
WHERE s.paddr = p.addr AND p.spid = 24078 
 
 
SPID 	SID  SERIAL# 
------ ----- ---------- 
24078 	18 	 5 




-- Top CPU Consuming SQL During A Certain Time Period
-- Note � in this case we are finding the Top 5 CPU intensive SQL statements executed between 9.00 AM and 11.00 AM

SELECT * 
FROM 
(
	SELECT SQL_ID, SUM(CPU_TIME_DELTA), 
		   SUM(DISK_READS_DELTA), COUNT(*)
	FROM DBA_HIST_SQLSTAT a, DBA_HIST_SNAPSHOT s
	WHERE s.SNAP_ID = a.SNAP_ID
	  AND s.Begin_Interval_Time > SYSDATE -1
	  AND EXTRACT(HOUR FROM S.END_INTERVAL_TIME) BETWEEN 9 AND 11
	GROUP BY SQL_ID 
	ORDER BY SUM(CPU_TIME_DELTA) DESC
)
WHERE ROWNUM

-- Top 5 SQL statements IN THE past one HOUR
SELECT * 
FROM 
(
    SELECT ash.SQL_ID, DBA_USERS.USERNAME,
     sqlarea.SQL_TEXT, SUM(ash.wait_time + ash.time_waited) ttl_wait_time
    FROM v$active_session_history ash, v$sqlarea sqlarea, dba_users
    WHERE ash.SAMPLE_TIME BETWEEN SYSDATE -  1/24  AND SYSDATE
      AND ash.sql_id = sqlarea.sql_id
      AND ash.user_id = dba_users.user_id
    GROUP BY ash.sql_id,sqlarea.sql_text, dba_users.username
    ORDER BY 4 DESC 
)
WHERE ROWNUM = 2


-- Top CPU consuming queries since past one day
SELECT * 
FROM 
(
	SELECT 
		SQL_ID, 
		SUM(CPU_TIME_DELTA), 
		SUM(DISK_READS_DELTA),
		COUNT(*)
	FROM 
		DBA_HIST_SQLSTAT A, DBA_HIST_SNAPSHOT S
	WHERE S.SNAP_ID = A.SNAP_ID
	 AND S.BEGIN_INTERVAL_TIME > SYSDATE -1
	GROUP BY SQL_ID
	ORDER BY SUM(CPU_TIME_DELTA) DESC
)
WHERE ROWNUM=1


-- Find what the top SQL was at a particular reported time of day
-- First determine the snapshot id values for the period in question.
-- In thos example we need to find the SNAP_ID for the period 10 PM to 11 PM on the 14th of November, 2012.

SELECT SNAP_ID,BEGIN_INTERVAL_TIME,END_INTERVAL_TIME
FROM DBA_HIST_SNAPSHOT
WHERE TO_CHAR(BEGIN_INTERVAL_TIME,'DD-MON-YYYY')='14-NOV-2012'
AND EXTRACT(HOUR FROM BEGIN_INTERVAL_TIME) BETWEEN 22 AND 23;


SELECT * FROM
(
	SELECT SQL.SQL_ID C1, SQL.BUFFER_GETS_DELTA C2, SQL.DISK_READS_DELTA C3, SQL.IOWAIT_DELTA C4
	FROM DBA_HIST_SQLSTAT SQL, DBA_HIST_SNAPSHOT S
	WHERE S.SNAP_ID = SQL.SNAP_ID AND S.SNAP_ID= &SNAPID ORDER BY C3 DESC
)
WHERE ROWNUM < 6 


-- Top 5 Queries for past week based on ADDM recommendations

/*

Top 10 SQL_ID's for the last 7 days as identified by ADDM
from DBA_ADVISOR_RECOMMENDATIONS and dba_advisor_log

*/
col SQL_ID form a16
col Benefit form 9999999999999

SELECT * 
FROM 
(
	SELECT B.ATTR1 AS SQL_ID, MAX(A.BENEFIT) AS "BENEFIT" 
	FROM DBA_ADVISOR_RECOMMENDATIONS A, DBA_ADVISOR_OBJECTS B 
	WHERE A.REC_ID = B.OBJECT_ID
	  AND A.TASK_ID = B.TASK_ID
	  AND A.TASK_ID IN (SELECT DISTINCT B.TASK_ID
						FROM DBA_HIST_SNAPSHOT A, DBA_ADVISOR_TASKS B, DBA_ADVISOR_LOG L
						WHERE A.BEGIN_INTERVAL_TIME > SYSDATE - 7 
						  AND  A.DBID = (SELECT DBID FROM V$DATABASE) 
						  AND A.INSTANCE_NUMBER = (SELECT INSTANCE_NUMBER FROM V$INSTANCE) 
						  AND TO_CHAR(A.BEGIN_INTERVAL_TIME, 'YYYYMMDDHH24') = TO_CHAR(B.CREATED, 'YYYYMMDDHH24') 
						  AND B.ADVISOR_NAME = 'ADDM' 
						  AND B.TASK_ID = L.TASK_ID 
						  AND L.STATUS = 'COMPLETED') 
	 AND LENGTH(B.ATTR4) > 1 GROUP BY B.ATTR1
   ORDER BY MAX(A.BENEFIT) DESC
) 
WHERE ROWNUM < 6;

**************************************** SPID **************************************** 
 
****************************************  Enable/Disable Trace  ****************************************   


-- Good URL for Trace File handling
-- https://oracle-base.com/articles/misc/sql-trace-10046-trcsess-and-tkprof

-- Start tracing  
SQL> begin dbms_system.set_ev(18,5, 10046,12,''); end; -- trace on 
 
-- collect trace information for approximately 15 minutes during the problem  
SQL> begin dbms_system.set_ev(18, 5, 10046,0,''); end; -- trace off 

-- This produced a trace file in the user_dump_dest directory. We used the tkprof 
-- utility to format the trace file and sort the SQL statements in descending order of highest fetch elapsed 
-- time as follows: 

tkprof ora_24078.trc 24078.prf sort=fchela 
 
$ cat 24078.prf 
<some lines removed for brevity> 
****************************************  Enable/Disable Trace  ****************************************   

****************************************  Remove Space from File Name Linux  **************************************** 

# mv �file with space.mp3? file_with_space.mp3

Now, the next command assumes that you have thousands of hundred of thousands MP3 files with spaces between 
its filenames. And you want to remove space character and replace them with underscores. Just make sure you are currently 
inside the working folder of these MP3 files and issue

# for files in *.mp3; do mv �$files� `echo $files | tr � � �_�`; done

Wonderful linux.

How to convert lower case filenames to uppercase filenames of hundred thousand files in one shot?

# for files in *.mp3; do mv �$files� `echo $files | tr �[:lower:]� �[:upper:]�`; done

You can replace *.mp3 with any other filename identifier or file glob.

****************************************  Remove Space from File Name Linux  **************************************** 


--Sessions:
select sid, serial#
from v$session s, dba_datapump_sessionsd
where s.saddr= d.saddr;

--PQ Sessions:
select sidfrom v$px_session
where qcsid= 23;

--Long Sessions:
select sid, serial#, sofar, totalwork
from v$session_longops
where opname= 'CASES_EXPORT'
and sofar!= totalwork;


****************************************  UTL_RECOMP Package  **************************************** 

The following examples show how these procedures care used:

    -- Schema level.
    EXEC UTL_RECOMP.recomp_serial('SCOTT');
    EXEC UTL_RECOMP.recomp_parallel(4, 'SCOTT');

    -- Database level.
    EXEC UTL_RECOMP.recomp_serial();
    EXEC UTL_RECOMP.recomp_parallel(4);

    -- Using job_queue_processes value.
    EXEC UTL_RECOMP.recomp_parallel();
    EXEC UTL_RECOMP.recomp_parallel(NULL, 'SCOTT');

There are a number of restrictions associated with the use of this package including:

    * Parallel execution is perfomed using the job queue. All existing jobs are marked as disabled until the operation is complete.
    * The package must be run from SQL*Plus as the SYS user, or another user with SYSDBA.
    * The package expects the STANDARD, DBMS_STANDARD, DBMS_JOB and DBMS_RANDOM to be present and valid.
    * Runnig DDL operations at the same time as this package may result in deadlocks.


-- Oracle version upgrade
http://onlineappsdba.com/index.php/2009/01/22/upgrade-oracle-database-10g-to-11g-r1-111x/


--********************************************************************--
-- recompile all objects

--please note that the process of recompiling an invalid object writes a significant amount of data to system tables and is fairly I/O intensive. 
--A slow disk system may be a significant bottleneck and limit speedups available from a higher degree of parallelism.

--Recompile all objects sequentially:
EXECUTE UTL_RECOMP.RECOMP_SERIAL();

--Recompile objects in schema SCOTT sequentially:
EXECUTE UTL_RECOMP.RECOMP_SERIAL('SCOTT');

--Recompile all objects using 4 parallel threads:
EXECUTE UTL_RECOMP.RECOMP_PARALLEL(4);

--Recompile objects in schema JOE using the number of threads specified in the parameter JOB_QUEUE_PROCESSES:
EXECUTE UTL_RECOMP.RECOMP_PARALLEL(NULL, 'JOE');


-- recompile the invalid objects in snox schema
exec dbms_utility.compile_schema(schema=>'SNOX');

****************************************  UTL_RECOMP Package  **************************************** 

production VDI 10.132.0.4
from local laptop RDP to 10.132.9.42 to access the production DB

select org.owner, org.object_type, org.status, org.org_cnt,
       dup.owner, dup.object_type, dup.status, dup.dup_cnt
(
    select owner, object_type, status, count(*) org_cnt
    from dba_objects
    where owner='SNOX4TRANSNOX_API'
    GROUP BY OWNER, OBJECT_TYPE, STATUS
)org
(
    select owner, object_type, status, count(*) dup_cnt
    from dba_objects
    where owner='SNOX4TRANSNOX_API_PUNE'
    GROUP BY OWNER, OBJECT_TYPE, STATUS 
)dup
where org.owner = substr(dup.owner,1,length(dup.owner)-5)
  and org.object_type = dup.object_type
order by 1,2,3 asc  


****************************************  DBMS_UTILITY Package  **************************************** 
-- DBMS_UTILITY package

-- get the CPU time taken by the procedure
--Returns the current CPU time in 100th's of a second
DECLARE
 i NUMBER;
 j NUMBER;
 k NUMBER;
BEGIN
  i := dbms_utility.get_cpu_time;

  SELECT COUNT(*)
  INTO j
  FROM all_tables t, all_indexes i
  WHERE t.tablespace_name = i.tablespace_name;

  k := dbms_utility.get_cpu_time;

  dbms_output.put_line(k-i);
END;
/

-- Create a stored procedure owned by a schema with the alter any user system privilege.
CREATE OR REPLACE PROCEDURE sp_alter_user (a_user_name VARCHAR2,
a_user_password VARCHAR2, a_admin VARCHAR2 := 'N') IS
 l_user VARCHAR2(255);
 l_user_grants VARCHAR2(255);
 l_user_default_role VARCHAR2(255);
BEGIN
  l_user := 'alter user ' || a_user_name ||
            ' identified by ' || a_user_password;

  -- If they need roles granted
  l_user_grants := 'GRANT connect,resource TO ' || a_user_name;

  l_user_default_role := 'alter user ' || a_user_name ||
  ' default role dba';

  dbms_utility.exec_ddl_statement(l_user);
  dbms_utility.exec_ddl_statement(l_user_grants);
  dbms_utility.exec_ddl_statement(l_user_default_role);
END sp_alter_user;
/


CREATE OR REPLACE PROCEDURE sp_create_user (a_user_name VARCHAR2,
a_user_password VARCHAR2, a_admin VARCHAR2 := 'N') IS
 l_user   VARCHAR2(255);
BEGIN
   l_user := 'create user ' || a_user_name ||
   ' identified by ' || a_user_password ||
   ' temporary tablespace temp';

   dbms_utility.exec_ddl_statement(l_user);

   sp_alter_user(a_user_name, a_user_password, a_admin);
END sp_create_user;
/



-- object dependency can be sreached like the below e.g..
exec dbms_utility.get_dependency('TABLE', 'UWCLASS', 'TESTTAB');

****************************************  DBMS_UTILITY Package  **************************************** 


****************************************  URLs for study  **************************************** 
-- good URL's for study

--- MySQL date_Forma function link 
http://www.w3schools.com/sql/func_date_format.asp


-- Hints for Optimization Approaches
http://www.oradev.com/hints.jsp

-- Configurating RMAN variables.
http://www.sc.ehu.es/siwebso/KZCC/Oracle_10g_Documentacion/server.101/b10734/rcmconfg.htm

-- export through the procedure
http://ergemp.blogspot.com/2008/02/scheduling-datapump-in-oracle-10g.html


http://www.dbazine.com/oracle/or-articles/still1 --- x ternal table


 http://books.google.co.in/books?id=14ZH0eZV6G8C&pg=PA231&lpg=PA231&dq=how+to+use+catupgrade.sql+in+oracle&source=bl&ots=brbd1N16Uz&sig=-2EYsmhfpEvgtHav6FM0G9_oUeA&hl=en&ei=SQipSavQDIm9kAW9ttjIDQ&sa=X&oi=book_result&resnum=6&ct=result#PPA131,M1 

-- example of converting rows into columns 
http://mennan.kagitkalem.com/ConvertingRowsToColumnsInOracle.aspx

-- for all undocumented init parameters
select ksppinm "Init_Param", ksppdesc "Description" 
from X$KSPPI
order by ksppinm asc

--index creation
http://www.psoug.org/reference/indexes.html#ixns

-- Good DBA query
http://www.shutdownabort.com

---------------------------------------------------------------------------
-- to check the previous qyery explain plan
execute the query with

explain plan for select * from employee;

1)  @?/rdbms/admin/utlxpls.sql

OR

2) select * from table(dbms_xplan.display)

 ---------------------------------------------------------------------------

-- RMAN Site
http://www.tiplib.com/kb/25/1/rman


--main link
http://dotproject.infonox.com:5000/index.php?m=projects&a=view&project_id=75


-- Oracle 10g New Features: Flashback and RMAN
http://www.orafaq.com/node/31

-- use this sit for reference for RMAN
http://download.oracle.com/docs/cd/B28359_01/backup.111/b28270/rcmquick.htm


-- 10G RMAN Part 1 and part 2
http://www.dbazine.com/blogs/blog-cf/chrisfoot/10grmanpart1
http://www.dbazine.com/blogs/blog-cf/chrisfoot/10grmanpart2


--replication sites
http://www.akadia.com/services/ora_replication_guide.html -- good coding

-- Streams Replication
http://www.oracle.com/technology/books/pdfs/book_rep_chap6_ce2.pdf

--Advance replications
http://www.wisdomforce.com/dweb/resources/docs/advanced_replication.pdf 

-- Replication Step-by-Step
http://stanford.edu/dept/itss/docs/oracle/10g/server.101/b10728/repsimpd.htm


-- RMAN Help
http://ss64.com/ora/rman_list.html

http://www.ctoedge.com/content/how-backup-and-restore-oracle-database-without-rman

-- RMAN
http://www.idevelopment.info/data/Oracle/DBA_tips/RMAN_9i/RMAN9_50.shtml

-- rman script explanation step by step
http://www.idevelopment.info/data/DBA_tips/RMAN_9i/RMAN9_7.shtml


****************************************  URLs for study  **************************************** 




****************************************  FORALL/Collection  **************************************** 
-- FORALL

-- PLS-00436 Restriction in FORALL Statements Removed

The PLS-00436 restriction has been removed, which means you can now reference the individual elements of a collection within the SET and 
WHERE clauses of a DML statement in a FORALL construct. To see this in action, create and populates a test table using the following code.

CREATE TABLE forall_test (
  id          NUMBER,
  description VARCHAR2(50)
);

INSERT INTO forall_test VALUES (1, 'ONE');
INSERT INTO forall_test VALUES (2, 'TWO');
INSERT INTO forall_test VALUES (3, 'THREE');
INSERT INTO forall_test VALUES (4, 'FOUR');
INSERT INTO forall_test VALUES (5, 'FIVE');
COMMIT;

The PL/SQL block below populates a collection with the existing data, amends the data in the collection, then updates the table with the amended data. 
The final query displays the changed data in the table.

DECLARE
  TYPE t_forall_test_tab IS TABLE OF forall_test%ROWTYPE;
  l_tab t_forall_test_tab;
BEGIN
  -- Retrieve the existing data into a collection.
  SELECT *
  BULK COLLECT INTO l_tab
  FROM   forall_test;

  -- Alter the data in the collection.
  FOR i IN l_tab.first .. l_tab.last LOOP
    l_tab(i).description := 'Description for ' || i;
  END LOOP;

  -- Update the table using the collection.
  FORALL i IN l_tab.first .. l_tab.last
    UPDATE forall_test
    SET    description = l_tab(i).description
    WHERE  id          = l_tab(i).id;

  COMMIT;
END;
/

SELECT * FROM forall_test;

        ID DESCRIPTION
---------- ---------------------------
         1 Description for 1
         2 Description for 2
         3 Description for 3
         4 Description for 4
         5 Description for 5

5 rows selected.

SQL>


--Next example of ForAll statment using Bulk Collect
CREATE OR REPLACE PROCEDURE UPD_FOR_DEPT
(
    V_depart_id IN  employee.department_id%type,
	v_NewSalary IN  employee.salary%type
)
is  
  type employee_tt is table of employee.employee_id%type  
      index by binary_integer;
	  employees employee_tt;
	  
type salary_tt is table of employee.salary%type  
      index by binary_integer;
	  salaries salary_tt;

type hire_date_tt is table of employee.hire_date%type  
      index by binary_integer;
	  hire_dates hire_date_tt;

begin
   select employee_id, salary, hire_date
   bulk collect into employees, salaries, hire_dates
   from employee
   where department_id = V_depart_id
   for update;
   
   forall indx inemployees.first ..employees.last
   insert into employee_history(employee_id, salary, hire_date)
   vales(employees(indx), salaries(indx), hire_dates(indx));
   
   forall indx in employees.first ..employee.last
   update employee
   set salary = v_NewSalary,
       hire_date = hire_dates(indx),
   where employee_id = employees (indx);

end UPD_FOR_DEPT;
/
	   	  
--********************************************************************--
****************************************  FORALL/Collection  **************************************** 


--********************************************************************--
-- Query returns date as per different time zone in the database

SELECT date_created, TO_DATE(TO_CHAR(TO_TIMESTAMP_TZ(TO_CHAR(date_created,'mm/dd/yyyy hh24:mi:ss'), 'mm/dd/yyyy hh24:mi:ss tzr') AT TIME ZONE TIME_ZONE,'mm/dd/yyyy hh24:mi:ss'),'mm/dd/yyyy hh24:mi:ss') AS merchant_time_zone 
FROM snox4transnox.merchant;


--********************************************************************--
-- Query returns the date of last months starting and ending date

SELECT ADD_MONTHS(TRUNC(SYSDATE,'MM'),-1) Last_Months_1day,
  TO_DATE(TO_CHAR(TRUNC(SYSDATE,'MM')-1,'mm/dd/yyyy')||' 23:59:59','mm/dd/yyyy hh24:mi:ss') Last_Months_lastDay
FROM dual;

-- will return the first of next month 11:00:00 AM
select ADD_MONTHS(TRUNC(SYSDATE,'MM'),+1)+11/24 from dual;
--********************************************************************--

-- check the answer for the same link
http://asktom.oracle.com/pls/asktom/f?p=100:11:0::NO::P11_QUESTION_ID:1619550482617



**************************************** Insert Nth Number of Recrods **************************************** 

--- insert 100000 records at a time
INSERT INTO transnox_cpass.TRANS_ATM  
(
SELECT transnox_cpass.seq_trans_atm.NEXTVAL,SUBSTR(dbms_random.value(1,10),25), SUBSTR(dbms_random.value(1,10),37)
FROM dual
connect BY LEVEL <= 100000
 );
 
SELECT MAX(LENGTH(ID)) FROM 
(
  SELECT SUBSTR(dbms_random.value(1,10),31) ID, SUBSTR(dbms_random.value(1,10),25), RPAD('*',16,'*' ) DATA
  FROM dual
  connect BY LEVEL <= 100000
)
**************************************** Insert Nth Number of Recrods **************************************** 


**************************************** RENAMING OBJECTS **************************************** 
-- How to rename the Table, Column, constraint, Index

SQL> Rename test to test1;
SQL> ALTER TABLE test RENAME TO test;

SQL> ALTER TABLE test RENAME COLUMN col2 TO description;

SQL> ALTER TABLE test RENAME CONSTRAINT test1_pk TO test_pk;
SQL> ALTER TABLE test RENAME CONSTRAINT FK_test1 TO test_foreign_key;

SQL> ALTER INDEX test1_pk RENAME TO test_pk;

SQL> ALTER TABLE TRANSNOX_GCA.TRANSACTION_11 RENAME TO TRANSACTION;

**************************************** RENAMING OBJECTS **************************************** 


**************************************** PARTITIONS **************************************** 

SQL> CREATE TABLE table2000
  2  ( x int,
  3    y int,
  4    z DATE
  5  )
  6  PARTITION BY RANGE (z)
  7  (
  8  PARTITION tab_1999_h1 VALUES LESS
  9  THAN(to_date('30-jun-1999','dd-mon-yyyy')),
 10  PARTITION tab_1999_h2 VALUES LESS
 11  THAN(to_date('31-dec-1999','dd-mon-yyyy')),
 12  PARTITION tab_2000_h1 VALUES LESS
 13  THAN(to_date('30-jun-2000','dd-mon-yyyy')),
 14  PARTITION tab_2000_h2 VALUES LESS
 15  THAN(to_date('31-dec-2000','dd-mon-yyyy'))
 16  )
 17  /

Table created.

insert into table2000  values ( 1, 1, '15-jun-1999' );
insert into table2000  values ( 2, 2, '15-dec-1999' );
insert into table2000  values ( 3, 3, '15-jun-2000' );
insert into table2000  values ( 4, 4, '15-dec-2000' );


SQL> CREATE TABLE new_table2000
	( x int,
	  y int,
	  z DATE
	)
	PARTITION BY RANGE (z)
	(
	PARTITION newtab_1999_h1 VALUES LESS
	THAN(to_date('30-jun-1999','dd-mon-yyyy')),
	PARTITION newtab_1999_h2 VALUES LESS
	THAN(to_date('31-dec-1999','dd-mon-yyyy'))
	)
/

Table created.

insert into NEW_table2000  values ( -1, -1, '15-jun-1999' );
insert into NEW_table2000  values ( -2, -2, '15-dec-1999' );


--So, how to make the NEW partitions replace the old?  we will make A new partition 
--become a table and swap that table for an OLD partition.  It'll look like this:

SQL> create table temp ( x int, y int, z date );
Table created.

SQL> alter table new_table2000 exchange partition newtab_1999_h1  with table temp;

Table altered.

SQL> 
SQL> alter table table2000  exchange partition tab_1999_h1  with table temp;

Table altered.

SQL> 
SQL> rename temp to table2000_tab_1999_h1;

Table renamed.

SQL> 


-- Renaming a table partition
SQL> ALTER TABLE range_list RENAME PARTITION sf TO sales_future;

-- good link for table partition syntax
http://psoug.org/reference/partitions.html



--- Processes of archiving parition table 

CREATE TABLE <Schema_Name>.<New_Arch_TableName> AS
SELECT * 
FROM <schema_name>.<Partition_Table_Name>
WHERE 1=2;

ALTER TABLE <schema_name>.<Partition_Table_Name> 
EXCHANGE PARTITION <Partition_Name>
WITH TABLE <Schema_Name>.<New_Arch_TableName>
EXCLUDING INDEXES
WITHOUT VALIDATION
UPDATE GLOBAL INDEXES;

ALTER TABLE <Schema_Name>.<New_Arch_TableName> DROP PARTITION <Partition_Name>;

-- for e.g >>> ALTER TABLE range_list DROP PARTITION s2k UPDATE GLOBAL INDEXES;


Analyze Parition tables and Indexes

Compile Schemas

-- for e.g....

SELECT * FROM list_part PARTITION (q1_northwest);


-- Local Indexes
CREATE INDEX year_idx
on all_fact (order_date)
LOCAL
(PARTITION name_idx1),
(PARTITION name_idx2),
(PARTITION name_idx3);



-- Global Indexes
CREATE INDEX item_idx
on all_fact (item_nbr)
GLOBAL
(PARTITION city_idx1 VALUES LESS THAN (100)),
(PARTITION city_idx1 VALUES LESS THAN (200)),
(PARTITION city_idx1 VALUES LESS THAN (300)),
(PARTITION city_idx1 VALUES LESS THAN (400)),
(PARTITION city_idx1 VALUES LESS THAN (500));

-- A global partitioned index is used for all other indexes except for the one that is used as the table partition key.

-- change the interval partition from year to month and month to day
--
ALTER TABLE SNOX4TRANSNOX.INFONOX_SERVICE_USAGE SET INTERVAL(NUMTOYMINTERVAL(1,'MONTH'));

--
ALTER TABLE SNOX4TRANSNOX.INFONOX_SERVICE_USAGE SET INTERVAL (NUMTODSINTERVAL(7,'day'));


**************************************** PARTITIONS **************************************** 


--********************************************************************--
 -- Undocumented SQL function SYS_OP_MAP_NONNULL
 
 -- This function makes it possible to have NULL = NULL:
SELECT 'hi there'
FROM DUAL
WHERE sys_op_map_nonnull (NULL) = sys_op_map_nonnull (NULL);
    
--*******************************************************************--

-- Query list the TIMEZONE name available  in the database
SELECT tzname, tzabbrev FROM V$TIMEZONE_NAMES;

--********************************************************************--


--get the sequence number 
select rno from ( select rownum rno from dual connect by level <= 10)

--********************************************************************--


**************************************** DBMS_METADATA **************************************** 

-- if you wanted to find all indexes on a particular table and generate the DDL you 
-- need only change the object_type to INDEX.

SELECT  DBMS_METADATA.GET_DEPENDENT_DDL('INDEX','TRANSACTION','TRANSNOX_IOX') from dual; 

--********************************************************************--

-- You can get the DDL information of any object by DBMS_METADATA.GET_DDL function....

-- get the procedure code from particular schema
select DBMS_METADATA.GET_DDL('PROCEDURE',u.object_name)
from DBA_objects u
where object_type = 'PROCEDURE'
   and u.owner='SYSTEM'
   and u.object_name='MAILSERVER_ACL'


-- get all the procedure code from the connected schema
select DBMS_METADATA.GET_DDL('PROCEDURE',u.object_name)
from user_objects u
where object_type = 'PROCEDURE';


-- get table structure of table of particular schema
select DBMS_METADATA.GET_DDL('TABLE',u.object_name)
from dba_objects u
where object_type = 'TABLE' 
  and object_name='BILLING_CLIENT_DATA' 
  AND OWNER='SYSTEM'


-- get the privileges given to rahulc schema
select DBMS_METADATA.GET_GRANTED_DDL('SYSTEM_GRANT','RAHULC') from dual;


-- get the object privileges which are given to transnox_iox schema
select DBMS_METADATA.GET_GRANTED_DDL('OBJECT_GRANT','TRANSNOX_IOX') from dual;


**************************************** DBMS_METADATA **************************************** 


**************************************** Oracle Regular Expressions **************************************** 
-- if you search for content where the second character is L,D or S, you can do it with:

select ename
from emp
where ename like '_L%'
or ename like '_D%' 
or ename like '_S%'; 

-- But with REGEXP_LIKE it is like this:

select ename
from emp
where regexp_like(ename,'^.[LDS]');

REGEXP_REPLACE (NVL (rcs.Consumer_Zip_Code, ' '),'[[:alnum:]]','')
                           
-- sreach the object_name which are having any number starting 0 to 9 at last 
regexp_like(object_name, '[0-9]$','i')

-- Object_name starting with W or O
regexp_like(object_name, '^[WO]','i')

-- search all those table_name which are starting with sn_temp and sc_temp
regexp_like(table_name,'^SN_TEMP|SC_TEMP','i')
OR
regexp_like(table_name,'^(SN|SC)_TEMP','i')
OR
REGEXP_LIKE(object_name,'S._TEMP[[:digit:]]','i') --- use it 

-- searching for all-numeric data. The caret (^) START and dollar 
-- ($) END denotes of the line, respectively. 
-- The plus (+) after the digit class represents one or more occurrences.
REGEXP_LIKE(x, '^[0-9]+$');

--The following query returns the first and last names for those employees with a 
--first name of Steven or Stephen (where first_name begins with Ste and ends with en and 
--in between is either v or ph)
SELECT first_name, last_name
FROM employees
WHERE REGEXP_LIKE (first_name, '^Ste(v|ph)en$');

--Using the Regexp_like operator to identify sales people whose last names begin with a "W" and end with an "N"
Regexp_like (last_name, '^W.*N$');

--Using the Regexp_like operator to identify sales people whose last names begin with a "W" or "V" and end with an "N"
Regexp_like (last_name, '^(W|V).*N$');

--Using the Regexp_like operator to identify sales people with an "FF", "FL", "LF", or "LL" in their last name
Regexp_like (last_name, '.*(F|L){2}.*');

--Using the Regexp_like operator to identify sales people with five consecutive digits in the address
Regexp_like (address, '[[:digit:]]{5}')

--Using the Regexp_like operator and Character classes to identify two digit address numbers
Regexp_like (address, '^[[:digit:]][[:digit:]][[:space:]]');

--Using the range (-) symbol to identify sales people whose names begin with characters between K and R
--A hyphen (-) is used in the character list to indicate a range of values.
Regexp_like (last_name, '^[K-R]');

--Using the Negate carot to identify addresses that do not begin with alphabetic characters
--Carots (^) placed inside a character list are not anchor symbols.  They are the negate symbol.
Regexp_like (address, '^[^[:alpha:]]{4}');

-- will return those object_name which will not have any number in the name of the objects
not REGEXP_LIKE(object_name,'[[:digit:]]','i')


-- This query uses the regular expression metacharacter period (.), which matches any character. The expression does not
-- look for three periods followed by a dash followed by four periods. It looks for any three characters, followed by a dash,
-- followed by any four characters.
SELECT park_name
FROM park
WHERE REGEXP_LIKE(description, '...-....');


-- some more (Class Operators) Regular Expressions hints
[:digit:]   Any digit
[:alpha:]   Any upper or lower case letter
[:lower:]   Any lower case letter
[:upper:]   Any upper case letter
[:alnum:]   Any upper or lower case letter or number
[:xdigit:]  Any hex digit
[:blank:]   Space or Tab
[:space:]   Space, tab, return, line feed, form feed
[:cntrl:]   Control Character, non printing
[:print:]   Printable character including a space
[:graph:]   Printable characters, excluding space.
[:punct:]   Punctuation character, not a control character or alphanumeric
 

 /*
Regular Expression Patterns.

Regular Expressions have a formal definition as part of the POSIX standard.  Different symbols define how a pattern is described.  Let�s start with the basic symbols.

Characters and Numbers represent themselves.  If you are searching for �abc� then the matching pattern is abc.  

Period (.) represents any single character or number.  The pattern �b.e� will match bee, bye, b3e but not bei, or b55e.  Likewise the pattern �..-..=��  matches any 
two characters, followed by a dash, followed by any two characters, followed by an equal sign, followed by any three characters.

Star (*) represent zero or more characters.  The pattern �b.*e will match bee, bye, beee, bzyxe and be.  The pattern �..-..=.*� can end with zero or more characters after the equal sign. 

Plus (+) represents one or more characters.  This pattern is the same a �.*� except that there must be one character.  Using the pattern �b.+e� the string �be� will not match.

Question Mark (?) represents zero or one character.  The pattern �..-..=.?� can only end with one character or no character after the equal sign.

If I wanted to match a US telephone number, I could use the pattern ��-�-�.�.  This pattern will match any three characters, followed by a dash, followed by 3 more characters, followed by 
a dash and four final characters.  So the string �123-456-7891� will match this pattern.  Well so will �abc-def-ghij�.  So this simple patter will match a lot of strings that are not phone numbers.  
We will improve on this pattern in a moment.

Brackets are used to define numbers of characters.  

{count}  defines an exact number of characters.  The pattern a{3) defines exactly three character �a�.  Used with the period, the {count} defines the number of characters.  The phone number
example could be written as the pattern �.{3}-.{3}-.{4}�.  

Note:  When used with many applications, the bracket already has a meaning and to use it in a expression is must be escaped, normally with a slash.  �.\{3\}-\{3\}-\{4\}�  In this example the slash �\� simply escapes the bracket.  With Oracle, this is not necessary.

{min,max} defines a minimum and maximum number of characters.  The pattern �.{2,8}� will match any 2 or more characters, up to 8 characters.

{min,} defines the minimum or more number of characters.  The pattern �sto{1,}p� will match any string that has �st� followed by one or more �o�, followed by a �p�.  This includes stop, stoop, stooooop, but not stp or stoip.

Square Brackets are used to define a subset of the expression.  Any one character in the bracket will match the pattern.  If I want only a number character then I could use a pattern like �[0123456789]�.  
 The phone number pattern could be written as: 

�[0123456789]{3}-[0123456789]{3}-[0123456789]{4}�  

With this pattern, I have excluded all the letters from matching strings.  A range of characters can also be defined in square brackets.  This is easier to type and read.  The range is defined using the 
dash between the min and max. The phone example now becomes:

�[0-9]{3}-[0-9]{3}-[0-9]{4}�

Ranges of letters can also be defined.  The pattern �st[aeiou][A-Za-z]� matches any string with the characters �st� followed by a vowel, followed by any character, upper or lower case.  
This pattern matches stop, stay, staY, stud.  The pattern �abc[1-9]� matches abc1, abc2, abc3,�

The caret [^] in square brackets matches any character except those following the caret.  The pattern �st[^o]p will match step, strp, but not stop.

So far, all the patterns match is the pattern is found anywhere in the line of text.  Use the caret and dollar sign to define patterns that match the start or end of a string.

^ defines that start of a string or column 1 of the string.

$ defines the end of a string or the last column.  This does not included carriage returns and line feeds.

The pattern �^St[a-z]*� matches a string that starts with �St� followed by zero or more lower case letters.  The pattern �stop$� only matches �stop� if it is the last word on the line.

| or vertical line defines the Boolean OR.  The patter �[1-9]|[a-z]� matched any number or lower case letter.  The pattern �stop|step� matches the strings stop or step.

\ or backward slash is the escape character.   This is use to tell the parser that the character following it is to be taken literally.  In the note earlier, it was pointed out that
 some characters have special meaning in some applications and must be escaped to tell the application to use that literal character.  Another reason to escape a character is when you want 
 to actually use the character in your matching pattern.  For example, if you want to match a number that has two decimal places you could use the pattern:

�[0-9]+.[0-9]{2}�

This example looks right but will not match the pattern that we are looking for.  The period we use to represent the decimal place, will actually match any character.  We must tell 
the expression parser that we want the character period and we do that by escaping the period character.

�[0-9]+\.[0-9]{2}�

Now the pattern will match one or more digits followed by a period and exactly two digits.

Class Operators

Class operators are used as an alternative way to define classes of characters.  They are defined in the format [: class :].

-- some more Regular Expressions hints
[:digit:]   Any digit
[:alpha:]   Any upper or lower case letter
[:lower:]   Any lower case letter
[:upper:]   Any upper case letter
[:alnum:]   Any upper or lower case letter or number
[:xdigit:]  Any hex digit
[:blank:]   Space or Tab
[:space:]   Space, tab, return, line feed, form feed
[:cntrl:]   Control Character, non printing
[:print:]   Printable character including a space
[:graph:]   Printable characters, excluding space.
[:punct:]   Punctuation character, not a control character or alphanume

Again, these class operators represent other characters.  The phone number example can be rewritten using class operators.

�[:digit:]{3}-[:digit:]{3}-[:digit:]{4}�

Being Greedy
Regular expressions are greedy.  By this we mean that the expression will match the largest string it can.  Think of it as the expression parser takes the entire sting and 
compares it to the pattern.  The parser then gives back characters until it finds that the string has no match or if finds the match.

Lets use a string �0123423434�

If my pattern is �.*4�  (zero of more characters followed by the digit 4).

The first match will be the entire sting.

Expression Grouping
Expression Grouping allows part of the pattern to be grouped.  This is also called tagging or referencing.  You group an expression by surrounding it with parens.  There can be only 9 
groups in a pattern.  Below is an example that contains two groups.

�([a-z]+) ([a-z]+)�

This pattern matches two lower case words.  Using a string defined as �fast stop�, the first group would contain �fast� and the second group �stop�.  The groups are 
referenced by a backward slash and the group number.  �\1� references �fast� while �\2� reference �stop�.  Thus \2 \1 results in �stop fast�.

Oracle and Regular Expressions
The Oracle 10g database provides four functions to implement Regular Expressions.  The Java Virtual Machine in the database also implements the Java support for Regular Expression.  
The four functions can be used in SQL statements or PL/SQL.  They operate on the database character datatypes to include VARCHAR2, CHAR, CLOB, NVARCHAR2, NCHAR, and NCLOB.  The four functions are:

REGEXP_LIKE       Returns true is the pattern is matched, otherwise false.
REGEXP_INSTR      Returns the position of the start  or end of the matching string.  Returns zero if the pattern does not match.
REGEXP_REPLACE    Returns a string where each matching string is replaced with the text specified.
REGEXP_SUBSTR     Returns the matching string, or NULL if no match is found.

Let�s look at each of the functions and how to put them to use.
 

REGEXP_LIKE
Syntax:  regexp_like(source, pattern(, options));

The source is a text literal, variable or column.  The pattern is the expression you are looking for.  The options define how the matching will take place.  The options are:

i = case insensitive

c = case sensitive

n = the period will match a new line character

m = allows the ^ and $ to match the beginning and end of lines contained in the source.  Normally these characters would match the beginning and end of the source.  This is for multi-line sources.

This function can be used anywhere a Boolean result is acceptable. 

begin
  n_phone_number varchar2(20);
  �
begin
  �
  if (regexp_like(n_phone_number, .*[567]$)) then �
  end if;
  �
end;
If the phone number ends in either 5,6 or 7, the return it true and the THEN clause is executed.

In a SQL statement, this function can only be used in the WHERE or HAVING clause.

select
   �
   phone
from
  �
where regexp_like(phone, .*[567]$);
 

The REGEXP_LIKE function can also be used in check constraints.

 

REGEXP_REPLACE
Syntax:  regexp_replace( source, pattern, replace string, position, occurrence, options)

The source can be a string literal, variable, or column.  The pattern is the expression to be replaced.  The replace string is the text that will replace the matching patterns.  
The optional position defines the location to begin searching the source string.  This defaults to 1.  The optional occurrence defines the occurrence of the pattern that you want replaced.  
This defaults to 0 (all occurrences).  Setting this to a positive number will result in only that occurrence being replaced.  The matching options are the same.

select
  regexp_replace('We are driving south by south east',
                 'south', 'north')
from dual;
 

We are driving north by north east

REGEXP_INSTR
Syntax:  regexp_instr(source, pattern, position, occurrence, begin_end, options)

The source can be a string literal, variable, or column.  The pattern is the expression to be replaced.  The optional position is the location to begin the search and defaults to 1.  
The occurrence defines the occurrence you are looking for.  The begin_end defines whether you want the position of the beginning of the occurrence or the position of the end of the occurrence.  
This defaults to 0 which is the beginning of the occurrence.  Use 1 to get the end position.  The matching options are the same.

select
  regexp_instr('We are driving south by south east', 'south')
from dual;
 
16
select
  regexp_instr('We are driving south by south east', 'south', 1, 2, 1)
from dual;
 
30
 

REGEXP_SUBSTR
Syntax:  regexp_substr(source, pattern, position, occurrence, options)

The source can be a string literal, variable, or column.  
The pattern is the expression to be replaced.  
The optional position is the location to begin the search and defaults to 1.  
The optional occurrence defines the occurrence you are looking for.  
The matching options are the same.

select
  regexp_substr('We are driving south by south east', 'south')
from dual;
 
south 
 
*/




---- More Specific on RegExp..

/*

Anchoring Characters are metacharacters that 
affect the position of the search.
----------------------------------------------------
Character Class      Description
^      Anchor the expression to the start of a line
$      Anchor the expression to the end of a line
 
 
 
Equivalence Classes      
----------------------------------------------------
Character Class      Description
= =      Oracle supports the equivalence classes through 
        the POSIX '[==]' syntax. A base letter and all of 
        its accented versions constitute an equivalence 
        class. For example, the equivalence class '[=a=]' 
        matches � and �. The equivalence classes are valid 
        only inside the bracketed expression
 
 
Match Options determine if the target is treated checked for 
case-sensitivity and whether or not the target is evaluated 
line by line or as a continuous string. 
----------------------------------------------------
Character Class      Description
c      Case sensitive matching
i      Case insensitive matching
m      Treat source string as multi-line activating Anchor chars
n      Allow the period (.) to match any newline character
 
 
 
Posix Characters tend to look very ugly but have the advantage 
that also take into account the 'locale', that is, any variant 
of the local language/coding system.
----------------------------------------------------
Character Class      Description
[:digit:]      Only the digits 0 to 9
[:alnum:]      Any alphanumeric character 0 to 9 OR A to Z or a to z.
[:alpha:]      Any alpha character A to Z or a to z.
[:blank:]      Space and TAB characters only.
[:xdigit:]     Hexadecimal notation 0-9, A-F, a-f.
[:punct:]      Punctuation symbols 
                --------------------------------
                % . , " ' ? ! : # $ & ( ) * ;
                + - / < > = @ [ ] \ ^ _ { } | ~
                --------------------------------
[:print:]      Any printable character.
[:space:]      Any whitespace characters (space, tab, NL, FF, VT, CR). 
                Many system abbreviate as \s.
[:graph:]      Exclude whitespace (SPACE, TAB). Many system abbreviate as \W.
[:upper:]      Any alpha character A to Z.
[:lower:]      Any alpha character a to z.
[:cntrl:]      Control Characters NL CR LF TAB VT FF NUL SOH STX 
                EXT EOT ENQ ACK SO SI DLE DC1 DC2 DC3 DC4 NAK SYN 
                ETB CAN EM SUB ESC IS1 IS2 IS3 IS4 DEL.
 
 
Quantifier Characters control the number of times a character 
or string is found in a search.
----------------------------------------------------
Character Class      Description
*      Match 0 or more times
?      Match 0 or 1 time
+      Match 1 or more times
{m}      Match exactly m times
{m,}      Match at least m times
{m, n}      Match at least m times but no more than n times
\n      Cause the previous expression to be repeated n times
 
 
 
Alternative Matching And Grouping Characters      
----------------------------------------------------
Character Class      Description
|      Separates alternates, often used with grouping 
        operator ()
 
( )      Groups subexpression into a unit for alternations, for 
        quantifiers, or for backreferencing 
 
[char]      Indicates a character list; most metacharacters inside a
        character list are understood as literals, with the 
        exception of character classes, and the ^ 
        and - metacharacters
 
 
////////////////////////////////////////////////////
Regex Cheat Sheet (non-posix)
////////////////////////////////////////////////////
 
 
Modifiers: 
i   case-insensitive pattern matching. 
 
g   global replace, or replace all 
 
m   Treat string as multiple lines. That is, 
    change ``^'' and ``$'' from matching at only 
    the very start or end of the string to the 
    start or end of any line anywhere within the string 
 
s   Treat string as single line. That is, change ``.'' to 
    match any character whatsoever, even a newline, which 
    it normally would not match. 
 
x   Extend your pattern's legibility by permitting 
    whitespace and comments.
 
 
Special Characters:
The following should be escaped if you are trying to 
match that character:
 
 \  ^  .  $  |  (  )  [  ]
 *  +  ?  {  }  ,
 
 
Special Character Definitions:
    \   Quote the next metacharacter
    ^   Match the beginning of the line
    .   Match any character (except newline)
    $   Match the end of the line (or before newline at the end)
    |   Alternation
    ()  Grouping
    []  Character class
    *      Match 0 or more times
    +      Match 1 or more times
    ?      Match 1 or 0 times
    {n}    Match exactly n times
    {n,}   Match at least n times
    {n,m}  Match at least n but not more than m times
 
More Special Characters: 
    \t          tab                   (HT, TAB)
    \n          newline               (LF, NL)
    \r          return                (CR)
    \f          form feed             (FF)
    \a          alarm (bell)          (BEL)
    \e          escape (think troff)  (ESC)
    \033        octal char (think of a PDP-11)
    \x1B        hex char
    \c[         control char
    \l          lowercase next char (think vi)
    \u          uppercase next char (think vi)
    \L          lowercase till \E (think vi)
    \U          uppercase till \E (think vi)
    \E          end case modification (think vi)
    \Q          quote (disable) pattern metacharacters till \E
 
Even More Special Characters:
    \w  Match a "word" character (alphanumeric plus "_")
    \W  Match a non-word character
    \s  Match a whitespace character
    \S  Match a non-whitespace character
    \d  Match a digit character
    \D  Match a non-digit character
    \b  Match a word boundary
    \B  Match a non-(word boundary)
    \A  Match only at beginning of string
    \Z  Match only at end of string, or before newline at the end
    \z  Match only at end of string
    \G  Match only where previous m//g left off (works only with /g)
 

*/

-- This is telling Oracle to start at the punct and include all characters until u reach a comma (include the comma as well).
SELECT regexp_substr( 'Employee Name and Age: Adam, Dana 28', '[:punct:][^,]+,' ) "REGEXP_SUBSTR"
FROM dual;

-- What if you want to find the number in the string?
SELECT regexp_substr( 'Employee Name and Age: Adam, Dana 28', '[[:digit:]]+' ) "REGEXP_SUBSTR"
FROM dual;


-- Tells oracle to start the string at the '-' character.  [^-] tells oracle to continue until it finds another '-' character.  
SELECT regexp_substr( '655-236-4567', '-[^-]+' ) "REGEXP_SUBSTR"
FROM dual;

-- Note that if you add an extra '-' at the end of the regular expression you will get the trailing '-' as part of the returned string:
SELECT regexp_substr( '655-236-4567', '-[^-]+-' ) "REGEXP_SUBSTR"
FROM dual;


Out put of REGEXP_SUBSTR
-236-

-- find the last '.' in the statment and returns all the characters followed by it.
-- so if there is value 'xyz.qos.jopuyt.sql' then it will return 'sql'
select REGEXP_SUBSTR(file_name, '[^.]+.$') from dual;


The basic regular expressions that for regexp_replace()

1- To remove duplicate white space and all carriage returns and linefeeds (this flattens the query into one line):

   regexp_replace(sql_text, '[[:space:]]+',' ' )
   
2- To transform all numeric literals into �:NUM�. The premise is that all numeric literals must be preceded by either one of 
"(=+, -" Otherwise, it is considered to be an identifier or a string literal:

   regexp_replace('([(=<>+, -])[0-9]+.?[0-9]*','1:NUM')
   
   
3- To transform all string literals into ��:STR��. For example, the string �select �abc� from dual� would be translated into 
�select �:STR� from dual� :

   regexp_replace('''(.)*?''',''':STR''' )
   
The final Oracle function call looks like this (three embedded regexp_replace):

   regexp_replace(
   regexp_replace(
   regexp_replace(sql_text, '[[:space:]]+',' ' ),
                  '([(=<>+, -])[0-9]+.?[0-9]*','1:NUM'),
                  '''(.)*?''',''':STR''' )



**************************************** Oracle Regular Expressions **************************************** 



--********************************************************************--
-- Modify the profile and keep the password same as it was.

SELECT * 
FROM dba_users 
WHERE username ='RAHULC'

ALTER PROFILE dbusers LIMIT PASSWORD_VERIFY_FUNCTION NULL

ALTER USER rahulc PROFILE DEFAULT 

ALTER USER rahulc IDENTIFIED BY "ispl2"

ALTER USER rahulc PROFILE dbusers

ALTER PROFILE dbusers LIMIT PASSWORD_VERIFY_FUNCTION VERIFY_FUNCTION;

--********************************************************************--

-- gives the list of those table which are not having an reference to/from 
-- any table within the schema
select table_name
from dba_tables o
where not exists (select 'x'    
                  from dba_constraints i
                  where i.TABLE_NAME = o.TABLE_NAME
                    and i.CONSTRAINT_TYPE = 'R'
                    AND i.CONSTRAINT_TYPE NOT IN ('P','U')
                    and i.owner = o.OWNER)
 and o.OWNER = 'TRANSHMS'

--********************************************************************--



select trunc(sysdate + 1) + 4/24 from dual

---********************************************************************--
-- To Execute any DDL Command from DBMS packages
DBMS_UTILITY.EXEC_DDL_STATEMENT('TRUNCATE TABLE AGENT_MERCHANt_proofs_ins;');
---********************************************************************--



--linux shorcuts 
http://www.csb.yale.edu/userguides/wordprocess/vi-summary.html


**************************************** SQLPLUS Command Line **************************************** 
------------------->>>>>>>>>>>>>>>>>>>>>>>
mydate=`date +%y%b%d`

exp  exportuser/expnox418@COMSDB file=/ora6/oracle/coms_amms/exp_amms_bkup.dmp log=/ora6/oracle/coms_amms/exp_amms_bkup_$mydate.log statistics=none tables=transcapitalone.APP_MER_MERCHANTSCOUT grants=n INDEXES=n CONSISTENT=n triggers=n query=\" where APPLICATION_ID \< 39911\" buffer=50000

export ORACLE_SID=aqprod

sqlplus "expuser/expbkups@aqprod" << EOF

spool /ora6/oracle/coms_amms/truncate_amms.log

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')Start_Date from dual;

truncate table transcapitalone.APP_MER_MERCHANTSCOUT;

select to_char(sysdate,'mm/dd/yyyy hh24:mi:ss')End_Date from dual;

spool off;


host imp expuser/expbkups@aqprod file=/ora6/oracle/coms_amms/exp_amms_bkup.dmp log=/ora6/oracle/coms_amms/imp_amms_bkup_$mydate.log fromuser=transcapitalone touser=transcapitalone ignore=y

rm -f /ora6/oracle/coms_amms/exp_amms_bkup.dmp

EOF
------------------->>>>>>>>>>>>>>>>>>>>>>>
---********************************************************************--
"
**************************************** SQLPLUS Command Line **************************************** 


--Create a public database link named, oralink, to an Oracle database named, 
--xe, located at 127.0.0.1 on port 1521. Connect to the Oracle database with 
--username, edb, and password, password.

CREATE PUBLIC DATABASE LINK oralink 
CONNECT TO edb IDENTIFIED BY 'password' USING '//127.0.0.1:1521/xe';

-- can create direct with using iP and port with SID name
create database link "repl_source"
connect to rahulc
identified by "ispl_201"
using '//10.240.1.14:1521/dev'; 

create database link "repl_source"
connect to rahulc
identified by "ispl_201"
using 'dev14';

-- this entry should be in tnsnames.ora of database server.

---********************************************************************--


SELECT TO_CHAR(time_stamp,'dd/mm/yyyy')dt, COUNT(*) ct_data
FROM transnox_gca.TRANSACTION
WHERE TIME_STAMP BETWEEN TO_DATE('01/01/2009 00:00:00','mm/dd/yyyy hh24:mi;ss')
                    AND TO_DATE('10/31/2009 23:59:59','mm/dd/yyyy hh24:mi;ss')
GROUP BY TO_CHAR(time_stamp,'dd/mm/yyyy')
ORDER BY TO_DATE(TO_CHAR(time_stamp,'dd/mm/yyyy'),'dd/mm/yyyy')


---********************************************************************--

--If you wish, however, it is still possible to revert to case insensitivity by 
--altering a system parameter, SEC_CASE_SENSITIVE_LOGON, as shown in the example 
--below.
-- in oracle 11G
SQL> conn / as sysdba
Connected.
SQL>  alter system set sec_case_sensitive_logon = false;


---********************************************************************--

**************************************** OBJECT COMPARE **************************************** 

-- compare missing indexes using database link (DBLink) 
SELECT UNIQUE table_owner, table_name, column_name, index_name, mixs
FROM 
(
    SELECT i.table_owner, i.table_name, i.column_name, i.index_name,
      NVL2((SELECT UNIQUE dic.table_name 
      		  FROM dba_ind_columns dic 
      		 WHERE DIC.TABLE_NAME = i.table_name 
      		   AND dic.table_owner = i.table_owner 
      		   AND dic.column_name = i.column_name 
      		   AND dic.table_owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mixs 
    FROM     
    (
        SELECT index_owner, index_name, table_owner, table_name, column_name
        FROM DBA_ind_columns@tp22
        WHERE index_owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')
          AND table_name NOT LIKE '%ORG'
        ORDER BY index_owner,table_owner,table_name ASC
    )i
)
WHERE mixs='N'
ORDER BY 1,2,3 ASC     


-- compare missing constraints indexes using DBLink
SELECT UNIQUE owner, table_name, column_name, mis_conts
FROM 
(
    SELECT dcc.owner, dcc.table_name, dcc.column_name, 
        NVL2((SELECT UNIQUE dc.table_name FROM dba_cons_columns dc WHERE dc.owner=dcc.owner AND dc.table_name = dcc.table_name AND dc.column_name = dcc.column_name AND  dc.table_name NOT LIKE 'BIN$%' AND dc.owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM') AND dc.table_name NOT LIKE '%ORG'),'Y','N') mis_conts
    FROM
    (
        SELECT owner, constraint_name, table_name, column_name 
        FROM dba_cons_columns@t2
        WHERE owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')
          AND table_name NOT LIKE '%ORG' AND table_name NOT LIKE 'BIN$%'
        ORDER BY owner, constraint_name, table_name, column_name ASC
    )dcc
)
WHERE mis_conts='N'
  AND REGEXP_LIKE(table_name,'[^0-9]$','i')
ORDER BY 1,2,3 ASC  


-- compare the missing objects using dblink
SELECT owner, object_name, object_type, mis_tables, mis_view, mis_proc, mis_func, mis_tri, mis_pac, mis_pac_body, mis_seq 
FROM 
(    
    SELECT UNIQUE doj.owner, doj.object_name, doj.object_type,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TABLE' AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i') AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tables,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_view,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_proc,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_func,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tri,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac_body,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_seq
    FROM 
    (
        SELECT owner, object_name, object_type  
        FROM dba_objects@tw
        WHERE owner IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
          AND object_name NOT LIKE '%ORG' 
          AND object_name NOT LIKE 'BIN$%'
          AND object_name NOT LIKE '%REPL'
          AND object_type IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
        ORDER BY owner, object_name, object_type ASC
    ) doj
)
WHERE mis_tables='N'
  AND mis_view='N'
  AND mis_proc='N'
  AND mis_func='N'
  AND mis_tri='N'
  AND mis_pac='N'
  AND mis_pac_body='N'
  AND mis_seq='N'
  AND REGEXP_LIKE(object_name,'[^0-9]$','i')
ORDER BY 1,2,3 ASC



CREATE OR REPLACE FORCE VIEW rchaudhari.chk_missing_objects
(
    OWNER, 
    OBJECT_NAME, 
    OBJECT_TYPE, 
    DBNAME, 
    MIS_TABLES, 
    MIS_VIEW, 
    MIS_PROC, 
    MIS_FUNC, 
    MIS_TRI, 
    MIS_PAC, 
    MIS_PAC_BODY, 
    MIS_SEQ
)
AS    
SELECT OWNER, OBJECT_NAME, OBJECT_TYPE, DBNAME, MIS_TABLES, MIS_VIEW, MIS_PROC, MIS_FUNC, MIS_TRI, MIS_PAC, MIS_PAC_BODY, MIS_SEQ 
FROM 
(    
    SELECT UNIQUE doj.owner, doj.object_name, doj.object_type, 'TE' DBName,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='TABLE' AND NOT REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i') AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tables,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_view,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_proc,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_func,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tri,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac_body,
        NVL2((SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type='SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_seq
    FROM 
    (
        SELECT owner, object_name, object_type, 'TW' DBName 
        FROM all_objects@tw
        WHERE owner IN ('RCHAUDHARI','TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
          AND object_name NOT LIKE '%ORG' 
          AND object_name NOT LIKE 'BIN$%'
          AND object_name NOT LIKE '%REPL'
          AND OBJECT_TYPE IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
        ORDER BY owner, object_name, object_type ASC
    ) doj
)
WHERE mis_tables='N'
  AND mis_view='N'
  AND mis_proc='N'
  AND mis_func='N'
  AND mis_tri='N'
  AND mis_pac='N'
  AND mis_pac_body='N'
  AND mis_seq='N'
  AND REGEXP_LIKE(object_name,'[^0-9]$','i')
ORDER BY 1,2,3 ASC



CREATE OR REPLACE FORCE VIEW RCHAUDHARI.CHK_indexes
(
   table_owner,
   table_name,
   column_name,
   index_name,
   te_miss_indexes
)
AS
SELECT UNIQUE table_owner, table_name, column_name, index_name, te_miss_indexes
FROM 
(
    SELECT tw.table_owner, tw.table_name, tw.column_name, tw.index_name,
      NVL2((SELECT UNIQUE te.table_name 
              FROM all_ind_columns te 
             WHERE te.TABLE_NAME = tw.table_name 
               AND te.table_owner = tw.table_owner 
               AND te.column_name = tw.column_name 
               AND te.table_owner = tw.table_owner),'Y','N') te_miss_indexes 
    FROM     
    (
        SELECT index_owner, index_name, table_owner, table_name, column_name
        FROM all_ind_columns@tw
        WHERE index_owner IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
          AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
        ORDER BY index_owner,table_owner,table_name ASC
    )tw
)
WHERE te_miss_indexes='N'
ORDER BY 1,2,3 ASC  



CREATE OR REPLACE FORCE VIEW RCHAUDHARI.CHK_Columns_DataTypes
(
   owner,
   table_name,
   column_name,
   data_type,
   data_length,
   TE_miss_Match
)
AS
SELECT UNIQUE owner, table_name, column_name, data_type, data_length, TE_miss_Match
FROM
(
    SELECT tw.owner, tw.table_name, tw.column_name, tw.data_type, tw.data_length,
        NVL2((SELECT UNIQUE te.table_name 
                FROM all_tab_columns te 
               WHERE te.owner=tw.owner 
                 AND te.table_name = tw.table_name 
                 AND te.column_name = tw.column_name 
                 AND te.DATA_TYPE = tw.data_type 
                 AND te.DATA_LENGTH = tw.data_length
                 AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
                 AND te.table_name NOT LIKE '%ORG'),'Y','N') TE_miss_Match
    FROM
    (
        SELECT owner, table_name, column_name, data_type, data_length
        FROM all_tab_columns@tw
        WHERE owner IN ('TRANSNOX_IOX', 'SNOX4TRANSNOX', 'WEBFORT_CPASS', 'TRANSNOX_CAT', 'TRANSTSYSPAYMENTGW','TRANSIT_GATEWAY_TNOX_319','TRANSIT_GATEWAY_SNOX_319','TRANSIT_FE_TNOX_319','TRANSIT_FE_SNOX_319','TRANSIT_SMSNOX_SNOX_318','TRANSIT_SMSNOX_TNOX_318')
          AND table_name NOT LIKE '%ORG' 
          AND NOT REGEXP_LIKE(table_name,'s._temp[[:digit:]]','i')
        ORDER BY owner, table_name, column_name ASC
    )tw
)
WHERE TE_miss_Match='N'
  AND REGEXP_LIKE(table_name,'[^0-9]$','i')
ORDER BY 1,2,3,4 ASC


CREATE OR REPLACE FORCE VIEW RCHAUDHARI.CHK_SEQUENCES
(
   SEQUENCE_NAME,
   TW_Seq_LastNumber,
   TE_SEQ_LastNumber,
   DIFF_NUMBER,
   CACHE_SIZE
)
AS
     SELECT TW.SEQUENCE_NAME,
            TW.LAST_NUMBER TW_Seq_LastNumber,
            TE.LAST_NUMBER TE_SEQ_LastNumber,
            TE.LAST_NUMBER - TW.LAST_NUMBER diff_number,
            TW.CACHE_SIZE
       FROM ALL_sequences@TW TW, ALL_sequences TE
      WHERE     TW.SEQUENCE_OWNER IN ('TRANSNOX_IOX',
                                        'SNOX4TRANSNOX',
                                        'WEBFORT_CPASS',
                                        'TRANSNOX_CAT',
                                        'TRANSTSYSPAYMENTGW')
            AND TW.SEQUENCE_OWNER = TE.SEQUENCE_OWNER
            AND TW.SEQUENCE_NAME = TE.SEQUENCE_NAME
            AND TE.LAST_NUMBER > TW.LAST_NUMBER
   ORDER BY 5 DESC;
   
   
-- compare the table's columns using dblink
SELECT unique owner, table_name, column_name, data_type, data_length, mis_cols
FROM
(
    SELECT dtc.owner, dtc.table_name, dtc.column_name, dtc.data_type, dtc.data_length,
        NVL2((SELECT UNIQUE dc.table_name 
        	    FROM dba_tab_columns dc 
        	   WHERE dc.owner=dtc.owner 
        	     AND dc.table_name = dtc.table_name 
        	     AND dc.column_name = dtc.column_name 
        	     AND DC.DATA_TYPE = dtc.data_type 
        	     AND DC.DATA_LENGTH = dtc.data_length 
        	     AND dc.table_name NOT LIKE 'BIN$%' 
        	     AND dc.owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP') AND dc.table_name NOT LIKE 'SN_TEMP%' AND dc.table_name NOT LIKE '%ORG'),'Y','N') mis_cols
    FROM
    (
        SELECT owner, table_name, column_name, data_type, data_length
        FROM dba_tab_columns@tp62
        WHERE owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')
          AND table_name NOT LIKE '%ORG' AND table_name NOT LIKE 'BIN$%'
          AND table_name NOT LIKE 'SN_TEMP%'
        ORDER BY owner, table_name, column_name ASC
    )dtc
)
WHERE mis_cols='Y'
  AND REGEXP_LIKE(table_name,'[^0-9]$','i')
ORDER BY 1,2,3,4 ASC


--- compare all the missing  objects from differetn database schema's
SELECT UNIQUE owner, object_name, object_type, --DBName,
    NVL2((SELECT UNIQUE OBJECT_NAME FROM DBA_OBJECTS@TEMPE_22 t22 WHERE t22.object_type=c121.OBJECT_TYPE AND t22.owner=c121.owner AND t22.object_name=c121.object_name),'x','Not present on Tempe_22') Tempe_22,
    NVL2((SELECT UNIQUE OBJECT_NAME FROM DBA_OBJECTS@tempe_21 t21 WHERE t21.object_type=c121.OBJECT_TYPE AND t21.owner=c121.owner AND t21.object_name=c121.object_name),'x','Not present on Tempe_21') Tempe_21,
    NVL2((SELECT UNIQUE OBJECT_NAME FROM DBA_OBJECTS@col122 c122 WHERE c122.object_type=c121.OBJECT_TYPE AND c122.owner=c121.owner AND c122.object_name=c121.object_name),'x','Not present on COL_122') COl_122,
    NVL2((SELECT UNIQUE OBJECT_NAME FROM DBA_OBJECTS col121 WHERE col121.object_type=c121.OBJECT_TYPE AND col121.owner=c121.owner AND col121.object_name=c121.object_name),'x','Not present on COL_121') COL_121
FROM 
  (
    SELECT owner, object_name, object_type, 'Tempe_22' dbname
    FROM dba_objects@tempe_22
    WHERE owner='TRANSNOX_RECON'
      AND object_type IN ('PROCEDURE','TABLE','FUNCTION','SEQUENCE')
    UNION ALL 
    SELECT owner, object_name, object_type, 'Tempe_21' dbname
    FROM dba_objects@tempe_21
    WHERE owner='TRANSNOX_RECON'
      AND object_type IN ('PROCEDURE','TABLE','FUNCTION','SEQUENCE')
    UNION ALL
    SELECT owner, object_name, object_type, 'col_122' dbname
    FROM dba_objects@col122
    WHERE owner='TRANSNOX_RECON'
      AND object_type IN ('PROCEDURE','TABLE','FUNCTION','SEQUENCE')
    UNION ALL
    SELECT owner, object_name, object_type, 'col_121' dbname
    FROM dba_objects
    WHERE owner='TRANSNOX_RECON'
      AND object_type IN ('PROCEDURE','TABLE','FUNCTION','SEQUENCE')
  ) c121
WHERE owner='TRANSNOX_RECON'
  AND NOT REGEXP_LIKE(object_name,'^tempsri*|^s.temp[[:digit]]','i')   
ORDER BY 3 ASC  


SELECT OWNER, OBJECT_NAME, OBJECT_TYPE, MIS_TABLES, MIS_VIEW, MIS_PROC, MIS_FUNC, MIS_TRI, MIS_PAC, MIS_PAC_BODY, MIS_SEQ
FROM (SELECT UNIQUE
			doj.owner,
			doj.object_name,
			doj.object_type,
			NVL2 ( (SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type = 'TABLE' AND NOT REGEXP_LIKE (object_name, 's._temp[[:digit:]]', 'i') AND oj.owner = doj.owner AND oj.object_name = doj.object_name), 'Y', 'N') mis_tables,
			NVL2 ( (SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type = 'VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name), 'Y', 'N') mis_view,
			NVL2 ( (SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type = 'PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name), 'Y', 'N') mis_proc,
			NVL2 ( (SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type = 'FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name), 'Y', 'N') mis_func,
			NVL2 ( (SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type = 'TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name), 'Y', 'N') mis_tri,
			NVL2 ( (SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type = 'PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name), 'Y', 'N') mis_pac,
			NVL2 ( (SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type = 'PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name), 'Y', 'N') mis_pac_body,
			NVL2 ( (SELECT UNIQUE oj.object_name FROM all_objects oj WHERE oj.object_type = 'SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name), 'Y', 'N') mis_seq
	   FROM (  SELECT owner, object_name, object_type
				 FROM all_objects@tw_Cpass
				WHERE     owner IN ('TRANSNOX_IOX','SNOX4TRANSNOX', 'TRANSIT_GATEWAY_TNOX_3111', 'TRANSIT_GATEWAY_SNOX_3111', 'TRANSIT_FE_TNOX_3111', 'TRANSIT_FE_SNOX_3111', 'TRANSIT_SMSNOX_SNOX_3111', 'TRANSIT_SMSNOX_TNOX_3111')
					  AND object_name NOT LIKE '%ORG'
					  AND object_name NOT LIKE 'BIN$%'
					  AND object_name NOT LIKE '%REPL'
					  AND OBJECT_TYPE IN ('TABLE', 'PROCEDURE', 'FUNCTION', 'TRIGGER', 'PACKAGE', 'PACKAGE BODY', 'SEQUENCE', 'VIEW')
			 ORDER BY owner, object_name, object_type ASC) doj)
WHERE     mis_tables = 'N'
	AND mis_view = 'N'
	AND mis_proc = 'N'
	AND mis_func = 'N'
	AND mis_tri = 'N'
	AND mis_pac = 'N'
	AND mis_pac_body = 'N'
	AND mis_seq = 'N'
	AND REGEXP_LIKE (object_name, '[^0-9]$', 'i')
ORDER BY 1, 2, 3 ASC;

**************************************** OBJECT COMPARE **************************************** 


---********************************************************************--
---Date and time
You can perform date arithmetic directly in SQL*Plus, doing the math right in the SQL: 

SQL> SELECT
  2    SYSDATE Today,
  3    SYSDATE - 1 Yesterday,
  4    SYSDATE + 1 Tomorrow
  5  FROM
  6    dual;

TODAY     	YESTERDAY 	TOMORROW
--------- 	--------- 	---------
23-JAN-05 	22-JAN-05 	24-JAN-05

As you can see, the standard unit in Oracle date arithmetic is one
day.  When you add time to the date with SQL updates, you do it in
fractions of a day.


1 Day              1               1            1
1 Hour             1/24            1/24         0.0417
1 Min              1/(24x60)       1/1440       .000694
1 Sec              1/(24x60x60)    1/86400      .000011574

The notation in the second column is most commonly used, because it is
so much easier to read.  Five minutes is 5/(24x60), much easier than 5
/1440 or .00347.  When we get to date functions in Chapter 2, you will
see that there are functions to do date math by months, weeks and so
forth.

---********************************************************************--


****************************************  Bulk Deletion ****************************************

-- bulk deletion
BEGIN
	loop -- keep looping 
	  --do the delete 4999 in each iteration
	  Delete from transcapitalone.Transactions where  Transactions_ID and rownum < 5000;

	  -- exit the loop when there where no more 5000 reccods to delete. 
	  exit when SQL%rowcount < 4999;

	  -- commit to clear the rollback segments. 
	  commit;
	end loop;

	commit; -- commit the last delete
END;

****************************************  Bulk Deletion ****************************************



--- granting grants to different type of object
SELECT DECODE(OBJECT_TYPE,'TABLE','GRANT SELECT,INSERT,UPDATE,DELETE ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;',
                          'SEQUENCE','GRANT SELECT ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;',
                          'PROCEDURE','GRANT EXECUTE ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;',
                          'FUNCTION','GRANT EXECUTE ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;',
                          'VIEW','GRANT SELECT,INSERT,UPDATE,DELETE ON TRANSNOX_IOX.'||OBJECT_NAME||' TO TRANSNOX_IOX_APP;'
             )OOPS_2_MUCH 
FROM dba_objects
WHERE owner='TRANSNOX_IOX'
  AND object_type IN ('TABLE','SEQUENCE','VIEW','TRIGGER','PROCEDURE','FUNCTION');


  
****************************************  DBA Related Queries ****************************************

-- catalog updation timestamp
SELECT dbms_registry.time_stamp('CATALOG') AS timestamp FROM DUAL


select b.file_id "file#", b.tablespace_name "Tablespace name", b.bytes "#Bytes",
	(b.bytes-sum(nvl(a.bytes,0)))"#used", sum(nvl(a.bytes,0))"#free",
	(sum(nvl(a.bytes,0))/(b.bytes))*100"%Free"
from sys.dba_free_space a,sys.dba_data_files b
where a.file_id(+)=b.file_id
group by b.tablespace_name ,b.file_id,b.bytes
order by b.tablespace_name;


-- calculates the over all size of database
SELECT (A.data_size+b.temp_size+c.redo_size)/1024/1024/1024 "total_GB_size"
FROM ( SELECT SUM(bytes) data_size FROM dba_data_files ) A,
( SELECT NVL(SUM(bytes),0) temp_size FROM dba_temp_files ) b,
( SELECT SUM(bytes) redo_size FROM sys.v_$log ) c;


--- Work Around to Calculate the size of procedures
SELECT  ds.owner,ds.name,status,sum(length(REPLACE(REPLACE(replace(text,chr(10),''),' ',''),'"',''))) proc_size
FROM DBA_OBJECTS do, dba_source ds
WHERE  do.object_type=ds.type
            and ds.name=do.object_name 
            and ds.owner=do.owner 
            and  ds.type ='PROCEDURE'
            and ds.owner='TRANSNOX_CPASS'  
group by ds.name,do.status,ds.owner;


SELECT owner,name,dense_rank () over (partition by name order by owner) object_rank,status,proc_size
FROM 
 (
	  ( 
		   SELECT  ds.owner,ds.name,status,sum(length(REPLACE(REPLACE(replace(text,chr(10),''),' ',''),'"',''))) proc_size
		   FROM DBA_OBJECTS do, dba_source ds
		   WHERE  do.object_type=ds.type
						and ds.name=do.object_name 
						and ds.owner=do.owner 
						and  ds.type ='PROCEDURE'
						and ds.owner=V_OWNER  
			group by ds.name,do.status,ds.owner
	   )
	union all
			SELECT  ds.owner,ds.name,status,sum(length(REPLACE(REPLACE(replace(text,chr(10),''),' ',''),'"',''))) proc_size
			FROM DBA_OBJECTS do, dba_source ds
			WHERE  do.object_type=ds.type
						and ds.name=do.object_name 
						and ds.owner=do.owner 
						and  ds.type ='PROCEDURE'
						and ds.owner in ( 'TNOXPASS_TFE_20115', 'TNOXPASS_GWAY_00515', 'TNOXPASS_SMSNOX_20176' )  
			group by ds.name,do.status,ds.owner
  )
order by 2,1;

--- DBA Daily Task 

- Daily check DB Alert log file for DB errors and resolve it.
- Check if your database and instance are up and running at enuf speed.
- Check if listener is for runnig fine without any network errors.
- Check the backups / Design and implement a backup & recovery system. (StandBy, Logical Backups(Export/Import), Online/Offline Backups, RMAN Backups, Strams/Replication)
- Check and Verify all scheduled DB Development / Backup jobs have run successfully.
- Check the backups has been moved on secure locations from where you can recover in case of DB failover.
- Check the Disk Space of DB Server where the Database files has be created.
- Check the Disk Space where your Archive files gets generated, if Your DB is in Archive log mode.
- Check the RedoLogs V$logfile and V$log.
- Implement Oracle failover processes if any.
- Performance tuning, instance level, SQL tuning, etc.
- Participate in code reviews.
- Participate in design reviews.
- read, study, play with Oracle, learn, learn, learn....
------------------------------------------------------------------------------------



-- find the last time database users logged on to the database
SELECT    
    A.username, os_username, A.TIMESTAMP, A.logoff_time, 
    A.returncode, A.terminal, A.userhost, A.ACTION_NAME
FROM dba_audit_session A
WHERE (A.username,A.TIMESTAMP) IN 
                                (SELECT b.username,MAX(b.TIMESTAMP)
                                 FROM dba_audit_session b
                                 GROUP BY b.username)
  AND A.TIMESTAMP<(SYSDATE-3)

------------------------------------------------------------------------

-- Analyze schema
EXEC DBMS_STATS.gather_schema_stats (ownname => 'TRANSNOX_IOX', cascade =>true,estimate_percent => dbms_stats.auto_sample_size);

exec dbms_stats.gather_schema_stats(ownname=>'TRANSNOX_IOX', degree=>8, estimate_percent=>50, cascade=>TRUE,granularity=>'ALL');


-- analyze table 
BEGIN
   SYS.DBMS_STATS.gather_table_stats (ownname        => 'UPLOAD_DATA',
                                      tabname        => 'GCA_TRAN_ID_2007_103',
                                      DEGREE         => 4,
                                      CASCADE        => TRUE,
                                      no_invalidate  => FALSE
                                     );
END;

****************************************  DBA Related Queries ****************************************

-- deleting records from bottom
delete from emp 
where rowid not in ( select rowid from emp minus select rowid from emp where rownum between 70 and 100);



****************************************  Memory Related Queries ****************************************

SELECT   statistic# s, NAME
    FROM SYS.v_$statname
   WHERE NAME IN
            ('recursive calls', 'db block gets', 'consistent gets',
             'physical reads', 'redo size',
             'bytes sent via SQL*Net to client',
             'bytes received via SQL*Net from client',
             'SQL*Net roundtrips to/from client', 'sorts (memory)',
             'sorts (disk)')
ORDER BY s



--SELECT FROM v$SQL TOP 10 BUFFER GETS
select * from (select buffer_gets,disk_reads,rows_processed,optimizer_mode,executions,sorts,loaded_versions,loads,sql_text 
from v$sql order by buffer_gets desc) 
where rownum < 11; 

--SELECT FROM v$SQL TOP 10 ELAPSED_TIME
select sql_text,ELAPSED_TIME from (select sql_text,ELAPSED_TIME 
from v$sql order by ELAPSED_TIME desc ) 
where rownum < 11; 

-- SELECT FROM v$SQL TOP 10 DISK_READS
select * from (select disk_reads,buffer_gets,rows_processed,optimizer_mode,executions,sorts,loaded_versions,loads,sql_text 
from v$sql order by disk_reads desc) 
where rownum < 11; 

-- SELECT FROM v$SQL TOP 10 ROWS_PROCESSED  
select * from (select rows_processed,buffer_gets,disk_reads,optimizer_mode,executions,sorts,loaded_versions,loads,sql_text 
from v$sql order by rows_processed desc) 
where rownum < 11; 

-- SELECT FROM v$SQL TOP 10 EXECUTIONS  
select * from (select executions,rows_processed,buffer_gets,disk_reads,optimizer_mode,sorts,loaded_versions,loads,sql_text 
            from v$sql 
            order by executions desc) 
where rownum < 11; 

-- SELECT FROM v$SQL TOP 10 SORTS  
select * from (select sorts,executions,rows_processed,buffer_gets,disk_reads,optimizer_mode,loaded_versions,loads,sql_text 
                from v$sql order by sorts desc) 
where rownum < 11; 

-- SELECT FROM v$SQL TOP 10 CPU_TIME  
select sql_text,cpu_time from (select sql_text,cpu_time from v$sql order by cpu_time desc ) where rownum < 11; 


-- 1.0 Oracle BUFFER CACHE Hit Ratio - Oracle MEMORY TUNING Calculate BUFFER CACHE hit ratio IN THE 
--DATABASE. Make sure it IS more THAN 80 FOR an oltp environment AND 99 IS THE best VALUE.
SELECT A.VALUE + b.VALUE "logical_reads", c.VALUE "phys_reads",ROUND(100 * ((A.VALUE+b.VALUE)-c.VALUE) /(A.VALUE+b.VALUE))"BUFFER HIT RATIO" 
FROM v$sysstat A, v$sysstat b, v$sysstat c
WHERE A.statistic# = 38 
  AND b.statistic# = 39 
  AND c.statistic# = 40;


--Check Session Level Hit Ratio - Oracle tuning THE Hit Ratio should be higher THAN 90%
SELECT Username, OSUSER, Consistent_Gets, Block_Gets, Physical_Reads, 100*( Consistent_Gets + Block_Gets - Physical_Reads)/( Consistent_Gets + Block_Gets ) "Hit Ratio %"
FROM V$SESSION,V$SESS_IO
WHERE V$SESSION.SID = V$SESS_IO.SID
  AND ( Consistent_Gets + Block_Gets )>0
  AND username IS NOT NULL
ORDER BY Username,"Hit Ratio %";


--List SESSION specific MEMORY - oracle memory tuning, list the uga and pga used by each session on the server 
SELECT se.SID,n.NAME, MAX(se.VALUE) maxmem 
FROM v$sesstat se,v$statname n
WHERE n.statistic# = se.statistic#
  AND n.NAME IN ('session pga memory','session pga memory max','session uga memory','session uga memory max')
GROUP BY n.NAME,se.SID
ORDER BY 3


-- List the size of Oracle stored procedures and use it to tune Oracle shared pool - Oracle memory tuning
-- This script LISTS THE SIZE OF stored objects 

--column num_instances heading "Num" format 999 
--column TYPE heading "Object Type" format a12 
--column source_size heading "Source" format 99,999,999 
--column parsed_size heading "Parsed" format 99,999,999 
--column code_size heading "Code" format 99,999,999 
--column error_size heading "Errors" format 999,999 
--column size_required heading "Total" format 999,999,999 
--compute SUM OF size_required ON report 

SELECT COUNT(NAME) num_instances, 
       TYPE 
    ,SUM(source_size) source_size 
    ,SUM(parsed_size) parsed_size 
    ,SUM(code_size) code_size 
    ,SUM(error_size) error_size 
    ,SUM(source_size) 
    +SUM(parsed_size) 
    +SUM(code_size) 
    +SUM(error_size) size_required 
FROM dba_object_size 
GROUP BY TYPE 
ORDER BY 2


-- Oracle sorts MONITORING Scripts - Oracle MEMORY TUNING
--Monitor THE sorts IN MEMORY vs DISK. Try TO KEEP THE DISK/MEMORY ratio TO LESS THAN .10 BY increasing THE sort_area_size 

SELECT NAME, VALUE FROM v$sysstat 
WHERE NAME IN ('sorts (memory)', 'sorts (disk)');

****************************************  Memory Related Queries ****************************************



select 
   SYS_CONTEXT('USERENV','TERMINAL') terminal,
   SYS_CONTEXT('USERENV','LANGUAGE') language,
   SYS_CONTEXT('USERENV','SESSIONID') sessionid,
   SYS_CONTEXT('USERENV','INSTANCE') instance,
   SYS_CONTEXT('USERENV','ENTRYID') entryid,
   SYS_CONTEXT('USERENV','ISDBA') isdba,
   SYS_CONTEXT('USERENV','NLS_TERRITORY') nls_territory,
   SYS_CONTEXT('USERENV','NLS_CURRENCY') nls_currency,
   SYS_CONTEXT('USERENV','NLS_CALENDAR') nls_calendar,
   SYS_CONTEXT('USERENV','NLS_DATE_FORMAT') nls_date_format,
   SYS_CONTEXT('USERENV','NLS_DATE_LANGUAGE') nls_date_language,
   SYS_CONTEXT('USERENV','NLS_SORT') nls_sort,
   SYS_CONTEXT('USERENV','CURRENT_USER') current_user,
   SYS_CONTEXT('USERENV','CURRENT_USERID') current_userid,
   SYS_CONTEXT('USERENV','SESSION_USER') session_user,
   SYS_CONTEXT('USERENV','SESSION_USERID') session_userid,
   SYS_CONTEXT('USERENV','PROXY_USER') proxy_user,
   SYS_CONTEXT('USERENV','PROXY_USERID') proxy_userid,
   SYS_CONTEXT('USERENV','DB_DOMAIN') db_domain,
   SYS_CONTEXT('USERENV','DB_NAME') db_name,
   SYS_CONTEXT('USERENV','HOST') host,
   SYS_CONTEXT('USERENV','OS_USER') os_user,
   SYS_CONTEXT('USERENV','EXTERNAL_NAME') external_name,
   SYS_CONTEXT('USERENV','IP_ADDRESS') ip_address,
   SYS_CONTEXT('USERENV','NETWORK_PROTOCOL') network_protocol,
   SYS_CONTEXT('USERENV','BG_JOB_ID') bg_job_id,
   SYS_CONTEXT('USERENV','FG_JOB_ID') fg_job_id,
   SYS_CONTEXT('USERENV','AUTHENTICATION_TYPE')authentication_type,
   SYS_CONTEXT('USERENV','AUTHENTICATION_DATA')authentication_data,
--   CURRENT_SQLn attributes return subsequent 4K-byte increments, where n can be an integer from 1 to 7, inclusive. 
--   CURRENT_SQL1 returns bytes 4K to 8K; CURRENT_SQL2 returns bytes 8K to 12K, and so forth. You can specify these 
--   attributes only inside the event handler for the fine-grained auditing feature.
   SYS_CONTEXT('USERENV','CURRENT_SQL') current_sql,
   SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER') client_identifier,
   SYS_CONTEXT('USERENV','GLOBAL_CONTEXT_MEMORY') global_context_memory,
   sys_context('USERENV', 'ACTION') Action_Taken,
   sys_context('USERENV', 'CLIENT_INFO')CLIENT_INFO,
   sys_context('USERENV', 'MODULE')program,
   sys_context('USERENV', 'SERVER_HOST') server_host,
   sys_context('USERENV', 'SERVICE_NAME')service_name
from dual;

-- link for sys_context
http://www.psoug.org/reference/sys_context.html

--***************************************************************
-- Multiple insert ,,,  link to check the same
http://www.sc.ehu.es/siwebso/KZCC/Oracle_10g_Documentacion/server.101/b10736/transform.htm#sthref712

-- check the customer_id and insert the records in different tables
INSERT FIRST
WHEN customer_id < 'I' THEN
  INTO cust_ah
  VALUES (customer_id, program_id, delivered_date)
WHEN customer_id < 'Q' THEN
  INTO cust_ip
  VALUES (customer_id, program_id, order_date)
WHEN customer_id > 'PZZZ' THEN
  INTO cust_qz
  VALUES (customer_id, program_id, delivered_date)
SELECT program_id, delivered_date, customer_id, order_date
FROM airplanes;


-- insert in to different tables..
INSERT ALL
INTO ap_cust VALUES (customer_id, program_id, delivered_date)
INTO ap_orders VALUES (order_date, program_id)
SELECT program_id, delivered_date, customer_id, order_date
FROM airplanes;


-- check the deptno column and inser as per it
INSERT ALL 
WHEN (deptno=10) THEN
  INTO emp_10 (empno,ename,job,mgr,sal,deptno)
  VALUES (empno,ename,job,mgr,sal,deptno)
WHEN (deptno=20) THEN
  INTO emp_20 (empno,ename,job,mgr,sal,deptno)
  VALUES (empno,ename,job,mgr,sal,deptno)
WHEN (deptno<=30) THEN
  INTO emp_30 (empno,ename,job,mgr,sal,deptno)
  VALUES (empno,ename,job,mgr,sal,deptno)
ELSE
  INTO leftover (empno,ename,job,mgr,sal,deptno)
  VALUES (empno,ename,job,mgr,sal,deptno)
SELECT * FROM emp;

SELECT * FROM emp_10;
SELECT * FROM emp_20;
SELECT * FROM emp_30;
SELECT * FROM leftover;



****************************************  CronJob Scripts ****************************************

30 * * * * sh /archivelogs/goldengate/scripts/chkc_process.sh

30 06 * * * sh  /recovery/oracle/dpump/expdp_uat_migration_11Oct2015.sh

-- cronjob
#minute (0-59)
#|   hour (0-23)
#|   |    day of the month (1-31)
#|   |    |   month of the year (1-12 or Jan-Dec)
#|   |    |   |   day of the week (0-6 with 0=Sun or Sun-Sat,,... 0=Sunday, 1=Monday, 2=Tuesday, 3=Wednesday 4=Thursday 5=Fri, 6=Saturday)
#|   |    |   |   |   commands or scripts
#|   |    |   |   |   |
00   0    *   *   0   /usr/bin/newsyslog 
#### above cronjob will rotate logs weekly (Sunday at midnight)

-- Event table Archiving from snox4transnox_gca schema
-- The CronJob will run on 1130AM o n Monday (1) and Friday (5) of every Month
30 12 * * 1,5 sh /oradata4/arc_cronjob/event_archiving.sh

30 03 * * 0,1,3,5 sh /home/oracle/cronjobs/del_1day_older_archfiles.sh > /home/oracle/cronjobs/del_1day_older_archfiles_logs.log

-- run it every 15 min
*/15 * * * *  sh /ora4/arc_cronjob/delete_arch_1day_older.sh

-- run it every 5 hrs
* */5 * * *  sh /home/oracle/cronjobs/delete_arch_1day_older.sh > /home/oracle/cronjobs/delete_arch_1day_older_logs.log


--- TransIT statitics collection
00 02 * * * sh /home/oracle/scripts/trans_settlement_stats.sql > /home/oracle/scripts/log_trans_settlement_stats.log


# GoldenGate ggserr.log rotation cron job
00 02 * * * sh /acfs/goldengate/scripts/log_rotation.sh > /acfs/goldengate/scripts/log_rotation.log


-- set job to drop the SN_TEMP and SC_TEMP tables

00 05 * * * sh /home/oracle/cronjobs/cronjob_srpt_2_drop_SNtemp_tbls.sh

cat /home/oracle/cronjobs/cronjob_srpt_2_drop_SNtemp_tbls.sh

#!/bin/sh
export ORACLE_BASE=/home/oracle/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11.1.0/db_1
export ORACLE_SID=devdb

PATH=$PATH:$HOME/bin:$ORACLE_HOME/bin

export PATH

sqlplus -s / as sysdba << eof
set pagesize 0;
set head off
set echo off
set feedback off
set serveroutput on
spool /home/oracle/cronjobs/drop_tbls_srpt.log
BEGIN
    FOR i IN (SELECT owner, object_name FROM dba_objects
              WHERE (object_name LIKE 'SC_TEMP%' OR object_name LIKE 'SN_TEMP%')
                AND object_type='TABLE' AND created < SYSDATE-50/1440)
    LOOP
        dbms_utility.exec_ddl_statement('drop table '||i.owner||'.'||i.object_name||' purge');
    END LOOP;
END;
/
show errors;
spool off
eof

****************************************  CronJob Scripts ****************************************



****************************************  FLASH BACKUP ****************************************

-- recyclebin to get the table name which was drop . 
SELECT OBJECT_NAME, ORIGINAL_NAME, TYPE
FROM USER_RECYCLEBIN
WHERE BASE_OBJECT = (SELECT BASE_OBJECT FROM USER_RECYCLEBIN
WHERE ORIGINAL_NAME = 'RECYCLETEST')
AND ORIGINAL_NAME != 'RECYCLETEST';


-- display the version of modified values of the columns in a table.
SELECT UNDO_SQL
FROM FLASHBACK_TRANSACTION_QUERY
WHERE XID = '05000C004AD10100';

select versions_starttime, versions_endtime, versions_xid,
versions_operation, APPLICATIONID, BUSINESS_STREET, BUSINESS_CITY, BUSINESS_STATE --column name to check the values
from transfastcap.temp versions between timestamp minvalue and maxvalue
order by VERSIONS_STARTTIME

--- put the versions_xid in hextoraw('') sreach condition and check the result.
-- it'll return all the DML statment which was execute for that versions_xid column
SELECT UNDO_SQL FROM FLASHBACK_TRANSACTION_QUERY WHERE XID = hextoraw('F0000800BB000000');


--- database will in flash time for 7 Hrs, for the session.
-- Once you logout the flash back will be disabled
EXEC dbms_flashback.enable_at_time(SYSTIMESTAMP - 3/24);


-- to disable the flashback mode
EXEC DBMS_FLASHBACK.DISABLE


select *
from agent_master
as of timestamp sysdate-2


--to purge the table
ALTER SESSION SET CURRENT_SCHEMA=transcapitalone;
PURGE TABLE transcapitalone."BIN$pnCDGt7Ts1bgQK8KGZY6yg==$0"; 


--- purge all the dropped objects which are present in recycle bin 
BEGIN
   FOR P IN (SELECT 'Purge table '||owner||'."'||object_name||'"' ptbl FROM sys.DBA_RECYCLEBIN)
   LOOP
      BEGIN
         EXECUTE IMMEDIATE P.ptbl;
      EXCEPTION
         WHEN OTHERS THEN NULL;
      END;
   END LOOP;
END;
/

--- Flash Back Query

-- Oracle Flashback Query can only be used if the server is configured to use Automatic 
-- Undo Management, rather than traditional rollback segments. The maximum time period 
-- that can be flashbacked to is defined using the UNDO_RETENTION parameter in the 
-- init.ora file. Alternatively, this parameter can be set using:

ALTER SYSTEM SET UNDO_RETENTION = <seconds>;

--- privilege to flashback any table 
GRANT FLASHBACK ANY TABLE to <username>;

--- Query to get the deleted data before 10 minutes
SELECT * FROM LOOKUP_TRANS_STATUS
 AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE); 
 
-- so like wish u can insert the data back in the table  
INSERT INTO LOOKUP_TRANS_STATUS
 SELECT * FROM LOOKUP_TRANS_STATUS
  AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE);
-- if wanna selected data from deleted data then  
   WHERE CONDITION... = ?;
 
 

--To select data as if we where in the past, you can use a flashback query. How long 
--you can go back depends on the size of the UNDO tablespace and on how quickly that fills up. 

--If you want to see the content of the table 1 hour ago you can query it like:

SELECT *
FROM tablename
AS OF TIMESTAMP SYSTIMESTAMP - INTERVAL '1' HOUR;


--If you want to see the content of the table 2 days ago you can query it like:

SELECT *
FROM tablename
AS OF TIMESTAMP SYSTIMESTAMP - INTERVAL '2' DAY;

--or you can select the status per SCN number.

--To query the current SCN number:

SELECT DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER() FROM DUAL; 


--To select a SCN number (System Change Number) on a specific timestamp:

SELECT TIMESTAMP_TO_SCN('11-JUN-09 10.30.09.000000000 AM') FROM dual; 


--With this SCN number you can query in the past with "scn-number":

SELECT *
FROM tablename
AS OF SCN "scn-number";


--To select changes on a table since a specific System Change Numbers (SCN):

SELECT * FROM tabelnaam
VERSIONS BETWEEN SCN SCN_x AND MAXVALUE; 
 

-- Initialization Parameters 
 
--Setting the location OF the flashback 
recovery area db_recovery_file_dest=/oracle/flash_recovery_area 
 
 
--Setting the size OF the flashback 
recovery area db_recovery_file_dest_size=2147483648 
 
--Setting the retention TIME FOR flashback files (IN minutes)
-- 2 days
db_flashback_retention_target=2880 




/*
Flashback Table Just like the flashback query helps retrieve rows of a table, 
FLASHBACK TABLE helps restore the state of a table to a certain 
point in time even if a table structure changed has occurred since 
then. The following command will take us to the table state at the
specified timestamp.
*/
 
FLASHBACK TABLE EMPLOYEE TO 
TIMESTAMP ('15-SEP-08 8:50:58','DD-MON-YY HH24: MI: SS');
 
/*
This command will not only restore the tables, but also the 
associated objects like indexes, constraints etc.
*/
 
 
/*
Flashback Drop
Oracle 10g introduces the function "Flashback drop". If a DROP 
TABLE command has been issued for the table EMPLOYEE, we can 
still restore the entire table by issuing the following command:
*/
 
FLASHBACK TABLE EMPLOYEE TO BEFORE DROP;
 
-- Recovering a dropped table doesn't any easier than this!
 
 
/*
Flashback database
Flashback Database requires the creation and configuration of 
an Oracle Flash Recovery Area before this feature can be used. 
 
"Flash Recovery Area", created by the DBA, is the allocation of 
space on the disk to hold all the recovery related files (Flashback 
Logs, Redo Archive logs, RMAN backups, and copies of control files).
 
Use the initialization parameters db_recovery_file_dest and 
b_recovery_file_dest_size to set the destination and the size 
of the recovery area.
 
Set Flashback to enabled to make Oracle database enter the 
flashback mode. The database must be mounted as Exclusive and 
not open. The database also has to be in the ARCHIVELOG MODE 
before we can use this feature:
*/
 
ALTER DATABASE ARCHIVELOG;
 
-- start the database in EXCLUSIVE mode:
 
SHUTDOWN IMMEDIATE;
STARTUP MOUNT EXCLUSIVE
 
 
-- enter flashback mode:
 
ALTER DATABASE FLASHBACK ON;
 
 
-- issue the Flashback command and rewind the database to 
-- the state it was in one hour ago.
 
Flashback database TO TIMESTAMP sysdate-(1/24);
 
-- after the system comes back with FLASHBACK COMPLETE, 
-- open the database:
 
ALTER DATABASE OPEN RESETLOGS;
 
-- the database is now restored. 
 
-- note that we have the option 
-- of using SCN instead of timestamp.

--***********************************************************
-- creating read only role
CREATE ROLE read_only NOT IDENTIFIED;

GRANT CREATE SESSION, SELECT ANY TABLE, SELECT ANY SEQUENCE, EXECUTE ANY PROCEDURE TO READ_ONLY;

-- create read write role
CREATE ROLE read_write NOT IDENTIFIED;

GRANT CREATE SESSION, SELECT ANY TABLE, SELECT ANY SEQUENCE, EXECUTE ANY PROCEDURE, INSERT ANY TABLE, UPDATE ANY TABLE, DELETE ANY TABLE TO read_write;

--***********************************************************


****************************************  Genarating Index Constraint Scripts ****************************************
-- Genarating Index Constraint Scripts

SELECT 'DROP INDEX '||OWNER||'.'||SEGMENT_NAME||';' Dropping_Index
FROM dba_segments
WHERE tablespace_name='INDEX_2'
  AND SEGMENT_TYPE='INDEX'
ORDER BY owner,segment_name ASC;  

-- create script for unique primary key index constraints
SELECT 'CREATE UNIQUE INDEX '||owner||'.'||constraint_name||' ON '||owner||'.'||table_name||' ('||wm_concat(column_name)||')'||' tablespace INDEX_3;' "Unique_PrimaryKey_Cons_Index"
FROM 
(
    SELECT dcc.owner, dcc.constraint_name, dcc.table_name, DC.CONSTRAINT_TYPE, dcc.column_name, dcc.position 
    FROM dba_segments ds, dba_constraints dc, dba_cons_columns dcc
    WHERE ds.owner = dc.owner
      AND dc.owner = dcc.owner
      AND ds.segment_name = dc.constraint_name
      AND dc.constraint_name = dcc.constraint_name
      AND ds.tablespace_name='INDEX_2'
      AND ds.segment_type='INDEX'   
      AND dc.constraint_type IN ('P','U')
    ORDER BY dcc.owner, dcc.constraint_name, dcc.table_name, dcc.position  ASC 
)
GROUP BY owner, constraint_name, table_name, constraint_type

-- create script for primary key constraints
SELECT 'ALTER TABLE '||owner||'.'||table_name||' ADD (CONSTRAINT '||constraint_name||' PRIMARY KEY ('||wm_concat(column_name)||')'||' USING INDEX '||owner||'.'||constraint_name||');' "PrimaryKey_Cons"
FROM 
(
    SELECT dcc.owner, dcc.constraint_name, dcc.table_name, DC.CONSTRAINT_TYPE, dcc.column_name, dcc.position 
    FROM dba_segments ds, dba_constraints dc, dba_cons_columns dcc
    WHERE ds.owner = dc.owner
      AND dc.owner = dcc.owner
      AND ds.segment_name = dc.constraint_name
      AND dc.constraint_name = dcc.constraint_name
      AND ds.tablespace_name='INDEX_2'
      AND ds.segment_type='INDEX'   
      AND dc.constraint_type='P'
    ORDER BY dcc.owner, dcc.constraint_name, dcc.table_name, dcc.position  ASC 
)
GROUP BY owner, constraint_name, table_name, constraint_type

--- create script of unique and non-unique indexes
SELECT
    CASE 
        WHEN uniqueness = 'UNIQUE' THEN 'CREATE UNIQUE INDEX '||table_owner||'.'||index_name||' ON '||table_owner||'.'||table_name||' ('||wm_concat(column_name)||') TABLESPACE INDEX_3;' 
        WHEN uniqueness = 'NONUNIQUE' THEN 'CREATE INDEX '||table_owner||'.'||index_name||' ON '||table_owner||'.'||table_name||' ('||wm_concat(column_name)||') TABLESPACE INDEX_3;' 
        ELSE NULL
    END "Unique_NonUnique_Index"   
FROM 
(
    SELECT dic.table_owner, dic.index_owner, dic.index_name, dic.table_name,di.uniqueness, dic.column_name, dic.column_position
    FROM dba_indexes di, dba_ind_columns dic
    WHERE di.owner=dic.index_owner
      AND di.index_name = dic.index_name
       AND di.tablespace_name='INDEX_2'
      AND NOT EXISTS (SELECT 1 FROM dba_constraints dc WHERE dc.owner=di.owner AND dc.constraint_name = di.index_name AND dc.constraint_type IN ('P','U'))
    ORDER BY dic.table_name, dic.column_position ASC
)
GROUP BY table_owner, index_name, table_name, uniqueness


SELECT 'GRANT '||WM_CONCAT(PRIVILEGE)||' ON '||grantor||'.'||table_name||' TO '||grantee||';' 
FROM dba_tab_privs
WHERE owner  IN('SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00530',
                'SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520',
                'SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528',
                'SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_0059',
                'SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_SMSNOX_20170','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189',
                'SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199',
                'SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT',
                'SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515',
                'TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532',
                'TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_0059','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_SMSNOX_20170','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197',
                'TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSNOX_CAT','TRANSNOX_CPASS',
                'TRANSNOX_CPASS_UAT','TRANSNOX_IOX','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00530','TRANSNOX_UID_00532','TRANSNOX_UID_00535')
GROUP BY grantor,table_name,grantee
UNION ALL
SELECT 'create or replace synonym '||owner||'.'||synonym_name||' for '||table_owner||'.'||table_name||';' oops
FROM dba_synonyms
WHERE table_owner IN ('SNOX4TRANSNOX_API','SNOX4TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS_UAT','SNOX4TRANSNOX_UID','SNOX4TRANSNOX_UID_00523','SNOX4TRANSNOX_UID_00530',
                'SNOX4TRANSNOX_UID_00532','SNOX4TRANSNOX_UID_00535','SNOXPASS_GWAY_00513','SNOXPASS_GWAY_00515','SNOXPASS_GWAY_00516','SNOXPASS_GWAY_00520',
                'SNOXPASS_GWAY_00521','SNOXPASS_GWAY_00522','SNOXPASS_GWAY_00523','SNOXPASS_GWAY_00524','SNOXPASS_GWAY_00526','SNOXPASS_GWAY_00527','SNOXPASS_GWAY_00528',
                'SNOXPASS_GWAY_00529','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_00532','SNOXPASS_GWAY_00533','SNOXPASS_GWAY_00534','SNOXPASS_GWAY_00534_UAT','SNOXPASS_GWAY_0059',
                'SNOXPASS_GWAY_006','SNOXPASS_GWAY_006_UAT','SNOXPASS_GWAY_007','SNOXPASS_SMSNOX_20170','SNOXPASS_SMSNOX_20176','SNOXPASS_SMSNOX_20179','SNOXPASS_SMSNOX_20189',
                'SNOXPASS_SMSNOX_20191','SNOXPASS_SMSNOX_20193','SNOXPASS_SMSNOX_20194','SNOXPASS_SMSNOX_20195','SNOXPASS_SMSNOX_20197','SNOXPASS_SMSNOX_20198','SNOXPASS_SMSNOX_20199',
                'SNOXPASS_SMSNOX_30001','SNOXPASS_SMSNOX_30001_UAT','SNOXPASS_SMSNOX_301','SNOXPASS_SMSNOX_301_UAT','SNOXPASS_TFE_201116','SNOXPASS_TFE_201124','SNOXPASS_TFE_201124_UAT',
                'SNOXPASS_TFE_20113','SNOXPASS_TFE_20115','SNOXPASS_TFE_20116','SNOXPASS_TFE_2012','SNOXPASS_TFE_2012_UAT','SNOXPASS_TFE_2013','TNOXPASS_GWAY_00513','TNOXPASS_GWAY_00515',
                'TNOXPASS_GWAY_00516','TNOXPASS_GWAY_00520','TNOXPASS_GWAY_00521','TNOXPASS_GWAY_00522','TNOXPASS_GWAY_00523','TNOXPASS_GWAY_00524','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_00527','TNOXPASS_GWAY_00528','TNOXPASS_GWAY_00529','TNOXPASS_GWAY_00531','TNOXPASS_GWAY_00532',
                'TNOXPASS_GWAY_00533','TNOXPASS_GWAY_00534','TNOXPASS_GWAY_00534_UAT','TNOXPASS_GWAY_0059','TNOXPASS_GWAY_006','TNOXPASS_GWAY_006_UAT','TNOXPASS_GWAY_007','TNOXPASS_SMSNOX_20170','TNOXPASS_SMSNOX_20176','TNOXPASS_SMSNOX_20179','TNOXPASS_SMSNOX_20189','TNOXPASS_SMSNOX_20191','TNOXPASS_SMSNOX_20193','TNOXPASS_SMSNOX_20194','TNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20197',
                'TNOXPASS_SMSNOX_20198','TNOXPASS_SMSNOX_20199','TNOXPASS_SMSNOX_30001','TNOXPASS_SMSNOX_30001_UAT','TNOXPASS_SMSNOX_301','TNOXPASS_SMSNOX_301_UAT','TNOXPASS_TFE_201116','TNOXPASS_TFE_201124','TNOXPASS_TFE_201124_UAT','TNOXPASS_TFE_20113','TNOXPASS_TFE_20115','TNOXPASS_TFE_20116','TNOXPASS_TFE_2012','TNOXPASS_TFE_2012_UAT','TNOXPASS_TFE_2013','TRANSNOX_CAT','TRANSNOX_CPASS',
                'TRANSNOX_CPASS_UAT','TRANSNOX_IOX','TRANSNOX_UID','TRANSNOX_UID_00523','TRANSNOX_UID_00530','TRANSNOX_UID_00532','TRANSNOX_UID_00535')
AND owner<>'PUBLIC'

**************************************** Genarating Index Constraint Scripts ****************************************



**************************************** Monitoring Data Guard log-Shipping counts ****************************************
-- Monitoring Data Guard log-Shipping counts
SELECT DB_NAME, HOSTNAME, LOG_ARCHIVED, LOG_APPLIED,APPLIED_TIME,
LOG_ARCHIVED-LOG_APPLIED LOG_GAP
FROM
	(
		SELECT NAME DB_NAME
		FROM V$DATABASE
	),
	(
		SELECT UPPER(SUBSTR(HOST_NAME,1,(DECODE(INSTR(HOST_NAME,'.'),0,LENGTH(HOST_NAME),
		(INSTR(HOST_NAME,'.')-1))))) HOSTNAME
		FROM V$INSTANCE
	),
	(
		SELECT MAX(SEQUENCE#) LOG_ARCHIVED
		FROM V$ARCHIVED_LOG WHERE DEST_ID=1 AND ARCHIVED='YES'
	),
	(
		SELECT MAX(SEQUENCE#) LOG_APPLIED
		FROM V$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES'
	),
	(
		SELECT TO_CHAR(MAX(COMPLETION_TIME),'DD-MON/HH24:MI') APPLIED_TIME
		FROM V$ARCHIVED_LOG WHERE DEST_ID=2 AND APPLIED='YES'
	);
	
	
-- will give you the amount of logfiles archived during the last 24 hours.
SELECT * FROM v$archived_log WHERE COMPLETION_TIME > SYSDATE -1;


SELECT TRUNC(completion_time) rundate,COUNT(*) "logswitch",ROUND((SUM(BLOCKS*block_size)/1024/1024)) "Redo MB"
FROM v$archived_log
GROUP BY TRUNC(completion_time)
--order by


SELECT COUNT(*),TO_DATE(COMPLETION_TIME,'dd/mm/yy') 
FROM V$ARCHIVED_LOG WHERE deleted<>'YES'
GROUP BY TO_DATE(COMPLETION_TIME,'dd/mm/yy');
	
	
**************************************** Monitoring Data Guard log-Shipping counts ****************************************



**************************************** DB Objects Comparison ****************************************
-- compaire the index/constraint of 2 DB schemas
SELECT UNIQUE OWNER, CONSTRAINT_NAME, TABLE_NAME, COLUMN_NAME, position, DECODE(CONSTRAINT_TYPE,'V','Check View','R','Foreign Key','U','Unique Key','P','Primary Key','C','Check','O','Read Only View','Others')Constraint_Type, MISSING_CONS
FROM 
  (
    SELECT
        remo.owner, remo.constraint_name, remo.table_name, remo.column_name, remo.position, remo.constraint_type,
        NVL2((SELECT UNIQUE table_name FROM dba_cons_columns dcc1 WHERE dcc1.table_name=remo.table_name AND dcc1.owner=remo.owner),'Y','N')MISSING_CONS 
    FROM 
      (
        SELECT dcc.owner, dcc.constraint_name, dcc.table_name, dcc.column_name, dcc.position, dc.constraint_type
        FROM dba_cons_columns@cpdb dcc, dba_constraints@cpdb dc
        WHERE 
           dc.owner IN ('ETLUPDATE','KEYNOX_CPASS','WEBFORT_CPASS','TRANSNOX_CAT','TRANSNOX_IOX','SNOX4TRANSNOX','TRANSNOX_IOX_APP','SNOX4TRANSNOX_APP','TRANSTSYSPAYMENTGW','TRANSTSYSPAYMENTGWAPP','TNOXPASS_GWAY_012','SNOXPASS_GWAY_012','SNOXPASS_SMSNOX_307','TNOXPASS_SMSNOX_307','SNOXPASS_TFE_2016','TNOXPASS_TFE_2016','TNOXPASS_GWAY_011','SNOXPASS_GWAY_011','SNOXPASS_SMSNOX_306','TNOXPASS_SMSNOX_306','TNOXPASS_TFE_2015','SNOXPASS_TFE_2015','SNOXPASS_SMSNOX_20195','TNOXPASS_SMSNOX_20195','SNOXPASS_GWAY_00526','TNOXPASS_GWAY_00526','TNOXPASS_GWAY_013','SNOXPASS_TFE_2017','SNOXPASS_GWAY_013','TNOXPASS_TFE_2017' )
--           dc.owner IN ('QCP','CHECKCASH')
          AND DC.CONSTRAINT_NAME = DCC.CONSTRAINT_NAME 
          AND DC.OWNER=DCC.OWNER
        ORDER BY TABLE_NAME,POSITION ASC
      ) remo  
  ) i
WHERE i.MISSING_CONS='N'    
--  AND EXISTS (SELECT 1 FROM dba_tables dt WHERE dt.table_name=i.table_name AND i.owner=i.owner)
  AND NOT REGEXP_LIKE(i.table_name,'ORG|*[[:digit:]]','i')
ORDER BY table_name, position ASC



-- compare missing indexes using database link (DBLink) 
SELECT UNIQUE table_owner, table_name, column_name, index_name, mixs
FROM 
(
    SELECT i.table_owner, i.table_name, i.column_name, i.index_name,
      NVL2((SELECT UNIQUE dic.table_name FROM dba_ind_columns dic WHERE DIC.TABLE_NAME = i.table_name AND dic.table_owner = i.table_owner AND dic.column_name = i.column_name AND dic.table_owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')),'Y','N') mixs 
    FROM     
    (
        SELECT index_owner, index_name, table_owner, table_name, column_name
        FROM DBA_ind_columns@tp22
        WHERE index_owner IN ('SNOX4TRANSNOX', 'SNOX4TRANSNOX_GCA', 'TRANSNOX_GCA', 'TRANSNOX_GLORY', 'TRANSNOX_RECON', 'TRANSNOX_WM')
          AND table_name NOT LIKE '%ORG'
        ORDER BY index_owner,table_owner,table_name ASC
    )i
)
WHERE mixs='N'
ORDER BY 1,2,3 ASC     



-- compare the missing objects using dblink
SELECT owner, object_name, object_type, mis_tables, mis_view, mis_proc, mis_func, mis_tri, mis_pac, mis_pac_body, mis_seq 
FROM 
(    
    SELECT UNIQUE doj.owner, doj.object_name, doj.object_type,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TABLE' AND OBJECT_name NOT LIKE 'SN_TEMP%' AND OBJECT_name NOT LIKE 'SC_TEMP%' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tables,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='VIEW' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_view,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PROCEDURE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_proc,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='FUNCTION' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_func,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='TRIGGER' AND OBJECT_name NOT LIKE '%REPL' AND oj.object_name NOT LIKE '%REPL' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_tri,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='PACKAGE BODY' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_pac_body,
        NVL2((SELECT UNIQUE oj.object_name FROM dba_objects oj WHERE oj.object_type='SEQUENCE' AND oj.owner = doj.owner AND oj.object_name = doj.object_name),'Y','N') mis_seq
    FROM 
    (
        SELECT owner, object_name, object_type  
        FROM dba_objects@col122
        WHERE owner IN ('TRANSNOX_GCA','SNOX4TRANSNOX_GCA','SNOX4TRANSNOX','TRANSNOX_GLORY','TRANSNOX_WM')
          AND object_name NOT LIKE '%ORG' AND object_name NOT LIKE 'BIN$%'
          AND object_name NOT LIKE '%REPL'
          AND object_type IN ('TABLE','PROCEDURE','FUNCTION','TRIGGER','PACKAGE','PACKAGE BODY','SEQUENCE','VIEW')
        ORDER BY owner, object_name, object_type ASC
    ) doj
)
WHERE mis_tables='N'
  AND mis_view='N'
  AND mis_proc='N'
  AND mis_func='N'
  AND mis_tri='N'
  AND mis_pac='N'
  AND mis_pac_body='N'
  AND mis_seq='N'
  AND NOT REGEXP_LIKE(object_name,'TEMPSRI*|[[:digit:]]','i')
ORDER BY 3,2 ASC

-- compare the table's columns using dblink
SELECT unique owner, table_name, column_name, data_type, data_length, mis_cols
FROM
(
    SELECT dtc.owner, dtc.table_name, dtc.column_name, dtc.data_type, dtc.data_length,
        NVL2((SELECT UNIQUE dc.table_name FROM dba_tab_columns dc WHERE dc.owner=dtc.owner AND dc.table_name = dtc.table_name AND dc.column_name = dtc.column_name AND DC.DATA_TYPE = dtc.data_type AND DC.DATA_LENGTH = dtc.data_length ),'Y','N') mis_cols
    FROM
    (
        SELECT owner, table_name, column_name, data_type, data_length
        FROM dba_tab_columns@tp62
        WHERE owner IN ('ACM','ACM6000','CHECKCASH','CHECKCASHAPP','EDITH','GCA_PARSER','GCAACH','IDNOX','KEYNOX','MERGECUSTCODE','QCAPP','QCMGR','QCP','QCPAPP','QCPMGR','QCPTESTAPP','QCREDIT','QFAPP','QFCS','QFUND','QKADVANCE','QKADVANCEAPP','QRACM','QRACM_TEST','QRACMQCP','QRQCP','QUIKMEDIA','REALTIMERPT','SNOX','SCORENOX','SCORENOXAPP','SNOXDEVICES','USAP_ADAPTER','VERIBIOMETRICS','WUMT','WUMTAPP')
          AND table_name NOT LIKE '%ORG' AND table_name NOT LIKE 'BIN$%'
          AND table_name NOT LIKE 'SN_TEMP%'
        ORDER BY owner, table_name, column_name ASC
    )dtc
)
WHERE mis_cols='Y'
  AND REGEXP_LIKE(table_name,'[^0-9]$','i')
ORDER BY 1,2,3,4 ASC



--matrix which will show the set of table names, and schema name in coulms, Under those will have Y for yes having PK on table
-- else N no pk is not present in table on column name as schema name
SELECT DISTINCT j.table_name,
  NVL2((SELECT table_name FROM dba_constraints i1 WHERE i1.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_EAN'),'Y','N') "EAN",
  NVL2((SELECT table_name FROM dba_constraints i2 WHERE i2.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_WU'),'Y','N') "WU",
  NVL2((SELECT table_name FROM dba_constraints i3 WHERE i3.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_SSA'),'Y','N') "SSA",
  NVL2((SELECT table_name FROM dba_constraints i4 WHERE i4.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_WUMT'),'Y','N') "WUMT",
  NVL2((SELECT table_name FROM dba_constraints i5 WHERE i5.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_PEL'),'Y','N') "PEL",
  NVL2((SELECT table_name FROM dba_constraints i6 WHERE i6.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_CNW'),'Y','N') "CNW",
  NVL2((SELECT table_name FROM dba_constraints i7 WHERE i7.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_CNE'),'Y','N') "CNE"
FROM 
     (SELECT DISTINCT table_name 
      FROM 
        (SELECT owner, table_name FROM dba_tables 
         WHERE owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW')
          MINUS
         SELECT owner, table_name 
         FROM dba_constraints 
         WHERE constraint_type='P'
           AND owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
         )
      WHERE table_name <> 'RELEASE_HISTORY'
         AND table_name NOT LIKE '%BKP%'
         AND table_name NOT LIKE '%TEMP%'
         AND table_name NOT LIKE 'TODROP'
         AND table_name NOT LIKE '%BK%'
         AND table_name NOT LIKE '%STAGDB%'
         AND table_name NOT LIKE '%TABLE%'
         AND table_name NOT LIKE '%TEST%'
         AND table_name NOT LIKE '%0%'
         AND table_name NOT LIKE '%PROD%'
      )j
         

--- gives the list of missing table_name from given owners.
SELECT table_name, EAN, WU, SSA, WUMT, PEL, CNW, CNE
FROM (
SELECT DISTINCT j.table_name,
  NVL2((SELECT table_name FROM dba_tables i1 WHERE i1.table_name = j.table_name AND owner='TRANSNOX_EAN'),'Y','N') EAN,
  NVL2((SELECT table_name FROM dba_tables i2 WHERE i2.table_name = j.table_name AND owner='TRANSNOX_WU'),'Y','N')  WU,
  NVL2((SELECT table_name FROM dba_tables i3 WHERE i3.table_name = j.table_name AND owner='TRANSNOX_SSA'),'Y','N') SSA,
  NVL2((SELECT table_name FROM dba_tables i4 WHERE i4.table_name = j.table_name AND owner='TRANSNOX_WUMT'),'Y','N') WUMT,
  NVL2((SELECT table_name FROM dba_tables i5 WHERE i5.table_name = j.table_name AND owner='TRANSNOX_PEL'),'Y','N') PEL,
  NVL2((SELECT table_name FROM dba_tables i6 WHERE i6.table_name = j.table_name AND owner='TRANSNOX_CNW'),'Y','N') CNW,
  NVL2((SELECT table_name FROM dba_tables i7 WHERE i7.table_name = j.table_name AND owner='TRANSNOX_CNE'),'Y','N') CNE
FROM   
    (
      SELECT TABLE_NAME
      FROM dba_TABLES
      WHERE owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
        AND table_name NOT LIKE '%TEMP%'
        AND table_name NOT LIKE '%TEST%'
        AND table_name NOT LIKE '%0%'
        AND table_name NOT LIKE '%BK%'
        AND table_name NOT LIKE '%BKP%'
        AND table_name NOT LIKE '%DROP%'
    )j)
WHERE NOT (EAN = 'Y' AND WU = 'Y' AND SSA = 'Y' AND WUMT = 'Y' AND PEL = 'Y' AND CNW = 'Y' AND CNE = 'Y') 
ORDER BY table_name ASC


-- missing columns list
SELECT table_name, column_name, EAN, WU, SSA, WUMT, PEL, CNW, CNE
FROM
  (
    SELECT DISTINCT j.table_name, j.column_name,
      NVL2((SELECT column_name FROM dba_tab_columns i1 WHERE i1.table_name = j.table_name AND i1.column_name = j.column_name AND owner='TRANSNOX_EAN'),'Y','N') EAN,
      NVL2((SELECT column_name FROM dba_tab_columns i2 WHERE i2.table_name = j.table_name AND i2.column_name = j.column_name AND owner='TRANSNOX_WU'),'Y','N')  WU,
      NVL2((SELECT column_name FROM dba_tab_columns i3 WHERE i3.table_name = j.table_name AND i3.column_name = j.column_name AND owner='TRANSNOX_SSA'),'Y','N') SSA,
      NVL2((SELECT column_name FROM dba_tab_columns i4 WHERE i4.table_name = j.table_name AND i4.column_name = j.column_name AND owner='TRANSNOX_WUMT'),'Y','N') WUMT,
      NVL2((SELECT column_name FROM dba_tab_columns i5 WHERE i5.table_name = j.table_name AND i5.column_name = j.column_name AND owner='TRANSNOX_PEL'),'Y','N') PEL,
      NVL2((SELECT column_name FROM dba_tab_columns i6 WHERE i6.table_name = j.table_name AND i6.column_name = j.column_name AND owner='TRANSNOX_CNW'),'Y','N') CNW,
      NVL2((SELECT column_name FROM dba_tab_columns i7 WHERE i7.table_name = j.table_name AND i7.column_name = j.column_name AND owner='TRANSNOX_CNE'),'Y','N') CNE
    FROM
        (
            SELECT owner, table_name, column_name
            FROM dba_tab_columns
            WHERE owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
              AND table_name IN(SELECT table_name
                                FROM (
                                SELECT DISTINCT j.table_name,
                                  NVL2((SELECT table_name FROM dba_tables i1 WHERE i1.table_name = j.table_name AND owner='TRANSNOX_EAN'),'Y','N') EAN,
                                  NVL2((SELECT table_name FROM dba_tables i2 WHERE i2.table_name = j.table_name AND owner='TRANSNOX_WU'),'Y','N')  WU,
                                  NVL2((SELECT table_name FROM dba_tables i3 WHERE i3.table_name = j.table_name AND owner='TRANSNOX_SSA'),'Y','N') SSA,
                                  NVL2((SELECT table_name FROM dba_tables i4 WHERE i4.table_name = j.table_name AND owner='TRANSNOX_WUMT'),'Y','N') WUMT,
                                  NVL2((SELECT table_name FROM dba_tables i5 WHERE i5.table_name = j.table_name AND owner='TRANSNOX_PEL'),'Y','N') PEL,
                                  NVL2((SELECT table_name FROM dba_tables i6 WHERE i6.table_name = j.table_name AND owner='TRANSNOX_CNW'),'Y','N') CNW,
                                  NVL2((SELECT table_name FROM dba_tables i7 WHERE i7.table_name = j.table_name AND owner='TRANSNOX_CNE'),'Y','N') CNE
                                FROM
                                    (
                                      SELECT TABLE_NAME
                                      FROM dba_TABLES
                                      WHERE owner IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
                                        AND table_name NOT LIKE '%TEMP%'
                                        AND table_name NOT LIKE '%TEST%'
                                        AND table_name NOT LIKE '%0%'
                                        AND table_name NOT LIKE '%BK%'
                                        AND table_name NOT LIKE '%BKP%'
                                        AND table_name NOT LIKE '%DROP%'
                                    )j)
                                WHERE EAN = 'Y' AND WU = 'Y' AND SSA = 'Y' AND WUMT = 'Y' AND PEL = 'Y' AND CNW = 'Y' AND CNE = 'Y')
        )j
  )
WHERE NOT (EAN = 'Y' AND WU = 'Y' AND SSA = 'Y' AND WUMT = 'Y' AND PEL = 'Y' AND CNW = 'Y' AND CNE = 'Y')
ORDER BY table_name ASC

**************************************** DB Objects Comparison ****************************************


-- good example for clob writing and bfile writing
http://www.idevelopment.info/data/Oracle/DBA_tips/LOBs/LOBS_41.shtml


--automate this for inoc schema snox supportnox db
SELECT count(*)
FROM snox.INFONOX_SERVICE_USAGE
WHERE BACKEND_OUTPUT LIKE '%TIMEOUT%'
  AND TIMESTAMP BETWEEN TO_DATE('10/23/2008 00:00:00','mm/dd/yyyy hh24:mi:ss') AND TO_DATE('10/23/2008 23:59:59','mm/dd/yyyy hh24:mi:ss')
  AND SERVICE_NAME='USAP_Adapter'


-- The following statement selects the name, job, salary and department 
-- number of all employees except purchasing clerks from department number 30:
SELECT last_name, job_id, salary, department_id 
FROM employees 
WHERE NOT (job_id = 'PU_CLERK' AND department_id = 30)
ORDER BY last_name; 

--***********************************************************


****************************************  SUBQUERY FACTORING ****************************************
-- script of creating table script for selected tables from selected schemas
WITH DATA AS 
(
    SELECT owner,table_name,column_name,data_type,data_length,column_id,
        row_number() OVER (PARTITION BY table_name ORDER BY column_id) rn, 
        COUNT(*) OVER (PARTITION BY table_name) cnt 
    FROM dba_tab_columns
    WHERE owner='SNOX4TRANSNOX_GCA'
     AND TABLE_NAME IN ('CC_CSR_TASK_ASSIGN_TS','CC_QUEUE_ID_MASTER','CC_TASK_INFO','CORPORATION_CONFIGURATION'
    ORDER BY owner,table_name,column_id ASC 
)
SELECT replace(REPLACE(REPLACE(REPLACE('create table '||owner||'.'||table_name||' ('||
LTRIM(SYS_CONNECT_BY_PATH(column_name ||' ' ||data_type ||'('||DECODE(data_type,'DATE','','CLOB','','BLOB','','LONG','',data_length)||')',', '),',')||');','DATE()','DATE'),'CLOB()','CLOB'),'BLOB()','BLOB'),'LONG()','LONG') scrt 
FROM DATA 
WHERE rn = cnt 
START WITH rn = 1 
CONNECT BY PRIOR table_name = table_name 
AND PRIOR rn = rn-1 
ORDER BY owner 
--***********************************************************

   
-- with Clause ref link  
http://psoug.org/reference/OLD/with.html?PHPSESSID=0170804500f330f02e30ddbb1f8e84a2

-- works like a loop in select statment
-- columns data separated by , (comma)
with data as 
( 
    select casinocode, employeecode, 
    row_number() over (partition by casinocode order by employeecode) rn, 
    count(*) over (partition by casinocode) cnt 
    from qcp.employees
    where CASINOCODE = '000012'
) 
select casinocode,
ltrim(sys_connect_by_path(employeecode,','),',') scbp
from data
where rn = cnt
start with rn = 1
connect by prior casinocode = casinocode
and prior rn = rn-1
order by casinocode


--- Script for comma separated 
SELECT parent_id, 
	RTRIM(XMLAGG(XMLELEMENT(e,child_id || ',')).EXTRACT('//text()'),',') AS "Children"   
FROM parentChildTable  
WHERE parent_id = 0  
GROUP BY parent_id 

SELECT parent_id, LISTAGG(child_id, ',') WITHIN GROUP (ORDER BY child_id) AS "Children"   
FROM parentChildTable  
WHERE parent_id = 0  
GROUP BY parent_id 

Or use the Oracle function WM_CONCAT(Column_Name) for comma separator


-- script to create grants for given schema's
with data as
(
    SELECT grantee,table_name,grantor,privilege,
            row_number() over (partition by table_name order by grantor) rn, 
            count(*) over (partition by table_name) cnt 
    from dba_tab_privs
    where grantor in ('SNOX4TRANSNOX','TRANSNOX_CPK')
      AND GRANTEE in ('SNOX4TRANSNOX','TRANSNOX_CPK')
    GROUP BY  grantee,table_name,grantor,privilege
    ORDER BY  table_name asc
)
select --grantor "Grants From",grantee "Grants To", table_name, 
    'GRANT '||ltrim(sys_connect_by_path(privilege,','),',')||' ON '||grantor||'.'||TABLE_NAME||' TO '||decode(grantor,'SNOX4TRANSNOX','TNOX_IOX0059','TRANSNOX_CPK','SNOX_10314')||';' scbp
from data 
where rn = cnt 
start with rn = 1 
connect by prior table_name = table_name 
and prior rn = rn-1 
order by 1 asc  


-- table name which are present in the schema and schema's will output as common separated
with data as
(
    SELECT owner, object_name,
            row_number() over (partition by object_name order by owner) rn, 
            count(*) over (partition by object_name) cnt 
    FROM dba_objects i
    WHERE object_type='TABLE' 
        AND object_name NOT LIKE 'SN_TEMP%'
        AND object_name <> 'RELEASE_HISTORY'
        AND object_name NOT LIKE '%BKP'
        AND object_name NOT LIKE 'TEMP%'
        AND object_name NOT LIKE 'TODROP'
        AND object_name NOT LIKE '%BK'
        AND object_name NOT LIKE 'SC_TEMP%'
        AND object_name NOT LIKE 'BIN$%'
        and  OWNER  IN ('TRANSNOX_PEL', 'TRANSNOX_EAN', 'TRANSNOX_SSA', 'TRANSNOX_WUMT', 'TRANSNOX_WU', 'TRANSNOX_CNW','TRANSNOX_CNE')
    GROUP BY  owner, object_name
    ORDER BY  object_name asc
)
select object_name, 
    ltrim(sys_connect_by_path(owner,','),',') scbp 
from data 
where rn = cnt 
start with rn = 1 
connect by prior object_name = object_name 
and prior rn = rn-1 
order by object_name  

****************************************  SUBQUERY FACTORING ****************************************


-- find 11 latest records
SELECT * 
FROM 
  (
     SELECT  *  FROM   qcp.transactions 
     ORDER BY ROWNUM DESC
  ) 
WHERE ROWNUM < 11;

-------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------
-- This excludes the weekends
CREATE OR REPLACE FUNCTION no_weekends_action (p_date1 IN DATE, p_date2 IN DATE) RETURN NUMBER IS
   l_count NUMBER := 0;
   v_excluded_days number;
   v_minutes       number;
   l_date1 DATE := LEAST(p_date1, p_date2);
   l_date2 DATE := GREATEST(p_date1, p_date2);
BEGIN
   WHILE (l_date1 <= l_date2) LOOP
      IF (TO_CHAR(l_date1,'DY') NOT IN ('SAT','SUN')) THEN
         l_count := l_count + 1;
      END IF;
      l_date1 := l_date1 + 1;
   END LOOP;
   
   v_excluded_days:= floor((l_date2-l_date1)-l_count);
   v_minutes := round(((l_date2-l_date1)-v_excluded_days )*24*60);
   RETURN v_minutes;
END;
/

select no_weekends_action(to_date('06/26/2009 01:23:00 PM','mm/dd/yyyy hh:mi:ss am'),
to_date('07/03/2009 03:42:00 PM','mm/dd/yyyy hh:mi:ss am')) ||' mins 'diff 
from dual

-------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------

--Returns A Day A Specified Number Of Days In The Future Skipping Weekends
CREATE OR REPLACE FUNCTION business_date 
(
	start_date DATE,
	Days2Add NUMBER
) RETURN DATE IS
 Counter  NATURAL := 0;
 CurDate  DATE := start_date;
 DayNum   POSITIVE;
 SkipCntr NATURAL := 0; 
BEGIN
  WHILE Counter < Days2Add LOOP
    CurDate := CurDate+1;
    DayNum := TO_CHAR(CurDate, 'D');

    IF DayNum BETWEEN 2 AND 6 THEN
      Counter := Counter + 1;
    ELSE
      SkipCntr := SkipCntr + 1;
    END IF;
  END LOOP;
  RETURN start_date + Counter + SkipCntr;
END business_date;
/

          
-- date come in wording
SELECT TO_CHAR(TO_DATE('10:30:18', 'HH24:MI:SS'), 'HH24SP:MISP:SSSP') FROM dual;

SELECT TO_CHAR(TO_DATE('01-JAN-2008', 'DD-MON-YYYY'), 'DDSP-MONTH-YYYYSP') FROM dual;

SELECT TO_CHAR(TO_DATE('01-JAN-2008', 'DD-MM-YYYY'), 'DDSP-MMSP-YYYYSP') FROM dual;

--*********************************************************************************************------------
-- number must be between 5373484 only
SELECT TO_CHAR(TO_DATE('123','J'), 'JSP')FROM dual;

-- Conver wordings in numbers like ONE THOUSAND TWO HUNDRED TWENTY-THREE will show as 1223 in result
SELECT LEVEL wordasint
FROM   dual
WHERE  TO_CHAR(TO_DATE(LEVEL,'J'), 'JSP') = 'ONE THOUSAND TWO HUNDRED TWENTY-THREE'
CONNECT BY TO_CHAR(TO_DATE(LEVEL-1,'J'),'JSP') != 'ONE THOUSAND TWO HUNDRED TWENTY-THREE'
AND    LEVEL < 10001;

--*********************************************************************************************------------

-- Coming Transaction Date is Leap year then alter to administrator
IF v_Flag = 'False' THEN
	v_ErrorFlag:=7;
	IF MOD(MOD(TO_CHAR(TO_DATE(i.UPS_Log_Date,'mmddyy'),'yyyy'),400),4) = 0 THEN
		IF SUBSTR(i.UPS_Log_Date,3,2) = '29' THEN
			 v_Flag:='True';
			 v_FlagError_Code:=400;
			 v_DB_Error_Code:= 'This is Leap Year Date --Invalid Date';
		END IF;
	END IF;
END IF;



-- Stringtokenizer
-- getting the values from values option in insert statement
replace(replace(replace(substr(v_Sql_String, instr(v_Sql_String,') values(')+9,length(v_Sql_String)),')',''),'''',''),' , ',',')


--- Missing Batches for Swiss Solution
select USER_ID, TIME_STAMP, REPORT_NAME, CHANGE_TYPE, AUDIT_TRAIL,'Inactive Casinos'
from snox.SNOX_UPDATE_AUDIT_TRAIL 
where report_name like 'CNOX_QCP%' and upper(change_type)='UPDATE'
 and upper(audit_trail) like '%CASINO_CODE%481901%PARAM%CCCA_OPTION%'
 

------------------------------------------------

---How to implement ISNUMERIC function in SQL *Plus ?
--It returns 0 if it pass a number, 1 if pass any char. 
SELECT INSTR(TRANSLATE('a', 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'),'X') IsNumeric
FROM dual; 

SELECT LENGTH (TRANSLATE (trim ('1'),' +-.0123456789',' ')) FROM dual ;

------------------------------------------------

where username not in 
('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','ACM_3_7_0_0','ACM_3_6_0_0','ACM_3_5_0_0','ACM_3_4_9_0','ACM_3_4_8_0','ACM_3_4_7_0',
'ACM_3_4_6_0','ACM_3_4_5_0','IMP_TEST','ACM_3_4_4_0','ACM3470','TODROP','SRC_C_REPL','SNOX4TRANSNOX_WUCC_BKP','TEST_USER',
'FDMS','BAMS','SQLLAB','RAHULC','PUNEDBA','PBT','OEM_TRANDB','ORADES','ALI', 'AMIR', 'ARTURO', 'HIEN', 'NASIR', 'RAHULC', 'SAQIB', 'SRIDHAR', 'TANVEER')

('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','SRC_LV','RAKESH','BAMS','TRANSNOX_WU','SQLLAB','ORADES','BDAS','PUBLIC','SRC_C_REPL','SRC_MONITOR','SRC_SC','SRC_SNOX','SNOX4TRANSNOX_WU')


SELECT * FROM dba_objects
WHERE owner IN 
('SNOX4TRANSNOX','SNOX4TRANSNOX_WU','SNOX4TRANSNOX_WUCC','TRANSNOX_GLORY','TRANSNOX_IDENTESYS','TRANSNOX_IFASTPAY','TRANSNOX_PURPOSE','TRANSNOX_SSA','TRANSNOX_WM','TRANSNOX_WU','')

-- GRANT command from snox4transnox to application schema's
SELECT 'GRANT '||PRIVILEGE||' ON '||OWNER||'.'||TABLE_NAME||' TO TRANSNOX_NR;'
FROM USER_TAB_PRIVS 
WHERE grantee='TRANSNOX_IFASTPAY'
 AND GRANTOR='SNOX4TRANSNOX'
 
 ------------------------------------------------------
 
-- count of all objects 
select OWNER, OBJECT_TYPE, STATUS,count(*) from dba_objects
group by OWNER, OBJECT_TYPE, STATUS
 
 ------------------------------------------------------
 
-- create tablespace script 
SELECT 'CREATE TABLESPACE '||tablespace_name||' DATAFILE D:\oracle\oradata\trans\datafiles\\'||tablespace_name||
'_01.DBF SIZE '||SUM(bytes)||
' AUTOEXTEND ON NEXT 10240k maxsize unlimited EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO ;'
FROM DBA_DATA_FILES
GROUP BY tablespace_name;
 
 ------------------------------------------------------ 
 
-- create user script 
select 'create user '||USERNAME||' identified by '||username||' default tablespace '|| default_tablespace ||' temporary tablespace temp quota unlimited on '|| default_tablespace ||';'
from dba_users
where username not in('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES');
 
 ------------------------------------------------------ 
 
--- drop user script
select 'drop user '||USERNAME||' cascade;' from all_users
where username not in('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES');
 
 ------------------------------------------------------ 
 
--- alter invalid objects script  
 select 'alter '||object_type||'  '||owner||'.'||object_name||'  COMPILE ; ' from dba_objects where status='INVALID'
 and  owner not in('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES','OUNIT');
 
 ------------------------------------------------------ 
 
-- grant privilege script
select 'GRANT '||privilege||' ON '||grantor||'.'||table_name||' TO '||grantee||';' 
from dba_tab_privs
where owner not in('SYS','SYSTEM','OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','RMAN','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES','OUNIT')
and grantee <>'PUBLIC'
 
 ------------------------------------------------------ 
 
--- revoke privilege script
select 'revoke connect from '||username from dba _users
where username in('OUTLN','DBSNMP','WMSYS','ORDSYS','ORDPLUGINS','MDSYS','CTXSYS','XDB','ANONYMOUS',
'WKSYS','WKPROXY','ODM','ODM_MTR','OLAPSYS','HR','OE','PM','SH','QS_ADM','QS','QS_WS','QS_ES','QS_OS','QS_CBADM',
'QS_CB','QS_CS','SCOTT','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','ANUPAM','FDMS_BAM','BLAKE','OSE$HTTP$ADMIN',
'TOAD','FDMS_STLMNT','FDMS','BAMS','SQLLAB','ORADES');
 
 ------------------------------------------------------ 
 
 -- copy command
COPY FROM sys/change_on_install@stag TO stag/stag@ispldb CREATE schemas_name USING -      
select username,account_status,default_tablespace,temporary_tablespace from dba_users;
 
 ------------------------------------------------------ 
 
---- dropping all temp<number>  tables for TranSending db
select 'DROP TABLE '||OWNER||'.'||TABLE_NAME||';' from dba_tables where length(substr(table_name,5))=26
and substr(table_name,1,4)='TEMP'
 
 ------------------------------------------------------ 
 
--- creating synonym for one schema
SELECT 'CREATE OR REPLACE SYNONYM '||synonym_name||' FOR '||TABLE_owner||'.'||synonym_name||';'
FROM dba_synonyms
WHERE TABLE_OWNER='SNOX4TRANSNOX' AND OWNER='TRANSNOX_PURPOSE'
 
 ------------------------------------------------------ 
 
-- changing index tablespace script for LOB indexes for data type like CLOB / BOLB etc...
SELECT 'ALTER TABLE '||OWNER||'.'||TABLE_NAME||' MOVE LOB ('||COLUMN_NAME||') STORE AS (TABLESPACE INDX);' indx 
FROM dba_tab_columns 
WHERE table_name IN 
 ('ADSMASTER','CALLNOX_AUDIT_TRAIL','CLOB_TEMP','CUST_FACE','CUST_FACE_HISTORY','CUST_FINGER','CUST_FINGER_PRINT','CUST_FINGER_PRINT_HISTORY','CUST_ID_IMAGES_HIST','ENROLLED_CHECK','ENROLLED_CHECK_HISTORY','ENROLLED_CHECK_PROFILE_HISTORY','KFE_REQUEST_RESPONSE','KFE_REQUEST_RESPONSE_BKP','KFE_REQUEST_RESPONSE_HIST','LOGO_IMAGES','MNOX_SERVER_DETAILS','RECON_FILE_CONFIG','SNOX_UPDATE_AUDIT_TRAIL ','SNOX_USER_ACCESS','SN_PRODUCT_DEPLOYMENT ','SN_PRODUCT_MASTER','SN_PRODUCT_TESTING ','SN_PROD_DB_RELEASE ','SUSP_CUST_FACE','SUSP_CUST_FINGER_PRINT','SUSP_CUST_ID_IMAGES','TEMP_CUST_FACE','TEMP_CUST_FINGER_PRINT','TEMP_CUST_ID_IMAGES','TRAN_CHECK_IMAGES','TRAN_CUST_FACE','TRAN_CUST_ID_IMAGE ','USER_FINGER_PRINT','USER_FINGER_PRINT_HISTORY') 
 AND data_type IN ('BOLB','CLOB')
 
 
ALTER TABLE  QCP.CUSTOMER_SIGNATURES
    MOVE TABLESPACE users
    LOB (ENROLLMENT_SIGNATURE) STORE AS (TABLESPACE INDX)
    
 ------------------------------------------------------ 
 
---- script for rebuilding index tablespace 
 SELECT 'ALTER INDEX '||OWNER||'.'||INDEX_NAME||' REBUILD TABLESPACE INDX;'
 FROM DBA_INDEXES
 WHERE OWNER IN 
  ('ADSMASTER','CALLNOX_AUDIT_TRAIL','CLOB_TEMP','CUST_FACE','CUST_FACE_HISTORY','CUST_FINGER','CUST_FINGER_PRINT','CUST_FINGER_PRINT_HISTORY','CUST_ID_IMAGES_HIST','ENROLLED_CHECK','ENROLLED_CHECK_HISTORY','ENROLLED_CHECK_PROFILE_HISTORY','KFE_REQUEST_RESPONSE','KFE_REQUEST_RESPONSE_BKP','KFE_REQUEST_RESPONSE_HIST','LOGO_IMAGES','MNOX_SERVER_DETAILS','RECON_FILE_CONFIG','SNOX_UPDATE_AUDIT_TRAIL ','SNOX_USER_ACCESS','SN_PRODUCT_DEPLOYMENT ','SN_PRODUCT_MASTER','SN_PRODUCT_TESTING ','SN_PROD_DB_RELEASE ','SUSP_CUST_FACE','SUSP_CUST_FINGER_PRINT','SUSP_CUST_ID_IMAGES','TEMP_CUST_FACE','TEMP_CUST_FINGER_PRINT','TEMP_CUST_ID_IMAGES','TRAN_CHECK_IMAGES','TRAN_CUST_FACE','TRAN_CUST_ID_IMAGE ','USER_FINGER_PRINT','USER_FINGER_PRINT_HISTORY') 
  AND INDEX_TYPE='NORMAL'
 
 ------------------------------------------------------ 
-- SQL Query by CPU Usage

select * from 
(select 
    cpu_time/1000000 cpu_time, 
    elapsed_time/1000000 elapsed_time, 
    disk_reads, 
    buffer_gets, 
    rows_processed,
    sql_text
from v$sqlarea 
order by cpu_time desc, disk_reads desc
) 
where rownum < 21


---- the overall CPU usage for each thread
SELECT p.spid THREAD, s.username,
    DECODE(NVL(p.background,0),1,bg.description,s.program ) program,
    ss.VALUE/100 CPU,physical_reads disk_io
 FROM 
    v$process p,
    v$session s,
    v$sesstat ss,
    v$sess_io si,
    v$bgprocess bg
 WHERE s.paddr=p.addr
  AND ss.SID=s.SID
  AND ss.statistic#=12 
  AND si.SID=s.SID
  AND bg.paddr(+)=p.addr
 ORDER BY ss.VALUE DESC;
 
/*
   which active session is bogging down the system with a bad hit ratio.
The ratio of buffer to physical block reads can many times be an indication of the efficiency of the query running. Anything under 
90% is typically bad. Very low hit ratios (< 10-30%) in a process can slow down the entire system.   
*/
SELECT
    P.username            unix_id
  , s.username            oracle_id
  , s.osuser              os_user
  , s.SID                 SID
  , s.serial#             serial_id
  , LPAD(P.spid,7)        unix_pid
  , sio.consistent_gets   consistent_gets
  , sio.block_gets        block_gets
  , sio.physical_reads    physical_reads
  , ROUND((consistent_gets+Block_gets-Physical_reads) /
          (Consistent_gets+Block_gets)*100,2) hit_ratio
FROM
    v$process P
  , v$session s
  , v$sess_io sio
WHERE
      P.addr=s.paddr
  AND s.SID = sio.SID
  AND (sio.consistent_gets + sio.block_gets) > 0
  AND s.username IS NOT NULL
ORDER BY hit_ratio ASC 
 
 ------------------------------------------------------ 
 
---- count of primary key columns 
SELECT constraint_name,table_name,owner,COUNT(*) cnt_cons 
FROM dba_cons_columns 
WHERE constraint_name LIKE 'PK%' 
  AND owner NOT IN 
   ('SYS','SYSTEM','WMSYS','ORDSYS','MDSYS','OLAPSYS','CTXSYS','WKSYS','DBSNMP','ISPL_DBA','RMAN','SRC_JAVA_REPL','SRC_C_REPL','TEST_USER') 
GROUP BY constraint_name,table_name,owner 
HAVING COUNT(*) >=1 
ORDER BY cnt_cons DESC
 
 ------------------------------------------------------ 
 
---- tables which are not having PK
SELECT OWNER,TABLE_NAME
FROM DBA_TABLES dt
WHERE NOT EXISTS (SELECT  'TRUE'
                  FROM DBA_CONSTRAINTS dc
                  WHERE dc.TABLE_NAME = dt.TABLE_NAME
                    AND dc.CONSTRAINT_TYPE='P')
  AND OWNER NOT IN ('SYS','SYSTEM','TOAD','OUTLN','WMSYS','ORDSYS','MDSYS','OLAPSYS','WKPROXY','CTXSYS','WKSYS','DBSNMP','ISPL_DBA','RMAN','SRC_JAVA_REPL','SRC_C_REPL','TEST_USER')
--ORDER BY OWNER, TABLE_NAME
 
 ------------------------------------------------------ 
 
--- table name and constraint name foreigen key plus pk
SELECT distinct 
   uc.owner, uc.table_name, uc.constraint_name, ucc.column_name,
   uc.r_constraint_name, pk_cons.table_name, pk_cons.column_name 
FROM dba_CONSTRAINTS uc, dba_CONS_COLUMNS ucc, 
(
   SELECT ucc2.constraint_name, ucc2.table_name, ucc2.column_name
   FROM dba_CONS_COLUMNS ucc2, dba_CONSTRAINTS uc
   WHERE ucc2.constraint_name = uc.constraint_name
     AND uc.constraint_type = 'P'
     and ucc2.TABLE_NAME='CC_CSR'
  )pk_cons
WHERE uc.constraint_name=ucc.constraint_name  
  AND uc.r_constraint_name = pk_cons.constraint_name
  AND uc.constraint_type='R'

------------------------------------------------------ 
 
--- primary key and no primary key tables
SELECT table_name, DECODE(constraint_type,'P','PK','NOPK') check_constraints
FROM(
SELECT table_name, constraint_type FROM USER_CONSTRAINTS
WHERE constraint_type='P'
UNION
SELECT table_name, NULL FROM USER_TABLES
WHERE table_name NOT IN(SELECT table_name
                        FROM USER_CONSTRAINTS
                        WHERE constraint_type='P'))
ORDER BY CONSTRAINT_TYPE ASC
 
 ------------------------------------------------------ 
 
--- query to list, all those table name which are having primary for all the column in table
SELECT table_name FROM USER_TABLES a
WHERE (SELECT COUNT(1) 
       FROM USER_CONS_COLUMNS b,USER_CONSTRAINTS c 
       WHERE a.table_name = b.table_name 
         AND b.constraint_name = c.constraint_name 
         AND c.constraint_type='P') = (SELECT COUNT(1) 
                                       FROM USER_TAB_COLUMNS b 
                                       WHERE a.table_name=b.table_name)
 
 ------------------------------------------------------ 
 
-- query to list all those tables which are having primary key but not those 
-- tables which are having primary key to all the columns in a table 
SELECT table_name FROM USER_TABLES
WHERE table_name IN(SELECT table_name
                 FROM USER_CONSTRAINTS
                 WHERE constraint_type='P')
  AND table_name NOT IN(SELECT table_name FROM USER_TABLES a
                        WHERE (SELECT COUNT(1) 
                               FROM USER_CONS_COLUMNS b,USER_CONSTRAINTS c 
                               WHERE a.table_name = b.table_name 
                                 AND b.constraint_name = c.constraint_name 
                                 AND c.constraint_type='P') = (SELECT COUNT(1) 
                                                               FROM USER_TAB_COLUMNS b 
                                                               WHERE a.table_name=b.table_name))
ORDER BY table_name ASC
 
 ------------------------------------------------------ 
 
--- will count records in all the table 
SELECT 'select '''||table_name||''', count(*) from '||table_name||';'qry
FROM user_tab_columns
WHERE column_name LIKE 'APPLICATION_ID'
ORDER BY table_name ASC
 
 ------------------------------------------------------ 
 
--- no primary key on tables
SELECT table_name FROM user_tables
MINUS
SELECT table_name FROM user_constraints WHERE constraint_type='P'
 
 ------------------------------------------------------ 
 
--- generate the script for invalid objects in database
SELECT 
   'Alter ' ||
   DECODE( object_type, 'PACKAGE BODY', 'PACKAGE', object_type ) ||
   ' ' ||
   owner || '.' || object_name || ' Compile ' ||  
   DECODE( object_type,'PACKAGE', 'SPECIFICATION','PACKAGE BODY', 'BODY') ||';' SQL_QUERY,
   DECODE( owner, 'SYS', 1,'SYSTEM', 2, 3) SORT_OWNER,
   DECODE( object_type,'VIEW', 1,'PACKAGE', 2,'TRIGGER', 9, 3) SORT_TYPE
FROM
   DBA_OBJECTS
WHERE status='INVALID'
  AND owner NOT IN
    ('SYS','SYSTEM','WMSYS','ORDSYS','MDSYS','OLAPSYS','CTXSYS','WKSYS','DBSNMP','ISPL_DBA','RMAN','SRC_JAVA_REPL','SRC_C_REPL','TEST_USER') 
ORDER BY
   SORT_OWNER, SORT_TYPE;
   
--- compile invalid object with in schema 
EXEC DBMS_UTILITY.COMPILE_SCHEMA( USER, FALSE );
SELECT 'ALTER '||OBJECT_TYPE||' '||OBJECT_NAME||' COMPILE;' FROM OBJ WHERE STATUS = 'INVALID'
 
 ------------------------------------------------------ 
 
-- the thrid highest value, just chage the value in place of 3 
-- and change the joing as per u want means what higest u want 
SELECT  eid FROM EMP1 c1
WHERE 3=(SELECT COUNT(*) FROM EMP1 c2 WHERE C1.eid >= C2.eid)   
 
 ------------------------------------------------------ 
 
--- Flash Back Query

-- Oracle Flashback Query can only be used if the server is configured to use Automatic 
-- Undo Management, rather than traditional rollback segments. The maximum time period 
-- that can be flashbacked to is defined using the UNDO_RETENTION parameter in the 
-- init.ora file. Alternatively, this parameter can be set using:

ALTER SYSTEM SET UNDO_RETENTION = <seconds>;

--- Query to get the deleted data before 10 minutes
SELECT * FROM LOOKUP_TRANS_STATUS
 AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE); 
 
-- so like wish u can insert the data back in the table  
INSERT INTO LOOKUP_TRANS_STATUS
 SELECT * FROM LOOKUP_TRANS_STATUS
  AS OF TIMESTAMP (SYSTIMESTAMP - INTERVAL '10' MINUTE);
-- if wanna selected data from deleted data then  
   WHERE CONDITION... = ?;
 
 

--To select data as if we where in the past, you can use a flashback query. How long 
--you can go back depends on the size of the UNDO tablespace and on how quickly that fills up. 

--If you want to see the content of the table 1 hour ago you can query it like:

SELECT *
FROM tablename
AS OF TIMESTAMP SYSTIMESTAMP - INTERVAL '1' HOUR;


--If you want to see the content of the table 2 days ago you can query it like:

SELECT *
FROM tablename
AS OF TIMESTAMP SYSTIMESTAMP - INTERVAL '2' DAY;

--or you can select the status per SCN number.

--To query the current SCN number:

SELECT DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER() FROM DUAL; 


--To select a SCN number (System Change Number) on a specific timestamp:

SELECT TIMESTAMP_TO_SCN('11-JUN-09 10.30.09.000000000 AM') FROM dual; 


--With this SCN number you can query in the past with "scn-number":

SELECT *
FROM tablename
AS OF SCN "scn-number";


--To select changes on a table since a specific System Change Numbers (SCN):

SELECT * FROM tabelnaam
VERSIONS BETWEEN SCN SCN_x AND MAXVALUE; 


--LASHBACK TABLE helps restore the state of a table to a certain point
--in time even if a table structure changed has occurred since then. The
--following simple command will take us to the table state at the
--specified timestamp.
FLASHBACK TABLE employee TO TIMESTAMP  to_date('27-Feb-09 05:00:00 PM','DD-MON-YY HH:MI:SS PM');


--Oracle 10g has provided another useful feature term as the Flashback
--drop. For our example if a DROP TABLE has been issued for the table
--EMPLOYEE we can still restore the whole table by issuing the following
--command.
FLASHBACK TABLE EMPLOYEE TO BEFORE DROP;
 

 ------------------------------------------------------ 
 
--- Values seprated by ','
SELECT SCORING_PROPERTY_NAME, MAX(CUSTOMER_CODE)
  FROM (SELECT rn, ROWNUM - LEVEL SCORING_PROPERTY_NAME, SYS_CONNECT_BY_PATH(CUSTOMER_CODE, ',') CUSTOMER_CODE
          FROM (SELECT ROWNUM rn, CUSTOMER_CODE FROM CUST_SCORE)
        CONNECT BY PRIOR rn = rn - 1 AND CUSTOMER_CODE != 48
         START WITH CUSTOMER_CODE = 48)a
 GROUP BY SCORING_PROPERTY_NAME
 ORDER BY SCORING_PROPERTY_NAME   
 
 ------------------------------------------------------ 

 --- referential constraint script from a schema
 SELECT 'ALTER TABLE '||uc.table_name||' ADD ('||CHR(13)||' CONSTRAINT '||uc.constraint_name||' FOREIGN KEY ('||ucc.column_name||')'||CHR(13)||'  REFERENCES '||pk_cons.table_name||'('||pk_cons.column_name||'));' CONS_QUERY 
 --   uc.table_name,uc.constraint_name,ucc.column_name,
  --  pk_cons.table_name"PK TableName",pk_cons.column_name "PK ColName" 
 FROM USER_CONSTRAINTS uc, USER_CONS_COLUMNS ucc, 
 (
    SELECT ucc.constraint_name,ucc.table_name,ucc.column_name
    FROM USER_CONS_COLUMNS ucc, USER_CONSTRAINTS uc
    WHERE ucc.constraint_name = uc.constraint_name
      AND uc.constraint_type='P'
   )pk_cons
 WHERE uc.constraint_name=ucc.constraint_name  
   AND uc.r_constraint_name = pk_cons.constraint_name
   AND uc.constraint_type='R'
ORDER BY uc.table_name ASC

------------------------------------------------------ 
 
-- deletion of child records
SELECT * FROM user_constraints WHERE constraint_Name = 'FK_CHKC_CS_HIST_XTNID'

SELECT * FROM chkc_transactions WHERE length(checkno) < 6

SELECT * FROM qcp.telechecktransactions WHERE length(checkno) < 6


DELETE FROM CHKC_CHECK_STATUS_HISTORY ch
WHERE ch.transactionid in 
 (
  SELECT
       ct.transactionid 
  FROM 
       chkc_transactions ct 
  WHERE 
       length (ct.checkno) < 6
 ) 


DELETE FROM chkc_transactions WHERE length(checkno) < 6

DELETE FROM qcp.telechecktransactions WHERE length(checkno) < 6

SELECT 
       CT.TRANSACTIONID, CT.CHECKNO, CH.TRANSACTIONID
FROM 
     CHKC_TRANSACTIONS CT, CHKC_CHECK_STATUS_HISTORY CH
WHERE 
      CT.TRANSACTIONID = CH.TRANSACTIONID
      AND LENGTH(CT.CHECKNO) < 6


DELETE FROM chkc_transactions A WHERE A.transactionid IN
(SELECT B.transactionID FROM CHKC_CHECK_STATUS_HISTORY B WHERE A.transactionid=B.transactionID)
 AND length(A.checkNo) < 6


---------------------------------------------------------------------

-- rowset will return the cursor records
SELECT deptno, depname, CURSOR( SELECT EMPLOYEE FROM EMP e WHERE e.LEVEL1 = dept.deptno )dep
FROM dept   WHERE deptno = 2;

---------------------------------------------------------------------

-- the procedure will return the result rowset 
CREATE OR REPLACE PACKAGE TYPES AS 
  TYPE cursor_type IS REF CURSOR;
END TYPES; 
/


CREATE OR REPLACE PROCEDURE GetEmpRS 
(
     i_LEVEL1    IN  NUMBER,
     p_recordset OUT TYPES.cursor_type
) AS 
BEGIN 
  OPEN p_recordset FOR
    SELECT LEVEL1, EMPLOYEE, EMP_ID, MGR_ID
    FROM   EMP
    WHERE  LEVEL1 = i_LEVEL1
    ORDER BY EMPLOYEE;
END GetEmpRS;
/

 SET SERVEROUTPUT ON SIZE 1000000
 DECLARE
   v_cursor  TYPES.cursor_type;
   
   v_LEVEL1   NUMBER; 
   v_EMPLOYEE  VARCHAR2(30);
   v_EMP_ID   NUMBER;
   v_MGR_ID   NUMBER;
   
 BEGIN
   GetEmpRS (i_LEVEL1    => 2,
             p_recordset => v_cursor);
             
   LOOP 
     FETCH v_cursor
     INTO  v_LEVEL1, v_EMPLOYEE, v_EMP_ID, v_MGR_ID;
     EXIT WHEN v_cursor%NOTFOUND;
     DBMS_OUTPUT.PUT_LINE(v_LEVEL1 || ' | ' || v_EMPLOYEE || ' | ' || v_EMP_ID || ' | ' || v_MGR_ID);
   END LOOP;
   CLOSE v_cursor;
 END;
 /


---------------------------------------------------------------------

 -- query which gives, difference between two dates 
 SELECT FLOOR((((SYSDATE-MAX(DATA_READING_TIMESTAMP))*24*60*60) -
  FLOOR(((SYSDATE-MAX(DATA_READING_TIMESTAMP))*24*60*60)/3600)*3600)/60)minutes
FROM SENSOR_DATA;


---------------------------------------------------------------------


**************************************** Bind Variable E.g. **************************************** 

variable v_value number;
declare
	v_return varchar2(30);
begin
	:v_value:=1111;
	select ename into v_return from emp where empno=:v_value;
	dbms_output.put_line(v_return);
end;
/

set serveroutput on

variable v_username varchar2(4000);

exec :v_username := '&1';

declare 
   v_User_Name   VARCHAR2(4000);
   v_cntFlag     NUMBER;
   v_grantsSQL   VARCHAR2(100);
begin 
  begin 
    select username into v_User_Name from all_users where username= upper(''||:v_username||''); 
    v_cntFlag:=0;
  exception
    when no_data_found then
	  v_cntFlag:=1;
  end;
   
  if v_cntFlag = 1 then
     execute immediate 'create user &1 identified by &1._dev default tablespace users temporary tablespace temp';
    
     v_grantsSQL:='GRANT CONNECT, RESOURCE TO &1';
     execute immediate v_grantsSQL;
     
	 dbms_output.put_line('------------------------------------');
	 dbms_output.put_line('Schema Name '||:v_username||' was not found and so it was created');
	 dbms_output.put_line('------------------------------------'); 	
  else
     dbms_output.put_line('------------------------------------');
     dbms_output.put_line('Schema Name '||:v_username||' found');
     dbms_output.put_line('------------------------------------');   
  end if;
end;
/
exit

**************************************** Bind Variable E.g. **************************************** 


--- storing milliseconds in oracle table

CREATE OR REPLACE JAVA SOURCE
NAMED "MyTimestamp"
AS
import java.lang.string;
import java.sql.timestamp;

PUBLIC CLASS MyTimestamp
{  PUBLIC static String getTimestamp()
   {
	RETURN (NEW TIMESTAMP(SYSTEM.currentTimeMillis())).toString();
   }
};
/

CREATE OR REPLACE FUNCTION my_timestamp RETURN VARCHAR2
AS LANGUAGE JAVA
NAME 'MyTimestamp.getTimestamp() return java.lang.String';
/

To use:
SELECT my_timestamp FROM DUAL ;

MY_TIMESTAMP
-----------------------
2002-04-18 16:54:38.688 
 
 
 -------------------------------------------------------------------------------


 ****************************************  Parent Child Seraching Function  **************************************** 

 -- Parent Child Seraching Function
   CREATE OR REPLACE FUNCTION sy_RF 
   (
      p_parent IN varchar
   )
          RETURN VARCHAR
   IS
          v_parent   varchar(50);
          v_val      varchar(50);
   	     v_val1     varchar(50);
   	     
 		 CURSOR c1  IS SELECT tree_node 
 		   			   FROM pstreenode a
 				 	   WHERE a.parent_node_name = p_parent AND a.effdt ='31-DEC-2006';
   BEGIN
      FOR dept IN c1
      LOOP
        DBMS_OUTPUT.put_line (dept.tree_node);
        
 	   declare
 	     cursor c2 is SELECT tree_node 
 	     			  FROM pstreenode a 
 	     			  WHERE a.parent_node_name =dept.tree_node
 	  					AND A.EFFDT='31-DEC-2006';
   		BEGIN
 		  FOR dept1 IN c2
 		  LOOP
 			 DBMS_OUTPUT.put_line ('-----'||dept1.tree_node);
 			 V_VAL:=DEPT1.TREE_NODE;
 			
 			 SELECT parent_node_name into v_val 
 			 FROM pstreenode a
 			 WHERE tree_node=V_VAL 
 			   AND a.effdt ='31-DEC-2006';
 			   
 			IF v_val=' ' THEN
 			  return ('TRUE1');
 			else
 			  V_VAL1:= sy_rf(DEPT1.TREE_NODE);
 			end if;
      	 END LOOP;
        End;
     END LOOP;
      RETURN ('TRUE');
 end;
 /
****************************************  Parent Child Seraching Function  **************************************** 
 
 
****************************************  COUNT of ROWs  **************************************** 

 -- table_name and count of records as per tables
 -- to execute the query you need to connect specific schema
 SELECT
      table_name,
      TO_NUMBER(
        EXTRACTVALUE(
          XMLTYPE(DBMS_XMLGEN.GETXML('select count(*) c from '||owner||'.'||table_name))
          ,'/ROWSET/ROW/C')
          )
          COUNT
    FROM all_tables
    WHERE owner='SNOX4TRANSNOX_CPASS' 

-- table_name and count of records as per tables
-- you execute the query from DBA granted user
SELECT
  owner,
  table_name,
  TO_NUMBER(EXTRACTVALUE(XMLTYPE(DBMS_XMLGEN.GETXML('select count(*) c from '||owner||'.'||table_name)),'/ROWSET/ROW/C')) COUNT
FROM dba_TABLES 
where owner='SNOX4TRANSNOX'
ORDER BY 1;  


-- get the data count for column's data
SELECT dt.owner owner, dt.table_name table_name,'delete from '||dt.owner||'.'||dt.table_name||';'
  TO_NUMBER(EXTRACTVALUE(XMLTYPE(DBMS_XMLGEN.GETXML('select count(*) c from '||dt.owner||'.'||dt.table_name||' where '||dtc.column_name||'=566')),'/ROWSET/ROW/C')) data_cnt
FROM all_TABLES dt, all_Tab_Columns dtc
where dt.owner = dtc.owner
  and dt.table_name = dtc.table_name
  and dt.owner='TRANSMONERIS'
  AND dtc.COLUMN_NAME = 'AGENT_ID'
  and TO_NUMBER(EXTRACTVALUE(XMLTYPE(DBMS_XMLGEN.GETXML('select count(*) c from '||dt.owner||'.'||dt.table_name||' where '||dtc.column_name||'=566')),'/ROWSET/ROW/C')) <> 0
ORDER BY 3 desc 


SELECT ata.owner,
   ata.table_name,
   column_name,
   TO_NUMBER(
     EXTRACTVALUE(
       XMLTYPE(
         DBMS_XMLGEN.GETXML(
           'select count(*) c from ' ||ata.owner||'.'||ata.table_name ||
           ' where regexp_like(to_char(' || column_name || '),''*infonox.com'',''i'')'
         )
       ),
       'ROWSET/ROW/C'
     )
   ) cnt      
FROM all_tables ata, all_tab_columns utc
WHERE ata.table_name = utc.table_name AND ata.owner = utc.owner
  AND ata.owner='SNOX4TRANSNOX_CPASS'
  AND data_type ='VARCHAR2'           
ORDER BY 4 DESC    



set serveroutput on
declare 
	--- count of the matched vales
	v_match_found	number;
	
	-- enter the schema name here
	v_schema_name varchar2(30):='TRANSTSYSPAYMENTGW';
	
	-- enter the search values here
	v_search_string varchar2(100):='*merchant*';
	
BEGIN
	FOR i IN (SELECT TABLE_NAME, COLUMN_NAME 
			  FROM DBA_TABLES 
			  WHERE OWNER=v_schema_name 
			    AND DATA_TYPE IN ('CHAR','VARCHAR2','CLOB'))
	LOOP
		execute immediate 'select count(*) from '||i.table_name||' where regexp_like('||i.column_name||','':1'',''i'')')
		into v_match_found
		using v_search_string;
		
		IF v_match_found > 0 THEN
		  dbms_output.put_line( t.table_name ||', '||t.column_name||', '||v_match_found );
		END IF;
		
	END LOOP;	
EXCEPTION
  WHEN OTHERS THEN
END;
/

****************************************  COUNT of ROWs  **************************************** 
 
 
 
****************************************  Multiple Columns in Single Row  **************************************** 

-- we can put mutiple columns in one single row
--- level is difine 3 so i have taken three columns, you can increase the level
--- and soo increase the column names and put them in first select 
SELECT DECODE(r, 1, TABLE_NAME, 2, OWNER, 3, SRC_TAB_ROW) col FROM 
 (SELECT TABLE_NAME, OWNER, SRC_TAB_ROW, ROWNUM rnum FROM REPL_TAB_SYNC) t,
 (SELECT LEVEL r FROM dual CONNECT BY LEVEL <=3)
 ORDER BY t.rnum, col

****************************************  Multiple Columns in Single Row  **************************************** 
 
 
****************************************  How Fast Tables is getting imported  ****************************************

---- Can one monitor how fast a table is imported?
 select substr(sql_text,instr(sql_text,'INTO "'),30) table_name,
         rows_processed,
         round((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60,1) minutes,
         trunc(rows_processed/((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60)) rows_per_min
  from   sys.v_$sqlarea
  where  sql_text like 'INSERT %INTO "%'
    and  command_type = 2
    and  open_versions > 0;
 
 ****************************************  How Fast Tables is getting imported  ****************************************

 
 ****************************************  Who is Locking what?  ****************************************
 --- who is locking what?
SELECT 
  oracle_username, os_user_name, locked_mode,
  object_name,object_type
FROM v$locked_object a,DBA_OBJECTS b
WHERE a.object_id = b.object_id    
 
SELECT Oracle_Username Username, owner Object_Owner, Object_Name, Object_Type, s.osuser, s.SID SID,
		s.SERIAL# SERIAL,DECODE(l.BLOCK, 0, 'Not Blocking', 1, 'Blocking', 2, 'Global') STATUS,
		DECODE(v.locked_mode, 0, 'None', 1, 'Null', 2, 'Row-S (SS)', 3, 'Row-X (SX)', 4, 'Share', 5, 'S/Row-X (SSX)', 6, 'Exclusive', TO_CHAR(lmode) ) MODE_HELD
FROM gv$locked_object v, dba_objects d, gv$lock l, gv$session s
WHERE v.object_id = d.object_id
  AND (v.object_id = l.id1)
  AND v.session_id = s.SID
ORDER BY oracle_username, session_id;

--Show which row is locked
select	do.object_name
,	row_wait_obj#
,	row_wait_file#
,	row_wait_block#
,	row_wait_row#
,	dbms_rowid.rowid_create (1, ROW_WAIT_OBJ#, ROW_WAIT_FILE#, 
				ROW_WAIT_BLOCK#, ROW_WAIT_ROW#)
from	v$session s
,	dba_objects do
where	sid=&sid
and 	s.ROW_WAIT_OBJ# = do.OBJECT_ID
/


- view all currently locked objects:
 
SELECT username U_NAME, owner OBJ_OWNER,
object_name, object_type, s.osuser,
DECODE(l.block,
  0, 'Not Blocking',
  1, 'Blocking',
  2, 'Global') STATUS,
  DECODE(v.locked_mode,
    0, 'None',
    1, 'Null',
    2, 'Row-S (SS)',
    3, 'Row-X (SX)',
    4, 'Share',
    5, 'S/Row-X (SSX)',
    6, 'Exclusive', TO_CHAR(lmode)
  ) MODE_HELD
FROM gv$locked_object v, dba_objects d,
gv$lock l, gv$session s
WHERE v.object_id = d.object_id
AND (v.object_id = l.id1)
AND v.session_id = s.sid
ORDER BY username, session_id;
 
 
-- list current locks
 
SELECT session_id,lock_type, 
	mode_held, 
	mode_requested, 
	blocking_others, 
	lock_id1
FROM dba_lock l
WHERE lock_type 
NOT IN ('Media Recovery', 'Redo Thread');
 
 
-- list objects that have been 
-- locked for 60 seconds or more: 
 
SELECT SUBSTR(TO_CHAR(w.session_id),1,5) WSID, p1.spid WPID,
	SUBSTR(s1.username,1,12) "WAITING User",
	SUBSTR(s1.osuser,1,8) "OS User",
	SUBSTR(s1.program,1,20) "WAITING Program",
	s1.client_info "WAITING Client",
	SUBSTR(TO_CHAR(h.session_id),1,5) HSID, p2.spid HPID,
	SUBSTR(s2.username,1,12) "HOLDING User",
	SUBSTR(s2.osuser,1,8) "OS User",
	SUBSTR(s2.program,1,20) "HOLDING Program",
	s2.client_info "HOLDING Client",
	o.object_name "HOLDING Object"
FROM gv$process p1, gv$process p2, gv$session s1, gv$session s2, dba_locks w, dba_locks h, dba_objects o
WHERE w.last_convert > 60
	AND h.mode_held != 'None'
	AND h.mode_held != 'Null'
	AND w.mode_requested != 'None'
	AND s1.row_wait_obj# = o.object_id
	AND w.lock_type(+) = h.lock_type
	AND w.lock_id1(+) = h.lock_id1
	AND w.lock_id2 (+) = h.lock_id2
	AND w.session_id = s1.sid (+)
	AND h.session_id = s2.sid (+)
	AND s1.paddr = p1.addr (+)
	AND s2.paddr = p2.addr (+)
ORDER BY w.last_convert DESC;
 
 
-- alternate example: 
SELECT s.username, s.sid, s.serial#, s.osuser, k.ctime, o.object_name
object, k.kaddr, DECODE(l.locked_mode,
									  1, 'No Lock',
									  2, 'Row Share',
									  3, 'Row Exclusive',
									  4, 'Shared Table',
									  5, 'Shared Row Exclusive',
									  6, 'Exclusive') locked_mode,
  DECODE(k.TYPE,
			  'BL','Buffer Cache Management (PCM lock)',
			  'CF','Controlfile Transaction',
			  'CI','Cross Instance Call',
			  'CU','Bind Enqueue',
			  'DF','Data File',
			  'DL','Direct Loader',
			  'DM','Database Mount',
			  'DR','Distributed Recovery',
			  'DX','Distributed Transaction',
			  'FS','File Set',
			  'IN','Instance Number',
			  'IR','Instance Recovery',
			  'IS','Instance State',
			  'IV','Library Cache Invalidation',
			  'JQ','Job Queue',
			  'KK','Redo Log Kick',
			  'LA','Library Cache Lock',
			  'LB','Library Cache Lock',
			  'LC','Library Cache Lock',
			  'LD','Library Cache Lock',
			  'LE','Library Cache Lock',
			  'LF','Library Cache Lock',
			  'LG','Library Cache Lock',
			  'LH','Library Cache Lock',
			  'LI','Library Cache Lock',
			  'LJ','Library Cache Lock',
			  'LK','Library Cache Lock',
			  'LL','Library Cache Lock',
			  'LM','Library Cache Lock',
			  'LN','Library Cache Lock',
			  'LO','Library Cache Lock',
			  'LP','Library Cache Lock',
			  'MM','Mount Definition',
			  'MR','Media Recovery',
			  'NA','Library Cache Pin',
			  'NB','Library Cache Pin',
			  'NC','Library Cache Pin',
			  'ND','Library Cache Pin',
			  'NE','Library Cache Pin',
			  'NF','Library Cache Pin',
			  'NG','Library Cache Pin',
			  'NH','Library Cache Pin',
			  'NI','Library Cache Pin',
			  'NJ','Library Cache Pin',
			  'NK','Library Cache Pin',
			  'NL','Library Cache Pin',
			  'NM','Library Cache Pin',
			  'NN','Library Cache Pin',
			  'NO','Library Cache Pin',
			  'NP','Library Cache Pin',
			  'NQ','Library Cache Pin',
			  'NR','Library Cache Pin',
			  'NS','Library Cache Pin',
			  'NT','Library Cache Pin',
			  'NU','Library Cache Pin',
			  'NV','Library Cache Pin',
			  'NW','Library Cache Pin',
			  'NX','Library Cache Pin',
			  'NY','Library Cache Pin',
			  'NZ','Library Cache Pin',
			  'PF','Password File',
			  'PI','Parallel Slaves',
			  'PR','Process Startup',
			  'PS','Parallel Slave Synchronization',
			  'QA','Row Cache Lock',
			  'QB','Row Cache Lock',
			  'QC','Row Cache Lock',
			  'QD','Row Cache Lock',
			  'QE','Row Cache Lock',
			  'QF','Row Cache Lock',
			  'QG','Row Cache Lock',
			  'QH','Row Cache Lock',
			  'QI','Row Cache Lock',
			  'QJ','Row Cache Lock',
			  'QK','Row Cache Lock',
			  'QL','Row Cache Lock',
			  'QM','Row Cache Lock',
			  'QN','Row Cache Lock',
			  'QO','Row Cache Lock',
			  'QP','Row Cache Lock',
			  'QQ','Row Cache Lock',
			  'QR','Row Cache Lock',
			  'QS','Row Cache Lock',
			  'QT','Row Cache Lock',
			  'QU','Row Cache Lock',
			  'QV','Row Cache Lock',
			  'QW','Row Cache Lock',
			  'QX','Row Cache Lock',
			  'QY','Row Cache Lock',
			  'QZ','Row Cache Lock',
			  'RT','Redo Thread',
			  'SC','System Commit number',
			  'SM','SMON synchronization',
			  'SN','Sequence Number',
			  'SQ','Sequence Enqueue',
			  'SR','Synchronous Replication',
			  'SS','Sort Segment',
			  'ST','Space Management Transaction',
			  'SV','Sequence Number Value',
			  'TA','Transaction Recovery',
			  'TM','DML Enqueue',
			  'TS','Table Space (or Temporary Segment)',
			  'TT','Temporary Table',
			  'TX','Transaction',
			  'UL','User-defined Locks',
			  'UN','User Name',
			  'US','Undo segment Serialization',
			  'WL','Writing redo Log',
			  'XA','Instance Attribute Lock',
			  'XI','Instance Registration Lock') TYPE
FROM gv$session s, sys.gv$lock c, sys.gv$locked_object l,
     dba_objects o, sys.gv$lock k, gv$lock v
WHERE o.object_id = l.object_id
	AND l.session_id = s.sid
	AND k.sid = s.sid
	AND s.saddr = c.saddr
	AND k.kaddr = c.kaddr
	AND k.kaddr = v.kaddr
	AND v.saddr = s.saddr
	AND k.lmode = l.locked_mode
	AND k.lmode = c.lmode
	AND k.request = c.request
ORDER BY object;
****************************************  Who is Locking what?  ****************************************

------------------------------------------------------------------------------
------------------------------------------------------------------------------
-- get the list of synonyms those have not got any privilege
SELECT SYNONYM_NAME,TABLE_OWNER,TABLE_NAME 
FROM USER_SYNONYMS A
WHERE NOT EXISTS (SELECT 'X' FROM USER_TAB_PRIVS_RECD B 
                  WHERE A.TABLE_OWNER=B.OWNER
						AND A.TABLE_NAME=B.TABLE_NAME)
ORDER BY 2,3 

------------------------------------------------------------------------------
------------------------------------------------------------------------------
-- counting all objects simple cursor

SELECT 
(CURSOR(
SELECT DECODE(GROUPING(a.owner), 1, 'All Owners',
a.owner) AS "Owner",
COUNT(CASE WHEN a.object_type = 'TABLE' THEN 1 ELSE NULL END) "TABLES",
COUNT(CASE WHEN a.object_type = 'INDEX' THEN 1 ELSE NULL END) "INDEXES",
COUNT(CASE WHEN a.object_type = 'PACKAGE' THEN 1 ELSE NULL END) "PACKAGES",
COUNT(CASE WHEN a.object_type = 'SEQUENCE' THEN 1 ELSE NULL END) "Sequences",
COUNT(CASE WHEN a.object_type = 'TRIGGER' THEN 1 ELSE NULL END) "TRIGGERS",
COUNT(CASE WHEN a.object_type NOT IN
('PACKAGE','TABLE','INDEX','SEQUENCE','TRIGGER') THEN 1 ELSE NULL END) "Other",
COUNT(CASE WHEN 1 = 1 THEN 1 ELSE NULL END) "Total"
FROM DBA_OBJECTS a
GROUP BY ROLLUP(a.owner))) Double_Click_Here
FROM dual;

       
SELECT DECODE(GROUPING(A.owner), 1, 'Total Objects of All Owners',A.owner) AS "Owner",
    COUNT(CASE WHEN A.object_type = 'TABLE' THEN 1 ELSE NULL END) "Tables",
       COUNT(CASE WHEN A.object_type = 'INDEX' THEN 1 ELSE NULL END) "Indexes",
       COUNT(CASE WHEN A.object_type = 'PACKAGE' THEN 1 ELSE NULL END) "Packages",
       COUNT(CASE WHEN A.object_type = 'SEQUENCE' THEN 1 ELSE NULL END) "Sequences",
       COUNT(CASE WHEN A.object_type = 'TRIGGER' THEN 1 ELSE NULL END) "Triggers",
       COUNT(CASE WHEN A.object_type NOT IN ('PACKAGE','TABLE','INDEX','SEQUENCE','TRIGGER') THEN 1 ELSE NULL END) "Other",
       COUNT(CASE WHEN 1 = 1 THEN 1 ELSE NULL END) "Total"
FROM DBA_OBJECTS A
WHERE owner IN ('TRANSNOX_CPASS','SNOX4TRANSNOX_CPASS')
GROUP BY ROLLUP(A.owner)

 ------------------------------------------------------------------------------
 ------------------------------------------------------------------------------
---successful CCCA transactions 
select c.transactiondate, c.amount/100 "Dollar Amount", c.SERVICECHARGE/100 "Fee", c.CHECKNO "GCA Check No",
      a.casinocode, b.casinoname, a.MACHINEID "WorkStation Code", a.DESCRIPTION 
from qcp.machines a, qcp.casinos b, qcp.transactions c
where a.casinocode = b.casinocode 
  and b.casinocode = c.casinocode
  and c.transaction_status in ('ATC','AUT','PTC','PTS')
  and trunc(c.transactiondate) between to_date('02/24/2007','mm/dd/yyyy') and to_date('01/09/2008','mm/dd/yyyy')
  

 ------------------------------------------------------------------------------
 ------------------------------------------------------------------------------
-- spid of schema
SELECT p.spid, s.username, s.program 
FROM v$process p, v$session s 
WHERE p.addr=s.paddr 
ORDER BY 2, 3, 1 
  

 ------------------------------------------------------------------------------
 ------------------------------------------------------------------------------
--TOP N query
SELECT * FROM  
( SELECT * 
  FROM chkc_transactions 
  ORDER BY TIMESTAMP DESC ) 
 WHERE ROWNUM <= 10;

 
 ------------------------------------------------------------------------------
 ------------------------------------------------------------------------------
 -- SQL to compare rows within two tables
(select * from A  
 minus 
 select * from B) -- Rows in A that are not in B
union all 
(  
 select * from B  
 minus 
 select * from A
) -- rows in B that are not in A


 
****************************************  StringTonkenizer  ****************************************

-- Stringtokenizer procedure 
CREATE OR REPLACE PROCEDURE Stringtokenizer
(
	p_InputString					VARCHAR2,
	p_Seperator						CHAR,
	p_ElementNumber					NUMBER,
	p_OutputString			IN OUT	VARCHAR2
)
AS
	v_InputString					VARCHAR2(4000);
	v_Seperator						CHAR;
	v_SeperatorPosition				NUMBER;
	v_NextSeperator					NUMBER;
BEGIN
	v_InputString := p_InputString;
	v_Seperator   := p_Seperator;
	
	IF SUBSTR(v_InputString, 1, 1) <> v_Seperator THEN
		v_InputString := v_Seperator || v_InputString;
	END IF;
	IF SUBSTR(v_InputString, LENGTH(v_InputString)) <> v_Seperator THEN
		v_InputString := v_InputString || v_Seperator;
	END IF;
	v_SeperatorPosition := INSTR(v_InputString, v_Seperator, 1, p_ElementNumber) + 1;
	v_NextSeperator := INSTR(v_InputString, v_Seperator, v_SeperatorPosition);
	IF v_NextSeperator = 0 /*INSTR(v_InputString, 1, v_NextSeperator) = 0 */ THEN
		p_OutputString := NULL;
	ELSE
		p_OutputString := SUBSTR(v_InputString, v_SeperatorPosition, (v_NextSeperator - v_SeperatorPosition));
	END IF;

END;
/


-- Stringtokenizer for cuting strings
DECLARE

	v_Saperator				   	 VARCHAR2(1):='~';
	v_Element				   	 NUMBER;
	v_Image_Type_Str			 VARCHAR2(4000);
	
BEGIN	
   v_Element:=1;
   Stringtokenizer(i_DML_String, v_Saperator, v_Element, v_Image_Type_Str);
   WHILE v_Image_Type_Str IS NOT NULL
   LOOP
	
 	 ---- Your code here for tokenized string.

   	   v_Element:= v_Element + 1;
   	   Stringtokenizer(i_Image_Type, v_Saperator, v_Element, v_Image_Type_Str);
   END LOOP;
END;


 -- script for stringtokenizer to cut vales TOKENIZE_DML function has been used

  v_ErrorFlag:=3;
  v_main_str:=trim(TOKENIZE_DML(v_Sql_String));

  Stringtokenizer( v_main_str, ',', v_Element_Ins, v_ins_string);
  WHILE v_ins_string IS NOT NULL
  LOOP
		v_ErrorFlag:=4;
		v_Temp:=1;
		Stringtokenizer(v_ins_string, '|', v_Temp, v_ColName);
		Stringtokenizer(v_ins_string, '|', v_Temp+1, v_ColVal);

		v_ErrorFlag:=5;
		IF v_ColName = 'RATE_CODE' THEN
		   v_strRate_Code := v_ColVal;
		ELSIF v_ColName = 'BIN' THEN
		   v_strBin:= TO_NUMBER(v_ColVal) * 100;
		ELSIF v_ColName = 'FIXED_FEE' THEN
		   v_strFixed_Fee:= TO_NUMBER(v_ColVal) * 100;
		ELSIF v_ColName = 'PERCENT_FEEE' THEN
		   v_strPercent_Fee:= TO_NUMBER(v_ColVal);
		ELSIF v_ColName = 'MINIMUM_FEE' THEN
		   v_strMinimum_Fee:= TO_NUMBER(v_ColVal) * 100;
		END IF;

		IF UPPER(i_UpdateType)='INSERT' THEN 
			v_ErrorFlag:=6;
			INSERT INTO FEE_RATE_DETAIL(RATE_CODE, BIN, FIXED_FEE, PERCENT_FEE, MINIMUM_FEE)
			 VALUES(v_strRate_Code, v_strBin,  v_strFixed_Fee,  v_strPercent_Fee,  v_strMinimum_Fee);

		ELSIF UPPER(i_UpdateType)='UPDATE' THEN 
			v_ErrorFlag:=7;
			UPDATE FEE_RATE_DETAIL
			SET 
			  FIXED_FEE   = v_strFixed_Fee,
			  PERCENT_FEE = v_strPercent_Fee,
			  MINIMUM_FEE = v_strMinimum_Fee
			WHERE RATE_CODE = v_strRate_Code
			   AND BIN = v_strBin;

		END IF;

	v_Element_Ins:= v_Element_Ins + 1;
	Stringtokenizer( v_main_str, ',', v_Element_Ins, v_Primary_keys);
  END LOOP;
****************************************  StringTonkenizer  ****************************************

 
****************************************  Insert/Update in CLOB/BLOB  ****************************************
-- Inserting and updating in clob and blob data types  
CREATE OR REPLACE PROCEDURE Example_1a IS
 dest_lob IN OUT BLOB;
 src_lob IN OUT   BLOB; 
BEGIN
  -- get the LOB locators
  -- note that the FOR UPDATE clause locks the row
  SELECT b_lob INTO dest_lob
  FROM lob_table
  WHERE key_value = 12 
  FOR UPDATE;

  SELECT b_lob INTO src_lob
  FROM lob_table
  WHERE key_value = 21;

  dbms_lob.append(dest_lob, src_lob);
  COMMIT;
END;
****************************************  Insert/Update in CLOB/BLOB  ****************************************


**************************************** Database Trigger  ****************************************
-- trigger which block some users to create any ddl on any schema's

CREATE OR REPLACE TRIGGER DATABASE_DDL_TRIG 
before DDL on Database
DECLARE 
    v_Os_User        varchar2(30);
    v_Program        varchar2(500);
BEGIN 

    select SYS_CONTEXT('USERENV', 'OS_USER')OS_USER, UPPER(sys_context('USERENV', 'MODULE'))
    into v_Os_User, v_Program
    from dual;
    
    if upper(v_Os_User) in ('ASHWIN', 'TARANNUM', 'SANDEEP', 'NITIN', 'SAURABH','ANUPAM', 'NIRAV', 'DEVESH', 
                            'DHARMESH', 'VAIBHAV', 'UDAY', 'AMOL', 'ATUL', 'SHAILESH', 'MILINDT', 'PARESH', 
                            'PHILIP', 'DISHANT', 'GANESH', 'SAUMYA', 'RUSHIKESH', 'RANJAN', 'MANOJ', 
                            'AMIT', 'RAJANI', 'SANJIT', 'MILINDD', 'KARAN', 'DEBARGHA', 'MAHESH') 
            and (v_Program in ('SQL*PLUS','DREAMCODER','DBSAINT.EXE','SQL DEVELOPER') 
                    OR v_Program like 'TOAD%') then
         RAISE_APPLICATION_ERROR (-20905, 'Please do not execute any DDL commands '||UPPER(v_Os_User)||' , PLEASE CONTACT YOUR DBA');
    end if;
END;
/



-- Block developers from using TOAD and other tools on production databases.

CONNECT / AS SYSDBA;
 
CREATE OR REPLACE TRIGGER block_tools_from_prod
  AFTER LOGON ON DATABASE
DECLARE
  v_prog sys.v_$session.program%TYPE;
BEGIN
  SELECT program INTO v_prog 
    FROM sys.v_$session
  WHERE  audsid = USERENV('SESSIONID')
    AND  audsid != 0  -- Don't Check SYS Connections
    AND  ROWNUM = 1;  -- Parallel processes will have the same AUDSID's
 
  IF UPPER(v_prog) LIKE '%TOAD%' OR UPPER(v_prog) LIKE '%T.O.A.D%' OR -- Toad
     UPPER(v_prog) LIKE '%SQLNAV%' OR   -- SQL Navigator
     UPPER(v_prog) LIKE '%PLSQLDEV%' OR -- PLSQL Developer
     UPPER(v_prog) LIKE '%BUSOBJ%' OR   -- Business Objects
     UPPER(v_prog) LIKE '%EXCEL%'       -- MS-Excel plug-in
  THEN
     RAISE_APPLICATION_ERROR(-20000, 'Development tools are not allowed here.');
  END IF;
END;
/
SHOW ERRORS


SELECT SCHEMANAME, OSUSER, MACHINE, MODULE, PROGRAM, SERVICE_NAME
FROM V$SESSION
WHERE TYPE <>'BACKGROUND'
  AND REGEXP_LIKE(schemaname,'transit*|qcp|*transnox*','i') 
  AND  REGEXP_LIKE(module,'sql.dev*|toad*|sql*','i')

****************************************  Database Trigger  ****************************************



****************************************  Eliminate Duplicates ****************************************

how does one eliminate duplicates rows from a table?

-- deleting duplicate records.
delete  sushil a WHERE rowid < (SELECT max(rowid) FROM sushil 
								WHERE name=a.name 
								GROUP BY name HAVING count (*)>1)

Choose one of the following queries to identify or remove duplicate rows from 
a table leaving only unique records in the table:
Method 1: 

     DELETE FROM table_name A WHERE ROWID > (
     SELECT min(rowid) FROM table_name B
     WHERE A.key_values = B.key_values);

Method 2: 
    create table table_name2 as select distinct * from table_name1;
    drop table_name1;
    rename table_name2 to table_name1;
    -- Remember to recreate all indexes, constraints, triggers, etc on table... 

Method 3: (thanks to Dennis Gurnick) 
    delete from my_table t1
    where  exists (select 'x' from my_table t2
                    where t2.key_value1 = t1.key_value1
                      and t2.key_value2 = t1.key_value2
                      and t2.rowid      > t1.rowid);

Note 1: One can eliminate N^2 unnecessary operations by creating an index on the 
        joined fields in the inner loop (no need to loop through the entire table on each 
        pass by a record). This will speed-up the deletion process. 
        
Note 2: If you are comparing NOT-NULL columns, use the NVL function. Remember that 
        NULL is not equal to NULL. This should not be a problem as all key columns should be 
        NOT NULL by definition. 


SELECT TASK_ID, DEVICE_ID FROM TRANSACTION
GROUP BY TASK_ID, DEVICE_ID
HAVING COUNT(*) > 1


-- delete 
SELECT * FROM columnlayout
WHERE ROWID IN (
      SELECT "ROWID"
      FROM (
            SELECT RANK() OVER(PARTITION BY USERNAME ORDER BY ROWID) RANK_N, ROWID AS "ROWID"
            FROM columnlayout
            WHERE USERNAME IN (
                  SELECT USERNAME FROM columnlayout
                  GROUP BY USERNAME
                  HAVING COUNT(*) > 1
            )
      )
      WHERE RANK_N > 1
);
****************************************  Eliminate Duplicates ****************************************






****************************************  REF CURSOR ****************************************

--- CURSOR examples
CURSOR cur_Payee IS SELECT * FROM PAYEE;

 	OPEN cur_Payee;
	  LOOP
	   FETCH cur_Payee INTO v_Payee_Rec;
	   EXIT WHEN cur_Payee%NOTFOUND;
				  v_ErrorFlag:=1;
			   -- Your Code here 
	  END LOOP;
    CLOSE cur_Payee ;


--- Ref CURSOR examples
TYPE Ref_Cursor_Type IS REF CURSOR ;
v_Ref_Cursor	Ref_Cursor_Type;

v_SQL_Str		VARCHAR2(4000);

BEGIN

   v_SQL_Str := 'SELECT EMPNO, ENAME, JOB, MGR from emp WHERE Empno = '||i_Empno;

   OPEN v_Ref_Cursor FOR v_SQL_Str;
	LOOP
	  FETCH v_Ref_Cursor INTO v_ENAME, v_JOB, v_MGR;
		EXIT WHEN v_Ref_Cursor%NOTFOUND;
		
		  --- Your Code here
		  
   END LOOP;
       
END;


--- Declaring TYPES
TYPE    TmpCurTyp IS REF CURSOR RETURN employees%ROWTYPE;
tmp_cv  TmpCurTyp; -- declare cursor variable

DECLARE
  TYPE EmpRecTyp IS RECORD (
                            employee_id     NUMBER,
							last_name 		VARCHAR2(25),
							salary 			NUMBER(8,2)
							);
TYPE EmpCurTyp IS REF CURSOR RETURN EmpRecTyp;
emp_cv EmpCurTyp; -- declare cursor variable
---------------------------------------------------------------


          TYPE Ref_Cur_Type IS REF CURSOR;
	      ref Ref_Cur_Type;

    OPEN ref FOR v_HeadDateQuery(run time select query);
       LOOP
		FETCH HeadDateQuery_Cur INTO  v_Timestamp,v_TotalBalance, v_description;
		EXIT WHEN ref%NOTFOUND;


--------------------------------------------------------------

OPEN HeadDateQuery_Cur FOR v_HeadDateQuery;
	LOOP
		FETCH HeadDateQuery_Cur INTO
		v_Binnumber,
		v_Denomination,
		v_Current_Balance_Amount,
		v_Current_Dispensed_Amount,
		v_Current_Retained_Amount,
		v_Config_Id;

		EXIT WHEN HeadDateQuery_Cur%NOTFOUND;
		v_InsertQuery :=    ' INSERT INTO ' || v_TempTable || '( '||
									' Sr_Nr,'||
									' Description,'||
									' Value '||
									' ) '||
									' VALUES ( :1,:2,:3)';

		EXECUTE IMMEDIATE v_InsertQuery	USING
		v_SerialNo,
		'Config ID For Bin '||v_Binnumber ,
		v_Config_Id;
		v_SerialNo := v_SerialNo +1;

	END LOOP;
	CLOSE HeadDateQuery_Cur;
	v_SerialNo := v_SerialNo +1;


-----------------------------------------------------------------------------------------
TYPE    TmpCurTyp IS REF CURSOR RETURN employees%ROWTYPE;
tmp_cv  TmpCurTyp; -- declare cursor variable

DECLARE
  TYPE EmpRecTyp IS RECORD (
                           employee_id NUMBER,
							last_name VARCHAR2(25),
							salary NUMBER(8,2)
							);
TYPE   EmpCurTyp IS REF CURSOR RETURN EmpRecTyp;
emp_cv EmpCurTyp; -- declare cursor variable

-----------------------------------------------------------------------------------------

DECLARE
CURSOR c1 IS SELECT last_name FROM employees ORDER BY last_name;
	name1 employees.last_name%TYPE;
	name2 employees.last_name%TYPE;
	name3 employees.last_name%TYPE;
BEGIN
OPEN c1;
	FETCH c1 INTO name1; -- this fetches first row
	FETCH c1 INTO name2; -- this fetches second row
	FETCH c1 INTO name3; -- this fetches third row
CLOSE c1;
END;

-------------------------------------------------------------------------------------------

BEGIN
FOR item IN
( SELECT last_name, job_id FROM employees WHERE job_id LIKE '%CLERK%'
AND manager_id > 120 )
LOOP
DBMS_OUTPUT.PUT_LINE('Name = ' || item.last_name || ', Job = ' ||
item.job_id);
END LOOP;
END;
/


---------------------------------------------------------------------------------------------

DECLARE
	   CURSOR c1 IS
	   		  SELECT t1.department_id, department_name, staff
			  FROM departments t1,
			  ( SELECT department_id, COUNT(*) AS staff
			    FROM employees GROUP BY department_id
			  ) t2
			  WHERE
			  t1.department_id = t2.department_id
			  AND staff >= 5;
BEGIN
	 FOR dept IN c1
	 	 LOOP
       DBMS_OUTPUT.PUT_LINE('Department = ' || dept.department_name || ', staff = ' || dept.staff);
		 END LOOP;
END;
/


-------------------------------------------------------------------------------------------------

DECLARE
	TYPE empcurtyp IS REF CURSOR RETURN employees%ROWTYPE;
	 emp empcurtyp;
-- after result set is built, process all the rows inside a single procedure
-- rather than calling a procedure for each row

	PROCEDURE process_emp_cv (emp_cv IN empcurtyp) IS
	person employees%ROWTYPE;
BEGIN
	DBMS_OUTPUT.PUT_LINE('-----');
	DBMS_OUTPUT.PUT_LINE('Here are the names from the result set:');
		
       LOOP
		FETCH emp_cv INTO person;
			EXIT WHEN emp_cv%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE('Name = ' || person.first_name ||' ' || person.last_name);
	END LOOP;
END;


BEGIN
-- First find 10 arbitrary employees.
OPEN emp FOR SELECT * FROM employees WHERE ROWNUM < 11;
process_emp_cv(emp);
CLOSE emp;
-- find employees matching a condition.
OPEN emp FOR SELECT * FROM employees WHERE last_name LIKE 'R%';
process_emp_cv(emp);
CLOSE emp;
END;



-------------------------------------------------------------------------------------------------


CREATE OR REPLACE PROCEDURE Cc_Assign_Csr_From_Queue
(
	i_Csr_Id		  IN		    VARCHAR2,
	
     o_OutputStatus 	  OUT 	    NUMBER,
	o_OutputMessage   OUT 	    VARCHAR2		  
)
AS 
	v_CSR_Queue	  	  	VARCHAR2(100);
	sqlStr				VARCHAR2(1000);
	v_ProductCode			VARCHAR2(50);
	v_ErrorFlag			NUMBER;
	
	CURSOR Csr_Weight(v_Curr_Task NUMBER)
	IS
		 SELECT
			Csr_Id
		 FROM
			CC_CSR CSR
		 WHERE
			CSR.Last_Poll_Time > SYSDATE-15/(24*60*60)
			AND	CSR.Max_Task > v_Curr_Task
		 ORDER BY
			CSR.Weight DESC;

	CURSOR csr_roundrobin (v_curr_task NUMBER, v_User_ID VARCHAR2,v_Product VARCHAR2)
	IS
		SELECT USER_ID FROM CC_CSR_TASK_cst.LAST_POLL_TIME > SYSDATE-15/(24*60*60));

	  V_ERROR_LOCATION   			   NUMBER;
BEGIN
	v_Csr_Id:=NULL;

	v_Current_Tasks:= Cc_Get_Csr_Task(i_Csr_Id);
	
	v_ErrorFlag := 1;
	
	sqlStr := 
	'SELECT	 	'||
		   'session_id,				'||
		   'task_id,				'||
		   'owner,					'||
		   'CSR_TASK_STATE, 		'||	
		   'TASK_SOURCE				'||		
	'FROM  						'||
		   'cc_csr_task tsk			'||
	'WHERE 						'||
		 'tsk.OWNER in (SELECT queue_id FROM cc_csr_queue WHERE csr_id = ''' || i_Csr_Id || ''')													'||
		 'AND tsk.TASK_SOURCE IN (SELECT CODE FROM PRODUCT_MASTER WHERE COMPANY_CODE IN' ||  i_Company || ')	'||
		 'AND rownum < 2		    '||
		 'AND CSR_TASK_STATE NOT IN (''END'',''ENDED'')' ||
	'ORDER BY tsk.START_TIME';
			

-------------
	
	EXECUTE IMMEDIATE sqlStr INTO v_session_id,v_task_id,v_Owner,v_Csr_task_state,v_ProductCode;
	 
		v_ErrorFlag := 2;
			
		IF UPPER(i_Algo) = 'BY_WEIGHTS' THEN
			BEGIN
				OPEN Csr_Weight(v_Current_Tasks);
				FETCH Csr_Weight INTO v_Csr_Id;
				IF Csr_Weight%ISOPEN THEN
					CLOSE Csr_Weight;
				END IF;
			END;
			v_ErrorFlag := 3;
			
		ELSIF UPPER(i_Algo) = 'ROUNDROBIN' THEN
			BEGIN
				OPEN Csr_RoundRobin(v_Current_Tasks,i_Csr_Id,v_ProductCode);
				FETCH Csr_Roundrobin INTO v_Csr_Id;
				IF csr_roundrobin%ISOPEN THEN
					CLOSE Csr_Roundrobin;
				END IF;
			END;
			v_ErrorFlag := 4;
			
		ELSIF UPPER(i_Algo) = 'RANDOM' THEN
			BEGIN
			    V_ERROR_LOCATION := 1;
		   		SELECT
		   		   Csr_Id
				INTO
				   v_Csr_Id
 	  		FROM
 	  		   CC_CSR CSR,
			   	   SNOX_USER_ACCESS su
	  		WHERE
	  		  csr.CSR_ID = su.USER_ID 
			      AND su.CALLNOX = 'G'
			      AND CSR.MAX_TASK > v_Current_Tasks 
				  AND Csr_Id = i_Csr_Id;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					 v_Csr_Id := NULL;			
			END;
		ELSE
		    v_ErrorFlag := 5;
			BEGIN
				SELECT
				   csr_id
				INTO
				   v_Csr_Id
				FROM
				   CC_CSR csr,
			   	   SNOX_USER_ACCESS su
				WHERE
	  		   csr.CSR_ID = su.USER_ID
			   	   AND su.CALLNOX = 'G' AND				
				   csr.MAX_TASK > v_Current_Tasks
				   AND csr_id = i_Csr_Id;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					 v_Csr_Id := NULL;				
			END;

			v_ErrorFlag := 6;
		END IF;
		
		v_ErrorFlag := 7;
		
    IF v_Csr_Id IS NOT NULL THEN
   	    BEGIN   		
	        Cc_Transfer_Csr
			  (
			  	 v_session_id,
				 v_Task_id,
				 i_Csr_Id,
				 v_Owner,
				 'Auto assigned task FROM queue to user',
				 o_OutputStatus,
				 o_OutputMessage
			  );
			  
			v_ErrorFlag := 8;
			  
			IF o_OutputStatus <> 0 THEN			
				RETURN;
			END IF;
			
			v_ErrorFlag := 9;
			
			UPDATE CC_CSR_TASK_ASSIGN_TS 
			SET LAST_ASSIGN_TIME = SYSDATE
			WHERE USER_ID = i_Csr_Id;
			
			v_ErrorFlag := 10;
			
			IF v_Owner= 'CSR_DE_QUEUE' AND v_Csr_task_state = 'END'	THEN
				UPDATE
				   CC_CSR_TASK
			   	SET
				   CSR_TASK_STATE = 'DATA_ENTRY'
			   	WHERE
			   	   session_id  = V_session_id
			   	   AND task_id = V_task_id ;
			END IF;
			
			o_OutputStatus	:= 0 ;
			--o_OutputMessage	:= 'SUCCESS';
			COMMIT;
   	  EXCEPTION
	   	    WHEN OTHERS THEN
			  		o_OutputStatus	:=	102;
			  		o_OutputMessage	:=	SUBSTR(SQLERRM,1,100);
	   END;
	 ELSE
			o_OutputStatus	:=	103;
			o_OutputMessage 	:= 'CSR Not elligible to own task.';			
		END IF;
		
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  		 o_OutputStatus := 104;
	  o_OutputMessage  := 'No Task to Assign';  			 

  WHEN OTHERS THEN
	  o_OutputStatus := 101 ;
	  o_OutputMessage  := 'Procedure Cc_Assign_Csr_From_Queue failed AT  ' || v_ErrorFlag || ':' || SUBSTR(SQLERRM,1,100);
END;
/

-------------------------------------------------------
Example 6-32 Fetching from a Cursor Variable into a Record

DECLARE
TYPE empcurtyp IS REF CURSOR RETURN employees%ROWTYPE;
   emp_cv empcurtyp;
   emp_rec employees%ROWTYPE;
BEGIN
	OPEN emp_cv FOR SELECT * FROM employees WHERE employee_id < 120;
		 LOOP
		 	 FETCH emp_cv INTO emp_rec; -- fetch from cursor variable
			 EXIT WHEN emp_cv%NOTFOUND; -- exit when last row is fetched
-- process data record
   		   DBMS_OUTPUT.PUT_LINE('Name = ' || emp_rec.first_name || ' ' ||emp_rec.last_name);
		 END LOOP;
	CLOSE emp_cv;
END;
/
-------------------------------------------------------
Example 6-33 Fetching from a Cursor Variable into Collections
DECLARE
	TYPE empcurtyp IS REF CURSOR;
	emp_cv empcurtyp;
	
	TYPE namelist IS TABLE OF employees.last_name%TYPE;
	names namelist;
	
	TYPE sallist IS TABLE OF employees.salary%TYPE;
	sals sallist;
BEGIN
	OPEN emp_cv FOR SELECT last_name, salary FROM employees WHERE job_id = 'SA_REP';
		 FETCH emp_cv BULK COLLECT INTO names, sals;
	CLOSE emp_cv;
-- loop through the names and sals collections
      FOR i IN names.FIRST .. names.LAST
	  	  LOOP
		   	  DBMS_OUTPUT.PUT_LINE('Name = ' || names(i) || ', salary = ' || sals(i));
		 END LOOP;
END;
/

****************************************  REF CURSOR ****************************************




****************************************  SQL SERVER ****************************************
 
 --- convert date time format mm-dd-yyyy hh:mi:ss
 select convert(VARCHAR(21),ActiveDate, 120) from Agencies
 
 --------------------------------------------------------------------------------
 
 -- counts all rows of all tables 
 SELECT [TableName] = so.name, [RowCount] = MAX(si.rows) 
 FROM  sysobjects so, sysindexes si 
 WHERE so.xtype = 'U' 
     AND si.id = OBJECT_ID(so.name) 
GROUP BY so.name 


---------------------------------------------------------------------------------
-- if you forgot the sa password for sql server,
-- execute the command in dos
osql -E -d  -Q "sp_password NULL, 'sa', 'sa'"

****************************************  SQL Server ****************************************





****************************************  SCHEDULED JOBS ****************************************

-- Scheduled Jobs 

/*
This part includes information about creating a Scheduled Job to run the export procedure periodically. As
Scheduled Jobs come with Oracle 10g, scripts in this article will work on databases later than Oracle 10.1.x.x

The sys package we will mainly use is DBMS_SCHEDULER. First we should create a job. You can find the following
command that i used to create a job. Alternate parameters are explained with comments.
*/


--The scheduler allows you to optionally create programs which hold metadata about a task, but no schedule information. A program may related 
--to a PL/SQL block, a stored procedure or an OS executable file. Programs are created using the CREATE_PROGRAM procedure:

-- Create the test programs.
BEGIN
  -- PL/SQL Block.
  DBMS_SCHEDULER.create_program (
	program_name   => 'test_plsql_block_prog',
	program_type   => 'PLSQL_BLOCK',
	program_action => 'BEGIN DBMS_STATS.gather_schema_stats(''SCOTT''); END;',
	enabled        => TRUE,
	comments       => 'Program to gather SCOTT''s statistics using a PL/SQL block.');

  -- Shell Script.
  DBMS_SCHEDULER.create_program (
	program_name        => 'test_executable_prog',
	program_type        => 'EXECUTABLE',
	program_action      => '/u01/app/oracle/dba/gather_scott_stats.sh',
	number_of_arguments => 0,
	enabled             => TRUE,
	comments            => 'Program to gather SCOTT''s statistics us a shell script.');

  -- Stored Procedure with Arguments.
  DBMS_SCHEDULER.create_program (
	program_name        => 'test_stored_procedure_prog',
	program_type        => 'STORED_PROCEDURE',
	program_action      => 'DBMS_STATS.gather_schema_stats',
	number_of_arguments => 1,
	enabled             => FALSE,
	comments            => 'Program to gather SCOTT''s statistics using a stored procedure.');

  DBMS_SCHEDULER.define_program_argument (
	program_name      => 'test_stored_procedure_prog',
	argument_name     => 'ownname',
	argument_position => 1,
	argument_type     => 'VARCHAR2',
	default_value     => 'SCOTT');

  DBMS_SCHEDULER.enable (name => 'test_stored_procedure_prog');
END;
/

-- Display the program details.
SELECT owner, program_name, enabled FROM dba_scheduler_programs;

--Programs can be deleted using the DROP_PROGRAM procedure:
BEGIN
  DBMS_SCHEDULER.drop_program (program_name => 'test_plsql_block_prog');
  DBMS_SCHEDULER.drop_program (program_name => 'test_stored_procedure_prog');
  DBMS_SCHEDULER.drop_program (program_name => 'test_executable_prog');
END;
/





BEGIN 
    DBMS_SCHEDULER.CREATE_JOB(
       job_name           =>  'log_to_table',
       job_type           =>  'STORED_PROCEDURE',   
                              -- Possible values could be:
                              -- PLSQL_BLOCK, 
                              -- STORED_PROCEDURE, 
                              -- EXECUTABLE, 
                              -- CHAIN.
       job_action         =>  'D_EPEKER.p_test_01', -- schemaname.procedure name to run
       start_date         =>  'to_date(''03/15/2009 22:00:00'',''mm/dd/yyyy hh24:mi:ss'')', -- date_to_start_execution date
       repeat_interval    =>  'FREQ=MONTHLY', -- every other day
                              
                              -- Possible values could be:
                              -- "FREQ = YEARLY" | "MONTHLY" | "WEEKLY" | 
                              -- "DAILY" | "HOURLY" | "MINUTELY" | "SECONDLY" 
                              -- INTERVAL = 1 through 99 
         
       end_date           =>  'sysdate+1',     -- date_to_end_execution
       job_class          =>  'logging_class',  
       enabled       	  => TRUE, -- it can flase to not start the job 
       comments           =>  'job_logs_something');-- explanation of the job
END;

/*

Jobs are created disabled by default and need to be enabled to run. You can find the following procedure to alter a
Scheduled Jobs attribute. By default a scheduled job drops itself after its execution ends. You should set
"auto_drop" attribute to FALSE to hold the Scheduled Job after its execution ends.

*/
-- 
-- enabling a job 
-- 
BEGIN
  SYS.DBMS_SCHEDULER.ENABLE 
    (name => 'D_EPEKER.LOG_TO_TABLE');
END;
/


--Jobs can be deleted using the DROP_JOB procedure:

BEGIN
  DBMS_SCHEDULER.drop_job (job_name => 'test_full_job_definition');
  DBMS_SCHEDULER.drop_job (job_name => 'test_prog_sched_job_definition');
  DBMS_SCHEDULER.drop_job (job_name => 'test_prog_job_definition');
  DBMS_SCHEDULER.drop_job (job_name => 'test_sched_job_definition');
END;
/


-- 
-- altering a job attribute
-- 
BEGIN
    DBMS_SCHEDULER.SET_ATTRIBUTE(
        name => 'log_to_table',  -- name of the job
        attribute => 'auto_drop',  -- attribute name
        value => FALSE  -- new value of the attribute
        );
END;

/*

As you can schedule a job, you can also run any Scheduled Job before its Scheduled time comes. To run or stop a job
immediately you can use the following command.

*/
-- 
-- executing a job immediately 

-- run the job
exec DBMS_SCHEDULER.RUN_JOB('log_to_table',FALSE);

-- stop the job
exec DBMS_SCHEDULER.STOP_JOB('log_to_table',TRUE);

/*
The most likely property of this newly "Scheduled Job" is that they can be easily
maintained and monitored by system views. You can find the related view in the
following.
*/
-- schedued jobs whichs owner is D_EPEKER
select * from dba_scheduler_jobs where owner='D_EPEKER';

-- you can also user user_scheduled_jobs view to find out the jobs and their properties
select * from user_scheduler_jobs;

-- Display the program details.
SELECT owner, program_name, enabled FROM dba_scheduler_programs;

-- run details of the scheduled jobs
select * from DBA_SCHEDULER_JOB_RUN_DETAILS 
  where lower(job_name) = 'log_to_file_external';

/*

For e.g..


BEGIN 
    DBMS_SCHEDULER.CREATE_JOB(
       job_name           =>  'Report_On_Comments_Count',
       job_type           =>  'STORED_PROCEDURE',   
       job_action         =>  'system.send_mail_column_report', -- schemaname.procedure name to run
       start_date         =>  TO_DATE('02/11/2011 11:30:00','mm/dd/yyyy hh24:mi:ss'), -- date_to_start_execution date
       repeat_interval    =>  'FREQ=WEEKLY; BYDAY=FRI;', -- will run on every friday 
       end_date           =>  NULL,     -- date_to_end_execution
       enabled             => TRUE, -- it can flase to not start the job 
       comments           =>  'Report on Table/Column comments count');-- explanation of the job
END;
/

BEGIN
  -- Run job synchronously.
  DBMS_SCHEDULER.run_job (job_name=> 'Report_On_Comments_Count', use_current_session => FALSE);
END;
/

BEGIN
  SYS.DBMS_SCHEDULER.ENABLE 
    (NAME => 'Report_On_Comments_Count');
END;
/

BEGIN
    DBMS_SCHEDULER.SET_ATTRIBUTE(
        NAME => 'Report_On_Comments_Count',  -- name of the job
        ATTRIBUTE => 'auto_drop',  -- attribute name
        VALUE => FALSE  -- new value of the attribute
        );
END;
/

exec DBMS_SCHEDULER.RUN_JOB('Report_On_Comments_Count',FALSE);

SELECT * FROM dba_scheduler_jobs WHERE job_name='REPORT_ON_COMMENTS_COUNT'

*/  
  
  
  
/*

There is a lot of way to determine the repeat interval. There is lots of examples 
in the following and you can also find the explanations of the frequencies.

*/
-- 
-- setting repeat_interval 
-- 
--Run every Friday
FREQ=DAILY; BYDAY=FRI;
FREQ=WEEKLY; BYDAY=FRI;
FREQ=YEARLY; BYDAY=FRI;

--Run every other Friday
FREQ=WEEKLY; INTERVAL=2; BYDAY=FRI;

--Run on the last day of every month.
FREQ=MONTHLY; BYMONTHDAY=-1;

--Run on the next to last day of every month.
FREQ=MONTHLY; BYMONTHDAY=-2;

--Run every 10 days
FREQ=DAILY; INTERVAL=10;

--Run daily at 4, 5, and 6PM.
FREQ=DAILY; BYHOUR=16,17,18;

--Run on the 15th day of every other month
FREQ=MONTHLY; INTERVAL=2; BYMONTHDAY=15;

--Run on the 29th day of every month
FREQ=MONTHLY; BYMONTHDAY=29;

--Run on the second Wednesday of each month
FREQ=MONTHLY; BYDAY=2WED;

--Run on the last Friday of the year.
FREQ=YEARLY; BYDAY=-1FRI;

--Run every 50 hours.
FREQ=HOURLY; INTERVAL=50;

--Run on the last day of every other month.
FREQ=MONTHLY; INTERVAL=2; BYMONTHDAY=-1;

--Run hourly for the first three days of every month.
FREQ=HOURLY; BYMONTHDAY=1,2,3;

--Run on the last workday of every month, excluding company holidays 
--(This example references an existing named schedule called Company_Holidays.)
FREQ=MONTHLY; BYDAY=MON,TUE,WED,THU,FRI; EXCLUDE=Company_Holidays; BYSETPOS=-1

--Run at noon every Friday and on company holidays.
FREQ=YEARLY;BYDAY=FRI;BYHOUR=12;INCLUDE=Company_Holidays


/*

-- To run everynight at midnight starting tonight
exec dbms_job.submit(:v_JobNo, 'proc1;', TRUNC(SYSDATE)+1, 'TRUNC(SYSDATE)+1');

-- To run every hour, on the hour, starting at the top of the hour
exec dbms_job.submit(:v_JobNo, 'proc2;', TRUNC(SYSDATE+(1/24), 'HH'),
'TRUNC(SYSDATE+(1/24),''HH'')');

-- To run every hour, starting now
exec dbms_job.submit(:v_JobNo, 'proc3;', INTERVAL => 'SYSDATE+(1/24)');

-- To run every ten minutes at 0,10,20,etc. minutes past the hour,
-- starting at the top of the hour
exec dbms_job.submit(:v_JobNo, 'proc4;', TRUNC(SYSDATE+(1/24), 'HH'),
'TRUNC(SYSDATE+(10/24/60),''MI'')');

-- To run every 2 min., on the minute, starting at the top of the 
-- minute
exec dbms_job.submit(:v_JobNo, 'proc5;', TRUNC(SYSDATE+(1/24/60), 'MI'),
'TRUNC(SYSDATE+(2/24/60),''MI'')');

-- To run every two minutes, starting now
exec dbms_job.submit(:v_JobNo, 'proc6;', INTERVAL => 'SYSDATE+(2/24/60)');

-- To run every half hour, starting at the top of the hour
exec dbms_job.submit(:v_JobNo, 'proc7;', TRUNC(SYSDATE+(1/24), 'HH'),
'TRUNC(SYSDATE+(30/24/60),''MI'')');


*/


-- Simple DB Job
-- which executes each day at 4:00 PM

DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( job       => X
   ,what      => 'DECLARE
       a NUMBER;
       b VARCHAR2(1000);
BEGIN
    P0(a,b);
END;   '
   ,next_date => to_date('24/07/2010 04:00:00','dd/mm/yyyy hh24:mi:ss')
   ,interval  => 'trunc(sysdate + 1) + 4/24'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || to_char(x));
COMMIT;
END;
/


frequency_clause = "FREQ" "=" ( predefined_frequency | user_defined_frequency )
predefined_frequency = "YEARLY" | "MONTHLY" | "WEEKLY" | "DAILY" | 
   "HOURLY" | "MINUTELY" | "SECONDLY"
user_defined_frequency = named_schedule

interval_clause = "INTERVAL" "=" intervalnum
   intervalnum = 1 through 99
bymonth_clause = "BYMONTH" "=" monthlist
   monthlist = monthday ( "," monthday)*
   month = numeric_month | char_month
   numeric_month = 1 | 2 | 3 ...  12
   char_month = "JAN" | "FEB" | "MAR" | "APR" | "MAY" | "JUN" |
   "JUL" | "AUG" | "SEP" | "OCT" | "NOV" | "DEC"
byweekno_clause = "BYWEEKNO" "=" weeknumber_list
   weeknumber_list = weeknumber ( "," weeknumber)*
   weeknumber = [minus] weekno
   weekno = 1 through 53
byyearday_clause = "BYYEARDAY" "=" yearday_list
   yearday_list = yearday ( "," yearday)*
   yearday = [minus] yeardaynum
   yeardaynum = 1 through 366
bydate_clause = "BYDATE" "=" date_list
   date_list = date ( "," date)*
   date = [YYYY]MMDD [ offset | span ]
bymonthday_clause = "BYMONTHDAY" "=" monthday_list
   monthday_list = monthday ( "," monthday)*
   monthday = [minus] monthdaynum
   monthdaynum = 1 through 31
byday_clause = "BYDAY" "=" byday_list
   byday_list = byday ( "," byday)*
   byday = [weekdaynum] day
   weekdaynum = [minus] daynum
   daynum = 1 through 53 /* if frequency is yearly */
   daynum = 1 through 5  /* if frequency is monthly */
   day = "MON" | "TUE" | "WED" | "THU" | "FRI" | "SAT" | "SUN"
byhour_clause = "BYHOUR" "=" hour_list
   hour_list = hour ( "," hour)*
   hour = 0 through 23
byminute_clause = "BYMINUTE" "=" minute_list
   minute_list = minute ( "," minute)*
   minute = 0 through 59
bysecond_clause = "BYSECOND" "=" second_list
   second_list = second ( "," second)*
   second = 0 through 59
bysetpos_clause = "BYSETPOS" "=" setpos_list
   setpos_list = setpos ("," setpos)*
   setpos = [minus] setpos_num
   setpos_num = 1 through 9999

include_clause = "INCLUDE" "=" schedule_list
exclude_clause = "EXCLUDE" "=" schedule_list
intersect_clause = "INTERSECT" "=" schedule_list
schedule_list = schedule_clause ("," schedule_clause)*
schedule_clause = named_schedule [ offset ]
named_schedule = [schema "."] schedule
periods_clause = "PERIODS" "=" periodnum
byperiod_clause = "BYPERIOD" "=" period_list
period_list = periodnum ("," periodnum)*
periodnum = 1 through 100

offset = ("+" | "-") ["OFFSET:"] duration_val
span = ("+" | "-" | "^") "SPAN:" duration_val
duration_val = dur-weeks | dur_days
dur_weeks = numofweeks "W"
dur_days = numofdays "D"
numofweeks = 1 through 53
numofdays = 1 through 376
minus = "-"

In calendaring syntax, * means 0 or more.

Table 93-1 Values for repeat_interval

Name	Description
FREQ
This specifies the type of recurrence. It must be specified. The possible predefined frequency values are YEARLY, MONTHLY, WEEKLY, DAILY, HOURLY, MINUTELY, and SECONDLY. Alternatively, specifies an existing schedule to use as a user-defined frequency.
INTERVAL
This specifies a positive integer representing how often the recurrence repeats. The default is 1, which means every second for secondly, every day for daily, and so on. The maximum value is 999.
BYMONTH
This specifies which month or months you want the job to execute in. You can use numbers such as 1 for January and 3 for March, as well as three-letter abbreviations such as FEB for February and JUL for July.
BYWEEKNO
This specifies the week of the year as a number. It follows ISO-8601, which defines the week as starting with Monday and ending with Sunday; and the first week of a year as the first week, which is mostly within the Gregorian year. That last definition is equivalent to the following two variants: the week that contains the first Thursday of the Gregorian year; and the week containing January 4th.
The ISO-8601 week numbers are integers from 1 to 52 or 53; parts of week 1 may be in the previous calendar year; parts of week 52 may be in the following calendar year; and if a year has a week 53, parts of it must be in the following calendar year.
As an example, in the year 1998 the ISO week 1 began on Monday December 29th, 1997; and the last ISO week (week 53) ended on Sunday January 3rd, 1999. So December 29th, 1997, is in the ISO week 1998-01; and January 1st, 1999, is in the ISO week 1998-53.
byweekno is only valid for YEARLY.
Examples of invalid specifications are "FREQ=YEARLY; BYWEEKNO=1; BYMONTH=12" and "FREQ=YEARLY;BYWEEKNO=53;BYMONTH=1".
BYYEARDAY
This specifies the day of the year as a number. Valid values are 1 to 366. An example is 69, which is March 10 (31 for January, 28 for February, and 10 for March). 69 evaluates to March 10 for non-leap years and March 9 in leap years. -2 will always evaluate to December 30th independent of whether it is a leap year.
BYDATE
This specifies a list of dates, where each date is of the form [YYYY]MMDD. A list of consecutive dates can be generated by using the SPAN modifier, and a date can be adjusted with the OFFSET modifier. An example of a simple BYDATE clause is the following:
BYDATE=0115,0315,0615,0915,1215,20060115
The following SPAN example is equivalent to BYDATE=0110,0111,0112,0113,0114, which is a span of 5 days starting at 1/10:
BYDATE=0110+SPAN:5D
The plus sign in front of the SPAN keyword indicates a span starting at the supplied date. The minus sign indicates a span ending at the supplied date, and the "^" sign indicates a span of n days or weeks centered around the supplied date. If n is an even number, it is adjusted up to the next odd number.
Offsets adjust the supplied date by adding or subtracting n days or weeks. BYDATE=0205-OFFSET:2W is equivalent to BYDATE=0205-14D (the OFFSET: keyword is optional), which is also equivalent to BYDATE=0122.
BYMONTHDAY
This specifies the day of the month as a number. Valid values are 1 to 31. An example is 10, which means the 10th day of the selected month. You can use the minus sign (-) to count backward from the last day, so, for example, BYMONTHDAY=-1 means the last day of the month and BYMONTHDAY=-2 means the next to last day of the month.
BYDAY
This specifies the day of the week from Monday to Sunday in the form MON, TUE, and so on. Using numbers, you can specify the 26th Friday of the year, if using a YEARLY frequency, or the 4th THU of the month, using a MONTHLY frequency. Using the minus sign, you can say the second to last Friday of the month. For example, -1 FRI is the last Friday of the month.
BYHOUR
This specifies the hour on which the job is to run. Valid values are 0 to 23. As an example, 10 means 10 a.m.
BYMINUTE
This specifies the minute on which the job is to run. Valid values are 0 to 59. As an example, 45 means 45 minutes past the chosen hour.
BYSECOND
This specifies the second on which the job is to run. Valid values are 0 to 59. As an example, 30 means 30 seconds past the chosen minute.
BYSETPOS
This selects one or more items by position in the list of timestamps that result after the whole calendaring expression is evaluated. It is useful for requirements such as running a job on the last workday of the month. Rather than attempting to express this with the other BY clauses, you can code the calendaring expression to evaluate to a list of every workday of the month, and then add the BYSETPOS clause to select only the last item of that list. Assuming that workdays are Monday through Friday, the syntax would then be:
FREQ=MONTHLY; BYDAY=MON,TUE,WED,THU,FRI; BYSETPOS=-1
Valid values are 1 through 9999. A negative number selects an item from the end of the list (-1 is the last item, -2 is the next to last item, and so on) and a positive number selects from the front of the list. The BYSETPOS clause is always evaluated last. BYSETPOS is only supported with the MONTHLY and YEARLY frequencies.
The BYSETPOS clause is applied to the list of timestamps once per frequency period. For example, when the frequency is defined as MONTHLY, the Scheduler determines all valid timestamps for the month, orders that list, and then applies the BYSETPOS clause. The Scheduler then moves on to the next month and repeats the procedure. Assuming a start date of Jun 10, 2004, the example evaluates to: Jun 30, Jul 30, Aug 31, Sep 30, Oct 29, and so on.
INCLUDE
This includes one or more named schedules in the calendaring expression. That is, the set of timestamps defined by each included named schedule is added to the results of the calendaring expression. If an identical timestamp is contributed by both an included schedule and the calendaring expression, it is included in the resulting set of timestamps only once. The named schedules must have been defined with the CREATE_SCHEDULE procedure.
EXCLUDE
This excludes one or more named schedules from the calendaring expression. That is, the set of timestamps defined by each excluded named schedule is removed from the results of the calendaring expression. The named schedules must have been defined with the CREATE_SCHEDULE procedure.
INTERSECT
This specifies an intersection between the calendaring expression results and the set of timestamps defined by one or more named schedules. Only the timestamps that appear both in the calendaring expression and in one of the named schedules are included in the resulting set of timestamps.
For example, assume that the named schedule last_sat indicates the last Saturday in every month, and that for the year 2005, the only months where the last day of the month is also a Saturday are April and December. Assume also that the named schedule end_qtr indicates the last day of each quarter in 2005:
3/31/2005, 6/30/2005, 9/30/2005, 12/31/2005
The following calendaring expression results in the these dates:
3/31/2005, 4/30/2005, 6/30/2005, 9/30/2005, 12/31/2005
FREQ=MONTHLY; BYMONTHDAY=-1; INTERSECT=last_sat,end_qtr
In this example, the terms FREQ=MONTHLY; BYMONTHDAY=-1 indicate the last day of each month.
PERIODS
This identifies the number of periods that together form one cycle of a user defined frequency. It is used in the repeat_interval expression of the schedule that defines the user defined frequency. It is mandatory when the repeat_interval expression in the main schedule contains a BYPERIOD clause. The following example defines the quarters of a fiscal year.
FREQ=YEARLY;BYDATE=0301,0601,0901,1201;PERIODS=4
BYPERIOD
This selects periods from a user defined frequency. For example, if a main schedule names a user defined frequency schedule that defines the fiscal quarters shown in the previous example, the clause BYPERIOD=2,4 in the main schedule selects the 2nd and 4th fiscal quarters.



DECLARE
  X NUMBER;
BEGIN
  SYS.DBMS_JOB.SUBMIT
  ( JOB       => X 
   ,what      => 'declare 
                    a number;
                    b varchar2(100);
                  begin
                    TRANSNOX_GCA.MONTHLY_DEVICE_COUNTS();
                  end; '
   ,next_date => TO_DATE('05/08/2013 01:06:06','dd/mm/yyyy hh24:mi:ss')
   ,INTERVAL  => 'SYSDATE+15/1440'
   ,no_parse  => FALSE
  );
  SYS.DBMS_OUTPUT.PUT_LINE('Job Number is: ' || TO_CHAR(x));
COMMIT;
END;
/

SELECT * FROM dba_jobs WHERE JOB=66;


BEGIN
sys.DBMS_IJOB.CHANGE_ENV
  ( 
     JOB => 66, 
     LUSER => 'TRANSCAPITALONEAPP', 
     PUSER => 'TRANSCAPITALONEAPP',
    CUSER => 'TRANSCAPITALONEAPP',
    NLSENV => 'NLS_LANGUAGE=''AMERICAN''
               NLS_TERRITORY=''AMERICA''
               NLS_CURRENCY=''$''
               NLS_ISO_CURRENCY=''AMERICA''
               NLS_NUMERIC_CHARACTERS=''.,''
               NLS_DATE_FORMAT=''DD-MON-RR''
               NLS_DATE_LANGUAGE=''AMERICAN''
               NLS_SORT=''BINARY''
              '); COMMIT;
END;
/




DECLARE
  MY_JOB NUMBER;
BEGIN
  DBMS_JOB.SUBMIT
  	(
  		JOB => MY_JOB, 
    	WHAT => 'DECLARE 
  				 o_OUTPUTSTATUS VARCHAR2(32767);
  				 o_OUTPUTMSG VARCHAR2(32767);
				 BEGIN 
				  PURGEDATA.TRANSIT_PURGING_PKG.PURGE_TAB_PROCS(o_OUTPUTSTATUS,o_OUTPUTMSG );
				  COMMIT; 
				 END; ',
	    NEXT_DATE => SYSDATE+15/1440,
	    INTERVAL => 'SYSDATE+1'
	);
    DBMS_OUTPUT.PUT_LINE(MY_JOB);
    COMMIT;
SYS.DBMS_IJOB.CHANGE_ENV
  ( 
    JOB => my_job , 
    LUSER => 'PURGEDATA', 
    PUSER => 'PURGEDATA',
    CUSER => 'PURGEDATA',
    NLSENV => 'NLS_LANGUAGE=''AMERICAN''
               NLS_TERRITORY=''AMERICA''
               NLS_CURRENCY=''$''
               NLS_ISO_CURRENCY=''AMERICA''
               NLS_NUMERIC_CHARACTERS=''.,''
               NLS_DATE_FORMAT=''DD-MON-RR''
               NLS_DATE_LANGUAGE=''AMERICAN''
               NLS_SORT=''BINARY'''
   ); 
   COMMIT;
END;
/ 

****************************************  SCHEDULED JOBS ****************************************





****************************************  ACL NETWORK For Setup of MAILS ****************************************
-- connect to system user

SELECT ANY_PATH
FROM RESOURCE_VIEW
WHERE ANY_PATH LIKE '/sys/acls/dba%';

SELECT host, lower_port, upper_port, acl
FROM   dba_network_acls;


SELECT acl,
       principal,
       privilege,
       is_grant,
       TO_CHAR(start_date, 'DD-MON-YYYY') AS start_date,
       TO_CHAR(end_date, 'DD-MON-YYYY') AS end_date
FROM   dba_network_acl_privileges;

grant execute on UTL_SMTP to public

BEGIN
    DBMS_NETWORK_ACL_ADMIN.CREATE_ACL (
    ACL => 'dba.xml', -- case sensitive
    DESCRIPTION=> 'Network Access Control for the DBAs',
    PRINCIPAL => 'SNOX', -- user or role the privilege is granted or denied (upper case)
    IS_GRANT => TRUE, -- privilege is granted or denied
    PRIVILEGE => 'connect', -- or 'resolve' (case sensitive)
    START_DATE => NULL, -- when the access control entity ACE will be valid
    END_DATE => NULL); -- ACE expiration date (TIMESTAMP WITH TIMEZONE format)
END;
/


BEGIN
  DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL (
    acl         => 'dba.xml',
    HOST        => 'MAIL.INFONOX.COM', 
    lower_port  => 25,
    upper_port  => 25); 
    COMMIT;
END;
/


BEGIN
 DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE 
  (
    ACL => 'dba.xml',
    PRINCIPAL => 'SNOX',
    IS_GRANT => TRUE,
    PRIVILEGE => 'connect',
    START_DATE => NULL, -- if the time interval is defined,
    END_DATE => NULL
 ); -- the ACE will expire after the specified date range
END;
/



--------------------------------->>>>>>>>>>>>>>>>

BEGIN
  DBMS_NETWORK_ACL_ADMIN.drop_acl (acl => 'dba1.xml');
  COMMIT;
END;
/

begin
 DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE 
  (
    ACL => 'dba.xml',
    PRINCIPAL => 'RAHULC',
    IS_GRANT => TRUE,
    PRIVILEGE => 'connect',
    START_DATE => null, -- if the time interval is defined,
    END_DATE => null
 ); -- the ACE will expire after the specified date range
end;
/

BEGIN
  DBMS_NETWORK_ACL_ADMIN.delete_privilege ( 
    acl         => 'dba1.xml', 
    principal   => 'RAHULC',
    is_grant    => TRUE, 
    privilege   => 'execute');

  COMMIT;
END;
/

--------------------------------->>>>>>>>>>>>>>>>

---------------------*********************-------------------


CREATE OR REPLACE PROCEDURE RAHULC.SEND_EVENT_MAIL
(
    o_OutputStatus OUT  NUMBER,
    o_OutputMessage OUT VARCHAR2 
)
AS
        v_mailHost     VARCHAR2(50):='MAIL.INFONOX.COM';
        v_Connection UTL_SMTP.Connection;
        v_reply UTL_SMTP.REPLY;
        
        MESSAGE      VARCHAR2(32767);
        crlf         VARCHAR2(2):=CHR(13)||CHR(10);
        
        v_error_flag NUMBER;
        
        v_Sender     VARCHAR2(100); --- mail sender
        v_Recipient  VARCHAR2(100); --- CC list
        
        v_Subject    VARCHAR2(100); --- Mail subject
        
        v_Body       VARCHAR2(32767);  --- Mail body
        
        v_cc_recipt1 VARCHAR2(100);
        
        v_date       VARCHAR2(20);
        v_Data       VARCHAR2(32767);
        v_Data_f     VARCHAR2(32767);
        v_count      NUMBER;
BEGIN
        SELECT TO_CHAR(SYSDATE,'mm/dd/yyyy hh24:mi:ss') INTO v_date FROM dual;
        
        v_error_flag :=1;
        -- Mail sender
        v_Sender     := 'rahulc@infonox.com';
        
        -- TO list
        v_Recipient  := 'rahulc@infonox.com';
        v_cc_recipt1 := 'baidhar@infonox.com'; 

        v_data:=NULL;
        FOR z  IN
        ( SELECT SCHEMA_NAME, TABLE_NAME FROM TABLE_LIST ORDER BY 1, 2 ASC)
        LOOP
                v_error_flag:=3;
                v_data_f    :='<TR><TD>'||z.SCHEMA_NAME ||'</TD><TD>'||UPPER(z.TABLE_NAME) ||'</TD></TR>';
                v_error_flag:=4;
                v_data      := v_data_f||v_data;
        END LOOP;

        v_error_flag:=5;
        v_data      :='<TR bgcolor="#CCCCCC"><TD>SCHEMA_NAME</TD><TD>TABLE_NAME</TD></TR>'||v_data;

                v_error_flag:=6;
                v_Subject    := 'Oracle Version 11G from Dev11G DB 231.84' ;
                
                v_error_flag:=7;
                v_Body      := '<BODY><FONT FACE="Courier New" size="04"> Hi Baidhar, </FONT></BODY> <br>'|| 
                               '&nbsp;&nbsp;&nbsp;&nbsp;<BODY><FONT FACE="Courier New" size="04"> Sending the '||
                               'Mail from Oracle version 11g from devdb dev11g database 192.168.231.84. Just printing some table data result here in HTML format of date '||v_date||
                               '</FONT></BODY>. <br>'|| '<BODY><FONT FACE="Courier New" size="11"><TABLE BORDER="1">'||v_data||
                               '</TABLE></FONT></BODY> <br><br>'|| '<BODY><FONT FACE="Courier New" size="04">Regards<br>'|| 
                               '- Rahul Chaudhari </FONT></BODY>';
        
                v_error_flag :=8;
                
                v_Connection := UTL_SMTP.OPEN_CONNECTION(v_mailHost, 25);
                v_reply      := UTL_SMTP.HELO(v_Connection, v_mailHost);
                v_reply      := UTL_SMTP.MAIL(v_Connection, v_Sender);
                v_reply      := UTL_SMTP.RCPT(v_Connection, v_Recipient);
                
                v_error_flag:=9;

                IF v_cc_recipt1 IS NOT NULL THEN
                   UTL_SMTP.rcpt(v_Connection,v_cc_recipt1);
                END IF;
                    
                MESSAGE := 'From: '||v_Sender||crlf|| 
                           'To: '||v_Recipient||crlf|| 
                           'Subject: '||v_Subject||crlf||''||crlf||v_Body;
                
                v_error_flag:=10;
                
                UTL_SMTP.DATA(v_Connection,'Content-type: text/html'|| crlf||MESSAGE);
                UTL_SMTP.QUIT(v_Connection);
                

        o_OutputStatus:='0';
        o_OutputMessage:='SUCCESS';
        
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Step number: '||v_error_flag||' Message: '||SUBSTR(SQLERRM,1,100));
END SEND_EVENT_MAIL;
/


****************************************  ACL NETWORK For Setup of MAILS ****************************************



****************************************  External Tables ****************************************

-- Creating an External Table and Loading Data

/*
	The following example creates an external table, then uploads the data to a 
	database table. We have tested the examples in the Oracle9i Database 
	Administrators Guide Release 1 (9.0.1) using Oracle 9.0.1 on Windows 2000.

	The file empxt1.dat in C:\Users\Zahn\Work contains the following sample data:

	7369,Schmied,Schlosser,7902,17.12.1980,800,0,20
	7499,Zaugg,Verk�ufer,7698,20.02.1981,1600,300,30
	7521,M�ller,Verk�ufer,7698,22.02.1981,1250,500,30
	7566,Holzer,Informatiker,7839,02.04.1981,2975,0,20
	7654,Zahn,Verk�ufer,7698,28.09.1981,1250,1400,30
	7698,Sutter,Informatiker,7839,01.05.1981,2850,0,30
	7782,Graf,Informatiker,7839,09.06.1981,2450,0,10

	The file empxt2.dat in C:\Users\Zahn\Work contains the following sample data:

	7788,Gasser,Analytiker,7566,19.04.1987,3000,0,20
	7839,Kiener,Lehrer,,17.11.1981,5000,0,10
	7844,Stoller,Verk�ufer,7698,08.09.1981,1500,0,30
	7876,Amstutz,Automechaniker,7788,23.05.1987,1100,0,20
	7900,Weigelt,Automechaniker,7698,03.12.1981,950 ,0,30
	7902,Wyss,Analytiker,7566,03.12.1981,3000,0,20
	7934,Messerli,Automechaniker,7782,23.01.1982,1300,0,10

	The following SQL statements create an external table and load its data into 
	database table EMP of the user scott.

*/

sqlplus /nolog

SQL*Plus: Release 9.0.1.0.1 - Production on
Sat Jan 26 10:44:48 2002
(c) Copyright 2001 Oracle Corporation. All rights reserved.

CONNECT  SYS/MANAGER  AS SYSDBA;
SET ECHO ON;

CREATE OR REPLACE DIRECTORY dat_dir AS 'C:\Oracle\Data';
CREATE OR REPLACE DIRECTORY log_dir AS 'C:\Oracle\Log';
CREATE OR REPLACE DIRECTORY bad_dir AS 'C:\Oracle\Bad';

Directory created.

GRANT READ ON DIRECTORY dat_dir TO scott;
GRANT WRITE ON DIRECTORY log_dir TO scott;
GRANT WRITE ON DIRECTORY bad_dir TO scott;

Grant succeeded.

CONNECT scott/tiger;
DROP TABLE empxt;

CREATE TABLE empxt (empno       NUMBER(4),
                    ename       VARCHAR2(20),
                    job         VARCHAR2(20),
                    mgr         NUMBER(4),
                    hiredate    DATE,
                    sal         NUMBER(7,2),
                    comm        NUMBER(7,2),
                    deptno      NUMBER(2)
                   )
 ORGANIZATION EXTERNAL
 (
   TYPE ORACLE_LOADER
   DEFAULT DIRECTORY dat_dir
   ACCESS PARAMETERS
   (
     records delimited by newline
     badfile bad_dir:'empxt%a_%p.bad'
     logfile log_dir:'empxt%a_%p.log'
     fields terminated by ','
     missing field values are null
     ( empno,
       ename,
       job,
       mgr,
       hiredate char date_format date mask "dd.mm.yyyy",
       sal,
       comm,
       deptno
     )
   )
   LOCATION ('empxt1.dat', 'empxt2.dat')
 )
 PARALLEL
 REJECT LIMIT UNLIMITED;

Table created.

ALTER SESSION ENABLE PARALLEL DML;

Session altered.

/*
	The first few statements in this example create the directory objects for the 
	operating system directories that contain the data sources, and for the bad 
	record and log files specified in the access parameters. You must also grant 
	READ or WRITE directory object privileges, as appropriate.

	The TYPE specification is given only to illustrate its use. If not specified, 
	ORACLE_LOADER is the default access driver. The access parameters, specified 
	in the ACCESS PARAMETERS clause, are opaque to Oracle. These access parameters
	are defined by the access driver, and are provided to the access driver by 
	Oracle when the external table is accessed.

	The PARALLEL clause enables parallel query on the data sources. The granule 
	of parallelism is by default a data source, but parallel access within a data 
	source is implemented whenever possible. For example, if PARALLEL=3 were 
	specified, then more than one parallel execution server could be working on 
	a data source.

	The REJECT LIMIT clause specifies that there is no limit on the number of 
	errors that can occur during a query of the external data. For parallel 
	access, this limit applies to each parallel query slave independently. 
	For example, if REJECT LIMIT 10 is specified, each parallel query process 
	is allowed 10 rejections. Hence, the only precisely enforced values for 
	REJECT LIMIT on parallel query are 0 and UNLIMITED.

*/

****************************************  External Tables ****************************************







****************************************  Oracle Installation ****************************************
--- hidden commands for installing oracle and some commands useful while installing oracle
http://pafumi.net/RAC_10g_Vmware.html


http://www.petefinnigan.com/other.htm

Oracle Installation Stuff



# set the kernel parameters

vi /etc/sysctl.conf

				
kernel.shmall = 18874368
kernel.shmmax = 3147483648  -- Smallest of -> (Half the size of the physical memory) or (4GB - 1 byte)
kernel.shmmni = 4096 -- semaphores: semmsl, semmns, semopm, semmni
kernel.sem = 250 32000 100 128
fs.file-max = 65536 --# 512 * PROCESSES
net.ipv4.ip_local_port_range = 1024 65000
net.core.rmem_default=4194304
net.core.rmem_max=4194304
net.core.wmem_default=262144
net.core.wmem_max=262144

-- For Enterprise Linux 5.0, the following lines should be appended to the "/etc/sysctl.conf" file.

kernel.shmmni = 4096
# semaphores: semmsl, semmns, semopm, semmni
kernel.sem = 250 32000 100 128
net.ipv4.ip_local_port_range = 1024 65000
net.core.rmem_default=4194304
net.core.rmem_max=4194304
net.core.wmem_default=262144
net.core.wmem_max=262144

-- Run the following command to change the current kernel parameters:

    /sbin/sysctl -p
    
Notes: Execute sysctl -p to make these new settings take effect.

--------------------------------------------------------------------------

#set the limitation parameters.

 vi /etc/security/limits.conf

oracle           soft    nofile          63536
oracle           hard    nofile          63536

oracle           soft    nproc           16384
oracle           hard    nproc           16384

oracle           soft    memlock         3145728
oracle           hard    memlock         3145728


--------------------------------------------------------------------------
--Add the following line to the /etc/pam.d/login file, if it does not already exist:

vi /etc/pam.d/login

session    required     pam_limits.so


--------------------------------------------------------------------------
-- Disable secure linux by editing the /etc/selinux/config file, making sure the SELINUX flag is set as follows:

SELINUX=disabled
    
--------------------------------------------------------------------------
# change the hosts and ip address setting as per the db server name and ip

vi /etc/hosts


127.0.0.1       localhost.localdomain localhost  --- local ip and localhost
10.66.15.212    sc-siguedb2.ifxsc.com sc-siguedb2 --- ip and DB Server name
10.66.15.213    sc-siguedb1.ifxsc.com sc-siguedb1 -- ip and db server name of standby DB
10.65.235.60    sqlcluster SQLCLUSTER CLUSTER	  -- ip and db server name of cluster DB
# 65.216.123.102  sqlcluster SQLCLUSTER CLUSTER



# reboot the linux server to take the effect in above memory configuration files.
# you should be on root for executing the below command for rebooting the linux server

sync;sync;reboot



--------------------------------------------------------------------------

-- set up the vncserver by login into oracle account
-- execute all the below commands in oracle account for vncserver set and start.
service vncserver start / stop

vncpasswd

vncserver :1.1521 --- starts vncserver for 1521 port only on :1

login to vnc and start the runinstall.sh from oracle user account


-- changes in vncserver file for starting in gnome mode

vi /home/oracle/.vnc/xstartup --- this is the home directory of oracle change as per your's

#make the chages before EOF of the file
exec gnome-session &

-- save the vncserver file and exit from vi editor

#kill the session of vncserver
vncserver -kill :1



/*

 unset SESSION_MANAGER
 exec /etc/X11/xinit/xinitrc

[ -r $HOME/.Xresources ] && xrdb $HOME/.Xresources
xsetroot -solid grey
vncconfig -iconic &
xterm -geometry 80x24+10+10 -ls -title "$VNCDESKTOP Desktop" &
exec gnome-session
twm &

*/

--------------------------------------------------------------------------
To create the oracle account and groups, execute the following commands: 
su - root
groupadd dba          # group of users to be granted SYSDBA system privilege
groupadd oinstall     # group owner of Oracle files
useradd -c "Oracle software owner" -g oinstall -G dba oracle -d /ora1/oracle

passwd oracle

cd /home/oracle

mkdir OraHome1

chown -R oracle.oinstall /home/oracle/OraHome1
chmod -R 777 /home/oracle/OraHome1

chown -R oracle.dba /ora1
chown -R oracle.dba /ora2
chown -R oracle.dba /ora3

chmod -R 777 /ora1
chmod -R 777 /ora2
chmod -R 777 /ora3


--------------------------------------------------------------------------

login to oracle account and modify .bash_profile  
file as per the ORACLE_BASE / ORACLE_HOME and ORACLE_SID  and also set rest environment
variables in this file 

for e.g

vi .bash_profile

# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs
ORACLE_BASE=/oracle
ORACLE_HOME=/oracle/OraHome1

#ORACLE_SID=stag
#ORACLE_SID=qadb

export ORACLE_BASE
export ORACLE_HOME
export ORACLE_SID

unset TWO_TASK
export LD_ASSUME_KERNEL=2.4.20
PATH=$ORACLE_HOME/bin:/usr/bin:/bin:/usr/bin/X11:/usr/local/bin:/sbin:

#PATH=$PATH:$HOME/bin

export PATH
unset USERNAME

--------------------------------------------------------------------------

#execute the command for unzip the file having .cpio extension else make it unzip which is having .zip extension
cpio -idmv < <file_path.cpio>

unzip <file_patch_path.zip>


--------------------------------------------------------------------------

-- Listener settings
LISTENER =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = 10.120.90.63)(PORT = 1521))
    )
  )


SID_LIST_LISTENER =
    (SID_DESC =
      (GLOBAL_DBNAME = qadb)
      (ORACLE_HOME = $ORACLE_HOME)
      (SID_NAME = qadb)
    )
  )



--------------------------------------------------------------------------

-- TNS Entry settings
qadb =
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=10.120.90.63)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=qadb)
    )
  )
  
  
  
  
  
--Final Setup******************************************************************************************
Create the new groups and users:

    groupadd oinstall
    groupadd dba
    groupadd oper
    groupadd asmadmin

    useradd -g oinstall -G dba,oper,asmadmin oracle
    passwd oracle

Note. We are not going to use the "asmadmin" group, since this installation will not use ASM.

Create the directories in which the Oracle software will be installed:

    mkdir -p /u01/app/oracle/product/11.1.0/db_1
    chown -R oracle:oinstall /u01
    chmod -R 775 /u01

Login as root and issue the following command:

    xhost +<machine-name>

Login as the oracle user and add the following lines at the end of the .bash_profile file:


# Oracle Settings
TMP=/tmp; export TMP
TMPDIR=$TMP; export TMPDIR

ORACLE_HOSTNAME=octifxsdb01.ifxtempe.com; export ORACLE_HOSTNAME

ORACLE_BASE=/u01/app/oracle; export ORACLE_BASE
ORACLE_HOME=$ORACLE_BASE/product/11.1.0/db_1; export ORACLE_HOME

ORACLE_SID=devdb; export ORACLE_SID

ORACLE_TERM=xterm; export ORACLE_TERM

PATH=/usr/sbin:$PATH; export PATH

PATH=$ORACLE_HOME/bin:$PATH; export PATH

#LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib; export LD_LIBRARY_PATH
#CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

if [ $USER = "oracle" ]; then
  if [ $SHELL = "/bin/ksh" ]; then
	ulimit -p 16384
	ulimit -n 65536
  else
	ulimit -u 16384 -n 65536
  fi
fi



--Installation
Log into the oracle user. If you are using X emulation then set the DISPLAY environmental variable:

    DISPLAY=<machine-name>:0.0; export DISPLAY
    
****************************************  Oracle Installation ****************************************




****************************************  Linux Command ****************************************

-- Linux Helpfull Command List

--Now we can see that the results aren�t sorted, so we�ll sort them by the sort -nr command, which sorts by numerical value in 
--reverse. Finally, we�ll run the results through head -10 to get the top 10 results:

--This is the command we are going to run:
du -sm * | sort -nr | head -10

-- getting the uniq result set from the linux command
egrep "WARNING OGG-01154" ggserr.log |awk '{print $15}' |sort|uniq

cat ggserr.log | grep "`date +%Y-%m-%d`" | grep "ORA-"


-- replace the string in big files without opening the files
grep -rl US7ASCII test.log |xargs sed -i -e 's/US7ASCII/US7ASCII1267892345/g'

--Shell scripting with conditions 

If then else condition

-eq-Checks to see if arguments are equal (for example, if [ 2 -eq 5 ] )
-ne-Checks for inequality of arguments
-lt-Checks if argument 1 is less than argument 2
-le-Checks if argument 1 is less than or equal to argument 2
-gt-Checks if argument 1 is greater than argument 2
-ge-Checks if argument 1 is greater than or equal to argument 2
-f-Checks if a file exists (for example, if [ -f "filename" ] )
-d-Checks if a directory exists

------------------------------------------------------------------------------

USEFUL SHELL SCRIPT ARGUMENTS

execute the below using echo ARGUMENTS

$1,$2----Positional parameter representing command line argument
$#----Number of arguments specified in command line
$0----Name of executed commands  -- for eg. echo $"Usage: $0 {start|stop|status|reload|restart|condrestart}"
$*---Complete set of positional parameters as a single string
"$@"----Each quotated string treated as seprate argument (recommended over $*)
$?---Exit status of last command
$$-- pid of current shell
#!----Pid of last bagoround job

---------------------------------------------------------------------------------

-- returns all the lines that contain a string 
-- matching the expression "foo" in the file "snox4transnox_backup_logs". 
 grep ORA snox4transnox_backup_logs.log

----------------------------------------------------------------------------------

 --- last 2 weeks files
find transnox/wucc/exp*.dmp -mtime -14 -print
 
--- exclude files which are modified last 2 weeks back... and take all files 
find transnox/wucc/exp*.dmp ! -mtime -14 -ls


--- this command finds out file which are not in modified in 14 days and which are in between 26 days
 find ../../transnox/centennial/exp*.dmp ! -mtime +26 ! -mtime -14 -ls
 
 
 -- one day prevoius file sreaching
 find /ora3/oracle/oradata/coms/archive -type f -mtime +0 -exec ls -l {} \;
 
 
 -- sreaching for the days given 
 ls -ltrh |grep "Jul  5"

 -- remove the files up till date like Mar 12
 ls -ltr | grep "Mar 12" | awk '{print $9}'  | xargs rm -f
 
 
 
 
  tar -zvxf snoxgateway.tar.gz
 
 %s/angad/rahul
 
 %s/angad/rahul/g
 
%s/\/home\/angad/\/home\/rahul/g


-- vi option for replace in front of script
:%s/^/ mv /g 

-- vi option for replace at the end of the script
:%s/$/ \/moneris5\/old_archive\/coms /g


:%s/$/ \/ora10\/old_archive /g

/ora10




-- checking the multiple disk space on linux
#!/bin/bash
for ID in `df -h | grep -v none | grep -v Filesystem | grep -v "/" | grep -v -w "home"| awk '{if ($5 > "80%") print $1 " " $5}' | sed 's/ /=/g'`
do
        echo $ID | sed 's/=/ /g'
        excecute the script
done


-- checking the /home partition disk space on linux
VAL=`df -h | grep "/ora4" | awk '{print $5}'`

if [ $VAL > 80 ]
then
	execute script
else
	:
fi

--- we can move more the one files in one command
-- i is string and 
-- t is verbose
ls olddir | xargs -i -t mv olddir/ newdir/


--- scp command help
expect -c "
# exp_internal 1 # uncomment for debugging
spawn  scp -q qcp_xtns.dmp oracle@logarchive.ifxlv.com:/archive/bkups/dumps/transmoneris
expect { 
		"*password:*" { send oracle@7534\r\n; interact } 
		eof { exit }
	}
exit
"

scp map_DB_bkups.tar.gz oracle@10.150.50.132:/gcabackup3/oracle/bkups_frm_17634_old_archiveServer/map_db
scp tp-transending.ifxtempe.com oracle@10.150.50.132:/gcabackup3/oracle/bkups_frm_17634_old_archiveServer/transending
scp qcpwdb63_17634_archiveServer.tar.gz oracle@10.150.50.132:/gcabackup3/oracle/bkups_frm_17634_old_archiveServer/gca
scp exp_xtns_archive_tempe_21.dmp exp_xtns_archive_tempe_21.log oracle@10.150.50.132:/gcabackup3/oracle/bkups_frm_17634_old_archiveServer/gca
scp *.tar* *.dmp oracle@10.150.50.132:/gcabackup3/oracle/bkups_frm_17634_old_archiveServer/transending/capitalone/
scp *.* oracle@10.150.50.132:/gcabackup3/oracle/bkups_frm_17634_old_archiveServer/transending/moneris
scp exp_tempe_archive_DB_bkup.log exp_tempe_arch_DB_bkup_12Jan16.dmp oracle@10.150.50.132:/gcabackup2/oracle/bkups_frm_17634_old_archiveServer/tp_archiveDB_bkups
scp -Cr Sigue_transit_final_backup/ tempe_bpo26/ oracle@10.150.50.132:/gcabackup3/oracle/bkups_frm_17634_old_archiveServer/transending/


Step one: pipe the output of "echo" into a translation (tr) command that will replace spaces with linefeeds (represented by "\n"):

$ echo "cherry apple peach" | tr " " "\n"
cherry
apple
peach 

Success: each word appears on a separate line. Now we are ready to sort.

Step two: add the sort command:

$ echo "cherry apple peach" | tr " " "\n" | sort
apple
cherry
peach 

--Let's try reversing the order of the sort:

$ echo "cherry apple peach" | tr " " "\n" | sort -r
peach
cherry
apple 


The file must be made executable by changing its permission bits. An example:

$ chmod +x (shell script filename) 

One normally executes a shell script this way:

$ ./scriptname.sh



------------------------------------------

 /* vi command option */
 
 vi command options
 
 esc :q!         --Just quit - donot save 
 esc :e!         --Revert to saved 
 esc :wq         --Save and exit 
 
 esc shift zz    --Save and exit 
 esc i           --Enter insert mode (edit mode) 
 esc a           --Enter append mode (edit mode) 
 esc             --Exit edit mode 
 esc r           --Replace a single character 
 esc x           --Delete a single character 
 esc dd          --Delete a single line 
 esc yy          --Copy a single line 
 esc p           --Paste a single line 
 .               --Repeat the last command 
 esc /           --String search 
 esc $           --Jump to end of line 
 esc ^           --Jump to begining of line 
 shift g         --Jump to the end of the file 
 :1              --Jump to the begining of the file 
 :.=             --Display the current line number 

----------------------------------------------------

--command finds the unique key values in a file
cat gcatest.log|awk -F ' ' {'print $3'}|uniq|sort|uniq

--- will delete the first thousand 
ls -ltrh|head -n 1000|awk '{print $9}'|xargs rm -f


00 19 * * * sh /archive/dba/bkups/bkups_scripts/veroDB_bkup_script.sh


-- to remove the 3 days older files
30 21 * * * find /ora1/oracle/bkups/dumps/transending/moneris/* -ctime +3 -exec rm -R {} \;

df -h | grep "/ora3" | awk '{print $5}'|sed 's/%//g'


file:///E:/mainStuff/Oracle%20Doc/Oracle%2010G%20streams/Streams%20Demo%201.htm
--********************************************************************--
-- cronjob will run for every 15 mins on all days
*/15 * * * *  sh /ora3/archive_cronjob/arch_1day_older_files.sh


#!/bin/bash
cd /archive/oracle/arcdb/archive

VAL=`ls -ltrh|wc -l`
if [ $VAL '>' 100 ]
then
    ls -ltrh |head -n 100|awk '{print $9}'|xargs rm -f
fi




#!/bin/bash

# checking the /ora3 disk partition space where archive files are getting create
VAL=`df -h | grep "/ora3" | awk '{print $5}'|sed 's/%//g'`

if [ $VAL '>' 78 ]
then
    echo  $VAL > log_no_ds.log
    echo "/ora3 Disk space above 80%"

	cd /ora3/oracle/oradata/tsnd/archive

	find 1_*.arc -type f -mtime +0 -exec ls -l {} \; > temp_file.sh

	for fn in `cat temp_file.sh |awk '{print $9}'`
	do
		echo " "

		# making the ta files
		MK_TAR=`echo $fn |sed 's/.arc/.tar.gz/g'`
		tar -cvzf $MK_TAR  $fn

		# deleting non tar files
		rm -f $fn

		# moving thetar file to different destination
		mv $MK_TAR  /ora4/old_archive
	done

	rm -f temp_file.sh
else
    echo "$VAL"
    echo "/ora3 Disk space is below 80%"
fi



*/30 * * * *  sh /ora3/old_archive/remove_old_arch_scrpt.sh


#!/bin/bash

# checking the /ora4 disk partition space where archive files are getting create
VAL=`df -h | grep "/ora4" | awk '{print $5}'|sed 's/%//g'`

if [ $VAL '>' 78 ]
then
    echo  $VAL > log_no_ds.log
    echo "/ora4 Disk space above 80%"

	cd /ora4/old_archive

	find *.tar.gz -type f -mtime +0 -exec ls -l {} \; | awk '{print $9}'|xargs rm -f

else
    echo "$VAL"
    echo "/ora4 Disk space is below 80%"
fi


--********************************************************************--
-- for standby database's
*/15 * * * *  sh /ora3/archive_cronjob/arch_1day_older_files.sh

#!/bin/bash

# checking the /ora3 disk partition space where archive files are getting create
VAL=`df -h | grep "/ora3" | awk '{print $5}'|sed 's/%//g'`

if [ $VAL '>' 76 ]
then
    echo  $VAL > log_no_ds.log
    echo "/ora3 Disk space above 80%"

	cd /ora3/oracle/oradata/tsnd/archive

	find 1_*.arc -type f -mtime +0 -exec ls -l {} \; | awk '{print $9}'|xargs rm -f 

else
    echo "$VAL"
    echo "/ora3 Disk space is below 80%"
fi


--********************************************************************--

*/
****************************************  Linux Command ****************************************






****************************************  Automat Grants and Synonyms ****************************************

DROP TYPE MYARRAY;

CREATE OR REPLACE TYPE myArray AS TABLE OF VARCHAR2(1000);
/

create or replace FUNCTION rr_stringtotable (i_string IN VARCHAR2, i_delimeter VARCHAR2)
      RETURN myArray
   AS
      v_data     myArray := myArray ();
      v_string   LONG := i_string;
      v_n        NUMBER;
   BEGIN
      WHILE (v_string IS NOT NULL)
      LOOP
         v_n := INSTR (v_string, i_delimeter);
e
         IF (v_n = 0)
         THEN
            v_n := LENGTH (v_string) + 1;
         END IF;

         v_data.EXTEND;
         v_data (v_data.COUNT) := SUBSTR (v_string, 1, v_n - 1);
         v_string := SUBSTR (v_string, v_n + 1);
      END LOOP;

      RETURN v_data;
   END;
/

-- pass the schema names separated by comma (,)
/* Formatted on 7/13/2011 5:39:39 PM (QP5 v5.149.1003.31008) */
DECLARE
   v_schema_name   VARCHAR2 (2000);

   CURSOR cur_grant_script
   IS
        SELECT    'GRANT '
               || WM_CONCAT (PRIVILEGE)
               || ' ON '
               || GRANTOR
               || '.'
               || TABLE_NAME
               || ' TO '
               || GRANTEE
                  grant_statement
          FROM dba_tab_privs
         WHERE grantee IN
                  (SELECT * FROM TABLE (rr_stringtotable (v_schema_name, ',')))
               AND grantor IN
                      (SELECT *
                         FROM TABLE (rr_stringtotable (v_schema_name, ',')))
               AND table_name NOT LIKE 'BIN$%'
               AND table_name NOT LIKE 'SN_TEMP%'
               AND table_name NOT LIKE 'SC_TEMP%'
      GROUP BY GRANTOR, TABLE_NAME, GRANTEE;

   CURSOR cur_synonym_script
   IS
      SELECT    'create or replace synonym '
             || owner
             || '.'
             || synonym_name
             || ' for '
             || table_owner
             || '.'
             || table_name
                synonym_statement
        FROM dba_synonyms ss
       WHERE ss.owner IN
                (SELECT * FROM TABLE (rr_stringtotable (v_schema_name, ',')))
             AND synonym_name IN
                    (SELECT object_name
                       FROM DBA_OBJECTS
                      WHERE     OWNER = ss.owner
                            AND OBJECT_TYPE = 'SYNONYM'
                            AND STATUS = 'INVALID');
BEGIN
   FOR cur_grant_script_rec IN cur_grant_script
   LOOP
      EXECUTE IMMEDIATE cur_grant_script_rec.grant_statement;
   END LOOP;

   FOR cur_synonym_script_rec IN cur_synonym_script
   LOOP
      EXECUTE IMMEDIATE cur_synonym_script_rec.synonym_statement;
   END LOOP;

   FOR cur_compile_schema
      IN (SELECT COLUMN_VALUE COLUMN_VALUE
            FROM TABLE (rr_stringtotable (v_schema_name, ',')))
   LOOP
      DBMS_UTILITY.
       COMPILE_SCHEMA (cur_compile_schema.COLUMN_VALUE, FALSE, FALSE);
   END LOOP;
EXCEPTION
   WHEN OTHERS
   THEN
      DBMS_OUTPUT.put_line (SQLCODE || '  ' || SQLERRM);
END;
/

****************************************  Automat Grants and Synonyms ****************************************






****************************************  Automat Replication Triggers ****************************************

CREATE OR REPLACE PROCEDURE REPL_TRI."GENERATE_TRIGGER" 
(
	o_Message 			OUT 	LONG
)
--AUTHID CURRENT_USER
IS
    v_tble_SchemaName           VARCHAR2(30):='SNOX4TRANSNOX_GCA';  

    v_ErrorFlag	   				NUMBER; 
	
	v_sql 			 			VARCHAR2(32000);
	
	v_Flagcnt 					VARCHAR2(6);
	
	v_Trigger_Count				NUMBER:=0;
	v_Table_Name				VARCHAR2(40);

	v_sqlString					VARCHAR2(2000);
	v_pk_columns				VARCHAR2(32000);
    
    v_sql_insert_str1           VARCHAR2(32000);
		
	v_clob_blob_strSQL			LONG; --VARCHAR2(32000);
	v_without_clob_blob_sqlstr  LONG; --VARCHAR2(32000);
	v_clbl_string				LONG; --VARCHAR2(32000);
	v_sqlstr					LONG; --VARCHAR2(32000);
	v_string					LONG; --VARCHAR2(32000);
	v_insert_string				LONG; --VARCHAR2(32000);
		
	v_Col_Name					VARCHAR2(30);	
 	v_Data_Type					VARCHAR2(30);	
	
	v_Col_Name1					VARCHAR2(30);	
 	v_Data_Type1				VARCHAR2(30);	
	v_prikeyCol_Name			VARCHAR2(30);

	v_pcols       				VARCHAR2(4000);
	v_pvals       				VARCHAR2(4000);
	v_Cols        				VARCHAR2(15000);
	v_vals        				VARCHAR2(30000);

	v_msg						NUMBER;
    
    v_errormsage                VARCHAR2(1000);
    
    v_len_check                 NUMBER;
    
    v_vals_CB                   VARCHAR2(100); -- for handling CLOB and BLOB
    v_Clob_Blob_flag            VARCHAR2(10):='FALSE';
	
	TYPE C_REF_CUR IS REF CURSOR;
	REF_COLNAME C_REF_CUR;
	
BEGIN

    --DBMS_OUTPUT.ENABLE(1000000); -- to increase the buffer of DBMS_OUTPUT function
   
	--Z_TRIGGER_CREATION_TBL
	
   v_Cols := NULL;
   v_Vals := NULL;
   
	v_ErrorFlag:=1;
	-- delete all records from Z_TRIGGER_CREATION_TBL  
	EXECUTE IMMEDIATE 'TRUNCATE TABLE Z_TRIGGER_CREATION_TBL';
    

	v_msg := 105;
    
       v_ErrorFlag:=1.2;
	-- list all those table which are having primary key and not having primary key
	-- execpt all those tables which are having primary key to all the columns in a table    
	FOR z IN (SELECT Table_Name, DECODE(Constraint_Type,'P','PK','NOPK') Check_Constraints
              FROM		
                  (SELECT ut.Table_Name, uc.Constraint_Type 
                   FROM USER_TABLES ut, USER_CONSTRAINTS uc
                   WHERE ut.Table_Name = uc.Table_Name
                     AND uc.constraint_type='P'
                     AND ut.Table_Name IN(SELECT Table_Name
                                          FROM USER_CONSTRAINTS
                                          WHERE Constraint_Type='P')
                     AND ut.Table_Name NOT IN(SELECT Table_Name FROM USER_TABLES A
                                              WHERE (SELECT COUNT(1) 
                                                     FROM USER_CONS_COLUMNS b,USER_CONSTRAINTS c 
                                                     WHERE A.Table_Name = b.Table_Name 
                                                       AND b.Constraint_Name = c.Constraint_Name 
                                                       AND c.Constraint_Type='P') = (SELECT COUNT(1) 
                                                                                     FROM USER_TAB_COLUMNS b 
                                                                                     WHERE A.Table_Name=b.Table_Name))
                    UNION
                    SELECT Table_Name, NULL FROM USER_TABLES
                    WHERE Table_Name NOT IN(SELECT Table_Name
                                           FROM USER_CONSTRAINTS
                                           WHERE Constraint_Type='P') AND table_name NOT IN('Z_TRIGGER_CREATION_TBL','Z_REPLICATION_DATA', 'Z_REPLICATION_DATA_EX', 'Z_TARGET_REP_DATA', 'Z_TARGET_REP_DATA_EX'))abc
        --				  WHERE table_name='PAYMENTECH_TRANSACTIONS'
                  ORDER BY Check_Constraints ASC
             )
	LOOP
      
          -- these condition is for primary key columns 
          IF z.CHECK_CONSTRAINTS ='PK' THEN
                v_Table_Name:=z.table_name;
    			
                  IF v_msg= 106 THEN
                      EXECUTE IMMEDIATE 'INSERT INTO Z_TRIGGER_CREATION_TBL VALUES ('''||CHR(10)||'-- Trigger Script for primary key tables'')'||CHR(10)||'';
                      --DBMS_OUTPUT.PUT_LINE(''||CHR(10)||'Trigger Script for primary key tables '||CHR(10));
                      v_msg:= 107;			  
                  END IF;				
    			
                BEGIN
                    v_pcols      := NULL;
                    v_pvals      := NULL;
                    v_Cols       := NULL;
                    v_vals       := NULL;

                    -- query for those cloumns which are having primary key difined 
                    v_ErrorFlag:=11;
                    v_pk_columns:=
                    ' SELECT Column_Name '||
                    ' FROM USER_CONS_COLUMNS ACC, USER_CONSTRAINTS AC  '||
                    ' WHERE ACC.Constraint_Name = AC.Constraint_Name   '||
                    '   AND AC.Constraint_Type  = ''P''				   '||
                    '   AND ACC.Table_Name	  = '''||v_Table_Name||'''';

                    -- start loop for columns difined with primary key 
                   OPEN REF_COLNAME FOR v_pk_columns;
                    LOOP
                      FETCH REF_COLNAME INTO v_prikeyCol_Name;
                       EXIT WHEN REF_COLNAME%NOTFOUND;
    				   
                         -- pk columns
                         v_ErrorFlag:=12;
                         IF v_pcols IS NOT NULL THEN
                             v_pcols := v_pcols ||'^~'||v_prikeyCol_Name;
                         ELSE
                             v_pcols := v_prikeyCol_Name;
                         END IF;

                         -- pk values
                         v_ErrorFlag:=13;
                         IF v_pvals IS NOT NULL THEN
                             v_pvals := v_pvals||'|| ''^~'' ||'||' :OLD.'||v_prikeyCol_Name;
                         ELSE
                             v_pvals := ':OLD.'||v_prikeyCol_Name;
                         END IF;
                    END LOOP;	 
    				
                    -- query to get column_name and there data_type for those tables, which are having pk 
                    v_ErrorFlag:=14;
                    v_sqlString:= 
                      ' SELECT COLUMN_NAME, DATA_TYPE '||
                      ' FROM USER_TAB_COLUMNS utb     '||
                      ' WHERE column_name NOT IN(SELECT Column_Name '||
                      '  	     				 FROM USER_CONS_COLUMNS acc, USER_CONSTRAINTS ac '||
                      '		 				     WHERE acc.table_name = utb.table_name		  	 '|| 
                      '							   AND ACC.Constraint_Name = AC.Constraint_Name  '||
                      '		   				       AND AC.Constraint_Type  = ''P'')              '||
                      '   AND utb.table_name='''||v_Table_Name||'''';
    				  
                    EXECUTE IMMEDIATE v_sqlString;

                    -- start loop
                    OPEN REF_COLNAME FOR v_sqlString;
                     LOOP
                      FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
                       EXIT WHEN REF_COLNAME%NOTFOUND;
                            -- only column values for those columns which are having data type like varchar, char number, integer
                            IF v_Data_Type IN ('VARCHAR2', 'CHAR', 'NUMBER', 'INTEGER','DATE') THEN
                               v_Cols  := v_Cols ||'^~'||v_Col_Name;
                            END IF;

                            -- all values
                            IF v_Data_Type = 'DATE' THEN
                               v_vals := v_vals ||'|| ''^~'' ||'||'''TO_DATE(''''''|| TO_CHAR (:NEW.'||v_Col_Name||', ''MMDDYYYY HH24MISS'')||'''''', ''''MMDDYYYY HH24MISS'''')''';
                            ELSIF v_Data_Type IN ('VARCHAR2', 'CHAR', 'NUMBER', 'INTEGER') THEN
                               v_vals := v_vals ||'|| ''^~'' ||'||' :NEW.'||v_Col_Name;
                            END IF;
                            
                            -- Actually Do nothing when CLOB/BLOB data type is coming, just taking in variable as null.. 
                            -- we can remove the  below if condition code
                            IF v_Data_Type IN ('BLOB','CLOB') THEN
                               v_vals_CB :='''''';
                               v_Clob_Blob_flag:='TRUE'; -- it will true when there is any clobn/blob in table
                            END IF;
                     END LOOP;
    				 
                     IF v_vals <> '''''' THEN
                        v_vals := SUBSTR(v_vals,11);
                        IF SUBSTR(v_vals,1,2)= '||' THEN
                          v_vals := SUBSTR(v_vals,3);
                        END IF;
                     END IF;
                ----------------------------------------------------------------------------------------------------

                    -- here stars the trigger creation scripts
                    v_sql := 'CREATE OR REPLACE TRIGGER '||SUBSTR(v_Table_Name,1,24)||'_REPL'           ||CHR(10)||
                    ' AFTER INSERT OR UPDATE OR DELETE'															||CHR(10)||
                    ' ON '	   	  		 																||CHR(10)||
                    '	'||v_Table_Name																	||CHR(10)||
                    ' FOR EACH ROW '																	||CHR(10)||
                    ' DECLARE '	   																		||CHR(10)||
                    ' 	v_Ref_Id      	NUMBER; '														||CHR(10)||
                    '	v_Operation   	VARCHAR2(10); '													||CHR(10)||
                    '	v_pcols       	VARCHAR2(1000)	:= NULL; '										||CHR(10)||
                    '	v_pvals       	VARCHAR2(1000)	:= NULL; '										||CHR(10)||
                    '	v_Cols        	VARCHAR2(4000)	:= NULL; '										||CHR(10)||
                    '	v_vals        	VARCHAR2(4000)	:= NULL; '										||CHR(10)||
                    '	v_child        	VARCHAR2(2); '													||CHR(10)||
                    ' BEGIN '							   						   						||CHR(10)||
                    ' '                                                                                 ||CHR(10)||
                    '   SELECT SRC_C_REPL.REPLICATION_SEQ.NEXTVAL INTO v_Ref_Id FROM Dual;'             ||CHR(10)||		 
                    ' '                                                                                 ||CHR(10)||	
                    '   IF DELETING THEN '																||CHR(10)||
                    '      v_operation := ''DELETE''; '												||CHR(10)||
                    '      v_pcols     := '''||v_pcols||'''; '										||CHR(10)||
                    '      v_pvals     := '||v_pvals||';'	  											||CHR(10)||
                    '   END IF;	'		   																||CHR(10)||
                    ' '                                                                                 ||CHR(10)||
                    '   IF UPDATING THEN '																||CHR(10)||
                    '      v_operation := ''UPDATE''; '													||CHR(10)||
                    '      v_pcols     := '''||v_pcols||'''; '											||CHR(10)||
                    '      v_pvals     := '||v_pvals||'; '	  											||CHR(10)||
                    '      v_cols      := '''||SUBSTR(v_Cols,3)||'''; '									||CHR(10)||
                    '      v_vals      := '||NVL(v_vals,'''''')||'; ' 							        ||CHR(10)||
                    '   END IF; ' 		   				 											    ||CHR(10)||
                    ' '                                                                                 ||CHR(10)||
                    '   IF INSERTING THEN '																||CHR(10)||
                    '      v_operation := ''INSERT''; '													||CHR(10);
    --				'      v_pcols     := '''||v_pcols||'''; '										||CHR(10)||
    --				'      v_pvals     := '||REPLACE(v_pvals,':OLD.',':NEW.')||'; '					||CHR(10);
    				
                    IF v_Clob_Blob_flag = 'TRUE' THEN
                      v_insert_string:=	
                        '      v_cols      := '''||v_pcols||''';	'	   	 							||CHR(10)||				  
                        '      v_vals      := '||REPLACE(v_pvals,':OLD.',':NEW.')||';	'				||CHR(10)||
                        '   END IF;	';
                        
                        v_Clob_Blob_flag:= 'FALSE'; -- mkae false clob/blob work is done
                    ELSE	
                      v_insert_string:=	
                        '      v_cols      := '''||v_pcols||'^~'||SUBSTR(v_Cols,3)||''';	'	   	 				||CHR(10)||
                        '      v_vals      := '||REPLACE(v_pvals,':OLD.',':NEW.')||'|| ''^~'' ||'||NVL(v_vals,'''''')||';	'||CHR(10)||
                        '   END IF;	';
                    END IF; 		
    				
                    --- break for clob, blob, long raw insertion in SRC_C_REPL.REPLICATION_DATA_EX
    				
                    -- query will return only those column name which are having blob, clob datatype 				
                    v_clob_blob_strSQL := 'SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '''||v_Table_Name||''' AND DATA_TYPE IN(''BLOB'',''CLOB'')';
                    EXECUTE IMMEDIATE v_clob_blob_strSQL;
    				
                    -- start loop for clob and blob
                    OPEN REF_COLNAME FOR v_clob_blob_strSQL;
                     LOOP
                      FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
                       EXIT WHEN REF_COLNAME%NOTFOUND;
    				     
                         -- for each blob and clob column will have to generate seprate insert statmenet
                         IF v_Data_Type='BLOB' THEN
                             v_clbl_string:=
                               '     INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
                               '      VALUES (v_ref_id, ''BLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
                               '	';
                         ELSIF v_Data_Type='CLOB' THEN
                             v_clbl_string:=
                               '     INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
                               '      VALUES (v_ref_id, ''CLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
                               ' ';
                         END IF;	   
    					 
                            v_string := v_string||CHR(10)||v_clbl_string;
    				   		
                            v_Flagcnt:='TRUE';		
                     END LOOP;
    					
                    IF v_Flagcnt='TRUE' THEN
                        -- insert block for clob and blob data types	
                        v_sqlstr:=	
                           ' '                                                                            ||CHR(10)||					  			   
                           '   v_child :=''Y'';'			  					  	  			          ||CHR(10)||
                           ' '                                                                            ||CHR(10)||
                           '   IF INSERTING OR UPDATING THEN '										      ||CHR(10)||
                           '     '||v_string 	 		  	   											  ||CHR(10)||          
                           '     v_child :=''N'';'			  					  	  			          ||CHR(10)||
                           '   END IF;'			  					  	  			          		  	  ||CHR(10)||
                           '    ';
                        -- make string empty for next blob and clob variables	
                        v_string:='';	
    				
                    END IF;

                    -- final block for inserting into replication_data table	 						 
                    v_without_clob_blob_sqlstr:=
                        ' '                                                                               ||CHR(10)||
                        '   INSERT INTO SRC_C_REPL.REPLICATION_DATA   '||CHR(10)||
                        '    VALUES (v_ref_id,SYSDATE,'''||v_tble_SchemaName||''','''||v_Table_Name||''',v_operation, v_pcols, v_pvals,v_cols,v_vals,nvl(v_child,''N''),0);'	||CHR(10)||
                        ' '                                                                                 ||CHR(10)||
                        ' END;	'                                                                           ||CHR(10)||
                        '/';
                        
                        -- taken the variable for checking the length of the inserted record
                        --v_len_check:=LENGTH(v_SQL||v_insert_string||CHR(10)||v_without_clob_blob_sqlstr||CHR(10));
                       
    				
                    BEGIN 
                        -- flag is difine for clob and blob trigger creation script
                        -- if the flag is true then it means that the script is having
                        -- clob and blob insertion script                                                  
                        IF v_Flagcnt='TRUE'  THEN 
                                  
                          v_sql_insert_str1:= v_SQL||v_insert_string||CHR(10)||v_sqlstr||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                                  
                          INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                          COMMIT;
                          v_Flagcnt:='FLASE';
                        ELSE
                                
                          v_sql_insert_str1:= v_SQL||v_insert_string||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                                  
                          INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                          COMMIT;
                        END IF;
                    EXCEPTION
                      WHEN OTHERS THEN
                        v_errormsage := SUBSTR(SQLERRM,1,100);
                         NULL;
                    END;

                    v_Trigger_Count := v_Trigger_Count +1 ;
    				
                    --DBMS_OUTPUT.PUT_LINE('Trigger created. -- '||SUBSTR(v_Table_Name,1,24)||'_REPL');

                EXCEPTION
                    WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Trigger not created for table '||v_Table_Name||' error is '||SQLERRM);
                END;
                
                COMMIT;
                
                -- variable making empty
                v_sql_insert_str1:=NULL;
                
          ELSIF z.CHECK_CONSTRAINTS ='NOPK' THEN
    		
                  v_Table_Name       := NULL;
                  v_sql		         := NULL;
                  v_pcols 	         := NULL;
                  v_pvals 	         := NULL;
                  v_Cols  	         := NULL;
                  v_vals  	         := NULL;
                  v_clob_blob_strSQL := NULL;
                  v_clbl_string 	 := NULL;
                  v_string      	 := NULL;
    			  
                  v_Table_Name:=z.table_name;
    			  
                  IF v_msg= 105 THEN
                      EXECUTE IMMEDIATE 'INSERT INTO Z_TRIGGER_CREATION_TBL VALUES ('''||CHR(10)||'-- Trigger Script for those tables which are not having primary key '')'||CHR(10)||'';
                      --DBMS_OUTPUT.PUT_LINE(''||CHR(10)||'Trigger script for those tables which are not having primary key'||CHR(10));
                      v_msg:=106;			  
                  END IF;				
    			    			  								  
                    v_sqlString:= 
                      ' SELECT COLUMN_NAME, DATA_TYPE '||
                      ' FROM USER_TAB_COLUMNS utb     '||
                      ' WHERE column_name NOT IN(SELECT Column_Name '||
                      '  	     				 FROM USER_CONS_COLUMNS acc, USER_CONSTRAINTS ac '||
                      '		 				     WHERE acc.table_name = utb.table_name		  	 '|| 
                      '							   AND ACC.Constraint_Name = AC.Constraint_Name  '||
                      '		   				       AND AC.Constraint_Type  = ''P'')              '||
                      '   AND utb.table_name='''||v_Table_Name||'''';
     
                  EXECUTE IMMEDIATE v_sqlString;
    		  	  
                  v_Table_Name:=''||v_Table_Name||'';
    		  
                BEGIN
                     OPEN REF_COLNAME FOR v_sqlString;
                      LOOP
                       FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
                       EXIT WHEN REF_COLNAME%NOTFOUND;				  	  
    					  
                          v_cols := v_cols||'^~'||v_Col_Name;
    					  	  
                          IF v_Data_Type='DATE' THEN
                             v_vals  := v_vals ||'|| ''^~'' ||'||'''TO_DATE(''''''|| TO_CHAR (:NEW.'||v_Col_Name||', ''MMDDYYYY HH24MISS'')||'''''', ''''MMDDYYYY HH24MISS'''')''';
                          ELSIF v_Data_Type IN ('VARCHAR2','CHAR','NUMBER') THEN
                             v_vals := v_vals ||'|| ''^~'' ||'||' :NEW.'||v_Col_Name; 
                          END IF;			  
    					   
                      END LOOP;
    		  
                      v_vals := SUBSTR(v_vals,11); --,LENGTH(v_vals));
                     -----------------------------------------------------------------------------
    				 
                      v_sql := 'CREATE OR REPLACE TRIGGER '||SUBSTR(v_Table_Name,1,24)||'_REPL'           ||CHR(10)||
                      ' AFTER INSERT '															  		  ||CHR(10)||
                      ' ON '	   	  		 															  ||CHR(10)||
                      '	'||v_Table_Name																	  ||CHR(10)||
                      ' FOR EACH ROW '																	  ||CHR(10)||
                      ' DECLARE '	   																	  ||CHR(10)||
                      '      v_Ref_Id      	NUMBER; '													  ||CHR(10)||
                      '      v_Operation   	VARCHAR2(10); '												  ||CHR(10)||
                      '      v_pcols       	VARCHAR2(1000)	:= NULL; '									  ||CHR(10)||
                      '      v_pvals       	VARCHAR2(1000)	:= NULL; '									  ||CHR(10)||
                      '      v_Cols        	VARCHAR2(4000)	:= NULL; '									  ||CHR(10)||
                      '      v_vals        	VARCHAR2(4000)	:= NULL; '									  ||CHR(10)||
                      '      v_child        	VARCHAR2(2); '											  ||CHR(10)||
                      ' BEGIN '							   						   						  ||CHR(10)||
                      ' '                                                                                 ||CHR(10)||
                      '   SELECT SRC_C_REPL.REPLICATION_SEQ.NEXTVAL INTO v_Ref_Id FROM Dual; '			  ||CHR(10)||
                      ' '                                                                                 ||CHR(10)||
                      '   IF INSERTING THEN '															  ||CHR(10)||
                      '      v_operation := ''INSERT''; '												  ||CHR(10)||
                      '      v_cols      := '''||SUBSTR(v_Cols,3)||''';	'	   							  ||CHR(10)||
                      '      v_vals      := '||NVL(v_vals,'''''')||';        '										  ||CHR(10)||
                      '   END IF;';
    				
                    --- break for clob, blob, long raw insertion in SRC_C_REPL.REPLICATION_DATA_EX
    				
                    -- query will return only those column name which are having blob, clob datatype 				
                    v_clob_blob_strSQL := 'SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '''||v_Table_Name||''' AND DATA_TYPE IN(''BLOB'',''CLOB'')';
                    EXECUTE IMMEDIATE v_clob_blob_strSQL;
    				
                    -- start loop for clob and blob
                    OPEN REF_COLNAME FOR v_clob_blob_strSQL;
                     LOOP
                      FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
                       EXIT WHEN REF_COLNAME%NOTFOUND;
    				     
                         -- for each blob and clob column will have to generate seprate insert statmenet
                         IF v_Data_Type='BLOB' THEN
                             v_clbl_string:=
                               '   INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
                               '    VALUES (v_ref_id, ''BLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
                               ' ';
                         ELSIF v_Data_Type='CLOB' THEN
                             v_clbl_string:=
                               '   INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)||CHR(9)|| 
                               '    VALUES (v_ref_id, ''CLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
                               ' ';
                         END IF;	   
    					 
                            v_string := v_string||CHR(10)||CHR(9)||v_clbl_string;
    				   		
                            v_Flagcnt:='TRUE';		
                     END LOOP;

                    IF v_Flagcnt='TRUE' THEN
                        -- insert block for clob and blob data types	
                        v_sqlstr:=	
                           ' '                                                                               ||CHR(10)||					  			   
                           '   v_child :=''Y'';'			  					  	  					     ||CHR(10)||
                           ' '                                                                               ||CHR(10)||
                           '   IF INSERTING OR UPDATING THEN '											     ||
                           '       '||v_string	 		  	   											     ||CHR(10)||          
                           '          v_child :=''N'';'														 ||CHR(10)||
                           '   END IF;'			  					  	  			        				 ||
                           '    ';

                       -- make string empty for next blob and clob variables	
                       v_string:='';	
                    END IF;

                    -- final block for inserting into replication_data table	 			
                    v_without_clob_blob_sqlstr:=
                        ' '                                                                                 ||CHR(10)||
                        '   INSERT INTO SRC_C_REPL.REPLICATION_DATA   '									   	 ||CHR(10)||
                        '    VALUES (v_ref_id,SYSDATE,'''||v_tble_SchemaName||''','''||v_Table_Name||''',v_operation, v_pcols, v_pvals,v_cols,v_vals,nvl(v_child,''N''),0);'	||CHR(10)||
                        ' '                                                                                 ||CHR(10)||
                        ' END; '                                                                            ||CHR(10)||
                        '/';
                        
                    BEGIN
                        -- flag is difine for clob and blob trigger creation script
                        IF v_Flagcnt='TRUE' THEN 
                           -- to avoid the inserting concatenation is too long error, inserting through the variable
                           v_sql_insert_str1:= v_SQL||CHR(10)||v_sqlstr||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                        
                           INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                           COMMIT;
                          v_Flagcnt:='FLASE';
                        ELSE
                           -- to avoid the inserting concatenation is too long error, inserting through the variable
                           v_sql_insert_str1:=v_SQL||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                        
                           INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                           COMMIT;
                        END IF;
                    EXCEPTION
                      WHEN OTHERS THEN
                          v_errormsage:= SUBSTR(SQLERRM,1,100);
                         DBMS_OUTPUT.PUT_LINE(v_errormsage);
                    END;

                    COMMIT;
                    
                     v_vals      := NULL;
                     v_Cols      := NULL;
    				  
                     v_Col_Name  := NULL;
                     v_Data_Type := NULL;
    					
                     v_Trigger_Count := v_Trigger_Count + 1;

                     --DBMS_OUTPUT.PUT_LINE('Trigger created. -- '||SUBSTR(v_Table_Name,1,24)||'_REPL');

                EXCEPTION
                  WHEN OTHERS THEN
                    DBMS_OUTPUT.PUT_LINE('Trigger not created for table '||v_Table_Name||' error is '||SQLERRM);
                END;		 
          END IF;
          
          -- variable making empty
          v_sql_insert_str1:=NULL;
    
	END LOOP;

	COMMIT;

	v_Trigger_Count := v_Trigger_Count;

	-- list of all those tables which are having primary key to 
	-- all the columns in a table
	FOR i IN (SELECT Table_Name FROM USER_TABLES A
			  WHERE (SELECT COUNT(1) 
				     FROM USER_CONS_COLUMNS b,USER_CONSTRAINTS c 
				   	 WHERE A.Table_Name = b.Table_Name 
				       AND b.Constraint_Name = c.Constraint_Name 
					   AND c.Constraint_Type='P') = (SELECT COUNT(1) 
					 	 						     FROM USER_TAB_COLUMNS b 
												   	 WHERE A.Table_Name=b.Table_Name)
			  ORDER BY Table_Name ASC)
	LOOP
	   BEGIN
             v_Table_Name       := NULL;
             v_sql		        := NULL;
             v_pcols 	        := NULL;
             v_pvals 	        := NULL;
             v_Cols  	        := NULL;
             v_vals  	        := NULL;
             v_clob_blob_strSQL := NULL;
             v_clbl_string 	    := NULL;
             v_string      	    := NULL;

	         v_Table_Name:= i.Table_Name;
	   	    
              IF v_msg = 107 THEN
                  EXECUTE IMMEDIATE 'INSERT INTO Z_TRIGGER_CREATION_TBL VALUES ('''||CHR(10)||'-- Trigger Script for those tables which are having primary key to all the columns in a table.'')'||CHR(10)||'';
                  --DBMS_OUTPUT.PUT_LINE(''||CHR(10)||'TRIGGER SCRIPT FOR THOSE TABLE WHICH ARE HAVING PRIMARY KEY FOR ALL COLUMNS IN A TABLE '||CHR(10));
                  v_msg:=NULL;			  
              END IF;		  

			 -- query for those cloumns which are having primary key difined 
			 v_pk_columns:=
			  ' SELECT Column_Name '||
			  ' FROM USER_CONS_COLUMNS ACC, USER_CONSTRAINTS AC  '||
			  ' WHERE ACC.Constraint_Name = AC.Constraint_Name   '||
			  '   AND AC.Constraint_Type  = ''P''				   '||
			  '   AND ACC.Table_Name	  = '''||v_Table_Name||'''';

			 -- start loop for columns difined with primary key 
   			 OPEN REF_COLNAME FOR v_pk_columns;
		      LOOP
		       FETCH REF_COLNAME INTO v_prikeyCol_Name;
		        EXIT WHEN REF_COLNAME%NOTFOUND;

			     -- pk columns
				 IF v_pcols IS NOT NULL THEN
					 v_pcols := v_pcols ||'^~'||v_prikeyCol_Name;
				 ELSE
					 v_pcols := v_prikeyCol_Name;
				 END IF;

				 -- pk values
				 IF v_pvals IS NOT NULL THEN
					 v_pvals := v_pvals||'|| ''^~'' ||'||' :OLD.'||v_prikeyCol_Name;
				 ELSE
					 v_pvals := ':OLD.'||v_prikeyCol_Name;
				 END IF;
			  END LOOP;	 
		  
		     v_sqlstring := 'SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '''||v_Table_Name||'''';
		     EXECUTE IMMEDIATE v_sqlstring; 
		  
			 OPEN REF_COLNAME FOR v_sqlString;
			  LOOP
			   FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
			   EXIT WHEN REF_COLNAME%NOTFOUND;				  	  
				  
				  v_cols := v_cols||'^~'||v_Col_Name;
				  
				  IF v_Data_Type='DATE' THEN
				    v_vals  := v_vals ||'|| ''^~'' ||'||'''TO_DATE(''''''|| TO_CHAR (:NEW.'||v_Col_Name||', ''MMDDYYYY HH24MISS'')||'''''', ''''MMDDYYYY HH24MISS'''')''';
				  ELSE
				    IF v_Data_Type IN ('VARCHAR2','CHAR','NUMBER','DATE') THEN
				       v_vals := v_vals ||'|| ''^~'' ||'||' :NEW.'||v_Col_Name;
					END IF;
				  END IF;			  
				   
		      END LOOP;
	  
	  		  v_vals := SUBSTR(v_vals,11);--,LENGTH(v_vals));
			 -----------------------------------------------------------------------------
			 
			  v_sql := 'CREATE OR REPLACE TRIGGER '||SUBSTR(v_Table_Name,1,24)||'_REPL'         ||CHR(10)||
			  ' AFTER INSERT '																	||CHR(10)||
			  ' ON '	   	  		 															||CHR(10)||
			  '	'||v_Table_Name																	||CHR(10)||
			  ' FOR EACH ROW '																	||CHR(10)||
			  ' DECLARE '	   																	||CHR(10)||
			  '      v_Ref_Id      	NUMBER; '													||CHR(10)||
			  '      v_Operation   	VARCHAR2(10); '												||CHR(10)||
			  '      v_pcols       	VARCHAR2(1000)	:= NULL; '									||CHR(10)||
			  '      v_pvals       	VARCHAR2(1000)	:= NULL; '									||CHR(10)||
			  '      v_Cols        	VARCHAR2(4000)	:= NULL; '									||CHR(10)||
			  '      v_vals        	VARCHAR2(4000)	:= NULL; '									||CHR(10)||
			  '      v_child        VARCHAR2(2); '												||CHR(10)||
			  ' BEGIN '							   						   						||CHR(10)||
			  ' '                                                                               ||CHR(10)||
			  '   SELECT SRC_C_REPL.REPLICATION_SEQ.NEXTVAL INTO v_Ref_Id FROM Dual; '			||CHR(10)||
			  ' '                                                                               ||CHR(10)||
			  '   IF INSERTING THEN '															||CHR(10)||
			  '      v_operation := ''INSERT''; '												||CHR(10)||
			  '      v_pcols     := '''||v_pcols||'''; '										||CHR(10)||
			  '      v_pvals     := '||REPLACE(v_pvals,':OLD.',':NEW.')||'; '					||CHR(10)||
			  '      v_cols      := '''||SUBSTR(v_Cols,3)||''';	'	   							||CHR(10)||
			  '      v_vals      := '||NVL(v_vals,'''''')||';        '							||CHR(10)||
			  '   END IF;	';
			
			--- break for clob, blob, long raw insertion in SRC_C_REPL.REPLICATION_DATA_EX
			
			-- query will return only those column name which are having blob, clob datatype 				
	  	    v_clob_blob_strSQL := 'SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '''||v_Table_Name||''' AND DATA_TYPE IN(''BLOB'',''CLOB'')';
			EXECUTE IMMEDIATE v_clob_blob_strSQL;
			
			-- start loop for clob and blob
		    OPEN REF_COLNAME FOR v_clob_blob_strSQL;
		     LOOP
		      FETCH REF_COLNAME INTO v_Col_Name, v_Data_Type;
		       EXIT WHEN REF_COLNAME%NOTFOUND;
			     
				 -- for each blob and clob column will have to generate seprate insert statmenet
				 IF v_Data_Type='BLOB' THEN
					 v_clbl_string:=
					   '   INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)|| 
					   '    VALUES (v_ref_id, ''BLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
					   ' ';
				 ELSIF v_Data_Type='CLOB' THEN
					 v_clbl_string:=
					   '   INSERT INTO SRC_C_REPL.REPLICATION_DATA_EX (replication_id, coltype, colname )     ' ||CHR(10)||CHR(9)|| 
					   '    VALUES (v_ref_id, ''CLOB'', '''||v_Col_Name||''');		 		 	   ' ||CHR(10)||
					   ' ';
				 END IF;	   
				 
				    v_string := v_string||CHR(10)||CHR(9)||v_clbl_string;
			   		
				  	v_Flagcnt:='TRUE';		
		     END LOOP;

			IF v_Flagcnt='TRUE' THEN
				-- insert block for clob and blob data types	
				v_sqlstr:=	
			       ' '                                          ||CHR(10)||					  			   
				   '   v_child :=''Y'';'			  			||CHR(10)||
				   ' '                                          ||CHR(10)||	
				   '   IF INSERTING OR UPDATING THEN '		    ||
				   '        '||v_string ||'' 		  	   		    ||CHR(10)||          
				   '      v_child :=''N'';'			  		    ||CHR(10)||
				   '   END IF;'			  					    ||
				   '    ';
			   -- make string empty for next blob and clob variables	
			   v_string:='';	
			END IF;

			-- final block for inserting into replication_data table	 	
			v_without_clob_blob_sqlstr:=
				' '                                             ||CHR(10)||
				'   INSERT INTO SRC_C_REPL.REPLICATION_DATA   ' ||CHR(10)||
				'    VALUES (v_ref_id,SYSDATE,'''||v_tble_SchemaName||''','''||v_Table_Name||''',v_operation, v_pcols, v_pvals,v_cols,v_vals,nvl(v_child,''N''),0);'	||CHR(10)||
				' 	   										  ' ||CHR(10)||
				' END;										  ' ||CHR(10)||
				'/';
			
            BEGIN
                -- flag is difine for clob and blob trigger creation script
                IF v_Flagcnt='TRUE' THEN 
                
                   v_sql_insert_str1:= v_SQL||CHR(10)||v_sqlstr||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                
                  INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                  COMMIT;
                  v_Flagcnt:='FLASE';
                ELSE
                
                    v_sql_insert_str1:= v_SQL||CHR(10)||v_without_clob_blob_sqlstr||CHR(10);
                
                  INSERT INTO Z_TRIGGER_CREATION_TBL VALUES (v_sql_insert_str1);
                  COMMIT;
                END IF;
            EXCEPTION
              WHEN OTHERS THEN
                  v_errormsage:= SUBSTR(SQLERRM,1,100);
                 DBMS_OUTPUT.PUT_LINE(v_errormsage);
            END;

            COMMIT;
            
			 v_vals      :=NULL;
			 v_Cols      :=NULL;
			 
			 v_Col_Name  :=NULL;
			 v_Data_Type :=NULL;		  
		  
	         v_Trigger_Count := v_Trigger_Count + 1;
		  	 
			 --DBMS_OUTPUT.PUT_LINE('Trigger created. -- '||SUBSTR(v_Table_Name,1,24)||'_REPL');

	   EXCEPTION
	     WHEN OTHERS THEN
		   DBMS_OUTPUT.PUT_LINE('Trigger not created for table '||v_Table_Name||' error is '||SQLERRM);
	   END;	
       
       v_sql_insert_str1 := NULL;
       
	END LOOP;

	COMMIT;
	
    
	o_Message := v_Trigger_Count;
	DBMS_OUTPUT.PUT_LINE('Total triggers created are - '||v_Trigger_Count);
EXCEPTION
	WHEN OTHERS THEN
		o_Message := 'ERROR NO '||TO_CHAR(v_ErrorFlag)||' '||SQLERRM;
END GENERATE_TRIGGER;
/

****************************************  Automat Replication Triggers ****************************************




1. Take a bowl of yogurt. Grind some black mustard and add it inside the yogurt and eat it followed by a glass of buttermilk to cure piles.
2. Drink 1/4 liter (0.1 US gal) of goat milk curdled for a night blended with the same amount of carrot juice to cure piles, especially bleeding piles.
3. Combine one tablespoon of roasted cumin seeds with a tablespoon of normal cumin seeds, both should be finally mixed in a glass of water and you will have one good home remedy for hemorrhoids to cure piles. Drink the mixture once every day.
4. Increase fiber in your diet to soften your stool to relieve pain and cure piles.
5. Take some figs and leave them in water for a night and next day eat the half of the figs and drink half the water they were soaked in on an empty stomach in the morning. Do the same in evening to cure piles.
6. Make a juice of bitter gourd and take it with buttermilk for hemorrhoid treatment.
7. For bleeding piles take an onion with three spoons of sugar, twice a day. If you can manage it then it is one of the fastest treatment to cure piles.
8. Eat dates rather then taking laxatives as dates are natural laxatives which won't put you on risk for dependence. this helps when you have constipation.