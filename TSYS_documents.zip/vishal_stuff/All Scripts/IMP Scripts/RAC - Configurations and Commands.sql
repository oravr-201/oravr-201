/*

-- Best DOC for RAC listener understanding
http://docs.oracle.com/html/B13681_01/rac_cfg.htm#i1024896


*/




/*

Log in as the "oracle" user and add the following lines at the end of the "/home/oracle/.bash_profile" file.

*/

----- .bash_profile file
# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs
# Oracle Settings
TMP=/tmp; export TMP
TMPDIR=$TMP; export TMPDIR

ORACLE_HOSTNAME=racnode1.tsysacquiring.org; export ORACLE_HOSTNAME
ORACLE_UNQNAME=racdb; export ORACLE_UNQNAME
ORACLE_BASE=/opt/app/oracle; export ORACLE_BASE
GRID_HOME=/opt/app/11.2.0.3/grid; export GRID_HOME
DB_HOME=$ORACLE_BASE/product/11.2.0.3/db_1; export DB_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
#ORACLE_SID=RAC1; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$BASE_PATH; export PATH
LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib; export LD_LIBRARY_PATH
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

if [ $USER = "oracle" ]; then
  if [ $SHELL = "/bin/ksh" ]; then
    ulimit -p 16384
    ulimit -n 65536
  else
    ulimit -u 16384 -n 65536
  fi
fi

alias grid_env='. /home/oracle/grid_env'
alias db_env='. /home/oracle/db_env'

PATH=$PATH:$HOME/bin
export PATH


---Create a file called "/home/oracle/grid_env" with the following contents.
ORACLE_SID=+ASM1; export ORACLE_SID
ORACLE_HOME=$GRID_HOME; export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$BASE_PATH; export PATH

LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib; export LD_LIBRARY_PATH
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH


---Create a file called "/home/oracle/db_env" with the following contents.
ORACLE_SID=RAC1; export ORACLE_SID
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
PATH=$ORACLE_HOME/bin:$BASE_PATH; export PATH

LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib; export LD_LIBRARY_PATH
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH



   
--->>>RAC Best Practices Oracle 11G R2 version 11.2.0.3.0<<<---


/*

Check-Points for Install....

. Check ipTables are off
. Suse-Linux is disabled

. Private/Public/Virtual/Scan IP address are setup properly
. Check /etc/hosts are configure for Private/Public/Virtual/Scan IPs
. Check /etc/resolv.conf has the DNS entry

. DNS/GNS --- Domain name service configuration
. NTPD/CSST --- Time sync server configurations

. Create ASM and Oracle Groups for users
. Create grid/oracle users and their directory structures and their privileges

. Check all Packages/Libs are install properly

. Password Less connectivity between all nodes are working

. Before installation run the ./runcluvfy utility for verifications

. Install Grid Software first
. At the end of Grid software installation, run the root.sh scripts from root privileged user

. Install oracle software and created database on same node
. Ran oracle software root.sh script from root privileged user

. Once the database is created check all default values like....
 	-- LOCAL_LISTENER
 	-- REMOTE_LISTENER
 	-- where are the Archivelog files are generated/created, if they are getting created in OCT_VOTE disk the move them to ORADATA disk group.

. Start and Check OEM connectivity from remotly access


*/



--Create the Oracle Cluster Database 
/*
	The database creation process should only be performed from one of the Oracle RAC nodes in the cluster (racnode1).
Use the Oracle Database Configuration Assistant (DBCA) to create the clustered database.

Before executing the DBCA, make certain that the $ORACLE_HOME and $PATH are set appropriately for the $ORACLE_BASE/product/11.2.0/dbhome_1 environment. 
Setting environment variables in the login script for the oracle user account was covered in Section 13.

You should also verify that all services we have installed up to this point (Oracle TNS listener, Oracle Clusterware processes, etc.) 
are running before attempting to start the clustered database creation process:

*/


-- Good URL
http://www.toadworld.com/KNOWLEDGE/KnowledgeXpertforOracle/tabid/648/TopicID/RACR2DB/Default.aspx



---******************* cluvfy utility ---******************* 

--**Cluvfy Options and Examples
--To list the various components the CVU will validate:
cluvfy comp -list

--Verify the cluster integrity on all nodes:
cluvfy comp crs -n all -verbose

--Check the integrity of the OCR:
cluvfy comp ocr -n all -verbose

--Confirm the connectivity between all of the nodes:
cluvfy comp nodecon -n all -verbose

--Compare the properties on one node (rac1) to that of a second node (rac2). This command is often used before running addNode.sh 
--to add a node to a cluster:
cluvfy comp peer -refnode rac1 -n rac2 -orainv oinstall -osdba asmdba -verbose

--Check the space availability of the /tmp file system on rac2:
cluvfy comp space -n rac2 -l /tmp/-z 200m -verbose


-- Before installing grid software for rac, verify all the settings with cluvfy utility
--- Import cluvfy checks before installation of grid software.... runcluvfy.sh utility script should be under grid software folder
./runcluvfy.sh stage -post hwos -n wdl1trandbs03,wdl1trandbs02,wdl1trandbs01 -verbose --- check once oracle.grid users are created and setup is ready to install grid
./runcluvfy.sh comp ssa -n epl1trandbrpt1,epl1trandbrpt2,epl1trandbrpt3 -s /ORASYS -verbose
./runcluvfy.sh comp cfs -n epl1trandbrpt1,epl1trandbrpt2,epl1trandbrpt3 -f ocfs2 -verbose
./runcluvfy.sh comp ssa -n epl1trandbrpt1,epl1trandbrpt2,epl1trandbrpt3 -s /dev/ASM -verbose
./runcluvfy.sh comp crs -n epl1trandbrpt1,epl1trandbrpt2,epl1trandbrpt3 -verbose
./runcluvfy.sh comp ocr -n epl1trandbrpt1,epl1trandbrpt2,epl1trandbrpt3 -verbose
./runcluvfy.sh comp voting -n epl1trandbrpt1,epl1trandbrpt2,epl1trandbrpt3 -verbose

cluvfy comp ocr -n all

-- once the Grid software is install the you can run the cluvfy utility script

-- below command checks the connectivity between all nodes with all option
cluvfy comp nodecon -n all -verbose

--*****************************************************************--

-- Query to get the Disk Space on ASM/RAC Instances
SELECT NAME, ROUND(SUM(TOTAL_MB/1024)) TOTAL_DISK_SPACE, ROUND(SUM(FREE_MB/1024)) FREE_DISK_SPACE, STATE 
FROM V$ASM_DISKGROUP
GROUP BY NAME,TOTAL_MB,STATE



-- In rac you can check the cluster name by
$GRID_HOME/bin/cemutlo -n

-- command to check the nodes name
$GRID_HOME/bin/./olsnodes



---******************* crsctl utility ---******************* 

--Use the crsctl command to determine if the cluster is working on a specific node 
$GRID_HOME/bin/crsctl check crs
OR
$GRID_HOME/bin/crsctl check cluster

-- Command to check if the cluster is working on all nodes
$GRID_HOME/bin/crsctl check cluster -all


-- will provide a report on all the cluster resources and if they are running.
$GRID_HOME/bin/crsctl stat res -t
OR
crsctl status resource -t

/opt/app/11.2.0/grid/bin/crsctl start crs -all

--Starting the Cluster on a specific node. 
$GRID_HOME/bin/crsctl start crs

-- Stop Oracle Clusterware on all of the nodes by executing the crsctl stop crs command on all of the nodes.
-- Stopping the Cluster on a specific node. 
$GRID_HOME/bin/crsctl stop crs

-- As a root, Stop one node cluster
/opt/app/11.2.0/grid4/bin/crsctl stop cluster -n uatdbnode1

--Enable or Disable Oracle Clusterware Daemons
/*
Oracle Clusterware will automatically restart when a node is rebooted. There may be cases (like performing system maintenance) 
where you do not want clusterware to restart on a given node. The first command in the following example will keep Clusterware 
from stopping on the node that the command is executed on:. The second command in the following example will re-enable Clusterware on that node.
*/

-- NOTE: This command is run by root users only 
-- Enable crs (/opt/app/11.2.0.3/grid/bin/crsctl enable crs)
$GRID_HOME/bin/crsctl enable crs

-- Disable crs
$GRID_HOME/bin/crsctl disable crs


--Managing the Voting Disks

--The crsctl command is also useful for managing the voting disks. This command locates all the voting disks that you have allocated:
$GRID_HOME/bin/crsctl query css votedisk


--You may want to add voting disks and the crsctl command is the way to do it. In this example we add a voting disk to a shared, non-ASM, disk system:
$GRID_HOME/bin/crsctl add css votedisk /ora05/shared/votedisk


--You can add voting disks to ASM too, but the command syntax is a bit different as seen in this example where we use the crsctl command to add 
--a voting disk to an ASM disk group called +VOTEDISK_DG:
$GRID_HOME/bin/crsctl replace votedisk +VOTEDISK_DG


--We can also remove voting disks as seen in this example where we remove the voting disk we previously created (yes, we are a bit fickle!). 
--Again, this is for non ASM filesystems:
$GRID_HOME/bin/crsctl delete css votedisk /ora05/shared/votedisk


--You would delete a voting disk by using the voting disk GUID and the crsctl command as seen here:
$GRID_HOME/bin/crsctl delete css votedisk voting-disk-GUID


--These commands can be executed without taking down the cluster and are very helpful when migrating voting disk to/from ASM.  You can also move 
--voting disks from one location to another using the crsctl command as seen here:
$GRID_HOME/bin/crsctl replace votedisk {+VOTEDISK_DG

--**Relocate a Resource
--Use the crsctl command if you have a resource on one host that you need to locate to another host. For example, if you wanted to 
--locate a resource called delta_one from host rac1 to host rac2 then you would issue the following command:
$GRID_HOME/bin/crsctl relocate resource delta_one -n rac1 -s rac2 
 
 
--Adding a Cluster Administrator
--You can use the crsctl command to add a cluster administrator as seen in this example:
Crsctl add crs administrator -u new_user_name
 
--**Removing a Cluster Administrator
-- You can use the crsctl command to add a cluster administrator as seen in this example:
Crsctl delete crs administrator -u remove_user_name


--Note that when enabling role-separate management, you will need to remove the * value as seen here:
Crsctl delete crs administrator -u �*�


--**Listing Cluster Administrators
--To list the users that are cluster administrators use the crsctl command as seen here:
crsctl query crs administrator

-- Check the version of Oracle Clusterware
crsctl query crs activeversion
 
--*****************************************************************--
 
 
 
-- Locate a physical backup for OCR
ocrconfig -showbackup


/* 
The ocrcheck utility is used to validate the integrity of the OCR and the OLR. Use the ocrcheck command whenever you have made any 
changes to your cluster (such as changing the VIP for example). Ocrcheck when used by itself will check the OCR. Ocrcheck also takes the following 
parameters:

-local - Check the OLR integrity 
-config - Display configured OCR's. 

*/
Examples of ocrcheck commands

--Here are some examples of the ocrcheck command:

Ocrcheck -local

Ocrcheck -config


-- Check Oracle TNS Listener Process on Both Nodes 
[grid@racnode1 ~]$ ps -ef | grep lsnr | grep -v 'grep' | grep -v 'ocfs' | awk '{print $9}'
LISTENER_SCAN1
LISTENER

[grid@racnode2 ~]$ ps -ef | grep lsnr | grep -v 'grep' | grep -v 'ocfs' | awk '{print $9}'
LISTENER


---******************* srvctl utility ---******************* 

-- command to check where the nodes are running or not
syntax: - srvctl status database -d db_unique_name [-f] [-v]

srvctl status database -d racdb1


-- Confirming Oracle ASM Function for Oracle Clusterware Files 
srvctl status asm -a

-- start and stop single instance
srvctl start instance -d racdb1 -n racnode1
srvctl stop instance -d racdb1 -n racnode1

-- if there are multiple instance on one moachine (node) then,
srvctl start instance -d racdb1 -n racnode1 -i racdb11,racdb12
srvctl stop instance -d racdb1 -n racnode1 -i racdb11,racdb12


-- check the instance status on nodes
srvctl status instance -d racdb1 -n racnode1 -i racdb1
srvctl status instance -d racdb1 -n racnode2 -i racdb1

--*****************************************************************--



--Log Files, Collecting Diagnostic Information and Trouble Resolution
/*
Because Oracle Clusterware 11g Release 2 consists of a number of different components it follows that there are a number of different log 
files associated with these processes. In this section we will first document the log files associated with the various Clusterware processes. 
We will then discuss a method of collecting the data in these logs into a single source that you can reference when doing trouble diagnosis.

Oracle Clusterware 11g Release 2 generates a number of different log files that can be used to troubleshoot Clusterware problems. Oracle Clusterware 
11g adds a new environment variable called GRID_HOME to reference the base of the Oracle Clusterware software home. The Clusterware log files are 
typically stored under the GRID_HOME directory in a sub-directory called log. Under that directory is another directory with the host name and then a 
directory that indicates the Clusterware component that the specific logs are associated with. For example, GRID_HOME/log/myrac1/crsd stores the log 
files associated with CRSD for the host myrac1. The following table lists the log file directories and the contents of those directories:

Directory Path 													Contents
-------------------------------------------------------------------------------------------------------------------------
GRID_HOME/log/<host>/alert<host>.log  						-- Clusterware alert log 
GRID_HOME/log/<host>/diskmon 								-- Disk Monitor Daemon 
GRID_HOME/log/<host>/client 								-- OCRDUMP, OCRCHECK, OCRCONFIG, CRSCTL 
GRID_HOME/log/<host>/ctssd 									-- Cluster Time Synchronization Service 
GRID_HOME/log/<host>/gipcd 									-- Grid Interprocess Communication Daemon 
GRID_HOME/log/<host>/ohasd 									-- Oracle High Availability Services Daemon 
GRID_HOME/log/<host>/crsd 									-- Cluster Ready Services Daemon 
GRID_HOME/log/<host>/gpnpd 									-- Grid Plug and Play Daemon 
GRID_HOME/log/<host>/mdnsd 									-- Mulitcast Domain Name Service Daemon 
GRID_HOME/log/<host>/evmd 									-- Event Manager Daemon 
GRID_HOME/log/<host>/racg/racgmain 							-- RAC RACG 
GRID_HOME/log/<host>/racg/racgeut 							-- RAC RACG 
GRID_HOME/log/<host>/racg/racgevtf 							-- RAC RACG 
GRID_HOME/log/<host>/racg 									-- RAC RACG (only used if pre-11.1 database is installed) 
GRID_HOME/log/<host>/cssd 									-- Cluster Synchronization Service Daemon 
GRID_HOME/log/<host>/srvm 									-- Server Manager 
GRID_HOME/log/<host>/agent/ohasd/oraagent_oracle11 			-- HA Service Daemon Agent 
GRID_HOME/log/<host>/agent/ohasd/oracssdagent_root 			-- HA Service Daemon CSS Agent 
GRID_HOME/log/<host>/agent/ohasd/oracssdmonitor_root 		-- HA Service Daemon ocssdMonitor Agent 
GRID_HOME/log/<host>/agent/ohasd/orarootagent_root 			-- HA Service Daemon Oracle Root Agent 
GRID_HOME/log/<host>/agent/crsd/oraagent_oracle11 			-- CRS Daemon Oracle Agent 
GRID_HOME/log/<host> agent/crsd/orarootagent_root 			-- CRS Daemon Oracle Root Agent 
GRID_HOME/log/<host> agent/crsd/ora_oc4j_type_oracle11g 	-- CRS Daemon Oracle OC4J Agent 
GRID_HOME/log/<host>/gnsd 									-- Grid Naming Service Daemon 
*/

========================================================================
---- All software for Oracle 11G R2 11.2.3.3
https://support.oracle.com/epmos/faces/PatchSearchResults?_adf.ctrl-state=ncqdgr1gr_4&_afrLoop=289357637068858


--To deconfigure Oracle Restart: 
-- Log in as the root user and execute the below command for deinstallation and de-configure the root.sh script
perl /opt/app/11.2.0/grid/crs/install/roothas.pl -deconfig -force

-- logs for root.sh scripts
/opt/app/11.2.0/grid/log/racnode1
========================================================================



--********************************************************************************************************************
--******************** Convert 11Gr2 Rac Database To Archivelog Mode ********************--
+DATA2

--follow below steps to put your database for active-in archivelog mode

--Putting the database into archive/noarchivelog mode in RAC environment:

-- Parameters to modify for changing the location of archivelogs
alter system set cluster_database=false scope=spfile;

crsctl stat res -t -- check except regracdb1 rest is working fine....

SQL> alter system set log_archive_start=TRUE SCOPE=SPFILE; 

SQL> alter system set log_archive_dest_1='location=+DATA2/qaracdb/archivefiles' SCOPE=SPFILE ; 

SQL> alter system set log_archive_dest_state_1 = enable scope=both;

SQL> alter system set log_archive_format='arch_%t_%s_%r.arc' SCOPE=spfile ;


-- regracdb1 was in mount stag so we have to stop all the rest of the nodes
srvctl stop instance -d regracdb

--srvctl start instance -d regracdb -i regracdb1
-- connect to node1 instance regracdb1 

export ORACLE_SID=devracdb1

sqlplus / as sysdba

SQL> startup nomount;

-- we are sure that, all the nodes/instance are down except one, which will be in nomount stage
SQL> alter database mount

SQL> alter database archivelog;

SQL> alter database open;

SQL> alter system set cluster_database=true scope=spfile ;

srvctl stop instance -d regracdb -i regracdb1

srvctl start database -d regracdb 

SQL> archive log list

--SQL> alter system set cluster_database=true scope=spfile ;


/*

This guide is intended for Oracle medium/low level administrators to have a reference for converting a non archive log Oracle 11gR2 RAC 
database into archive log mode.

To do this, first of all we connect to the machine as the �oracle� user and login the database as sysdba, then check the current mode of the database:

The current settings place all archive logs in the same directory. This is acceptible since the thread (%t) is part of the archive format 
preventing any name conflicts between instances. 

If NODE-SPECIFIC locations are required then, LOG_ARCHIVE_DEST_1 parameter can be repeated for each instance with the different location 
and relevant SID prefix.


e.g..

-- This change will be done for devracdb1
ALTER SYSTEM SET log_archive_dest_1='location=/opt/app/oracle/oradata/devracdb/archive/' SCOPE=spfile SID='devracdb1';
ALTER SYSTEM SET log_archive_format='arch_%t_%s_%r.arc' SCOPE=spfile SID='devracdb1';


-- This change will be done for devracdb2 on same locations on server(can place on different location as well)
ALTER SYSTEM SET log_archive_dest_1='location=/opt/app/oracle/oradata/devracdb/archive/' SCOPE=spfile SID='devracdb2';
ALTER SYSTEM SET log_archive_format='arch_%t_%s_%r.arc' SCOPE=spfile SID='devracdb2';

alter system set processes=1500 SCOPE=spfile SID='devracdb2'
*/



[oracle@rac1 ~]$ export ORACLE_SID=RACORA1
[oracle@rac1 ~]$ export ORACLE_HOME=/u01/app/11.2.0/grid
[oracle@rac1 ~]$ export ORACLE_SID='+ASM1';
[oracle@rac1 ~]$ asmcmd

ASMCMD> cd ASMDATA/regracdb/archivelogs
ASMCMD> ls
1_27_729858920.dbf
2011_07_05/


--******************** CONVERT 11GR2 RAC DATABASE TO ARCHIVELOG MODE ********************--
--********************************************************************************************************************


------
--******************** REMOTE & LOCAL LISTENER ********************--

-- if it shows error Connect timeout the modify the parameter remote_listener and local_listener
-- ORA-12170: TNS:Connect timeout occurred
alter system set remote_listener = "regracdbtaf","(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=regracdb.tsysacquiring.org)(PORT=1521)))"  scope=both;


alter system set local_listener = "LISTENER","(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=racnode1-vip.tsysacquiring.org)(PORT=1521)))" scope=both SID='+ASM1';
alter system set local_listener = "LISTENER","(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=racnode2-vip.tsysacquiring.org)(PORT=1521)))" scope=both SID='+ASM2';


alter system set local_listener = "LISTENER","(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=racnode1-vip.tsysacquiring.org)(PORT=1521)))" scope=both SID='racdb11';
alter system set local_listener = "LISTENER","(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=racnode2-vip.tsysacquiring.org)(PORT=1521)))" scope=both SID='racdb12';

/home/oracle/initracdb1.ora

--*****************************************************************--

-- TNS Entry
RACDBSRV =
 (DESCRIPTION =
	(LOAD_BALANCE = YES)
	(FAILOVER = YES )
	(ADDRESS = (PROTOCOL = TCP)(HOST = rac-scan.tsysacquiring.ora)(PORT = 1521))
	(CONNECT_DATA =
	  (SERVER = DEDICATED)
	  (SERVICE_NAME = racdb)
	  (FAILOVER_MODE =
		 (TYPE = SELECT)
		 (METHOD = BASIC)
		 (RETRIES = 200)
		 (DELAY = 10 )
	   )
     )
   )
   


--********************************************************************************************************************
--********** DUPLICATE RAC DB from ACTIVE Database RAC DB Using RMAN **********--
   
Step by Step instruction

--In this guide assume we are migrating a single instance database HRDEV to a two node RAC database HRPRD with following specifications: 
Source database:
	Database name: HRDEV
	Single instance
	Version: 11.2.0.3
	Hostname: dev-db-01
	Filesystem: ASM

Target database:
	Database name: HRPRD
	RAC  2 nodes
	Version: 11.2.0.3
	ORACLE_HOME: /apps/oracle/product/11.2.0/db_1
	GI_HOME: /apps/grid/11.2.0/
	Hostname: prd-db-01/prd-db-02
	Filesystem: ASM
	Diskgroup: +HR

/*
For target database HRPRD we assume that an empty database has already been created with two instances , spfile and controlfiles already exist and 
database already member of clusterware. As a matter of fact we will use only instances of this database as auxiliary instance and all datafiles can be 
deleted manually before duplication as this database is going to be a refreshed from HRDEV database by our DUPLICATE command.

The diskgroup that will be used for this database is �+HR�
*/

--1- Prepare auxiliary instance HRPRD1 on prd-db-01

--Stop all instances of your cluster database except one. In this example we will use only HRPRD1 instance which runs 
--on prd-db-01 and we need to stop other instance HRPRD2 :

racdb-Linux-Node1> srvctl stop instance -d HRPRD -i HRPRD2 

--set following parameters on HRPRD1 instance:
racdb-Linux-Node1> . oraenv HRPRD1 
racdb-Linux-Node1> sqlplus / as sysdba  
SQL>alter system set db_name=HRPRD scope=spfile; 
SQL>alter system set cluster_database=false scope=spfile; 
SQL>alter system set db_create_file_dest='+HR'; 
SQL>alter system set db_create_online_log_dest_1='+HR';  
SQL>shutdown immediate 

-- Re-Login with sys as sysdba once again
SQL>startup nomount 

--2- Enable statis registration for HRPRD1 to running listener LISTENER.

Add following entries into listener.ora file in GI_HOME.

Edit /apps/grid/11.2.0/network/admin/listener.ora and add following lines:

SID_LIST_LISTENER =   
   (SID_LIST =     
   )     
   (SID_DESC =       
     (SID_NAME = HRPRD1)       
     (ORACLE_HOME = /apps/oracle/product/11.2.0/db_1)       
     (GLOBAL_DBNAME = HRPRD)     
    )   
   ) 

--Make sure that ORACLE_HOME in this entry points to correct home which is the home that HRPRD database runs from

--3- Add following tns entries to BOTH auxiliary and target tnsnames.ora file :

HRDEV =   
 (DESCRIPTION =     
   (ADDRESS = 
     (PROTOCOL = TCP)(HOST = dev-db-01)(PORT = 1521))     
     (CONNECT_DATA =       
       (SERVER = DEDICATED)       
       (SERVICE_NAME = HRDEV)     
      )   
    )  
    
HRPRD1 =   
  (DESCRIPTION =     
    (ADDRESS = 
      (PROTOCOL = TCP)(HOST = prd-db-01)(PORT = 1521))     
    (CONNECT_DATA =       
      (SERVER = DEDICATED)       
      (SERVICE_NAME = HRPRD)     
     )   
  ) 

--4- Ceate a password file for auxiliary instance HRPRD1 on prd-db-01:

--Connections to both instances will be through listener and using TNS , so we need to use passwords for both auxiliary and target connections.
--For HRPRD as a new and empty database we may need to create a password file for it as follow:

 racdb-Linux-Node1> . oraenv HRPRD1 
 racdb-Linux-Node1> cd $ORACLE_HOME/dbs 
 racdb-Linux-Node1> orapwd password=sys file=orapwHRPRD1 

--I have assumed that SYS password on source database HRDEV is �sys�

--5- Test connectivity to auxiliary and target instance from BOTH hosts using TNS

--Make sure your connectivity to source database and also to your auxiliary instance works fine , otherwise duplicate from active database won't work.

racdb-Linux-Node1> sqlplus sys/sys@HRPRD1 as sysdba 

racdb-Linux-Node1> sqlplus sys/sys@HRDEV as sysdba 

--Try above commands on both target and auxiliary hosts prd-db-01 and dev-db-01 , do not continue unless your connectivity is fine.

--6- On auxiliary host start RMAN and run the DUPLICATE command:

--From host prd-db-01 which runs auxiliary instance hrprd1 start rman. Make sure auxiliary connection is established through listener not through 
--OS authentication.

racdb-Linux-Node1> . oraenv 

HRPRD1 

racdb-Linux-Node1> rman target sys/sys@HRDEV auxiliary sys/sys@hrprd1 
RMAN>run{          
         DUPLICATE TARGET DATABASE TO HRPRD          
         FROM ACTIVE DATABASE;         
        } 
       
--7- When step 6 finished successfully , start HRPRD database using srvctl , you need to enable second thread as well

--Change the HRPRD database to be cluster database again and start both instances:
racdb-Linux-Node1> . oraenv 
HRPRD1 

racdb-Linux-Node1> sqlplus / as sysdba  
SQL> alter database add logfile thread 2 group 4 size 200m; 
-- add few more groups 
SQL> create tablespace UNDOTBS2 datafile '+HR' size 1g; 
SQL> alter system set undo_tablespace='UNDOTBS2' sid='HRPRD2'; 
SQL> alter database enable public thread 2; 
SQL> alter system set cluster_database=true scope=spfile; 
SQL> shutdown immediate  

racdb-Linux-Node1> srvctl start db -d HRPRD 

--********************************************************************************************************************


--- Failover Testing for TAF - Transparent Application Failover

srvctl add service -d <database_unique_name> -s <service_name> -r <preferred_instances_list> 
      			   -a <available_instances_list> -P <failover_type [NONE | BASIC | PRECONNECT]>


-- Create the service - which should not be the same as default database service name
srvctl add service -d txnDCW -s transittxn -r loadrpdbnode2,loadrpdbnode3 -P BASIC 

-- once you create the service for taf, check crsctl stat res -t where you will find this service as offline

srvctl config service -d txnDCE -s transittxn

srvctl start service -d txnDCE -s transittxn

srvctl modify service -d txnDCE -s transittxn -e select -m BASIC -z 180 -w 5 -j LONG -q TRUE


srvctl add service -d transitrpttp -s transitrpt -r wpl1trandbrpt1,wpl1trandbrpt2,wpl1trandbrpt3 -P BASIC 
srvctl modify service -d devracdb -s devracdbtaf -e select -m BASIC -z 60 -w 3 -j LONG -q TRUE
srvctl config service -d devracdb -s devracdbtaf
srvctl start service -d devracdb -s devracdbtaf

-- for DCW tempe reporting db
srvctl add service -d transitrpttp -s transitrpt -r transitr1,transitr2,transitr3 -P BASIC
srvctl modify service -d transitrpttp -s transitrpt -e select -m BASIC -z 180 -w 5 -j LONG -q TRUE
srvctl config service -d transitrpttp -s transitrpt
srvctl start service -d transitrpttp -s transitrpt


srvctl add service -d devracdb -s devracdb_taf -r devracdb1,devracdb2 -P BASIC 
srvctl modify service -d devracdb -s devracdb_taf -e select -m BASIC -z 60 -w 3 -j LONG -q TRUE
srvctl config service -d devracdb -s devracdb
srvctl start service -d devracdb -s devracdb_taf

srvctl modify service -d devracdb -s devracdb -e select -m BASIC -z 60 -w 3 -j LONG -q TRUE



###### As �Oracle� (owner of database) user

test - name of database
test1- instance on node1
test2- instance on node2
testscan- name for the new taf service

srvctl add service -d test -s testscan -r �test1,test2? -P BASIC

srvctl start service -d test -s testscan

srvctl config service -d test

SQL> select name,service_id from dba_services where name = 'testscan';

SQL> select name, failover_method, failover_type, failover_retries,goal,
clb_goal,aq_ha_notifications from dba_services where service_id = 3;

SQL> execute dbms_service.modify_service (service_name => 'testscan' -
, aq_ha_notifications => true -
, failover_method => dbms_service.failover_method_basic -
, failover_type => dbms_service.failover_type_select -
, failover_retries => 180 -
, failover_delay => 5 -
, clb_goal => dbms_service.clb_goal_long);

lsnrctl status
lsnrctl status LISTENER_SCAN1
lsnrctl status LISTENER_SCAN2
lsnrctl status LISTENER_SCAN3

��������������������

TESTING THE TAF USING SCAN

In your client tnsnames.ora file add below entry after creating TAF service above :

testSCAN =
(DESCRIPTION =
(ADDRESS = (PROTOCOL = TCP)(HOST = testscan.domain.com)(PORT = 1521))
(CONNECT_DATA =
(SERVER = DEDICATED)
(SERVICE_NAME = testscan)
(FAILOVER_MODE=
(TYPE=select)
(METHOD=basic))))

sqlplus system/system@testrac

You can verify the client connections to 11gR2 database for TAF using -

SQL> SELECT MACHINE, FAILOVER_TYPE, FAILOVER_METHOD, FAILED_OVER, COUNT(*)
FROM V$SESSION
GROUP BY MACHINE, FAILOVER_TYPE, FAILOVER_METHOD, FAILED_OVER;

MACHINE AILOVER_TYPE FAILOVER_M FAI COUNT(*)
��� ����- ��� �- �
mymachine SELECT BASIC NO 1

SQL> select count(*) from table;

-- You can continously run this query and mean while go to the cluter node and down the 
-- service on node2 and the instance also on node 2

-- LOGON TO CLUSTER NODE1 as �grid� user:

srvctl stop service -d test -n testracnode2

srvctl stop instance -d test -n testracnode2

crsctl stat res -t

And when you go back to your client connection. You can see that the query is still executing without the connection being lost.

SQL> SELECT MACHINE, FAILOVER_TYPE, FAILOVER_METHOD, FAILED_OVER, COUNT(*)
FROM V$SESSION
GROUP BY MACHINE, FAILOVER_TYPE, FAILOVER_METHOD, FAILED_OVER;

Donot forget to start the service again

srvctl start instance -d test -n testracnode2

srvctl start service -d test -n testracnode2


###########SRVCTL COMMAND TO ADD SERVICE FOR TAF

srvctl add service -d test -s testscan -r �test1,test2? -P BASIC -m BASIC -z 180 -w 5 -j LONG -q TRUE -e SESSION

-d database unique name

-s name of the service to be created

-r preferred instances where the service would run

-P Basic or Preconnect method of connection, PRECONNECT establishes a backup connection on another ndoe, whereas BASIC does a session failover

-z failover retries

-w failover delay

-j session type. either a long session or short session, LONG or SHORT

-q Send Oracle Advanced Queuing (AQ) HA notifications. For standalone servers, applicable in Oracle Data Guard environments only

-e Session Select or None. Use sess

### Command to check serrvice status ####

srvctl config service -d test -s testscan -a

Warning:-a option has been deprecated and will be ignored.
Service name: testscan
Service is enabled
Server pool: test_testscan
Cardinality: 2
Disconnect: false
Service role: PRIMARY
Management policy: AUTOMATIC
DTP transaction: false
AQ HA notifications: true
Failover type: SESSION
Failover method: NONE
TAF failover retries: 180
TAF failover delay: 5
Connection Load Balancing Goal: LONG
Runtime Load Balancing Goal: NONE
TAF policy specification: BASIC
Edition:
Preferred instances: test1,test2
Available instances:




---------------------------
-- SQL query to check the count of session per instance
SELECT gi.instance_name, COUNT(*)
FROM gv$session gs, gv$instance gi
WHERE gs.inst_id = gi.inst_id
GROUP BY gi.instance_name
ORDER BY 1 ASC


SELECT inst_id Instance_Node,  schemaname, osuser, machine, COUNT(*)
FROM gv$session
WHERE TYPE<>'BACKGROUND'
GROUP BY inst_id,  schemaname, osuser, machine
ORDER BY COUNT(*) DESC


--********************************************************************************************************************
-- Moving data files to new ASM diskgroup


-- create the backup as copy script for all datafiles
SQL> select 'backup as copy datafile '||file#||' format �+DATA2�;' from v$datafile;

'BACKUPASCOPYDATAFILE'||FILE#||'FORMAT�+DATA2�;'
���������������������������
backup as copy datafile 1 format '+DATA2';
backup as copy datafile 2 format '+DATA2';
backup as copy datafile 3 format '+DATA2';
backup as copy datafile 4 format '+DATA2';
backup as copy datafile 5 format '+DATA2';

-- run the below rman command for taking backup
RMAN> run {
2> backup as copy datafile 1 format '+DATA2';
3> backup as copy datafile 2 format '+DATA2';
4> backup as copy datafile 3 format '+DATA2';
5> backup as copy datafile 4 format '+DATA2';
6> backup as copy datafile 5 format '+DATA2';
7> }


RMAN>

-- Stop database (both instance will be stopped)
[oracle@dba01tst dbs]$ srvctl stop database -d DBATST

-- Mount the database instance, do not open it
[oracle@dba01tst dbs]$ srvctl start instance -d DBATST -i DBATST1 -o mount

[oracle@dba01tst dbs]$ sqlplus / as sysdba

SQL> select 'switch datafile '||file#||' to copy;' from v$datafile;

'SWITCHDATAFILE'||FILE#||'TOCOPY;'
����������������������
switch datafile 1 to copy;
switch datafile 2 to copy;
switch datafile 3 to copy;
switch datafile 4 to copy;
switch datafile 5 to copy;

SQL> select 'recover datafile '||file#||';' from v$datafile;

'RECOVERDATAFILE'||FILE#||';'
�������������������-
recover datafile 1;
recover datafile 2;
recover datafile 3;
recover datafile 4;
recover datafile 5;

[oracle@dba01tst dbs]$ rman target /

RMAN> switch datafile 1 to copy;

RMAN> switch datafile 2 to copy;

RMAN> switch datafile 3 to copy;

RMAN> switch datafile 4 to copy;

RMAN> switch datafile 5 to copy;

RMAN> recover datafile 1;

RMAN> recover datafile 2;

RMAN> recover datafile 3;

RMAN> recover datafile 4;

RMAN> recover datafile 5;


[oracle@dba01tst dbs]$ sqlplus / as sysdba

SQL> alter database open;

Database altered.

--Useful metalink note : How to move a datafile from ASM to the file system [ID 390416.1]
--********************************************************************************************************************



--********************************************************************************************************************
--Moving OCR to new ASM diskgroup

[root@dba01tst /]# ocrcheck
Status of Oracle Cluster Registry is as follows :
Version : 3
Total space (kbytes) : 262120
Used space (kbytes) : 2964
Available space (kbytes) : 259156
ID : 192353601
Device/File Name : +DATA
Device/File integrity check succeeded

Device/File not configured

Device/File not configured

Device/File not configured

Device/File not configured

Cluster registry integrity check succeeded

Logical corruption check succeeded

-- First the new ASM diskgroup must be added and this will appear as the OCRMirror. 
-- Afterwards OCR location in the old diskgroup is removed (this will make the ocrmirror to become the ocr).

[root@dba01tst /]# ocrconfig -add +DATA2

[root@dba01tst /]# ocrcheck

Status of Oracle Cluster Registry is as follows :
Version : 3
Total space (kbytes) : 262120
Used space (kbytes) : 2964
Available space (kbytes) : 259156
ID : 192353601
Device/File Name : +DATA
Device/File integrity check succeeded
Device/File Name : +DATA2
Device/File integrity check succeeded

Device/File not configured

Device/File not configured

Device/File not configured

Cluster registry integrity check succeeded

Logical corruption check succeeded

[root@dba01tst /]# ocrconfig -delete +DATA

[root@dba01tst /]# ocrcheck

Status of Oracle Cluster Registry is as follows :
Version : 3
Total space (kbytes) : 262120
Used space (kbytes) : 2964
Available space (kbytes) : 259156
ID : 192353601
Device/File Name : +DATA2
Device/File integrity check succeeded

Device/File not configured

Device/File not configured

Device/File not configured

Device/File not configured

Cluster registry integrity check succeeded

Logical corruption check succeeded

-- Related metalink note : OCR / Vote disk Maintenance Operations: (ADD/REMOVE/REPLACE/MOVE) [ID 428681.1]
--********************************************************************************************************************








-- Clean Up a Failed Grid Infrastruture Installation

-- This article describes how to clean up a failed Grid Infrastructure installation. It 
-- specifically focuses on what to do if the "root.sh" script fails during this process and you want to rewind and start again.


-- Grid Infrastructure

-- On all cluster nodes except the last, run the following command as the "root" user.

[root@wpl1trandbrpt1 app]# perl /opt/app/11.2.0/grid/crs/install/rootcrs.pl -verbose -deconfig -force

-- On the last cluster node, run the following command as the "root" user.

[root@wpl1trandbrpt1 app]# perl /opt/app/11.2.0/grid/crs/install/rootcrs.pl -verbose -deconfig -force -lastnode

-- This final command will blank the OCR configuration and voting disk.

-- You should be in a position to rerun the "root.sh" file now, but if you are 
-- using ASM, you will need to prepare your ASM disks before doing so.


ASM Disks

-- Once you attempt an installation, your ASM disks are marked as being used, so they can no longer be 
-- used as candidate disks. To revert them to candidate disk do the following.

-- Overwrite the header for the relevant partitions using the "dd" command.

[root@wpl1trandbrpt1 app]# dd if=/dev/zero of=/dev/oracleasm/disks/ASMRPTCRSVT2 bs=1024 count=100
-- My allocation unit is 1MB that is why I am using bs=1024

-- Remove and create the ASM disk for each partition.

[root@wpl1trandbrpt1 app]# /etc/init.d/oracleasm deletedisk DATA /dev/oracleasm/disks/ASMRPTCRSVT2 -- this step is not needed once you execute the above command.

[root@wpl1trandbrpt1 app]# oracleasm createdisk ASMRPTORADATA1 /dev/mapper/asmrptoradata1p1
[root@wpl1trandbrpt1 app]# oracleasm createdisk ASMRPTORADATA2 /dev/mapper/asmrptoradata2p1
[root@wpl1trandbrpt1 app]# oracleasm createdisk ASMRPTORADATA3 /dev/mapper/asmrptoradata3p1
[root@wpl1trandbrpt1 app]# oracleasm createdisk ASMRPTORADATA4 /dev/mapper/asmrptoradata4p1

[root@wpl1trandbrpt1 app]# oracleasm scandisks -- this should be executed on all the nodes
[root@wpl1trandbrpt1 app]# oracleasm listdisks

-- The disks will now be available as candidate disks.



OR 

-- After running the rootcrs.pl script on all the nodes and main node. just run the below simple command to deinstall ASM and created Disk.

-- go to software/deinstall path, and run the command from there
[root@wpl1trandbrpt1 app]# cd /opt/app/software/deinstall

[root@wpl1trandbrpt1 app]# ./deinstall -hone /opt/app/11.2.0/grid
--********************************************************************************************************************

-- this should be run in revers order of nodes like 3,2,1 nodes

Dual Environment CRSCTL Commands
crsctl add resource
crsctl add type
crsctl check css
crsctl delete resource
crsctl delete type
crsctl get hostname
crsctl getperm resource
crsctl getperm type
crsctl modify resource
crsctl modify type
crsctl setperm resource
crsctl setperm type
crsctl start resource
crsctl status resource
crsctl status type
crsctl stop resource


crsctl add crs administrator
crsctl add css votedisk
crsctl add serverpool
crsctl check cluster
crsctl check crs
crsctl check resource
crsctl check ctss
crsctl config crs
crsctl delete crs administrator
crsctl delete css votedisk
crsctl delete node
crsctl delete serverpool
crsctl disable crs
crsctl enable crs
crsctl get css
crsctl get css ipmiaddr
crsctl get nodename
crsctl getperm serverpool
crsctl lsmodules
crsctl modify serverpool
crsctl pin css
crsctl query crs administrator
crsctl query crs activeversion
crsctl query crs releaseversion
crsctl query crs softwareversion
crsctl query css ipmidevice
crsctl query css votedisk
crsctl relocate resource
crsctl relocate server
crsctl replace discoverystring
crsctl replace votedisk
crsctl set css
crsctl set css ipmiaddr
crsctl set css ipmiadmin
crsctl setperm serverpool
crsctl start cluster
crsctl start crs
crsctl status server
crsctl status serverpool
crsctl stop cluster
crsctl stop crs
crsctl unpin css
crsctl unset css

Oracle Restart Environment CRSCTL Commands  -> The commands listed in this section control Oracle High Availability Services.
crsctl check has
crsctl config has
crsctl disable has
crsctl enable has
crsctl query has releaseversion
crsctl query has softwareversion
crsctl start has
crsctl stop has
 
ATTENTION:
The following commands are deprecated in Oracle Clusterware 11g release 2 (11.2):

crs_stat
crs_register
crs_unregister
crs_start
crs_stop
crs_getperm
crs_profile
crs_relocate
crs_setperm

crsctl check crsd
crsctl check cssd
crsctl check evmd
crsctl debug log
crsctl set css votedisk
crsctl start resources
crsctl stop resources
--********************************************************************************************************************



-- Oracle RAC: GRID_HOME is occupied by crfclust.bdb

-- So, what is this file about?
-- crfclust.bdb is a Cluster Health Monitor (CHM) file, which collects the stats of Cluster as well as the OS statistics by means 
-- of the Cluster Health Monitor Service ora.crf.

-- This file has a default size of 1 GB. However, it may grow beyond the default size if a high retention period is defined. 
-- If the file is growing beyond the default size even with a low retention period, it is most likely a bug and one such bug is Bug 10165314.

-- To permanently fix the issue and to prevent the CHM file to grow beyond the default size, we can apply the patch 10165314.

-- For an immediate workaround, we can delete the CHM file (crfclust.bdb) as follows:

cd /opt/app/11.2.0/grid4/crf/db/regdbnode1/

[root@regdbnode1 regdbnode1]# /opt/app/11.2.0/grid4/bin/crsctl stop res ora.crf -init
[root@regdbnode1 regdbnode1]# rm -f *.bdb
[root@regdbnode1 regdbnode1]# /opt/app/11.2.0/grid4/bin/crsctl start res ora.crf -init
--********************************************************************************************************************


-- Oracle RAC: GRID_HOME is occupied by crfclust.bdb

-- crfclust.bdb is a Cluster Health Monitor (CHM) file, which collects the stats of Cluster as well as the OS statistics by 
-- means of the Cluster Health Monitor Service ora.crf. This file has a default size of 1 GB. However, it may grow beyond the 
-- default size if a high retention period is defined. If the file is growing beyond the default size even with a low retention 
-- period, it is most likely a bug and one such bug is Bug 10165314.

-- To permanently fix the issue and to prevent the CHM file to grow beyond the default size, we can apply the patch 10165314.

-- For an immediate workaround, we can delete the CHM file (crfclust.bdb) as follows:

-- Step 1. Stop the Cluster Health Monitor resource ora.crf as grid owner

[root@my-lab01 ~]$/app/grid/11.2.0.4/bin/crsctl stop res ora.crf -init
CRS-2673: Attempting to stop 'ora.crf' on 'my-lab01'
CRS-2677: Stop of 'ora.crf' on 'my-lab01' succeeded

-- Step 2. Remove the huge CHM files
The file can only be removed by the root user as it is owned by root.

cd $GI_HOME/crf/db/[nodename]
rm *.bdb
Example:

[root@my-lab01 ~]$cd /app/grid/11.2.0.4/crf/db/my-lab01
[root@my-lab01 my-lab01]$rm crfclust.bdb

-- Step 3. Start the Cluster Health Monitor resource ora.crf

[root@my-lab01 ~]$/app/grid/11.2.0.4/bin/crsctl start res ora.crf -init
CRS-2672: Attempting to start 'ora.crf' on 'my-lab01'
CRS-2676: Start of 'ora.crf' on 'my-lab01' succeeded
--********************************************************************************************************************