
--*********************************************************************************--
--																				   --
--       Below are the steps to configure GoldenGate Replication software          --
--																				   --
--*********************************************************************************--


-- Below changes has to be done on both Parimary and Reporting Database.. (until -->EOF_Of_Script)


--create a folder for goldengate Home and add the path in .bash_profile
mkdir -p /opt/app/goldengate


-- set the os env for OGG_HOME ~/.bas_profile for 
OGG_HOME=/opt/app/goldengate; export OGG_HOME
-- add the $OGG_HOME in PATH line and also in LD_LIBRARY_PATH


-- Once done, then install the golden software in $OGG_HOME folder
unzip 112101_fbo_ggs_Linux_x64_ora11g_64bit.zip
tar -xf fbo_ggs_Linux_x64_ora11g_64bit.tar

/*

--- best URL for GOLDEN GATE 
http://database.com.mk/wordpress/category/oracle/golden-gate/

--- Once you have Install Oracle and created database you will also need to install Oracle GoldenGate software

--create a folder ogg home under app/oracle/product folder path
mkdir -p /opt/app/oracle/product/ogg

--set the os env for OGG_HOME ~/.bas_profile for 
OGG_HOME=/opt/app/oracle/product/ogg; export OGG_HOME

-- add the $OGG_HOME in PATH line and also in LD_LIBRARY_PATH

-- Once done, then install the golden software in $OGG_HOME folder
unzip 112101_fbo_ggs_Linux_x64_ora11g_64bit.zip
tar -xf fbo_ggs_Linux_x64_ora11g_64bit.tar

-- start gg command line utility for creating sub directories in $OGG_HOME folder only
./ggsci

GGSCI>create subdirs
GGSCI>exit

oracle@db1>mkdir $OGG_HOME/discard


*/

-- start gg command line utility for creating sub directories in $OGG_HOME folder only
./ggsci

GGSCI> create subdirs
GGSCI> exit

oracle> mkdir $OGG_HOME/discard


-- The GoldenGate software has been successfully installed on both BOX Primary and Reporting


-- Add Supplemental log data to database
-- database should be in Archivelog mode if not then please convert it to ARCHIVELOG mode

-- This has to be done on both the DBs Primary and Reporting DBs

oracle> sqlplus / as sysdba

SQL> ALTER DATABASE ADD SUPPLEMENTAL LOG DATA; 

SQL> ALTER DATABASE FORCE LOGGING;

/*

Below should be On

ALTER DATABASE ADD SUPPLEMENTAL LOG DATA;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (PRIMARY KEY) COLUMNS;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (UNIQUE) COLUMNS;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (FOREIGN KEY) COLUMNS;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA (ALL) COLUMNS;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA FOR PROCEDURAL REPLICATION;

*/

SQL> ALTER SYSTEM SWITCH LOGFILE; 

SQL> SELECT FORCE_LOGGING, SUPPLEMENTAL_LOG_DATA_MIN FROM V$DATABASE;

FOR SUPPLEME
--- --------
YES YES

-- trun off recyclebin for handling ddl commands
SQL> ALTER SYSTEM SET RECYCLEBIN=OFF SCOPE=SPFILE;

SQL> ALTER TABLE SYS.SEQ$ ADD SUPPLEMENTAL LOG DATA (PRIMARY KEY) COLUMNS;

--- there is no need to shutdown the database, I have done for fresh start after supplemental log data command...
SQL> SHUTDOWN IMMEDIATE
SQL> EXIT;


oracle> sqlplus / as sysdba
SQL> STARTUP



-- Once the DB is up and running - 

-- Create connecting and Administrator user on both the DBs primary and reporting for GoldenGet Replication 
SQL> CREATE USER OGG IDENTIFIED BY GGATE DEFAULT TABLESPACE USERS TEMPORARY TABLESPACE TEMP;

SQL> GRANT CONNECT, RESOURCE, UNLIMITED TABLESPACE, DBA TO GGATE; 

SQL> GRANT EXECUTE ON UTL_FILE TO GGATE;

-- The DBA role is not sufficient for advanced scenarios; you must also run the DBMS_GOLDENGATE_AUTH package. 
-- When keying in the DBMS_GOLDENGATE_AUTH command, the entire string after EXEC is without spaces or line breaks.
SQL> EXEC DBMS_GOLDENGATE_AUTH.GRANT_ADMIN_PRIVILEGE (grantee=>'GGATE',privilege_type=>'capture',grant_select_privileges=>true, do_grants=>TRUE); 


-- TNSNames.ora entry should be present on both the DBs (Primary and Reporting DBs) if you are using connection string in extract,DataPump, replicat processes
pridb=
  (DESCRIPTION=
    (ADDRESS = (PROTOCOL=TCP)(HOST=wdl2mltidbs01.tsysacquiring.org)(PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=pridb.tsysacquiring.org)
    )
  )

reptdb=
  (DESCRIPTION=
    (ADDRESS= (PROTOCOL=TCP)(HOST=wdl2mltidbs02.tsysacquiring.org) (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=reptdb.tsysacquiring.org)
    )
  )

  
-- Execute the below scripts from $OGG_HOME in GGATE schema (run on both Primary and Reporting DBs)
oracle>cd $OGG_HOME

oracle> sqlplus / as sysdba

-- when prompt for GoldenGate schemaname, then give ggate 
SQL> @marker_setup
SQL> @ddl_setup
SQL> @role_setup
SQL> @ddl_enable
SQL> @ddl_pin ggate
SQL> @sequence


/*

On Both the Database machine (Primary and Reporting) GoldenGate Software Home (Path) should be the same

*/

-- set the ORACLE_SID env before creating checkpoint table for database (instance)
oracle> export ORACLE_SID=pridb

oracle>cd $OGG_HOME

oracle>./ggsci

/* On Primary DB under ggsci...

./GLOABLS --- 

Now on Primary DB We have to Create below 2 main processes for normal replication

1) mgr process --- which is manager process
2) Extract Processes 
	i) dpump process --- 
   ii) extract process ---

*/

-- Now create the Globals file
GGSCI> edit params ./GLOBALS
-- Starting the file ----------
GGSCHEMA GGATE
CHECKPOINTTABLE GGATE.CHKPTAB
-- Ending the file ------------

-- on site Primary and Reporting site
GGSCI> ADD CHECKPOINTTABLE ggate.CHKPTAB



---> DEVDB Replication processes

-- Extract Process
ADD EXTRACT EPDEV, TRANLOG, THREADS 2, BEGIN NOW
ADD EXTTRAIL /opt/app/goldengate/dirdat/DA, EXTRACT EPDEV, MEGABYTES 100

-- Pump Process 
ADD EXTRACT PPD2R, EXTTRAILSOURCE /opt/app/goldengate/dirdat/DA
ADD RMTTRAIL /opt/app/goldengate/dirdat/DV, EXTRACT PPD2R, MEGABYTES 100


-- Replicat Process
ADD REPLICAT RPR2D, EXTTRAIL /opt/app/goldengate/dirdat/DV

ADD REPLICAT RPD2R, EXTTRAIL /opt/app/goldengate/dirdat/RG


---> REGDB Replication processes

-- Extract Process
ADD EXTRACT EPREG, TRANLOG, THREADS 1, BEGIN NOW
ADD EXTTRAIL /opt/app/goldengate/dirdat/RA, EXTRACT EPREG, MEGABYTES 100

-- Pump Process
ADD EXTRACT PPR2D, EXTTRAILSOURCE /opt/app/goldengate/dirdat/RA
ADD RMTTRAIL /opt/app/goldengate/dirdat/RG, EXTRACT PPR2D, MEGABYTES 100


-- Replicat Process
ADD REPLICAT RPD2R, EXTTRAIL /opt/app/goldengate/dirdat/RG
------------------------------------------------------------------------------------


/*
SHELL Command: shell command is same like, oracle sqlplus host command.

Using shell command first create the dblogin.sql file in ./dirsql directory

*/

GGSCI> shell vi ./dirsql/dblogin.sql
--in vi editor mode
dblogin userid ggate, password ggate1
-- and save the file
--:wq

/**/

/*
OBEY Command: put the ggsci command/script 

*/

GGSCI> 

-- The name of the check point table must be added to the GLOBALS file
-- Name of the table should be same as mentioned in ./GLOBALS file
-- if you don't remember the name then this "ADD CHECKPOINTTABLE" command 
-- will also create checkpoint table
-- Add this to Both DBs Primary and reporting
GGSCI> ADD CHECKPOINTTABLE GGATE.CHKPTAB

GGSCI>

--> Manager process file on primary and reporting DB
GGSCI> edit params mgr
-- >> START_OF_FILE
-- TSYS

-- GoldenGate Manager Parameter File (mgr.prm)
-- Last Modified 5/25/2011
--
-- Set the runtime attributes for manager
-- Parameters are not case sensitive (can be lower, upper, or mixed case).
-- Directory and file names are case sensitive for Linux and UNIX only.

-- PORT sets the GoldenGate Manager Listener port.
-- Manager listens on this port for GoldenGate connection requests
-- These requests can come from Director or GoldenGate Extract.
-- Any other entity attemtpting to connect to this port will receive a
-- "refused" reply
PORT 15000

-- DYNAMICPORTLIST sets the port, series, or range of ports where two way
-- communication will be allowed for Director or GoldenGate Extract. If the
-- connect request comes from GoldenGate Extract, Manager will spawn a
-- process of the Server executable. This process receives data transmitted
-- over TCP/IP by Extract and performs a disk operation into the designated
-- file location.
DYNAMICPORTLIST 15001-15025

-- PURGEOLDEXTRACTS is used for housekeeping purposes.
-- Every 10 minutes Manager spawns a housekeeping process that checks for
-- amongst other things, files that are no longer needed. Any files in the designated
-- directory or folder will be purged if there are no GoldenGate processes that require
-- the file (holding a checkpoint to the file).
PURGEOLDEXTRACTS /opt/app/goldengate/dirdat/*, USECHECKPOINTS, MINKEEPDAYS 2
--*/

-- Autorestart if process terminates abnormally
-- RETRIES <max retries> : The maximum number of times that Manager should try to restart
-- a process before aborting retry efforts. The default number of tries is 2.
-- WAITMINUTES <wait minutes> : The amount of time, in minutes, to pause between discovering
-- that a process has terminated abnormally and restarting the process. Use this option to 
-- delay restarting until a necessary resource becomes available or some other event occurs. 
-- The default delay is 2 minutes.

-- RESETMINUTES <reset minutes> : The window of time, in minutes, during which retries are 
-- counted. The default is 120 minutes (2 hours). After the time expires, the number 
-- of retries reverts to zero.

-- E for Extract and R for Replicat
AUTORESTART ER *, RETRIES 6, WAITMINUTES 2, RESETMINUTES 30

-- Specifies maximum lag time in minutes after which a warning should be logged in the 
-- error log ggserror.log
LAGCRITICALMINUTES 5

-- Specifies maximum lag time in minutes after which the error should be logged
-- in the error log. Once the LAGCRITICALMINUTES time exceeds.
LAGINFOMINUTES 10

-- It is the time interval at which manager checks extract, pump or replicat process for lag.
LAGREPORTMINUTES 60

-- There are numerous runtime attributes that may be set in this file; including, but
-- not limited to options that control process failure restart, process startup, and lag
-- reporting.
--
-- For more information on other parameter settings related to GoldenGate Manager,
-- refer to the Oracle GoldenGate for Windows and Unix Reference Guide.

-- >> END_OF_FILE MGR Parameter --


-- Start manager process (on Primary and Reporting) DBs
GGSCI>START MGR

-- confirm if it is running 
GGSCI>info all

-- Above all the steps should be done on both the Primary and Reporting database
-- Even the mgr process and ./GLOBALS file should be created on both primary and reporting DB

-->EOF_Of_Script   *****************************************************************************************--
--  ********************************************************************************************************--





--- Datapump process is created on Primary DB from where DDLs/DMLs will be replicate from...

--> Datapump process on primary DB
GGSCI> edit params DPDCW

-- >> START_OF_FILE

-- TSYS
--
-- Set the runtime attributes for an Exract Data Pump which reads
-- from a local Extract Trail, then transmits the data to a Remote
-- file location (RMTTRAIL) on the target GoldenGate server..
--

-- EXTRACT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (PPTW.prm) must exist in the
-- dirprm directory/folder.
EXTRACT DPDCW

-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
-- CHECKPARAMS

-- RMTHOST defines the target server Extract will transmit to.
-- <host/ipaddress> is the target server DNS name, or configured
-- tcp/ip address. MGRPORT is the GoldenGate Manager
-- Listener port configured in the target mgr.prm file. COMPRESS
-- states that outgoing blocks of records are to be compressed to
-- reduce bandwidth requirements. A 4:1 compressioin ratio, or more
-- is not uncommon; however additional CPU resource is required for
-- compression on the source side, and decmpression on the target.
-- Replace <host/ipaddress> with the target GoldenGate server
-- name or ip address.
RMTHOST 10.100.226.209, MGRPORT 7809, COMPRESS

-- RMTTRAIL indentifies thedirectory/folder and file identifier on the
-- target server where Extract will write its data. When the
-- file is created on disk, six digits are appended to the two
-- character identifier; starting with 000000. As the file reaches
-- maximum capacity a new file is created and Extract rolls to that
-- new file. A maximun of 999999 Extract Trail files may exist
-- per GoldenGate Extract; however, each file name set must be
-- unique for the server where the Extract runs.
RMTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/TR

-- PASSTHRU denotes that the Extract does not evaluate the data,
--meaning that it does not log into the database and lookup the table
-- definitions. The data is read and passed through to the target server.
PASSTHRU

-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 00:01

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 00:01

-- REPORTCOUNT denotes that every 60 seconds the Extract report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE

---Sequences
--SEQUENCE KEYNOX_FX.*;
--SEQUENCE SNOX4TRANSNOX.*;
--SEQUENCE SNOX4TRANSNOX_CPASS.*;
--SEQUENCE SNOX4TRANSNOX_API.*;
--SEQUENCE TRANSNOX_CPASS.*;
--SEQUENCE TRANSNOX_IOX.*;
--SEQUENCE TNOXPASS_TFE_2013.*;
--SEQUENCE SNOXPASS_TFE_2013.*;
--SEQUENCE TNOXPASS_GWAY_00531.*;
--SEQUENCE SNOXPASS_GWAY_00531.*;
--SEQUENCE TNOXPASS_SMSNOX_303.*;
--SEQUENCE SNOXPASS_SMSNOX_303.*;

---- Schema name for the Table Data
TABLE TRANSNOX_CPASS.* ;
TABLE SNOX4TRANSNOX_CPASS.* ;

-- >> END_OF_FILE
-- SAVE AND EXIT FROM FILE -------------


GGSCI> info all



--> Extract process on primary DB
GGSCI> edit params EDCW

-- >> START_OF_FILE
-- TSYS

-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
-- CHECKPARAMS

-- Last modified 05/24/2013  William Kendall
-- GoldenGate Extract Parameter File (EPTW.prm)
-- Extracts all objects for all of the Schemas in the Source.
--
-- Set the runtime attributes for an Extract which reads
-- Oracle Redo/Archive logs for change data capture and stores
-- this data locally.

-- EXTRACT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (EPTW.prm) must exist in the
-- dirprm directory/folder.
EXTRACT EDCW

-- EXTTRAIL indentifies the local directory/folder and
-- file identifier where Extract will write its data. When the
-- file is created on disk, six digits are appended to the two
-- character identifier; starting with 000000. As the file reaches
-- maximum capacity a new file is created and Extract rolls to that
-- new file. A maximun of 999999 Extract Trail files may exist
-- per GoldenGate Extract.
EXTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/PS

-- This area is used for creating and monitoring environments
-- Must set environments
-- If you change servers you will need to change SID
-- IF fails, do a view report SEVICE-NAME to see env
SETENV (ORACLE_SID  = "PRIDB")
SETENV (ORACLE_HOME = "/opt/app/oracle/product/11.2.0/dbhome_1")

-- Import Language Settings
-- SETENV (NLS_LANG="AMERICAN_AMERICA.US7ASCII")

-- The login credentials GoldenGate is to use to access the database.
USERID ggate, PASSWORD ggate1
TRANLOGOPTIONS DBLOGREADER

-- DDL Parameter
--DDL INCLUDE MAPPED;
DDL INCLUDE ALL;

-- Add Trandata for DDL
DDLOPTIONS REPORT, ADDTRANDATA

-- THREADOPTIONS PROCESSTHREADS SELECT 1
-- THREADOPTIONS PROCESSTHREADS SELECT 2

DBOPTIONS ALLOWUNUSEDCOLUMN
-- DBOPTIONS ALLOWNOLOGGING

---------------------------------------------------------------------
-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 11:00

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 11:00

-- REPORTCOUNT denotes that every 60 seconds the Extract report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE

-- End of "best practices" section
---------------------------------------------------------------------

-- By IGNORETRUNCATES parameter, No TRUNCATES should be performed.
-- Replication will allow to truncate replication By GETTRUNCATES parameter.
GETTRUNCATES

-- Sequence Parameter
-- and must be terminated with a semi-colon. Each table must be listed; however,
-- wildcards are allowed, with the * wildcard denoting all tables in the database.

--SEQUENCE KEYNOX_FX.*;
--SEQUENCE TRANSNOX_CPASS.*;
--SEQUENCE SNOX4TRANSNOX_CPASS.*;

--exclude Tables

-- List of Mother schemas
TABLEEXCLUDE TRANSNOX_CPASS.MV*
TABLEEXCLUDE TRANSNOX_CPASS.DBMS_TABCOMP_TEMP_UNCMP
TABLE TRANSNOX_CPASS.*;

TABLEEXCLUDE SNOX4TRANSNOX_CPASS.MV*
TABLE SNOX4TRANSNOX_CPASS.*;
-- >> END_OF_FILE

-- SAVE AND EXIT FROM FILE -------------



GSSCI> info all

GSSCI> ADD EXTRACT EDCW,TRANLOG, THREADS 1, BEGIN NOW
GSSCI> ADD EXTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/PS, EXTRACT EPTW, MEGABYTES 100

GSSCI> ADD EXTRACT DPDCW, EXTTRAILSOURCE /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/PS
GSSCI> ADD RMTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/TR, EXTRACT DPDCW, MEGABYTES 100

GSSCI> ALTER EXTRACT EDCW TRANLOG BEGIN NOW
GSSCI> ALTER EXTRACT DPDCW TRANLOG BEGIN NOW



/*

-- For setting up the reporting database, followup the below process

start the extract and datapump processes on source database and take the export using flashback scn and import it to 
build target reporting db


-- Take the export of schemas using flashback_scn
SQL> SELECT 'flashback_scn=' || TO_CHAR(sys.DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER) FROM dual;

oracle> vi exp_test.par
DUMPFILE="LoadTestBackup_11454852.dmp"
LOGFILE="exp_LoadTestBackup_11454852.log"
DIRECTORY=BKUP
FLASHBACK_SCN=11454852
COMPRESSION=ALL
CONTENT=ALL
SCHEMAS=('SNOX4TRANSNOX_API','KEYNOX_FX','SNOX4TRANSNOX','SNOX4TRANSNOX_CPASS','SNOXPASS_GWAY_00531','SNOXPASS_GWAY_007','SNOXPASS_GWAY_008','SNOXPASS_TFE_2013','SNOXPASS_TFE_2014','TNOXPASS_GWAY_007','TNOXPASS_GWAY_008','TNOXPASS_TFE_2013','TRANSNOX_CPASS','TRANSNOX_IOX','SNOXPASS_SMSNOX_303','TNOXPASS_SMSNOX_303')

--
oracke> expdp rchaudhari parfile=exp_test.par

oracle> vi impdp_test.par
DUMPFILE="LoadTestBackup_11454852_1.dmp"
LOGFILE="imp_LoadTestBackup_2_11454852.log"
DIRECTORY=BKUP
STREAMS_CONFIGURATION=n
TABLE_EXISTS_ACTION=SKIP
SKIP_UNUSABLE_INDEXES=y
CONTENT=ALL
PARTITION_OPTIONS=none

oracle> impdp rchaudhari parfile=impdp_test.par

--- we starting the extract and replicat process after import is done on reporting DB upto the flashback_scn
-- start extract
./ggsci
GGSCI> dblogin userid ggate,password ggate
GGSCI> start extract EPRW aftercsn 11454852

-- On reporting db start replicat
GGSCI> dblogin userid ggate,password ggate
GGSCI> start replicat RPRWCP02 aftercsn 1621973013

start replicat RPRWCP03 aftercsn 1621973013


*/


--- On Reporting/Target site

--> Replicat process on Reporting DB
GGSCI> edit params RDCE
-- >> START_OF_FILE
-- TSYS
--
--
-- GoldenGate Replicat Parameter File (RPRE.prm)
--
-- Set the runtime attributes for a Replicat which reads
-- from a GoldenGate Remote Trail and applies the data
-- to a target set of tables

-- REPLICAT defines the type of process and the identifier
-- (group name) within GoldenGate. A corresponding file
-- with the same name (RPRE.prm) must exist in the
-- dirprm directory/folder.
REPLICAT RDCE

-- Verifies parameter file syntax. COMMENT OUT AFTER TESTING.
-- CHECKPARAMS

-- Set environment
-- This area is used for creating and monitoring environments
-- Must set environments
-- If you change servers you will need to change SID
-- IF fails, do a view report SEVICE-NAME to see env
SETENV (ORACLE_SID  = "reptdb")
SETENV (ORACLE_HOME = "/opt/app/oracle/product/11.2.0/dbhome_1")

-- Import Language Settings
-- SETENV (NLS_LANG="AMERICAN_AMERICA.US7ASCII")

-- The login credentials GoldenGate is to use to access the database.
USERID ggate@reptdb, PASSWORD ggate1

-- The ASSUMETARGETDEFS means that the target table schema is
-- the same as the source. For this to be valid, the column names,
-- and data types, are the same and they appear in the same order
-- as the source tables.
ASSUMETARGETDEFS

-- DBOPTIONS SUPPRESSTRIGGERS parameter to prevent triggers on target
-- when user is GoldenGate user (oraclegg). Package
-- dbms_goldengate_auth.grant_admin_privilege must be run for GoldenGate user
--    exec dbms_goldengate_auth.grant_admin_privilege(grantee => 'ORACLEGG', grant_select_privileges => TRUE);
-- 
--	NOTE: SUPPRESSTRIGGERS prevents the trigger body from executing.
--	The WHEN portion of the trigger must still compile and execute
--	correctly to avoid database errors.
DBOPTIONS SUPPRESSTRIGGERS

-- DDLERROR is a catch all for DDL to just ignore all DDL errors.
-- use this only for troubleshooting
--DDLERROR default ignore
--  DDLERROR DEFAULT IGNORE
DDLERROR DEFAULT IGNORE

-- DDL Parameter
--DDL INCLUDE ALL EXCLUDE OBJNAME "TRANSNOX_IOX.REPORT_USAGE_SEQ" EXCLUDE OBJNAME "TRANSNOX_CPASS.REPORT_USAGE_SEQ"
DDL INCLUDE ALL

DDLOPTIONS REPORT
DDLERROR 942 DISCARD INCLUDE OPTYPE DROP
REPERROR (1403, DISCARD)

-- The DISCARD file is where Replicat writes transaction information
-- when it encounters a data issue
DISCARDFILE ./dirrpt/RPRE.dsc, APPEND, MEGABYTES 500

-- The following are "best practice" runtime options which may be
-- used for workload accounting and load balancing purposes.

-- STATOPTIONS RESETREPORTSTATS ensures that process
-- statistics counters will be reset whenever a new report file is
-- created.
STATOPTIONS RESETREPORTSTATS

-- Generate a report every day at 1 minute after midnight.
-- This report will contain the number of operations, by operation
-- type, performed on each table.
REPORT AT 00:01

-- Close the current report file and create a new one daily at 1
-- minute after midnight. Eleven report files are maintained on disk
-- in the dirrpt directory/folder for each GoldenGate group. The
-- current report file names are <group name>.rpt. The older reports
-- are <group name>0.rpt through <group name>9.rpt, with the
-- older report files having larger numbers.
REPORTROLLOVER AT 00:01

-- REPORTCOUNT denotes that every 60 seconds the Replicat report file
-- in the dirrpt directory/folder will have a line added to it that reports the
-- total number of records processed since startup, along with the rated
-- number of records processed per second since startup, and the change
-- in rate, or "delta" since the last report.
-- In a production environment, this setting would typically be 1 hour.
REPORTCOUNT EVERY 1 HOUR, RATE

-- End of "best practices" section

-- Overlap Mode Processing
-- Handlecollisions and End Runtime are to be used only when the target
-- database is being instantiated. Once the initial load extract and replicat
-- complete, we start change data replicat with these options.
-- Handlecollisions sets the replicat to ignore missing data in the target
-- and to overlay the row if it already exists.
-- End Runtime sets replicat to terminate normally whenever it encounters
-- a record that matches, or is after the process start time.
-- Never, never set this is a running production environment!
--HANDLECOLLISIONS
--END 2012-06-20 15:56:00
--END 2010-06-15 09:45:00

ALLOWNOOPUPDATES
--
-- The MAP statement sets the correlation between the source and
-- target tables. The source schema and tables are identified on the left
-- hand side of the statement and the target schema and tables are
-- identified after the keyword TARGET. Wildcards are allowed, and the
-- * wildcard denotes all tables. The MAP statement must be terminated
-- by a semi-colon.

-- MAP WEBRATER_OWNER.QUOTE, TARGET WEBRATER_OWNER.QUOTE, FILTER (@RANGE(1, 3));

--MAPEXCLUDE SCOTT.DEPT

MAP TNOXPASS_TFE_*.*, TARGET TNOXPASS_TFE_*.* ;
MAP SNOXPASS_TFE_*.*, TARGET SNOXPASS_TFE_*.* ;

MAP TNOXPASS_SMSNOX_*.*, TARGET TNOXPASS_SMSNOX_*.* ;
MAP SNOXPASS_SMSNOX_*.*, TARGET SNOXPASS_SMSNOX_*.* ;

MAP TNOXPASS_GWAY_*.*, TARGET TNOXPASS_GWAY_*.* ;
MAP SNOXPASS_GWAY_*.*, TARGET SNOXPASS_GWAY_*.* ;

MAPEXCLUDE TRANSNOX_CPASS.REPORT_USAGE_AUDITTRAIL
MAP TRANSNOX_CPASS.*, TARGET TRANSNOX_CPASS.* ;

-- By default, Oracle GoldenGate synchronizes insert, update, and delete operations. You can
-- use the following parameters in the Extract or Replicat parameter file to control which
-- kind of operations are processed, such as only inserts or only inserts and updates.
-- IGNOREINSERTS | GETINSERTS
-- IGNOREUPDATES | GETUPDATES
-- IGNOREDELETES | GETDELETES
--- If you want to ignore DELETE DML on any table
--IGNOREDELETES

MAP SNOX4TRANSNOX_CPASS.*, TARGET SNOX4TRANSNOX_CPASS.* ;

-- >> END_OF_FILE
-- SAVE AND EXIT FROM FILE -------------



-- on site Reporting
-- Just an reminder that we have to execute it.. We have already executed it first
GGSCI> ADD CHECKPOINTTABLE ggate.CHKPOINTTABLE 

/*

The file exttrail in replicat process should be the same file of Primary Database's RMTTRAIL file.
This file is also in process DPDCW (Parameter file dpump)

*/

GGSCI> ADD REPLICAT RDCE, EXTTRAIL /opt/app/goldengate/product/11.2.0/dbhome_1/dirdat/TR
GGSCI> ALTER REPLICAT RDCE, BEGIN NOW


---- Thank You, Main Configuration Ends Here ----------------------------------------------------------------





--***********************************************************************************************************

-------------------*******************************************************-----------------------------
--																									--
--          GoldenGate NOTES & COMMANDS													--
--																									--
-------------------*******************************************************-----------------------------

-- to refresh the manager
GGSCI>REFRESH MANAGER

--View latency between the records processed by Goldengate and the timestamp in the data source
send extract exttnox, getlag

-- for all extract processes
lag extract ext*


--Find the run status of a particular process
status manager

status extract exttnox

--Information on Child processes started by the Manager
send manager childstatus

--Detailed information of a particular process
info extract exttnox, detail


--Monitoring an Extract recovery 
send extract exttnox status

-- Monitoring command for ip details
-- the result show much more info of the data pump extract process
-- this command will show the result of dpump extract process only
send extract edcw gettcpstats


--Monitoring processing volume - Statistics of the operations processed 
stats extract exttnox


--View processing rate - can use 'hr','min' or 'sec' as a parameter
stats extract ECPASS reportrate hr

-- GGSCI Command 
show all
info all
start extract ext3
history
shell ls -ltrh -- it's works like host command in oracle sqlplus prompt
obey -- to process a file which contains the ggs commands. OBEY is useful for executing commands that are frequently used in sequence.
obey ./dirsql/dblogin.sql -- user login 


-- Do not delete archive files, else extract and replicator process will abeneded..
-- In case you have deleted the archive logs and replication is/was using them then your extract process will not start...
-- check the logs of replication and youwill find that it is checking for older archive logs which are not present now..
-- this case to restart the extract process

ALTER EXTRACT ecpass BEGIN <TIMESTAMP>
OR
alter extract ecpass begin now

start extract ecpass



--How to reset extract:
-- if you do not set an RBA it will begin from 0 at the trail file you specify for the replicat, and for the extract 
-- EXTSEQNO will be the current redo log which you can get from V$LOG
-- EXTSEQNO X and EXTRBA Y numbers will get from trail files
ALTER EXTRACT <NAME> EXTSEQNO X, EXTRBA Y

alter extarct edcw, extseqno 815, extrba 6124048

ALTER EXTRACT edcw, BEGIN 2014-01-08
ALTER EXTRACT edcw, THREAD 1, BEGIN 2014-01-08


/* How tO get the extseqno and extrba

GGSCI (dbserver2) 7> info REPLICAT ROLAP01, detail

REPLICAT  ROLAP01 Last Started 2010-04-01 15:35 Status STOPPED
Checkpoint Lag 00:00:00 (updated 00:12:43 ago)
Log Read Checkpoint File ./dirdat/tb000279 <------- SEQNO
2010-04-08 12:27:00.001016 RBA 43750979 <------- RBA

Extract Source 	        Begin 	        End
./dirdat/tb000279 	2010-04-01 	12:47 2010-04-08 12:27
./dirdat/tb000257 	2010-04-01 	04:30 2010-04-01 12:47
./dirdat/tb000255 	2010-03-30 	13:50 2010-04-01 04:30
./dirdat/tb000206 	2010-03-30 	13:50 First Record
./dirdat/tb000206 	2010-03-30 	04:30 2010-03-30 13:50
./dirdat/tb000184 	2010-03-30 	04:30 First Record
./dirdat/tb000184 	2010-03-30 	00:00 2010-03-30 04:30
./dirdat/tb000000 	*Initialized*   2010-03-30 00:00
./dirdat/tb000000 	*Initialized*   First Record

Adjust the new Replicat process ROLAP02 to adopt these values, so that the process knows where to start from on startup.

GGSCI (dbserver2) 8> alter replicat ROLAP02, extseqno 279
REPLICAT altered.

GGSCI (dbserver2) 9> alter replicat RPRWCP01, extrba 1191
REPLICAT altered.

*/

ALTER REPLICAT <NAME> EXTSEQNO X, EXTRBA Y

ALTER REPLICAT RDCE EXTSEQNO 279, EXTRBA 43750979

-- Start after scn
START REPLICAT <NAME>, AFTERCSN 5397864


-- The following alters Extract to start processing data from January 1, 2011.
ALTER EXTRACT finance, BEGIN 2011-01-01

-- The following alters Extract to start processing at a specific location in the trail.
ALTER EXTRACT finance, EXTSEQNO 26, EXTRBA 338

-- The following alters Extract in an Oracle RAC environment, and applies the new begin point only for redo thread 4.
ALTER EXTRACT accounts, THREAD 4, BEGIN 2011-01-01

-- The following alters Extract in a SQL Server environment to start at a specific LSN.
ALTER EXTRACT sales, LSN 3454:875:445

-- The following alters Extract to increment to the next file in the trail sequence.
ALTER EXTRACT finance, ETROLLOVER

-- The following alters Extract to upgrade to integrated capture.
ALTER EXTRACT finance, UPGRADE INTEGRATED TRANLOG

-- The following alters Extract to downgrade to classic capture in a RAC environment.
ALTER EXTRACT finance, DOWNGRADE INTEGRATED TRANLOG THREADS 3

-- The following alters Extract in an Oracle environment to start processing data from source database SCN 778899.
ALTER EXTRACT finance, SCN 778899

start replicat RPTECP01 aftercsn 1621973013

-- The following shows ALTER EXTRACT for an IBM for i journal start point.
ALTER EXTRACT finance, SEQNO 1234  JOURNAL accts/acctsjrn

-- The following shows ALTER EXTRACT for an IBM for i journal and receiver start point.
ALTER EXTRACT finance, SEQNO 1234 JOURNAL accts/acctsjrn JRNRCV accts/jrnrcv0005


-- Final Setup.. Run ADD TRANDATA SCHEMA_NAME.* without ; (smicolon) for all those schema which you want to add for replications

--Use ADD TRANDATA to enable GoldenGate to acquire the transaction information it needs from the transaction logs. Use the DBLOGIN
--command to establish a database connection before using this command

-- This has to be run first time and after each new table created in future...

--before running add trandata command we have to stop all the running processes

stop *

info all

-- we can keep manager rnning like that and run the below command.. once it is completed start all processes again

add trandata snox4transnox_cpass.* --- there is no smicolon (;)
add trandata transnox_cpass.* --- there is no smicolon (;)

start *

info all


-- if any running process is abended then exclude the below command by the process names
-- so consider that reptnox process on reporting side is abended, due to some errors
alter replicat reptnox begin now
start replicat reptnox 

info all


-- or try to stop the process first 
stop replicat reptnox
info all

-- then again try to start the process by above command

-- if you want to delete the replicat/extract process then login to ogg user and delete it.
dblogin userid ogg password ogg;
delete replicat reptnox;

--command to check DDL
GGSCI>DUMPDDL SHOW

/*

Enabling DDL Support

By default DDL replication support is:

disabled for the extract process
enabled for the replicat process
To enable DDL support, therefore, it is only necessary to specify the DDL parameter for the extract process.

In the following examples, the DDL parameter has also been set for the replicat process.

The DDL parameter can only be specified once in a parameter file. However, one or more DDL inclusion criteria can be specified to include 
or exclude DDL operations based on:

scope
object type
operation type
object name
strings in the DDL statement or comments
If multiple DDL filtering options are specified then all criteria must be true for the DDL to be included.

The syntax for the DDL parameter is as follows:


Parameter

DDL
Not available for datapump process
[
{INCLUDE | EXCLUDE}
[, MAPPED | UNMAPPED | OTHER | ALL]
[, OPTYPE <type>]
[, OBJTYPE '<type>']
[, OBJNAME <name>]
[, INSTR '<string>']
[, INSTRCOMMENTS '<comment_string>']
[, STAYMETADATA]
[, EVENTACTIONS (<action specification>)
]
 
DDLERROR
extract
DDLERROR [RESTARTSKIP <num skips>] [SKIPTRIGGERERROR <num errors>]
 
replicat
DDLERROR
{<error> | DEFAULT} {<response>}-response include abend / discard / ignore / retryop maxretries <n>
{INCLUDE <inclusion clause> | EXCLUDE <exclusion clause>}
[IGNOREMISSINGOBJECTS | ABENDONMISSINGOBJECTS]
 
DDLOPTIONS
DDLOPTIONS
[, ADDTRANDATA [ABEND | RETRYOP <RETRYDELAY <seconds> MAXRETRIES <retries>]
[, DEFAULTUSERPASSWORDPASSWORD <password>
[ENCRYPTKEY DEFAULT | ENCRYPTKEY <keyname>]]
[, GETAPPLOPS | IGNOREAPPLOPS]
[, GETREPLICATES | IGNOREREPLICATES]
[, IGNOREMAPPING]
[, MAPDERIVED | NOMAPDERIVED]
[, MAPSCHEMAS]
[, MAPSESSIONSCHEMA] <source_schema> TARGET <target_schema>
[, PASSWORD ENCRYPTKEY [DEFAULT | ENCRYPTKEY <keyname>]
[, REMOVECOMMENTS {BEFORE | AFTER}]
[, REPLICATEPASSWORD | NOREPLICATEPASSWORD]
[, REPORT | NOREPORT]
[, UPDATEMETADATA]
[, USEOWNERFORSESSION]
 
DDLTABLE
DDL history table name specified, the default is GGS_DDL_HIST

If an EXCLUDE clause is specified, then a corresponding INCLUDE clause must exist.

For example the following is valid as it contains both clauses:

DDL INCLUDE ALL, EXCLUDE OBJNAME "US03.*"
The following is valid as it includes an INCLUDE clause:

DDL INCLUDE OBJNAME "US03.*"
However the following is invalid as it only contains an EXCLUDE clause:

DDL EXCLUDE OBJNAME "US03.*"

EXCLUDE clauses have priority over INCLUDE clauses where both reference the same objects.

Basic DDL Configuration
The following example parameter files contain a minimal configuration that I use for testing. I would recommend specifying more restrictive 
parameters for non-test environments.


The DDLERROR parameter prevents the replicat process from abending if there is a mismatch between the source and target environments. 
This should not really happen under normal circumstances; in a test environment this parameter may be required to synchronize the objects 
between the databases.

Although the above configurations only replicate DML for the US03 schema, the DDL INCLUDE ALL command replicates DDL for all schemas. 
So if a new table is created under the US01 schema, this should be replicated to the same schema in the target database.


TO filter OUT More DDLs excluding then in ddl_Filter.sql function instead of extract process


NOTE: - Before modifying function ogg.filterDDL please disable sys.GGS_DDL_TRIGGER_BEFORE Trriger


You can write PL/SQL code to pass information about the DDL to a function that
computes whether or not the DDL is passed to Extract. By sending fewer DDL
operations to Extract, you can improve capture performance.

1. Copy the ddl_filter.sql file that is in the Oracle GoldenGate installation
directory to a test machine where you can test the code that you will be writing.
2. Open the file for editing. It contains a PL/SQL function named filterDDL, which
you can modify to specify if/then filter criteria. The information that is passed to
this function includes:

� ora_owner: 		the owner of the DDL object
� ora_name: 		the defined name of the object
� ora_objtype: 		the type of object, such as TABLE or INDEX
� ora_optype: 		the operation type, such as CREATE or ALTER
� ora_login_user: 	The user that executed the DDL
� retVal: 			can be either INCLUDE to include the DDL, or EXCLUDE to exclude the

DDL from Extract processing.
In the location after the 'compute retVal here' comment, write filter code for
each type of DDL that you want to be filtered. The following is an example:

if ora_owner='SYS' then
retVal:='EXCLUDE';
end if;
if ora_objtype='USER' and ora_optype ='DROP' then
retVal:='EXCLUDE';
end if;

if ora_owner='JOE' and ora_name like 'TEMP%' then
retVal:='EXCLUDE';
end if;

In this example, the following DDL is excluded from being processed by the DDL trigger:

� DDL for objects owned by SYS
� any DROP USER
� any DDL on JOE.TEMP%

3. (Optional) To trace the filtering, you can add the following syntax to each if/then
statement in the PL/SQL:

if ora_owner='JOE' and ora_name like 'TEMP%' then
retVal:='EXCLUDE';
if "&gg_user" .DDLReplication.trace_level >= 1 then
"&gg_user" .trace_put_line ('DDLFILTER', 'excluded JOE.TEMP%');
end if;

Make the changes and compile the back to ogg user

OR 

You can handle all the unwantted objects and owner in sys.GGS_DDL_TRIGGER_BEFORE Trriger, but be carefull for it



You can exclude DDL in three ways
1) using Function OGG.filterDDL
2) using Trigger sys.GGS_DDL_TRIGGER_BEFORE
3) Extract process like below code in extract exttnox file...

	--DDL support--
	ddl include ALL, exclude OBJTYPE USER, exclude OBJTYPE TABLESPACE, &
		exclude objtype 'DATABASE LINK', EXCLUDE OBJNAME TNOX.SN_TEMP*, &
		EXCLUDE OBJNAME snox.SN_TEMP*


*/


--- Just a Point
--There is a limitation of DDL for 2 MB replicating per objects at a time like Table,Packages,Procedure and Functions.


-- Command to check lagging
GGSCI> lag reptnox

-- Command to check/verify the tables
GGSCI> list tables transnox_cpass.*

OR

GGSCI> list tables snox4transnox_cpass.*


-- The ! command without arguments executes the most recent command.
GGSCI> !



-- You cannot use a wildcard in the schema name. 
-- for e.g..
MAP TNOXPASS_TFE_*.*, TARGET TNOXPASS_TFE_*.* ;
MAP SNOXPASS_TFE_*.*, TARGET SNOXPASS_TFE_*.* ;

MAP TNOXPASS_SMSNOX_*.*, TARGET TNOXPASS_SMSNOX_*.* ;
MAP SNOXPASS_SMSNOX_*.*, TARGET SNOXPASS_SMSNOX_*.* ;

MAP TNOXPASS_GWAY_*.*, TARGET TNOXPASS_GWAY_*.* ;
MAP SNOXPASS_GWAY_*.*, TARGET SNOXPASS_GWAY_*.* ;



-- Table Patition Replication....
* Create Table Partition is replicated
* DMLs on Table Partition is also replicated
* Drop partition is only working for user define partition names.
* Name generated by Oracle System for Table Partition will not be dropped (or any DDL related on it) as it 
  checks for the same name of the table partition on replication DB...
* In Interval Partition, system generated partition will not be dropped, name mismatches


-- register extract to the database
/*
   There are two types of CAPTURE's in GoldenGate Replication 
   1) CLASSIC CAPTURE 
   2) INTEGRATED CAPTURE
   
   If extract is register with database (Before starting any process -- mgr, extract, dpump) then it is 
   INTEGRATED CAPTURE, else it's CLASSIC CAPTURE
*/

--- it means we are enabling INTEGRATED CAPTURE replication mode
GGSCI> REGISTER EXTRACT EDCW DATABASE 



---- PARAMETERS for Extract Process

-- option to exclude the user name or ID that is used by Replicat to apply transactions. 
-- Multiple EXCLUDEUSER statements can be used. The specified user is subject to the rules of 
-- the GETREPLICATES or IGNOREREPLICATES parameter
* EXCLUDEUSER or EXCLUDEUSERID 


-- Controls whether or not data operations (DML) produced by business applications except 
-- Replicat are included in the content that Extract writes to a specific trail or file.
* GETAPPLOPS | IGNOREAPPLOPS


-- Controls whether or not DML operations produced by Replicat are included in the content 
-- that Extract writes to a specific trail or file.
* GETREPLICATES | IGNOREREPLICATES



-- command tocheck the replicat process
replicat paramfile /opt/app/goldengate/product/11.2.0/dbhome_1/dirprm/rdce.prm




----
-- To Check and try for the same


-- Create a GoldenGate replication configuration to run a SHELL SCRIPT
-- when an end-of-day processing record is replicated

--- So it will show who many records have been process through-out the day

-- On target(replication) site add the parameter in replicat process
STREQ(STATE, "EOD COMPLETE")=1, EVENACTIONS (Shell "Update_Balances.sh")

-- start replicat process again and check the same at EOD



-- Linux script to Monitor the Replication process is on page number 177-178-179
------------------------------------------------------------------------------
-- OGG Command Line Monitoring Script

-- Linux scripting

vi info_all_cpdb.sh

#!/bin/sh

#info_all.sh

ORACLE_HOSTNAME=$HOST; export ORACLE_HOSTNAME
ORACLE_UNQNAME=cpdb_ga; export ORACLE_UNQNAME
ORACLE_BASE=/opt/oracle; export ORACLE_BASE
GRID_HOME=/opt/oracle/product/11.2.0/grid; export GRID_HOME
DB_HOME=$ORACLE_BASE/product/11.2.0/dbhome_1; export DB_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
ORACLE_SID=cpdb; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
#Oracle Gloden Gate Software Home OGG_HOME
OGG_HOME=/archivelogs/goldengate; export OGG_HOME

BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH:$OGG_HOME; export PATH
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH


echo
echo �######################################################################�
echo `date +%d/%m/%Y\ %k:%M:%S`
echo
$OGG_HOME/ggsci <<EOF
info all
exit
EOF
echo �######################################################################�


--**************************************************************************************************************************************************************
Handling GoldenGate Exceptions and Errors with REPERROR
We can use the REPERROR parameter in the Replicat parameter file to control the way that the replication process responds to or handles any errors 
encountered in any of the DML statements which it is trying to process.

We can use the keyword DEFAULT to set a global response for all errors except those for which explicit REPERROR statements have been specified.

In the example we will see how we are handling the ORA-00001: unique constraint violated error using an exception handler specified via the 
REPERROR (-1, EXCEPTION) clause of the Replicat parameter file.

By default, if the replicat process encounters any error condition it will abend.

The example shows how by using an exception handler, replicat process does not abend, but handles the exceptions appropriately and continues processing.

If we have a primary key defined on both the source and target tables and if a unique key violation does happen, then neither the Extract or Replicat 
process gets affected and processing is not halted on either end of the Goldengate environment.

But if we have a case where say there are duplicate key values on the source table, but on the target table there is a primary or unique constraint in place. 
When these duplicate rows get propagated to the target server via the extract trail and when the Replicat process does encounter these row violations of 
the primary key constraint in place on the target table, the replicat process will abend.

However, we can use the REPERROR parameter to specify how we will handle this specific error (or any other error or all errors).

In our example, we have created an �exception� table and the exception handler is to write information about any such rows which are violating the 
unique constraint to this exception table AND continue processing without abending the replicat process.

Without the exception handler in place, we will first see that the Replicat process terminates or abends.

SQL> /
Enter value for 1: 4001
Enter value for 2: KERRY
old   3:  (&1,'&2')
new   3:  (4001,'KERRY')
insert into emp
*
ERROR at line 1:
ORA-00001: unique constraint (IDIT_PRD.PK_EMP) violated





GGSCI (indb02) 5> info replicat myrep

REPLICAT   MYREP     Last Started 2011-04-15 12:18   Status ABENDED
Checkpoint Lag       00:00:00 (updated 00:00:17 ago)
Log Read Checkpoint  File ./dirdat/gg000016
                     2011-04-15 12:19:30.219092  RBA 1825

Using the VIEW REPORT command, we can see why the process has abended.

2011-04-15 12:22:27  WARNING OGG-01004  Aborted grouped transaction on 'IDIT_PRD.EMP', Database error 1 (ORA-00001: unique constraint (IDIT_PRD.PK_EMP) violated).

2011-04-15 12:22:27  WARNING OGG-01003  Repositioning to rba 1825 in seqno 16.

2011-04-15 12:22:27  WARNING OGG-01154  SQL error 1 mapping IDIT_PRD.EMP to IDIT_PRD.EMP OCI Error ORA-00001: unique constraint (IDIT_PRD.PK_EMP) 
violated (status = 1), SQL . 

--Now let us put in an exception handler into our replicat parameter file.

REPLICAT myrep
SETENV (NLS_LANG="AMERICAN_AMERICA.WE8ISO8859P1")
SETENV (ORACLE_SID=GGDB2)
ASSUMETARGETDEFS
USERID idit_prd,PASSWORD idit_prd
REPERROR (-1, EXCEPTION)
MAP idit_prd.emp, TARGET idit_prd.emp;
INSERTALLRECORDS
MAP idit_prd.emp, TARGET idit_prd.emp_exception,
EXCEPTIONSONLY,
COLMAP (USEDEFAULTS,
optype = @GETENV ("lasterr", "optype"),
dberr = @GETENV ("lasterr", "dberrnum"),
dberrmsg = @GETENV ("lasterr", "dberrmsg"));
So the REPERROR (-1, EXCEPTION) means that when we encounter the ORA-00001 error, the exception handler will kick in.


--***********************************************************************************************************

/* Add DDLERROR parameter in the replicat parameter file

See below the parameter DDLERROR where I choose to entirely IGNORE all �ORA-01432' errors. No retries (RETRYOP), 
no filtering on object names (OBJNAME).

edit params <replicat_process_name>

-- ignore all 'ORA-01432: public synonym to be dropped does' errors
-- This failed because, apparently, this public synonym is not present in the Replicat database. 
-- The result the Replicat process abended.
ddlerror 1432 ignore

*/




-------------------------------
-- Manager Process
GGSCI (vzwc1) 1> view params mgr  
  
PORT 7839    
DYNAMICPORTLIST 7840-7914    
USERID goldengate, PASSWORD goldengate    
--AUTOSTART EXTRACT *    
AUTORESTART EXTRACT *,RETRIES 3,WAITMINUTES 5,RESETMINUTES 10     
PURGEOLDEXTRACTS ./dirdat/*,usecheckpoints, minkeepdays 1     --*/  
PURGEDDLHISTORY MINKEEPDAYS 3, MAXKEEPDAYS 5     
PURGEMARKERHISTORY MINKEEPDAYS 3, MAXKEEPDAYS 5     
LAGREPORTHOURS 1    
LAGINFOMINUTES 30    
LAGCRITICALMINUTES 45  

-------------------------------




-- Applying database patches and upgrades when DDL support is enabled 
NOTE: Database patchesand upgrades usually invalidate the Oracle GoldenGate DDL trigger and otherOracle GoldenGate 	
DDL objects. Before applying a database patch, do the following.
	
1. Disable the Oracle GoldenGate DDLtrigger by running the following script.
	@ddl_disable
	
2. Apply the patch.

3. Enable the DDL trigger by running thefollowing script.
	@ddl_enable


-- Applying Oracle GoldenGate patches and upgrades when DDLsupport is enabled
NOTE: If there are instructionslike these in the release notes or upgrade instructions that accompany arelease, 
follow those instead of these. Do not use this procedure for anupgrade from an Oracle GoldenGate version that does not support 
DDL statementsthat are larger than 30K (pre-version 10.4).
 
	Follow these steps to apply a patch or upgrade to the DDL objects. This procedure may or maynot preserve the current DDL 
synchronization configuration, depending onwhether the new build requires a clean installation.
 
1. Run GGSCI. Keep the session open for theduration of this procedure.

2. Stop Extract to stop DDL capture.
	STOP EXTRACT<group>

3. Stop Replicat to stop DDL replication.
	STOP REPLICAT<group>

4. Download or extract the patch or upgradefiles according to the instructions provided by Oracle GoldenGate.

5. Change directories to the OracleGoldenGate installation directory.

6. Run SQL*Plus and log in as a user thathas SYSDBA privileges.

7. Disconnect all sessions that ever issuedDDL, including those of Oracle GoldenGate processes, SQL*Plus, businessapplications, 
   and any other software that uses Oracle. Otherwise the databasemight generate an ORA-04021 error.

8. Run the ddl_disable script to disablethe DDL trigger.

9. Run the ddl_setup script. You areprompted for:
	(1) The name of the Oracle GoldenGateDDL schema. If you changed the schema name, use the new one.
	(2) The installation mode: Selecteither NORMAL or INITIALSETUP mode, depending on what the installation orupgrade instructions require. 
		NORMAL mode recompiles the DDL environmentwithout removing DDL history. INITIALSETUP removes the DDL history.

10. Run the ddl_enable.sql script to enablethe DDL trigger.

11. In GGSCI, start Extract to resume DDLcapture.
	START EXTRACT<group>

12. Start Replicat to start DDLreplication.
	START REPLICAT<group>
	
	
	
	
------------------------------------------------------------------------------------

-- ORA-26723: user "GGATE" requires the role "DV_GOLDENGATE_REDO_ACCESS"
After shutting down the db, ran chopt on all the nodes --
abcde0025: (abncu1) /u01/abncu/admin> chopt disable dv

------------------------------------------------------------------------------------









/*
		PURGEOLDEXTRATCS does not work

* If not, add PURGEOLDEXTRACTS to the Manager parameter file to prevent old files from
accumulating.

* If you are using PURGEOLDEXTRACTS, make certain that the Manager user has the
authority to purge trail files, and make certain that the PURGEOLDEXTRACTS options are
used correctly. See the Oracle GoldenGate Windows and UNIX Reference Guide.

* Is there an obsolete Replicat group that is linked to the trail?

* A trail file will not be purged if another process has a checkpoint in it. Delete the
obsolete group with the DELETE REPLICAT command, so that the checkpoint records are
deleted.

* If a checkpoint table is being used for the group, log into the database with the DBLOGIN
command first, so that the checkpoint will be removed from the table.
DBLOGIN [TARGETDB <dsn>,] [USERID <user>, PASSWORD <pw>]
DELETE REPLICAT <group>>

*/