
Use v$session_longops if you have a long running pl/sql procedure and want to 
give feedback on how far the procedure proceeded. If the following Procedure 
is run, it will report its progress in v$session_longops. The Procedure will 
also set the module attribute in v$session which makes it possible to find the 
sid and serial# of the session. 
create table f(g number);

    create or replace procedure long_proc as
        rindex       pls_integer := dbms_application_info.set_session_longops_nohint;
        slno         pls_integer; 
                                              -- Name of task
        op_name      varchar2(64) := 'long_proc';
    
        target       pls_integer := 0;        -- ie. The object being worked on
        context      pls_integer;             -- Any info
        sofar        number;                  -- how far proceeded
        totalwork    number := 1000000;       -- finished when sofar=totalwork
    
                                              -- desc of target
        target_desc  varchar2(32) := 'A long running procedure';
    
        units        varchar2(32) := 'inserts';                -- unit of sofar and totalwork
      begin
    
      dbms_application_info.set_module('long_proc',null);
    
      dbms_application_info.set_session_longops (
        rindex,
        slno);
    
      for sofar in 0..totalwork loop
    
        insert into f values (sofar);
    
        if mod(sofar,1000) = 0 then
          dbms_application_info.set_session_longops (
            rindex,
            slno,
            op_name,
            target,
            context,
            sofar,
            totalwork,
            target_desc,
            units);
    
        end if;
    
      end loop;
    end long_proc;

If the procedure long_proc is run, you can issue the following query to get 
feedback on its progress: 

    select time_remaining,sofar,elapsed_seconds 
    from v$session_longops l, v$session s 
    where l.sid=s.sid and l.serial# = s.serial# and s.module='long_proc'
