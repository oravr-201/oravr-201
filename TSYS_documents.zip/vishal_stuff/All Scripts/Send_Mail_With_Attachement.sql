CREATE OR REPLACE PROCEDURE RAHULC.SEND_MAiL_wrapped
as
    v_Connection            UTL_SMTP.Connection;
    v_reply                 UTL_SMTP.REPLY;
    Message                 VARCHAR2(4000);
    crlf                    VARCHAR2(2):=chr(13)||chr(10);

    v_Sender                VARCHAR2(100);
    v_Recipient             VARCHAR2(100);
    v_Subject               VARCHAR2(100);
    v_Body                  VARCHAR2(1000);
    v_cc_recipt1            VARCHAR2(100);
    v_cc_recipt2            VARCHAR2(100);
    v_cc_recipt3            VARCHAR2(100);

    v_data                  varchar2(32000);

BEGIN

    v_Sender        := 'rahulc@infonox.com';
    v_Recipient     := 'rahulc@infonox.com';
    v_Subject       := 'Mail with attachment from PL/SQL'; -- mail subject line

/*
   -- If i_Error
    v_Body          := 'Hi All,'||chr(10)||chr(10)
                       ||chr(32)||chr(32)||'This is a first mail for an Attachement from Oracle version 10G '||chr(10)||chr(10)||
                       'Regards'||chr(10)||
                       '- DB Team';
*/

    v_cc_recipt1  := 'milindb@infonox.com';
    v_cc_recipt2  := 'gaurav@infonox.com';
    v_cc_recipt3  := 'srikanth@infonox.com';

     for i in (select CODE||','||DESCRIPTION||','||PATH||','||VALUE||','||B_OPTION||','||HELP_TEXT||','||OPERATION_TYPE||','||ACTION_TYPE||','||ACTIVITY_ACCESS oops
               from LOOKUP_POSTOFFICE_ACTION)
     loop

        v_data:= v_data||chr(10)||i.oops;

     end loop;

    dbms_output.put_line(v_Body);

    v_Connection := UTL_SMTP.OPEN_CONNECTION('MAIL.INFONOX.COM',25) ;
    v_reply      := UTL_SMTP.HELO(v_Connection,'MAIL.INFONOX.COM') ;
    v_reply      := UTL_SMTP.MAIL(v_Connection,v_Sender);
    v_reply      := UTL_SMTP.RCPT(v_Connection,v_Recipient);

    --IF v_cc_recipt1 is not null then
        UTL_SMTP.rcpt(v_Connection,v_cc_recipt1);
        UTL_SMTP.rcpt(v_Connection,v_cc_recipt2);
        UTL_SMTP.rcpt(v_Connection,v_cc_recipt3);
    --END IF;


    utl_smtp.Data(
                    v_Connection,

                    --- list of to, from, cc and subject line
                    'Date: '   || to_char(sysdate, 'Dy, DD Mon YYYY hh24:mi:ss') || crlf ||
                    'From: '||v_Sender||crlf||
                    'To: '||v_Recipient||crlf||
                    'Cc: '||v_cc_recipt1||crlf||
                    'Cc: '||v_cc_recipt2||crlf||
                    'Cc: '||v_cc_recipt3||crlf||
                    'Subject: '||v_Subject || crlf ||

                    'MIME-Version: 1.0'|| crlf ||       -- Use MIME mail standard
                    'Content-Type: multipart/mixed;'|| crlf ||
                    ' boundary="-----SECBOUND"'|| crlf ||

                    '-------SECBOUND'|| crlf ||
                    'Content-Type: text/plain;'|| crlf ||
                    'Content-Transfer_Encoding: 7bit'|| crlf ||

                    crlf ||
                    -- text message body
                    'Hi All,'||crlf||crlf||
                       chr(32)||chr(32)||'Testing email with Attachment from PL/SQL from Oracle version 10G '||crlf||crlf||
                    'Regards'||crlf||
                    '- DB Team'||crlf ||

                    '-------SECBOUND'|| crlf ||
                    'Content-Type: text/plain;'|| crlf ||
                    ' name="Attachment_Excel.cvs"'|| crlf ||
                    'Content-Transfer_Encoding: 8bit'|| crlf ||
                    'Content-Disposition: attachment;'|| crlf ||
                    ' filename="Attachment_Excel.cvs"'|| crlf ||
                    crlf || -- columns headline in excel file
                    'CODE, DESCRIPTION, PATH, VALUE, B_OPTION, HELP_TEXT, OPERATION_TYPE, ACTION_TYPE, ACTIVITY_ACCESS'||crlf||
                    v_data ||  -- Content / data in the excel file.
                    crlf ||
                    '-------SECBOUND--'
                                -- End MIME mail
                     -- any more text here can be added...

                  );

   -- UTL_SMTP.DATA(v_Connection,'MIME-Version: 1.0'||crlf||'Content-type: text/html' || crlf||Message);
    UTL_SMTP.QUIT(v_Connection);
END SEND_MAiL_wrapped;
/
