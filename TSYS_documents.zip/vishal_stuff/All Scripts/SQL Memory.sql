*Determine if the data block buffers is set high enough:

select 1-(sum(decode(name, 'physical reads', value,0))/ 	
	 (sum(decode(name, 'db block gets', value,0)) + 	
	 (sum(decode(name, 'consistent gets', value,0))))) * 100
	 "Read Hit Ratio" 
from   v$sysstat;

Read Hit Ratio
      98.415926

*Determine library cache hit ratio: 

select  sum(pins) Executions, sum(pinhits) Execution_Hits, 
        ((sum(pinhits) / sum(pins)) * 100) phitrat,
        sum(reloads) Misses,
        ((sum(pins) / (sum(pins) + sum(reloads))) * 100)  hitrat
from v$librarycache;

Executions 	Execution Hits   PHITRAT       Misses  HITRAT
  3,582              3,454        96.43        6       99.83

Tip: If the hit ratio or reloads is high, increase the shared_pool_size INIT.ora parameter.  Reloads indicate that
statements that were once in memory now had to be reloaded because they were pushed out, whereas misses include statements
that are loaded for the first time.

*Determine dictionary cache miss ratio: 

select 	sum(gets) Gets, sum(getmisses) Misses,
       	(1 - (sum(getmisses) / (sum(gets) +     	
	sum(getmisses))))*100 HitRate
from  	v$rowcache;

Gets 	Misses 	HitRate
10233    508 	95.270459

*How much memory is left for SHARED_POOL_SIZE:

col value for 999,999,999,999 heading SharedPoolSize
col bytes for 999,999,999,999 heading FreeBytes

select   	to_number(v$parameter.value) value, v$sgastat.bytes, 
(v$sgastat.bytes/v$parameter.value)*100 PercentFree
from 	v$sgastat, v$parameter
where	v$sgastat.name = 'free memory'
and v$sgastat.pool='shared pool'
and	v$parameter .name = 'shared_pool_size';

Shared Pool Size	Free Bytes	Percent Free
     100,000,000 	82,278,960	82.27896

*select sum(ksmchsiz) Bytes, ksmchcls Status
 from 	x$ksmsp
 group by 	ksmchcls;

BYTES       	STATUS 
    350,000	R-free                                                                                
         40 	R-freea                                                                               
     25,056 	free                                                                                  
  2,571,948	freeabl                                                                               
  4,113,872 	perm                                                                                  
  1,165,504 	recr
  
Tip: 
  
  An ORA-4031 is usually caused when the shared pool gets fragmented (you�re not necessarily out of shared pool) into
  smaller pieces over the course of a day and a request for a large piece of memory is issued which can not be filled. 
  
Tip:
  
  Retrieving information from memory is over 10,000 times (depending on the memory you have) faster than retrieving it from
  disk so make sure that the SGA is large enough

*select 	decode(state,0, 'FREE', 1, decode(lrba_seq,0,'AVAILABLE','BEING USED'), 
   	3, 'BEING USED', state) "BLOCK STATUS", count(*)
from 	x$bh
group by 	decode(state,0,'FREE',1,decode(lrba_seq,0,
   	'AVAILABLE','BEING USED'),3, 'BEING USED', state);


*Example 1 (Create a table with CACHE):

CREATE TABLE TEST_TAB (COL1 NUMBER)
TABLESPACE USERS
CACHE;

NOCACHE is the Default!

Example 2 (Alter a table to CACHE):

ALTER TABLE TEST_TAB
CACHE;

Example 3 (The CACHE Hint):

SELECT 	/*+ CACHE(CUST) */ ENAME, JOB
FROM   	CUST
WHERE  	TABLE_NAME = 'EMP';

Example 4 (The NOCACHE Hint):

SELECT 	/*+ FULL(CUST)  NOCACHE(CUST) */  ENAME, JOB
FROM   	CUST
WHERE  	TABLE_NAME = 'EMP';

*You may also pin (cache) PL/SQL object statements into memory: In the event that you cannot maintain a sufficient
SHARED_POOL_SIZE, it may become important to keep the most important objects cached (pinned) in memory.  The following
example shows how to pin PL/SQL object statements in memory using the DBMS_SHARED_POOL.KEEP procedure.  For additional
PL/SQL tips see chapter 10 which focus exclusively on PL/SQL. 

BEGIN 
  DBMS_SHARED_POOL.KEEP(�PROCESS_DATE�,�P�);
END;

Tip: Pin PL/SQL objects into memory immediately upon starting the database to avoid insufficient memory errors later in the
day.  To accomplish this, use the DBMS_SHARED_POOL.KEEP procedure for PL/SQL object statements.  Ensure that the STANDARD
procedure is pinned soon after startup since it is so large.


Goal#3: Find problem queries hurting memory

A single index or a single query can bring an entire system to a near standstill.  By using v$sqlarea, you can find the
problem queries on your system.  Below, the example shows how to find the problem queries.  I am searching for queries
where the disk reads are greater than 10,000.  If your system is much larger, you may need to set this to a higher number.

--Example 5 (Finding the largest amount of physical reads by query): 

select 	disk_reads, sql_text 
from   	v$sqlarea
where  	disk_reads > 10000 
order 	by disk_reads desc;

--Example 6 (Finding the largest amount of logical reads by query):

select 	buffer_gets, sql_text
from   	v$sqlarea
where  	buffer_gets > 200000
order by 	buffer_gets desc;

BUFFER_GETS	SQL_TEXT
------------------	-----------------------------------------------------------------
300219		select order#,cust_no, from orders 
		where division = �1�    


You may need to join to the v$sqltext view:

You may have to join in the v$sqltext table to get the full text since
v$sqlarea only shows a portion of the SQL_TEXT.  

Break on User_Name On Disk_Reads on Buffer_Gets on Rows_Processed

Select 	A.User_Name, B.Disk_Reads, B.Buffer_Gets,
       	B.Rows_Processed, C.SQL_Text
From 	V$Open_Cursor A, V$SQLArea B, V$SQLText C
Where	A.User_Name = Upper('&&User')
  And  	A.Address = C.Address
  And  	A.Address = B.Address
Order By 	A.User_Name, A.Address, C.Piece;
