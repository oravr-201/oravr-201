--
--    Below is the process for making comparison between 
--  All production Database
--
--

--- BELOW PROCESS IS FOR QPCW-SC DATABASE. 


--  Job (1) is run at each day 3.00 AM PST
-- The work of job is to call procedure Repl_Rowscount_Table_job
1) Repl_Rowscount_Table_job

-- procedure which populates data in ALL_JOB_DETAILS table, if there is any error in job Repl_Rowscount_Table_job
-- and also these procedure calls to second procedure Repl_Rowscount_Table
2) Repl_Rowscount_Table_Job

-- procedure populat the table Repl_Count_Tables
3) Repl_Rowscount_Table
     
     -- populate's the count of all table's records from all the schema's.
     Repl_Count_Tables
     
-------------------------------------------------
-------------------------------------------------

--- BELOW PROCESS IS FOR QPCW-SC-REPL DATABASE.

-- Job (2)
1) Repl_Rowscount_Table_job (job is executed at same time)

2) steps 2, 3 are same here also.

-- Job (3) is to call db_sync_job procedure
-- Runs at 3:30 AM PST -- Actually after completing the above job process
4) db_sync_job

-- these procedure populates different tables with using 
-- DBLink from Primary Database
5) db_sync_job
    
     i) REPL_TAB_SYNC_HIST 			-- insert's the history data from table REPL_TAB_SYNC and 
     					   			-- also insert's data from MISSING_TABLE_SECONDARYDB, STATUS is MISSING in hist table
    ii) REPL_COUNT_TABLES_SECONDRY  -- get's populate from using DBlink of primary database from table like ... REPL_COUNT_TABLES@DBLINK
   iii) MISSING_TABLE_SECONDARYDB   -- missing tables from secondry database
    iV)REPL_TAB_SYNC				-- main table for populating the comparison between primary and secondry databases
    
    
---------------------------------------------------- ***********----------------------------    
---------------------------------------------------- ***********----------------------------
---------------------------------------------------- ***********----------------------------
    
    
---- objects needed for primary database
schema name    := SRC_Monitor
Job at 3.00 AM := Repl_Rowscount_Table_job
procedure      := Repl_Rowscount_Table_job, Repl_Rowscount_Table
Table 		   := Repl_Count_Tables


---- objects needed for secondry database
schema name    := SRC_Monitor
Job at 3.00 AM := Repl_Rowscount_Table_job
Job at 3.30 AM := db_sync_job
procedure      := db_sync_job
Table 		   := REPL_TAB_SYNC_HIST, REPL_TAB_SYNC, MISSING_TABLE_SECONDARYDB, 
				  REPL_COUNT_TABLES_SECONDRY, REPL_COUNT_TABLES@DBLINK1562
				  
				  
---------------------------------- ********** ---------------------------------
---------------------------------- ********** ---------------------------------
---------------------------------- ********** ---------------------------------


-- SEQUENCE ALTERATION PROCESS

-- QCPW-SC

There is one job for altering the sequence 

Sequence_Newval_JOB -- job
Sequence_Newval_JOB -- Procedure
Sequence_Newval		-- procedure
SEQ_DET_WITHNEWVAL  -- populating sequence numbers
SEQ_LASTNO_HIST		-- last number of sequence number.



---------------------------------- ********** ---------------------------------
---------------------------------- ********** ---------------------------------
---------------------------------- ********** ---------------------------------

-- OBJECT VERIFICATION PROCESS

REPL_OBJECTS_VERIFICATION_JOB -- job
REPL_OBJECTS_VERIFICATION_JOB -- procedure
Repl_Objects_Verification -- procedure