----------------------------------------------------------------------
   Returining Days count between to days except saturday & sunday
----------------------------------------------------------------------

select count(*)
      from (select rownum rnum
              from all_objects
              where rownum <= to_date('15-nov-2004') - to_date('1-nov-2004')+1 )
     where to_char( to_date('1-nov-2004')+rnum-1, 'DY' ) 
                      not in ( 'SAT', 'SUN' )
