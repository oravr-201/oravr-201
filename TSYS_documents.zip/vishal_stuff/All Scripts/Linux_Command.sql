-- Linux Helpfull Command List

-- replace the string in big files without opening the files
grep -rl US7ASCII test.log |xargs sed -i -e 's/US7ASCII/US7ASCII1267892345/g'

--Shell scripting with conditions 

If then else condition

-eq�Checks to see if arguments are equal (for example, if [ 2 �eq 5 ] )
-ne�Checks for inequality of arguments
-lt�Checks if argument 1 is less than argument 2
-le�Checks if argument 1 is less than or equal to argument 2
-gt�Checks if argument 1 is greater than argument 2
-ge�Checks if argument 1 is greater than or equal to argument 2
-f�Checks if a file exists (for example, if [ -f "filename" ] )
-d�Checks if a directory exists

------------------------------------------------------------------------------

USEFUL SHELL SCRIPT ARGUMENTS

execute the below using echo ARGUMENTS

$1,$2----Positional parameter representing command line argument
$#----Number of arguments specified in command line
$0----Name of executed commands  -- for eg. echo $"Usage: $0 {start|stop|status|reload|restart|condrestart}"
$*---Complete set of positional parameters as a single string
"$@"----Each quotated string treated as seprate argument (recommended over $*)
$?---Exit status of last command
$$-- pid of current shell
#!----Pid of last bagoround job

---------------------------------------------------------------------------------

-- returns all the lines that contain a string 
-- matching the expression "foo" in the file "snox4transnox_backup_logs". 
 grep ORA snox4transnox_backup_logs.log

----------------------------------------------------------------------------------

 --- last 2 weeks files
find transnox/wucc/exp*.dmp -mtime -14 -print
 
--- exclude files which are modified last 2 weeks back... and take all files 
find transnox/wucc/exp*.dmp ! -mtime -14 -ls


--- this command finds out file which are not in modified in 14 days and which are in between 26 days
 find ../../transnox/centennial/exp*.dmp ! -mtime +26 ! -mtime -14 -ls
 
 
 -- one day prevoius file sreaching
 find /ora3/oracle/oradata/coms/archive -type f -mtime +0 -exec ls -l {} \;
 
 
 -- sreaching for the days given 
 ls -ltrh |grep "Jul  5"

 -- remove the files up till date like Mar 12
 ls -ltr | grep "Mar 12" | awk '{print $9}'  | xargs rm -f
 
 
  tar -zvxf snoxgateway.tar.gz
 
 %s/angad/rahul
 
 %s/angad/rahul/g
 
%s/\/home\/angad/\/home\/rahul/g


-- vi option for replace in front of script
:%s/^/ mv /g 

-- vi option for replace at the end of the script
:%s/$/ \/moneris5\/old_archive\/coms /g


:%s/$/ \/ora10\/old_archive /g

/ora10




-- checking the multiple disk space on linux
#!/bin/bash
for ID in `df -h | grep -v none | grep -v Filesystem | grep -v "/" | grep -v -w "home"| awk '{if ($5 > "80%") print $1 " " $5}' | sed 's/ /=/g'`
do
        echo $ID | sed 's/=/ /g'
        excecute the script
done


-- checking the /home partition disk space on linux
VAL=`df -h | grep "/ora4" | awk '{print $5}'`

if [ $VAL > 80 ]
then
	execute script
else
	:
fi

--- we can move more the one files in one command
-- i is string and 
-- t is verbose
ls olddir | xargs -i -t mv olddir/ newdir/


--- scp command help
expect -c "
# exp_internal 1 # uncomment for debugging
spawn  scp -q qcp_xtns.dmp oracle@logarchive.ifxlv.com:/archive/bkups/dumps/transmoneris
expect { 
		"*password:*" { send oracle@7534\r\n; interact } 
		eof { exit }
	}
exit
"
 
--********************************

 /* vi command option */
 
 vi command options
 
 esc :q!         --Just quit - donot save 
 esc :e!         --Revert to saved 
 esc :wq         --Save and exit 
 
 esc shift zz    --Save and exit 
 esc i           --Enter insert mode (edit mode) 
 esc a           --Enter append mode (edit mode) 
 esc             --Exit edit mode 
 esc r           --Replace a single character 
 esc x           --Delete a single character 
 esc dd          --Delete a single line 
 esc yy          --Copy a single line 
 esc p           --Paste a single line 
 .               --Repeat the last command 
 esc /           --String search 
 esc $           --Jump to end of line 
 esc ^           --Jump to begining of line 
 shift g         --Jump to the end of the file 
 :1              --Jump to the begining of the file 
 :.=             --Display the current line number 

--********************************

--command finds the unique key values in a file
cat gcatest.log|awk -F ' ' {'print $3'}|uniq|sort|uniq

--- will delete the first thousand 
ls -ltrh|head -n 1000|awk '{print $9}'|xargs rm -f




00 19 * * * sh /archive/dba/bkups/bkups_scripts/veroDB_bkup_script.sh

30 19 * * * sh /archive/dba/bkups/bkups_scripts/tsnoxDB_bkup_script.sh

00 20 * * * sh /archive/dba/bkups/bkups_scripts/exp_SSA_bkup_script.sh

25 20 * * * sh /archive/dba/bkups/bkups_scripts/moneris_T2_bkups_script.sh

55 20 * * * sh /archive/dba/bkups/bkups_scripts/sigue_bkup_script.sh

00 21 * * * sh /archive/dba/bkups/bkups_scripts/transgca_script.sh

31 22 * * * sh /archive/dba/bkups/bkups_scripts/trans_bkup_script.sh


-- to remove the 3 days older files
30 21 * * * find /ora1/oracle/bkups/dumps/transending/moneris/* -ctime +3 -exec rm -R {} \;

# remove the old backups
00 20 * * * find /archive/dba/bkups/dumps/transending/sigueGreystone/* -ctime +3 -exec rm -R {} \;
30 20 * * * find /archive/dba/bkups/dumps/transending/capitalone/* -ctime +5 -exec rm -R {} \;
30 21 * * * find /archive/dba/bkups/dumps/transending/moneris/* -ctime +5 -exec rm -R {} \;



#55 18 * * * sh /archive/dba/bkups/bkups_scripts/exp_snox_glorywm_bkup.sh

#20 19 * * * sh /archive/dba/bkups/bkups_scripts/exp_keyNox_fx_bkup.sh

#25 19 * * * sh /archive/dba/bkups/bkups_scripts/exp_snox_gca_bkup.sh

#50 19 * * * sh /archive/dba/bkups/bkups_scripts/exp_glorywm_bkup.sh

#20 20 * * * sh /archive/dba/bkups/bkups_scripts/exp_tsnox_gca_bkup.sh