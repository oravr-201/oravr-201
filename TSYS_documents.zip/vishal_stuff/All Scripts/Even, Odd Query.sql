            One can easily select all even, odd, or Nth rows from a 
            table using SQL queries like this: 
            
            
SELECT *
FROM emp
WHERE (ROWID,0) IN (SELECT ROWID, MOD(ROWNUM,4) FROM emp)
