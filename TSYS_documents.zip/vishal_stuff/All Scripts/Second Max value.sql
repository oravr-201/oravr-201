select max(hdate) from sdate where hdate < (select max(hdate) from sdate)

------------------------------------------------------------------------------

SELECT 
  *
FROM 
  (select salary, dense_rank() over ( order by salary )r  from salary )
WHERE  r = 2;  	  	  	  	
  
  select * from (select hdate, row_number() 
    over ( order by hdate desc ) r from sdate)
  where r = 2

------------------------------------------------------------------------------

SELECT 
  *
FROM 
  (select employee_id,
  first_name,
  last_name,
  salary,
  dense_rank() over(order by salary)r from employee)
WHERE 
  r = 4
  
------------------------------------------------------------------------------
		   
  select * FROM sdate 
    where hdate = (select max(hdate) from sdate 
       where hdate < (select max(hdate) from sdate));

------------------------------------------------------------------------------
		   
select * FROM sdate
        where hdate = (select max(hdate) from sdate
           where hdate < (select max(hdate) from sdate))

------------------------------------------------------------------------------
		   
select first_name, salary from employee where salary = 
    (select salary from 
        (select rownum rank, salary from (select distinct(salary) 
              salary from employee order by salary desc)) 
    where rank = 6);
	
	
---- second record

SELECT first_Name, Manager_id FROM (
SELECT First_Name, manager_id, rank() over(Order by Manager_id desc Nulls last)as Rank_MGR
FROM employee) WHERE Rank_MGR < 4



SELECT min(add_Months(hire_date,-1)) FROM employee



SELECT Min(x.DF) FROM (SELECT DISTINCT hire_Date AS DF  FROM EMPLOYEE 
ORDER BY DF ASC) X WHERE ROWNUM < 5

SELECT 
       HDATE
FROM
   (SELECT 
           min(HDATE),
           RANK() OVER(ORDER BY HDATE ASC NULLS FIRST) AS Emp_Rank
      FROM SDate
      ORDER BY HDATE ASC NULLS FIRST
    )
WHERE HDATE < 2
GROUP by HDATE



----------- ? highest query just chage the value in place of 3
---- it will give the highest
	
SELECT  eid FROM EMP1 c1
WHERE 3=(SELECT COUNT(*) FROM EMP1 c2
WHERE C1.eid<=C2.eid)

		   
