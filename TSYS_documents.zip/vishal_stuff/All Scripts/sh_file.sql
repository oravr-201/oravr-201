#cd /ora3/oracle/oradata/mons/archive

for fn in `cat temp_move.sh`
do
	echo ""
    MK_TAR=`echo $fn |sed 's/.arc/.tar.gz/g'`
    tar -cvzf $MK_TAR  $fn

    # deleting non tar files
    rm -f $fn

    # moving thetar file to different destination
    mv $MK_TAR  /moneris6/oracle/old_arch_ora3
done

rm -f temp_move.sh




00 22 * * * su - oracle -c "sh /ora3/archive_cronjob/tar_script.sh" > /ora3/archive_cronjob/logs_cronjob_arc.log

00 22 * * * su - oracle -c "sh /ora4/archive_cronjob/tar_script.sh" > /ora4/archive_cronjob/logs_cronjob_arc.log

05 01 * * * su - oracle -c "sh /ora3/oracle/archive_cronjob/tar_script.sh" > /archive/dba/tar_srtp_cjob_logs.log

30 22 * * 1 su - oracle -c "sh /ora3/oracle/archive_cronjob/weekly_script.sh" > /archive/dba/weekly_cjob_logs.log

00 07 * * * su - mysql -c "sh /home/mysql/bkup_mysql_script/mysql_db_bck_script.sh" > /home/mysql/bkup_mysql23166_logs.log




-- weekly scripts
#!/bin/bash
# transfer and remove the weekly tar file to other location 

#remove weekly tar files from /ora10/old_archive folder
cd /moneris5/old_archive/coms/

find *.gz -mtime +7 -exec rm -f {} \; 


#transfer weekly tar files 
cd /moneris6/old_archive/coms/

find *.gz -mtime +7 -exec ls -l {} \; > weekly_move_tarfiles.sh

for fn in `cat weekly_move_tarfiles.sh |awk '{print $9}'`
do
   echo " "
   echo "mv $fn /moneris5/old_archive/"

done




/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@10.65.25.34
expect "password:"
send "oracle@1534\r"
expect "sftp> "
send "put /ora5/oracle/exp_transgca.tar  /ora8/oracle/exp_transgca.tar\r"
expect "sftp> "
expect "sftp> "
send "exit\r"
SCRIPT_END



-- archiving 1 day older archive file scripts.
#!/bin/bash

# checking the /data disk partition space where archive files are getting created
VAL=`df -h | grep "/data" | awk '{print $5}'|sed 's/%//g'`

if [ $VAL '>' 80 ]
then
    echo "$VAL"
    echo  $VAL > disk_checking.log
    echo "Disk space above 80%"
    
    cd /ora6/oracle/arc_aqprod
    
       find *.dbf -type f -mtime +0 -exec ls -l {} \; > temp_file.sh 
       
       for fn in `cat temp_file.sh |awk '{print $9}'`
	   do
	           echo " "
	   
	           # deleting non tar files
	           rm -f $fn
	   
	   done
	   
	   rm -f temp_file.sh       
else
    echo "$VAL"
    echo "Disk space is below 80%"
fi


-- 
for fn in `cat temp_move.sh`
do
	echo ""
    MK_TAR=`echo $fn |sed 's/.dbf/.tar.gz/g'`
    tar -cvzf $MK_TAR  $fn

    # deleting non tar files
    rm -f $fn

    # moving thetar file to different destination
    mv $MK_TAR  /moneris5/old_archive
done

rm -f temp_move.sh




-- archiving 1 day older archive files script
#!/bin/bash

cd /ora4/oracle/oradata/aqprod/archive

find 1_*.arc -type f -mtime +0 -exec ls -l {} \; > temp_file.sh

for fn in `cat temp_file.sh |awk '{print $9}'`
do
        echo " "

        # making the ta files
        MK_TAR=`echo $fn |sed 's/.dbf/.tar.gz/g'`
        tar -cvzf $MK_TAR  $fn

        # deleting non tar files
        rm -f $fn

        # moving thetar file to different destination
        mv $MK_TAR  /ora8/old_archive/
done


rm -f temp_file.sh



--- disk checking script
#!/bin/bash

# checking the /data disk partition space where archive files are getting created
VAL=`df -h | grep "/data" | awk '{print $5}'|sed 's/%//g'`

if [ $VAL '>' 78 ]
then
    echo "$VAL"
    echo  $VAL > log_no_ds.log
    echo "Disk space above 80%"
    sh /ora4/oracle/archive_cronjob/arch_1day_older_files.sh
else
    echo "$VAL"
    echo "Disk space is below 80%"
fi

*/15 * * * * su - oracle -c "sh /ora4/archive_cronjob/disk_space_checking.sh" > /ora4/archive/cronjob/ds_cron_logs.log

*/30 * * * * su - oracle -c "sh /ora3/archive_cronjob/check_disk_space.sh" > /ora3/archive_cronjob/ds_cron_log.log

/etc/init.d/crond restart
