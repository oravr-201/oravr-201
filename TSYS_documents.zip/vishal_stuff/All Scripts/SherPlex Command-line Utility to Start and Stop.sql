How to stop and start SharePlex for Oracle Command Utility


 -- Shutdown Command
1) Logging to DB server where the SharePlex utility is running 
2) connect to spadmin user
    
	pbrun su -l spadmin
	
3) After logging to spadmin user, Check if the SherPlex is running by command

   ps -ewf |grep sp_

4) If nothing is coming then SherPlex is not running, If some thing is returning by above command then SherPleX is running
5) To Shudown the SherPlex utility, first connect to SherPlex Command-Line Utility   

    sp_ctrl

6) Once SherPlex Command-line utility is logged in execute 

    shutdown
	
7) Check again by command

    ps -ewf |grep sp_
	
8) If there is nothing returning then SherPlex is shutdown.


-- Start SherPlex replicator
1) Logging to DB server where the SharePlex utility is running 
2) connect to spadmin user
    
	pbrun su -l spadmin
	
3) After logging to spadmin user, Check if the SherPlex is running by command

   ps -ewf |grep sp_

4) If nothing is coming then SherPlex is not running, If some thing is returning by above command then SherPleX is running
5) To Start the utility, execute the bleow command on main command prompt of spadmin (not under sp_ctrl command prompt)
   
    sp_cop -u 2100 &
	
6) After executing the above command, check if SherPlex is really started

   ps -ewf |grep sp_

7) if above command returns something then SherPlex is started Successfully, if not then start with quick start command 

     sp_ctrl (execute the command to enter in SherPlex utility command-line)
	 
	 sp_ctrl> start post


8) qstatus is the command for checking the status
