Anchoring Characters are metacharacters that 
affect the position OF the search.
----------------------------------------------------
Character Class      Description
^      Anchor the expression TO the START OF a line
$      Anchor the expression TO the END OF a line
 
 
 
Equivalence Classes      
----------------------------------------------------
Character Class      Description
= =      Oracle supports the equivalence classes through 
        the POSIX '[==]' syntax. A base letter AND ALL OF 
        its accented versions constitute an equivalence 
        class. FOR example, the equivalence class '[=a=]' 
        matches ? AND ?. The equivalence classes are valid 
        only inside the bracketed expression
 
 
Match Options determine IF the target IS treated checked FOR 
case-sensitivity AND whether OR NOT the target IS evaluated 
line BY line OR AS a continuous string. 
----------------------------------------------------
Character Class      Description
c      CASE sensitive matching
i      CASE insensitive matching
m      TREAT source string AS multi-line activating Anchor chars
n      Allow the period (.) TO match ANY newline character
 
 
 
Posix Characters tend TO look very ugly but have the advantage 
that also take INTO account the 'locale', that IS, ANY variant 
OF the local language/coding system.
----------------------------------------------------
Character Class      Description
[:digit:]      Only the digits 0 TO 9
[:alnum:]      ANY alphanumeric character 0 TO 9 OR A TO Z OR a TO z.
[:alpha:]      ANY alpha character A TO Z OR a TO z.
[:blank:]      SPACE AND TAB characters only.
[:xdigit:]     Hexadecimal notation 0-9, A-F, a-f.
[:punct:]      Punctuation symbols 
                --------------------------------
                % . , " ' ? ! : # $ & ( ) * ;
                + - / < > = @ [ ] \ ^ _ { } | ~  
                --------------------------------  --'
[:print:]      Any printable character.
[:space:]      Any whitespace characters (space, tab, NL, FF, VT, CR). 
                Many system abbreviate as \s.
[:graph:]      Exclude whitespace (SPACE, TAB). Many system abbreviate as \W.
[:upper:]      Any alpha character A to Z.
[:lower:]      Any alpha character a to z.
[:cntrl:]      Control Characters NL CR LF TAB VT FF NUL SOH STX 
                EXT EOT ENQ ACK SO SI DLE DC1 DC2 DC3 DC4 NAK SYN 
                ETB CAN EM SUB ESC IS1 IS2 IS3 IS4 DEL.
 
 
Quantifier Characters control the number of times a character 
or string is found in a search.
----------------------------------------------------
Character Class      Description
*      Match 0 or more times
?      Match 0 or 1 time
+      Match 1 or more times
{m}      Match exactly m times
{m,}      Match at least m times
{m, n}      Match at least m times but no more than n times
\n      Cause the previous expression to be repeated n times
 
 
 
Alternative Matching And Grouping Characters      
----------------------------------------------------
Character Class      Description
|      Separates alternates, often used with grouping 
        operator ()
 
( )      Groups subexpression into a unit for alternations, for 
        quantifiers, or for backreferencing 
 
[char]      Indicates a character list; most metacharacters inside a
        character list are understood as literals, with the 
        exception of character classes, and the ^ 
        and - metacharacters
 
 
////////////////////////////////////////////////////
Regex Cheat Sheet (non-posix)
////////////////////////////////////////////////////
 
 
Modifiers: 
i   case-insensitive pattern matching. 
 
g   global replace, or replace all 
 
m   Treat string as multiple lines. That is, 
    change ``^'' and ``$'' from matching at only 
    the very start or end of the string to the 
    start or end of any line anywhere within the string 
 
s   Treat string as single line. That is, change ``.'' to 
    match any character whatsoever, even a newline, which 
    it normally would not match. 
 
x   Extend your patterns legibility by permitting 
    whitespace and comments.
 
 
Special Characters:
The following should be escaped if you are trying to 
match that character:
 
 \  ^  .  $  |  (  )  [  ]
 *  +  ?  {  }  ,
 
 
Special Character Definitions:
    \   Quote the next metacharacter
    ^   Match the beginning of the line
    .   Match any character (except newline)
    $   Match the end of the line (or before newline at the end)
    |   Alternation
    ()  Grouping
    []  Character class
    *      Match 0 or more times
    +      Match 1 or more times
    ?      Match 1 or 0 times
    {n}    Match exactly n times
    {n,}   Match at least n times
    {n,m}  Match at least n but not more than m times
 
More Special Characters: 
    \t          tab                   (HT, TAB)
    \n          newline               (LF, NL)
    \r          return                (CR)
    \f          form feed             (FF)
    \a          alarm (bell)          (BEL)
    \e          escape (think troff)  (ESC)
    \033        octal char (think of a PDP-11)
    \x1B        hex char
    \c[         control char
    \l          lowercase next char (think vi)
    \u          uppercase next char (think vi)
    \L          lowercase till \E (think vi)
    \U          uppercase till \E (think vi)
    \E          end case modification (think vi)
    \Q          quote (disable) pattern metacharacters till \E
 
Even More Special Characters:
    \w  Match a "word" character (alphanumeric plus "_")
    \W  Match a non-word character
    \s  Match a whitespace character
    \S  Match a non-whitespace character
    \d  Match a digit character
    \D  Match a non-digit character
    \b  Match a word boundary
    \B  Match a non-(word boundary)
    \A  Match only at beginning of string
    \Z  Match only at end of string, or before newline at the end
    \z  Match only at end of string
    \G  Match only where previous m//g left off (works only with /g)
