Procedure to enable SQL trace for users on your database:
=========================================================

1. Get the SID and SERIAL# for the process you want to trace.

	SQL> select sid, serial# from sys.v_$session where ...
	       SID    SERIAL#
	---------- ----------
	         8      13607

2. Enable tracing for your selected process:

	SQL> ALTER SYSTEM SET TIMED_STATISTICS = TRUE;
	SQL> execute dbms_system.set_sql_trace_in_session(8, 13607, true); 

3. Ask user to run just the necessary to demonstrate his problem.

4. Disable tracing for your selected process:

	SQL> execute dbms_system.set_sql_trace_in_session(8,13607, false); 
	SQL> ALTER SYSTEM SET TIMED_STATISTICS = FALSE;

5. Look for trace file in USER_DUMP_DEST

	$ cd /app/oracle/admin/oradba/udump  
	$ ls -ltr
	total 8
	-rw-r-----    1 oracle   dba         2764 Mar 30 12:37 ora_9294.trc

6. Run TKPROF to analyse trace output

	$ tkprof ora_9294.trc x EXPLAIN=monitor/oramon SYS=NO 

7. View or print the output file x.prf.

