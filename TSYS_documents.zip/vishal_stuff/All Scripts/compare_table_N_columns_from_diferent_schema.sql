-- Checks the missing constraints
SELECT DISTINCT j.table_name,
  NVL2((SELECT table_name FROM dba_constraints i1 WHERE i1.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_IOX'),'Y','N') "IOX",
  NVL2((SELECT table_name FROM dba_constraints i2 WHERE i2.table_name = j.table_name AND constraint_type='P' AND owner='TRANSNOX_CAT'),'Y','N') "CAT"
FROM 
     (SELECT DISTINCT table_name 
      FROM 
        (SELECT owner, table_name FROM dba_tables 
         WHERE owner IN ('TRANSNOX_IOX', 'TRANSNOX_CAT')
          MINUS
         SELECT owner, table_name 
         FROM dba_constraints 
         WHERE constraint_type='P'
           AND owner IN ('TRANSNOX_IOX', 'TRANSNOX_CAT')
         )
      WHERE table_name <> 'RELEASE_HISTORY'
         AND table_name NOT LIKE '%BKP%'
         AND table_name NOT LIKE '%TEMP%'
         AND table_name NOT LIKE 'TODROP'
         AND table_name NOT LIKE '%BK%'
         AND table_name NOT LIKE '%STAGDB%'
         AND table_name NOT LIKE '%TABLE%'
         AND table_name NOT LIKE '%TEST%'
         AND table_name NOT LIKE '%0%'
         AND table_name NOT LIKE '%PROD%'
      )j
         

--- Checks the Missing tables
SELECT table_name, IOX, CAT
FROM (
SELECT DISTINCT j.table_name,
  NVL2((SELECT table_name FROM dba_tables i1 WHERE i1.table_name = j.table_name AND owner='TRANSNOX_IOX'),'Y','N') IOX,
  NVL2((SELECT table_name FROM dba_tables i2 WHERE i2.table_name = j.table_name AND owner='TRANSNOX_CAT'),'Y','N')  CAT
FROM   
    (
      SELECT TABLE_NAME
      FROM dba_TABLES
      WHERE owner IN ('TRANSNOX_IOX', 'TRANSNOX_CAT')
        AND table_name NOT LIKE '%TEMP%'
        AND table_name NOT LIKE '%TEST%'
        AND table_name NOT LIKE '%0%'
        AND table_name NOT LIKE '%BK%'
        AND table_name NOT LIKE '%BKP%'
        AND table_name NOT LIKE '%DROP%'
    )j)
WHERE NOT (IOX = 'Y' AND CAT = 'Y') 
ORDER BY table_name ASC







-- Check the Missing columns
SELECT table_name, column_name, IOX, CAT
FROM
  (
    SELECT DISTINCT j.table_name, j.column_name,
      NVL2((SELECT column_name FROM dba_tab_columns i1 WHERE i1.table_name = j.table_name AND i1.column_name = j.column_name AND owner='TRANSNOX_IOX'),'Y','N') IOX,
      NVL2((SELECT column_name FROM dba_tab_columns i2 WHERE i2.table_name = j.table_name AND i2.column_name = j.column_name AND owner='TRANSNOX_CAT'),'Y','N')  CAT
    FROM
        (
            SELECT owner, table_name, column_name
            FROM dba_tab_columns
            WHERE owner IN ('TRANSNOX_IOX', 'TRANSNOX_CAT')
              AND table_name IN(SELECT table_name
                                FROM (
                                SELECT DISTINCT j.table_name,
                                  NVL2((SELECT table_name FROM dba_tables i1 WHERE i1.table_name = j.table_name AND owner='TRANSNOX_IOX'),'Y','N') IOX,
                                  NVL2((SELECT table_name FROM dba_tables i2 WHERE i2.table_name = j.table_name AND owner='TRANSNOX_CAT'),'Y','N')  CAT
                                FROM
                                    (
                                      SELECT TABLE_NAME
                                      FROM dba_TABLES
                                      WHERE owner IN ('TRANSNOX_IOX', 'TRANSNOX_CAT')
                                        AND table_name NOT LIKE '%TEMP%'
                                        AND table_name NOT LIKE '%TEST%'
                                        AND table_name NOT LIKE '%0%'
                                        AND table_name NOT LIKE '%BK%'
                                        AND table_name NOT LIKE '%BKP%'
                                        AND table_name NOT LIKE '%DROP%'
                                    )j)
                                WHERE CAT = 'Y' AND IOX = 'Y')
        )j
  )
WHERE NOT (CAT = 'Y' AND IOX = 'Y')
ORDER BY table_name ASC
