          TYPE Ref_Cur_Type 	 	IS REF CURSOR;
	           ref     	Ref_Cur_Type;

    OPEN ref FOR v_HeadDateQuery(run time select query);
       LOOP
		FETCH HeadDateQuery_Cur INTO  v_Timestamp,v_TotalBalance, v_description;
		EXIT WHEN ref%NOTFOUND;

	snoxdevices me Acm_Cashbalancereport procs puchna hai........................

    -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
OPEN HeadDateQuery_Cur FOR v_HeadDateQuery;
	LOOP
		FETCH HeadDateQuery_Cur INTO
		v_Binnumber,
		v_Denomination,
		v_Current_Balance_Amount,
		v_Current_Dispensed_Amount,
		v_Current_Retained_Amount,
		v_Config_Id;

		EXIT WHEN HeadDateQuery_Cur%NOTFOUND;
		v_InsertQuery :=    ' INSERT INTO ' || v_TempTable || '( '||
									' Sr_Nr,'||
									' Description,'||
									' Value '||
									' ) '||
									' VALUES ( :1,:2,:3)';

		EXECUTE IMMEDIATE v_InsertQuery	USING
		v_SerialNo,
		'Config ID For Bin '||v_Binnumber ,
		v_Config_Id;
		v_SerialNo := v_SerialNo +1;

	END LOOP;
	CLOSE HeadDateQuery_Cur;
	v_SerialNo := v_SerialNo +1;


-----------------------------------------------------------------------------------------
TYPE    TmpCurTyp IS REF CURSOR RETURN employees%ROWTYPE;
tmp_cv  TmpCurTyp; -- declare cursor variable

DECLARE
  TYPE EmpRecTyp IS RECORD (
                           employee_id NUMBER,
							last_name VARCHAR2(25),
							salary NUMBER(8,2)
							);
TYPE   EmpCurTyp IS REF CURSOR RETURN EmpRecTyp;
emp_cv EmpCurTyp; -- declare cursor variable

-----------------------------------------------------------------------------------------

DECLARE
CURSOR c1 IS SELECT last_name FROM employees ORDER BY last_name;
	name1 employees.last_name%TYPE;
	name2 employees.last_name%TYPE;
	name3 employees.last_name%TYPE;
BEGIN
OPEN c1;
	FETCH c1 INTO name1; -- this fetches first row
	FETCH c1 INTO name2; -- this fetches second row
	FETCH c1 INTO name3; -- this fetches third row
CLOSE c1;
END;

-------------------------------------------------------------------------------------------

BEGIN
FOR item IN
( SELECT last_name, job_id FROM employees WHERE job_id LIKE '%CLERK%'
AND manager_id > 120 )
LOOP
DBMS_OUTPUT.PUT_LINE('Name = ' || item.last_name || ', Job = ' ||
item.job_id);
END LOOP;
END;
/


---------------------------------------------------------------------------------------------

DECLARE
	   CURSOR c1 IS
	   		  SELECT t1.department_id, department_name, staff
			  FROM departments t1,
			  ( SELECT department_id, COUNT(*) AS staff
			    FROM employees GROUP BY department_id
			  ) t2
			  WHERE
			  t1.department_id = t2.department_id
			  AND staff >= 5;
BEGIN
	 FOR dept IN c1
	 	 LOOP
       DBMS_OUTPUT.PUT_LINE('Department = ' || dept.department_name || ', staff = ' || dept.staff);
		 END LOOP;
END;
/


-------------------------------------------------------------------------------------------------

DECLARE
	TYPE empcurtyp IS REF CURSOR RETURN employees%ROWTYPE;
	 emp empcurtyp;
-- after result set is built, process all the rows inside a single procedure
-- rather than calling a procedure for each row

	PROCEDURE process_emp_cv (emp_cv IN empcurtyp) IS
	person employees%ROWTYPE;
BEGIN
	DBMS_OUTPUT.PUT_LINE('-----');
	DBMS_OUTPUT.PUT_LINE('Here are the names from the result set:');
		
       LOOP
		FETCH emp_cv INTO person;
			EXIT WHEN emp_cv%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE('Name = ' || person.first_name ||' ' || person.last_name);
	END LOOP;
END;


BEGIN
-- First find 10 arbitrary employees.
OPEN emp FOR SELECT * FROM employees WHERE ROWNUM < 11;
process_emp_cv(emp);
CLOSE emp;
-- find employees matching a condition.
OPEN emp FOR SELECT * FROM employees WHERE last_name LIKE 'R%';
process_emp_cv(emp);
CLOSE emp;
END;



-------------------------------------------------------------------------------------------------


CREATE OR REPLACE PROCEDURE Cc_Assign_Csr_From_Queue
(
	i_Csr_Id		  IN		    VARCHAR2,
	
     o_OutputStatus 	  OUT 	    NUMBER,
	o_OutputMessage   OUT 	    VARCHAR2		  
)
AS 
	v_CSR_Queue	  	  	VARCHAR2(100);
	sqlStr				VARCHAR2(1000);
	v_ProductCode			VARCHAR2(50);
	v_ErrorFlag			NUMBER;
	
	CURSOR Csr_Weight(v_Curr_Task NUMBER)
	IS
		 SELECT
			Csr_Id
		 FROM
			CC_CSR CSR
		 WHERE
			CSR.Last_Poll_Time > SYSDATE-15/(24*60*60)
			AND	CSR.Max_Task > v_Curr_Task
		 ORDER BY
			CSR.Weight DESC;

	CURSOR csr_roundrobin (v_curr_task NUMBER, v_User_ID VARCHAR2,v_Product VARCHAR2)
	IS
		SELECT USER_ID FROM CC_CSR_TASK_cst.LAST_POLL_TIME > SYSDATE-15/(24*60*60));

	  V_ERROR_LOCATION   			   NUMBER;
BEGIN
	v_Csr_Id:=NULL;

	v_Current_Tasks:= Cc_Get_Csr_Task(i_Csr_Id);
	
	v_ErrorFlag := 1;
	
	sqlStr := 
	'SELECT	 	'||
		   'session_id,				'||
		   'task_id,				'||
		   'owner,					'||
		   'CSR_TASK_STATE, 		'||	
		   'TASK_SOURCE				'||		
	'FROM  						'||
		   'cc_csr_task tsk			'||
	'WHERE 						'||
		 'tsk.OWNER in (SELECT queue_id FROM cc_csr_queue WHERE csr_id = ''' || i_Csr_Id || ''')													'||
		 'AND tsk.TASK_SOURCE IN (SELECT CODE FROM PRODUCT_MASTER WHERE COMPANY_CODE IN' ||  i_Company || ')	'||
		 'AND rownum < 2		    '||
		 'AND CSR_TASK_STATE NOT IN (''END'',''ENDED'')' ||
	'ORDER BY tsk.START_TIME';
			


********************                important            ***********************


			
	EXECUTE IMMEDIATE sqlStr INTO v_session_id,v_task_id,v_Owner,v_Csr_task_state,v_ProductCode;
	 
		v_ErrorFlag := 2;
			
		IF UPPER(i_Algo) = 'BY_WEIGHTS' THEN
			BEGIN
				OPEN Csr_Weight(v_Current_Tasks);
				FETCH Csr_Weight INTO v_Csr_Id;
				IF Csr_Weight%ISOPEN THEN
					CLOSE Csr_Weight;
				END IF;
			END;
			v_ErrorFlag := 3;
			
		ELSIF UPPER(i_Algo) = 'ROUNDROBIN' THEN
			BEGIN
				OPEN Csr_RoundRobin(v_Current_Tasks,i_Csr_Id,v_ProductCode);
				FETCH Csr_Roundrobin INTO v_Csr_Id;
				IF csr_roundrobin%ISOPEN THEN
					CLOSE Csr_Roundrobin;
				END IF;
			END;
			v_ErrorFlag := 4;
			
		ELSIF UPPER(i_Algo) = 'RANDOM' THEN
			BEGIN
			    V_ERROR_LOCATION := 1;
		   		SELECT
		   		   Csr_Id
				INTO
				   v_Csr_Id
 	  		FROM
 	  		   CC_CSR CSR,
			   	   SNOX_USER_ACCESS su
	  		WHERE
	  		  csr.CSR_ID = su.USER_ID 
			      AND su.CALLNOX = 'G'
			      AND CSR.MAX_TASK > v_Current_Tasks 
				  AND Csr_Id = i_Csr_Id;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					 v_Csr_Id := NULL;			
			END;
		ELSE
		    v_ErrorFlag := 5;
			BEGIN
				SELECT
				   csr_id
				INTO
				   v_Csr_Id
				FROM
				   CC_CSR csr,
			   	   SNOX_USER_ACCESS su
				WHERE
	  		   csr.CSR_ID = su.USER_ID
			   	   AND su.CALLNOX = 'G' AND				
				   csr.MAX_TASK > v_Current_Tasks
				   AND csr_id = i_Csr_Id;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					 v_Csr_Id := NULL;				
			END;

			v_ErrorFlag := 6;
		END IF;
		
		v_ErrorFlag := 7;
		
    IF v_Csr_Id IS NOT NULL THEN
   	    BEGIN   		
	        Cc_Transfer_Csr
			  (
			  	 v_session_id,
				 v_Task_id,
				 i_Csr_Id,
				 v_Owner,
				 'Auto assigned task FROM queue to user',
				 o_OutputStatus,
				 o_OutputMessage
			  );
			  
			v_ErrorFlag := 8;
			  
			IF o_OutputStatus <> 0 THEN			
				RETURN;
			END IF;
			
			v_ErrorFlag := 9;
			
			UPDATE CC_CSR_TASK_ASSIGN_TS 
			SET LAST_ASSIGN_TIME = SYSDATE
			WHERE USER_ID = i_Csr_Id;
			
			v_ErrorFlag := 10;
			
			IF v_Owner= 'CSR_DE_QUEUE' AND v_Csr_task_state = 'END'	THEN
				UPDATE
				   CC_CSR_TASK
			   	SET
				   CSR_TASK_STATE = 'DATA_ENTRY'
			   	WHERE
			   	   session_id  = V_session_id
			   	   AND task_id = V_task_id ;
			END IF;
			
			o_OutputStatus	:= 0 ;
			--o_OutputMessage	:= 'SUCCESS';
			COMMIT;
   	  EXCEPTION
	   	    WHEN OTHERS THEN
			  		o_OutputStatus	:=	102;
			  		o_OutputMessage	:=	SUBSTR(SQLERRM,1,100);
	   END;
	 ELSE
			o_OutputStatus	:=	103;
			o_OutputMessage 	:= 'CSR Not elligible to own task.';			
		END IF;
		
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  		 o_OutputStatus := 104;
	  o_OutputMessage  := 'No Task to Assign';  			 

  WHEN OTHERS THEN
	  o_OutputStatus := 101 ;
	  o_OutputMessage  := 'Procedure Cc_Assign_Csr_From_Queue failed AT  ' || v_ErrorFlag || ':' || SUBSTR(SQLERRM,1,100);
END;
/
-------------------------------------------------------
Example 6�32 Fetching from a Cursor Variable into a Record
DECLARE
TYPE empcurtyp IS REF CURSOR RETURN employees%ROWTYPE;
   emp_cv empcurtyp;
   emp_rec employees%ROWTYPE;
BEGIN
	OPEN emp_cv FOR SELECT * FROM employees WHERE employee_id < 120;
		 LOOP
		 	 FETCH emp_cv INTO emp_rec; -- fetch from cursor variable
			 EXIT WHEN emp_cv%NOTFOUND; -- exit when last row is fetched
-- process data record
   		   DBMS_OUTPUT.PUT_LINE('Name = ' || emp_rec.first_name || ' ' ||emp_rec.last_name);
		 END LOOP;
	CLOSE emp_cv;
END;
/
-------------------------------------------------------
Example 6�33 Fetching from a Cursor Variable into Collections
DECLARE
	TYPE empcurtyp IS REF CURSOR;
	emp_cv empcurtyp;
	
	TYPE namelist IS TABLE OF employees.last_name%TYPE;
	names namelist;
	
	TYPE sallist IS TABLE OF employees.salary%TYPE;
	sals sallist;
BEGIN
	OPEN emp_cv FOR SELECT last_name, salary FROM employees WHERE job_id = 'SA_REP';
		 FETCH emp_cv BULK COLLECT INTO names, sals;
	CLOSE emp_cv;
-- loop through the names and sals collections
      FOR i IN names.FIRST .. names.LAST
	  	  LOOP
		   	  DBMS_OUTPUT.PUT_LINE('Name = ' || names(i) || ', salary = ' || sals(i));
		 END LOOP;
END;
/
---------------------------------------------------------------------------------------------













