
UAT :

tnoxpass_tfe_2018 : TnoxpaSS_tfe$2018 :
Encrypted Password : 309A7FE77579E16482355E366BC7F54956708AD1182DB205
Key = 8592867031E64597
Password = 69D4F23742F4A064855A4537CAFB0FB6CA73CE1227F02794

snoxpass_tfe_2018 : SnoxpaSS_tfe$2018 : 
Encrypted Password : 7723A93C1A60DD6F82355E366BC7F54956708AD1182DB205
Key = C2D5B92AD3573231
Password = 5F793803FB2482AF1403EA97424901D5CCAA82B0B545CB3C


production :

tnoxpass_tfe_2018 : tNoXpaSSt$fe$2018 : 
Encrypted Password : 5FA9C1A02518FD25D85B2D51B246496F56708AD1182DB205
Key = 57D570894658B640
Password = B06DC52C09EEC4DAC39BAD951EFD82745306CD35C7426FF4

snoxpass_tfe_2018 : sNoXpaSSt$fe$2018 : 
Encrypted Password : C4865EAE8321E806D85B2D51B246496F56708AD1182DB205
Key = A27A6415F4522ADC
Password = 05026BB34C11EB5FBB80B87DD7846E30E9234D367BAFCFC7


--------------------------------------------------------------------------------------------------
-- Jun TransIT DB release VBS details

VBS Schemas			Encrypted Password								  Originale password
-------------------------------------------------------------------------------------------------------
SNOXPASS_TFE_2017	59EA217B91375581EF2AFAA28AD9129940429A937078BA09  -->> SnoxPass_Tfe$2017 
TNOXPASS_TFE_2017	2ECCF4EC7CFF2A8EEF2AFAA28AD9129940429A937078BA09  -->> TnoxPass_Tfe$2017 

SNOXPASS_GWAY_013	59EA217B91375581F89A2876C7F9CD96E30AE00E0F1AF8CA  -->> SnoxPass_Gway$013
TNOXPASS_GWAY_013	2ECCF4EC7CFF2A8EF89A2876C7F9CD96E30AE00E0F1AF8CA  -->> TnoxPass_Gway$013


-- for SNOXPASS_TFE_2017 schema
Key = AD2554378CE5FB13
Password = B573FE912F1DA39F54E5C642213560F1D8FB72D258A1713C

-- for TNOXPASS_TFE_2017 schema
Key = 2C8CA4A883C2CE83
Password = F54A8977A943D37279705731EB6744267803069801BA4138
-------------------------------------------------------------------------------------------------

-------------------------------------------------------
-- 21April2014 VBS Release...
VBS Schemas						Encrypted Password								  Originale password
-------------------------------------------------------------------------------------------------------
SNOXPASS_TFE_2017			59EA217B91375581F58E4BB5A0A58D3F40429A937078BA09 	SnoxPass_TFE$2017
TNOXPASS_TFE_2017			2ECCF4EC7CFF2A8EF58E4BB5A0A58D3F40429A937078BA09 	TnoxPass_TFE$2017

TNOXPASS_SMSNOX_307			2ECCF4EC7CFF2A8EA2DD86B05378B50C81DE4F4BC3449A5E 	TnoxPass_SMSNOX$307
SNOXPASS_SMSNOX_307			59EA217B91375581A2DD86B05378B50C81DE4F4BC3449A5E	SnoxPass_SMSNOX$307
TNOXPASS_GWAY_012			2ECCF4EC7CFF2A8E4FED7E488C01D9E24373C6C5F866901A	TnoxPass_GWAY$012
SNOXPASS_GWAY_012			59EA217B913755814FED7E488C01D9E24373C6C5F866901A	SnoxPass_GWAY$012

--- SNOXPASS_TFE_2017 schema's Encrypted key and Password
Key = DAF257D6CE860B98
Password = 841296F47087C2586D0E733FF22305AF188A38F5D4CFCD41

--- TNOXPASS_TFE_2017 schema's Encrypted key and Password
Key = 7FA473DA2ADC8049
Password = A6CD50F69162CB12A1425F1345071BD43AE55DAA6D1103CC
-------------------------------------------------------



-------------------------------------------------------
-- 20Jan2014 VBS Release...
SNOXPASS_TFE_2016 --- SNoxPass_TFE2016$132
TNOXPASS_TFE_2016 --- TNoxPass_TFE2016$132

SMSNOX:
SNOXPASS_SMSNOX_306 --- SNoxPass_SMSNOX306$132
TNOXPASS_SMSNOX_306 --- TNoxPass_SMSNOX306$132 

GATEWAY:
SNOXPASS_GWAY_011 --- SnoXPass_GWAY011$132
TNOXPASS_GWAY_011 --- TnoXPass_GWAY011$132
-------------------------------------------------------


---- VBS 30Oct2013
SNOXGCA518 -- snoxGCA$518
TNOXGCA518 -- tnoxGCA$518



-- CPass VBS
TNOXPASS_TFE_2014 -- TNoxPass$Tfe2014 	
SNOXPASS_TFE_2014 -- SNoxPass$Tfe2014  	
TNOXPASS_SMSNOX_303 -- TNoxPass$SmsNox303 	
SNOXPASS_SMSNOX_303 -- SNoxPass$SmsNox303 	
TNOXPASS_GWAY_008 -- TNoxPass$Gway008 	
SNOXPASS_GWAY_008 -- SNoxPass$Gway008 	

-- 19OCT2013 CPass VBS 
SNOXPASS_SMSNOX_304 -- Snox$Pass_smsnox304
TNOXPASS_SMSNOX_304 -- Tnox$Pass_smsnox304
SNOXPASS_GWAY_009 -- Snox$Pass_gway009
TNOXPASS_GWAY_009 -- Tnox$Pass_gway009


-- 91X Gateway VBS 28Mar2013
TNOXGCA517 -- TNox$GCA517 -- 0E7553B1152E54B798B1643DCCDECD07
SNOXGCA517 -- SNox$GCA517 -- 9C5694F3821A8F3F98B1643DCCDECD07


-- Nov2012
TNox$GCA513 - 0E7553B1152E54B78496430C8DED5F59
SNox$GCA513 - 9C5694F3821A8F3F8496430C8DED5F59

-- 07 Feb 2012
tnoxgca_91x_20109/tnoXgcA91x_20109--92C39A4CDAFED4C83B828B3B962DFC669850F6D2E40F11CC
snoxgca_91x_20109/snoXgcA91x_20109--126907E9F37D53693B828B3B962DFC669850F6D2E40F11CC

91x VBS
snoxgca_91x_20106/gcasnox91X$20106
tnoxgca_91x_20106/gcatnox91X$20106

counter pass schema names
tnoxpass_smsnox_20179 -- Tnoxpas$SMSnox20179 -- D8AA498522C772E10C2B03D7FEBAE758BDFF4B09F6F93756
snoxpass_smsnox_20179 -- Snoxpas$SMSnox20179 -- FA10A1E3B3C28B250C2B03D7FEBAE758BDFF4B09F6F93756

tnoxpass_tfe_20116    -- Tnoxpas$TFE20116    -- D8AA498522C772E16A866A4A3C20B0589850F6D2E40F11CC
snoxpass_tfe_20116    -- Snoxpas$TFE20116    -- FA10A1E3B3C28B256A866A4A3C20B0589850F6D2E40F11CC

tnoxpass_gway_00516   -- Tnoxpas$GWAY00516   -- D8AA498522C772E188278902CB4EA22DA1505803C62B8EEB
snoxpass_gway_00516   -- Snoxpas$GWAY00516   -- FA10A1E3B3C28B2588278902CB4EA22DA1505803C62B8EEB


1. TNOXPASS_TFE_20115 -- tnoXpaSs_tFe$_20115
2. SNOXPASS_TFE_20115 -- snoXpaSs_tFe$_20115

tnoxpass_tfe_201116 / tNoxpass$Tfe201116
snoxpass_tfe_201116 / sNoxpass$Tfe201116
tnoxpass_gway_00520 / tNoxpass$Gway00520
snoxpass_gway_00520 / sNoxpass$Gway00520
tnoxpass_smsnox_20189 / tNoxpass$Smsnox20189
snoxpass_smsnox_20189 / sNoxpass$Smsnox20189



tnoxgca_91x_20107 / tNoxgca$91x20107
snoxgca_91x_20107 / sNoxgca$91x20107 
tnoxgca512 / tNoxgca$512
snoxgca512  / sNoxgca$512


ch@nge.it-- 10.100.125.216 rchaudhari

MonerisSFA -- for opening the zip file of Moneris protfolio 

-- http://forums.oracle.com/forums/thread.jspa?threadID=1108826&tstart=0
ispl_2010/mbhavsar@tsys.com-- support.oracle.com

moneris portfoli import password
-- MonerisSFA

Pass2014you

201oopsYEpassword
Tw1n$2009
 

201Pass!$

i@fonoX201 -- 101.35/10.238.35.25

201DBApass$!

transhms/hms_train_dev@10.238.35.25

keynox/keynox_dev@lv_supportnox
keynox_fx/fXlvkeyn0x$0@lv_supportnox

ExportUSer/expsc21 -- 10.65.245.21 counterpass DB

-- schema/password 192.168.231.83
-- main schema
snox4transnox/snoxcpk
transnox_iox/iox123transnox
transtsyspaymentgw/paymentgw

-- app schema
snox4transnox_app/snoxcpk_app
transnox_iox_app/iox123transnoxapp
transtsyspaymentgwapp/paymentgwapp

A$dministrator$!Pass201 --10.52

toor/  @10.240.1.10 -- password is 2 space
	
SNOXGCA_91X_20103N4/snoxGca91X20103$n4
SNOXGCA511/snoxGca5naopxp11

TNOXGCA_91X_20103N4/tnoxGca91X20103$n4
TNOXGCA511/tnoxGca5naopxp11
	
	
	
ispl_admin_201

QA_TEAM/Q@Te$m --
transhms/H@m$C0ms!!  -- stag
transhmsapp/H@m$C0ms!!app -- stag
transmoneris/M@n$rIs1086app  -- stag86
transmoneris/M@n$rIs1086  -- stag86


TNOXPASS_TFE_20113 / tnOx_TfE_2#113
SNOXPASS_TFE_20113 / snOx_TfE_2#113

TNOXPASS_GWAY_00513 / nOx_GwAy_0#513
SNOXPASS_GWAY_00513 / nOx_GwAy_0#513

system/sys$%Or@cle160 --- system for 192.168.101.160
sys/system$%Or@cle160 --- sys  for 192.168.101.160

sys/sys$%or@cle$

su/i0Zc1$QXTpfjf@10.75.240.21

system/sys$%or@cle$

su/w6W!jCmp@10.65.1.40

oracle@sigue123@172.19.100.30 -- sid is isdp
system/syssiguestag@172.19.100.30


rahulc/r@hul123@

server IP 10.65.240.50
UserName : root
password : IfxSc@r5c3



system/syshathi@192.168.101.23
oracle/mpty%kow@192.168.101.23

transgca/transcybergca123@coms-sc

*** There are only  2 tables
(db_connections, replication_time_lag_data)
in SNOX,
used  for monitoring DB connections and replication lagging 

oracle/ora@199$ -- 10.75.240.21
oracle/oracle123@traning.ifxlv.com --10.75.240.21

sqlplus /nolog

conn snox/x3o5n0s0@snox-sc

alter session set nls_date_format='dd-mm-yy hh24:mi:ss';

select R.*,sysdate from REPLICATOR_TIME_LAG_DATA R
where timestamp between sysdate-2 and sysdate
order by timestamp desc;

inventory/inv@@tory@192.168.101.160

oracle@10.75.15.50 --- oracle Las Vegas Archive server

root/mpty%kox@10.65.245.212

----192.168.101.160
log / sc89120
root / Show@321**



 qcptestapp/qcptestappnox418
 qracm_test/qracmnox418
------------------------------------------------------------------

exportuser/exp04t$@transending export import users

hummer~H3
oracle/mpty%kow
system/sys1532232@transnox-db

*******************************************************************
*******************************************************************

Replicator 10.25.245.36 -- connect throug 101.34 from REMOTE SERVER an not from PCAnyWhere software

dba/2@@3@@2 --- Replicator machine

-- LV Replicator Machines
administrator/IfxLv@r5c3 -- 36, 37, 38

administrator/IfxSc@r5c3 -- 36, 37, 38


SC (ifxSC)
10.25.245.36 -- Rep1 SRC_C_REPL, SRC_SNOX
10.25.245.37 -- Rep2 SRC_TRANSNOX, TARGET_C_REPL, TARGET_C_REPL
10.25.245.38 -- Backup for Replicators

LV (ifxLV)
10.75.245.36 -- Rep1 SRC_C_REPL, SRC_SNOX
10.75.245.37 -- Rep2 SRC_TRANSNOX, TARGET_C_REPL, TARGET_C_REPL
10.75.245.38 -- Backup for Replicators

SELECT * FROM DBA_OBJECTS WHERE OWNER='SRC_TRANSNOX'

SELECT DISTINCT USER_NAME FROM SRC_TRANSNOX.TARGET_REP_DATA


Schema Name / DB IP                    	      Replicating From		   Recplicating To 

SNOX4TRANSNOX_WUCC 	   (10.25.245.190) -->    10.25.245.36 (Rep1) -->    

TRANSNOX_WU / SNOX 	   (10.25.245.34)  -->    10.25.245.37 (Rep2) --> 

TRANSNOX_WM		   	   (10.25.245.210) -->    10.25.245.36 (Rep1) -->  10.25.245.212 -- SRC_C_REPL

ACM, CHECKCASH, QCP	   (10.25.245.62)  -->	  10.25.245.36 (Rep1) -->  10.25.245.65  			
QCPMGR, QCREDIT, WUMT,
EDITH, USAP_ADAPTER,
SNOX.db_connections 


SELECT 'INSERT INTO '||USER_NAME||'.'||TABLE_NAME||'('||REPLACE(COLS,'^~',',')||') '||' VALUES ('''||REPLACE(VALS,'^~',''',''')||''');' ABC
from src_backup.TARGET_REP_DATA WHERE TABLE_NAME='USER_DATA'

--- execute the query to check the for terminal.
select USER#, USERNAME, MACHINE, TERMINAL, SCHEMANAME, STATUS, SERVER, OSUSER, PROCESS 
from v$session where terminal like '%LV%' or schemaname like 'SRC%' 
ORDER BY USERNAME ASC

select COUNT(*) from SRC_SC.REPLICATION_DATA


select COUNT(*) from SRC_SC.TARGET_REP_DATA


--- then open the machine as per the terminal
if rep1 then open 10.25.245.36
if rep2 then open 10.25.245.37

-- under the path 
c:\infonox

there are some dbreplicator folders, in each folders there is BIN folder like
(c:\infonox\dbreplicator\bin) and inside bin folder there is ReplicateConfig.RCF
file, Open this file in notpade and check for the details like SOURCE DB and TARGET DB 
also ip and schema name which are replicated.


it can be that if 36 and 37 is not accessable then 38 is the backup of replication programs
so you can start the replcation from rep3 i.e 38

*******************************************************************
*******************************************************************

-- process to increment the sequence 
-- do it schema by schema

acm 
qcp 
checkcash 
qcredit 
wumt 
qfund 
qcpmgr 
qcmgr 
scorenox 
qfcs 


take the script of sequence with drop script schema wish from prod db 62

copy it on textpad schema wish 

increment sequence the number(start with <number>(increment the right no. by 1 then previous no.))
for e.g sequence no is 8989896523, then need to change it as 9989896523.


execut script the on 7563 / 7566 / 10.25.245.62

execute the script of grants and synonyms for sequence

complie all the procedure / function / package 

compare the procedure / function / package from 7562 to 7563 / 7566 / 10.25.245.62

the count of invalid and valid procedure / function / package should me matched from 7562 to 7563 / 7566 / 10.25.245.62



*******************************************************************
*******************************************************************

src_c_repl/srcwucc			--- 10.25.245.190

src_snox/src15210			--- 10.25.245.210
src_c_repl/src210	 		--- 10.25.245.210

target_c_repl/tar210		--- 10.25.245.210


src_c_repl/srcsc1562 		--- 10.25.245.62
src_snox/src				--- 10.25.245.62

src_snox/src1562			--- 10.75.15.62
src_backup/src1562			--- 10.75.15.62
src_c_repl/src1562			--- 10.75.15.62
src_sc/src1562				--- 10.75.245.62

target_c_repl/tartransnox 	--- 10.25.245.32

target_c_repl/tarsc232		--- 10.25.245.65


target_c_repl/tar			--- 10.25.245.45

target_c_repl/tar212 		--- 10.25.245.212


src_c_repl/src7566			--- 10.75.15.62
target_c_repl/tar1563		--- 10.75.15.66



idnox/idnox980

src_c_repl/src   --- replication schema

src_monitor/src1565@qcpw-sc-repl

system/sysgcashow@192.168.101.190 -- gcashow_New

system/sys24562@10.75.245.62
src_monitor/src24562@10.75.245.62

punedba/pune%15190@snox-wucc 	 	  --- 10.25.15.190
punedba/Punedba1532@transnox-sc 	  --- 10.25.15.33
punedba/punedba1545@snox-sc	 	  --- 10.25.15.45
punedba/pune%1561@trans-sc		 	  --- 10.25.15.61
punedba/punedba1562@qcpw-sc     	  --- 10.25.15.62
punedba/punedba1565@qcpw-sc-repl     --- 10.25.15.65
punedba/punedba1534@terabytes	 	  --- 10.25.15.34
punedba/punedba1530@vero-sc     	  --- 10.25.15.30
punedba/punedba15210@gcasnox-sc	  --- 10.25.245.210
punedba/punedba15212@Backup_SnoxDB	  --- 10.25.245.212

punedba/punedba1014@dev			  --- 10.240.1.14
punedba/punedba1014@devdb			  --- 192.168.231.82
punedba/punedba1014@qa				  --- 192.168.231.81
punedba/punedba1014@stag	  		  --- 192.168.101.160

bdas/bdash@coms-sc 				  --- 10.245.15.61


punedba/punedba7562@LV_qcpw_sc    	  --- 10.75.15.62


*******************************************************************
*******************************************************************



oracle/dM$qsl22@10.238.1.231

-- TB Server Production Backup server

oracle/oracle@1534
su/root@1534

-----


10.75.245.62 oracle 9.2.0.7.0
oracle/heyram123
system/sys1075

****************************************************************************
---- QCPW-SC (Primary Production) 45/30 days data
---- Password is same for SNOX-SC Replication db
---- IP Address 10.25.245.62 for Primary DB QCPW-SC
---- IP Address 10.25.15.65 for Replicated QCPW-SC-REPL DB
---- PORT 1521 same for both
---- SID aqprod same for both
****************************************************************************


-- qr reporting schemas
qracm/qracmnox418
qrqcp/qrqcpnox418

snoxdevices/x3o5n0s0

veribiometrics/verinox418

qcpmgr/qcpmgrnox418

snox/x3o5n0s0

usap_adapter/usapnox418

-- checkcasking 
checkcash/checkcashnox418
checkcashapp/checkcashnaopxp418


--- qcp
qcp/qncopx418
qcpapp/qcpnaopxp418@QCPW-SC   


-- quikadvance
qkadvance/qknox418
qkadvanceapp/qkadvancenaopxp418


-- edith
edith/edithnaopxp418

src_monitor/src1562

--wumt
wumt/wumtnox418
wumtapp/wumtnaopxp418

qfund/qfnox418
qcredit/qcnox418
acm/ancomx418
qfcs/qfcsnox418


acm3900/acm3900naopxp418
acm5000/acm3900naopxp418
acm6000/acm6000naopxp418

mergecustcode/merge1562

---- event table storing schema
histob_snox/histnox418

realtimerpt/realtimerptnox418

--- export / import schema.
punedba/punedba1532 

****************************************************************************
---- SNOX-SC (Secondry Production) (SNOX-LV Replication DB for SNOX-SC)
---- SUPPORTNOX DB's
---- Password is same for SNOX-LV Replication db
---- IP Address 10.25.245.210 Secondry SupportNox GCASNOX-SC DB     ---10.25.245.45 Secondry SupportNox SNOX-SC DB
---- (IP Address 10.50.15.45 for Replicated SNOX-LV DB)
---- PORT 1521 same for both
---- SID aqprod same for both
****************************************************************************

src_c_repl/src --- replication schema

-- qr reporting schemas
qracm/qracmnox418
qrqcp/qrqcpnox418


qcpmgr/qcpmgrnox418

qcp/qcpnaopxp418

--- snox gca
snox/x3o5n0s0   

snoxdevices/x3o5n0s0            

checkcash/checkcashnox418

ssk/x1k5s2s1            

src_monitor/src1562

-- checkcashing schema
ckch/h1c5k2c1           

histobj/histobjnox418@

edith/edithnaopxp418

--- transnox_wu production and snox4transnox 
transnox_wu/transnox1545noxwu
snox4transnox_wu/snox4transnox1545noxwu

snox4transnox_wucc/x3o5n0s0

transnox_ifastpay/transnox1545noxifastpay

transnox_purpose/transnox1545noxpurpose

transnox_cnw/transnox1545noxcnw
 
transnox_ssa/transnox1545noxssa
snox4transnox_ssa/snox4transnox1545noxssa

snox4transnox_ean/snox4transnox1545noxean

snox4transnox_oneview/viewone$4

transnox_pel/transnox1545noxpel

snox4transnox_cnw/snox4transnox1545noxcnw

snox4transnox_cne/cnesnox4transnoxnaopxp418
transnox_cne/cnetransnoxnaopxp418 


snox4transnox/snox4transnox1545nox


snox4transnox_gca/gcasnox4transnoxnaopxp418

transnox_gca/gcatransnoxnaopxp418

transnox_glory/transnoxnox1545glory

transnox_wm/transnox1545noxwm



--sigue production schema's 10.66.15.212sueprod.ifxsc.com
transnox_sigue/pass$123qsl
snox4transnox/qsl$123pass 
****************************************************************************
---- OLD-SC (VERO / TRANSNOX PRODUCTION DB)
---- IP Address 10.25.245.30
---- PORT 1521
---- SID aqprod
****************************************************************************

ofac_adapter/ofac_adapter980

snox_vero/snox980     ---------- snox_main_vero / snox4vero


-- system user
system/sysnox814 


Snox_cw/snoxcwprod    ---- snox cashwork


--- GECFUsers   
cwprod/cwnaopxp418prod  ---- gecf   
Snox_cw/snoxcwprod      --- snox_main_gecf
Snoxcwprod/prodsnoxcw   ---- snox_gecf


--- GECFUser (For Staging)
snox_ge/snox_ge         --- (snox_main_gecf)
GECF/GECFSTAG@GEVERO-SC
SnoxGECF/SNOXGECF@GEVERO-SC


--- VERO Users
vero_cce/vero_cce980@snoxdb  -------- vero_afatm    
Snoxvero_cce/snoxvero_cce980 ----------- snoxvero_afatm

--- transnox
snox4transnox/snox4transnox_dev
transnox_purpose/transnox980
transnox_ifastpay/transnox_ifastpay_dev


--SNOXNEO-SC -- 10.253.245.32
snox_neo/snox1532@SNOXNEO-SC ---- stinfonox prod snox schema
water/water1532@SNOXNEO-SC

****************************************************************************
--- Replication schemas and tables
srcrep_vero/srcrep

--- Tables Name : 
REPLICATION_DATA
REPLICATION_DATA_EX
TARGET_REP_DATA
TARGET_REP_DATA_EX
****************************************************************************



Source User Name (For Replication):
		srcrep_cw/src
Tables Name : 
REPLICATION_DATA
REPLICATION_DATA_EX
TARGET_REP_DATA
TARGET_REP_DATA_EX




--- Transending Users (For Prod)
transmsn/msncyber123
transcapitalone/hmscyber123

oracle/mpty%kox@10.25.15.61
oracle/mpty%kow@10.25.15.63


Target Schema used for replicating for all products:
Target User : target_c_repl/tar
No Table Found




Replication Software location Server : (192.168.101.252)

Software            : C:\Infonox\DBReplicator\Bin\DBReplicator.exe  
Configuration Files : C:\Infonox\DBReplicator\Bin\ ReplicateConfig_vero.rcf (VERO)
				: C:\Infonox\DBReplicator\Bin\ ReplicateConfig_ge.rcf (GECF)
Log Files           : C:\Infonox\DBReplicator\Logs\06292005\003\Repl0001.txt



Production GCA_Server Detail (10.50.15.25,1521)(Replication):

Service Running :  aqprod

Production GCA_Server Detail (10.50.15.15)(Primary):
snoxdevices/x3o5n0s0@QCPW-LV(from 101.34)
Service Running :  aqprod



chetan/Rep_2005@qcpwb-lv
--chetan/Jun2404@SNOX-LV

sqlplus chetan/Jun2404@qcpwb-lv
SQLPLUS snoxdevices/x3o5n0s0@qcpwb-lv


--- PCANYWHERE Connection of 192.168.231.81 from 192.168.101.34
Admin/Lt401k!U
Administrator/gca%2004

-- Putty connection
9.55  - linux
user oracle 
password ora@199$

- tns.ora in 101.34
tnsping = SNOX-LV
IP = 10.50.15.45
SID = AQPROD
name = E3500 


---- TRAIN-LV DB
system/sysgcatest@TRAIN-LV

snox/x3o5n0s0@TRAIN-LV


------------------

edith/edithstag@IGTSERVER
snox_edith/snoxaqprd@IGTSERVER
snoxdevices/snoxaqprd@IGTSERVER
qcpmgr/qcpmgrstag@IGTSERVER



----------- quikplay
dbsnmp/dbsnmp@QUIKPLAY-LV
--qplay/snoxifxqp_pass@quiplay-lv
qplay/qplay_pass@quiplay-lv




---------------------------------------------------------------------
qr reports --- SQL SERVER productions

10.50.15.45 Production Database.(sid aqprod)
		qracm/qracmnox418@SNOX-LV 


192.168.30.11
	SQL SERVER Production IP 
	username /password := qr_user/QRINFO
	SID := QRPROD


String userName = "TRANSGCA";
	String password = "transgca%2005";
	String url = "jdbc:microsoft:sqlserver://192.168.60.11:1433";
	String dbName = "QRPROD";


--- OLD IP 192.168.60.11 
NEW IP 10.25.245.220
new sqp server productions ----unknown
qr_user/qrinfo
qrdemo/omedrq


192.168.30.12
	SQL Server Prod2 IP
	username /password = term_master/term_master
	SID = term_master



---------------------------------------------------------------------



-- database replication information
1] QCPW-SC   -- primary db
2] QCPW-LV   -- primary replicate db

3] OLD-SC    -- primary replicated db from qcpw-sc

4] SNOX-SC   -- primary secondry  db
5] SNOX-LV   -- secondry replicate db
6] TRANSDB   -- primary TranSending db(10.25.245.61)
7] TRANSDB   -- secondry replicate db (10.25.245.62)
8] GEVERO-SC -- primary vero db
9] EMN8DB    -- primary emn8db db

10] IGTSERVER-LV
11] GCASHOW 





cvs.infonox.com

maven/ispl_201


transnox
192.168.101.35
sandeeps/%ldap*

Make complete release

developement

tess

DB Release



10.50.2.99
su/IfxSc@r5c3
oracle/oracle


10.25.101.40 
su/IfxLv@r5c3
oracle/oracle123


192.168.101.160
oracle/oracle123


------------------------
--10.240.1.14
root/nox1.14
oracle/ora_201

-- for sftp the files and folder 
sftp sftp_user@192.168.101.34

sftp_user/55SSH_06

------------------------


--10.25.245.30
old-sc / snox-sc
oracle / mpty%kow 





---10.240.1.46
root/ispl_20!
oracle/ora_@1




