        ++----------------------------------------------------------------------------------------------++
        --                      Report on Servers and IP ADDresses.                                     --
        --                                                                                              --
        --  Created By :- Rahul Chaudhari                                                               --
        --                                                                                              --
        --  This information is for DBA Team. you can redistribute it and/or                            --
        --  modify it if you are DBA Team Member.                                                       --
        ++----------------------------------------------------------------------------------------------++



--------------------------------------------------------------------------
                        
---- SQL SERVER DATABASE 
192.168.253.4 :   QRM/QRM  SQL SERVER Local Databases 

192.168.101.178 QR_USER/QR_USER  SQL SERVER QA and Stag Database
(qa (db is  qrqa) and stag (db is qrdev)are on same server)
IP:   192.168.101.178
login:   sa/qr_sql

--------------------------------------------------------------------------


---------------------------

  MySQL Database
            root/2n2Cluster -------- machine 
            mysql/mysql -- machine username/password
  192.168.231.73    Linux version   rootadmin / R@dm1$09 ---- machine
  192.168.231.73    rahulc/rootispl_126 ---- mysql root user
                    root/cluster2n2
                    omni/omni ------------ omni
                    snox/snox ----------- snox
  
  192.168.231.72  root/rootispl_126 --- mysql root user                    
                    username  root / MySQL5db   
                 


  192.168.253.10    Linux version   root / ispl_201 --- machine / root user of mysql 
  192.168.253.10        rahulc / ispl_201  ----- machine    

                        omni/omni ----- omni db
                        snox/snox_dev ----- snoxdb db
                        retailpc/retailpc_dev  ----- retailpc db
                        merchantpc/merchantpc ------- merchantpc
                        stv/stv ----------- stv db


  10.240.1.19    Linux version   mysql/mysql -------- machine / root user of mysql
            retailpc/retailpc_dev
            root/ispl_201
            
             Database       USER                              PASSWORD
             
            STINFONOX       STINFONOX (STIFX_USER)            STIFX_USER_DEV
            stv             stv                               stv20025
            dotproject      dp_user                           dp_pass           
            
            
  192.168.101.160  Windows Version  root/root_stag 
                retailpc/retailpc_stag
                
192.168.101.125   Production MySQL DB for infonox site      
rootadmin / R@dm1%09 su / Password123 --- Machine account pass
mysql 
   root/root101.215

   for STINFONOX DB
   Schema name : STINFONOX
   User : STIFX_USER 
   Password : STIFX_USER_DEV

   for stv DB
   schema name : stv
   User : stv
   password : stv20025
   
   
   
   mysql --- 10.240.1.51   
   root/ispl_201@10.240.1.51


10.238.1.210 new production MySQL db for the sites stv1.com and stifx.com
infonox / stv@20025 ----- Machine user Account
su / IfxSc@r5c3 ---- su account

rahulc / t0m&hari1  --- Machine Password

  root/root1.210
    
     mysql -u root -pispl210 -h 10.238.1.210 -- with grant option

mysql/mysql210 -- machine password 210
mysql/mysql@202  -- machine password for 10.65.240.202
mysql -u root -proot@202 -h 10.65.240.202 --< 10.65.240.202

ocvinfonox/ocv202ifxnox

backup path /home/sites/dbbackup
backup script path /home/rahulc/mysqlbck_script.sh
    
    mysql -u root -proot1.210 -h 10.238.1.210

Server IP : 10.238.1.210
User: phpbb
Password : phpbb_dev
Database Name : phpbb

--production server
wu_forum/wunox_forum
ifxtransit_forum/ifxnoxtransit_forum

--prod
commercebank_ptl/commercebanknox418ptl
commercebank_frm/commercebanknox418frm


--local db
wu_forum/wu_forum_dev
ifxtransit_forum/ifxtransit_forum_dev

--prod
telecheckpf/telecheckpfnox418

-- prod
telecheck_portal/telecheck_portalnox418

--prod 
ottoport/ottoportnox210

-- local dev
ottoport/ottoport_dev

transit database
production pass -- transitnox
local pass -- transit_dev

VirtualReceptionist
User: vrtl
Password : vrtl2005
*********************

dart
User: dart
Password : dart_user_dev

*****************************
wumobile
User: wumobile
Password : wumobile_dev


   for STINFONOX DB
   Schema name : STINFONOX
   User : STIFX_USER 
   Password : STIFX_USER_DEV

   for stv DB
   schema name : stv
   User : stv
   password : stv20025
   
   
   mysql/mysql123@192.168.231.72
    mysql -u root -pMySQL5db -h 192.168.231.72
-------------------------------   
new production server
192.168.231.65

machine mysql/mysql

mysql user rahulc/ispl_201

root/root231.65@% and localhost

root/root66@ 192.168.231.66

backup server for mysql and dotproject
192.168.231.66
/home/mysql


#!bin/bash
mydate=`date +%d%m%Y`

mypath=/home/mysql/mysqldb_backup

fpath=$mypath/backup_$mydate.sql

mysqldump -u punedba -ppune%23165 -h 192.168.231.65 dotproject  > $fpath
   
-------------------------------------------

Host - meetme.infonox.com
Username - cdr
Password - cdr_2006_1
db - asteriskcdrdb

----------------------------------------------

---- Machine username/password

101.160 admin/admin pcanywhere login inside login  Administrator/GCA%2004 
        # VNC Viwer  password :- a%%*dba

231.80 Administrator/admin@db
        # VNC Viwer password :- l)gin





----------------------------------------
Backup dbs


      DBName      Machine           source - account/password       distination account/password     source                                locations                                
      
   1] GCATEST     10.50.2.99        oracle/oracle                   serverlogs/serverlogs            /home/oracle/Backup_Training_DB        \\10.60.253.51/10.50.2.99_db_bkup       
   2] 





--  backup of database

  10.50.2.99
  
  /home/oracle  script folder 
    oracledb_bck.sh script to be run
 
 -- ZIP files are saved on 
 ftphost='10.60.253.51'
 ftpuser='serverlogs'
 ftppasswd='serverlogs'
 bkplocation='/home/oracle/Backup_Training_DB/'
 bkpdestination='10.50.2.99_db_bkup'
 
  

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
-- Production schema name and passwords



-- CVS server 192.168.231.65
cvs/cvs@231.65
su/Lt401k!U






GCA linux machine 

192.168.101.14

root/Password123
oracle/oracle123

rahulc/R@HulC101 


 ssh -l oracle 10.25.245.34

















cool_dba/cool_dba@blogger.com

