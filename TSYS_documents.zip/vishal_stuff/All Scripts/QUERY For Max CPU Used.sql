set line 240
set verify off
column sid format 999
column pid format 999 
column S_# format 999
column username format A9 heading "ORA User"
column program  format a29
column SQL      format a60
COLUMN OSname format a9 Heading "OS User"
 SELECT 
 P.pid pid,
 S.sid sid,
 P.spid spid,
 S.username username ,
 S.osuser osname,
 P.serial# S_#,
 P.terminal,
 P.program  program,
 P.background,
 S.status, 
 RTRIM(SUBSTR(a.sql_text, 1, 80))  SQL
 FROM v$process P, v$session S,
      v$sqlarea A
 WHERE P.addr = s.paddr
 AND   S.sql_address = a.address (+)
 AND P.spid LIKE '%&1%'
/
set termout off
spool /tmp/PID.lst
 SELECT
 '++'||S.username username ,
 RTRIM(REPLACE(a.sql_text,chr(10),''))||';'
 FROM v$process P, v$session S,
      v$sqlarea A
 WHERE P.addr = s.paddr
 AND   S.sql_address = a.address (+)
 AND P.spid LIKE '%&&1%'
/
spool off

