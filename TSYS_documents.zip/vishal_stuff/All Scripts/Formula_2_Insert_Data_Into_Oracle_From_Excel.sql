=CONCATENATE("insert into TEMP_TABLE values('",A2,"','",B2,"','",C2,"','",D2,"','",E2,"','",F2,"','",G2,"','",H2,"','",I2,"','",J2,"','",K2,"','",L2,"','",M2,"','",N2,"');")


use this formula at the last column 

to apply for all

goto end row on same column where the formula is.. at the end row type 1 and 
press goto again top then copy the formula by ctl+c and take the cursor to next row for the same column 
where formula is and press (CTL + SHIFT + DOWN ARROW) and press enter to apply the formula for all the rows .