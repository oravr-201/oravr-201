
            Can One Monitor How Fast A Table Is Imported?

If you need to monitor how fast rows are imported from a running import job, 
try one of the following methods:

Method 1: 

    SELECT 
         SUBSTR(sql_text,INSTR(sql_text,'INTO "'),30) table_name,
         rows_processed,
         ROUND((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60,1) minutes,
         TRUNC(rows_processed/((sysdate-to_date(first_load_time,'yyyy-mm-dd hh24:mi:ss'))*24*60)) rows_per_min
    FROM   sys.v_$sqlarea
    WHERE  sql_text LIKE 'INSERT %INTO "%'
           AND  command_type = 2
           AND  open_versions > 0;

For this to work one needs to be on Oracle 7.3 or higher (7.2 might also be OK). 
If the import has more than one table, this statement will only show information 
about the current table being imported. 
