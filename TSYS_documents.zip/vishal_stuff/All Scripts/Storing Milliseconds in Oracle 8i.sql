
CREATE OR REPLACE JAVA SOURCE
NAMED "MyTimestamp"
AS
import java.lang.string;
import java.sql.timestamp;

PUBLIC CLASS MyTimestamp
{  PUBLIC static String getTimestamp()
   {
	RETURN (NEW TIMESTAMP(SYSTEM.currentTimeMillis())).toString();
   }
};
/

CREATE OR REPLACE FUNCTION my_timestamp RETURN VARCHAR2
AS LANGUAGE JAVA
NAME 'MyTimestamp.getTimestamp() return java.lang.String';
/

To use:
SELECT my_timestamp FROM DUAL ;

MY_TIMESTAMP
-----------------------
2002-04-18 16:54:38.688

