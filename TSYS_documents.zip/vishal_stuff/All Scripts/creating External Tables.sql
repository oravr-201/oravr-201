Creating an External Table and Loading Data

The following example creates an external table, then uploads the data to a 
database table. We have tested the examples in the Oracle9i Database 
Administrators Guide Release 1 (9.0.1) using Oracle 9.0.1 on Windows 2000.

The file empxt1.dat in C:\Users\Zahn\Work contains the following sample data:

7369,Schmied,Schlosser,7902,17.12.1980,800,0,20
7499,Zaugg,Verk�ufer,7698,20.02.1981,1600,300,30
7521,M�ller,Verk�ufer,7698,22.02.1981,1250,500,30
7566,Holzer,Informatiker,7839,02.04.1981,2975,0,20
7654,Zahn,Verk�ufer,7698,28.09.1981,1250,1400,30
7698,Sutter,Informatiker,7839,01.05.1981,2850,0,30
7782,Graf,Informatiker,7839,09.06.1981,2450,0,10

The file empxt2.dat in C:\Users\Zahn\Work contains the following sample data:

7788,Gasser,Analytiker,7566,19.04.1987,3000,0,20
7839,Kiener,Lehrer,,17.11.1981,5000,0,10
7844,Stoller,Verk�ufer,7698,08.09.1981,1500,0,30
7876,Amstutz,Automechaniker,7788,23.05.1987,1100,0,20
7900,Weigelt,Automechaniker,7698,03.12.1981,950 ,0,30
7902,Wyss,Analytiker,7566,03.12.1981,3000,0,20
7934,Messerli,Automechaniker,7782,23.01.1982,1300,0,10

The following SQL statements create an external table and load its data into 
database table EMP of the user scott.

sqlplus /nolog

SQL*Plus: Release 9.0.1.0.1 - Production on
Sat Jan 26 10:44:48 2002
(c) Copyright 2001 Oracle Corporation. All rights reserved.

CONNECT  SYS/MANAGER  AS SYSDBA;
SET ECHO ON;

CREATE OR REPLACE DIRECTORY dat_dir AS 'C:\Oracle\Data';
CREATE OR REPLACE DIRECTORY log_dir AS 'C:\Oracle\Log';
CREATE OR REPLACE DIRECTORY bad_dir AS 'C:\Oracle\Bad';

Directory created.

GRANT READ ON DIRECTORY dat_dir TO scott;
GRANT WRITE ON DIRECTORY log_dir TO scott;
GRANT WRITE ON DIRECTORY bad_dir TO scott;

Grant succeeded.

CONNECT scott/tiger;
DROP TABLE empxt;

CREATE TABLE empxt (empno       NUMBER(4),
                    ename       VARCHAR2(20),
                    job         VARCHAR2(20),
                    mgr         NUMBER(4),
                    hiredate    DATE,
                    sal         NUMBER(7,2),
                    comm        NUMBER(7,2),
                    deptno      NUMBER(2)
                   )
 ORGANIZATION EXTERNAL
 (
   TYPE ORACLE_LOADER
   DEFAULT DIRECTORY dat_dir
   ACCESS PARAMETERS
   (
     records delimited by newline
     badfile bad_dir:'empxt%a_%p.bad'
     logfile log_dir:'empxt%a_%p.log'
     fields terminated by ','
     missing field values are null
     ( empno,
       ename,
       job,
       mgr,
       hiredate char date_format date mask "dd.mm.yyyy",
       sal,
       comm,
       deptno
     )
   )
   LOCATION ('empxt1.dat', 'empxt2.dat')
 )
 PARALLEL
 REJECT LIMIT UNLIMITED;

Table created.

ALTER SESSION ENABLE PARALLEL DML;

Session altered.

The first few statements in this example create the directory objects for the 
operating system directories that contain the data sources, and for the bad 
record and log files specified in the access parameters. You must also grant 
READ or WRITE directory object privileges, as appropriate.

The TYPE specification is given only to illustrate its use. If not specified, 
ORACLE_LOADER is the default access driver. The access parameters, specified 
in the ACCESS PARAMETERS clause, are opaque to Oracle. These access parameters
are defined by the access driver, and are provided to the access driver by 
Oracle when the external table is accessed.

The PARALLEL clause enables parallel query on the data sources. The granule 
of parallelism is by default a data source, but parallel access within a data 
source is implemented whenever possible. For example, if PARALLEL=3 were 
specified, then more than one parallel execution server could be working on 
a data source.

The REJECT LIMIT clause specifies that there is no limit on the number of 
errors that can occur during a query of the external data. For parallel 
access, this limit applies to each parallel query slave independently. 
For example, if REJECT LIMIT 10 is specified, each parallel query process 
is allowed 10 rejections. Hence, the only precisely enforced values for 
REJECT LIMIT on parallel query are 0 and UNLIMITED.

