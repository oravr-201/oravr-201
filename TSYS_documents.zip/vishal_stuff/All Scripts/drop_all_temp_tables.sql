00 05 * * * sh /home/oracle/cronjobs/drop_temp_tables_script.sh



-- sh drop_temp_tables_script.sh

# .bash_profile

PATH=$PATH:$HOME/bin

# Oracle Settings
ORACLE_HOSTNAME=$HOST; export ORACLE_HOSTNAME
ORACLE_UNQNAME=devracdb; export ORACLE_UNQNAME
ORACLE_BASE=/opt/app/oracle; export ORACLE_BASE
DB_HOME=$ORACLE_BASE/product/11.2.0/db_1; export DB_HOME
GI_HOME=/opt/app/11.2.0/grid; export GI_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
ORACLE_SID=devracdb1; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH:$GI_HOME/bin; export PATH
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

export PATH

sqlplus -s / as sysdba << eof
set pagesize 0;
set head off
set echo off
set feedback off
set serveroutput on
spool /opt/app/cronjobs/drop_tbls_srpt.log
PROMPT
PROMPT "*****************************************************"
PROMPT
SELECT owner, COUNT(*)
FROM dba_objects
WHERE REGEXP_LIKE(object_name,'s._temp[[:digit:]]','i')
  AND object_type='TABLE'
  AND created < SYSDATE-50/1440
GROUP BY owner
ORDER BY 1,2 ASC;
PROMPT
PROMPT "*****************************************************"
PROMPT
BEGIN
    FOR i IN (SELECT owner, object_name FROM dba_objects
              WHERE REGEXP_LIKE(object_name,'S._TEMP[[:digit:]]','i')
                AND object_type='TABLE' AND created < SYSDATE-50/1440)
    LOOP
        dbms_utility.exec_ddl_statement('drop table '||i.owner||'.'||i.object_name||' purge');
    END LOOP;
END;
/
show errors;
spool off
eof






--- sh flush_recycle_bin_objects.sh

# .bash_profile

PATH=$PATH:$HOME/bin

# Oracle Settings
ORACLE_HOSTNAME=$HOST; export ORACLE_HOSTNAME
ORACLE_UNQNAME=devracdb; export ORACLE_UNQNAME
ORACLE_BASE=/opt/app/oracle; export ORACLE_BASE
DB_HOME=$ORACLE_BASE/product/11.2.0/db_1; export DB_HOME
GI_HOME=/opt/app/11.2.0/grid; export GI_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
ORACLE_SID=devracdb1; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH:$GI_HOME/bin; export PATH
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

export PATH

sqlplus -s / as sysdba << eof
set pagesize 0;
set head off
set echo off
set feedback off
set serveroutput on
spool /home/oracle/cronjobs/purge_recyclebin.log
BEGIN
   FOR i IN (SELECT 'Purge table '||owner||'."'||object_name||'"' ptbl FROM sys.DBA_RECYCLEBIN)
   LOOP
      BEGIN
         EXECUTE IMMEDIATE i.ptbl;
      EXCEPTION
         WHEN OTHERS THEN NULL;
      END;
   END LOOP;
END;
/
show errors;
spool off
eof




sqlplus -s / as sysdba << eof
set pagesize 0;
set head off
set echo off
set feedback off
set serveroutput on
spool /home/oracle/cronjobs/analyzes_schema_logs.log
  exec dbms_stats.gather_schema_stats(ownname => upper('$1'), options => 'GATHER');
  COMMIT;
show errors;
spool off
eof
