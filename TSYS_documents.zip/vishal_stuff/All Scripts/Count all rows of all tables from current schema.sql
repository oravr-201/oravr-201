
set termout off echo off feed off trimspool on head off pages 0

spool c:\countallstag.tmp
select 'SELECT count(*), '''||table_name||''' from '||table_name||';'
from   user_tables
/
spool off

set termout on
@@c:\countallstag.tmp

set head on feed on
