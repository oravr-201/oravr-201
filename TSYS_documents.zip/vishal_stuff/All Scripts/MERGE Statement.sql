
Oracle9i New Feature Series: MERGE Statement - Insert or Update ("Upsert")


MERGE INTO target_table USING source_table ON match-condition
{WHEN [NOT] MATCHED THEN 
  [UPDATE SET ...|DELETE|INSERT VALUES ....|SIGNAL ...]}  
[ELSE IGNORE]


MERGE INTO bonuses B
USING (
  SELECT employee_id, salary
  FROM employee
  WHERE dept_no =20) E
ON (B.employee_id = E.employee_id)
WHEN MATCHED THEN
  UPDATE SET B.bonus = E.salary * 0.1
WHEN NOT MATCHED THEN
  INSERT (B.employee_id, B.bonus)
  VALUES (E.employee_id, E.salary * 0.05);
  
  
MERGE INTO emp e 
USING emp_load l  ON 
(e.empno=l.empno)  WHEN MATCHED THEN    UPDATE SET      e.ename = l.ename,      e.job = l.job,      e.mgr = l.mgr,      e.hiredate = l.hiredate,      e.sal = l.sal,      e.comm = l.comm,      e.deptno = l.deptno  WHEN NOT MATCHED THEN    INSERT VALUES (      l.empno, l.ename, l.job,      l.mgr, l.hiredate,      l.sal, l.comm, l.deptno    )/  