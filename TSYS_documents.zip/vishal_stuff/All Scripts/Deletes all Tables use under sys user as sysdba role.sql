rem =========================================================================
rem 
rem                     oriclean.sql
rem 
rem  HARDCORE HARDCORE HARDCORE HARDCORE HARDCORE HARDCORE HARDCORE HARDCORE
rem 
rem     Copyright (C) Oriole Software, 1998
rem 
rem     Downloaded from http://www.oriolecorp.com
rem 
rem     This script for Oracle database administration is free software; you
rem     can redistribute it and/or modify it under the terms of the GNU General
rem     Public License as published by the Free Software Foundation; either
rem     version 2 of the License, or any later version.
rem 
rem     This script is distributed in the hope that it will be useful,
rem     but WITHOUT ANY WARRANTY; without even the implied warranty of
rem     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
rem     GNU General Public License for more details.
rem 
rem     You should have received a copy of the GNU General Public License
rem     along with this program; if not, write to the Free Software
rem     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
rem 
rem =========================================================================
rem
rem    This script creates a package to clean-up tables, typically after
rem    running tests in a production database. It automatically takes
rem    care of referential constraints and cascades truncation or deletion
rem    even if no ON DELETE CASCADE was specified.
rem
rem    WHAT THIS PACKAGE DOES IS POTENTIALLY EXTREMELY DANGEROUS AND IT
rem    MUST BE USED WITH THE UTMOST CARE. ORIOLE CANNOT IN ANY CASE BE 
rem    CONSIDERED RESPONSIBLE FOR LOSS OF DATA FOLLOWING THE USE OF THIS
rem    PACKAGE WHICH YOU USE AT YOUR OWN RISK.
rem
rem    This script must be run by user SYS, either under SQL*Plus or after
rem    logging as INTERNAL under Server Manager.
rem    It creates a public synonym for the package.
rem
rem    When running the package :
rem     1) Don't forget to set serveroutput on
rem     2) Execute the default 'dry run' first. It will tell you
rem        which tables will be affected and you shall be able to
rem        detect any potential problem - you may have a well hidden
rem        referential constraint which could force the cleaning of
rem        unexpected tables.
rem     3) Run the procedures with 'do_it' set to TRUE.
rem
rem    Examples below.
rem
create or replace package oriclean
as
  --
  --  trunc_tab() :
  --   Truncates a table and all the tables which
  --   reference it. Leaves the data referenced by
  --   the table untouched. Very useful for cleaning up
  --   tables used for tests before coming in production.
  --
  --   Parameters : '[schema.]table_name'
  --                 boolean to require the actual truncation
  --                 (dry run by default)
  --
  --    In the default dry run mode, the procedure just 'says' which
  --    table it would truncate.
  --
  procedure trunc_tab(table_name in varchar2,
                      do_it in boolean default FALSE);
  --
  --  delete_tab() :
  --    Deletes specific lines in a table and automatically deletes
  --    all the lines elsewhere which reference them; in other words,
  --    it behaves as if integrity constraints had been declared as
  --    ON DELETE CASCADE. Useful for deleting test data which is
  --    polluting a production database.
  --
  --   Parameters : '[schema.]table_name'
  --                'where_cond'
  --                fire_triggers
  --                boolean to require the actual deletion
  --                (dry run by default)
  --
  --    where_cond is a where condition but MUST NOT contain
  --    the WHERE keyword. Otherwise it may be as complicated
  --    as one wants. Do not forget double quotes if you refer
  --    to character constants or dates.
  --    fire_triggers is a boolean which specifies whether we want
  --    triggers to be fired on the table or not (default is to fire
  --    them); if you do not want the triggers to be fired AND do not
  --    specify any condition, it's much much faster to use trunc_tab()
  --    instead.
  --    In the default dry run mode, the procedure just 'says' how many
  --    rows it would delete in such or such table.
  --
  --  Examples :
  --   1) execute oriclean.delete_tab('ORDERS.T_ORDER', 
  --                   'ordered_by=''TEST'' and timestamp < trunc(sysdate)',
  --                   do_it=>TRUE)';
  --
  --   2) execute oriclean.delete_tab('ORDERS.T_ORDER', do_it=>TRUE);
  --    will do the same as
  --      execute oriclean.trunc_tab('ORDERS.T_ORDER'), do_it=>TRUE;
  --    but will fire the (on delete) triggers on the table.
  --
  procedure delete_tab(table_name       in varchar2,
                       where_condition  in varchar2 default NULL,
                       fire_triggers    in boolean default TRUE,
                       do_it            in boolean default FALSE);

end;
/
create or replace package body oriclean
as
  type NumArrTyp   is table of number index by binary_integer;
  type RowidArrTyp is table of rowid  index by binary_integer;
  --
  --  Global variables (big strings, we do not want 
  --  stack overflow while recursing!)
  --
  G_my_schema     varchar2(30); 
  G_objid_array   NumArrTyp;
  G_deleted_array NumArrTyp;
  G_objid_count   binary_integer := 0;
  G_rowcount      number := 0;
  --
  --  Forward definitions
  --
  function del_rows(p_table  in varchar2,
                    p_rowids in RowidArrTyp,
                    do_it  in boolean)
  return number;
  procedure del_tab(table_name in varchar2,
                    p_objid      in number,
                    where_condition      in varchar2,
                    do_it      in boolean);
  function objid_pos(p_objid    in     number,
                     p_insert   in     boolean,
                     p_inserted in out boolean)
  return binary_integer;
  function tabname(p_objid in number)
  return varchar2;

  -- ===========================
  --
  --  Function implementation
  --
  -- ===========================
  --
  --   trunc_tab : public function
  --
  procedure trunc_tab(table_name in varchar2,
                      do_it      in boolean default FALSE)
  is
    type ReferencingTyp is table of varchar2(61)
                           index by binary_integer;
    type ConstraintTyp is  table of varchar2(30)
                           index by binary_integer;
    v_referencing_tables   ReferencingTyp;
    v_fk_constraints       ConstraintTyp;
    v_owner_name           varchar2(30);
    v_table_name           varchar2(30);
    cursor_id              number;
    cursor_open            boolean := FALSE;
    pos                    number;
    i                      binary_integer := 0;
    j                      binary_integer := 0;
    cursor c0 is           select ru.name || '.' || ro.name fk_table,
                                  rco.name constraint_name
                           from obj$ ro,
                                user$ ru,
                                cdef$ rcd,
                                con$ rco
                           where rcd.enabled is not null
                             and exists (select 'x'
                                         from cdef$ cd,
                                              obj$ o,
                                              user$ u 
                                         where u.name = v_owner_name
                                           and u.user# = o.owner#
                                           and o.name = v_table_name
                                           and o.obj# = cd.obj#
                                           and cd.con# = rcd.rcon#)
                              and ro.obj# = rcd.obj#
                              and ru.user# = ro.owner#
                              and rcd.con# = rco.con#;
  begin
    pos := instr(table_name, '.');
    if (pos = 0)
    then
      v_owner_name := G_my_schema;
      v_table_name := upper(table_name);
    else
      v_owner_name := upper(substr(table_name, 1, pos - 1));
      v_table_name := upper(substr(table_name, pos + 1));
    end if;
    --
    --   Truncate referencing tables as well and disable enabled
    --   foreign keys. What we disable is stored to PL/SQL tables
    --   in order to reenable these constraints, and these constraints
    --   only, later.
    --
    for rec0 in c0
    loop
      if (rec0.fk_table != v_owner_name || '.' || v_table_name)
      then
        trunc_tab(rec0.fk_table, do_it);        
      end if;
      if (do_it)
      then
        cursor_id := dbms_sql.open_cursor;
        cursor_open := TRUE;
        dbms_sql.parse(cursor_id, 'alter table ' || rec0.fk_table
                                   || ' disable constraint '
                                   || rec0.constraint_name,
                                 dbms_sql.native);
        pos := dbms_sql.execute(cursor_id);
        dbms_sql.close_cursor(cursor_id);      
        cursor_open := FALSE;
      end if;
      i := i + 1;
      v_referencing_tables(i) := rec0.fk_table;
      v_fk_constraints(i) := rec0.constraint_name;
    end loop;
    if (do_it)
    then
      dbms_output.put_line('Truncating table ' || table_name || ' ...');
      cursor_id := dbms_sql.open_cursor;
      cursor_open := TRUE;
      dbms_sql.parse(cursor_id, 'truncate table ' || table_name,
                                 dbms_sql.native);
      pos := dbms_sql.execute(cursor_id);
      j := 0;
      loop
        j := j + 1;
        exit when (j > i);
        dbms_sql.parse(cursor_id,
                     'alter table ' || v_referencing_tables(j)
                     || ' enable constraint '
                     || v_fk_constraints(j),
                     dbms_sql.native);
        pos := dbms_sql.execute(cursor_id);
      end loop;
      dbms_sql.close_cursor(cursor_id);      
    else
      dbms_output.put_line(table_name || ' would be truncated ...');
    end if;
  exception
    when others then
       if (do_it)
       then
         j := 0;
         loop
           j := j + 1;
           exit when (j > i);
           if not cursor_open
           then
             cursor_id := dbms_sql.open_cursor;
           end if;
           dbms_sql.parse(cursor_id,
                        'alter table ' || v_referencing_tables(j)
                        || ' enable constraint '
                        || v_fk_constraints(j),
                                 dbms_sql.native);
           pos := dbms_sql.execute(cursor_id);
         end loop;
       end if;
       raise;
  end;

  --
  --   delete_tab : public function
  --
  procedure delete_tab(table_name in varchar2,
                       where_condition      in varchar2 default NULL,
                       fire_triggers       in boolean default TRUE,
                       do_it      in boolean default FALSE)
  is
    type TriggerTyp is table of varchar2(61)
                       index by binary_integer;
    v_trigger_array    TriggerTyp;
    i                  binary_integer;
    j                  binary_integer;
    k                  binary_integer;
    cursorid           number;
    pos                number;
    dummy              number;
    v_inserted         boolean;
    v_inserted_flag    boolean;
    v_owner_name       varchar2(30);
    v_table_name       varchar2(30);
    v_name             varchar2(30);
    v_objid            number;
    cursor c1(c_objid in number) is
                       select obj# objid
                       from cdef$
                       where refact is null
                         and robj# = c_objid;
    cursor c2(c_objid in number) is
                       select u.name || '.' || o.name trigname
                       from user$ u,
                            obj$ o,
                            trigger$ t
                       where t.baseobject = c_objid
                         and nvl(t.enabled, 0) != 0
                         and t.obj# = o.obj#
                         and o.owner# = u.user#;
  begin
    G_rowcount := 0;
    pos := instr(table_name, '.');
    if (pos = 0)
    then
      v_owner_name := G_my_schema;
      v_table_name := upper(table_name);
    else
      v_owner_name := upper(substr(table_name, 1, pos - 1));
      v_table_name := upper(substr(table_name, pos + 1));
    end if;
    --
    --  The join with tab# is useless, but works with Oracle7
    --  and Oracle8, contrarily to a condition on type (Oracle7)
    --  or type# (Oracle8)
    --
    select o.obj#
    into v_objid
    from obj$ o,
         user$ u,
         tab$ t
    where u.name = v_owner_name
      and u.user# = o.owner#
      and o.name = v_table_name
      and o.obj# = t.obj#;
    --
    --  Do we want triggers to be fired ?
    --
    if (not fire_triggers)
    then
       --
       --  Get all the triggers on the table and all the tables
       --  which are likely to be deleted
       --
       --  Table list first. Beware of self-referencing tables.
       --
       v_inserted := TRUE;
       i := 1;
       j := 1;
       G_objid_array(1) := v_objid;
       while (v_inserted)
       loop
         v_inserted := FALSE;
         loop
           begin
             for rec1 in c1(G_objid_array(i))
             loop
               k := objid_pos(rec1.objid, TRUE, v_inserted_flag);
               if (v_inserted_flag)
               then
                 v_inserted := TRUE;
               end if;
               G_deleted_array(k) := 0;
             end loop;
             i := i + 1;
           exception
             when no_data_found then
                 exit;
           end;
         end loop;
       end loop;
       --
       --   At this stage we must have a unique list of tables.
       --   Let's get - and disable - the triggers.
       --
       if (do_it)
       then
         i := 1;
         j := 1;
         cursorid := dbms_sql.open_cursor;
         loop
           begin
             for rec2 in c2(G_objid_array(i))
             loop
               v_trigger_array(j) := rec2.trigname;
               j := j + 1;
               dbms_sql.parse(cursorid, 'alter trigger ' || rec2.trigname
                                  || ' disable', dbms_sql.native);
               dbms_output.put_line('disabling ' || rec2.trigname);
               dummy := dbms_sql.execute(cursorid);
             end loop;
             i := i + 1;
           exception
             when no_data_found then
               exit;
           end;
         end loop;
         dbms_sql.close_cursor(cursorid);      
      end if;
    else
      --
      --   Reset counters if needed
      --
      for i in 1 .. G_objid_count
      loop
        G_deleted_array(i) := 0;
      end loop;
    end if;
    --
    del_tab(table_name, v_objid, where_condition, do_it);
    commit;
    --
    if ((not fire_triggers) and do_it)
    then
      i := 1;
      cursorid := dbms_sql.open_cursor;
      loop
        begin
          dbms_sql.parse(cursorid, 'alter trigger ' || v_trigger_array(i)
                                  || ' enable', dbms_sql.native);
          dbms_output.put_line('enabling ' || v_trigger_array(i));
          dummy := dbms_sql.execute(cursorid);
          i := i + 1;
        exception
          when no_data_found then
            exit;
        end;
      end loop;
      dbms_sql.close_cursor(cursorid);      
    end if;
    --
    i := 1;
    while (i <= G_objid_count)
    loop
      v_name := tabname(G_objid_array(i));
      if (not do_it)
      then
        dbms_output.put_line(rpad(v_name, 30) || ':'
                           || to_char(G_deleted_array(i), '9999999990')
                           || ' row(s) would be deleted');
      else
        dbms_output.put_line(rpad(v_name, 30) || ':'
                           || to_char(G_deleted_array(i), '9999999990')
                           || ' row(s) deleted');
      end if;
      i := i + 1;
    end loop;
  exception
    when others then
      dbms_output.put_line('delete_tab: ' || SQLERRM);
      if ((not fire_triggers) and do_it)
      then
        if (not dbms_sql.is_open(cursorid))
        then
          cursorid := dbms_sql.open_cursor;
        end if;
        i := 1;
        loop
          begin
            dbms_sql.parse(cursorid, 'alter trigger ' || v_trigger_array(i)
                                    || ' enable', dbms_sql.native);
            dbms_output.put_line('enabling ' || v_trigger_array(i));
            dummy := dbms_sql.execute(cursorid);
            i := i + 1;
          exception
            when no_data_found then
              exit;
          end;
        end loop;
        dbms_sql.close_cursor(cursorid);      
      end if;
      i := 1;
      while (i <= G_objid_count)
      loop
        if (not do_it)
        then
          dbms_output.put_line(rpad(v_name, 30) || ':'
                             || to_char(G_deleted_array(i), '9999999990')
                             || ' row(s) would be deleted');
        else
          dbms_output.put_line(rpad(tabname(G_objid_array(i)), 30) || ':'
                             || to_char(G_deleted_array(i), '9999999990')
                             || ' row(s) deleted');
        end if;
        i := i + 1;
      end loop;
      raise;
  end;

  --
  --   objid_pos : private function
  --
  --   Returns the position of the object id in the G_objid_array array.
  --   If flag 'p_insert' is set to TRUE, the out parameter tells whether
  --   it has just been inserted or was already here.
  --   Returns 0 if not to insert and not there.
  --
  function objid_pos(p_objid in number,
                     p_insert in boolean,
                     p_inserted in out boolean)
  return binary_integer
  is
    k binary_integer;
  begin
    p_inserted := FALSE;
    G_objid_array(G_objid_count + 1) := p_objid;
    k := 1;
    while (G_objid_array(k) <> p_objid)
    loop
      k := k + 1;
    end loop;
    if (k = G_objid_count + 1)
    then
      if (p_insert)
      then
        G_objid_count := G_objid_count + 1;
        p_inserted := TRUE;
        return(G_objid_count);
      else
        return 0;
      end if;
    else
      return k;
    end if;
  end;

  --
  --   tabname : private function
  --
  --   Returns the table name
  --
  function tabname(p_objid in number)
  return varchar2
  is
    table_name varchar2(30);
  begin
    select name
    into table_name
    from obj$
    where obj# = p_objid;
    return table_name;
  end;

  --
  --   del_referencing_rows : private function
  --
  procedure del_referencing_rows(p_stmt in varchar2,
                                 p_table in varchar2,
                                 p_objid in number,
                                 p_rowid in varchar2,
                                 do_it in boolean)
  is
    v_rowid_array  RowidArrTyp;
    v_rowid        varchar2(20);
    v_rowid_idx    binary_integer;
    v_cursor_id    integer;
    v_rows         integer;
    v_tabidx       binary_integer;
    v_inserted     boolean;
  begin
    v_tabidx := objid_pos(p_objid, TRUE, v_inserted);
    if (v_inserted)
    then
      G_deleted_array(v_tabidx) := 0;
    end if;
    --
    -- prepare a cursor to execute the statement
    --
    v_rowid_idx := 0;
    v_cursor_id := dbms_sql.open_cursor;
    dbms_sql.parse(v_cursor_id, p_stmt, dbms_sql.native);
    dbms_sql.define_column(v_cursor_id, 1, v_rowid, 20);
    dbms_sql.bind_variable(v_cursor_id, 'rwid', p_rowid);
    v_rows := dbms_sql.execute(v_cursor_id);
    loop
      begin
        --
        -- get the rowid value of the row
        --
        v_rows := dbms_sql.fetch_rows(v_cursor_id);
        if (v_rows = 0)
        then
          exit;
        end if;
        dbms_sql.column_value(v_cursor_id, 1, v_rowid);
        v_rowid_idx := v_rowid_idx + 1;
        v_rowid_array(v_rowid_idx) := chartorowid(v_rowid);
      exception
        when no_data_found then
           exit;
      end;
    end loop;
    dbms_sql.close_cursor(v_cursor_id);
    if (v_rowid_idx > 0)
    then
      G_deleted_array(v_tabidx) := G_deleted_array(v_tabidx) +
                                   del_rows(p_table, v_rowid_array, do_it);
    end if;
  exception
    when others then
      dbms_output.put_line('del_referencing_rows: ' || SQLERRM);
      dbms_output.put_line(p_rowid);
      dbms_output.put_line(p_stmt);
      if dbms_sql.is_open(v_cursor_id)
      then
        dbms_sql.close_cursor(v_cursor_id);
      end if;
      raise;
  end;

  --
  --   del_rows : private function
  --
  --   Deletes from p_table row all rows in p_rowids (and all referencing rows)
  --
  function del_rows(p_table  in varchar2,
                    p_rowids in RowidArrTyp,
                    do_it  in boolean)
  return number
  is
    v_stmt       varchar2(2500) := '';
    v_selstmt    varchar2(2500) := '';
    v_string1    varchar2(1000) := '';
    v_string2    varchar2(1000) := '';
    v_index      binary_integer;
    v_rowid      varchar2(20);
    v_cursor_id  integer;
    v_rows       integer;
    v_del_rows   integer;
    v_prevcon#   number         := 0;
    v_prevobj#   number         := 0;
    v_prevtable  varchar2(61)   := '';
    cursor c is  select u.name || '.' || o.name table_name,
                        o.obj#,
                        cc.con#,
                        cc.pos#,
                        c.name  fk_colname,
                        rc.name pk_colname
                 from user$ u,
                      obj$ o,
                      ccol$ cc,
                      col$ c,
                      col$ rc,
                      ccol$ rcc,
                      cdef$ cd,
                      obj$ ro,
                      user$ ru
                 where ru.name = decode(instr(p_table, '.'), 0, user,
                         upper(substr(p_table, 1, instr(p_table, '.') - 1)))
                   and ru.user# = ro.owner#
                   and ro.name = decode(instr(p_table, '.'), 0, upper(p_table),
                         upper(substr(p_table, instr(p_table, '.') + 1)))
                   and ro.obj# = cd.robj#
                   and cd.con# = cc.con#
                   and cd.rcon# = rcc.con#
                   and cc.pos# = rcc.pos#
                   and rcc.obj# = ro.obj#
                   and cc.obj# = o.obj#
                   and o.owner# = u.user#
                   and c.obj# = o.obj#
                   and c.col# = cc.col#
                   and rc.obj# = ro.obj#
                   and rc.col# = rcc.col#
                 order by 1, 2, 3, 4;
  begin
    for rec in c
    loop
      if (rec.con# != v_prevcon#)
      then
        if (v_prevcon# != 0)
        then
          v_selstmt := 'select rowid' || chr(10) ||
                       'from ' || v_prevtable || chr(10) ||
                       'where (' || v_string1 || ') = (select ' ||
                                    v_string2 || chr(10) ||
                       chr(9) || 'from ' || p_table || chr(10) ||
                       chr(9) || 'where rowid = :rwid)';
          v_index := 1;
          loop
            begin
              del_referencing_rows(v_selstmt,
                                   v_prevtable,
                                   v_prevobj#,
                                   p_rowids(v_index),
                                   do_it);
              v_index := v_index + 1;
            exception
              when no_data_found then
                 exit;
            end;
          end loop;
        end if;
        v_prevobj# := rec.obj#;
        v_prevcon# := rec.con#;
        v_prevtable := rec.table_name;
        v_string1 := rec.fk_colname; 
        v_string2 := rec.pk_colname; 
      else
        v_string1 := v_string1 || ',' || rec.fk_colname;
        v_string2 := v_string2 || ',' || rec.pk_colname;
      end if;
    end loop;
    if (v_prevcon# != 0)
    then
      v_selstmt := 'select rowid' || chr(10) ||
                   'from ' || v_prevtable || chr(10) ||
                   'where (' || v_string1 || ') = (select ' ||
                                v_string2 || chr(10) ||
                   chr(9) || 'from ' || p_table || chr(10) ||
                   chr(9) || 'where rowid = :rwid)';
      v_index := 1;
      loop
        begin
          del_referencing_rows(v_selstmt,
                               v_prevtable,
                               v_prevobj#,
                               p_rowids(v_index),
                               do_it);
          v_index := v_index + 1;
        exception
          when no_data_found then
             exit;
        end;
      end loop;
    end if;
    --
    --  We can now safely delete the specified rows
    --
    --  We use a bind variable to limit parsing when a
    --  large number of rows are to be deleted from the
    --  same table.
    --
    begin
      if (do_it)
      then
        v_cursor_id := dbms_sql.open_cursor;
        v_stmt := 'delete ' || p_table || ' where rowid = :rwid';
        dbms_sql.parse(v_cursor_id, v_stmt, dbms_sql.native);
      end if;
    v_del_rows := 0;
    v_index := 1;
    loop
      begin
        v_rowid := p_rowids(v_index);
        if (do_it)
        then
          dbms_sql.bind_variable(v_cursor_id, 'rwid', v_rowid);
          v_rows := dbms_sql.execute(v_cursor_id);
          v_del_rows := v_del_rows + v_rows;
        else
          v_del_rows := v_del_rows + 1;
        end if;
        v_index := v_index + 1;
        G_rowcount := G_rowcount + 1;
        if ((mod(G_rowcount, 100) = 0) and do_it)
        then
          commit;
        end if;
      exception
        when no_data_found then
           exit;
      end;
    end loop;
    exception
       when others then
         if dbms_sql.is_open(v_cursor_id)
         then
            dbms_sql.close_cursor(v_cursor_id);
         end if;
         dbms_output.put_line('del_rows: ' || SQLERRM);
         raise;
    end;
    if dbms_sql.is_open(v_cursor_id)
    then
       dbms_sql.close_cursor(v_cursor_id);
    end if;
    return v_del_rows;
  end;
 
  --
  --   del_tab : private function
  --
  procedure del_tab(table_name in varchar2,
                    p_objid      in number,
                    where_condition      in varchar2,
                    do_it      in boolean)
  is
    v_rowid_array RowidArrTyp;
    v_rowid_idx   binary_integer;
    v_owner_name  varchar2(30);
    v_table_name  varchar2(30);
    v_rowid       varchar2(18);
    v_rows        number;
    cursor0       number;
    pos           number;
    v_tabidx      binary_integer;
    v_inserted    boolean;
  begin
     cursor0 := dbms_sql.open_cursor;
     pos := instr(table_name, '.');
     if (pos = 0)
     then
       v_owner_name := G_my_schema;
       v_table_name := upper(table_name);
     else
       v_owner_name := upper(substr(table_name, 1, pos - 1));
       v_table_name := upper(substr(table_name, pos + 1));
     end if;
     if (do_it)
     then
       dbms_output.put_line('cleaning  : ' || v_owner_name
                                       || '.' || v_table_name);
       dbms_output.put_line('condition : ' || where_condition);
     else
       dbms_output.put_line('simulating cleaning of : ' || v_owner_name
                                       || '.' || v_table_name);
       dbms_output.put_line('condition              : ' || where_condition);
     end if;
     --
     if (where_condition is null)
     then
       dbms_sql.parse(cursor0,
                      'select rowidtochar(rowid) from ' || table_name,
                      dbms_sql.native);
     else
       dbms_sql.parse(cursor0,
                      'select rowidtochar(rowid) from ' || table_name
                      || ' where ' || where_condition,
                      dbms_sql.native);
     end if;
     v_tabidx := objid_pos(p_objid, TRUE, v_inserted);
     G_deleted_array(v_tabidx) := 0;
     --
     --  Load an array with the ROWIDs of rows to be deleted
     --
     dbms_sql.define_column(cursor0, 1, v_rowid, 18);
     v_rows := 1;
     v_rowid_idx := 1;
     v_rows := dbms_sql.execute_and_fetch(cursor0);
     while (v_rows > 0)
     loop
       begin
         dbms_sql.column_value(cursor0, 1, v_rowid);
         v_rowid_array(v_rowid_idx) := chartorowid(v_rowid);
         v_rowid_idx := v_rowid_idx + 1;
         v_rows := dbms_sql.fetch_rows(cursor0);
       exception
         when no_data_found then
            v_rows := 0;
       end;
     end loop; 
     dbms_sql.close_cursor(cursor0);      
     G_deleted_array(v_tabidx) := G_deleted_array(v_tabidx)
                                  + del_rows(table_name,
                                             v_rowid_array,
                                             do_it);
  exception
    when others then
      if dbms_sql.is_open(cursor0)
      then
        dbms_sql.close_cursor(cursor0);      
      end if;
      raise;
  end;

begin
  dbms_output.enable(500000);
  select username
  into G_my_schema
  from v_$session
  where audsid = userenv('SESSIONID');
end;
/
drop public synonym oriclean;
create public synonym oriclean for oriclean;

