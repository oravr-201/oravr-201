6572474368
--*****************************************************************

# set the kernel parameters

vi /etc/sysctl.conf

				
kernel.shmall = 18874368
kernel.shmmax = 3147483648  -- Smallest of -> (Half the size of the physical memory) or (4GB - 1 byte)
kernel.shmmni = 4096 -- semaphores: semmsl, semmns, semopm, semmni
kernel.sem = 250 32000 100 128
fs.file-max = 65536 --# 512 * PROCESSES
net.ipv4.ip_local_port_range = 1024 65000
net.core.rmem_default=4194304
net.core.rmem_max=4194304
net.core.wmem_default=262144
net.core.wmem_max=262144

-- For Enterprise Linux 5.0, the following lines should be appended to the "/etc/sysctl.conf" file.

kernel.shmmni = 4096
# semaphores: semmsl, semmns, semopm, semmni
kernel.sem = 250 32000 100 128
net.ipv4.ip_local_port_range = 1024 65000
net.core.rmem_default=4194304
net.core.rmem_max=4194304
net.core.wmem_default=262144
net.core.wmem_max=262144

-- Run the following command to change the current kernel parameters:

    /sbin/sysctl -p
    
Notes: Execute sysctl -p to make these new settings take effect.

--*****************************************************************

#set the limitation parameters.

vi /etc/security/limits.conf

oracle           soft    nofile          63536
oracle           hard    nofile          63536

oracle           soft    nproc           16384
oracle           hard    nproc           16384

oracle           soft    memlock         3145728
oracle           hard    memlock         3145728


--*****************************************************************
--Add the following line to the /etc/pam.d/login file, if it does not already exist:

vi /etc/pam.d/login

session    required     pam_limits.so


--*****************************************************************
-- Disable secure linux by editing the /etc/selinux/config file, making sure the SELINUX flag is set as follows:


vi /etc/selinux/config

SELINUX=disabled
    
--*****************************************************************
# change the hosts and ip address setting as per the db server name and ip

vi /etc/hosts


127.0.0.1       localhost.localdomain localhost  --- local ip and localhost
10.66.15.212    sc-siguedb2.ifxsc.com sc-siguedb2 --- ip and DB Server name
10.66.15.213    sc-siguedb1.ifxsc.com sc-siguedb1 -- ip and db server name of standby DB
10.65.235.60    sqlcluster SQLCLUSTER CLUSTER	  -- ip and db server name of cluster DB
# 65.216.123.102  sqlcluster SQLCLUSTER CLUSTER



# reboot the linux server to take the effect in above memory configuration files.
# you should be on root for executing the below command for rebooting the linux server

sync;sync;reboot



--*****************************************************************

-- set up the vncserver by login into oracle account
-- execute all the below commands in oracle account for vncserver set and start.
service vncserver start / stop

vncpasswd

vncserver :1.1521 --- starts vncserver for 1521 port only on :1

login to vnc and start the runinstall.sh from oracle user account


-- changes in vncserver file for starting in gnome mode

vi /home/oracle/.vnc/xstartup --- this is the home directory of oracle change as per your's

#make the chages before EOF of the file
exec gnome-session &

-- save the vncserver file and exit from vi editor

#kill the session of vncserver
vncserver -kill :1



/*

 unset SESSION_MANAGER
 exec /etc/X11/xinit/xinitrc

[ -r $HOME/.Xresources ] && xrdb $HOME/.Xresources
xsetroot -solid grey
vncconfig -iconic &
xterm -geometry 80x24+10+10 -ls -title "$VNCDESKTOP Desktop" &
exec gnome-session
twm &

*/

--*****************************************************************
To create the oracle account and groups, execute the following commands: 
su - root
groupadd dba          # group of users to be granted SYSDBA system privilege
groupadd oinstall     # group owner of Oracle files
useradd -c "Oracle software owner" -g oinstall -G dba oracle -d /ora1/oracle

passwd oracle

cd /home/oracle

mkdir OraHome1

chown -R oracle.oinstall /home/oracle/OraHome1
chmod -R 777 /home/oracle/OraHome1

chown -R oracle.dba /ora1
chown -R oracle.dba /ora2
chown -R oracle.dba /ora3

chmod -R 777 /ora1
chmod -R 777 /ora2
chmod -R 777 /ora3


mkdir -p /opt/app/oracle/product/11.2.0/dbhome_1
mkdir -p /opt/app/11.2.0/grid_1


chown -R oracle.oinstall /opt/app/
chmod -R 775 /opt/app/

mkdir -p /backup/oracle/
chown -R oracle:oinstall /backup/oracle/
chmod -R 775 /backup/oracle/
--*****************************************************************

login to oracle account and modify .bash_profile  
file as per the ORACLE_BASE / ORACLE_HOME and ORACLE_SID  and also set rest environment
variables in this file 

for e.g

vi .bash_profile

# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs
ORACLE_BASE=/oracle
ORACLE_HOME=/oracle/OraHome1

#ORACLE_SID=stag
#ORACLE_SID=qadb

export ORACLE_BASE
export ORACLE_HOME
export ORACLE_SID

unset TWO_TASK
export LD_ASSUME_KERNEL=2.4.20
PATH=$ORACLE_HOME/bin:/usr/bin:/bin:/usr/bin/X11:/usr/local/bin:/sbin:

#PATH=$PATH:$HOME/bin

export PATH
unset USERNAME

--*****************************************************************

#execute the command for unzip the file having .cpio extension else make it unzip which is having .zip extension
cpio -idmv < <file_path.cpio>

unzip <file_patch_path.zip>


--*****************************************************************

-- Listener settings
LISTENER =
  (DESCRIPTION_LIST =
    (DESCRIPTION =
      (ADDRESS = (PROTOCOL = TCP)(HOST = 10.120.90.63)(PORT = 1521))
    )
  )


SID_LIST_LISTENER =
    (SID_DESC =
      (GLOBAL_DBNAME = loadtest)
      (ORACLE_HOME = $ORACLE_HOME)
      (SID_NAME = loadtest)
    )
  )



--*****************************************************************

-- TNS Entry settings
loadtest =
  (DESCRIPTION=
    (ADDRESS=
      (PROTOCOL=TCP)
      (HOST=loadtestdb.infonox.com)
      (PORT=1521)
    )
    (CONNECT_DATA=
      (SERVICE_NAME=loadtest)
    )
  )
  
  
  
  
  
--Final Setup******************************************************************************************
Create the new groups and users:

    groupadd oinstall
    groupadd dba
    groupadd oper
    groupadd asmadmin

    useradd -g oinstall -G dba,oper,asmadmin oracle
    passwd oracle

Note. We are not going to use the "asmadmin" group, since this installation will not use ASM.

Create the directories in which the Oracle software will be installed:

    mkdir -p /u01/app/oracle/product/11.1.0/db_1
    chown -R oracle:oinstall /u01
    chmod -R 775 /u01

Login as root and issue the following command:

    xhost +<machine-name>

Login as the oracle user and add the following lines at the end of the .bash_profile file:


# Oracle Settings
TMP=/tmp; export TMP
TMPDIR=$TMP; export TMPDIR

ORACLE_HOSTNAME=octifxsdb01.ifxtempe.com; export ORACLE_HOSTNAME

ORACLE_BASE=/u01/app/oracle; export ORACLE_BASE
ORACLE_HOME=$ORACLE_BASE/product/11.1.0/db_1; export ORACLE_HOME

ORACLE_SID=devdb; export ORACLE_SID

ORACLE_TERM=xterm; export ORACLE_TERM

PATH=/usr/sbin:$PATH; export PATH

PATH=$ORACLE_HOME/bin:$PATH; export PATH

#LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib; export LD_LIBRARY_PATH
#CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

if [ $USER = "oracle" ]; then
  if [ $SHELL = "/bin/ksh" ]; then
	ulimit -p 16384
	ulimit -n 65536
  else
	ulimit -u 16384 -n 65536
  fi
fi



--Installation
Log into the oracle user. If you are using X emulation then set the DISPLAY environmental variable:

    DISPLAY=<machine-name>:0.0; export DISPLAY