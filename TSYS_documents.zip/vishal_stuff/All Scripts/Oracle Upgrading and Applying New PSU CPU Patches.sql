/* 

*****> Some points 

    To minimize the downtime during the upgrade process one can switch the database to NOARCHIVELOG mode. Once the upgrade
    has been completed successfully the ARCHIVELOG mode has to be switched on again.

*/

-- Check the database last upgraded version and applied patches on the version
SQL> select * from sys.REGISTRY$HISTORY 


-- If OEM is configured than stop the agent
export AGENT_HOME=/home/oracle/app/oracle/agent11g

$AGENT_HOME/bin/./emctl stop agent --- status (checks the status)
                                    --- start (start the agent)

                                    
--- Upgrad the Oracle Version E.g. from 10G to 11G or 11G (version R1 - 11.1.) to 11G (version R2 - 11.2.)
-- or from 11G (Version 11.1.0.6) to 11G (version 11.1.0.7)


Download the Oracle version you want to install 11G R1, 11G R2 release.

Once downloaded then unzip the file.

Before starting the task of database upgradation....>
/* 

-- Take the mentioned files Backup before Upgrading the Oracle Version 
    1) SPIFL
    2) PFILE  --- before shutting down the database for upgradation, create the PFILE from SPFILE.
    3) Password Files. --- check in $ORACLE_HOME/dbs folder.
    
*/

--stop the running listener
ORACLE> lsnrctl stop


SQL> CREATE PFILE='$ORACLE_HOME/dbs/initdevdb.ora' FROM SPFILE;

-- Do not make shutdown abort instead should shutdown the DB in immediate mode
SQL> shutdown immediate

-- again start the database to shutdown in normal
SQL> startup 

-- shutdown the DB in normal mode.
SQL> shutdown normal


-- Suppose you want to Upgrade Oracle version 11.1.0.7.0 (R1) on 10G or 11.1.0.6


--start the VNCServer for installation of latest oracle version
vncserver :1

start installation of Oracle version and check for any errors while installation of software 
and run the script which installation is asking while installing the software.

--After installation is done successfully then connect to sysdba 
sqlplus / as sysdba

-- Start upgrading the database
SQL>startup upgrade

-- There might be errors of realted to memory 
/*

--*****> If the errors is coming as 
ORA-03113: end-of-file on communication channel
Process ID: 5565
Session ID: 170 
Serial number: 3

while connecting starting the database in mount stage...

To resolve the Bug ... Bug 7272646: ORA-27103 WHEN MEMORY_TARGET > 3G

https://support.oracle.com/CSP/main/article?cmd=show&type=BUG&id=7272646


There are the parameteres in init parameter file .ora in which we have to look into

memory_target=13500416000
devdb.__pga_aggregate_target=5380243456
devdb.__sga_target=8120172544


resolve it by

   commenting memory_target parameter and memory_target - devdb.__sga_target = devdb.__pga_aggregate_target

*/

--After modification in init parameter file save it, Again connect to sysdba
sqlplus / as sysdba

-- create spfile from the modified pfile
SQL>create spfile from pfile='/home/oracle/app/oracle/product/11.1.0/db_1/dbs/initdevdb.ora';

-- again start upgradation of database
SQL> startup upgrade

--After successfully open database without any errors execute the script catupgrd.sql
----Along with catalog.sql and catproc.sql, many other scripts will get execute by calling catupgrd.sql
SQL> @$ORACLE_HOME\rdbms\admin\catupgrd.sql

--Restart the database using immediate keyword and restart the database with normal startup command
SQL> shutdown immediate

-- start the database again
SQL> STARTUP

-- Run the utlrp.sql script to recompile all invalid PL/SQL packages. This step is optional but recommended.
SQL> @ORACLE_BASE\ORACLE_HOME\rdbms\admin\utlrp.sql

--- should check for the invalid objects
SQL> SELECT COUNT(*) FROM UTL_RECOMP_COMPILED;

--- Use the command to flush the pool. 
SQL> ALTER SYSTEM FLUSH SHARED_POOL 


/*

-- Some Help....
shared_pool_reserved_size - 
	Controls the amount of SHARED_POOL_SIZE reserved for large allocations. The fixed view V$SHARED_POOL_RESERVED helps you tune these parameters. 
Begin this tuning only after performing all other shared pool tuning on the system. 

shared_pool_reserved_min_alloc - 
	Controls allocation for the reserved memory. To create a reserved list, SHARED_POOL_RESERVED_SIZE must be greater than SHARED_POOL_RESERVED_MIN_ALLOC. 
Only allocations larger than SHARED_POOL_RESERVED_POOL_MIN_ALLOC can allocate space from the reserved list if a chunk of memory of sufficient size is 
not found on the shared pool free lists. The default value of SHARED_POOL_RESERVED_MIN_ALLOC should be adequate for most systems. 

*/


--Finally, a run of the post-upgrade status script utlu111s.sql is required to verify that all components have been upgraded successfully to new version installed
SQL>@?/rdbms/admin/utlu111s.sql



-- If OEM is configured than start the agent
$AGENT_HOME/bin/./emctl start agent --- status (checks the status)
                                    --- stop ( stops the agent)

                                    














-----***************************************************
--                                                     *
--              Apply the PSU and CPU Patches          *
--                                                     *
-----***************************************************

/*

*********************************************************************************************************************
                                                                                                                    *
To install Opatch or patchsets all processes that use the $ORACLE_HOME being patched MUST be shutdown cleanly,      *
this would include databases, listeners, intelligent agents, database control etc.                                  *
                                                                                                                    *
*********************************************************************************************************************

*/

-------------------------------------> UPGRADATION STARTING HERE <--------------------------------

-- Applying the PSU and CPU patches 

-- Opatch path should be present in env.
export AGENT_HOME=/home/oracle/app/oracle/agent11g

-- If OEM is configured than stop the agent
export AGENT_HOME=/home/oracle/app/oracle/agent11g

export PATH=$PATH:$ORACLE_HOME/OPatch



$AGENT_HOME/bin/./emctl stop agent --- status (checks the status)
                                    --- start (start the agent)
                                    
               
              

/*

--The following example applies all patches under the <patch_location> directory:
oracle> opatch napply <patch_location>

--The following example applies patches 1, 2, and 3 that are under the <patch_location> directory:
oracle> opatch napply <patch_location> -id 1,2,3

--The following example applies all patches under the <patch_location> directory. OPatch skips duplicate patches and 
--subset patches (patches under <patch_location> that are subsets of patches installed in the Oracle home).

oracle> opatch napply <patch_location> -skip_subset -skip_duplicate

-- The following example applies patches 1, 2, and 3 that are under the <patch_location> directory. OPatch skips duplicate patches and 
--subset patches (patches under <patch_location> that are subsets of patches installed in the Oracle home).

oracle> opatch napply <patch_location> -id 1,2,3 -skip_subset -skip_duplicate

*/







/* 	Installing OPtach utility to New version

    You must use the OPatch utility version 11.1.0.8.2 or later to apply this patch to apply the patch set Oracle 11.1.0.7.0
    
    just copy the new version OPtach utility to Oracle's home directoy 
    
    cd /home/oracle/app/oracle/product/11.1.0/db_1/OPatch
    
    mv OPatch OPatch_old
    
    unzip OPatch.tar.gz
    
    
*/    








111082

--- Before applying the patch set, Determine whether any currently installed one-off patches conflict with the PSU patch as follows:
cd /home/oracle/software/psu_patches/cpu_patchset

opatch prereq CheckConflictAgainstOHWithDetail -phBaseDir  14739378/




--stop the running listener
ORACLE> lsnrctl stop

-- Do not make shutdown abort instead should shutdown the DB in immediate mode
SQL> shutdown immediate

-- again start the database to shutdown in normal
SQL> startup 

-- shutdown the DB in normal mode.
SQL> shutdown normal


-- Suppose if want to apply the PSU patch than
opatch napply /home/oracle/software/psu_patches/cpu_patchset/10249534 -skip_subset -skip_duplicate

and 

cd /home/oracle/software/psu_patches/psu_15Jan2013/
-- -- Suppose if want to apply the CPU patch than
opatch apply 14739378/

--- Once the patche set (PSU/CPU) is applied, follow the below process 


-- start DB
sqlplus / as sysdba
SQL> startup

-- run the below command 
SQL> @?/rdbms/admin/catbundle.sql psu apply;

SQL>shutdown normal;

--- if there is any error for registry$history table then you have to startup database in startup upgrade mode 
--- and run @?\rdbms\admin\catupgrd.sql script, which will run catalog.sql and catproc.sql with other main script to valided all invalid objects




--If you want to check whether view recompilation has already been performed for the database, execute the following statement:
SQL>SELECT * FROM registry$history where ID = '6452863';


--If the view recompilation has been performed, this statement returns one or more rows. If the view recompilation has not been performed, 
--this statement returns no rows.

/*
   Then you need to check & run the @?/cpu/view_recompile/recompile_precheck_jan2008cpu.sql script, if you find any error in the script you will have to 
   startup and perform upgrade with STARTUP UPGRADE command

*/


--Run the pre-check script (so named because it was initially released in CPUJan2008), which reports the maximum 
--number of views and objects that may be recompiled:

sqlplus /nolog

SQL> CONNECT / AS SYSDBA
SQL> SHUTDOWN IMMEDIATE
SQL> STARTUP UPGRADE
SQL> @?/cpu/view_recompile/recompile_precheck_jan2008cpu.sql
SQL> 
--The purpose of this step is to help you determine whether view recompilation should be done at the same time as the PSU install, or scheduled later.


--Run the view recompilation script. Note that this script is run with the database in upgrade mode, which restricts connections as SYSDBA.
SQL> @?/cpu/view_recompile/view_recompile_jan2008cpu.sql
SQL> SHUTDOWN;
SQL> exit


--Re-connect to sqlplus prompt
sqlplus / as sysdba

--- Again start the database in normal mode
SQL> STARTUP;

--If any invalid objects were reported, run the utlrp.sql script as follows:
SQL> @?/rdbms/admin/utlrp.sql



--Finally, a run of the post-upgrade status script utlu111s.sql is required to verify that all components have been upgraded successfully to new version installed
SQL>@?/rdbms/admin/utlu111i.sql




-------------------------------------> UPGRADATION DONE HERE <--------------------------------

















--******> Once the PSU/CPU Patche is applied
-- If OEM is configured than start the agent
$AGENT_HOME/bin/./emctl start agent --- status (checks the status)
                                    --- stop ( stops the agent)
-- start listener
lsnrctl start








-- Check once the Critical Patche Update is done by opatch utility
opatch lsinventory -detail



--**************************************************************
----------------------------------
Patch Deinstallation Instructions:
----------------------------------

1. Make sure to follow the same pre-install steps when deinstalling
a patch.  This includes verifying the inventory and shutting down
any services running from the ORACLE_HOME / machine before rolling
the patch back.

2. Change to the directory where the patch was unzipped.
  cd <PATCH_TOP>/8639653

3. Run OPatch to deinstall the patch.
  opatch rollback -id 8639653


--**************************************************************


-- Determining the latest PSU installed in the Oracle Home. For PSUs, enter the following command:
oracle> opatch lsinventory -bugs_fixed | grep -i 'DATABASE PSU'





--**************************************************************

-- for Starting and Stopping Enterprise Manager Components
--http://docs.oracle.com/cd/E11857_01/em.111/e16790/emctl.htm


/*
Starting the Database Control on UNIX
To start the Database Control, as well the Management Agent and the Management Service associated with the Database Control:

Set the following environment variables to identify the Oracle home and the system identifier (SID) for the database instance you want to manage:

ORACLE_HOME

ORACLE_SID

Change directory to the ORACLE_HOME/bin directory.

Enter the following command:

$PROMPT> ./emctl start dbconsole

Stopping the Database Control on UNIX
To stop the Database Control, as well the Management Agent and the Management Service associated with the Database Control:

Set the following environment variables to identify the Oracle home and the system identifier (SID) for the database instance you want to manage:

ORACLE_HOME

ORACLE_SID

Change directory to the ORACLE_HOME/bin directory.

Enter the following command:

$PROMPT> ./emctl stop dbconsole

*/