Top-N queries are a whole new thing in Oracle8i release 2.  They are very *cool* 
and much much easier to do.

Let's say you wanted the top 2 salary earners by deptno in the EMP table.  This 
can be interpreted at least 3 ways:

o find the top two salaries by deptno and give me everyone who makes that

o find upto three people who make the highest salaries.  If 4 people make the 
highest salary the answer will be the NULL set.  If 2 people make the highest 
and 2 people make the next highest -- the answer will be 2 rows (just the 
highest) since if we returned both -- we'd get four rows

o return me the first three highest paid people you happen to find.

We can do all three easily now:


ops$tkyte@DEV816> select *
  2    from ( select deptno, ename, sal,
  3                  dense_rank()
  4                  over ( partition by deptno
  5                         order by sal desc nulls LAST ) dr
  6            from emp )
  7   where dr <= 2
  8  /

    DEPTNO ENAME             SAL         DR
---------- ---------- ---------- ----------
        10 KING             5000          1
        10 CLARK            2450          2
        20 SCOTT            3000          1
        20 FORD             3000          1
        20 JONES            2975          2
        30 BLAKE            2850          1
        30 ALLEN            1600          2

7 rows selected.

ops$tkyte@DEV816>


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------


What we did here was to use the DENSE_RANK() function to get the top two 
salaries.  We assigned the dense rank to the salary sorted descending.  Notice 
that when sorting, especially descending sorts, it is critical to add NULLS LAST 
to the order by (new in 8.1.6).  By default NULLS are �greater� than any other 
value in a sort.  If the salary fields had been null for any row � it would have 
been considered the largest value, not what you would want.  

A dense rank does not skip numbers and will assign the same number to those rows 
with the same value.  Hence, after the result set is built in the inline view � 
we can simply select all of the rows with a dense rank of three or less � that 
gives us everyone who makes the top three commissions by department number.

Lastly, we had to use an inline view and alias the dense rank column to DR.  
This is because we cannot use analytic functions in a where clause directly so 
we had to compute the view and then filter just the rows we wanted to keep.

Now for method 2:

ops$tkyte@DEV816> select *
  2    from ( select deptno, ename, sal,
  3                  count(*)
  4                  over ( partition by deptno
  5                         order by sal desc nulls LAST ) cnt
  6             from emp )
  7    where cnt <= 2
  8  /

    DEPTNO ENAME             SAL        CNT
---------- ---------- ---------- ----------
        10 KING             5000          1
        10 CLARK            2450          2
        20 SCOTT            3000          2
        20 FORD             3000          2
        30 BLAKE            2850          1
        30 ALLEN            1600          2

6 rows selected.

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

This one was a little tricky. What we are doing is counting everyone who makes 
what we make or more.  By counting everyone who makes what we make or more, we 
can retrieve only rows such that the count (CNT) of people making the same or 
more is less then or equal to 2.  Notice how for department 20, SCOTT and FORD 
both have a count of 2 � they are the top 2 salary earners in that department 
hence they are both in the same window with regards to each other. 

For the last question we can:

ops$tkyte@DEV816> select *
  2    from (select deptno, ename, sal,
  3                 row_number()
  4                 over ( partition by deptno
  5                        order by sal desc nulls LAST ) rn
  6            from emp )
  7   where rn <= 3
  8  /

    DEPTNO ENAME             SAL         RN
---------- ---------- ---------- ----------
        10 KING             5000          1
        10 CLARK            2450          2
        10 MILLER           1300          3
        20 SCOTT            3000          1
        20 FORD             3000          2
        20 JONES            2975          3
        30 BLAKE            2850          1
        30 ALLEN            1600          2
        30 TURNER           1500          3

9 rows selected.

That works by sorting each partition by SAL DESC (with NULLS LAST) and then 
assigning a sequential row number to each row in the partition.  We use a where 
clause after doing this to get just the first three rows in each partition.

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

They make the same salary -- the column:

count(*) over (partition by deptno order by sal desc) cnt


says "break the results into groups by deptno.   Within each group -- sort by 
sal.  Then count the rows with the same or less salary (since we sorted by sal 
-- that defines the 'key')"

So, when you do that with deptno = 20, SCOTT and FORD both make the same -- 
hence they get counted together (when you sort by SAL, SCOTT and FORD are the 
"same", neither comes before NOR after the other see).

We are counting ROWS (count(*) always counts ROWS)


So, say we change the key from "sal desc" to "sal desc, ROWID" -- what then?

scott@ORA817DEV.US.ORACLE.COM>  select ename,
  2          deptno,
  3          sal,
  4          comm,
  5          count(*) over (partition by deptno order by sal desc) cnt,
  6          count(*) over (partition by deptno order by sal desc, ROWID) cnt
  7   from emp;

ENAME          DEPTNO        SAL       COMM        CNT        CNT
---------- ---------- ---------- ---------- ---------- ----------
KING               10       5000                     1          1
CLARK              10       2450                     2          2
MILLER             10       1300                     3          3

SCOTT              20       3000                     2          1
FORD               20       3000                     2          2
JONES              20       2975                     3          3
ADAMS              20       1100                     4          4
SMITH              20        800                     5          5

BLAKE              30       2850                     1          1
ALLEN              30       1600        300          2          2
TURNER             30       1500          0          3          3
WARD               30       1250        500          5          4
MARTIN             30       1250       1400          5          5
JAMES              30        950                     6          6

14 rows selected.

Now, count(*) is counting the rows in the group such that the row is less then 
"sal desc, rowid" and since rowid it unique -- it assigns the count based on 
physical location in the datafile (eg: if you dump and reload the data -- FORD 
might come before SCOTT next time).
