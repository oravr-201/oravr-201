




--- Determine the interval breakdown between two dates for a DATE datatype

--- diff. between two date queries


SELECT TO_CHAR(Open_timestamp,'MMDDYYYY:HH24:MI:SS') Open_timestamp,
         TO_CHAR(Close_timestamp,'MMDDYYYY:HH24:MI:SS') Close_timestamp,
         TRUNC(86400*(Close_timestamp-Open_timestamp))-
         60*(TRUNC((86400*(Close_timestamp-Open_timestamp))/60)) seconds,
         TRUNC((86400*(Close_timestamp-Open_timestamp))/60)-
         60*(TRUNC(((86400*(Close_timestamp-Open_timestamp))/60)/60)) minutes,
         TRUNC(((86400*(Close_timestamp-Open_timestamp))/60)/60)-
         24*(TRUNC((((86400*(Close_timestamp-Open_timestamp))/60)/60)/24)) hours,
         TRUNC((((86400*(Close_timestamp-Open_timestamp))/60)/60)/24) days,
         TRUNC(((((86400*(Close_timestamp-Open_timestamp))/60)/60)/24)/7) weeks
FROM dual





---- Formatting of the TIMESTAMP datatype with fractional seconds

SELECT TO_CHAR(sysdate,'MM/DD/YYYY HH24:MI:SS:FF3') "Date" FROM dual