

----query returns Last record of table

select 
    * 
from 
    (
        select 
            * 
        from 
            cc_csr 
        order by rownum desc
    ) 
where rownum = 1;
