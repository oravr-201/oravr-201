
SELECT schemaname, osuser, machine, terminal, status, COUNT(*)
FROM v$session
WHERE SCHEMANAME NOT IN ('SYS')
GROUP BY schemaname, osuser, machine, terminal, status
order by 6 desc, 1,2,3,4,5 asc