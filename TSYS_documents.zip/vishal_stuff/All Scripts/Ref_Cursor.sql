CREATE OR REPLACE PACKAGE GetRefCursors IS

-- ************************************************
-- ** Author: Alf A. Pedersen www.databasedesign-resource.com
-- ** Version: : Apr. 10 2006
-- **
-- ************************************************
-- ** General global cursor for all functions returning result sets.
TYPE csGetResultSet is REF CURSOR;



-- *******************************************
-- ** Get all accounts for a given interval
-- ** In parameters:
-- ** First account
-- ** Last account
-- ** Returns:
-- ** Ref Cursor for the given account interval.
-- ***********************************************
function sfGetAccountInterval
( pFirstAccount in ACCOUNTS.ACCOUNT_NO%type
,pLastAccount in ACCOUNTS.ACCOUNT_NO%type)
return csGetResultSet;

end GetRefCursors;
/

CREATE OR REPLACE package body GetRefCursors is
-- ************************************************
-- ** Author: Alf A. Pedersen www.databasedesign-resource.com
-- ** Version: : Apr. 10 2006
-- **
-- ************************************************

-- ************************************************
-- ** Get all accounts for a given interval
-- ** In parameters:
-- ** First account
-- ** Last account
-- ** Returns:
-- ** Ref Cursor for the given account interval.
-- ************************************************

function sfGetAccountInterval
( pFirstAccount in ACCOUNTS.ACCOUNT_NO%type
,pLastAccount in ACCOUNTS.ACCOUNT_NO%type)
return csGetResultSet is

csGetAccounts csGetResultSet;

begin

open csGetAccounts for

SELECT accounts.account_no
,accounts.name
FROM accounts
WHERE accounts.account_no BETWEEN pFirstAccount AND pLastAccount
ORDER BY accounts.account_no;

return csGetAccounts;

end sfGetAccountInterval;

end GetRefCursors;
/
