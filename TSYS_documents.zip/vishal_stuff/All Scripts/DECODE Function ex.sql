--DECODE EXAMPLE

DECODE(i_TypeCode,'13',NULL,'8',NULL,i_CasinoCode)

IF i_TypeCode = '13' THEN
	i_CasinoCode = NULL
ELSIF i_TypeCode = '8' THEN
	i_CasinoCode = NULL
END IF;


You could use the decode function in an SQL statement as follows: 

SELECT supplier_name,
 
	decode (supplier_id, 10000,  'IBM', 
						 10001, 'Microsoft', 
						 10002, 'Hewlett Packard', 
			'Gateway') result 
	FROM suppliers; 

++==============================================================================++
||																				||
++==============================================================================++

The above decode statement is equivalent to the following IF-THEN-ELSE statement: 

IF supplier_id = 10000 THEN
     result := 'IBM'; 

ELSIF supplier_id = 10001 THEN
    result := 'Microsoft'; 

ELSIF supplier_id = 10002 THEN
    result := 'Hewlett Packard'; 

ELSE
    result := 'Gateway'; 

END IF;  


Now, we can use Decode to display different things in a report based on the values in Viewable. 
 SELECT Firstname, 
     Decode(Viewable, 1,'VISIBLE', 2,'INVISIBLE', 3,'UNKNOWN', 'OTHER')
FROM   employee;

Results:

FIRSTNAME		Viewable
===========================
John			VISIBLE
Tim			INVISIBLE
Julie			INVISIBLE
Stacy			VISIBLE
Rahul			UNKNOWN
Leena			OTHER
Amy			VISIBLE
Bill			UNKNOWN
Teri			UNKNOWN
Decode checks the column values and interprets the provided values in pairs. This is how it works: 
 Switch viewable:

Case 1:
    Result = VISIBLE
Case 2:
    Result = INVISIBLE
Case 3:
    Result = UNKNOWN
Default:
    Result = OTHER
End Case

OR
====================

If Viewable = 1 Then
    Result = VISIBLE
Elsif Viewable = 2 Then
    Result = INVISIBLE
Elsif Viewable = 3 Then
    Result = UNKNOWN
Else
    Result = OTHER
End If

++================================================================================++
||																				  ||
++================================================================================++ 

One can use Decode in Updates as well. For example, instead of writing 50 different updates to change 
state names, we can do it in one Update using Decode as follows: 

Update 
	employee
set    homestate = decode(homestate, 
                        'AL', 'Alabama',
                        'AK', 'Alaska',
                        'AS', 'American Samoa',
                        'AZ', 'Arizona',
				. . . . . . . .
                        . . . . . . . . 
                        'WA', 'Washington',
                        'WV', 'West Virginia',
                        'WI', 'Wisconsin',
                        'WY', 'Wyoming' , homestate)
 where homecountry = 'UNITED STATES'
This will replace state abbreviations with state names. And it leaves the abbreviations alone in case it 
doesn't match any of the values, such as AL, AK, etc.
