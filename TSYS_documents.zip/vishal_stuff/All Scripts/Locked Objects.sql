
Who is locking what: 

------->

        select oracle_username os_user_name, locked_mode, object_name, object_type from  v$locked_object a,dba_objects b where  a.object_id = b.object_id;



wait the query should retuen 0 zero

select
  (select total_waits from v$system_event
  where event='buffer busy waits')
-  /* minus */
  (select sum(count) from v$waitstat)
FROM
  dual
