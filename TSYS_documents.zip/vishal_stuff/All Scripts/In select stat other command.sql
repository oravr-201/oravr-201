


    select 'alter trigger ' || owner ||'.'|| trigger_name ||' disable; '
    from dba_triggers
    
    
    
    select 'alter table ' || owner ||'.'|| table_name || ' disable constraint ' || constraint_name || ';'
    from dba_constraints
    where (r_owner, r_constraint_name) = (select owner, constraint_name
    from dba_constraints
    where owner = upper('&1')
    and table_name = upper('&2')
    and constraint_type = 'P')
    
    /

    Wheres the best place to look to see if a tablespace was in hot backup mode
    when a system crashes? 
    
    
    select 'alter tablespace ' ||tablespace_name||' end backup;'
    from dba_data_files where file_id
    in (select file# from v$backup where status ='ACTIVE');
    
    
SELECT 'DROP Table '|| Table_Name ||'CASCADE' 
FROM dba_synonyms 
WHERE Table_owner='QCP';
