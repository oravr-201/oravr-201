        
 Query shows if a tablespace was in hot backup mode when a system crashes? 
       
        
        select d.tablespace_name
        from   v$backup b,
            dba_data_files d
        where  b.file# = d.file_id
        and  b.status = 'ACTIVE'
