


select sys_context('USERENV','DB_NAME') from dual;



select DECODE(UPPER(sys_context('USERENV','DB_NAME')),'AQPROD','QCPW DB') "DB Name", 
   ab.grantee "Username", nvl(trim(granted_role),'NO PRIVILEGES') "Roles", 
   (case 
     when granted_role = 'dba' then 'Read+Write'
     when granted_role = 'RESOURCE' THEN 'Read Only'
     when granted_role = 'CONNECT' then 'Read Only'
     when granted_role = 'VIEWER' then 'Read Only' 
     when granted_role in ('EXP_FULL_DATABASE','IMP_FULL_DATABASE','DATAPUMP_EXP_FULL_DATABASE','DATAPUMP_IMP_FULL_DATABASE') then 'Read Only(Backups)'
     when granted_role = 'DB_RELEASE_GROUP' then 'Read+Write'
     when granted_role = 'OPERATOR' then 'Read Only'
     else 'SYSTEM'
   end) "Read/Write",
   du.account_status "Account_Status",
   du.lock_date "Lock_Date"
from 
 (
    select username grantee, ' ' granted_role from DBA_users where username not in (select grantee from DBA_role_privs) and username not in (select grantee from dba_sys_privs) 
    union 
    select  grantee, granted_role  granted_role from dba_role_privs where grantee in (select username from DBA_users)
    union 
    select grantee, privilege granted_role    from dba_sys_privs    where grantee not in (select grantee from DBA_role_privs)      and grantee in (select username from DBA_users)
  ) ab,
  dba_users du
where ab.grantee = du.username
order by 2 asc ; 




