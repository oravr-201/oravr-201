-- ---------------------------------------------------
-- dt.sql
--
-- produces a list of any tables and columns that are dependent
-- on the table that is passed as a parameter
-- ie. lists all Foreign Key columns linked to the table's Primary Key
--
-- Modifications:
-- 12-FEB-2005 SC  Created
--

-- ---------------------------------------------------

set serveroutput on size 150000 
set echo off verify off feedback off


prompt Examining the data dictionary for dependent tables. Please
wait....
prompt

declare
cursor c1 is

select a.constraint_name, a.table_name,
       decode(sign(length(a.constraint_name) -12),
              1,substr(a.constraint_name,1,10)||'..', 
              a.constraint_name) short_constraint_name
from user_constraints a, user_constraints b
where b.table_name = upper('&1')
and   b.constraint_type = 'P'
and   a.r_constraint_name = b.constraint_name
and   a.constraint_type in ('R');
--
-- pk-columns
cursor c2 is 
select nvl(decode(position,1,null,',')||rtrim(column_name),'None')pk_coln 
from user_cons_columns a, user_constraints b
where a.constraint_name = b.constraint_name
and   b.table_name = upper('&1')
and   b.constraint_type = 'P'
order by position;
--
-- fk-dependents
cursor c3 (p_constraint_name varchar2 ) is 
select decode(position,1,null,',')||rtrim(column_name) fk_coln 
from user_cons_columns a 
where a.constraint_name = p_constraint_name
order by position;
--

cname varchar2(30);
fk_col_list varchar2(90);
pk_col_list varchar2(90);
fk_coln         varchar2(30);
pk_coln         varchar2(30);
out_line1       varchar2(120); 
--
begin
pk_col_list := null;
open c2 ;
loop 
  fetch c2 into pk_coln;
  exit when c2%notfound;
--  dbms_output.put_line(pk_col_list ||':'||pk_coln);
  pk_col_list := pk_col_list || pk_coln;

--  pk_col_list := pk_col_list ;
--  dbms_output.put_line(pk_col_list);
end loop;
close c2;

dbms_output.put_line('Constraint   Links (table.col1,col2) To PK column of table '||upper('&1'));
dbms_output.put_line('------------------------------------------------------------------------------------- ');

for q1 in c1 loop
 cname := q1.constraint_name;
 fk_col_list := null;
 open c3 (cname);
 loop 

  fetch c3 into fk_coln;
  exit when c3%notfound;
  fk_col_list := fk_col_list || fk_coln;
 end loop;
 close c3;
 --
 dbms_output.put_line(
   rpad(q1.short_constraint_name,13) ||
   rpad(q1.table_name||'.'||rpad(lower(fk_col_list),30),39)||' '||
   lower(pk_col_list));
end loop;
end;
/
prompt

set verify on feedback on


-- ---------------------------------------------------
-- Section 2:
--
-- produces a list of any tables and columns that are referred to
-- by the table that is passed as a parameter
-- ie. lists all tables,columns that are primary keys based on any 
-- columns in the passed table
--
-- ---------------------------------------------------

set serveroutput on size 150000 
set echo off verify off feedback off


prompt Examining the data dictionary for related tables. Please wait....
prompt

declare

cursor c1 is
select b.constraint_name, b.table_name,
       decode(sign(length(b.constraint_name) -12),
              1,substr(b.constraint_name,1,10)||'..', 
              b.constraint_name) short_constraint_name
from  user_constraints b
where b.table_name = upper('&1')
and   b.constraint_type = 'R';
--
-- fk-dependents
cursor c2 (p_constraint_name varchar2 ) is 
select decode(position,1,null,',')||rtrim(column_name) fk_coln 
from user_cons_columns a 
where a.constraint_name = p_constraint_name
order by position;
--
-- pk-columns
cursor c3 (p_constraint_name varchar2) is 
select a.table_name,decode(position,1,null,',')||rtrim(a.column_name)

pk_coln 
from user_cons_columns a, user_constraints b
where p_constraint_name = b.constraint_name
and   a.constraint_name = b.r_constraint_name
order by position;
--
cname       varchar2(30);
short_cname varchar2(30);
fk_col_list varchar2(90);
pk_col_list varchar2(90);
fk_coln         varchar2(30);
pk_coln         varchar2(30);
pk_table        varchar2(30);
out_line1       varchar2(120); 
--

begin

dbms_output.put_line('Constraint Links columns of To');

dbms_output.put_line('Name '||rpad(upper('&1'),40)||'PK columns of ');
dbms_output.put_line('------------------------------------------------------------------------------------- ');

for q1 in c1 loop
 cname := q1.constraint_name;
 short_cname := q1.short_constraint_name;
 --
 -- get foreign key columns
 fk_col_list := null;
 open c2 (cname);
 loop 
  fetch c2 into fk_coln;
  exit when c2%notfound;
  fk_col_list := fk_col_list || fk_coln;
 end loop;
 close c2;
 fk_col_list := rpad(lower(fk_col_list),40); 
 -- --

 -- -- get primary key columns
 pk_col_list := null;
 open c3 (cname);
 loop 
  fetch c3 into pk_table,pk_coln;
  exit when c3%notfound;
  pk_col_list := pk_col_list || pk_coln;
 end loop;
 close c3;
 pk_col_list := rpad(upper(pk_table)||'.'||lower(pk_col_list),40);
 --
 dbms_output.put_line(
   rpad(q1.short_constraint_name,13) || fk_col_list|| pk_col_list);
end loop;
end;
/
prompt

set verify on feedback on


