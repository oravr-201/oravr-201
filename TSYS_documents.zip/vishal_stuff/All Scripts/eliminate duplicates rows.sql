How does one eliminate duplicates rows from a table?


Choose one of the following queries to identify or remove duplicate rows from 
a table leaving only unique records in the table:
Method 1: 

     DELETE FROM table_name A WHERE ROWID > (
     SELECT min(rowid) FROM table_name B
     WHERE A.key_values = B.key_values);

Method 2: 
    create table table_name2 as select distinct * from table_name1;
    drop table_name1;
    rename table_name2 to table_name1;
    -- Remember to recreate all indexes, constraints, triggers, etc on table... 

Method 3: (thanks to Dennis Gurnick) 
    delete from my_table t1
    where  exists (select 'x' from my_table t2
                    where t2.key_value1 = t1.key_value1
                      and t2.key_value2 = t1.key_value2
                      and t2.rowid      > t1.rowid);

--- One More e.g.. for removing duplicate data
    DELETE from address A
    WHERE (A.name, A.vorname, A.birth) IN
        (SELECT B.name, B.vorname, B.birth FROM address B
          WHERE A.name = B.name AND A.vorname = B.vorname
            AND A.birth = B.birth AND A.rowid > B.rowid);

Note 1: One can eliminate N^2 unnecessary operations by creating an index on the 
        joined fields in the inner loop (no need to loop through the entire table on each 
        pass by a record). This will speed-up the deletion process. 
        
Note 2: If you are comparing NOT-NULL columns, use the NVL function. Remember that 
        NULL is not equal to NULL. This should not be a problem as all key columns should be 
        NOT NULL by definition. 


SELECT TASK_ID, DEVICE_ID FROM TRANSACTION
GROUP BY TASK_ID, DEVICE_ID
HAVING COUNT(*) > 1


9921107362














31373399167



