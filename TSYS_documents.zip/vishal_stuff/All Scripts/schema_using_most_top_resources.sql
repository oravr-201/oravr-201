/*
	which Oracle sessions (which server threads) are consuming the most resources. 
	However, you can use the query in Listing 1 to display the overall CPU usage for 
	each thread (although the CPU usage for background tasks might not be shown). 

*/

SELECT p.spid thread, s.username,
    decode(nvl(p.background,0),1,bg.description,
    s.program ) program,
    ss.value/100 CPU,physical_reads disk_io,
	s.machine,
	s.logon_time 
 FROM 
 	v$process p,
    v$session s,
    v$sesstat ss,
    v$sess_io si,
    v$bgprocess bg
 WHERE 
 	s.paddr=p.addr
 	and ss.sid=s.sid
    and ss.statistic#=12 
    and si.sid=s.sid
    and bg.paddr(+)=p.addr
 ORDER BY ss.value desc;