#! /bin/bash
# This script transfers the tar file to backup server of LV 10.75.245.50

echo "Backup Started `date`"

echo "Transferring Daily_Backup_Files to backup server 10.75.245.50"
#cd /snox6/prod_bck/tarlocation
cd /snox6/prod_bck/bck_scripts
#/home/oracle/prod_bck/capitaloneT2

/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@10.75.15.50
expect "password:"
send "oracle\r"
expect "sftp> "
send "cd /snox6/prod_bck/bck_scripts\r"
expect "sftp> "
send "put *.txt /home/oracle/prod_bck/capitaloneT2\r"
expect "sftp> "
send "exit\r"
SCRIPT_END

echo "Backup Completed `date`"

exit 0

#EOF

