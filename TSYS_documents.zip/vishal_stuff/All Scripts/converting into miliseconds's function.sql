DROP FUNCTION dbo.fn_TimeDiff
GO
CREATE FUNCTION dbo.fn_TimeDiff (@Date1 DATETIME, @Date2 DATETIME, @RtnType VARCHAR(2))
	RETURNS Decimal(18,5)
AS
/**********************************************************************************
Purpose:	Returns the time difference IN a format specific TO the @RtnType. 
Created:	11-9-2004
Author:		Jeff Michelson	Jamin Tech Solutions,Inc. Http://www.JaminTech.com
Parameters	@RtnType - The RETURN format IN standard SQL date-part abbreviations 
			hh 	- Hours
			mi OR n	- minutes
			ss OR s	- seconds
			ms	- milliseconds
**********************************************************************************/


     BEGIN
    	DECLARE @fD1 	DATETIME
    	,	@fD2 	DATETIME
    	,	@RtnVal DECIMAL(18,5)	
    		
    	SET @fD1 = (SELECT CONVERT(DATETIME,"1/1/1980 " + CONVERT(VARCHAR(2),datepart(hh,@Date1)) + ":" + CONVERT(VARCHAR(2),datepart(n,@Date1)) + ":" + CONVERT(VARCHAR(2),datepart(s,@Date1))))
    	SET @fD2 = (SELECT CONVERT(DATETIME,"1/1/1980 " + CONVERT(VARCHAR(2),datepart(hh,@Date2)) + ":" + CONVERT(VARCHAR(2),datepart(n,@Date2)) + ":" + CONVERT(VARCHAR(2),datepart(s,@Date2))))
    	SET @RtnVal = CASE @RtnType
    			WHEN "hh" 	THEN datediff(hh,@fD1,@fD2)
    			WHEN "mi" 	THEN datediff(mi,@fD1,@fD2)
    			WHEN "n"	THEN datediff(n,@fD1,@fD2)
    			WHEN "s"	THEN datediff(s,@fD1,@fD2)
    			WHEN "ss"	THEN datediff(ss,@fD1,@fD2)
    			WHEN "ms"	THEN datediff(ms,@fD1,@fD2)
    		 END	
    	
    	RETURN @RtnVal
 END
GO
