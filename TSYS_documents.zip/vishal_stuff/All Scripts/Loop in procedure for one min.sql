SELECT TO_NUMBER(TO_CHAR(SYSDATE,'MM')) INTO V_minutes_fr FROM dual;
IF V_minutes_fr = 58 OR V_minutes_fr = 59 THEN
   V_minutes_fr := 0 ;
END IF;   
LOOP
	SELECT TO_NUMBER(TO_CHAR(SYSDATE,'MM')) INTO V_minutes_to FROM dual;
    IF V_minutes_to - V_minutes_fr >= 1 THEN
	   EXIT;
	END IF;
END LOOP;
