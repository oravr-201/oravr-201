    +---------------------------------------------------------------+
    |    What are the difference between DDL, DML and DCL commands? |
    +---------------------------------------------------------------+
    
DDL is Data Definition Language statements. 

Some examples: 

    CREATE     -    to create objects in the database 
    ALTER      -    alters the structure of the database 
    DROP       -    delete objects from the database 
    TRUNCATE   -    remove all records from a table, including all spaces 
                    allocated for the records are removed 
    COMMENT    -    add comments to the data dictionary 
    GRANT      -    gives users access privileges to database 
    REVOKE     -    withdraw access privileges given with the GRANT command 


DML is Data Manipulation Language statements. 

Some examples: 

    SELECT     -    retrieve data from the a database 
    INSERT     -    insert data into a table 
    UPDATE     -    updates existing data within a table 
    DELETE     -    deletes all records from a table, the space for the records remain 
    CALL       -    call a PL/SQL or Java subprogram 
    EXPLAIN PLAN-   explain access path to data 
    LOCK TABLE -    control concurrency 
    
    
DCL is Data Control Language statements. 

Some examples: 

    COMMIT     -    save work done 
    SAVEPOINT  -    identify a point in a transaction to which you can later roll back 
    ROLLBACK   -    restore database to original since the last COMMIT 
    SET TRANSACTION-Change transaction options like what rollback segment to use 
