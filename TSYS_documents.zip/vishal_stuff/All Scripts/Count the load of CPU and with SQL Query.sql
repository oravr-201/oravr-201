-- Count the load of CPU and with SQL Query
SELECT unique se.username, se.machine, ROUND (value/100) "CPU Usage", SQL_EXEC_START, LOGON_TIME, sa.DISK_READS DISK_READS,
       sa.SQL_TEXT SQL
FROM v$session se, v$sesstat ss, v$statname st, v$sqlarea sa
WHERE ss.statistic# = st.statistic#
   AND se.sid = ss.SID 
   and se.SQL_ADDRESS = sa.ADDRESS
   and se.SQL_HASH_VALUE = sa.HASH_VALUE
   and se.STATUS = 'ACTIVE'
--   and sw.EVENT != 'client message'
   AND se.username IS NOT NULL
   AND name LIKE  '%CPU used by this session%'
   and username='SYSTEM'
