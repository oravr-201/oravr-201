# Oracle Database 10g: Administration Workshop II
# Oracle Server Technologies - Curriculum Development
#
# ***Training purposes only***
# ***Not appropriate for production use***
#
# This script imports the WORDS table
#
# Written by: Tom Best
imp system/oracle file=/home/oracle/labs/words.dmp full=y log=words.log
