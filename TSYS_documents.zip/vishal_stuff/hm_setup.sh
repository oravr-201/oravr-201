#!/bin/bash

cd /home/oracle/labs

sqlplus / as sysdba <<EOF

set echo on
create table scott.tabjmw(c number) tablespace users;
variable obj number;

begin
select object_id into :obj from dba_objects where owner='SCOTT' and object_name='TABJMW';
end;
/
print obj;
update tab$ set cols=1001 where obj#=:obj;
commit;
EOF

