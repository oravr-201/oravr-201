# /bash/bin

# load oracle profile
. ~/.bash_profile

# User specific environment and startup program
CURRENT_TIMESTAMP=`date +%d%b%Y%H`
BKUP_FOLDER=/backup/oracle/bkups/dpump
EXPDP_DUMPFILE=expdp_${ORACLE_SID}_tsysjira_${CURRENT_TIMESTAMP}.dmp
EXPDP_LOGFILE=expdp_logs_${ORACLE_SID}_tsysjira_${CURRENT_TIMESTAMP}.log
BKUP_TAR_FILE=expdp_${ORACLE_SID}_tsysjira_${CURRENT_TIMESTAMP}.tar.gz

#What day is today, if the day is Monday then remove all 3 days before tar.gz dumpfiles
DAY_TODAY=`date +"%A"`

#Send EMail once rman script is completed
MAIL_FROM=RMAN-DEV-NR-QA-BKUPS
MAIL_TO=ifx-dbalerts@tsys.com
MAIL_CC=""
SUBJECT_LINE="DataPump Export Backup - ${ORACLE_SID} - ${CURRENT_TIMESTAMP}"
EMAIL_BODY=${EXPDP_LOGFILE}
SEND_MAIL_SCRIPT=/home/oracle/cronjobs/perlemail.pl

#schemas to be backup
BKUP_SCHEMA_LIST=TSYSJIRA2

cd ${BKUP_FOLDER}

# On Monday remove all older backups, delete 3 days before all *.tar.gz dumpfiles
if [ $DAY_TODAY = 'Monday' ] ; then
   find ${BKUP_FOLDER}/* -type f -ctime +3 -print|xargs rm -f
fi

expdp / directory=BKUP_DPUMP dumpfile=${EXPDP_DUMPFILE} logfile=${EXPDP_LOGFILE} schemas=${BKUP_SCHEMA_LIST} compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y

# send mail if there are any errors to ifx-dbalerts
#send_mail
#### Check for RMAN/ORA Errors and notify accordingly
EXPDP_LOGS_ERRORS=`egrep "ORA-" ${EXPDP_LOGFILE}`

if [ -z "${EXPDP_LOGS_ERRORS}" ] ; then
   echo "No Errors"
else
   echo "Errors Found !!!!"
   SUBJECT_LINE="Errors found in DataPump export Date - ${CURRENT_TIMESTAMP} - ${ORACLE_SID}"
   perl ${SEND_MAIL_SCRIPT} -f ${MAIL_FROM} -t ${MAIL_TO} -s "${SUBJECT_LINE}" -l "${EMAIL_BODY}"
fi

cd ${BKUP_FOLDER}

tar -cvzf ${BKUP_TAR_FILE} ${EXPDP_DUMPFILE} ${EXPDP_LOGFILE}

rm -f ${EXPDP_DUMPFILE} ${EXPDP_LOGFILE}
