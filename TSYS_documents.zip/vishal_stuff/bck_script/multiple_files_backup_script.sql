#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=/ora1/oracle/OraHome1


mydate=`date +%m%d%y%H`

cd /archive/dba/bkups/

dumps=/archive/dba/bkups/dumps

logs=/archive/dba/bkups/current_logs

previous_logs=/archive/dba/bkups/previous_logs

#removing all prevous logs
rm -rf $previous_logs/*.log

#moving all old logs to prevoius folder
mv $logs/*.log  $previous_logs/

#zip file path
tarpath=$dumps

####################################################################
#function for changing the alert file which contents error of export logfile

alert_status()
{
  if [ "$ALERT_FILE" = "capitalone" ]; then
      alertErr="/archive/dba/bkups/capone_alert.err"
  elif [ "$ALERT_FILE" = "sigueGreystone" ]; then
  	  alertErr="/archive/dba/bkups/sigueGreystone_alert.err"      
  elif [ "$ALERT_FILE" = "transending_rest" ]; then
      alertErr="/archive/dba/bkups/transending_rest_alert.err"
  else
     echo "bad error"
  fi
}


####################################################################
#function for sending if export logfile conetents error else will send success mail

mail_status()
{
MAILSERVER="smtp.ifxsc.com"
MAIL_FROM="prod_bkp@infonox.com"
MAIL_TO="prod_bkp@infonox.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
Subject: $SUBJECT

Hi All,

   `cat ${alertErr}`

Regards,
 RahulC
.
"

echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
######################################################################

#capitalone production schema backup.
exp exportuser/expnox418@1552 file=$dumps/transending/capitalone/exp_capone_$mydate.dmp log=$logs/capone_export_logs.log owner=transcapitalone statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files

$ALERT_FILE="capitalone"

cat $logs/capone_export_logs.log | grep "ORA-" > alert_status
COUNT=`cat alert_status | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail "
    SUBJECT="No Errors in capitaloneDB export logs"
    echo " Successfully completed the backup of capitaloneDB" > alert_status
    mail_status
else
    echo " sending failure"
    SUBJECT="Errors in export log file $logs/capone_export_logs.log for capitaloneDB"
    mail_status
fi

#zip the dump file
tar -cf $tarpath/transending/capitalone/exp_capone_$mydate.tar $dump/transending/capitalone/exp_capone_$mydate.dmp
rm -rf $dump/transending/capitalone/exp_capone_$mydate.dmp

rm -f alert_status
#######################################################################

#sigue and greystone production schema backup.
exp exportuser/expnox418@1552 file=$dumps/transending/sigueGreystone/exp_sigueGreystoneDB_$mydate.dmp log=$logs/sigueGreystoneDB_export_logs.log owner=transsigue,transgreystone statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
$ALERT_FILE="sigueGreystone"
cat $logs/capone_export_logs.log | grep "ORA-" > alert_status
COUNT=`cat alert_status | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail "
    SUBJECT="No Errors in sigueGreystoneDB export logs"
    echo " Successfully completed the backup of sigueGreystoneDB" > alert_status
    mail_status

else
    echo " sending failure"
    SUBJECT="Errors in export log file $logs/capone_export_logs.log for sigueGreystoneDB"
    mail_status
fi

#zip the dump file
tar -cf $tarpath/transending/sigueGreystone/exp_sigueGreystoneDB_$mydate.tar $dumps/transending/sigueGreystone/exp_sigueGreystoneDB_$mydate.dmp
rm -rf $dumps/transending/sigueGreystone/exp_sigueGreystoneDB_$mydate.dmp

rm -f alert_status
#######################################################################

#transending rest production schema backup.
exp exportuser/expnox418@1552 file=$dumps/transending/transending_rest/exp_transending_rest_$mydate.dmp log=$logs/transending_rest_export_logs.log owner=transmsn,transifx,transgca,transfastcap statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
$ALERT_FILE="sigueGreystone"
cat $logs/transending_rest_export_logs.log | grep "ORA-" > alert_status
COUNT=`cat alert_status | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail "
    SUBJECT="No Errors in transending rest schema export logs"
    echo " Successfully completed the backup of transending rest schemas" > alert_status
    mail_status

else
    echo " sending failure"
    SUBJECT="Errors in export log file $logs/transending_rest_export_logs.log for transending rest schemas"
    mail_status
fi

#zip the dump file
tar -cf $tarpath/transending/transending_rest/exp_transending_rest_$mydate.tar $dump/transending/transending_rest/exp_transending_rest_$mydate.dmp
rm -rf $dump/transending/transending_rest/exp_transending_rest_$mydate.dmp

rm -f alert_status
#######################################################################