#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=/ora1/oracle/OraHome1


mydate=`date +%m%d%y%H`

cd /moneris1/bkups

dumps=/moneris1/bkups/dumps

logs=/moneris1/bkups/current_logs

previous_logs=/moneris1/bkups/previous_logs

#removing all prevous logs
rm -f $previous_logs/capone_export_logs.log
rm -f $previous_logs/sigueGreystoneDB_export_logs.log
rm -f $previous_logs/transending_rest_export_logs.log


#moving all old logs to prevoius folde
mv $logs/capone_export_logs.log  $previous_logs/
mv $logs/sigueGreystoneDB_export_logs.log  $previous_logs/
mv $logs/transending_rest_export_logs.log  $previous_logs/


#zip file path
tarpath=$dumps

MAIL_FILE="/moneris1/bkups/mail.txt"

capone_alertErr="/moneris1/bkups/capitaloneDB_alert.err"
sigueGerystone_alertErr="/moneris1/bkups/sigueGerystoneDB_alert.err"
transrest_alertErr="/moneris1/bkups/trans_restDB_alert.err"
snoxwucc_alertErr="/moneris1/bkups/snox_wucc.err"

####################################################################
#function for sending if export logfile conetents error else will send success mail

mail_status()
{
MAILSERVER="smtp.ifxsc.com"
MAIL_FROM="prod_bkp@infonox.com"
MAIL_TO="prod_bkp@infonox.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
Subject: Backup export For Transending Schemas

Hi All,

  `cat ${MAIL_FILE}`

Regards,
 RahulC
.
"

echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
######################################################################

#capitalone production schema backup.
exp exportuser/expnox418@coms file=$dumps/transending/exp_capone_$mydate.dmp log=$logs/capone_export_logs.log owner=transcapitalone statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files

cat $logs/capone_export_logs.log | grep "ORA-" > $capone_alertErr
COUNT=`cat $capone_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for capitaloneDB"
    echo -e  "######################## CapitalOne Schema ####################################\n " > $MAIL_FILE
    echo  " No Errors in CapitalOne schema export logs " >> $MAIL_FILE
    echo  " Successfully completed the backup of CapitalOne schema" >> $MAIL_FILE
else
    echo " sending failure for capitaloneDB"
    echo -e "######################## CapitalOne Schema ####################################\n " > $MAIL_FILE
    echo " Errors in export log file $logs/capone_export_logs.log for capitaloneDB" >> $MAIL_FILE
    cat $capone_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/transending/exp_capone_$mydate.tar.gz $dumps/transending/exp_capone_$mydate.dmp
rm -f $tarpath/transending/exp_capone_$mydate.dmp

rm -f $alertErr
#######################################################################

#sigue and greystone production schema backup.    transgreystone
exp exportuser/expnox418@coms file=$dumps/transending/exp_sigueGreystoneDB_$mydate.dmp log=$logs/sigueGreystoneDB_export_logs.log owner=transsigue statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/capone_export_logs.log | grep "ORA-" > $sigueGerystone_alertErr
COUNT=`cat $sigueGerystone_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for sigue and Gerystone"
    echo -e "\n ######################## TransSigue TransGreyStone schemas ####################\n" >> $MAIL_FILE
    echo " No Errors in sigue and Gerystone schemas export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of sigue and Gerystone schemas" >> $MAIL_FILE
else
    echo " sending failure for sigue and Gerystone"
    echo -e "\n ######################## TransSigue TransGreyStone schemas ####################\n" >> $MAIL_FILE
    echo -e "  Errors in export log file $logs/sigueGreystoneDB_export_logs.log for sigue and Gerystone schemas\n" >> $MAIL_FILE
    cat $sigueGerystone_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/transending/exp_sigueGreystoneDB_$mydate.tar.gz $dumps/transending/exp_sigueGreystoneDB_$mydate.dmp
rm -f $tarpath/transending/exp_sigueGreystoneDB_$mydate.dmp

rm -f $alertErr
#######################################################################

#transending rest production schema backup.
exp exportuser/expnox418@coms file=$dumps/transending/exp_transending_rest_$mydate.dmp log=$logs/transending_rest_export_logs.log owner=transmsn,transifx,transgca,transfastcap statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/transending_rest_export_logs.log | grep "ORA-" > $transrest_alertErr
COUNT=`cat $alensrest_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for  trans_rest"
    echo -e "\n ######################### Transending_rest schemas ############################\n" >> $MAIL_FILE
    echo -e " No Errors in Transending_rest schemas export logs " >> $MAIL_FILE
    echo  " Successfully completed the backup of Transending_rest schemas" >> $MAIL_FILE
else
    echo " sending failure for trans_rest"
    echo -e "\n ######################### Transending_rest schemas ############################\n" >> $MAIL_FILE
    echo -e "Errors in export log file $logs/transending_rest_export_logs.log for Transending_rest schemas\n" >> $MAIL_FILE
    cat $transrest_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/transending/exp_transending_rest_$mydate.tar.gz $dumps/transending/exp_transending_rest_$mydate.dmp
rm -f $tarpath/transending/exp_transending_rest_$mydate.dmp
#######################################################################

#teletechDB production schema backup.
exp exportuser/expnox418@coms file=$dumps/teletechDB/exp_snox_wucc_$mydate.dmp log=$logs/snox_wucc_export_logs.log owner=snox4transnox_wucc statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/snox_wucc_export_logs.log | grep "ORA-" > $snoxwucc_alertErr
COUNT=`cat $snoxwucc_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for  trans_rest"
    echo -e "\n ######################### snox_wucc schemas ############################\n" >> $MAIL_FILE
    echo -e " No Errors in snox_wucc schemas export logs " >> $MAIL_FILE
    echo  " Successfully completed the backup of snox_wucc schemas" >> $MAIL_FILE
else
    echo " sending failure for trans_rest"
    echo -e "\n ######################### snox_wucc schemas ############################\n" >> $MAIL_FILE
    echo -e "Errors in export log file $logs/snox_wucc_export_logs.log for snox_wucc schemas\n" >> $MAIL_FILE
    cat $snoxwucc_alertErr >> $MAIL_FILE
fi

mail_status

#zip the dump file
tar -cvzf $tarpath/teletechDB/exp_snox_wucc_$mydate.tar.gz $dumps/teletechDB/exp_snox_wucc_$mydate.dmp
rm -f $tarpath/teletechDB/exp_snox_wucc_$mydate.dmp
#######################################################################


/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@10.65.25.34
expect "password:"
send "oracle@1534\r"
expect "sftp> "
send "put $tarpath/teletechDB/exp_snox_wucc_$mydate.tar.gz $tarpath/transending/exp_capone_$mydate.tar.gz\r"
send "put $tarpath/transending/exp_sigueGreystoneDB_$mydate.tar.gz /archive/dba/bkups/dumps/transending/sigueGreystone\r"
send "put $tarpath/transending/exp_transending_rest_$mydate.tar.gz /archive/dba/bkups/dumps/transending/transending_rest\r"
send "put $tarpath/teletechDB/exp_snox_wucc_$mydate.tar.gz /archive/dba/bkups/dumps/teletechDB\r"
expect "sftp> "
expect "sftp> "
send "exit\r"
SCRIPT_END



rm -f $tarpath/teletechDB/exp_snox_wucc_$mydate.tar.gz
rm -f $tarpath/teletechDB/*.tar.gz
