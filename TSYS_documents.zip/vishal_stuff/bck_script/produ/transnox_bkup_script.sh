#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=/ora1/oracle/OraHome1


mydate=`date +%m%d%y%H`

cd /ora2/bkups/

dumps=/ora2/bkups/dumps

logs=/ora2/bkups/current_logs

previous_logs=/ora2/bkups/previous_logs

#removing all prevous logs
rm -f $previous_logs/ssa_export_logs.log
rm -f $previous_logs/cnw_export_logs.log
rm -f $previous_logs/wu_wumt_export_logs.log
rm -f $previous_logs/ifastpay_export_logs.log
rm -f $previous_logs/elan_export_logs.log
rm -f $previous_logs/pentel_export_logs.log

#moving all old logs to prevoius folde
mv $logs/ssa_export_logs.log  $previous_logs
mv $logs/cnw_export_logs.log  $previous_logs
mv $logs/wu_wumt_export_logs.log  $previous_logs
mv $logs/ifastpay_export_logs.log  $previous_logs
mv $logs/elan_export_logs.log  $previous_logs
mv $logs/pentel_export_logs.log  $previous_logs

#zip file path
tarpath=$dumps

MAIL_FILE="/ora2/bkups/transnox_mail.txt"

SSA_alertErr="/ora2/bkups/SSA_alert.err"
CNW_alertErr="/ora2/bkups/CNW_alert.err"
WU_WUMT_alertErr="/ora2/bkups/WU_WUMT_alert.err"
iFastPay_Idnox_alertErr="/ora2/bkups/iFastPay_Idnox_alert.err"
ELAN_alertErr="/ora2/bkups/EAN_alert.err"
PEL_alertErr="/ora2/bkups/PEL_alert.err"

####################################################################
#function for sending if export logfile conetents error else will send success mail

mail_status()
{
MAILSERVER="smtp.ifxsc.com"
MAIL_FROM="prod_bkp@infonox.com"
MAIL_TO="prod_bkp@infonox.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
Subject: Backup export For Transnox Schemas

Hi All,

  `cat ${MAIL_FILE}`

Regards,
 RahulC
.
"

echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
######################################################################

#SSA production schema backup.
exp expuser/expbkups@transnoxDB file=$dumps/ssa/exp_SSA_$mydate.dmp log=$logs/SSA_export_logs.log owner=snox4transnox_ssa,transnox_ssa statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files

cat $logs/SSA_export_logs.log | grep "ORA-" > $SSA_alertErr
COUNT=`cat $SSA_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for SSA"
    echo -e "######################## SSA Schema ####################################\n " > $MAIL_FILE
    echo  " No Errors in SSA schema export logs " >> $MAIL_FILE
    echo  " Successfully completed the backup of SSA schema" >> $MAIL_FILE
else
    echo " sending failure for SSA"
    echo -e "######################## SSA Schema ####################################\n " > $MAIL_FILE
    echo " Errors in export log file $logs/SSA_export_logs.log for SSA" >> $MAIL_FILE
    cat $SSA_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/ssa/exp_SSA_$mydate.tar.gz $dumps/ssa/exp_SSA_$mydate.dmp
rm -rf $dumps/ssa/exp_SSA_$mydate.dmp
#######################################################################

#CNW production schema backup.
exp expuser/expbkups@transnoxDB file=$dumps/cnw/exp_cnw_$mydate.dmp log=$logs/cnw_export_logs.log owner=snox4transnox_cnw,transnox_cnw statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/cnw_export_logs.log | grep "ORA-" > $CNW_alertErr
COUNT=`cat $CNW_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for CNW"
    echo -e "\n######################## CNW schema ####################################\n" >> $MAIL_FILE
    echo " No Errors in CNW schema export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of CNW schema" >> $MAIL_FILE
else
    echo " sending failure for CNW"
    echo -e "\n######################## CNW schema ####################################\n" >> $MAIL_FILE
    echo -e "  Errors in export log file $logs/cnw_export_logs.log for CNW schema\n" >> $MAIL_FILE
    cat $CNW_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/cnw/exp_cnw_$mydate.tar.gz $dumps/cnw/exp_cnw_$mydate.dmp
rm -rf $dumps/cnw/exp_cnw_$mydate.dmp
#######################################################################

#WU and WUMT production schemas backup.
exp expuser/expbkups@transnoxDB file=$dumps/wu_wumt/exp_wu_wumt_$mydate.dmp log=$logs/wu_wumt_export_logs.log owner=snox4transnox_wumt,snox4transnox_wu,transnox_wumt,transnox_wu statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/wu_wumt_export_logs.log | grep "ORA-" > $WU_WUMT_alertErr
COUNT=`cat $WU_WUMT_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for WU and WUMT"
    echo -e "\n######################## WU and WUMT schemas ###########################\n" >> $MAIL_FILE
    echo " No Errors in WU and WUMT schemas export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of WU and WUMT schemas" >> $MAIL_FILE
else
    echo " sending failure for WU and WUMT"
    echo -e "\n######################## WU and WUMT schemas ###########################\n" >> $MAIL_FILE
    echo -e "  Errors in export log file $logs/wu_wumt_export_logs.log for WU and WUMT schemas\n" >> $MAIL_FILE
    cat $WU_WUMT_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/wu_wumt/exp_wu_wumt_$mydate.tar.gz $dumps/wu_wumt/exp_wu_wumt_$mydate.dmp
rm -rf $dumps/wu_wumt/exp_wu_wumt_$mydate.dmp
#######################################################################

#iFastPay and IdNox production schemas backup.
exp expuser/expbkups@transnoxDB file=$dumps/ifastpay/exp_ifastpay_$mydate.dmp log=$logs/ifastpay_export_logs.log owner=snox4transnox,transnox_ifastpay,idnox statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/ifastpay_export_logs.log | grep "ORA-" > $iFastPay_Idnox_alertErr
COUNT=`cat $iFastPay_Idnox_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for iFastPay and IdNox "
    echo -e "\n######################## iFastPay and IdNox  schemas ###################\n" >> $MAIL_FILE
    echo " No Errors in iFastPay and IdNox  schemas export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of iFastPay and IdNox  schemas" >> $MAIL_FILE
else
    echo " sending failure for iFastPay and IdNox "
    echo -e "\n######################## iFastPay and IdNox  schemas ###################\n" >> $MAIL_FILE
    echo -e " Errors in export log file $logs/ifastpay_export_logs.log for iFastPay and IdNox schemas\n" >> $MAIL_FILE
    cat $iFastPay_Idnox_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/ifastpay/exp_ifastpay_$mydate.tar.gz $dumps/ifastpay/exp_ifastpay_$mydate.dmp
rm -rf $dumps/ifastpay/exp_ifastpay_$mydate.dmp
#######################################################################

#Elan production schema backup.
exp expuser/expbkups@transnoxDB file=$dumps/elan/exp_elan_$mydate.dmp log=$logs/elan_export_logs.log owner=snox4transnox_ean,transnox_ean statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/elan_export_logs.log | grep "ORA-" > $ELAN_alertErr
COUNT=`cat $ELAN_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for ELAN"
    echo -e "\n######################### ELAN schema ##################################\n" >> $MAIL_FILE
    echo -e " No Errors in ELAN schema export logs " >> $MAIL_FILE
    echo  " Successfully completed the backup of ELAN schema" >> $MAIL_FILE
else
    echo " sending failure for ELAN"
    echo -e "\n######################### ELAN schema ##################################\n" >> $MAIL_FILE
    echo -e "Errors in export log file $logs/elan_export_logs.log for ELAN schema\n" >> $MAIL_FILE
    cat $ELAN_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/elan/exp_elan_$mydate.tar.gz $dumps/elan/exp_elan_$mydate.dmp
rm -rf $dumps/elan/exp_elan_$mydate.dmp
#######################################################################

#Elan production schema backup.
exp expuser/expbkups@transnoxDB file=$dumps/pentel/exp_pentel_$mydate.dmp log=$logs/pentel_export_logs.log owner=snox4transnox_pel,transnox_pel statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/pentel_export_logs.log | grep "ORA-" > $PEL_alertErr
COUNT=`cat $PEL_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for PENTEL"
    echo -e "\n######################### PENTEL schema ##################################\n" >> $MAIL_FILE
    echo -e " No Errors in PENTEL schema export logs " >> $MAIL_FILE
    echo  " Successfully completed the backup of PENTEL schema" >> $MAIL_FILE
else
    echo " sending failure for PENTEL"
    echo -e "\n######################### PENTEL schema ##################################\n" >> $MAIL_FILE
    echo -e "Errors in export log file $logs/pentel_export_logs.log for ELAN schema\n" >> $MAIL_FILE
    cat $PEL_alertErr >> $MAIL_FILE
fi

mail_status

#zip the dump file
tar -cvzf $tarpath/pentel/exp_pentel_$mydate.tar.gz $dumps/pentel/exp_pentel_$mydate.dmp
rm -rf $dumps/pentel/exp_pentel_$mydate.dmp
#######################################################################


/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@10.65.25.34
expect "password:"
send "oracle@1534\r"
expect "sftp> "
send "put $tarpath/ssa/exp_SSA_$mydate.tar.gz /archive/dba/bkups/dumps/transnoxDB/ssa\r"
send "put $tarpath/cnw/exp_cnw_$mydate.tar.gz /archive/dba/bkups/dumps/transnoxDB/cnw\r"
send "put $tarpath/wu_wumt/exp_wu_wumt_$mydate.tar.gz /archive/dba/bkups/dumps/transnoxDB/wu_wumt\r"
send "put $tarpath/ifastpay/exp_ifastpay_$mydate.tar.gz /archive/dba/bkups/dumps/transnoxDB/ifastpay\r"
send "put $tarpath/elan/exp_elan_$mydate.tar.gz /archive/dba/bkups/dumps/transnoxDB/elan\r"
send "put $tarpath/pentel/exp_pentel_$mydate.tar.gz /archive/dba/bkups/dumps/transnoxDB/pentel\r"
expect "sftp> "
expect "sftp> "
send "exit\r"
SCRIPT_END

rm -f $tarpath/ssa/exp_SSA_$mydate.tar.gz
rm -f $tarpath/cnw/exp_cnw_$mydate.tar.gz
rm -f $tarpath/wu_wumt/exp_wu_wumt_$mydate.tar.gz
rm -f $tarpath/ifastpay/exp_ifastpay_$mydate.tar.gz
rm -f $tarpath/elan/exp_elan_$mydate.tar.gz
rm -f $tarpath/pentel/exp_pentel_$mydate.tar.gz

