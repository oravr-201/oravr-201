#!/bin/ksh
#############################################################################
##
## Program:   DBbkup.ksh
##
## Description:
##     This script is run daily to perform a 'FULL' backup.  It uses the
##     oracle Recovery Manager (RMAN) to perform the backup.  This script
##     currently does NOT require a storage manager and backups to a file
##     system.
## Date Modified:
##           Core :
##     Version 1.0:
##
##     Version 1.1: Ray Harkins 07/29/2011
##     Modified Ed's original script to add the <BACKUPDIR>/<SID>/db directory
##     so new database datalist standards can be implemented.
##
##     Version 1.2: Ray Harkins 08/29/2011
##     Modified hot_backup_database(C).sh to include syntax for the creation
##     of a backup controlfile to trace (readable controlfile copy) at the
##     end of the full database backup.
##
##    $Author: $ Ed LeBlanc
##       Date: $
##
##    $Source: $
##     $State: $
##
##  $Revision: $
##
##       $Log: $
##
##
## Exit Status:
##    0 Successful completion without error
##    1 Failure during database/sql access/execution
##    2 Failure during file/non-sql execution
##
## Setup and initialization:
##      Automatic.
##
## Required Variables:
##      The following variables are required to be in the oracle profile.
##    1. ORACLE_SID
##    2. ORACLE_HOME
##    3. PATH
##    4. SEND_ITO_CMD
##    5. WORKDIR
##    6. LOGDIR
##    7. SQLDIR
##    8. MLIST
##    9. PLIST
##   10. HOST
##
## Logging:
##    EXP_{ORACLE_SID}_YYYYMMDDHHMMSS.out file is built in LOGDIR.
##    BKUP_YYYYMMDDHHMMSS.out file is built in LOGDIR.
##
## Parameter(s):
##                 Oracle SID = $1
##
## Requirement(s):
##    scripts
##          /usr/local/bin/alter
##          /usr/local/bin/get_status.sql
##    command
##          mailx         (UNIX mail messaging)
##          sqlplus       (Oracle SQL tool/utility)
##          exp           (Oracle export utility)
##          gzip/compress (UNIX compression utility) - optional
##
##     output
##          /oracle/recovery/dcexports/rcat/EXP_{ORACLE_SID}_YYYYMMDDHHMMSS.dmp
##
#############################################################################

#
SID=$1
ARGS=$#
#

PROGRAM=`basename $0`

#############################################################################
##
## Get required variables if necessary.
##

if [ "x${ORACLE_SID}x" = "xx" ]; then

   . ~oracle/.profile >/dev/null 2>&1
fi

if [ $ARGS -ne 1 ] ;
then
  echo "Usage: ${PROGRAM} <SID>"
  exit 2
fi

# Set Oracle environment for ORACLE_SID
. ${HOME}/scripts/alter $SID >/dev/null 2>&1

if [ ! -r $SCRIPTDIR/ORA${ORACLE_SID}.env ]
then
    echo "File $SCRIPTDIR/ORA${ORACLE_SID}.env ( monitor environment file ) Not found"
    exit 9
else
    . $SCRIPTDIR/ORA${ORACLE_SID}.env
fi

#############################################################################
##
## Override profile variables
##

#PLIST="Ed.LeBlanc@tsysacquiring.com"
#MLIST="Ed.LeBlanc@tsysacquiring.com"

#############################################################################
##
## Set variables specific to this script.
##

DT=`date +%Y%m%d_%H%M%S`
MM=`date +%m`
DD=`date +%d`
YYYY=`date +%Y`
STM=`date +%H%M%S`
LOGFILE="${LOGDIR}/BKUP_${ORACLE_SID}_${MM}${YYYY}.log"
DEBUG_LOG_NO="/dev/null"
DEBUG_LOG_YES="${LOGDIR}/BKdb_${ORACLE_SID}_${DT}.log"
RMAN=$ORACLE_HOME/bin/rman
RCVCAT=rcat
TARGET_CONNECT_STR=/

#
if [ ${IS_LINUX} -eq 1 ]
then
   export ECHO="echo -e "
else
   export ECHO="echo "
fi

#Set this to $DEBUG_LOG_NO or$DEBUG_LOG_YES
export RMAN_LOG_FILE=${DEBUG_LOG_YES}

if [ -f $LOGFILE ]
then
   HEADING=0
else
   HEADING=1
fi
export BACKUP_TYPE=FULL

# Logfile for script
bkfile=${LOGDIR}/BKUP_${ORACLE_SID}_$DT.log

$ECHO Script $0 >> ${DEBUG_LOG_YES}
$ECHO ==== Backup started on `date` ==== >> ${DEBUG_LOG_YES}
$ECHO >> ${DEBUG_LOG_YES}
$ECHO "${SID}-hot" >> ${DEBUG_LOG_YES}
$ECHO " Variables" >> ${DEBUG_LOG_YES}
$ECHO "    HOST                 " ${HOST}>> ${DEBUG_LOG_YES}
$ECHO "    SID                  " ${SID}>> ${DEBUG_LOG_YES}
$ECHO "    BACKUP_TYPE          " ${BACKUP_TYPE}>> ${DEBUG_LOG_YES}
$ECHO "    DBUG LOGFILE         " ${DEBUG_LOG_YES}>> ${DEBUG_LOG_YES}
$ECHO "    BKUP LOGFILE         " ${LOGFILE}>> ${DEBUG_LOG_YES}
$ECHO "    TEMP LOGFILE         " ${bkfile}>> ${DEBUG_LOG_YES}
$ECHO "    BACKUP COMPRESSED    " ${BACKUP_COMPRESSED}>> ${DEBUG_LOG_YES}
$ECHO "    PURGE_ARCH_LOGS_OLDER" ${PURGE_ARCH_LOGS_OLDER}>> ${DEBUG_LOG_YES}


#############################################################################
##
## DB backup.
##
function db_backup
{
#
if [ "${BACKUP_COMPRESSED}" = "YES" ]
then
  $ECHO " Calling `date` hot_database_backupC.sh" >> ${DEBUG_LOG_YES}
  ${HOME}/scripts/backup/hot_database_backupC.sh ${SID} >> ${DEBUG_LOG_YES}
  RC=$?
  $ECHO " Return code `date` hot_database_backupC.sh" ${RC} >> ${DEBUG_LOG_YES}
else
  $ECHO " Calling `date` hot_database_backup.sh" >> ${DEBUG_LOG_YES}
  ${HOME}/scripts/backup/hot_database_backup.sh ${SID} >> ${DEBUG_LOG_YES}
  RC=$?
  $ECHO " Return code `date` hot_database_backup.sh" ${RC} >> ${DEBUG_LOG_YES}
fi

HOT_RC=${RC}

return ${HOT_RC}
}

#############################################################################
##
## RCAT export.
##
function rcat_export
{
#
$ECHO "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" >> ${DEBUG_LOG_YES}
$ECHO " Calling `date` rcat_exp.ksh" >> ${DEBUG_LOG_YES}
${HOME}/scripts/DBexport.sh rcat >/dev/null 2>&1
RC=$?
$ECHO " Return code `date` rcat_exp.sh" ${RC} >> ${DEBUG_LOG_YES}
EXP_RC=${RC}

return ${EXP_RC}
}

#############################################################################
##
## Initiate TSM file backup for DB and RCAT.
##
function file_backup
{
#
$ECHO "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" >> ${DEBUG_LOG_YES}
$ECHO " Backing up to tape Library `date` " >> ${DEBUG_LOG_YES}
#/opt/omni/bin/omnib -datalist dcwctm01_oracledb >> ${DEBUG_LOG_YES}
${TAPE_SM_CMD} ${DB_DATALIST} >> ${DEBUG_LOG_YES}
RC=$?
$ECHO " Return code from backup command `date`" ${RC} >> ${DEBUG_LOG_YES}
TAPE_RC=${RC}

return ${TAPE_RC}
}

#############################################################################
##
## Log and purge old logs.
##
function log_n_purge
{
#
find ${LOGDIR} -name "BKdb_${ORACLE_SID}_*.log" -atime +5 -print -exec rm {} \;
find ${LOGDIR} -name "BKUP_${ORACLE_SID}_*.log" -atime +91 -print -exec rm {} \;

ETM=`date +%H%M%S`
$ECHO ==== Backup completed on `date` ==== >> ${DEBUG_LOG_YES}

if [[ $HEADING -eq 1 ]]
then
  $ECHO "Bkup --Oracle--          ----Time----- Bkup Exp  Tape Del" >> ${LOGFILE}
  $ECHO "Type Sid        Date     Start  End    Code Code Code Code" >> ${LOGFILE}
  $ECHO "==== ========== ======== ====== ====== ==== ==== ==== ====" >> ${LOGFILE}
fi

## Commented out line with value for TAPE_RC (Storage Manager Tape Return Code)
##$ECHO ${BACKUP_TYPE} ${SID} ${MM}${DD}${YYYY} ${STM} ${ETM} ${HOT_RC} ${EXP_RC} ${TAPE_RC} ${DEL_RC} | awk '{printf("%4s %-10s %8s %6s %6s %4s %4s %4s %4s \n", $1, $2, $3, $4, $5, $6, $7, $8, $9)}' >> ${LOGFILE}
$ECHO ${BACKUP_TYPE} ${SID} ${MM}${DD}${YYYY} ${STM} ${ETM} ${HOT_RC} ${EXP_RC} 0 ${DEL_RC} | awk '{printf("%4s %-10s %8s %6s %6s %4s %4s %4s %4s \n", $1, $2, $3, $4, $5, $6, $7, $8, $9)}' >> ${LOGFILE}

}

#############################################################################
##
## Mail_dba
##
function mail_dba
{
#
$ECHO "RMAN RC = ${HOT_RC}\nEXP RC = ${EXP_RC}\nTAPE_RC = ${TAPE_RC}\nDEL_OBSOLETE = ${DEL_RC}" | mailx -s "${MSG}" ${MLIST}
return

}

#############################################################################
##
## Del_Obsolete
##
function del_obsolete
{
#

##$RMAN target ${TARGET_CONNECT_STR} rcvcat rman/rman@${RCVCAT} msglog ${LOGDIR}/rman_del_obsolete-${ORACLE_SID}.log  @${HOME}/scripts/backup/RMANdelobsolete.rcv
$RMAN target ${TARGET_CONNECT_STR} msglog ${LOGDIR}/rman_del_obsolete-${ORACLE_SID}.log  @${HOME}/scripts/backup/RMANdelobsolete.rcv

DEL_RC=$?
return ${DEL_RC}

}

#############################################################################
##
## Logout
##
function logout
{
#

exit ${EXIT_CODE}

}

#############################################################################
##
## MAIN
##
#

## RMAN Backup
#
db_backup
RC=$?
if [ "${RC}" != "0" ]
then
  MSG="${ORACLE_SID}-${HOST} RMAN Backup Failed"
  mail_dba
  exit ${RC}
fi

## RCAT-RMAN delete obsolete
#
del_obsolete
RC=$?
if [ "${RC}" != "0" ]
then
  MSG="${ORACLE_SID}-${HOST} RMAN Delete Obsolete Failed"
  mail_dba
  #exit ${RC}
fi

## RCAT Export
#
##rcat_export
##RC=$?
##if [ "${RC}" != "0" ]
##then
##  MSG="${ORACLE_SID}-${HOST} RCAT Export Failed"
##  mail_dba
  #exit ${RC}
##fi

## Storage Manager backup
#
### No storage manager information provided - RWH 03/02/12
#file_backup
#RC=$?
#if [ "${RC}" != "0" ]
#then
#  MSG="${ORACLE_SID}-${HOST} SM File Backup Failed"
#  mail_dba
#  exit ${RC}
#fi

log_n_purge
exit

