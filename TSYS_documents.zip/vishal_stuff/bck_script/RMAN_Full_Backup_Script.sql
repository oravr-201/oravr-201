#!/bin/sh
# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs

PATH=$PATH:$HOME/bin

export PATH

# Oracle Settings
export HOST=`hostname`
export MLIST=acq-dba@tsys.com
export PLIST=""

ORACLE_HOSTNAME=$HOST; export ORACLE_HOSTNAME
ORACLE_UNQNAME=transittxnaz; export ORACLE_UNQNAME
ORACLE_BASE=/opt/app/oracle; export ORACLE_BASE
GRID_HOME=/opt/app/11.2.0/grid; export GRID_HOME
DB_HOME=$ORACLE_BASE/product/11.2.0/dbhome_1; export DB_HOME
ORACLE_HOME=$DB_HOME; export ORACLE_HOME
ORACLE_SID=transitt1; export ORACLE_SID
ORACLE_TERM=xterm; export ORACLE_TERM
BASE_PATH=/usr/sbin:$PATH; export BASE_PATH
PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/scripts:$BASE_PATH:$GRID_HOME/bin:$GRID_HOME/OPatch; export PATH
export NLS_LANG=AMERICAN_AMERICA.WE8MSWIN1252
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib; export CLASSPATH

# Get the Last Date of Monday, which will be start of week for Full Backup
weekStart_Date=`date -dlast-Monday +"%A%d%b%Y"`
#weekStart_Date=`date -dMonday +"%Y%b%a%d"`

# Get the coming Sunday, which will be End of Week.
weekEnd_Date=`date -dSunday +"%A%d%b%Y"`

# Get the current Date
date_format=`date +%d%b%Y`

weekly_dir=/backup/rmanbackup/transit_RMANBkup_${weekStart_Date}_${weekEnd_Date}

mkdir -p $weekly_dir

cd $weekly_dir

full_bkup_dir=transitt1_Full_rmanbkup_${date_format}

mkdir -p ${full_bkup_dir}

cd ${full_bkup_dir}

backup_path=${weekly_dir}/${full_bkup_dir}

rman  catalog rcat/rcat130@catlog log=${backup_path}/transitt1_rmanbkup_full_${date_format}.log << EOF
connect target rman/rman130;
run
{
   SQL 'alter system switch logfile';
   BACKUP SPFILE FORMAT '${BACKUP_PATH}/transitt1_bkup_spfile_%u_%s_%T.spfbak';
   BACKUP AS COPY CURRENT CONTROLFILE FORMAT '${BACKUP_PATH}/transitt1_cntlfile_%u.ctl';
   ALLOCATE CHANNEL c1 TYPE DISK;
   BACKUP DATABASE FORMAT '${BACKUP_PATH}/transitt1_rmanbkup_%u_%s_%T.bak';
   BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-3' DELETE INPUT FORMAT '${BACKUP_PATH}/transitt1_arclogfs_%u_%s_%T.arcbak';
   RELEASE CHANNEL c1;
   SQL 'alter system switch logfile';
}
resync catalog;
exit
EOF

echo "RMAN Backup of TransIT prod db is done"


BACKUP SPFILE FORMAT '/backup/rmanbackup/spfile_rman.ora'


/recovery/oracle/rmanbackup/RMAN_devracdb1_Bkup_Sunday16Aug2015_Saturday22Aug2015

rman target / log=${BACKUP_PATH}/rmanbkup_${ORACLE_SID}_${DATE_FORMAT}.log << EOF
run
{
   SQL 'alter system switch logfile';
   BACKUP SPFILE FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_spfile_%u_%s_%T.spfbak';
   BACKUP AS COPY CURRENT CONTROLFILE FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_ctrlfile_%u.ctl';
   ALLOCATE CHANNEL c1 TYPE DISK;
   BACKUP DATABASE FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_%u_%s_%T.bak';
   BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-3' DELETE INPUT FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_archlogfs_%u_%s_%T.arcbak';
   RELEASE CHANNEL c1;
   SQL 'alter system switch logfile';
}
exit
EOF


-- level=0 temporary script
rman target / log=/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rman_fullbkup_logs.log << EOF
CONFIGURE RETENTION POLICY TO REDUNDANCY 7;
CONFIGURE SNAPSHOT CONTROLFILE NAME TO '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_devracdb_ctrlfile_%u.ctl'
run
{
   SQL 'alter system switch logfile';
   BACKUP SPFILE FORMAT '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_devracdb1_spfile_%u_%s_%T.spfbak';
   BACKUP AS COPY CURRENT CONTROLFILE FORMAT '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_devracdb1_ctrlfile_%u.ctl';
   ALLOCATE CHANNEL c1 TYPE DISK;
   BACKUP DATABASE FORMAT '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_devracdb1_%u_%s_%T.bak';
   BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-2' DELETE INPUT FORMAT '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_devracdb1_archlogfs_%u_%s_%T.arcbak';
   RELEASE CHANNEL c1;
   SQL 'alter system switch logfile';
}
exit
EOF


alter system set events '10298 trace name context forever, level 32'

rman target / log=/recovery/oracle/rmanbackup/RMAN_devracdb1_Bkup_Sunday16Aug2015_Saturday22Aug2015/test_log.log << EOF
CONFIGURE RETENTION POLICY TO REDUNDANCY 7;
run
{
   SQL 'alter system switch logfile';
   BACKUP SPFILE FORMAT '/recovery/oracle/rmanbackup/RMAN_devracdb1_Bkup_Sunday16Aug2015_Saturday22Aug2015/rmanbackup_devracdb_spfile_%u_%s_%T.spfbak';
   BACKUP AS COPY CURRENT CONTROLFILE FORMAT '/recovery/oracle/rmanbackup/RMAN_devracdb1_Bkup_Sunday16Aug2015_Saturday22Aug2015/rmanbackup_devracdb_ctrlfile_%u.ctl';
   
   SQL 'alter system switch logfile';
}
exit
EOF


BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-3' DELETE INPUT FORMAT '/recovery/oracle/rmanbackup/RMAN_devracdb1_Bkup_Sunday16Aug2015_Saturday22Aug2015/rmanbackup_devracdb_archlogfs_%u_%s_%T.arcbak';



case $BKUP_DAY in
   Sunday)
        echo "Sunday"
        fun_level_0 ;;
   Monday)
        echo "Monday"
        fun_level_1 ;;
   Tuesday)
        echo "Tuesday" 
		fun_level_1 ;;
   Wednesday)
        echo "Wednesday" 
		fun_level_1C ;;
   Thursday)
        echo "Thursday" 
		fun_level_1 ;;
   Friday)
        echo "Friday" 
		fun_level_1 ;;
   Saturday)
        echo "Saturday" 
		fun_level_1C ;;
esac
















ALLOCATE CHANNEL t1 TYPE DISK ;
ALLOCATE CHANNEL t2 TYPE DISK ;
ALLOCATE CHANNEL t3 TYPE DISK ;
ALLOCATE CHANNEL t4 TYPE DISK ;
SET COMMAND ID TO 'RMAN';
SQL 'ALTER SYSTEM SWITCH LOGFILE';
BACKUP 
	SPFILE 
	FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_spfile_%u_%s_%T.spfile';
BACKUP
    CURRENT CONTROLFILE
    FORMAT '+ASMTXNARCHIVE/transittxnaz/autobackup/CF_%d_%u_%s';
BACKUP AS
    COMPRESSED BACKUPSET DATABASE
    FORMAT '${BACKUP_DIR}/${ORACLE_SID}/db/DB_compress_%d_%s_%u';
BACKUP
    ARCHIVELOG ALL NOT BACKED UP 1 TIMES
    FILESPERSET 20
    FORMAT '${BACKUP_DIR}/${ORACLE_SID}/db/ARCH_%d_%s_%u';
    DELETE FORCE NOPROMPT ARCHIVELOG UNTIL TIME '(SYSDATE -${PURGE_ARCH_LOGS_OLDER})' BACKED UP 1 TIMES TO DEVICE TYPE DISK;
RELEASE CHANNEL t1;
RELEASE CHANNEL t2;
RELEASE CHANNEL t3;
RELEASE CHANNEL t4;


--------------------------------------

func_rman_bkup(){
echo
rman_bkup_strg="
rman target / log=${RMAN_BAKUP_LOG} << EOF
CONFIGURE RETENTION POLICY TO REDUNDANCY 3;
run {
ALLOCATE CHANNEL R1 TYPE DISK;
ALLOCATE CHANNEL R2 TYPE DISK;
ALLOCATE CHANNEL R3 TYPE DISK;
ALLOCATE CHANNEL R4 TYPE DISK;
SQL 'ALTER SYSTEM SWITCH LOGFILE';
BACKUP 
	SPFILE 
	FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_spfile_%u_%s_%T';
BACKUP 
	CURRENT CONTROLFILE 
	FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_ctrlfile_%u_%s_%T';
BACKUP AS
	COMPRESSED BACKUPSET DATABASE 
	FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_DBFiles_%u_%s_%T.dbfile';
BACKUP
    ARCHIVELOG ALL NOT BACKED UP 1 TIMES
    FILESPERSET 15
    FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_archlogfiles_%u_%s_%T';
    DELETE FORCE NOPROMPT ARCHIVELOG UNTIL TIME 'SYSDATE-3' BACKED UP 1 TIMES TO DEVICE TYPE DISK;
SQL 'ALTER SYSTEM SWITCH LOGFILE';
RELEASE CHANNEL R1;
RELEASE CHANNEL R2; 
RELEASE CHANNEL R3; 
RELEASE CHANNEL R4;
}
exit 0
EOF
"
echo
}

#if [ $FLAG='FULL_BACKUP_WAS_TAKEN_BEFORE' ]; then

fun_level_1(){
echo
rman target / log=${RMAN_BAKUP_LOG} << EOF
CONFIGURE RETENTION POLICY TO REDUNDANCY 7;
run
{
   ALLOCATE CHANNEL c1 TYPE DISK;
   SQL 'alter system switch logfile';
   BACKUP 
		SPFILE 
		FORMAT '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_${ORACLE_SID}_spfile_%u_%s_%T.spfbak';
   BACKUP 
		CURRENT CONTROLFILE 
		FORMAT '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_${ORACLE_SID}_ctrlfile_%u.ctl';
   BACKUP 
		INCREMENTAL LEVEL 1 DATABASE 
		FORMAT '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_${ORACLE_SID}_%u_%s_%T.bak';
   BACKUP 
		ARCHIVELOG UNTIL TIME 'SYSDATE-3' DELETE INPUT 
		FORMAT '/backups/devdb_bkups/RMAN_devracdb1_Bkup_Sunday23Aug2015_Saturday29Aug2015/rmanbackup_${ORACLE_SID}_archlogfs_%u_%s_%T.arcbak';
   SQL 'alter system switch logfile';
      RELEASE CHANNEL c1;
}
exit
EOF
echo
}

fun_level_1C(){
echo
rman target / log=${RMAN_BAKUP_LOG} << EOF
CONFIGURE RETENTION POLICY TO REDUNDANCY 7;
run
{
   SQL 'alter system switch logfile';
   BACKUP SPFILE FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_spfile_%u_%s_%T.spfbak';
   BACKUP AS COPY CURRENT CONTROLFILE FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_ctrlfile_%u.ctl';
   ALLOCATE CHANNEL c1 TYPE DISK;
   BACKUP INCREMENTAL LEVEL 1 FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_%u_%s_%T.bak' DATABASE;
   BACKUP ARCHIVELOG UNTIL TIME 'SYSDATE-3' DELETE INPUT FORMAT '${BACKUP_PATH}/rmanbackup_${ORACLE_SID}_archlogfs_%u_%s_%T.arcbak';
   RELEASE CHANNEL c1;
   SQL 'alter system switch logfile';
}
EOF
echo
}

