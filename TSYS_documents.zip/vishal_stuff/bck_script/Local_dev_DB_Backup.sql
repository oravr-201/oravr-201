#!/bin/sh

mydate=`date +%m%d%y%H`


exp script

tar script

rm -rf script