#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=$ORACLE_BASE/OraHome1
#export ORACLE_SID=aqprod

#.$ORACLE_BASE/.bash_profile

mydate=`date +%m%d%y%H`

cd /oracle/bkups

dumpfile=/oracle/bkups/dumps

logfilepath=/oracle/bkups/current_logs

ziploc=$dumpfile

previous_logs=/oracle/bkups/previous_logs

# deleting all old logs
rm -rf $previous_logs/stag160_export_log.log
rm -rf $previous_logs/qadev160_export_log.log

mv $logfilepath/stag160_export_log.log $previous_logs
mv $logfilepath/qadev160_export_log.log $previous_logs

############################################################
# exporting stag160 schemas
exp expuser/expstag160@stag file=$dumpfile/stag160_exp_bkup_$mydate.dmp log=$logfilepath/stag160_export_log.log full=y rows=y statistics=none buffer=500000

# exporting qadev160 schemas
exp expuser/expqadev160@qadev file=$dumpfile/qadev160_exp_bkup_$mydate.dmp log=$logfilepath/qadev160_export_log.log full=y rows=y statistics=none buffer=500000

###########################################################
#send mail if there is any ORA- error in import log files for staging DB
###########################################################
#send mail if there is any ORA- error in import log files for staging DB
rm -rf stag160_alert.err
cat $logfilepath/stag160_export_log.log | grep "ORA-" > stag160_alert.err

COUNT=`cat stag160_alert.err | wc -l`

if [ "$COUNT" == "0" ]
then
        echo " No Errors"
else
    mail -s "Errors in Import log file $logfilepath/stag160_export_log.log" rahulc@infonox.com,milindb@infonox.com,Gaurav@infonox.com,narendra@infonox.com < stag160_alert.err
fi

#send mail if there is any ORA- error in import log files for qadev160
rm -rf qadev160_alert.err
cat $logfilepath/qadev160_export_log.log | grep "ORA-" > qadev160_alert.err

COUNT=`cat qadev160_alert.err | wc -l`

if [ "$COUNT" == "0" ]
then
        echo " No Errors"
else
    mail -s "Errors in Import log file $logfilepath/qadev160_export_log.log" rahulc@infonox.com,milindb@infonox.com,Gaurav@infonox.com,narendra@infonox.com < qadev160_alert.err
fi


###########################################################
#tar file for stag160
tar -cf $ziploc/stag160_exp_bkup_$mydate.tar $dumpfile/stag160_exp_bkup_$mydate.dmp

#tar file for qadev160
tar -cf $ziploc/qadev160_exp_bkup_$mydate.tar $dumpfile/qadev160_exp_bkup_$mydate.dmp

rm -rf $dumpfile/stag160_exp_bkup_$mydate.dmp
rm -rf $dumpfile/qadev160_exp_bkup_$mydate.dmp

###########################################################
#moving bkup tar file of stag160 to 192.168.231.84 bkup server  
/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@192.168.231.84
expect "password:"
send "oracle123\r"
expect "sftp> "
send "put $ziploc/stag160_exp_bkup_$mydate.tar /oracle/bkups/stag160\r"
expect "sftp> "
send "exit\r"
SCRIPT_END

exit 0
quit
#EOF


#moving bkup tar file of qadev160 to 192.168.231.84 bkup server  
/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@192.168.231.84
expect "password:"
send "oracle123\r"
expect "sftp> "
send "put $ziploc/qadev160_exp_bkup_$mydate.tar /oracle/bkups/qadev160\r"
expect "sftp> "
send "exit\r"
SCRIPT_END

exit 0
quit
#EOF


###########################################################
# removing the tar file from DB server 192.168.101.160
rm -rm $ziploc/stag160_exp_bkup_$mydate.tar
rm -rm $ziploc/qadev160_exp_bkup_$mydate.tar
