00 09,22 * * * su - oracle -c "sh /archive/dba/bkups/bkup_scripts/exp_bkups_script.sh" >> /archive/dba/bkups/logprod1.log




#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=/ora1/oracle/OraHome1


mydate=`date +%m%d%y%H`

cd /archive/dba/bkups/

dumps=/archive/dba/bkups/dumps

cuurent_logs=/archive/dba/bkups/logs

previous_logs=/archive/dba/bkups/previous_logs

alertErr="/archive/dba/bkups/capitaloneDB_alert.err"

#removing all prevous logs
--rm -rf $previous_logs/*.log

#moving all old logs to prevoius folder
--mv $logs/*.log  $previous_logs/

#zip file path
tarpath=$dumps

rm -f $alertErr

####################################################################
#mail code

mail_status()
{
MAILSERVER="smtp.ifxsc.com"
MAIL_FROM="rahulc@infonox.com"
MAIL_TO="rahulc@infonox.com"
MAIL_CC="milindb@infonox.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
RCPT TO: $MAIL_CC
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
Cc: $MAIL_CC
Subject: $SUBJECT

Hi All,

   `cat ${alertErr}`

Regards,
 RahulC
.
"

echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
######################################################################

#sigue production DB backup.
exp exportuser/expnox418@1552 file=$dumps/transending/capitalone/exp_capone_$mydate.dmp log=$cuurent_logs/capone_import_logs.log owner=transcapitalone statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $cuurent_logs/capone_import_logs.log | grep "ORA-" > $alertErr
COUNT=`cat $alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail "
    SUBJECT="No Errors in capitaloneDB export logs"
    echo " Successfully completed the backup of capitaloneDB" > $alertErr
    mail_status

else
    echo " sending failure"
    SUBJECT="Errors in export log file $cuurent_logs/capone_import_logs.log for capitaloneDB"
    mail_status
fi

#zip the dump file
tar -cf $tarpath/transending/capitalone/exp_capone_$mydate.tar $dump/transending/capitalone/exp_capone_$mydate.dmp
rm -rf $dump/transending/capitalone/exp_capone_$mydate.dmp
#######################################################################

#moving bkup tar file of capitaloneDB bkup on scdb3.ifxsc.com 10.25.245.34 bkups server
/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@10.25.15.34
expect "password:"
send "oracle@1534\r"
expect "sftp> "
send "put /archive/dba/bkups/dumps/capitaloneDB_bkup_$mydate.tar /archive/dba/bkups/dumps/capitaloneDB\r"
send "exit\n"
expect eof
SCRIPT_END

###########################################################
# removing the tar file from DB server 10.25.245.190 capitaloneDB server
rm -rf $tarpath/capitaloneDB_bkup_$mydate.tar
