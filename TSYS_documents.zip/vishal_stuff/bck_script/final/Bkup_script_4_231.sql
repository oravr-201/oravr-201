#!/bin/sh

export ORACLE_BASE=/ora1/oracle
export ORACLE_HOME=$ORACLE_BASE/OraHome1
export ORACLE_SID=aqprod

#.$ORACLE_BASE/.bash_profile

mydate=`date +%m%d%y%H`

cd /qa/bkups

dumpfile=/qa/bkups/dump

logfilepath=/qa/bkups/current_logs

ziploc=$dumpfile

previous_logs=/qa/bkups/previous_logs

# deleting all old logs
rm -rf $previous_logs/stag86_export_log.log
rm -rf $previous_logs/qadb86_export_log.log

mv $logfilepath/stag86_export_log.log $previous_logs
mv $logfilepath/qadb86_export_log.log $previous_logs

############################################################
# exporting stag86 schemas
exp expuser/expnox418@stag86 file=$dumpfile/stag86_exp_bkup_$mydate.dmp log=$logfilepath/stag86_export_log.log full=y rows=y statistics=none buffer=500000

# exporting qadb86 schemas
exp expuser/expnox418@qadb86 file=$dumpfile/qadb86_exp_bkup_$mydate.dmp log=$logfilepath/qadb86_export_log.log full=y rows=y statistics=none buffer=500000

###########################################################
#send mail if there is any ORA- error in import log files for staging DB
rm -rf stag86_alert.err
cat $logfilepath/stag86_export_log.log | grep ORA- > stag86_alert.err

if [ 'cat stag86_alert.err|wc -l' != 0 ]
then
    mail -s "Errors in Import log file $logfilepath/stag86_export_log.log" rahulc@infonox.com,milindb@infonox,Gaurav@infonox.com,narendra@infonox.com < stag86_alert.err
fi

#send mail if there is any ORA- error in import log files for qadb86
rm -rf qadb86_alert.err
cat $logfilepath/qadb86_export_log.log | grep ORA- > qadb86_alert.err

if [ 'cat qadb86_alert.err|wc -l' != 0 ]
then
    mail -s "Errors in Import log file $logfilepath/qadb86_export_log.log" rahulc@infonox.com,milindb@infonox,Gaurav@infonox.com,narendra@infonox.com < qadb86_alert.err
fi

###########################################################
#tar file for stag86
tar -cf $ziploc/stag86_exp_bkup_$mydate.tar $dumpfile/stag86_exp_bkup_$mydate.dmp

#tar file for qadb86
tar -cf $ziploc/qadb86_exp_bkup_$mydate.tar $dumpfile/qadb86_exp_bkup_$mydate.dmp

rm -rf $dumpfile/stag86_exp_bkup_$mydate.dmp
rm -rf $dumpfile/qadb86_exp_bkup_$mydate.dmp

###########################################################
#moving bkup tar file of stag86 to 192.168.231.84 bkup server  
/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@192.168.231.84
expect "password:"
send "oracle123\r"
expect "sftp> "
send "put $ziploc/stag86_exp_bkup_$mydate.tar /qa/bkups/stag86\r"
expect "sftp> "
send "exit\r"
SCRIPT_END

exit 0
quit
#EOF


#moving bkup tar file of qadb86 to 192.168.231.84 bkup server  
/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@192.168.231.84
expect "password:"
send "oracle123\r"
expect "sftp> "
send "put $ziploc/qadb86_exp_bkup_$mydate.tar /qa/bkups/qadb86\r"
expect "sftp> "
send "exit\r"
SCRIPT_END

exit 0
quit
#EOF


###########################################################
# removing the tar file from DB server 192.168.231.86
rm -rm $ziploc/stag86_exp_bkup_$mydate.tar
rm -rm $ziploc/qadb86_exp_bkup_$mydate.tar
