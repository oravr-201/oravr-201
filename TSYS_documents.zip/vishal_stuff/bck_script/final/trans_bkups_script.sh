#!/bin/sh

mydate=`date +%m%d%y%H`

cd /qa/bkups/

dumps=/qa/bkups/dumps

logs=/qa/bkups/current_logs

previous_logs=/qa/bkups/previous_logs

#removing all prevous logs
rm -f $previous_logs/exp_*_logs.log

#moving all old logs to prevoius folder
mv $logs/exp_*_logs.log  $previous_logs/

#zip file path
tarpath=$dumps

MAIL_FILE="/qa/bkups/mail.txt"

qadb86_alertErr="/qa/bkups/qadb86_alert.err"
stag86_alertErr="/qa/bkups/stag86_alert.err"

siguestag_alertErr="/qa/bkups/siguestag_alert.err"

devdb_alertErr="/qa/bkups/devdb_alert.err"

####################################################################
#function for sending if export logfile conetents error else will send success mail

mail_status()
{
MAILSERVER="smtp.ifxsc.com"
MAIL_FROM="rahulc@infonox.com"
MAIL_TO="narendra@infonox.com"
MAIL_CC="milindb@infonox.com"
MAIL_CC="gaurav@infonox.com"
MAIL_CC="srikanth@infonox.com"
MAIL_CC="rahulc@infonox.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
Cc: $MAIL_CC
Cc: $MAIL_CC
Cc: $MAIL_CC
Cc: $MAIL_CC
Subject: Backup export For Transending Schemas

Hi All,

   `cat ${MAIL_FILE}`

Regards,
 RahulC
.
"

echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
######################################################################

#stag86.
exp expuser/expstag86@stag86 file=$dumps/stag86/exp_stag86_$mydate.dmp log=$logs/exp_stag86_logs.log statistics=none full=y rows=y buffer=500000

#sending mail if there is any ORA- error in export log files

cat $logs/$logs/exp_stag86_logs.log | grep "ORA-" > $stag86_alertErr
COUNT=`cat $stag86_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for stag86"
    echo "######################## stag 231.86 DB #################################### " > $MAIL_FILE
    echo -e " \n No Errors in stag 231.86 DB export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of stag 231.86 DB" >> $MAIL_FILE
else
    echo " sending failure for stag 231.86 DB"
    echo "######################## stag 231.86 DB #################################### " > $MAIL_FILE
    echo -e " \n Errors in export log file $logs/exp_stag86_logs.log for stag 231.86 DB \n" >> $MAIL_FILE
    cat $stag86_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cf $tarpath/stag86/exp_stag86_$mydate.tar $dumps/stag86/exp_stag86_$mydate.dmp
rm -rf $dump/stag86/exp_stag86_$mydate..dmp

#######################################################################

#qadb86 .
exp expuser/expqadb86@qadb86 file=$dumps/qadb86/exp_qadb86_$mydate.dmp log=$logs/exp_qadb86_logs.log owner=transsigue,transgreystone statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/exp_qadb86_logs.log | grep "ORA-" > $qadb86_alertErr
COUNT=`cat $qadb86_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for qadb 231.86 DB"
    echo " ######################## qadb 231.86 DB #################### " >> $MAIL_FILE
    echo -e " \n No Errors in qadb 231.86 DB export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of qadb 231.86 DB" >> $MAIL_FILE
else
    echo " sending failure for sigue and Gerystone"
    echo " ######################## TransSigue TransGreyStone schemas #################### " >> $MAIL_FILE
    echo -e " \n Errors in export log file $logs/exp_qadb86_logs.log for qadb 231.86 DB \n" >> $MAIL_FILE
    cat $qadb86_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cf $tarpath/qadb86/exp_qadb86_$mydate.tar $dumps/qadb86/exp_qadb86_$mydate.dmp
rm -rf $dumps/qadb86/exp_qadb86_$mydate.dmp

#######################################################################

#devdb bkups.
exp expuser/expdevdb@devdb file=$dumps/devdb/exp_devdb_$mydate.dmp log=$logs/exp_devdb_logs.log owner=transmsn,transifx,transgca,transfastcap statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/exp_devdb_logs.log | grep "ORA-" > $devdb_alertErr
COUNT=`cat $devdb_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for Devdb database"
    echo " ######################### Devdb database ############################ " >> $MAIL_FILE
    echo -e " \n No Errors in Devdb database export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of Devdb database" >> $MAIL_FILE
else
    echo " sending failure for Devdb database"
    echo " ######################### Devdb database ############################ " >> $MAIL_FILE
    echo -e " \n Errors in export log file $logs/exp_devdb_logs.log for Devdb database \n" >> $MAIL_FILE
    cat $devdb_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cf $tarpath/transending/exp_devdb_$mydate.tar $dumps/devdb/exp_devdb_$mydate.dmp
rm -rf $dumps/devdb/exp_devdb_$mydate.dmp

#######################################################################

#sigue stag bkups.
exp expuser/expsiguestag@sigue_stag file=$dumps/sigue_stag/exp_siguestag_$mydate.dmp log=$logs/exp_siguestag_logs.log owner=snox4transnox,transnox_sigue statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/exp_siguestag_logs.log | grep "ORA-" > $siguestag_alertErr
COUNT=`cat $siguestag_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for sigue stag DB"
    echo " ######################### sigue stag DB ############################ " >> $MAIL_FILE
    echo -e " \n No Errors in sigue stag DB export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of sigue stag DB" >> $MAIL_FILE
else
    echo " sending failure for sigue stag DB"
    echo " ######################### sigue stag DB ############################ " >> $MAIL_FILE
    echo -e " \n Errors in export log file $logs/exp_siguestag_logs.log for sigue stag DB \n" >> $MAIL_FILE
    cat $devdb_alertErr >> $MAIL_FILE
fi

mail_status

#zip the dump file
tar -cf $tarpath/sigue_stag/exp_siguestag_$mydate.tar $dumps/sigue_stag/exp_siguestag_$mydate.dmp
rm -rf $dumps/sigue_stag/exp_siguestag_$mydate.dmp

#######################################################################