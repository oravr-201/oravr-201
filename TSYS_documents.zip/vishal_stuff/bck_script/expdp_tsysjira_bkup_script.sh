# /bash/bin

# load oracle profile
. ~/.bash_profile

# User specific environment and startup program
CURRENT_TIMESTAMP=`date +%d%b%Y`
BKUP_FOLDER=/backup/oracle/bkups/dpump
EXPDP_DUMPFILE=expdp_${ORACLE_SID}_${CURRENT_TIMESTAMP}.dmp
EXPDP_LOGFILE=expdp_logs_${ORACLE_SID}_${CURRENT_TIMESTAMP}.log
BKUP_TAR_FILE=expdp_${ORACLE_SID}_${CURRENT_TIMESTAMP}.tar.gz

#Send EMail once rman script is completed
MAIL_FROM=RMAN-DEV-NR-QA-BKUPS
MAIL_TO=ifx-dbalerts@tsys.com
MAIL_CC=""
SUBJECT_LINE="DataPump Export Backup - ${ORACLE_SID} - ${CURRENT_TIMESTAMP}"
EMAIL_BODY=${EXPDP_LOGFILE}
SEND_MAIL_SCRIPT=/home/oracle/cronjobs/perlemail.pl

#schemas to be backup 
BKUP_SCHEMA_LIST=TSYSJIRA

bcd ${BKUP_FOLDER}

#expdp / directory=BKUP_DPUMP dumpfile=${EXPDP_DUMPFILE} logfile=${EXPDP_LOGFILE} exclude=statistics,table:\"like \'SN_TEMP%\'\",table:\"like \'SC_TEMP%\'\" exclude=SCHEMA:\"IN \(\'ANONYMOUS\',\'APEX_030200\',\'APEX_PUBLIC_USER\',\'APPQOSSYS\',\'CTXSYS\',\'DBSNMP\',\'DIP\',\'EXFSYS\',\'FLOWS_FILES\',\'MDSYS\',\'MGMT_VIEW\',\'OLAPSYS\',\'OPS$ORACLE\',\'ORACLE_OCM\',\'ORDDATA\',\'ORDPLUGINS\',\'ORDSYS\',\'OUTLN\',\'OWBSYS\',\'OWBSYS_AUDIT\',\'SCOTT\',\'SI_INFORMTN_SCHEMA\',\'SPATIAL_CSW_ADMIN_USR\',\'SPATIAL_WFS_ADMIN_USR\',\'SYS\',\'SYSMAN\',\'SYSTEM\',\'WMSYS\',\'XDB\',\'XS$NULL\'\)\" full=y compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y
expdp / directory=BKUP_DPUMP dumpfile=${EXPDP_DUMPFILE} logfile=${EXPDP_LOGFILE} schemas=${BKUP_SCHEMA_LIST} compression=all content=all data_options=xml_clobs REUSE_DUMPFILES=y

# send mail if there are any errors to ifx-dbalerts
#send_mail
#### Check for RMAN/ORA Errors and notify accordingly
EXPDP_LOGS_ERRORS=`egrep "ORA-" ${EXPDP_LOGFILE}`

if [ -z "${EXPDP_LOGS_ERRORS}" ] ; then
   echo "No Errors"
else
   echo "Errors Found !!!!"
   SUBJECT_LINE="Errors found in DataPump export Date - ${CURRENT_TIMESTAMP} - ${ORACLE_SID}"
   perl ${SEND_MAIL_SCRIPT} -f ${MAIL_FROM} -t ${MAIL_TO} -s "${SUBJECT_LINE}" -l "${EMAIL_BODY}"
fi

cd ${BKUP_FOLDER}

tar -cvzf ${BKUP_TAR_FILE} ${EXPDP_DUMPFILE} ${EXPDP_LOGFILE}

