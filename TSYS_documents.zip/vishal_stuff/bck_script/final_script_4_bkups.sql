#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=/ora1/oracle/OraHome1


mydate=`date +%m%d%y%H`

cd /archive/bkups/

dumps=/archive/bkups/dumps

logs=/archive/bkups/logs

previous_logs=/archive/bkups/previous_logs

alertErr="/archive/bkups/snox_gloryWM_alert.err"

#removing all prevous logs
--rm -rf $previous_logs/*.log

#moving all old logs to prevoius folder
--mv $logs/*.log  $previous_logs/

#zip file path
tarpath=$dumps

rm -f $alertErr

####################################################################
#mail code

mail_status()
{
MAILSERVER="smtp.ifxsc.com"
MAIL_FROM="ifx-dbpune@tsys.com"
MAIL_TO="rchaudhari@tsys.com"
MAIL_CC="rchaudhari@tsys.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
RCPT TO: $MAIL_CC
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
Cc: $MAIL_CC
Subject: $SUBJECT

Hi All,

    `cat ${alertErr}`

Regards,
 RahulC
.
"
echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
######################################################################

#Snox4Transnox, Glory and WM production DB schemas backup.
#exp expuser/expbkups@7567 file=$dumps/snox_gloryWM/snox_gloryWM_bkup_$mydate.dmp log=$logs/snox_gloryWM_import_logs.log owner=snox4transnox_wucc buffer=500000 statistics=none

#sending mail if there is any ORA- error in import log files
cat $logs/snox_gloryWM_import_logs.log | grep "ORA-" > $alertErr

#counting the words in alert file if it is grater then 0 it
# means there is an error in import logfile
COUNT=`cat $alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
   echo " Success Mail "
   SUBJECT="No Errors in schemas Snox4Transnox, Glory and WM import logs"
   echo " Successfully done the import for Snox4Transnox, Glory and WM schemas" > $alertErr
   mail_status

else
   echo " sending failure"
   SUBJECT="Errors in import log file $logs/snox_gloryWM_import_logs.log for Snox4Transnox, Glory and WM schemas"
   mail_status
fi

#zip the dump file
tar -cf $tarpath/snox_gloryWM/snox_gloryWM_bkup_$mydate.tar $dumps/snox_gloryWM/snox_gloryWM_bkup_$mydate.dmp
rm -rf $dumps/snox_gloryWM/snox_gloryWM_bkup_$mydate.dmp
######################################################################
