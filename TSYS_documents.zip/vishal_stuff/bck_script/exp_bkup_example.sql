#!/bin/bash

#exp system/sys7534 file=det_2004.dmp log=det_2004_log.log statistics=none tables=transgca_Det.GCA_DET_DATA_2004_1,transgca_Det.GCA_DET_DATA_2004_2,transgca_Det.GCA_DET_DATA_2004_3,transgca_Det.GCA_DET_DATA_2004_4,transgca_Det.GCA_DET_DATA_2004_5,transgca_Det.GCA_DET_DATA_2004_6,transgca_Det.GCA_DET_DATA_2004_7,transgca_Det.GCA_DET_DATA_2004_8,transgca_Det.GCA_DET_DATA_2004_9 transgca_Det.GCA_DET_DATA_2004_10,transgca_Det.GCA_DET_DATA_2004_11,transgca_Det.GCA_DET_DATA_2004_12

#tar -cvzf det_2004.tar.gz det_2004.dmp


/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@10.50.15.53
expect "password:"
send "mpty%kow\r"
expect "sftp> "
send "put /archive/det_2004.tar.gz /moneris2/oracle/transgca_stuff/\r"
expect "sftp> "
expect "sftp> "
send "exit\r"
SCRIPT_END



/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@10.100.126.61
expect "password:"
send "mpty%kow\r"
expect "sftp> "
send "get /recovery/oracle/dpump/expdp_uat_migration_11oct2015.tar.gz\r"
expect "sftp> "
send "exit\r"
SCRIPT_END



###########################################################
#moving bkup tar file of stag160 to 192.168.231.84 bkup server  
/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@192.168.231.84
expect "password:"
send "oracle123\r"
expect "sftp> "
send "put /oracle/bkups/dump/exp_dev_bkups_$mydate.tar /oracle/bkups/stag160\r"
expect "sftp> "
send "put /oracle/bkups/dump/exp_trans_bkups_$mydate.tar /oracle/bkups/qadev160\r"
expect "sftp> "
send "exit\r"
SCRIPT_END