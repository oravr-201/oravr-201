
#!/bin/sh




#                  +--------------------------------------------------------------------+
#                  |       Structural Backup script for DEV / SSK / TRANS DB            |
#                  |                                                                    |
# 		   |    This script is daily backup script which will take structural   |
# 		   | backup of DEV / SSK / TRANS Database one by one.                   |
#  		   |                                                                    |
# 	 	   | Date of Script Creation :- 22/06/2006                              |
#  		   | Created by :- DB Team Pune                                         |
#  		   |                                                                    |
#  		   +--------------------------------------------------------------------+

      


filepath=/data/oracle92/oracledb_backup/str_bck

mydate=`date +%m_%d_%Y_%H_%M_%S`



cp -rf /data/oracle92/oracledb_backup/str_bck/dump/*.* /data/oracle92/oracledb_backup/str_bck/previous/


rm -rf /data/oracle92/oracledb_backup/str_bck/dump/*.*



exp system/manager@dev file=$filepath/dump/dev_str_bck_$mydate.dmp  log=$filepath/logs/dev_str_bck_logs.log full=y rows=n statistics=none

exp system/manager@ssk file=$filepath/dump/ssk_str_bck_$mydate.dmp  log=$filepath/logs/ssk_str_bck_logs.log full=y rows=n statistics=none


exp system/manager@trans file=$filepath/dump/trans_str_bck_$mydate.dmp  log=$filepath/logs/trans_str_bck_logs.log  full=y rows=n statistics=none




