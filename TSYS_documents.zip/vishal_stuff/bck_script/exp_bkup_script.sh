#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=$ORACLE_BASE/OraHome1

#.$ORACLE_BASE/.bash_profile

mydate=`date +%m%d%y%H`

cd /oracle/bkups

dumpfile=/data/oracle92/oracle_backup/full_bck

logfilepath=$dumpfile/logs

ziploc=$dumpfile

mail_msg=/oracle/bkups/mailmsg

previous_logs=/oracle/bkups/previous_logs

# deleting all old logs
rm -rf $previous_logs/exp_dev_bkups_log.log
rm -rf $previous_logs/exp_trans_bkups_log.log

mv $logfilepath/exp_dev_bkups_log.log $previous_logs
mv $logfilepath/exp_trans_bkups_log.log $previous_logs

############################################################
# exporting stag160 schemas
exp expuser/expdev@dev file=$dumpfile/exp_dev_bkups_$mydate.dmp log=$logfilepath/exp_dev_bkups_log.log full=y rows=y statistics=none buffer=500000

# exporting qadev160 schemas
exp expuser/exptrans@trans file=$dumpfile/exp_trans_bkups_$mydate.dmp log=$logfilepath/exp_trans_bkups_log.log full=y rows=y statistics=none buffer=500000

###########################################################
#send mail if there is any ORA- error in import log files for staging DB
rm -rf stag160_alert.err
cat $logfilepath/exp_dev_bkups_log.log | grep "ORA-" > stag160_alert.err

COUNT=`cat stag160_alert.err | wc -l`

if [ "$COUNT" -eq "0" ]
then
        echo " No Errors"
   mail -s "Export backup completed for stag on 231.160 DB" rahulc@infonox.com,milindb@infonox.com,Gaurav@infonox.com,narendra@infonox.com < $mail_msg/stag160.txt
else
    mail -s "Errors in Import log file $logfilepath/exp_dev_bkups_log.log" rahulc@infonox.com,milindb@infonox.com,Gaurav@infonox.com,narendra@infonox.com < stag160_alert.err
fi

#send mail if there is any ORA- error in import log files for qadev160
rm -rf qadev160_alert.err
cat $logfilepath/exp_trans_bkups_log.log | grep "ORA-" > qadev160_alert.err

COUNT=`cat qadev160_alert.err | wc -l`

if [ "$COUNT" -eq "0" ]
then
        echo " No Errors"
    mail -s "Export backup completed for qadev on 231.160 DB server" rahulc@infonox.com,milindb@infonox.com,Gaurav@infonox.com,narendra@infonox.com < $mail_msg/qadev160.txt
else
    mail -s "Errors in Import log file $logfilepath/exp_trans_bkups_log.log" rahulc@infonox.com,milindb@infonox.com,Gaurav@infonox.com,narendra@infonox.com < qadev160_alert.err
fi


###########################################################
#tar file for stag160
tar -cf $ziploc/exp_dev_bkups_$mydate.tar $dumpfile/exp_dev_bkups_$mydate.dmp

#tar file for qadev160
tar -cf $ziploc/exp_trans_bkups_$mydate.tar $dumpfile/exp_trans_bkups_$mydate.dmp

rm -rf $dumpfile/exp_dev_bkups_$mydate.dmp
rm -rf $dumpfile/exp_trans_bkups_$mydate.dmp

###########################################################
#moving bkup tar file of stag160 to 192.168.231.84 bkup server  
/usr/bin/expect <<SCRIPT_END
set timeout -1
spawn sftp oracle@192.168.231.84
expect "password:"
send "oracle123\r"
expect "sftp> "
send "put /oracle/bkups/dump/exp_dev_bkups_$mydate.tar /oracle/bkups/stag160\r"
expect "sftp> "
send "put /oracle/bkups/dump/exp_trans_bkups_$mydate.tar /oracle/bkups/qadev160\r"
expect "sftp> "
send "exit\r"
SCRIPT_END

###########################################################
# removing the tar file from DB server 192.168.231.160
rm -rm $ziploc/exp_dev_bkups_$mydate.tar
rm -rm $ziploc/exp_trans_bkups_$mydate.tar

rm -rf /oracle/bkups/stag160_alert.err
rm -rf /oracle/bkups/qadev160_alert.err
