
#!/bin/sh




#                  +--------------------------------------------------------------------+
#                  |       Full Backup script for DEV / SSK / TRANS DB                  |
#                  |                                                                    |
# 		   |    This script is daily backup script which will take full         |
# 		   | backup of DEV / SSK / TRANS Databases one by one.                  |
#  		   |                                                                    |
# 	 	   | Date of Script Creation :- 22/06/2006                              |
#  		   | Created by :- DB Team Pune                                         |
#  		   |                                                                    |
#  		   +--------------------------------------------------------------------+


      

filepath=/data/oracle92/oracledb_backup/full_bck

mydate=`date +%m_%d_%Y_%H_%M_%S`




cp -rf /data/oracle92/oracledb_backup/full_bck/dump/*.* /data/oracle92/oracledb_backup/full_bck/previous/


rm -rf /data/oracle92/oracledb_backup/full_bck/dump/*.*



exp system/manager@dev file=$filepath/dump/dev_full_bck_$mydate.dmp  log=$filepath/logs/dev_full_bck_logs.log full=y rows=y statistics=none


exp system/manager@ssk file=$filepath/dump/ssk_full_bck_$mydate.dmp  log=$filepath/logs/ssk_full_logs.log full=y rows=y statistics=none


exp system/manager@trans file=$filepath/dump/trans_full_bck_$mydate.dmp  log=$filepath/logs/trans_full_bck_logs.log  full=y rows=y statistics=none


