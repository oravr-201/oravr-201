﻿#!/bin/ksh

##############################################################################
# Purposes - a script to manually run backups
##############################################################################
#
##############################################################################
# First a few environment variables
##############################################################################

export TMPYEAR=`date +%Y`
export TMPDATE=`date +%Y%m%d`
export TMPTIME=`date +%H%M%S`

if [ `date +%m` -eq 1 ]
     then
          if [ `date +%d` -lt 3 ]
               then export TMPYEAR=`expr $TMPYEAR - 1`
          fi
fi
export BASEDIR=/home/oracle
export CMDDIR=$BASEDIR/scripts
export ENVDIR=$BASEDIR/env
export SQLDIR=$BASEDIR/sql
export TMP_ADDR=none


# Now we will look at setting up some OS specific items

export OS=`uname`
if [ "$OS" = "HP-UX" ]
     then AWK=/usr/bin/awk
          ORATAB=/etc/oratab
elif [ "$OS" = "Linux" ]
     then AWK=/bin/gawk
          MAILX=/bin/mail
          ORATAB=/etc/oratab
else
          AWK=/usr/bin/nawk
          ORATAB=/var/opt/oracle/oratab
          MAILX=/usr/bin/mailx
fi

##############################################################################
# Going to put in the options here
##############################################################################
# -i = instance name
# -t = Type of backup ((f)ull, (d)atafiles, (a)rchivelogs) (default = full)
# -a = email address for report delivery
# -r = Set retention days to store on disk (default 3)
# -c = Try to compress old backups (note additional checking is done as well) (default=y)
# -g = Compress using gzip after backup finishes (default is 0)

export TMP_TYPE=f
export TMP_RET=3
export TMP_COMP_ASK=Y
export GZFILES=0

while getopts ":i:t:a:r:c:g:" opt ; do
     case $opt in
          a ) export TMP_ADDR=$OPTARG ;;
          i ) export TMP_ENV=$OPTARG
              if [[ -r $ENVDIR/$TMP_ENV ]]
                   then . $ENVDIR/$TMP_ENV
              else echo "\n\t Environment file not found or invalid.  Trying to use $ENVDIR/$TMP_ENV"
                   echo "Please use $0 -? for help\n\n"
                   exit 1
              fi ;;
          r ) export TMP_RET=$OPTARG
              if [[ $TMP_RET != [0-9] ]]
                   then echo "\n\t Must enter a number from 1-9 only "
                        echo "\t Please use $0 -? for more help\n\n"
                        exit 1
              fi ;;
          t ) export TMP_TYPE=$OPTARG
              if [[ $TMP_TYPE != [FfDdAa] ]]
                   then echo "\n\n"
                        echo "\t You selected option $TMP_TYPE"
                        echo "\t You must only choose f, d, or a"
                        echo "\t Please use $0 -? for more help\n\n"
                        exit 1
              fi ;;
          c ) export TMP_COMP_ASK=$OPTARG ;;
          g ) export GZFILES=$OPTARG
              if [[ $GZFILES != [0-9] ]]
                   then echo "\n\t Value must be numeric.  Defaulting to 0 (no compress)"
                        export GZFILES=0
              fi ;;
          * ) echo "\n\n"
              echo "\t Here is your handy little help file.  Please observe\n"
              echo "\t Usage : $0 -i <envfile> [-a email][-r number][-t f|d|a][-c y|n] "
              echo "\t  where"
              echo "\t       -a = email address to send report to"
              echo "\t       -i = Valid environment file.  Must reside in $ENVDIR"
              echo "\t       -t = (f)ull, or (d)atafile, or (a)rchivelog - choose only one"
              echo "\t       -r = Number of days to retain old backups (default 3)"
              echo "\t       -c = Compress old bkups (permissions will be checked) Default Y"
              echo "\t       -g = Compress using gzip for current backup (default is 0 for no gzip)"
              echo "\n\n"
              exit 1 ;;
     esac
done
shift $(($OPTIND - 1))

if [[ -z $TMP_ENV ]]
     then echo "\n\n\t No Environment file dpecified - FATAL ERROR - Must abort"
          echo "\t Please use $0 -? for help\n\n"
          exit 1
fi


export ARCHFILE=`date +%Y%m%d_%H%M%S`_${ORACLE_UNQNAME}_manual_archive.log
export BKUPDIR=/opt/oracle/backup/${ORACLE_UNQNAME}
export DATADIR=$BKUPDIR/$TMPDATE
export RCVFILE=$DATADIR/${TMPDATE}_${TMPTIME}_${ORACLE_UNQNAME}_temp_bkup.rcv
export RESTORE_FILE=$BKUPDIR/$TMPDATE/${ORACLE_UNQNAME}_level_0_restore.rcv
export LOGDIR=${BASEDIR}/logs/${ORACLE_UNQNAME}
export RMANLOG=${BASEDIR}/logs/${ORACLE_UNQNAME}

#####################################################################################
# Now to modify the RCV file to specify a date in the backup file names
#####################################################################################

export TMP_SQL=/tmp/${ORACLE_UNQNAME}_rmantmp.sql
export TMP_DTE=/tmp/${ORACLE_UNQNAME}_tmpdate.lst
export ARC_CHK=/tmp/${ORACLE_UNQNAME}_arclog_count.lst
export DBID_VAL=/tmp/${ORACLE_UNQNAME}_dbid_count.lst
export TMPTBL=/tmp/${ORACLE_UNQNAME}_tmptbl.lst
mkdir -p ${BKUPDIR}

echo "set heading off" > $TMP_SQL
echo "set feedback off" >> $TMP_SQL
echo "alter session set NLS_DATE_FORMAT = 'YYYYMMDD';" >> $TMP_SQL
echo "spool $TMP_DTE"  >> $TMP_SQL
echo "select trim(sysdate - $TMP_RET) from dual;" >> $TMP_SQL
echo "spool off"  >> $TMP_SQL
echo "spool $ARC_CHK" >> $TMP_SQL
echo "select count(*) from v\$archived_log where completion_time < sysdate - 1 and deleted = 'NO';" >> $TMP_SQL
echo "spool off" >> $TMP_SQL
echo "spool $DBID_VAL" >> $TMP_SQL
echo "select dbid from v\$database;" >> $TMP_SQL
echo "spool off" >> $TMP_SQL
echo "spool $TMPTBL" >> $TMP_SQL
echo "select a.name||'|'||b.name||'|'||bytes/(1024*1024)||'|junk'||'|' from v\$tablespace a, v\$tempfile b where b.ts# = a.ts#;" >> $TMP_SQL
echo "spool off;"
echo "exit" >> $TMP_SQL

sqlplus -s "/ as sysdba" @$TMP_SQL

DELDATE=`grep $TMPYEAR $TMP_DTE`
export ARC_COUNT=`$AWK ' NF > 0 {print $1}' $ARC_CHK`
export DBID=`$AWK ' NF > 0 {print $1}' $DBID_VAL`


cd $BKUPDIR
export DELDIR=`ls -ltr|$AWK 'NF==9 && /^d/ {print $NF}'`
for deldir in $DELDIR ; do
     if [ $deldir -lt $DELDATE ]
          then echo "About to delete directory $BKUPDIR/$deldir" >> $RMANLOG/$ARCHFILE
               rm -Rf $BKUPDIR/$deldir >> $RMANLOG/$ARCHFILE
     fi
done


if [[ -d $DATADIR ]]
     then continue
else
     mkdir -p $DATADIR
     chmod -R 777 $DATADIR 2>/dev/null
fi

#####################################################################################
# Now to copy the init files, pw files, and env files for the instance
#####################################################################################
sqlplus -s "/ as sysdba" << EOF
create pfile='$DATADIR/init${ORACLE_UNQNAME}.ora.${TMPDATE}' from spfile;
EOF

cp -p ${ORACLE_HOME}/dbs/*uatrpt* $DATADIR
cp -p $ENVDIR/$TMP_ENV $DATADIR

#####################################################################################
# Now to create the sql script to recreate temp files since they do not get backed up
# and we get all the temp spaces from dbms_metadata.get_ddl to extract the info
# and using an anonymous block
#####################################################################################

sqlplus -s "/ as sysdba" << EOF
set heading off;
set feedback off;
set serveroutput on;
spool /tmp/tmp_tblspace_list_${ORACLE_UNQNAME}.out
declare c clob;
begin
     for t in ( select tablespace_name from dba_tablespaces where contents = 'TEMPORARY')
     loop
          select dbms_metadata.get_ddl('TABLESPACE', t.tablespace_name) into c from dual;
          dbms_output.put_line(c);
          dbms_output.put(';');
     end loop;
end;
/
EOF

#####################################################################################
# And this is just because I hate double quotes unless I intend to be case sensitive
#####################################################################################

cat /tmp/tmp_tblspace_list_${ORACLE_UNQNAME}.out | tr -d \" > ${DATADIR}/remake_tempspace.sql

#####################################################################################
# Make sure we have controlfile autobackup on so spfile and control files
# get backed up automatically - this keeps us from needing a catalog
#####################################################################################

rman target / << EOF
CONFIGURE CONTROLFILE AUTOBACKUP ON;
EOF

#####################################################################################
# This is generates the RCV file for doing the restore.  It includes things
# like copying the init file to the right location as well as password files
# it uses the principle that this is a bare metal restore.
#####################################################################################

echo "host 'cp ${DATADIR}/env* ${BASEDIR}/env';"                                                                     >> $RESTORE_FILE
echo "host 'cp ${DATADIR}/init${ORACLE_SID}.ora ${ORACLE_HOME}/dbs';"                                                >> $RESTORE_FILE
echo "host 'cp ${DATADIR}/orapw* ${ORACLE_HOME}/dbs';"                                                               >> $RESTORE_FILE
echo "host 'cp ${DATADIR}/snapcf* ${ORACLE_HOME}/dbs';"                                                              >> $RESTORE_FILE
echo "set dbid=$DBID;"                                                                                               >> $RESTORE_FILE
echo "run { "                                                                                                        >> $RESTORE_FILE
echo "    startup nomount; "                                                                                         >> $RESTORE_FILE
echo "    allocate channel bkup1 type disk format '${DATADIR}/%d_bkup_%U_%p.rman_bkup';"                             >> $RESTORE_FILE
echo "    allocate channel bkup2 type disk format '${DATADIR}/%d_bkup_%U_%p.rman_bkup';"                             >> $RESTORE_FILE
echo "    allocate channel bkup3 type disk format '${DATADIR}/%d_bkup_%U_%p.rman_bkup';"                             >> $RESTORE_FILE
echo "    allocate channel bkup4 type disk format '${DATADIR}/%d_bkup_%U_%p.rman_bkup';"                             >> $RESTORE_FILE
echo "    restore controlfile from autobackup; "                                                                     >> $RESTORE_FILE
echo "    restore spfile from autobackup; "                                                                          >> $RESTORE_FILE
echo "    shutdown immediate; "                                                                                      >> $RESTORE_FILE
echo "    }"                                                                                                         >> $RESTORE_FILE
echo "startup mount;"                                                                                                >> $RESTORE_FILE
echo "shutdown immediate;"                                                                                           >> $RESTORE_FILE
echo "run { "                                                                                                        >> $RESTORE_FILE
echo "    startup mount; "                                                                                           >> $RESTORE_FILE
echo "    allocate channel bkup1 type disk format '${DATADIR}/%d_bkup_%U_%p.rman_bkup';"                             >> $RESTORE_FILE
echo "    allocate channel bkup2 type disk format '${DATADIR}/%d_bkup_%U_%p.rman_bkup';"                             >> $RESTORE_FILE
echo "    allocate channel bkup3 type disk format '${DATADIR}/%d_bkup_%U_%p.rman_bkup';"                             >> $RESTORE_FILE
echo "    allocate channel bkup4 type disk format '${DATADIR}/%d_bkup_%U_%p.rman_bkup';"                             >> $RESTORE_FILE
echo "    restore database; "                                                                                        >> $RESTORE_FILE
echo "    }"                                                                                                         >> $RESTORE_FILE
echo "run { "                                                                                                        >> $RESTORE_FILE
echo "    recover database;"                                                                                         >> $RESTORE_FILE
echo "    }"                                                                                                         >> $RESTORE_FILE
echo "alter database open resetlogs;"                                                                                >> $RESTORE_FILE


if [[ -a $RCVFILE ]]
     then rm $RCVFILE
fi

if [[ $TMP_TYPE = [FfDd] ]]
     then
          echo "run { "                                                                                           >> $RCVFILE
          echo "      set controlfile autobackup format for device type disk to '${DATADIR}/controlfile_%F.ora';" >> $RCVFILE
          echo "      allocate channel bkup1 type disk format \"$DATADIR/%d_bkup_%U_%p.rman_bkup\";"              >> $RCVFILE
          echo "      allocate channel bkup2 type disk format \"$DATADIR/%d_bkup_%U_%p.rman_bkup\";"              >> $RCVFILE
          echo "      allocate channel bkup3 type disk format \"$DATADIR/%d_bkup_%U_%p.rman_bkup\";"              >> $RCVFILE
          echo "      allocate channel bkup4 type disk format \"$DATADIR/%d_bkup_%U_%p.rman_bkup\";"              >> $RCVFILE
          echo "      set limit channel bkup1 kbytes 1024000;"                                                    >> $RCVFILE
          echo "      set limit channel bkup2 kbytes 1024000;"                                                    >> $RCVFILE
          echo "      set limit channel bkup3 kbytes 1024000;"                                                    >> $RCVFILE
          echo "      set limit channel bkup4 kbytes 1024000;"                                                    >> $RCVFILE
          echo "      backup full as compressed backupset "                                                       >> $RCVFILE
          echo "           filesperset 4                  "                                                       >> $RCVFILE
          echo "           tag='Backup for $TMPDATE'      "                                                       >> $RCVFILE
          echo "           database                       "                                                       >> $RCVFILE
          echo "           include current controlfile;   "                                                       >> $RCVFILE
          echo "    }" >> $RCVFILE
fi
echo "sql \"alter system switch logfile\";"                                                                       >> $RCVFILE
echo "sql \"alter system checkpoint\";"                                                                           >> $RCVFILE
if [[ $TMP_TYPE = [AaFf] ]]
     then
               echo "run { "                                                                                      >> $RCVFILE
               echo " set controlfile autobackup format for device type disk to '${DATADIR}/controlfile_%F.ora';" >> $RCVFILE
               echo "      allocate channel arch1 type disk format \"${DATADIR}/%d_arch_%U_%p.rman_bkup\";"       >> $RCVFILE
               echo "      allocate channel arch2 type disk format \"${DATADIR}/%d_arch_%U_%p.rman_bkup\";"       >> $RCVFILE
               echo "      allocate channel arch3 type disk format \"${DATADIR}/%d_arch_%U_%p.rman_bkup\";"       >> $RCVFILE
               echo "      allocate channel arch4 type disk format \"${DATADIR}/%d_arch_%U_%p.rman_bkup\";"       >> $RCVFILE
               echo "      set limit channel arch1 kbytes 2048000;"                                               >> $RCVFILE
               echo "      set limit channel arch2 kbytes 2048000;"                                               >> $RCVFILE
               echo "      set limit channel arch3 kbytes 2048000;"                                               >> $RCVFILE
               echo "      set limit channel arch4 kbytes 2048000;"                                               >> $RCVFILE
               echo "      backup archivelog all;               "                                                 >> $RCVFILE
               echo "      delete archivelog all backed up 2 times to device type disk;      "                    >> $RCVFILE
               echo "    }"                                                                                       >> $RCVFILE
fi


{ # Output for manual archive run
echo "`date`\n---------- Beginning of Manual archivelog backup ----------\n"

rman target / nocatalog cmdfile $RCVFILE

export RETURN_STATUS=$?

echo "\n\n ---------- Ending Manual backup ----------\n`date`\n"
echo "exit $RETURN_STATUS"

} >> $RMANLOG/$ARCHFILE

cp $RMANLOG/$ARCHFILE $DATADIR
#######################################################################
# If the backup had problems we need to tell someone!
#######################################################################
if [[ $RETURN_STATUS -ne 0 && "$TMP_ADDR" = "none" ]]
     then cat $RMANLOG/$ARCHFILE | \
          $MAILX -s "**** BACKUP FAILED ***** $ORACLE_UNQNAME on $TMPDATE" dhaas@tsys.com
          export MAIL_FLAG=1
fi

if [[ "$TMP_ADDR" != "none" && $MAIL_FLAG -ne 1 ]]
     then cat $RMANLOG/$ARCHFILE | \
          grep -v ">" | \
          grep -v release | \
          grep -v channel | \
          grep -v piece   | \
          grep -v input   | \
          grep -v compil  | \
          grep -v archive | \
          grep -v "backup set" | \
          grep -v execut  | \
          grep -v "set_count" | \
          grep [a-z] | $MAILX -s "Backup report for $ORACLE_UNQNAME on $TMPDATE" $TMP_ADDR
          exit 1
     else cat $RMANLOG/$ARCHFILE
fi

cp ${ORACLE_HOME}/dbs/snap* $DATADIR

sqlplus "/ as sysdba" << EOF
alter database backup controlfile to '${DATADIR}/${ORACLE_UNQNAME}_controlfile_backup.ora.${TMPDATE}_${TMPTIME}';
alter database backup controlfile to trace as '${DATADIR}/${ORACLE_UNQNAME}_controlfile_trace.ora.${TMPDATE}_${TMPTIME}';
EOF

cd $DATADIR
chown oracle:dba *
chmod 660 *

if [[ $GZFILES -ne 0 ]]
     then cd $DATADIR
          export GZFILES=`ls -ltr | awk 'NF > 7 {print $NF}'`
          for gzfile in $GZFILES ; do
               nice -n 10 gzip -v9 $gzfile
          done
fi

rm $TMP_SQL $TMP_DTE $ARC_CHK $DBID_VAL $TMPTBL

