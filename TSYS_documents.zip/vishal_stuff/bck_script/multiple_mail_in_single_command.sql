#!/bin/sh

#export ORACLE_BASE=/ora1/oracle
#export ORACLE_HOME=/ora1/oracle/OraHome1


mydate=`date +%m%d%y%H`

cd /archive/dba/bkups/

dumps=/data/oracle92/oracle_backup/full_bck

logs=$dumps/logs

previous_logs=$dumps/previous

#removing all prevous logs
rm -f $previous_logs/dev_export_logs.log
rm -f $previous_logs/trans_export_logs.log


#moving all old logs to prevoius folde
mv $logs/dev_export_logs.log  $previous_logs/
mv $logs/trans_export_logs.log  $previous_logs/


#zip file path
tarpath=$dumps/dump

MAIL_FILE="/data/oracle92/oracle_backup/mailbox/dev.txt"

dev_alertErr="/data/oracle92/oracle_backup/dev_alert.err"
trans_alertErr="/data/oracle92/oracle_backup/trans_alert.err"


####################################################################
#function for sending if export logfile conetents error else will send success mail

mail_status()
{
MAILSERVER="mail.infonox.com"
MAIL_FROM="rahulc@infonox.com"
MAIL_TO="milindb@infonox.com"
MAIL_CC="narendra@infonox.com"
MAIL_CC="gaurav@infonox.com"
MAIL_CC="srikanth@infonox.com"
MAIL_CC="dipali@infonox.com"
MAIL_CC="rahulc@infonox.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
RCPT TO: $MAIL_CC
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
Cc: $MAIL_CC
Cc: $MAIL_CC
Cc: $MAIL_CC
Cc: $MAIL_CC
Cc: $MAIL_CC
Subject: Backup export For Local databases.

Hi All,

  `cat ${MAIL_FILE}`

Regards,
 RahulC
.
"

echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
######################################################################

#local dev db.
exp expuser/expdev@dev file=$dumps/dump/exp_dev_$mydate.dmp log=$logs/dev_export_logs.log full=y rows=y statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files

cat $logs/dev_export_logs.log | grep "ORA-" > $dev_alertErr
COUNT=`cat $dev_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for dev database"
    echo -e  "######################## Dev DB ####################################\n " > $MAIL_FILE
    echo  " No Errors in Dev database export logs " >> $MAIL_FILE
    echo  " Successfully completed the backup of Dev database" >> $MAIL_FILE
else
    echo " sending failure for Dev database"
    echo -e "######################## Dev database ####################################\n " > $MAIL_FILE
    echo " Errors in export log file $logs/dev_export_logs.log for Dev database" >> $MAIL_FILE
    cat $dev_alertErr >> $MAIL_FILE
fi

#zip the dump file
tar -cvzf $tarpath/exp_dev_$mydate.tar $dumps/dump/exp_dev_$mydate.dmp
rm -f $dumps/dump/exp_dev_$mydate.dmp

rm -f $alertErr
#######################################################################

#Trans Database
exp expuser/exptrans@trans file=$dumps/dump/exp_trans_$mydate.dmp log=$logs/trans_export_logs.log full=y rows=y statistics=none indexes=n buffer=500000

#sending mail if there is any ORA- error in export log files
cat $logs/dev_export_logs.log | grep "ORA-" > $trans_alertErr
COUNT=`cat $trans_alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
    echo " Success Mail for Trans Database"
    echo -e "\n ######################## Trans Database ####################\n" >> $MAIL_FILE
    echo " No Errors in Trans Database export logs " >> $MAIL_FILE
    echo " Successfully completed the backup of Trans Database schemas" >> $MAIL_FILE
else
    echo " sending failure for Trans Database"
    echo -e "\n ######################## Trans Database ####################\n" >> $MAIL_FILE
    echo -e "  Errors in export log file $logs/trans_export_logs.log for Trans Database\n" >> $MAIL_FILE
    cat $trans_alertErr >> $MAIL_FILE
fi

mail_status

#zip the dump file
tar -cvzf $tarpath/exp_trans_$mydate.tar $dumps/dump/exp_trans_$mydate.dmp
rm -f $dumps/dump/exp_trans_$mydate.dmp

rm -f $alertErr
#######################################################################
