#!/bin/sh
sqlplus -s / as sysdba << eof
set pagesize 0;
set head off
set echo off
set feedback off
spool /home/oracle/cronjobs/drop_tbls_srpt.log
SELECT 'drop table '||owner||'.'||object_name||' purge;' oops FROM dba_objects WHERE (object_name LIKE 'SC_TEMP%' OR object_name LIKE 'SN_TEMP%') AND object_type='TABLE' AND created < SYSDATE-50/1440;
select 'exit' from dual;
spool off
start /home/oracle/cronjobs/cronjob_srpt_2_drop_SNtemp_tbls.sh
host rm -f /home/oracle/cronjobs/drop_tbls_srpt.log
eof


00 20 * * * sh /home/oracle/cronjobs/cronjob_srpt_2_drop_SNtemp_tbls.sh


00 20 * * * sh /oradata2/bkups/bkup_scripts/expdp_qadb_bkups_script.sh





CREATE USER OPS$DBJOBS
  IDENTIFIED EXTERNALLY
  DEFAULT TABLESPACE USERS
  TEMPORARY TABLESPACE TEMP
  PROFILE DEFAULT
  ACCOUNT UNLOCK;
  -- 3 Roles for OPS$DBJOBS 
  GRANT RESOURCE TO OPS$DBJOBS;
  GRANT EXP_FULL_DATABASE TO OPS$DBJOBS;
  GRANT CONNECT TO OPS$DBJOBS;
  ALTER USER OPS$DBJOBS DEFAULT ROLE ALL;
  -- 1 System Privilege for OPS$DBJOBS 
  GRANT UNLIMITED TABLESPACE TO OPS$DBJOBS;
  -- 1 Object Privilege for OPS$DBJOBS 
    GRANT READ, WRITE ON DIRECTORY SYS.DPDUMP4 TO OPS$DBJOBS;

	
	
30 22 * * * sh /oradata3/dbjobs/backups/bkups_scripts/expdp_qadb_bkups_Script.sh



#!/bin/bash
#Oracle Path variables
export AGENT_HOME=/home/oracle/agent11g
export ORACLE_BASE=/home/oracle/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11.1.0/db_1
export ORACLE_SID=regdev
TNS_ADMIN=/home/oracle/app/oracle/product/11.1.0/db_1/network/admin; export TNS_ADMIN
PATH=$PATH:$HOME/bin:$ORACLE_HOME/bin:$AGENT_HOME/bin; export PATH


maildate=$(date +"%Y-%m-%d")
NOW=`date +%m%d%y%H`

TAR_FILES="expdp_qadb_bkups_$NOW.tar.gz"
LOG_DIR=/oradata2/bkups/dumpfiles
alertErr="/oradata2/bkups/alertErr/exp_qadb_alert.err"

rm -f $alertErr
touch $alertErr

########################################################################################
#mail code

mail_status()
{
MAILSERVER=" tmpmail.infonox.com"
MAIL_FROM="ifx-dbdev@tsys.com"
MAIL_TO="rchaudhari@tsys.com"
MAIL_CC="rchaudhari@tsys.com"
#MAIL_CC1="rchaudhari@tsys.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
RCPT TO: $MAIL_CC
#RCPT TO: $MAIL_CC1
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
CC: $MAIL_CC
#CC: $MAIL_CC1
Subject: $SUBJECT

Hi All,

   `cat ${alertErr}`

Regards,
- DB Team...
.
"
echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
########################################################################################

#Production DB schemas backup.
expdp / directory=bkups dumpfile=expdp_qadb_bkups.dmp logfile=expdp_qadb_bkupslog.log network_link=qadb exclude=statistics,TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\"  content=all compression=all reuse_dumpfiles=y full=y

#sending mail if there is any ORA- error in export log files
cat $LOG_DIR/expdp_qadb_bkupslog.log | egrep "^ORA-|^EXP-" > $alertErr

#counting the words in alert file if it is grater then 0 it
# means there is an error in export logfile
COUNT=`cat $alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
   echo " Success Mail "
   echo "Sucessfully done the backup of qadb Database " > $alertErr
  # cat $alertErr  | mail -s "No Errors in backup of qadb Database on $maildate   " rchaudhari@tsys.com -c rchaudhari@tsys.com
else
   echo " sending failure"
   SUBJECT="Errors found in backup of qadb Database"
   echo -e "Please check the backup log file on path $LOG_DIR/expdp_qadb_bkupslog.log\n" > $alertErr
   echo -e "Below are the sample errors which found in the backup log file..\n" >> $alertErr
   cat $LOG_DIR/expdp_qadb_bkupslog.log | egrep "^ORA-|^EXP-"  >> $alertErr
   #cat $alertErr  | mail -s "Errors found in backup of qadb Database $maildate" rchaudhari@tsys.com -c rchaudhari@tsys.com
fi

mail_status

cp $LOG_DIR/expdp_qadb_bkupslog.log /oradata3/dbjobs/backups/priv_logs/

#zip the dump file
cd $LOG_DIR
tar -cvzf $TAR_FILES expdp_qadb_bkups.dmp expdp_qadb_bkupslog.log

rm -f $LOG_DIR/expdp_qadb_bkups.dmp

######################################################################


























CREATE USER OPS$DBJOBS
  IDENTIFIED EXTERNALLY
  DEFAULT TABLESPACE USERS
  TEMPORARY TABLESPACE TEMP
  PROFILE DEFAULT
  ACCOUNT UNLOCK;
  -- 3 Roles for OPS$DBJOBS 
  GRANT RESOURCE TO OPS$DBJOBS;
  GRANT EXP_FULL_DATABASE TO OPS$DBJOBS;
  GRANT CONNECT TO OPS$DBJOBS;
  ALTER USER OPS$DBJOBS DEFAULT ROLE ALL;
  -- 1 System Privilege for OPS$DBJOBS 
  GRANT UNLIMITED TABLESPACE TO OPS$DBJOBS;
  -- 1 Object Privilege for OPS$DBJOBS 
    GRANT READ, WRITE ON DIRECTORY SYS.DPDUMP4 TO OPS$DBJOBS;

	
	
30 22 * * * sh /oradata3/dbjobs/backups/bkups_scripts/expdp_devdb_bkups_Script.sh



#!/bin/bash
#Oracle Path variables
export AGENT_HOME=/home/oracle/agent11g
export ORACLE_BASE=/home/oracle/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11.1.0/db_1
export ORACLE_SID=regdev
TNS_ADMIN=/home/oracle/app/oracle/product/11.1.0/db_1/network/admin; export TNS_ADMIN
PATH=$PATH:$HOME/bin:$ORACLE_HOME/bin:$AGENT_HOME/bin; export PATH


maildate=$(date +"%Y-%m-%d")
NOW=`date +%m%d%y%H`

TAR_FILES="expdp_devdb_bkups_$NOW.tar.gz"
LOG_DIR=/oradata2/bkups/dumpfiles
alertErr="/oradata2/bkups/alertErr/exp_devdb_alert.err"

rm -f $alertErr
touch $alertErr

########################################################################################
#mail code

mail_status()
{
MAILSERVER="mail.infonox.com"
MAIL_FROM="ifx-dbdev@tsys.com"
MAIL_TO="rchaudhari@tsys.com"
MAIL_CC="mbadhe@tsys.com"
#MAIL_CC1="rchaudhari@tsys.com"

FILE_MAIL="
MAIL FROM: $MAIL_FROM
RCPT TO: $MAIL_TO
RCPT TO: $MAIL_CC
#RCPT TO: $MAIL_CC1
DATA
FROM: $MAIL_FROM
TO: $MAIL_TO
CC: $MAIL_CC
#CC: $MAIL_CC1
Subject: $SUBJECT

Hi All,

   `cat ${alertErr}`

Regards,
- DB Team...
.
"
echo "${FILE_MAIL}" | nc $MAILSERVER 25 2>/dev/null  1>&2
}
########################################################################################

#Production DB schemas backup.
expdp / directory=bkups dumpfile=expdp_devdb_bkups.dmp logfile=expdp_devdb_bkupslog.log network_link=devdb exclude=statistics,TABLE:\"LIKE \'SN_TEMP%\'\", TABLE:\"LIKE \'SC_TEMP%\'\"  content=all compression=all reuse_dumpfiles=y full=y

#sending mail if there is any ORA- error in export log files
cat $LOG_DIR/expdp_devdb_bkupslog.log | egrep "^ORA-|^EXP-" > $alertErr

#counting the words in alert file if it is grater then 0 it
# means there is an error in export logfile
COUNT=`cat $alertErr | wc -l`

if [ "$COUNT" -eq "0" ]
then
   echo " Success Mail "
   echo "Sucessfully done the backup of devdb Database " > $alertErr
  # cat $alertErr  | mail -s "No Errors in backup of devdb Database on $maildate   " rchaudhari@tsys.com -c rchaudhari@tsys.com
else
   echo " sending failure"
   SUBJECT="Errors found in backup of devdb Database"
   echo -e "Please check the backup log file on path $LOG_DIR/expdp_devdb_bkupslog.log\n" > $alertErr
   echo -e "Below are the sample errors which found in the backup log file..\n" >> $alertErr
   cat $LOG_DIR/expdp_devdb_bkupslog.log | egrep "^ORA-|^EXP-"  >> $alertErr
   #cat $alertErr  | mail -s "Errors found in backup of devdb Database $maildate" rchaudhari@tsys.com -c rchaudhari@tsys.com
fi

mail_status

cp $LOG_DIR/expdp_devdb_bkupslog.log /oradata3/dbjobs/backups/priv_logs/

#zip the dump file
cd $LOG_DIR
tar -cvzf $TAR_FILES expdp_devdb_bkups.dmp expdp_devdb_bkupslog.log

rm -f $LOG_DIR/expdp_devdb_bkups.dmp

######################################################################


