# Written by: Tom Best
export ORACLE_SID=orcl
sqlplus / as sysdba <<-EOI
  select file#, avg(datafile_blocks),
    avg(blocks_read),
    avg(blocks_read/datafile_blocks) * 100 as PCT_READ_FOR_BACKUP,
    avg(blocks)
  from v\$backup_datafile
  where used_change_tracking = 'YES'
    and incremental_level > 0
    group by file#;
  quit
EOI
