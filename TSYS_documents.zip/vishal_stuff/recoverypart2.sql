/ora1/oracle/admin/aqprod/udump/aqprod_ora_30071.trc
Oracle Database 10g Enterprise Edition Release 10.2.0.3.0 - Production
With the Partitioning, OLAP and Data Mining options
ORACLE_HOME = /ora1/oracle/OraHome1
System name:	Linux
Node name:	sc-archives.ifxsc.com
Release:	2.6.9-42.ELsmp
Version:	#1 SMP Wed Jul 12 23:27:17 EDT 2006
Machine:	i686
Instance name: aqprod
Redo thread mounted by this instance: 1
Oracle process number: 15
Unix process pid: 30071, image: oracle@sc-archives.ifxsc.com (TNS V1-V3)

*** SERVICE NAME:() 2009-02-20 21:04:08.516
*** SESSION ID:(1099.9) 2009-02-20 21:04:08.516
*** 2009-02-20 21:04:08.516
-- The following are current System-scope REDO Log Archival related
-- parameters and can be included in the database initialization file.
--
-- LOG_ARCHIVE_DEST=''
-- LOG_ARCHIVE_DUPLEX_DEST=''
--
-- LOG_ARCHIVE_FORMAT=%t_%s_%r.dbf
--
-- DB_UNIQUE_NAME="aqprod"
--
-- LOG_ARCHIVE_CONFIG='SEND, RECEIVE, NODG_CONFIG'
-- LOG_ARCHIVE_MAX_PROCESSES=2
-- STANDBY_FILE_MANAGEMENT=MANUAL
-- STANDBY_ARCHIVE_DEST=?/dbs/arch
-- FAL_CLIENT=''
-- FAL_SERVER=''
--
-- LOG_ARCHIVE_DEST_10='LOCATION=USE_DB_RECOVERY_FILE_DEST'
-- LOG_ARCHIVE_DEST_10='OPTIONAL REOPEN=300 NODELAY'
-- LOG_ARCHIVE_DEST_10='ARCH NOAFFIRM NOEXPEDITE NOVERIFY SYNC'
-- LOG_ARCHIVE_DEST_10='REGISTER NOALTERNATE NODEPENDENCY'
-- LOG_ARCHIVE_DEST_10='NOMAX_FAILURE NOQUOTA_SIZE NOQUOTA_USED NODB_UNIQUE_NAME'
-- LOG_ARCHIVE_DEST_10='VALID_FOR=(PRIMARY_ROLE,ONLINE_LOGFILES)'
-- LOG_ARCHIVE_DEST_STATE_10=ENABLE
--
-- Below are two sets of SQL statements, each of which creates a new
-- control file and uses it to open the database. The first set opens
-- the database with the NORESETLOGS option and should be used only if
-- the current versions of all online logs are available. The second
-- set opens the database with the RESETLOGS option and should be used
-- if online logs are unavailable.
-- The appropriate set of statements can be copied from the trace into
-- a script file, edited as necessary, and executed when there is a
-- need to re-create the control file.
--
--     Set #1. NORESETLOGS case
--
-- The following commands will create a new control file and use it
-- to open the database.
-- Data used by Recovery Manager will be lost.
-- Additional logs may be required for media recovery of offline
-- Use this only if the current versions of all online logs are
-- available.
-- WARNING! The current control file needs to be checked against
-- the datafiles to insure it contains the correct files. The
-- commands printed here may be missing log and/or data files.
-- Another report should be made after the database has been
-- successfully opened.
-- After mounting the created controlfile, the following SQL
-- statement will place the database in the appropriate
-- protection mode:
--  ALTER DATABASE SET STANDBY DATABASE TO MAXIMIZE PERFORMANCE
STARTUP NOMOUNT
CREATE CONTROLFILE REUSE DATABASE "AQPROD" NORESETLOGS  NOARCHIVELOG
    MAXLOGFILES 16
    MAXLOGMEMBERS 3
    MAXDATAFILES 100
    MAXINSTANCES 8
    MAXLOGHISTORY 5842
LOGFILE
  GROUP 1 (
    '/ora2/oracle/oradata/aqprod/redo101.log',
    '/ora1/oracle/oradata/aqprod/redo102.log'
  ) SIZE 100M,
  GROUP 2 (
    '/ora2/oracle/oradata/aqprod/redo201.log',
    '/ora1/oracle/oradata/aqprod/redo202.log'
  ) SIZE 100M,
  GROUP 3 (
    '/ora2/oracle/oradata/aqprod/redo301.log',
    '/ora1/oracle/oradata/aqprod/redo302.log'
  ) SIZE 100M
-- STANDBY LOGFILE
DATAFILE
  '/ora2/oracle/oradata/aqprod/system01.dbf',
  '/ora2/oracle/oradata/aqprod/undotbs01.dbf',
  '/ora2/oracle/oradata/aqprod/sysaux01.dbf',
  '/archive/oradata/aqprod/users02.dbf',
  '/ora3/oracle/oradata/aqprod/trans_data02.dbf',
  '/ora3/oracle/oradata/aqprod/trans_data01.dbf',
  '/ora3/oracle/oradata/aqprod/trans_200702.dbf',
  '/archive/oradata/aqprod/trans_200701.dbf',
  '/ora1/oracle/oradata/aqprod/archive_data01.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA02.dbf',
  '/archive/oradata/aqprod/users102.dbf',
  '/ora1/oracle/oradata/aqprod/users101.dbf',
  '/archive/oradata/aqprod/users04.dbf',
  '/archive/oradata/aqprod/users01.dbf',
  '/archive/oradata/aqprod/trans_200705.dbf',
  '/archive/oradata/aqprod/trans_200704.dbf',
  '/archive/oradata/aqprod/trans_200702.dbf',
  '/archive/oradata/aqprod/trans_200708.dbf',
  '/archive/oradata/aqprod/trans_200707.dbf',
  '/archive/oradata/aqprod/trans_200706.dbf',
  '/archive/oradata/aqprod/users08.dbf',
  '/archive/oradata/aqprod/users07.dbf',
  '/archive/oradata/aqprod/users06.dbf',
  '/archive/oradata/aqprod/users05.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA08.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA07.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA06.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA05.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA04.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA03.dbf',
  '/ora2/oracle/oradata/aqprod/trans_2007bb102.dbf',
  '/ora2/oracle/oradata/aqprod/trans_2007b101.dmp'
CHARACTER SET WE8ISO8859P1
;
-- Commands to re-create incarnation table
-- Below log names MUST be changed to existing filenames on
-- disk. Any one log file from each branch can be used to
-- re-create incarnation records.
-- ALTER DATABASE REGISTER LOGFILE '/ora2/oracle/flash_area/AQPROD/archivelog/2009_02_20/o1_mf_1_1_%u_.arc';
-- Recovery is required if any of the datafiles are restored backups,
-- or if the last shutdown was not normal or immediate.
RECOVER DATABASE
-- Database can now be opened normally.
ALTER DATABASE OPEN;
-- No tempfile entries found to add.
--
--     Set #2. RESETLOGS case
--
-- The following commands will create a new control file and use it
-- to open the database.
-- Data used by Recovery Manager will be lost.
-- The contents of online logs will be lost and all backups will
-- be invalidated. Use this only if online logs are damaged.
-- WARNING! The current control file needs to be checked against
-- the datafiles to insure it contains the correct files. The
-- commands printed here may be missing log and/or data files.
-- Another report should be made after the database has been
-- successfully opened.
-- After mounting the created controlfile, the following SQL
-- statement will place the database in the appropriate
-- protection mode:
--  ALTER DATABASE SET STANDBY DATABASE TO MAXIMIZE PERFORMANCE
STARTUP NOMOUNT
CREATE CONTROLFILE REUSE DATABASE "AQPROD" RESETLOGS  NOARCHIVELOG
    MAXLOGFILES 16
    MAXLOGMEMBERS 3
    MAXDATAFILES 100
    MAXINSTANCES 8
    MAXLOGHISTORY 5842
LOGFILE
  GROUP 1 (
    '/ora2/oracle/oradata/aqprod/redo101.log',
    '/ora1/oracle/oradata/aqprod/redo102.log'
  ) SIZE 100M,
  GROUP 2 (
    '/ora2/oracle/oradata/aqprod/redo201.log',
    '/ora1/oracle/oradata/aqprod/redo202.log'
  ) SIZE 100M,
  GROUP 3 (
    '/ora2/oracle/oradata/aqprod/redo301.log',
    '/ora1/oracle/oradata/aqprod/redo302.log'
  ) SIZE 100M
-- STANDBY LOGFILE
DATAFILE
  '/ora2/oracle/oradata/aqprod/system01.dbf',
  '/ora2/oracle/oradata/aqprod/undotbs01.dbf',
  '/ora2/oracle/oradata/aqprod/sysaux01.dbf',
  '/archive/oradata/aqprod/users02.dbf',
  '/ora3/oracle/oradata/aqprod/trans_data02.dbf',
  '/ora3/oracle/oradata/aqprod/trans_data01.dbf',
  '/ora3/oracle/oradata/aqprod/trans_200702.dbf',
  '/archive/oradata/aqprod/trans_200701.dbf',
  '/ora1/oracle/oradata/aqprod/archive_data01.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA02.dbf',
  '/archive/oradata/aqprod/users102.dbf',
  '/ora1/oracle/oradata/aqprod/users101.dbf',
  '/archive/oradata/aqprod/users04.dbf',
  '/archive/oradata/aqprod/users01.dbf',
  '/archive/oradata/aqprod/trans_200705.dbf',
  '/archive/oradata/aqprod/trans_200704.dbf',
  '/archive/oradata/aqprod/trans_200702.dbf',
  '/archive/oradata/aqprod/trans_200708.dbf',
  '/archive/oradata/aqprod/trans_200707.dbf',
  '/archive/oradata/aqprod/trans_200706.dbf',
  '/archive/oradata/aqprod/users08.dbf',
  '/archive/oradata/aqprod/users07.dbf',
  '/archive/oradata/aqprod/users06.dbf',
  '/archive/oradata/aqprod/users05.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA08.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA07.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA06.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA05.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA04.dbf',
  '/archive/oradata/aqprod/ARCHIVE_DATA03.dbf',
  '/ora2/oracle/oradata/aqprod/trans_2007bb102.dbf',
  '/ora2/oracle/oradata/aqprod/trans_2007b101.dmp'
CHARACTER SET WE8ISO8859P1
;
-- Commands to re-create incarnation table
-- Below log names MUST be changed to existing filenames on
-- disk. Any one log file from each branch can be used to
-- re-create incarnation records.
-- ALTER DATABASE REGISTER LOGFILE '/ora2/oracle/flash_area/AQPROD/archivelog/2009_02_20/o1_mf_1_1_%u_.arc';
-- Recovery is required if any of the datafiles are restored backups,
-- or if the last shutdown was not normal or immediate.
RECOVER DATABASE USING BACKUP CONTROLFILE
-- Database can now be opened zeroing the online logs.
ALTER DATABASE OPEN RESETLOGS;
-- No tempfile entries found to add.
--
