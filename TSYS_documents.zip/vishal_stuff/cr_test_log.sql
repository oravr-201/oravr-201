REM For training only
set echo on
-- cleanup previous runs
-- you will see an error the first time this script is run
drop table system.test_log;

-- create a table to hold timing information

create table system.test_log
(job_type	VARCHAR2(10),
timemark	VARCHAR2(10),
act_time	TIMESTAMP with TIME ZONE)
/

