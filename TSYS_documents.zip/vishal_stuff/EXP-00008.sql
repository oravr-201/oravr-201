Q The following Export Error  Sloved on Server Compaq
----> 
    While Exporting any schema through service name @devdb on Server compaq the 
    following were the errors           
        EXP-00008: ORACLE error 604 encountered
        ORA-00604: error occurred at recursive SQL level 1
        ORA-06502: PL/SQL: numeric or value error: character string buffer too small
        ORA-06512: at line 8
        ORA-00904: invalid column name
        EXP-00000: Export terminated unsuccessfully
        
        
    Solution :--  
            Solved it by running CATALOG.SQL as it was found that incompatibility 
            with the catalog.
