REM "************************** "
REM "For training purposes ONLY, execute as the oracle OS user

set echo on
set serveroutput on
set term on
set lines 200
set pages 44
set pause on pause "Press [Enter] to continue..."

drop tablespace tbssga including contents and datafiles;

create tablespace tbssga datafile '+DATA' size 20m;

drop tablespace mytemp including contents and datafiles;

create temporary tablespace mytemp tempfile '+DATA' size 40m reuse;

drop user amm cascade;

create user amm 
 identified by "oracle_4U" 
 default tablespace tbssga 
 temporary tablespace mytemp;

grant connect,resource,dba to amm;
pause Press [Enter] to continue...

column COMP format a10

SELECT substr(COMPONENT, 0, 10) COMP, CURRENT_SIZE CS, USER_SPECIFIED_SIZE US 
  FROM v$memory_dynamic_components 
 WHERE CURRENT_SIZE!=0;
pause Press [Enter] to continue...

