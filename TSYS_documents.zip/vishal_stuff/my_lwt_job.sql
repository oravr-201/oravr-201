REM For training only
set echo on
BEGIN 
  -- the drop procedure will give and error the first time
  -- this script is run
  sys.DBMS_SCHEDULER.DROP_JOB('my_lwt_job');
END;
/

DECLARE
   jobname VARCHAR2(30);
BEGIN
-- Create the Job
jobname := 'my_lwt_job';
sys.dbms_scheduler.create_job(
    job_name => '"SYSTEM"."MY_LWT_JOB"',
    program_name => '"SYSTEM"."PROG_1"',
    job_class => '"DEFAULT_JOB_CLASS"',
    job_style => 'LIGHTWEIGHT',
    repeat_interval => 'FREQ=DAILY;INTERVAL=2',
    comments => 'Lightweight job',
    enabled => TRUE);
END;
/
