#!/usr/bin/ksh

#---------------------------------------------------------------------
# author : rtatikon
# usage  : object_status.sh [before|after]
# does   : takes object status #
#---------------------------------------------------------------------

if [ $# -eq 0 ]
then
    echo "Usage : $0 [ before | aftter ]"
    exit 1
fi

status=$1

echo "\n\nVerifying Database List for upgrading "
if [ ! -s dbase.lst ]
then
   echo "\n\ndbase.lst file is missing in cdupg directory or dbase.lst is empty !!!\n\n"
   exit 1
fi

for sid in `cat dbase.lst` do

	echo "\nRunning showcompile on $sid db for $status upgrade \n"
        export ORACLE_SID=$sid
	sleep 3
	upg_showcompile.sh

	echo "set lines 132 trimsp on pages 1000 echo on
        col comp_name for a35
	spool upg_10g_${sid}_${status}.log

	select 'Databse Info : '||instance_name||' on '||host_name dbInfo from v\$instance;

	Prompt Taking Objects Invalid Status 	select owner,status,count(1) from dba_objects where status='INVALID' group by owner,status 	order by owner,status ;

	Prompt Taking Objects Total Status
	select status,count(1) from dba_objects group by status order by status ;

	Prompt Checking dba_registry status
        select comp_id,comp_name,version,status from dba_registry ;
	spool off

	spool upg_10g_${sid}_${status}_otherInfo.log

	prompt Taking Database links 	col OWNER for a10
	col HOST for a10
	col USERNAME for a10
	col DB_LINK for a30
	select * from dba_db_links ;

	Promp Checking BACKUP status
	select '**ALERT:The TableSpace' || NAME || ' In BACKUP Mode ',STATUS from v\$tablespace vd,v\$backup vb
	where vd.TS#=vb.FILE# and STATUS='ACTIVE' ;

	Prompt Taking o/s distributed transactions info
	col GLOBAL_TRAN_ID for a32
	col OS_USER for a10
	col DB_USER for a15
	select local_tran_id, global_tran_id,OS_USER,DB_USER from dba_2pc_pending;

	prompt Taking INVALID object information
	col OBJECT_NAME for a32
	col OWNER for a15
        select owner,object_name,object_type,object_id,status
        from dba_objects where object_id in(select obj# from  sys.obj\$ where status=3)
        order by 1,2 ;

	Prompt Checking x\$view dependecies
	set lines 132 trimsp on
	col REFERENCED_NAME for a20
	select d1.OWNER,d1.name,d2.OBJECT_TYPE,d1.REFERENCED_NAME,d2.STATUS from dba_dependencies d1, dba_objects d2
	where d1.owner not  in ('SYS','SYSTEM','ORACLE') and  d1.REFERENCED_NAME like 'X%\$%'
	and d1.owner=d2.owner and d1.name=d2.OBJECT_NAME
	order by 1,2 ;

	spool off
	" | sqlplus -s '/ as sysdba'

echo  "\n\nLog file : vi upg_10g_${sid}_${status}.log \n"

done
