#!/bin/sh
#
# Run as: oracle
# This creates the APPRAISAL tablespace.
#
# Written by: Mark Fuller
. oraenv << EOI
orcl
EOI
 
sqlplus -s / as sysdba << EOI2
  CREATE TABLESPACE APPRAISAL DATAFILE '+DATA' SIZE 25M;
  create table hr.emp tablespace appraisal as select * from hr.employees;
  quit
EOI2
exit

